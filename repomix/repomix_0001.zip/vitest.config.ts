import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    setupFiles: ['tests/testing/vitestSetup.ts'],
    coverage: {
      include: ['src/**/*'],
      exclude: ['src/index.ts'],
      reporter: ['text', 'json', 'html'],
    },
    watch: false,
    testTimeout: 15000,
  },
});
