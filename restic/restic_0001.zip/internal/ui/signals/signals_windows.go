package signals

func setupSignals() {}
