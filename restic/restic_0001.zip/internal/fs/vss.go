//go:build !windows

package fs

import (
	"time"

	"github.com/restic/restic/internal/errors"
)

// mountPoint is a dummy for non-windows platforms to let client code compile.
type mountPoint struct {
}

// IsSnapshotted is true if this mount point was snapshotted successfully.
func (p *mountPoint) IsSnapshotted() bool {
	return false
}

// GetSnapshotDeviceObject returns root path to access the snapshot files and folders.
func (p *mountPoint) GetSnapshotDeviceObject() string {
	return ""
}

// vssSnapshot is a dummy for non-windows platforms to let client code compile.
type vssSnapshot struct {
	mountPointInfo map[string]mountPoint
}

// HasSufficientPrivilegesForVSS returns nil if the user is allowed to use VSS.
func HasSufficientPrivilegesForVSS() error {
	return errors.New("VSS snapshots are only supported on windows")
}

// getVolumeNameForVolumeMountPoint add trailing backslash to input parameter
// and calls the equivalent windows api.
func getVolumeNameForVolumeMountPoint(mountPoint string) (string, error) {
	return mountPoint, nil
}

// newVssSnapshot creates a new vss snapshot. If creating the snapshots doesn't
// finish within the timeout an error is returned.
func newVssSnapshot(_ string,
	_ string, _ time.Duration, _ volumeFilter, _ ErrorHandler) (vssSnapshot, error) {
	return vssSnapshot{}, errors.New("VSS snapshots are only supported on windows")
}

// Delete deletes the created snapshot.
func (p *vssSnapshot) Delete() error {
	return nil
}

// GetSnapshotDeviceObject returns root path to access the snapshot files
// and folders.
func (p *vssSnapshot) GetSnapshotDeviceObject() string {
	return ""
}
