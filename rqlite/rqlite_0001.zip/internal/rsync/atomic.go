package rsync

import (
	"sync"
	"sync/atomic"
	"time"
)

// AtomicMonotonicUint64 is a uint64 with atomic operations which will
// only store the maximum value.
type AtomicMonotonicUint64 struct {
	value uint64
	mu    sync.Mutex
}

// NewAtomicMonotonicUint64 returns a new AtomicMonotonicUint64.
func NewAtomicMonotonicUint64() *AtomicMonotonicUint64 {
	return &AtomicMonotonicUint64{}
}

// Load returns the stored value.
func (a *AtomicMonotonicUint64) Load() uint64 {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.value
}

// Store stores a new value if it is greater than the current value.
func (a *AtomicMonotonicUint64) Store(v uint64) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if v > a.value {
		a.value = v
	}
}

// Reset resets the stored value to 0.
func (a *AtomicMonotonicUint64) Reset() {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.value = 0
}

// AtomicTime is a time.Time with atomic operations.
type AtomicTime struct {
	t  time.Time
	mu sync.RWMutex
}

// NewAtomicTime returns a new AtomicTime.
func NewAtomicTime() *AtomicTime {
	return &AtomicTime{}
}

// Store stores a new time.
func (t *AtomicTime) Store(newTime time.Time) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.t = newTime
}

// Load returns the stored time.
func (t *AtomicTime) Load() time.Time {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.t
}

// Add adds a duration to the stored time.
func (t *AtomicTime) Add(d time.Duration) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.t = t.t.Add(d)
}

// Sub return the difference between the stored time and the given time.
func (t *AtomicTime) Sub(tt *AtomicTime) time.Duration {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.t.Sub(tt.t)
}

// IsZero returns true if the stored time is zero, false otherwise.
func (t *AtomicTime) IsZero() bool {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.t.IsZero()
}

// AtomicBool is a boolean with atomic operations.
type AtomicBool struct {
	state int32 // 1 for true, 0 for false
}

// NewAtomicBool returns a new AtomicBool initialized to false.
func NewAtomicBool() *AtomicBool {
	return &AtomicBool{state: 0}
}

// Set sets the AtomicBool to true.
func (b *AtomicBool) Set() {
	atomic.StoreInt32(&b.state, 1)
}

// Unset sets the AtomicBool to false.
func (b *AtomicBool) Unset() {
	atomic.StoreInt32(&b.state, 0)
}

// SetBool sets the AtomicBool to the given boolean value.
func (b *AtomicBool) SetBool(state bool) {
	var value int32
	if state {
		value = 1
	}
	atomic.StoreInt32(&b.state, value)
}

// Is returns true if the AtomicBool is true, false otherwise.
func (b *AtomicBool) Is() bool {
	return atomic.LoadInt32(&b.state) == 1
}

// IsNot returns true if the AtomicBool is false, false otherwise.
func (b *AtomicBool) IsNot() bool {
	return atomic.LoadInt32(&b.state) == 0
}

// AtomicString is a string with atomic operations.
type AtomicString struct {
	s  string
	mu sync.RWMutex
}

// NewAtomicString returns a new AtomicString.
func NewAtomicString() *AtomicString {
	return &AtomicString{}
}

// Store stores a new string.
func (s *AtomicString) Store(newString string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.s = newString
}

// Load returns the stored string.
func (s *AtomicString) Load() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.s
}

// AtomicMap is a thread-safe map with atomic operations.
type AtomicMap[K comparable, V any] struct {
	m  map[K]V
	mu sync.RWMutex
}

// NewAtomicMap returns a new AtomicMap.
func NewAtomicMap[K comparable, V any]() *AtomicMap[K, V] {
	return &AtomicMap[K, V]{
		m: make(map[K]V),
	}
}

// Get returns the value for the given key and a boolean indicating if the key exists.
func (m *AtomicMap[K, V]) Get(key K) (V, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	value, exists := m.m[key]
	return value, exists
}

// Set stores the value for the given key.
func (m *AtomicMap[K, V]) Set(key K, value V) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.m[key] = value
}
