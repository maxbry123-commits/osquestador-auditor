package cdc

import (
	"bytes"
	"crypto/tls"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

func Test_StdoutSink_Write(t *testing.T) {
	sink := NewStdoutSink()

	// Redirect stdout to capture output
	oldStdout := os.Stdout
	r, w, _ := os.Pipe()
	os.Stdout = w

	testData := []byte(`{"test": "data"}`)
	_, err := sink.Write(testData)
	if err != nil {
		t.Fatalf("Write failed: %v", err)
	}

	// Restore stdout and read captured output
	w.Close()
	os.Stdout = oldStdout

	var buf bytes.Buffer
	io.Copy(&buf, r)
	r.Close()

	output := strings.TrimSpace(buf.String())
	expected := string(testData)
	if output != expected {
		t.Errorf("Expected output %q, got %q", expected, output)
	}
}

func Test_StdoutSink_Close(t *testing.T) {
	sink := NewStdoutSink()
	err := sink.Close()
	if err != nil {
		t.Errorf("Close should not return error, got: %v", err)
	}
}

func Test_StdoutSink_String(t *testing.T) {
	sink := NewStdoutSink()
	expected := "stdout"
	if got := sink.String(); got != expected {
		t.Errorf("Expected %q, got %q", expected, got)
	}
}

func Test_HTTPSink_Write_Success(t *testing.T) {
	// Create test server
	var receivedData []byte
	var receivedContentType string
	testSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		receivedContentType = r.Header.Get("Content-Type")
		body, _ := io.ReadAll(r.Body)
		receivedData = body
		w.WriteHeader(http.StatusOK)
	}))
	defer testSrv.Close()

	sink := NewHTTPSink(testSrv.URL, nil, 5*time.Second)

	testData := []byte(`{"test": "data"}`)
	_, err := sink.Write(testData)
	if err != nil {
		t.Fatalf("Write failed: %v", err)
	}

	if !bytes.Equal(receivedData, testData) {
		t.Errorf("Expected data %s, got %s", testData, receivedData)
	}

	if receivedContentType != "application/json" {
		t.Errorf("Expected Content-Type 'application/json', got %q", receivedContentType)
	}
}

func Test_HTTPSink_Write_Accepted(t *testing.T) {
	// Test that 202 Accepted is also considered success
	testSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusAccepted)
	}))
	defer testSrv.Close()

	sink := NewHTTPSink(testSrv.URL, nil, 5*time.Second)

	_, err := sink.Write([]byte(`{"test": "data"}`))
	if err != nil {
		t.Errorf("Write should succeed with 202 status, got error: %v", err)
	}
}

func Test_HTTPSink_Write_HTTPError(t *testing.T) {
	// Test HTTP error response
	testSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer testSrv.Close()

	sink := NewHTTPSink(testSrv.URL, nil, 5*time.Second)

	_, err := sink.Write([]byte(`{"test": "data"}`))
	if err == nil {
		t.Error("Write should fail with 500 status")
	}

	expectedError := "HTTP request failed with status 500"
	if !strings.Contains(err.Error(), expectedError) {
		t.Errorf("Expected error to contain %q, got: %v", expectedError, err)
	}
}

func Test_HTTPSink_Write_NetworkError(t *testing.T) {
	// Test network error (invalid URL)
	sink := NewHTTPSink("http://invalid-url-that-does-not-exist:9999", nil, 1*time.Second)

	_, err := sink.Write([]byte(`{"test": "data"}`))
	if err == nil {
		t.Error("Write should fail with network error")
	}

	if !strings.Contains(err.Error(), "error sending HTTP request") {
		t.Errorf("Expected network error message, got: %v", err)
	}
}

func Test_HTTPSink_WithTLS(t *testing.T) {
	// Create HTTPS test server
	testSrv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))
	defer testSrv.Close()

	// Use insecure TLS config for testing
	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
	}

	sink := NewHTTPSink(testSrv.URL, tlsConfig, 5*time.Second)

	_, err := sink.Write([]byte(`{"test": "data"}`))
	if err != nil {
		t.Errorf("Write with TLS should succeed, got error: %v", err)
	}
}

func Test_HTTPSink_Close(t *testing.T) {
	sink := NewHTTPSink("http://example.com", nil, 5*time.Second)
	err := sink.Close()
	if err != nil {
		t.Errorf("Close should not return error, got: %v", err)
	}
}

func Test_HTTPSink_String(t *testing.T) {
	endpoint := "https://webhook.example.com/cdc"
	sink := NewHTTPSink(endpoint, nil, 5*time.Second)
	if got := sink.String(); got != endpoint {
		t.Errorf("Expected %q, got %q", endpoint, got)
	}
}

func Test_NewSink_Stdout(t *testing.T) {
	cfg := SinkConfig{
		Endpoint: "stdout",
	}

	sink, err := NewSink(cfg)
	if err != nil {
		t.Fatalf("NewSink failed: %v", err)
	}

	if _, ok := sink.(*StdoutSink); !ok {
		t.Errorf("Expected StdoutSink, got %T", sink)
	}
}

func Test_NewSink_HTTP(t *testing.T) {
	cfg := SinkConfig{
		Endpoint:        "http://example.com",
		TransmitTimeout: 10 * time.Second,
	}

	sink, err := NewSink(cfg)
	if err != nil {
		t.Fatalf("NewSink failed: %v", err)
	}

	if _, ok := sink.(*HTTPSink); !ok {
		t.Errorf("Expected HTTPSink, got %T", sink)
	}
}

func Test_NewSink_HTTPS(t *testing.T) {
	cfg := SinkConfig{
		Endpoint:        "https://example.com",
		TransmitTimeout: 10 * time.Second,
	}

	sink, err := NewSink(cfg)
	if err != nil {
		t.Fatalf("NewSink failed: %v", err)
	}

	if _, ok := sink.(*HTTPSink); !ok {
		t.Errorf("Expected HTTPSink, got %T", sink)
	}
}

func Test_NewSink_UnsupportedScheme(t *testing.T) {
	cfg := SinkConfig{
		Endpoint: "ftp://example.com",
	}

	_, err := NewSink(cfg)
	if err == nil {
		t.Error("NewSink should fail with unsupported scheme")
	}

	expectedError := `cdc: unsupported scheme "ftp"`
	if err.Error() != expectedError {
		t.Errorf("Expected error %q, got %q", expectedError, err.Error())
	}
}

func Test_NewSink_InvalidURL(t *testing.T) {
	cfg := SinkConfig{
		Endpoint: "://invalid-url",
	}

	_, err := NewSink(cfg)
	if err == nil {
		t.Error("NewSink should fail with invalid URL")
	}

	if !strings.Contains(err.Error(), "failed to parse endpoint URL") {
		t.Errorf("Expected URL parse error, got: %v", err)
	}
}
