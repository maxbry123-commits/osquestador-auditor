export type SysDBSerializationFormat = string;

export interface workflow_status {
  workflow_uuid: string;
  status: string;
  name: string;
  class_name?: string;
  config_name?: string;
  authenticated_user: string;
  output: string;
  error: string;
  assumed_role: string;
  authenticated_roles: string; // Serialized list of roles.
  request: string; // Serialized event dispatch data (such as HTTPRequest)
  executor_id: string; // Set to "local" for local deployment, set to microVM ID for cloud deployment.
  application_version?: string;
  queue_name?: string;
  created_at: number;
  updated_at: number;
  application_id: string;
  recovery_attempts: number;
  workflow_timeout_ms: number | null;
  workflow_deadline_epoch_ms: number | null;
  inputs: string;
  started_at_epoch_ms?: number;
  deduplication_id?: string; // ID used to identify enqueued workflows for de-duplication.
  priority?: number; // Optional priority for the workflow.
  queue_partition_key?: string; // Partition key for partitioned queues.
  forked_from?: string;
  was_forked_from?: boolean;
  owner_xid?: string;
  parent_workflow_id?: string;
  serialization: SysDBSerializationFormat | null;
  delay_until_epoch_ms?: number | null;
  rate_limited?: boolean;
  completed_at?: number | null;
  attributes?: Record<string, unknown> | null; // Custom key-value attributes attached at creation, stored as JSONB.
  schedule_name?: string | null; // If enqueued by a named schedule, that schedule's name.
  debounce_deadline_epoch_ms?: number | null; // Absolute cap (epoch ms) beyond which bounces may not extend the delay.
  is_debounced?: boolean; // True if the deduplication ID is a debounce key cleared on the DELAYED->ENQUEUED transition.
  application_name?: string | null; // Owning application. NULL means unclaimed: any application may read and claim the row.
}

export interface notifications {
  destination_uuid: string;
  topic: string;
  message: string;
  consumed: boolean;
  serialization: SysDBSerializationFormat | null;
}

export interface workflow_events {
  workflow_uuid: string;
  key: string;
  value: string;
  serialization: SysDBSerializationFormat | null;
}

export interface operation_outputs {
  workflow_uuid: string;
  function_id: number;
  output: string;
  error: string;
  child_workflow_id: string;
  function_name?: string;
  started_at_epoch_ms?: number;
  completed_at_epoch_ms?: number;
  serialization: SysDBSerializationFormat | null; // Relevant only to getEvent / recv / etc.
  application_name?: string | null; // Denormalized from the parent so step observability filters without a join.
}

export interface event_dispatch_kv {
  // Key fields
  service_name: string;
  workflow_fn_name: string;
  key: string;

  // Payload fields
  value?: string;
  update_time?: number; // Timestamp of record (for upsert)
  update_seq?: bigint; // Sequence number of record (for upsert)
}

export interface streams {
  workflow_uuid: string;
  key: string;
  value: string;
  offset: number;
  function_id: number;
  serialization: SysDBSerializationFormat | null;
}

export interface workflow_events_history {
  workflow_uuid: string;
  function_id: number;
  key: string;
  value: string;
  serialization: SysDBSerializationFormat | null;
}

export interface workflow_schedules {
  schedule_id: string;
  schedule_name: string;
  workflow_name: string;
  workflow_class_name: string;
  schedule: string;
  status: string;
  context: string;
  last_fired_at: string | null;
  automatic_backfill: boolean;
  cron_timezone: string | null;
  queue_name: string | null;
  application_name?: string | null; // Owning application. NULL means unclaimed; schedule_name stays globally unique.
}

export interface application_versions {
  version_id: string;
  version_name: string;
  version_timestamp: number;
  created_at: number;
  application_name?: string | null; // Owning application. NULL means unclaimed.
}

export interface queues {
  queue_id: string;
  name: string;
  concurrency: number | null;
  worker_concurrency: number | null;
  rate_limit_max: number | null;
  rate_limit_period_sec: number | null;
  priority_enabled: boolean;
  partition_queue: boolean;
  // Any of these being set partitions the queue; each applies per partition.
  partition_concurrency: number | null;
  partition_worker_concurrency: number | null;
  partition_rate_limit_max: number | null;
  partition_rate_limit_period_sec: number | null;
  polling_interval_sec: number;
  created_at: number;
  updated_at: number;
  application_name?: string | null; // Owning application. NULL means unclaimed; name stays globally unique.
}

// This is the deserialized version of operation_outputs
export interface step_info {
  function_id: number;
  function_name: string;
  output: unknown;
  error: Error | null;
  child_workflow_id: string | null;
  started_at_epoch_ms?: number;
  completed_at_epoch_ms?: number;
}

// This is system DB schema for portable inputs / outputs / messages / events / errors

// ---------- Canonical JSON value space ----------
// Note the absensce of "Date", etc.
// Canonical Date = RFC 3339 / ISO-8601 UTC string: YYYY-MM-DDTHH:mm:ss(.sss)Z
// This can be fixed with AJV (applied later)
export type JsonPrimitive = null | boolean | number | string;
export type JsonValue = JsonPrimitive | JsonObject | JsonArray;
export type JsonObject = { [k: string]: JsonValue };
export type JsonArray = JsonValue[];

// ---------- Workflow args + result ----------
export type JsonWorkflowArgs = {
  positionalArgs?: JsonArray;
  namedArgs?: JsonObject;
};
export type JsonWorkflowResult = JsonValue;
export interface JsonWorkflowErrorData {
  name: string; // Error name
  message: string; // Human-readable ;-) string
  code?: number | string;
  data?: JsonValue; // structured details (retryable, origin, etc.)
}

export class PortableWorkflowError extends Error {
  constructor(
    message: string,
    readonly name: string,
    readonly code?: number | string,
    readonly data?: JsonValue,
  ) {
    super(message);
  }
}

// --------- Notification(Message) and WF event
export type JsonMessage = JsonValue;
export type JsonEvent = JsonValue;
