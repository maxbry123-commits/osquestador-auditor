import { DBOS, FunctionName } from '@dbos-inc/dbos-sdk';
import {
  type DataSourceTransactionHandler,
  isPGRetriableTransactionError,
  DBOSError,
  DBOSStepAlreadyRecordedError,
  replayRecordedStep,
  registerTransaction,
  runTransaction,
  DBOSDataSource,
  registerDataSource,
  createTransactionCompletionSchemaPG,
  createTransactionCompletionTablePG,
  CheckSchemaInstallationReturn,
  checkSchemaInstallationPG,
} from '@dbos-inc/dbos-sdk/datasource';
import { AsyncLocalStorage } from 'async_hooks';
import { SuperJSON } from 'superjson';

// Prisma reports a failed raw query's SQLSTATE in `meta` rather than on the error itself,
// and reports a write conflict raised by its own query API as P2034 with no SQLSTATE at all.
function unwrapPrismaError(error: unknown): unknown {
  const prismaError = (error as { code?: unknown; meta?: unknown } | null) ?? undefined;
  if (prismaError?.code === 'P2034') {
    return { code: '40001' };
  }
  const meta = prismaError?.meta;
  return meta && typeof meta === 'object' && 'code' in meta ? meta : error;
}

type PrismaLike = {
  $connect: () => Promise<void>;
  $disconnect: () => Promise<void>;
  $queryRawUnsafe<T = unknown>(query: unknown, ...values: unknown[]): Promise<T>;
  $executeRawUnsafe(query: unknown, ...values: unknown[]): Promise<number>;
};

type PrismaLikeTx = {
  $queryRawUnsafe<T = unknown>(query: TemplateStringsArray | string, ...values: unknown[]): Promise<T>;
  $executeRawUnsafe(query: TemplateStringsArray | string, ...values: unknown[]): Promise<number>;
  $transaction: (tf: (tx: PrismaLike) => Promise<unknown>, config?: unknown) => Promise<unknown>;
};

interface PrismaDataSourceContext {
  client: PrismaLike;
  owner: PrismaTransactionHandler;
}

type TransactionIsolationLevel = 'ReadUncommitted' | 'ReadCommitted' | 'RepeatableRead' | 'Serializable';

export type TransactionConfig = {
  isolationLevel?: TransactionIsolationLevel;
  readOnly?: boolean;
  name?: string;
};

const asyncLocalCtx = new AsyncLocalStorage<PrismaDataSourceContext>();

class PrismaTransactionHandler implements DataSourceTransactionHandler {
  readonly dsType = 'PrismaDataSource';
  readonly schemaName: string;

  constructor(
    readonly name: string,
    private readonly prismaAccess: PrismaLike | (() => PrismaLike),
    schemaName: string = 'dbos',
  ) {
    this.schemaName = schemaName;
  }

  get #prismaDB() {
    if (!this.prismaAccess) {
      throw new Error(`DataSource ${this.name} is not initialized.`);
    }
    if (typeof this.prismaAccess === 'function') {
      const p = this.prismaAccess();
      if (!p) {
        throw new Error(`DataSource ${this.name} is not initialized.`);
      }
      return p;
    }
    return this.prismaAccess;
  }

  async initialize(): Promise<void> {
    let installed = false;
    try {
      const res = await this.#prismaDB.$queryRawUnsafe<CheckSchemaInstallationReturn[]>(
        checkSchemaInstallationPG(this.schemaName),
      );
      installed = !!res[0]?.schema_exists && !!res[0]?.table_exists;
    } catch (e) {
      throw new Error(
        `In initialization of 'PrismaDataSource' ${this.name}: Database could not be queried: ${(e as Error).message}`,
      );
    }

    // Install
    if (!installed) {
      try {
        await this.#prismaDB.$executeRawUnsafe(createTransactionCompletionSchemaPG(this.schemaName));
        await this.#prismaDB.$executeRawUnsafe(createTransactionCompletionTablePG(this.schemaName));
      } catch (err) {
        throw new Error(
          `In initialization of 'PrismaDataSource' ${this.name}: The '${this.schemaName}.transaction_completion' table does not exist, and could not be created.  This should be added to your database migrations.
          See: https://docs.dbos.dev/typescript/tutorials/transaction-tutorial#installing-the-dbos-schema`,
        );
      }
    }
  }

  destroy(): Promise<void> {
    return Promise.resolve();
  }

  async #checkExecution(
    client: PrismaLike,
    workflowID: string,
    stepID: number,
  ): Promise<{ output: string | null } | { error: string } | undefined> {
    type Result = { output: string | null; error: string | null };
    const result = await client.$queryRawUnsafe<Result[]>(
      `SELECT output, error FROM "${this.schemaName}".transaction_completion
      WHERE workflow_id = $1 AND function_num = $2`,
      workflowID,
      stepID,
    );
    if (result?.[0] === undefined) {
      return undefined;
    }
    const { output, error } = result[0];
    return error !== null ? { error } : { output };
  }

  async #recordError(workflowID: string, stepID: number, error: string): Promise<void> {
    // $executeRawUnsafe reports affected rows, so DO NOTHING yields 0 when a duplicate won.
    const inserted = await this.#prismaDB.$executeRawUnsafe(
      `INSERT INTO "${this.schemaName}".transaction_completion (workflow_id, function_num, error)
       VALUES ($1, $2, $3)
       ON CONFLICT (workflow_id, function_num) DO NOTHING`,
      workflowID,
      stepID,
      error,
    );
    if (inserted === 0) {
      throw new DBOSStepAlreadyRecordedError(workflowID, stepID);
    }
  }

  // A duplicate execution won the race, so its recorded outcome is the durable one.
  async #replayConflictingStep<Return>(workflowID: string, stepID: number): Promise<Return> {
    const recorded = await this.#checkExecution(this.#prismaDB, workflowID, stepID);
    if (recorded === undefined) {
      throw new DBOSError(
        `Step ${stepID} of workflow ${workflowID} conflicted with a concurrent execution, but no recorded outcome was found`,
      );
    }
    return replayRecordedStep<Return>(recorded);
  }

  static async #recordOutput(
    client: PrismaLike,
    workflowID: string,
    stepID: number,
    output: string | null,
    schemaName: string,
  ): Promise<void> {
    const inserted = await client.$executeRawUnsafe(
      `INSERT INTO "${schemaName}".transaction_completion (workflow_id, function_num, output)
       VALUES ($1, $2, $3)
       ON CONFLICT (workflow_id, function_num) DO NOTHING`,
      workflowID,
      stepID,
      output,
    );
    if (inserted === 0) {
      throw new DBOSStepAlreadyRecordedError(workflowID, stepID);
    }
  }

  async invokeTransactionFunction<This, Args extends unknown[], Return>(
    config: TransactionConfig | undefined,
    target: This,
    func: (this: This, ...args: Args) => Promise<Return>,
    ...args: Args
  ): Promise<Return> {
    const workflowID = DBOS.workflowID;
    const stepID = DBOS.stepID;
    if (workflowID !== undefined && stepID === undefined) {
      throw new Error('DBOS.stepID is undefined inside a workflow.');
    }

    const readOnly = config?.readOnly ?? false;
    const saveResults = !readOnly && workflowID !== undefined;

    // Retry loop if appropriate
    let retryWaitMS = 1;
    const backoffFactor = 1.5;
    const maxRetryWaitMS = 2000; // Maximum wait 2 seconds.

    while (true) {
      // Check to see if this tx has already been executed
      const previousResult = saveResults ? await this.#checkExecution(this.#prismaDB, workflowID, stepID!) : undefined;
      if (previousResult) {
        return replayRecordedStep<Return>(previousResult);
      }

      try {
        const result = (await (this.#prismaDB as unknown as PrismaLikeTx).$transaction(
          async (client) => {
            // execute user's transaction function
            const result = await asyncLocalCtx.run({ client, owner: this }, async () => {
              return (await func.call(target, ...args)) as Return;
            });

            // save the output of read/write transactions
            if (saveResults) {
              await PrismaTransactionHandler.#recordOutput(
                client,
                workflowID,
                stepID!,
                SuperJSON.stringify(result),
                this.schemaName,
              );
            }

            return result;
          },
          { isolationLevel: config?.isolationLevel },
        )) as Return;

        return result;
      } catch (error) {
        if (saveResults && error instanceof DBOSStepAlreadyRecordedError) {
          return await this.#replayConflictingStep<Return>(workflowID, stepID!);
        }
        if (isPGRetriableTransactionError(unwrapPrismaError(error))) {
          DBOS.span?.addEvent('TXN SERIALIZATION FAILURE', { retryWaitMillis: retryWaitMS }, performance.now());
          await new Promise((resolve) => setTimeout(resolve, retryWaitMS));
          retryWaitMS = Math.min(retryWaitMS * backoffFactor, maxRetryWaitMS);
          continue;
        } else {
          if (saveResults) {
            const message = SuperJSON.stringify(error);
            try {
              await this.#recordError(workflowID, stepID!, message);
            } catch (recordError) {
              if (recordError instanceof DBOSStepAlreadyRecordedError) {
                return await this.#replayConflictingStep<Return>(workflowID, stepID!);
              }
              throw recordError;
            }
          }

          throw error;
        }
      }
    }
  }
}

export class PrismaDataSource<PrismaClient> implements DBOSDataSource<TransactionConfig> {
  static #getClient(p?: PrismaTransactionHandler) {
    if (!DBOS.isInTransaction()) {
      throw new Error('invalid use of PrismaDataSource.client outside of a DBOS transaction.');
    }
    const ctx = asyncLocalCtx.getStore();
    if (!ctx) {
      throw new Error('invalid use of PrismaDataSource.client outside of a DBOS transaction.');
    }
    if (p && p !== ctx.owner) throw new Error('Request of `PrismaDataSource.client` from the wrong object.');
    return ctx.client;
  }

  get client(): PrismaClient {
    return PrismaDataSource.#getClient(this.#provider) as PrismaClient;
  }

  static async initializeDBOSSchema(prisma: PrismaLike, schemaName: string = 'dbos') {
    await prisma.$queryRawUnsafe(createTransactionCompletionSchemaPG(schemaName));
    await prisma.$queryRawUnsafe(createTransactionCompletionTablePG(schemaName));
  }

  static async uninitializeDBOSSchema(prisma: PrismaLike, schemaName: string = 'dbos') {
    await prisma.$executeRawUnsafe(`DROP TABLE IF EXISTS "${schemaName}".transaction_completion;`);
    await prisma.$executeRawUnsafe(`DROP SCHEMA IF EXISTS "${schemaName}" CASCADE;`);
  }

  #provider: PrismaTransactionHandler;

  constructor(
    readonly name: string,
    prismaAccess: PrismaLike | (() => PrismaLike),
    schemaName: string = 'dbos',
  ) {
    this.#provider = new PrismaTransactionHandler(name, prismaAccess, schemaName);
    registerDataSource(this.#provider);
  }

  async runTransaction<T>(func: () => Promise<T>, config?: TransactionConfig) {
    return await runTransaction(func, config?.name ?? func.name, { dsName: this.name, config });
  }

  registerTransaction<This, Args extends unknown[], Return>(
    func: (this: This, ...args: Args) => Promise<Return>,
    config?: TransactionConfig & FunctionName,
  ): (this: This, ...args: Args) => Promise<Return> {
    return registerTransaction(this.name, func, config);
  }

  transaction(config?: TransactionConfig) {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const ds = this;
    return function decorator<This, Args extends unknown[], Return>(
      target: object,
      propertyKey: PropertyKey,
      descriptor: TypedPropertyDescriptor<(this: This, ...args: Args) => Promise<Return>>,
    ) {
      if (!descriptor.value) {
        throw Error('Use of decorator when original method is undefined');
      }

      descriptor.value = ds.registerTransaction(descriptor.value, {
        ...config,
        name: config?.name ?? String(propertyKey),
        ctorOrProto: target,
      });

      return descriptor;
    };
  }
}
