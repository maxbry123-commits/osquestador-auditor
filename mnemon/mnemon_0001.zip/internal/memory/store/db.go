package store

import (
	"database/sql"
	"fmt"
	"math"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"github.com/mnemon-dev/mnemon/internal/memory/embed"
	_ "modernc.org/sqlite"
)

// DefaultStoreName is the fallback store when none is specified.
const DefaultStoreName = "default"

const embeddingFloat32UserVersion = 1

var validStoreNameRe = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9_-]*$`)

// dbExecer abstracts sql.DB and sql.Tx so store methods work in both contexts.
type dbExecer interface {
	Exec(string, ...any) (sql.Result, error)
	Query(string, ...any) (*sql.Rows, error)
	QueryRow(string, ...any) *sql.Row
}

// DB wraps the SQLite database connection.
type DB struct {
	conn     *sql.DB
	tx       *sql.Tx // current active transaction (nil = no transaction)
	path     string
	readOnly bool
}

// IsReadOnly returns true if the database was opened in read-only mode.
func (db *DB) IsReadOnly() bool { return db.readOnly }

// execer returns the active transaction if set, otherwise the raw connection.
func (db *DB) execer() dbExecer {
	if db.tx != nil {
		return db.tx
	}
	return db.conn
}

// InTransaction runs fn inside a single SQL transaction.
// All store methods called within fn will use the transaction automatically.
func (db *DB) InTransaction(fn func() error) error {
	if db.tx != nil {
		return fmt.Errorf("nested transactions not supported")
	}
	tx, err := db.conn.Begin()
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	db.tx = tx
	defer func() { db.tx = nil }()
	if err := fn(); err != nil {
		tx.Rollback()
		return err
	}
	return tx.Commit()
}

// DefaultDataDir returns ~/.mnemon.
func DefaultDataDir() string {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		home = os.Getenv("HOME")
	}
	if home == "" {
		home = "/tmp"
	}
	return filepath.Join(home, ".mnemon")
}

// ValidStoreName returns true if name matches [a-zA-Z0-9][a-zA-Z0-9_-]*.
func ValidStoreName(name string) bool {
	return validStoreNameRe.MatchString(name)
}

// StoreDir returns <baseDir>/data/<name>.
func StoreDir(baseDir, name string) string {
	return filepath.Join(baseDir, "data", name)
}

// ActiveFile returns the path to <baseDir>/active.
func ActiveFile(baseDir string) string {
	return filepath.Join(baseDir, "active")
}

// ReadActive reads the active store name from <baseDir>/active.
// Returns DefaultStoreName if the file doesn't exist or is empty.
func ReadActive(baseDir string) string {
	data, err := os.ReadFile(ActiveFile(baseDir))
	if err != nil {
		return DefaultStoreName
	}
	name := strings.TrimSpace(string(data))
	if name == "" {
		return DefaultStoreName
	}
	if !ValidStoreName(name) {
		return DefaultStoreName
	}
	return name
}

// WriteActive writes the active store name to <baseDir>/active.
func WriteActive(baseDir, name string) error {
	if !ValidStoreName(name) {
		return fmt.Errorf("invalid store name %q", name)
	}
	if err := os.MkdirAll(baseDir, 0o755); err != nil {
		return err
	}
	return os.WriteFile(ActiveFile(baseDir), []byte(name+"\n"), 0o644)
}

// ListStores returns sorted names of all stores under <baseDir>/data/.
func ListStores(baseDir string) ([]string, error) {
	dataDir := filepath.Join(baseDir, "data")
	entries, err := os.ReadDir(dataDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var names []string
	for _, e := range entries {
		if e.IsDir() && ValidStoreName(e.Name()) {
			names = append(names, e.Name())
		}
	}
	sort.Strings(names)
	return names, nil
}

// StoreExists checks whether the named store directory exists.
func StoreExists(baseDir, name string) bool {
	if !ValidStoreName(name) {
		return false
	}
	fi, err := os.Stat(StoreDir(baseDir, name))
	return err == nil && fi.IsDir()
}

// MigrateIfNeeded moves a legacy ~/.mnemon/mnemon.db into the new
// data/default/ layout. It is safe to call multiple times.
func MigrateIfNeeded(baseDir string) error {
	oldDB := filepath.Join(baseDir, "mnemon.db")
	newDir := StoreDir(baseDir, DefaultStoreName)
	newDB := filepath.Join(newDir, "mnemon.db")

	// Also check for WAL/SHM files
	oldWAL := oldDB + "-wal"
	oldSHM := oldDB + "-shm"

	// Already migrated or fresh install
	if _, err := os.Stat(oldDB); os.IsNotExist(err) {
		return nil
	}
	// If new layout already exists, don't overwrite
	if _, err := os.Stat(newDB); err == nil {
		return nil
	}

	if err := os.MkdirAll(newDir, 0o755); err != nil {
		return fmt.Errorf("create default store dir: %w", err)
	}
	if err := os.Rename(oldDB, newDB); err != nil {
		return fmt.Errorf("migrate database: %w", err)
	}

	// Move WAL and SHM if they exist
	if err := renameIfExists(oldWAL, newDB+"-wal"); err != nil {
		return fmt.Errorf("migrate WAL: %w", err)
	}
	if err := renameIfExists(oldSHM, newDB+"-shm"); err != nil {
		return fmt.Errorf("migrate SHM: %w", err)
	}

	fmt.Fprintf(os.Stderr, "mnemon: migrated database to %s\n", newDB)
	return nil
}

func renameIfExists(oldPath, newPath string) error {
	if _, err := os.Stat(oldPath); err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	return os.Rename(oldPath, newPath)
}

// OpenReadOnly opens an immutable SQLite snapshot in read-only mode.
// Immutable mode avoids WAL/SHM sidecar files, making the handle safe for a
// database copied onto a read-only filesystem. Callers must not use this mode
// to observe a database that another process is actively changing.
func OpenReadOnly(dataDir string) (*DB, error) {
	dbPath := filepath.Join(dataDir, "mnemon.db")
	if _, err := os.Stat(dbPath); err != nil {
		return nil, fmt.Errorf("database not found: %s", dbPath)
	}

	// mode=ro is a SQLite URI parameter, not a generic filename query
	// parameter. Without the file: URI scheme modernc/sqlite treats this as a
	// normal read-write open and silently ignores the intended protection.
	dsn := &url.URL{Scheme: "file", Path: filepath.ToSlash(dbPath)}
	query := dsn.Query()
	query.Set("mode", "ro")
	query.Set("immutable", "1")
	query.Add("_pragma", "foreign_keys(1)")
	dsn.RawQuery = query.Encode()

	conn, err := sql.Open("sqlite", dsn.String())
	if err != nil {
		return nil, fmt.Errorf("open readonly database: %w", err)
	}
	conn.SetMaxOpenConns(1)
	return &DB{conn: conn, path: dbPath, readOnly: true}, nil
}

// Open opens (or creates) the SQLite database at the given directory.
func Open(dataDir string) (*DB, error) {
	if err := os.MkdirAll(dataDir, 0o755); err != nil {
		return nil, fmt.Errorf("create data dir: %w", err)
	}

	dbPath := filepath.Join(dataDir, "mnemon.db")
	conn, err := sql.Open("sqlite", dbPath+"?_pragma=journal_mode(WAL)&_pragma=foreign_keys(1)")
	if err != nil {
		return nil, fmt.Errorf("open database: %w", err)
	}

	conn.SetMaxOpenConns(1) // SQLite single-writer

	db := &DB{conn: conn, path: dbPath}
	if err := db.migrate(); err != nil {
		conn.Close()
		return nil, fmt.Errorf("migrate: %w", err)
	}
	return db, nil
}

// Close closes the database connection.
func (db *DB) Close() error {
	return db.conn.Close()
}

// Path returns the database file path.
func (db *DB) Path() string {
	return db.path
}

// Conn returns the underlying sql.DB for advanced queries.
func (db *DB) Conn() *sql.DB {
	return db.conn
}

func (db *DB) migrate() error {
	schema := `
CREATE TABLE IF NOT EXISTS insights (
    id          TEXT PRIMARY KEY,
    content     TEXT NOT NULL,
    category    TEXT DEFAULT 'general',
    importance  INTEGER DEFAULT 3,
    tags        TEXT DEFAULT '[]',
    entities    TEXT DEFAULT '[]',
    source      TEXT DEFAULT 'user',
    access_count INTEGER DEFAULT 0,
    stored_at   TEXT,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    deleted_at  TEXT
);

CREATE TABLE IF NOT EXISTS edges (
    source_id   TEXT NOT NULL,
    target_id   TEXT NOT NULL,
    edge_type   TEXT NOT NULL CHECK(edge_type IN ('temporal','semantic','causal','entity')),
    weight      REAL DEFAULT 1.0,
    metadata    TEXT DEFAULT '{}',
    created_at  TEXT NOT NULL,
    PRIMARY KEY (source_id, target_id, edge_type),
    FOREIGN KEY (source_id) REFERENCES insights(id) ON DELETE CASCADE,
    FOREIGN KEY (target_id) REFERENCES insights(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_insights_category ON insights(category);
CREATE INDEX IF NOT EXISTS idx_insights_importance ON insights(importance);
CREATE INDEX IF NOT EXISTS idx_insights_created ON insights(created_at);
CREATE INDEX IF NOT EXISTS idx_insights_deleted ON insights(deleted_at);
CREATE INDEX IF NOT EXISTS idx_insights_source ON insights(source);
CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(edge_type);
CREATE INDEX IF NOT EXISTS idx_edges_source_type ON edges(source_id, edge_type);
CREATE INDEX IF NOT EXISTS idx_edges_target_type ON edges(target_id, edge_type);

CREATE TABLE IF NOT EXISTS oplog (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    operation   TEXT NOT NULL,
    insight_id  TEXT,
    detail      TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_oplog_created ON oplog(created_at);
`
	_, err := db.conn.Exec(schema)
	if err != nil {
		return err
	}

	// Phase 2 migration: add last_accessed_at column
	if err := addColumnIfNotExists(db.conn, `ALTER TABLE insights ADD COLUMN last_accessed_at TEXT`); err != nil {
		return fmt.Errorf("add last_accessed_at: %w", err)
	}

	// Retention grace is based on when a row entered this store, not its
	// historical event time. Existing rows predate that distinction, so their
	// created_at is the least surprising backfill. The column stays nullable for
	// compatibility with external sync/import tools that write legacy rows.
	if err := addColumnIfNotExists(db.conn, `ALTER TABLE insights ADD COLUMN stored_at TEXT`); err != nil {
		return fmt.Errorf("add stored_at: %w", err)
	}
	if _, err := db.conn.Exec(`UPDATE insights SET stored_at = created_at WHERE stored_at IS NULL OR stored_at = ''`); err != nil {
		return fmt.Errorf("backfill stored_at: %w", err)
	}
	// Keep legacy/external writers safe when they omit the new column. SQLite
	// cannot add a column with a non-constant CURRENT_TIMESTAMP default during
	// migration, so a trigger supplies the physical insertion time instead.
	if _, err := db.conn.Exec(`
		CREATE TRIGGER IF NOT EXISTS set_insight_stored_at
		AFTER INSERT ON insights
		WHEN NEW.stored_at IS NULL OR NEW.stored_at = ''
		BEGIN
			UPDATE insights
			SET stored_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
			WHERE id = NEW.id;
		END`); err != nil {
		return fmt.Errorf("create stored_at trigger: %w", err)
	}
	if _, err := db.conn.Exec(`CREATE INDEX IF NOT EXISTS idx_insights_stored ON insights(stored_at)`); err != nil {
		return fmt.Errorf("create stored_at index: %w", err)
	}

	// Phase 3 migration: add embedding column
	if err := addColumnIfNotExists(db.conn, `ALTER TABLE insights ADD COLUMN embedding BLOB`); err != nil {
		return fmt.Errorf("add embedding: %w", err)
	}
	if err := db.migrateEmbeddingsToFloat32(); err != nil {
		return fmt.Errorf("migrate embeddings to float32: %w", err)
	}

	// Lifecycle migration: add effective_importance column
	if err := addColumnIfNotExists(db.conn, `ALTER TABLE insights ADD COLUMN effective_importance REAL DEFAULT 0.5`); err != nil {
		return fmt.Errorf("add effective_importance: %w", err)
	}
	if _, err := db.conn.Exec(`CREATE INDEX IF NOT EXISTS idx_insights_effective_imp ON insights(effective_importance)`); err != nil {
		return fmt.Errorf("create effective_imp index: %w", err)
	}
	if _, err := db.conn.Exec(`CREATE INDEX IF NOT EXISTS idx_prune_candidates ON insights(deleted_at, importance, access_count, effective_importance)`); err != nil {
		return fmt.Errorf("create prune_candidates index: %w", err)
	}
	if _, err := db.conn.Exec(`CREATE INDEX IF NOT EXISTS idx_prune_age_candidates ON insights(deleted_at, importance, access_count, stored_at, effective_importance)`); err != nil {
		return fmt.Errorf("create prune_age_candidates index: %w", err)
	}

	// Migration: remove narrative edge type from existing databases
	if err := db.migrateRemoveNarrativeEdges(); err != nil {
		return fmt.Errorf("remove narrative edges: %w", err)
	}

	// One-time cleanup: soft-delete narrative category insights from legacy databases.
	// Only runs the UPDATE when narrative insights actually exist (avoids needless writes).
	var narrativeCount int
	_ = db.conn.QueryRow(`SELECT COUNT(*) FROM insights WHERE category = 'narrative' AND deleted_at IS NULL`).Scan(&narrativeCount)
	if narrativeCount > 0 {
		if _, err := db.conn.Exec(`UPDATE insights SET deleted_at = datetime('now') WHERE category = 'narrative' AND deleted_at IS NULL`); err != nil {
			return fmt.Errorf("clean narrative insights: %w", err)
		}
	}

	return nil
}

// addColumnIfNotExists runs an ALTER TABLE ADD COLUMN statement,
// ignoring "duplicate column" errors (column already exists).
func addColumnIfNotExists(conn *sql.DB, stmt string) error {
	_, err := conn.Exec(stmt)
	if err != nil && strings.Contains(err.Error(), "duplicate column") {
		return nil
	}
	return err
}

func (db *DB) migrateEmbeddingsToFloat32() error {
	var userVersion int
	if err := db.conn.QueryRow(`PRAGMA user_version`).Scan(&userVersion); err != nil {
		return err
	}
	if userVersion >= embeddingFloat32UserVersion {
		return nil
	}

	tx, err := db.conn.Begin()
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback()

	rows, err := tx.Query(`SELECT id, embedding FROM insights WHERE embedding IS NOT NULL`)
	if err != nil {
		return fmt.Errorf("select embeddings: %w", err)
	}
	type migratedEmbedding struct {
		id   string
		blob []byte
	}
	var migrated []migratedEmbedding
	for rows.Next() {
		var id string
		var blob []byte
		if err := rows.Scan(&id, &blob); err != nil {
			rows.Close()
			return fmt.Errorf("scan embedding: %w", err)
		}
		vec := embed.DeserializeLegacyVector(blob)
		if vec == nil || !looksLikeLegacyVector(vec) {
			// Not a parseable legacy float64 blob (empty, malformed, or
			// already in float32 form) — leave it untouched. Aborting the
			// whole migration over one bad row would permanently block the
			// database from opening, and re-encoding non-legacy data here
			// would silently corrupt it.
			fmt.Fprintf(os.Stderr, "mnemon: skipping float32 migration for insight %s: embedding is not a legacy float64 vector (%d bytes)\n", id, len(blob))
			continue
		}
		migrated = append(migrated, migratedEmbedding{id: id, blob: embed.SerializeVector(vec)})
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return fmt.Errorf("scan embeddings: %w", err)
	}
	rows.Close()

	for _, item := range migrated {
		if _, err := tx.Exec(`UPDATE insights SET embedding = ? WHERE id = ?`, item.blob, item.id); err != nil {
			return fmt.Errorf("update embedding %s: %w", item.id, err)
		}
	}
	if _, err := tx.Exec(fmt.Sprintf(`PRAGMA user_version = %d`, embeddingFloat32UserVersion)); err != nil {
		return fmt.Errorf("set user_version: %w", err)
	}

	return tx.Commit()
}

// looksLikeLegacyVector reports whether v's values are plausible for an
// embedding (finite and of reasonable magnitude). It guards against
// misreading an already-migrated float32 blob as legacy float64: reinterpreting
// arbitrary float32 bit patterns as float64 yields NaN, Inf, or extreme
// magnitudes with overwhelming probability, so a vector that looks "normal"
// is almost certainly genuine legacy data.
func looksLikeLegacyVector(v []float64) bool {
	for _, f := range v {
		if math.IsNaN(f) || math.IsInf(f, 0) || math.Abs(f) > 1e6 {
			return false
		}
	}
	return true
}

// migrateRemoveNarrativeEdges recreates the edges table without the 'narrative' type
// if the old CHECK constraint still allows it.
func (db *DB) migrateRemoveNarrativeEdges() error {
	// Foreign key enforcement is disabled for both the probe and the rebuild.
	//
	// The probe needs it because it inserts a sentinel edge whose endpoints do
	// not exist. The driver opens the database with foreign_keys(1), so the
	// insert fails on the foreign key long before the CHECK constraint is
	// consulted -- and the error was being read as "the schema already rejects
	// 'narrative'". The migration therefore never ran on any database opened
	// through the driver, and legacy stores still carry the old constraint.
	//
	// The rebuild needs it because copying every row into a fresh table is
	// rejected by any pre-existing dangling edge, and real stores accumulate
	// them: a `.recover` after corruption, or any write made while
	// enforcement was off, leaves edges pointing at rows that are gone. One
	// such row would abort the migration on every open. Orphans are copied
	// verbatim rather than filtered out -- dropping them would be a silent
	// data deletion justified only by the convenience of this migration.
	//
	// PRAGMA foreign_keys is a no-op inside a transaction, so it is toggled
	// around one. The pool is capped at a single connection, so it applies to
	// the connection performing the work.
	if _, err := db.conn.Exec(`PRAGMA foreign_keys=OFF`); err != nil {
		return fmt.Errorf("disable foreign keys for edge rebuild: %w", err)
	}
	defer func() { _, _ = db.conn.Exec(`PRAGMA foreign_keys=ON`) }()

	// The probe is rolled back, always. Written in autocommit -- which is what
	// it was, and what disabling enforcement above now lets succeed -- the
	// sentinel row outlives a rebuild that fails or a process that dies
	// mid-migration. The next open's probe then collides with the leftover on
	// the primary key, and this function reads any error as "the schema
	// already rejects 'narrative'", so the migration is skipped from then on
	// and the database is stranded on the old schema permanently: the same
	// failure being repaired here, arriving through a different door.
	//
	// The id is random rather than a fixed '__test' because insight ids are
	// caller-supplied. A fixed sentinel can collide with a real row, and a
	// cleanup keyed on it can take real edges with it.
	probeTx, err := db.conn.Begin()
	if err != nil {
		return fmt.Errorf("begin probe: %w", err)
	}
	_, testErr := probeTx.Exec(
		`INSERT INTO edges VALUES ('__probe_'||hex(randomblob(8)),'__probe_'||hex(randomblob(8)),'narrative',0,'{}',datetime('now'))`)
	if err := probeTx.Rollback(); err != nil {
		return fmt.Errorf("roll back probe: %w", err)
	}
	if testErr != nil {
		return nil // current schema already rejects 'narrative', nothing to do
	}

	// Old schema — migrate within a transaction
	tx, err := db.conn.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	steps := []string{
		// A sentinel left behind by the older autocommit probe is a
		// 'narrative' row, so the next step removes it along with the rest.
		`DELETE FROM edges WHERE edge_type = 'narrative'`,
		`ALTER TABLE edges RENAME TO edges_old`,
		`CREATE TABLE edges (
			source_id   TEXT NOT NULL,
			target_id   TEXT NOT NULL,
			edge_type   TEXT NOT NULL CHECK(edge_type IN ('temporal','semantic','causal','entity')),
			weight      REAL DEFAULT 1.0,
			metadata    TEXT DEFAULT '{}',
			created_at  TEXT NOT NULL,
			PRIMARY KEY (source_id, target_id, edge_type),
			FOREIGN KEY (source_id) REFERENCES insights(id) ON DELETE CASCADE,
			FOREIGN KEY (target_id) REFERENCES insights(id) ON DELETE CASCADE
		)`,
		`INSERT INTO edges SELECT * FROM edges_old`,
		`DROP TABLE edges_old`,
		`CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id)`,
		`CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id)`,
		`CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(edge_type)`,
	}
	for _, s := range steps {
		if _, err := tx.Exec(s); err != nil {
			return fmt.Errorf("step %q: %w", s[:min(len(s), 40)], err)
		}
	}
	return tx.Commit()
}
