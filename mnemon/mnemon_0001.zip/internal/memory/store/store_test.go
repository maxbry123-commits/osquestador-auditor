package store

import (
	"bytes"
	"database/sql"
	"encoding/binary"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/mnemon-dev/mnemon/internal/memory/embed"
	"github.com/mnemon-dev/mnemon/internal/memory/model"
)

// testDB creates a fresh SQLite database in a temp directory, auto-closed on test cleanup.
func testDB(t *testing.T) *DB {
	t.Helper()
	db, err := Open(t.TempDir())
	if err != nil {
		t.Fatalf("open test DB: %v", err)
	}
	t.Cleanup(func() { db.Close() })
	return db
}

func makeInsight(id, content string, importance int) *model.Insight {
	now := time.Now().UTC()
	return &model.Insight{
		ID:         id,
		Content:    content,
		Category:   model.CategoryFact,
		Importance: importance,
		Tags:       []string{},
		Entities:   []string{},
		Source:     "test",
		CreatedAt:  now,
		UpdatedAt:  now,
	}
}

// --- Insight CRUD ---

func TestInsertAndGetInsight(t *testing.T) {
	db := testDB(t)
	ins := makeInsight("ins-1", "Go uses SQLite for storage", 3)
	ins.Tags = []string{"go", "sqlite"}
	ins.Entities = []string{"Go", "SQLite"}

	if err := db.InsertInsight(ins); err != nil {
		t.Fatalf("insert: %v", err)
	}

	got, err := db.GetInsightByID("ins-1")
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if got.Content != ins.Content {
		t.Errorf("content: want %q, got %q", ins.Content, got.Content)
	}
	if got.Importance != 3 {
		t.Errorf("importance: want 3, got %d", got.Importance)
	}
	if len(got.Tags) != 2 || got.Tags[0] != "go" {
		t.Errorf("tags: want [go sqlite], got %v", got.Tags)
	}
	if len(got.Entities) != 2 || got.Entities[0] != "Go" {
		t.Errorf("entities: want [Go SQLite], got %v", got.Entities)
	}
}

func TestOpenReadOnlyRejectsWrites(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "store with spaces")
	db, err := Open(dir)
	if err != nil {
		t.Fatalf("open writable DB: %v", err)
	}
	if err := db.InsertInsight(makeInsight("seed", "existing", 3)); err != nil {
		t.Fatalf("insert seed: %v", err)
	}
	if err := db.Close(); err != nil {
		t.Fatalf("close writable DB: %v", err)
	}

	ro, err := OpenReadOnly(dir)
	if err != nil {
		t.Fatalf("open read-only DB: %v", err)
	}
	if !ro.IsReadOnly() {
		t.Fatal("read-only handle must report IsReadOnly")
	}
	stats, err := ro.GetStats()
	if err != nil {
		t.Fatalf("query through read-only handle: %v", err)
	}
	if stats.Total != 1 {
		t.Fatalf("read-only total insights = %d, want 1", stats.Total)
	}
	if err := ro.InsertInsight(makeInsight("forbidden", "must not persist", 3)); err == nil {
		t.Fatal("read-only handle accepted an insert")
	}
	if err := ro.Close(); err != nil {
		t.Fatalf("close read-only DB: %v", err)
	}

	reopened, err := Open(dir)
	if err != nil {
		t.Fatalf("reopen writable DB: %v", err)
	}
	defer reopened.Close()
	stats, err = reopened.GetStats()
	if err != nil {
		t.Fatalf("stats after rejected write: %v", err)
	}
	if stats.Total != 1 {
		t.Fatalf("total insights after rejected write = %d, want 1", stats.Total)
	}
}

func TestOpenReadOnlyDoesNotCreateSidecars(t *testing.T) {
	sourceDir := t.TempDir()
	db, err := Open(sourceDir)
	if err != nil {
		t.Fatalf("open source DB: %v", err)
	}
	if err := db.InsertInsight(makeInsight("seed", "snapshot content", 3)); err != nil {
		t.Fatalf("insert source insight: %v", err)
	}
	if err := db.Close(); err != nil {
		t.Fatalf("close source DB: %v", err)
	}

	snapshotDir := filepath.Join(t.TempDir(), "read only snapshot")
	if err := os.MkdirAll(snapshotDir, 0o755); err != nil {
		t.Fatalf("create snapshot dir: %v", err)
	}
	database, err := os.ReadFile(filepath.Join(sourceDir, "mnemon.db"))
	if err != nil {
		t.Fatalf("read source DB: %v", err)
	}
	if err := os.WriteFile(filepath.Join(snapshotDir, "mnemon.db"), database, 0o444); err != nil {
		t.Fatalf("write snapshot DB: %v", err)
	}

	ro, err := OpenReadOnly(snapshotDir)
	if err != nil {
		t.Fatalf("open snapshot read-only: %v", err)
	}
	stats, err := ro.GetStats()
	if err != nil {
		t.Fatalf("query snapshot: %v", err)
	}
	if stats.Total != 1 {
		t.Fatalf("snapshot total insights = %d, want 1", stats.Total)
	}
	if err := ro.Close(); err != nil {
		t.Fatalf("close snapshot: %v", err)
	}

	for _, suffix := range []string{"-wal", "-shm", "-journal"} {
		path := filepath.Join(snapshotDir, "mnemon.db"+suffix)
		if _, err := os.Stat(path); !os.IsNotExist(err) {
			t.Fatalf("read-only snapshot created sidecar %s (stat error %v)", path, err)
		}
	}
}

func TestGetInsightByID_NotFound(t *testing.T) {
	db := testDB(t)
	_, err := db.GetInsightByID("nonexistent")
	if err == nil {
		t.Error("want error for nonexistent ID, got nil")
	}
}

func TestSoftDeleteInsight(t *testing.T) {
	db := testDB(t)
	ins := makeInsight("del-1", "to be deleted", 2)
	db.InsertInsight(ins)

	// Add an edge to verify it gets cleaned up
	db.InsertEdge(&model.Edge{
		SourceID: "del-1", TargetID: "del-1",
		EdgeType: model.EdgeTemporal, Weight: 1.0,
		Metadata: map[string]string{}, CreatedAt: time.Now().UTC(),
	})

	if err := db.SoftDeleteInsight("del-1"); err != nil {
		t.Fatalf("soft delete: %v", err)
	}

	// Should not be found via GetInsightByID (excludes deleted)
	_, err := db.GetInsightByID("del-1")
	if err == nil {
		t.Error("deleted insight should not be found via GetInsightByID")
	}

	// But should be found via GetInsightByIDIncludeDeleted
	got, err := db.GetInsightByIDIncludeDeleted("del-1")
	if err != nil {
		t.Fatalf("get include deleted: %v", err)
	}
	if got.DeletedAt == nil {
		t.Error("deleted_at should be set")
	}

	// Edges should be deleted
	edges, _ := db.GetEdgesByNode("del-1")
	if len(edges) != 0 {
		t.Errorf("edges should be deleted, got %d", len(edges))
	}
}

func TestSoftDeleteInsight_AlreadyDeleted(t *testing.T) {
	db := testDB(t)
	ins := makeInsight("del-2", "already deleted", 2)
	db.InsertInsight(ins)
	db.SoftDeleteInsight("del-2")

	err := db.SoftDeleteInsight("del-2")
	if err == nil {
		t.Error("double delete should return error")
	}
}

// --- Store names ---

func TestReadActiveRejectsInvalidStoreName(t *testing.T) {
	baseDir := t.TempDir()
	if err := os.WriteFile(ActiveFile(baseDir), []byte("../outside\n"), 0o644); err != nil {
		t.Fatalf("write active file: %v", err)
	}

	if got := ReadActive(baseDir); got != DefaultStoreName {
		t.Fatalf("invalid active store should fall back to %q, got %q", DefaultStoreName, got)
	}
}

func TestWriteActiveRejectsInvalidStoreName(t *testing.T) {
	if err := WriteActive(t.TempDir(), "../outside"); err == nil {
		t.Fatal("expected invalid store name error")
	}
}

func TestListStoresFiltersInvalidDirectoryNames(t *testing.T) {
	baseDir := t.TempDir()
	for _, name := range []string{"default", "work_1", ".hidden"} {
		dir := filepath.Join(baseDir, "data", name)
		if err := os.MkdirAll(dir, 0o755); err != nil {
			t.Fatalf("create store dir %q: %v", name, err)
		}
	}

	names, err := ListStores(baseDir)
	if err != nil {
		t.Fatalf("list stores: %v", err)
	}
	want := []string{"default", "work_1"}
	if len(names) != len(want) {
		t.Fatalf("store count mismatch: want %v, got %v", want, names)
	}
	for i := range want {
		if names[i] != want[i] {
			t.Fatalf("store names mismatch: want %v, got %v", want, names)
		}
	}
}

func TestStoreExistsRejectsInvalidStoreName(t *testing.T) {
	baseDir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(baseDir, "outside"), 0o755); err != nil {
		t.Fatalf("create outside dir: %v", err)
	}

	if StoreExists(baseDir, "../outside") {
		t.Fatal("invalid store name must not resolve outside data directory")
	}
}

// --- Query ---

func TestQueryInsights_Filters(t *testing.T) {
	db := testDB(t)
	ins1 := makeInsight("q-1", "Go language features", 5)
	ins1.Category = model.CategoryFact
	ins2 := makeInsight("q-2", "Python web framework", 2)
	ins2.Category = model.CategoryDecision
	ins3 := makeInsight("q-3", "Go concurrency patterns", 4)
	ins3.Category = model.CategoryFact
	db.InsertInsight(ins1)
	db.InsertInsight(ins2)
	db.InsertInsight(ins3)

	// Keyword filter
	results, err := db.QueryInsights(QueryFilter{Keyword: "Go"})
	if err != nil {
		t.Fatalf("query keyword: %v", err)
	}
	if len(results) != 2 {
		t.Errorf("keyword 'Go': want 2 results, got %d", len(results))
	}

	// Category filter
	results, err = db.QueryInsights(QueryFilter{Category: "decision"})
	if err != nil {
		t.Fatalf("query category: %v", err)
	}
	if len(results) != 1 || results[0].ID != "q-2" {
		t.Errorf("category decision: want [q-2], got %v", results)
	}

	// MinImportance filter
	results, err = db.QueryInsights(QueryFilter{MinImportance: 4})
	if err != nil {
		t.Fatalf("query importance: %v", err)
	}
	if len(results) != 2 {
		t.Errorf("importance>=4: want 2 results, got %d", len(results))
	}
}

// --- Edges ---

func TestInsertAndGetEdges(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("e-1", "source", 3))
	db.InsertInsight(makeInsight("e-2", "target", 3))

	edge := &model.Edge{
		SourceID: "e-1", TargetID: "e-2",
		EdgeType: model.EdgeSemantic, Weight: 0.85,
		Metadata:  map[string]string{"cosine": "0.8500"},
		CreatedAt: time.Now().UTC(),
	}
	if err := db.InsertEdge(edge); err != nil {
		t.Fatalf("insert edge: %v", err)
	}

	// GetEdgesByNode
	edges, err := db.GetEdgesByNode("e-1")
	if err != nil {
		t.Fatalf("get edges by node: %v", err)
	}
	if len(edges) != 1 {
		t.Fatalf("want 1 edge, got %d", len(edges))
	}
	if edges[0].EdgeType != model.EdgeSemantic {
		t.Errorf("edge type: want semantic, got %s", edges[0].EdgeType)
	}
	if edges[0].Metadata["cosine"] != "0.8500" {
		t.Errorf("metadata cosine: want 0.8500, got %s", edges[0].Metadata["cosine"])
	}

	// Also visible from target side
	edges, err = db.GetEdgesByNode("e-2")
	if err != nil {
		t.Fatalf("get edges by target: %v", err)
	}
	if len(edges) != 1 {
		t.Error("edge should be visible from target node too")
	}
}

func TestGetEdgesBySourceAndType(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("st-1", "a", 3))
	db.InsertInsight(makeInsight("st-2", "b", 3))
	db.InsertInsight(makeInsight("st-3", "c", 3))

	db.InsertEdge(&model.Edge{
		SourceID: "st-1", TargetID: "st-2",
		EdgeType: model.EdgeTemporal, Weight: 1.0,
		Metadata: map[string]string{}, CreatedAt: time.Now().UTC(),
	})
	db.InsertEdge(&model.Edge{
		SourceID: "st-1", TargetID: "st-3",
		EdgeType: model.EdgeSemantic, Weight: 0.9,
		Metadata: map[string]string{}, CreatedAt: time.Now().UTC(),
	})

	edges, err := db.GetEdgesBySourceAndType("st-1", model.EdgeTemporal)
	if err != nil {
		t.Fatalf("get by source and type: %v", err)
	}
	if len(edges) != 1 || edges[0].TargetID != "st-2" {
		t.Errorf("want 1 temporal edge to st-2, got %v", edges)
	}
}

func TestFindInsightsWithEntity(t *testing.T) {
	db := testDB(t)
	ins1 := makeInsight("fe-1", "uses Go", 3)
	ins1.Entities = []string{"Go", "SQLite"}
	ins2 := makeInsight("fe-2", "uses Python", 3)
	ins2.Entities = []string{"Python"}
	ins3 := makeInsight("fe-3", "also uses Go", 3)
	ins3.Entities = []string{"Go"}
	db.InsertInsight(ins1)
	db.InsertInsight(ins2)
	db.InsertInsight(ins3)

	ids, err := db.FindInsightsWithEntity("Go", "fe-3", 10)
	if err != nil {
		t.Fatalf("find: %v", err)
	}
	if len(ids) != 1 || ids[0] != "fe-1" {
		t.Errorf("want [fe-1], got %v", ids)
	}
}

// --- Transactions ---

func TestInTransaction_Commit(t *testing.T) {
	db := testDB(t)
	err := db.InTransaction(func() error {
		db.InsertInsight(makeInsight("tx-1", "in transaction", 3))
		return nil
	})
	if err != nil {
		t.Fatalf("transaction: %v", err)
	}
	got, err := db.GetInsightByID("tx-1")
	if err != nil || got == nil {
		t.Error("committed insight should be readable")
	}
}

func TestInTransaction_Rollback(t *testing.T) {
	db := testDB(t)
	err := db.InTransaction(func() error {
		db.InsertInsight(makeInsight("tx-2", "will be rolled back", 3))
		return errRollback
	})
	if err == nil {
		t.Error("transaction should return error on rollback")
	}
	_, err = db.GetInsightByID("tx-2")
	if err == nil {
		t.Error("rolled back insight should not be readable")
	}
}

var errRollback = &rollbackError{}

type rollbackError struct{}

func (e *rollbackError) Error() string { return "rollback" }

func TestInTransaction_Nested(t *testing.T) {
	db := testDB(t)
	err := db.InTransaction(func() error {
		return db.InTransaction(func() error { return nil })
	})
	if err == nil {
		t.Error("nested transactions should return error")
	}
}

// --- Lifecycle ---

func TestComputeEffectiveImportance_NewInsight(t *testing.T) {
	// Brand new: importance=3, 0 accesses, 0 days, 0 edges
	ei := ComputeEffectiveImportance(3, 0, 0, 0)
	// base=0.5, accessFactor=max(1.0, log(1))=1.0, decay=1.0, edge=1.0
	want := 0.5
	if math.Abs(ei-want) > 0.01 {
		t.Errorf("new insight: want ~%f, got %f", want, ei)
	}
}

func TestComputeEffectiveImportance_MaxImportance(t *testing.T) {
	ei := ComputeEffectiveImportance(5, 0, 0, 0)
	// base=1.0
	if ei != 1.0 {
		t.Errorf("max importance new: want 1.0, got %f", ei)
	}
}

func TestComputeEffectiveImportance_Decay(t *testing.T) {
	// After 30 days (1 half-life), should be ~half
	fresh := ComputeEffectiveImportance(3, 0, 0, 0)
	decayed := ComputeEffectiveImportance(3, 0, 30, 0)
	ratio := decayed / fresh
	if math.Abs(ratio-0.5) > 0.01 {
		t.Errorf("30-day decay ratio: want ~0.5, got %f", ratio)
	}
}

func TestComputeEffectiveImportance_HighAccess(t *testing.T) {
	low := ComputeEffectiveImportance(3, 0, 0, 0)
	high := ComputeEffectiveImportance(3, 10, 0, 0)
	if high <= low {
		t.Errorf("high access should increase EI: low=%f, high=%f", low, high)
	}
}

func TestComputeEffectiveImportance_EdgeBonus(t *testing.T) {
	noEdge := ComputeEffectiveImportance(3, 0, 0, 0)
	withEdge := ComputeEffectiveImportance(3, 0, 0, 5)
	if withEdge <= noEdge {
		t.Errorf("edges should increase EI: no=%f, with=%f", noEdge, withEdge)
	}
}

func TestComputeEffectiveImportance_EdgeCapped(t *testing.T) {
	e5 := ComputeEffectiveImportance(3, 0, 0, 5)
	e10 := ComputeEffectiveImportance(3, 0, 0, 10)
	// Edge count capped at 5, so e5 == e10
	if e5 != e10 {
		t.Errorf("edge cap at 5: e5=%f, e10=%f (should be equal)", e5, e10)
	}
}

func TestIsImmune(t *testing.T) {
	if !IsImmune(4, 0) {
		t.Error("importance>=4 should be immune")
	}
	if !IsImmune(5, 0) {
		t.Error("importance=5 should be immune")
	}
	if !IsImmune(1, 3) {
		t.Error("accessCount>=3 should be immune")
	}
	if IsImmune(3, 2) {
		t.Error("importance=3, access=2 should NOT be immune")
	}
	if IsImmune(1, 0) {
		t.Error("importance=1, access=0 should NOT be immune")
	}
}

func TestBaseWeight(t *testing.T) {
	tests := []struct {
		importance int
		want       float64
	}{
		{5, 1.0},
		{4, 0.8},
		{3, 0.5},
		{2, 0.3},
		{1, 0.15},
	}
	for _, tt := range tests {
		got := baseWeight(tt.importance)
		if got != tt.want {
			t.Errorf("baseWeight(%d): want %f, got %f", tt.importance, tt.want, got)
		}
	}
}

// --- edge table rebuild ---

// allowNarrativeEdges restores the historical edges schema, which still admits
// the 'narrative' edge type, by rewriting the stored CHECK constraint in place.
func allowNarrativeEdges(t *testing.T, db *DB) {
	t.Helper()
	for _, s := range []string{
		`PRAGMA writable_schema=ON`,
		`UPDATE sqlite_master SET sql = replace(sql, "'entity'", "'entity','narrative'") WHERE name = 'edges'`,
		`PRAGMA writable_schema=OFF`,
	} {
		if _, err := db.conn.Exec(s); err != nil {
			t.Fatalf("%s: %v", s, err)
		}
	}
}

// Removing the 'narrative' edge type rebuilds the edges table, copying every
// row into a fresh one. The driver enables foreign key enforcement, so a
// single pre-existing dangling edge aborts that copy -- and because the
// migration runs on every open, the database can never get past it.
//
// Orphans are not exotic. A `.recover` rebuild after corruption, or any write
// made while enforcement was off, produces them; one live store was found
// holding 51. They must survive the rebuild verbatim rather than being
// silently dropped.
func TestMigrateRemoveNarrativeEdges_ToleratesOrphanedEdges(t *testing.T) {
	dir := t.TempDir()

	db, err := Open(dir)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	if err := db.InsertInsight(makeInsight("narr-src", "content", 3)); err != nil {
		t.Fatalf("insert insight: %v", err)
	}

	// Restore the historical schema that still admits 'narrative', and plant
	// an orphan the way real damage arrives: with enforcement off.
	if _, err := db.conn.Exec(`PRAGMA foreign_keys=OFF`); err != nil {
		t.Fatalf("disable fk: %v", err)
	}
	allowNarrativeEdges(t, db)
	if _, err := db.conn.Exec(
		`INSERT INTO edges VALUES ('narr-src','vanished','semantic',0.5,'{}','2026-01-01T00:00:00Z')`); err != nil {
		t.Fatalf("insert orphaned edge: %v", err)
	}
	db.Close()

	// Reopening runs migrate(); the rebuild must not be blocked by the orphan.
	reopened, err := Open(dir)
	if err != nil {
		t.Fatalf("migration must survive an orphaned edge, got: %v", err)
	}
	defer reopened.Close()

	var orphans int
	if err := reopened.conn.QueryRow(
		`SELECT COUNT(*) FROM edges WHERE target_id = 'vanished'`).Scan(&orphans); err != nil {
		t.Fatalf("count orphan: %v", err)
	}
	if orphans != 1 {
		t.Errorf("orphaned edge must survive the rebuild verbatim, got %d", orphans)
	}

	// And the migration actually did its job.
	if _, err := reopened.conn.Exec(
		`INSERT INTO edges VALUES ('narr-src','narr-src','narrative',1,'{}','2026-01-01T00:00:00Z')`); err == nil {
		t.Error("narrative edge type must be rejected after migration")
	}
}

// The probe writes a sentinel edge to learn whether the CHECK still admits
// 'narrative'. Written outside a transaction it outlives a rebuild that fails
// or a process that dies mid-migration, and the next probe then collides with
// the leftover on the primary key. This function reads any error as "the
// schema already rejects narrative", so the rebuild is skipped from then on
// and the database is stranded on the old schema permanently.
func TestMigrateRemoveNarrativeEdges_ProbeSurvivesNothing(t *testing.T) {
	dir := t.TempDir()

	// A second handle, kept open, is the only way to inspect and repair the
	// file between two failed opens: Open closes its connection when migrate
	// fails and hands back nothing to inspect with.
	side, err := Open(dir)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer side.Close()
	if err := side.InsertInsight(makeInsight("probe-src", "content", 3)); err != nil {
		t.Fatalf("insert insight: %v", err)
	}
	allowNarrativeEdges(t, side)

	// Fail the rebuild the way a crash would: after the probe has run. An
	// existing `edges_old` makes the rename step fail deterministically.
	if _, err := side.conn.Exec(`CREATE TABLE edges_old (x)`); err != nil {
		t.Fatalf("block rebuild: %v", err)
	}
	if _, err := Open(dir); err == nil {
		t.Fatal("blocked rebuild must be reported, not silently skipped")
	}

	var left int
	if err := side.conn.QueryRow(
		`SELECT COUNT(*) FROM edges WHERE edge_type = 'narrative'`).Scan(&left); err != nil {
		t.Fatalf("count leftovers: %v", err)
	}
	if left != 0 {
		t.Errorf("probe row outlived a failed migration: %d left behind", left)
	}

	// Unblocked, the migration must still run. This is the assertion that
	// matters: a surviving probe row makes every later attempt collide, and
	// the database keeps the old constraint for good.
	if _, err := side.conn.Exec(`DROP TABLE edges_old`); err != nil {
		t.Fatalf("unblock rebuild: %v", err)
	}
	reopened, err := Open(dir)
	if err != nil {
		t.Fatalf("reopen after unblocking: %v", err)
	}
	defer reopened.Close()
	if _, err := reopened.conn.Exec(
		`INSERT INTO edges VALUES ('probe-src','probe-src','narrative',1,'{}','2026-01-01T00:00:00Z')`); err == nil {
		t.Error("narrative edge type must be rejected after migration")
	}
}

// Insight ids are caller-supplied, so the fixed '__test' sentinel could name a
// real insight -- and the migration deleted edges by that id to clean up after
// itself.
func TestMigrateRemoveNarrativeEdges_KeepsRealEdgesNamedLikeTheSentinel(t *testing.T) {
	dir := t.TempDir()

	db, err := Open(dir)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	if err := db.InsertInsight(makeInsight("__test", "content", 3)); err != nil {
		t.Fatalf("insert insight: %v", err)
	}
	allowNarrativeEdges(t, db)
	if _, err := db.conn.Exec(
		`INSERT INTO edges VALUES ('__test','__test','semantic',0.5,'{}','2026-01-01T00:00:00Z')`); err != nil {
		t.Fatalf("insert edge: %v", err)
	}
	db.Close()

	reopened, err := Open(dir)
	if err != nil {
		t.Fatalf("reopen: %v", err)
	}
	defer reopened.Close()

	var kept int
	if err := reopened.conn.QueryRow(
		`SELECT COUNT(*) FROM edges WHERE source_id = '__test' AND edge_type = 'semantic'`).Scan(&kept); err != nil {
		t.Fatalf("count: %v", err)
	}
	if kept != 1 {
		t.Errorf("a real edge was deleted because its id matched the probe sentinel, got %d", kept)
	}
}

func TestMigrateStoredAtBackfillsLegacyInsights(t *testing.T) {
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "mnemon.db")
	legacy, err := sql.Open("sqlite", dbPath)
	if err != nil {
		t.Fatalf("open legacy database: %v", err)
	}
	if _, err := legacy.Exec(`
		CREATE TABLE insights (
			id TEXT PRIMARY KEY,
			content TEXT NOT NULL,
			category TEXT DEFAULT 'general',
			importance INTEGER DEFAULT 3,
			tags TEXT DEFAULT '[]',
			entities TEXT DEFAULT '[]',
			source TEXT DEFAULT 'user',
			access_count INTEGER DEFAULT 0,
			created_at TEXT NOT NULL,
			updated_at TEXT NOT NULL,
			deleted_at TEXT
		);
		INSERT INTO insights
			(id, content, created_at, updated_at)
		VALUES
			('legacy-row', 'pre-migration memory', '2025-01-02T03:04:05Z', '2025-01-02T03:04:05Z')
	`); err != nil {
		legacy.Close()
		t.Fatalf("create legacy schema: %v", err)
	}
	if err := legacy.Close(); err != nil {
		t.Fatalf("close legacy database: %v", err)
	}

	migrated, err := Open(dir)
	if err != nil {
		t.Fatalf("migrate legacy database: %v", err)
	}
	defer migrated.Close()

	var storedAt string
	if err := migrated.conn.QueryRow(
		`SELECT stored_at FROM insights WHERE id = 'legacy-row'`).Scan(&storedAt); err != nil {
		t.Fatalf("read stored_at: %v", err)
	}
	if storedAt != "2025-01-02T03:04:05Z" {
		t.Fatalf("stored_at = %q, want legacy created_at", storedAt)
	}

	// A sync tool built against the old schema can continue omitting stored_at;
	// the migrated store must still protect that incoming row as newborn.
	if _, err := migrated.conn.Exec(`
		INSERT INTO insights (id, content, created_at, updated_at)
		VALUES ('external-row', 'legacy writer payload', '2020-01-01T00:00:00Z', '2020-01-01T00:00:00Z')
	`); err != nil {
		t.Fatalf("legacy-style insert after migration: %v", err)
	}
	if err := migrated.conn.QueryRow(
		`SELECT stored_at FROM insights WHERE id = 'external-row'`).Scan(&storedAt); err != nil {
		t.Fatalf("read external stored_at: %v", err)
	}
	physicalTime, err := time.Parse(time.RFC3339, storedAt)
	if err != nil {
		t.Fatalf("parse external stored_at %q: %v", storedAt, err)
	}
	if physicalTime.Before(time.Now().UTC().Add(-time.Minute)) {
		t.Fatalf("legacy-style insert inherited historical event time: %s", physicalTime)
	}
}

// --- AutoPrune ---

func disableAutoPruneGrace(t *testing.T) {
	t.Helper()
	t.Setenv("MNEMON_AUTO_PRUNE_MIN_AGE", "0")
}

func TestAutoPrune_PrunesLowestEI(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)

	// Insert more than max
	for i := 0; i < 5; i++ {
		ins := makeInsight("prune-"+string(rune('a'+i)), "content", 2)
		db.InsertInsight(ins)
	}

	// Set max to 3 — should prune 2 (capped by PruneBatchSize)
	pruned, err := db.AutoPrune(3, nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 2 {
		t.Errorf("want 2 pruned, got %d", pruned)
	}

	all, _ := db.GetAllActiveInsights()
	if len(all) != 3 {
		t.Errorf("want 3 remaining, got %d", len(all))
	}
}

// Auto-prune is destructive and, before this test, was the only mutation that
// left no oplog entry — a store could silently shed thousands of insights with
// no record of which ones. Every pruned id must be recoverable from the oplog.
func TestAutoPrune_RecordsOplogEntryPerPrunedInsight(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)

	for i := range 5 {
		db.InsertInsight(makeInsight("audit-"+string(rune('a'+i)), "content", 2))
	}

	prunedIDs, err := db.AutoPruneWithResult(3, nil, "trigger-write")
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	pruned := len(prunedIDs)
	if pruned != 2 {
		t.Fatalf("want 2 pruned, got %d", pruned)
	}

	entries, err := db.GetOplog(50)
	if err != nil {
		t.Fatalf("get oplog: %v", err)
	}
	logged := map[string]bool{}
	for _, e := range entries {
		if e.Operation == "prune" {
			logged[e.InsightID] = true
			if e.Detail == "" {
				t.Errorf("prune entry for %s has empty detail", e.InsightID)
			}
			if !strings.Contains(e.Detail, "trigger=trigger-write") {
				t.Errorf("prune entry for %s missing trigger: %q", e.InsightID, e.Detail)
			}
		}
	}
	if len(logged) != pruned {
		t.Errorf("want %d prune oplog entries, got %d", pruned, len(logged))
	}

	// Every id recorded as pruned must name a row that still exists and is
	// soft-deleted, so the oplog can be trusted as the recovery index. Asking
	// only whether the id is inactive is not the same claim: a lookup that
	// excludes deleted rows also returns nothing for an id that was never in
	// the store, so a fabricated entry would satisfy it.
	for id := range logged {
		ins, err := db.GetInsightByIDIncludeDeleted(id)
		if err != nil {
			t.Errorf("oplog names %s, but no such insight exists: %v", id, err)
			continue
		}
		if ins.DeletedAt == nil {
			t.Errorf("oplog claims %s pruned but it is still active", id)
		}
	}
	for _, id := range prunedIDs {
		if !logged[id] {
			t.Errorf("returned pruned id %s has no matching oplog entry", id)
		}
	}
}

func TestAutoPrune_RespectsImmune(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)

	// Insert 3 insights: 2 immune (importance=4), 1 not
	immune1 := makeInsight("immune-1", "important", 4)
	immune2 := makeInsight("immune-2", "also important", 5)
	weak := makeInsight("weak-1", "low importance", 1)
	db.InsertInsight(immune1)
	db.InsertInsight(immune2)
	db.InsertInsight(weak)

	// Max=1 — only non-immune should be pruned
	pruned, err := db.AutoPrune(1, nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 1 {
		t.Errorf("want 1 pruned (only the weak one), got %d", pruned)
	}

	// Verify the weak one was pruned
	_, err = db.GetInsightByID("weak-1")
	if err == nil {
		t.Error("weak insight should be pruned")
	}
}

func TestAutoPrune_RespectsExcludeIDs(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)
	ins1 := makeInsight("ex-1", "content a", 1)
	ins2 := makeInsight("ex-2", "content b", 1)
	db.InsertInsight(ins1)
	db.InsertInsight(ins2)

	// Max=0, exclude ex-1
	pruned, _ := db.AutoPrune(0, []string{"ex-1"})
	if pruned != 1 {
		t.Errorf("want 1 pruned (only ex-2), got %d", pruned)
	}
	_, err := db.GetInsightByID("ex-1")
	if err != nil {
		t.Error("excluded insight should survive")
	}
}

func TestMaxInsightsLimit(t *testing.T) {
	tests := []struct {
		name string
		env  string
		want int
	}{
		{"unset", "", MaxInsights},
		{"raised", "5000", 5000},
		{"lowered", "200", 200},
		{"padded", "  2500 ", 2500},
		{"zero disables", "0", MaxInsightsUnlimited},
		{"negative disables", "-1", MaxInsightsUnlimited},
		// A typo must not silently shrink the store.
		{"unparseable", "1_000", MaxInsights},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv("MNEMON_MAX_INSIGHTS", tt.env)
			if got := MaxInsightsLimit(); got != tt.want {
				t.Errorf("MaxInsightsLimit() with %q = %d, want %d", tt.env, got, tt.want)
			}
		})
	}
}

func TestAutoPruneMinAge(t *testing.T) {
	tests := []struct {
		name string
		env  string
		want time.Duration
	}{
		{name: "default", env: "", want: DefaultAutoPruneMinAge},
		{name: "hours", env: "2h", want: 2 * time.Hour},
		{name: "days", env: "7d", want: 7 * 24 * time.Hour},
		{name: "padded", env: " 30m ", want: 30 * time.Minute},
		{name: "zero disables", env: "0", want: 0},
		{name: "negative falls back", env: "-1h", want: DefaultAutoPruneMinAge},
		{name: "invalid falls back", env: "tomorrow", want: DefaultAutoPruneMinAge},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv("MNEMON_AUTO_PRUNE_MIN_AGE", tt.env)
			if got := AutoPruneMinAge(); got != tt.want {
				t.Errorf("AutoPruneMinAge() with %q = %s, want %s", tt.env, got, tt.want)
			}
		})
	}
}

func TestAutoPrune_DefaultGraceProtectsNewbornInsights(t *testing.T) {
	t.Setenv("MNEMON_AUTO_PRUNE_MIN_AGE", "")
	db := testDB(t)

	old := makeInsight("old", "eligible old memory", 1)
	old.CreatedAt = time.Now().UTC().Add(-DefaultAutoPruneMinAge - time.Hour)
	old.UpdatedAt = old.CreatedAt
	if err := db.InsertInsight(old); err != nil {
		t.Fatalf("insert old insight: %v", err)
	}
	if _, err := db.Conn().Exec(`UPDATE insights SET stored_at = ? WHERE id = ?`,
		old.CreatedAt.Format(time.RFC3339), old.ID); err != nil {
		t.Fatalf("age stored_at for old insight: %v", err)
	}
	for _, id := range []string{"newborn-a", "newborn-b"} {
		if err := db.InsertInsight(makeInsight(id, "newborn memory", 1)); err != nil {
			t.Fatalf("insert %s: %v", id, err)
		}
	}

	prunedIDs, err := db.AutoPruneWithResult(1, nil, "newborn-b")
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if len(prunedIDs) != 1 || prunedIDs[0] != "old" {
		t.Fatalf("pruned ids = %v, want [old]", prunedIDs)
	}
	for _, id := range []string{"newborn-a", "newborn-b"} {
		if _, err := db.GetInsightByID(id); err != nil {
			t.Errorf("grace period did not protect %s: %v", id, err)
		}
	}
}

func TestAutoPrune_AuditFailureRollsBackDeletion(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)
	for _, id := range []string{"rollback-a", "rollback-b"} {
		if err := db.InsertInsight(makeInsight(id, "must survive", 1)); err != nil {
			t.Fatalf("insert %s: %v", id, err)
		}
	}
	if _, err := db.Conn().Exec(`
		CREATE TRIGGER reject_auto_prune_audit
		BEFORE INSERT ON oplog
		WHEN NEW.operation = 'prune'
		BEGIN
			SELECT RAISE(ABORT, 'audit unavailable');
		END`); err != nil {
		t.Fatalf("create rejecting trigger: %v", err)
	}

	if _, err := db.AutoPruneWithResult(1, nil, "rollback-b"); err == nil {
		t.Fatal("auto prune succeeded without its required audit record")
	}
	active, err := db.GetAllActiveInsights()
	if err != nil {
		t.Fatalf("get active insights: %v", err)
	}
	if len(active) != 2 {
		t.Fatalf("audit failure left %d active insights, want 2", len(active))
	}
}

// Switching auto-prune off has to hold at the capacity check itself, not only
// at the call sites, or a future caller reintroduces the reaping.
func TestAutoPrune_UnlimitedCeilingPrunesNothing(t *testing.T) {
	db := testDB(t)
	for i := range 5 {
		if err := db.InsertInsight(makeInsight("uncapped-"+string(rune('a'+i)), "content", 1)); err != nil {
			t.Fatalf("insert: %v", err)
		}
	}

	pruned, err := db.AutoPrune(MaxInsightsUnlimited, nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 0 {
		t.Errorf("want 0 pruned with auto-prune disabled, got %d", pruned)
	}
	all, _ := db.GetAllActiveInsights()
	if len(all) != 5 {
		t.Errorf("want all 5 insights retained, got %d", len(all))
	}
}

// A raised ceiling has to change what AutoPrune actually takes, not only what
// gc reports: the same store that prunes under a lower resolved ceiling is
// left whole once MNEMON_MAX_INSIGHTS resolves above its size.
func TestAutoPrune_RaisedCeilingChangesEnforcement(t *testing.T) {
	disableAutoPruneGrace(t)
	db := testDB(t)
	for i := range 5 {
		if err := db.InsertInsight(makeInsight("raised-"+string(rune('a'+i)), "content", 2)); err != nil {
			t.Fatalf("insert: %v", err)
		}
	}

	t.Setenv("MNEMON_MAX_INSIGHTS", "8")
	pruned, err := db.AutoPrune(MaxInsightsLimit(), nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 0 {
		t.Errorf("raised ceiling: want 0 pruned, got %d", pruned)
	}

	// Control: the same store over a lower resolved ceiling does prune, so the
	// zero above is the ceiling's doing rather than an inert store.
	t.Setenv("MNEMON_MAX_INSIGHTS", "3")
	pruned, err = db.AutoPrune(MaxInsightsLimit(), nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 2 {
		t.Errorf("lowered ceiling control: want 2 pruned, got %d", pruned)
	}

	all, _ := db.GetAllActiveInsights()
	if len(all) != 3 {
		t.Errorf("want 3 remaining after control prune, got %d", len(all))
	}
}

func TestAutoPrune_NothingToPrune(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("ok-1", "content", 3))

	pruned, err := db.AutoPrune(10, nil)
	if err != nil {
		t.Fatalf("auto prune: %v", err)
	}
	if pruned != 0 {
		t.Errorf("nothing to prune: want 0, got %d", pruned)
	}
}

// --- Oplog ---

func TestOplog(t *testing.T) {
	db := testDB(t)
	db.LogOp("remember", "ins-1", "test detail")
	db.LogOp("recall", "", "query: test")

	entries, err := db.GetOplog(10)
	if err != nil {
		t.Fatalf("get oplog: %v", err)
	}
	if len(entries) != 2 {
		t.Fatalf("want 2 entries, got %d", len(entries))
	}
	// Most recent first
	if entries[0].Operation != "recall" {
		t.Errorf("first entry: want recall, got %s", entries[0].Operation)
	}
	if entries[1].Operation != "remember" {
		t.Errorf("second entry: want remember, got %s", entries[1].Operation)
	}
}

// --- Embedding ---

func TestUpdateAndGetEmbedding(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("emb-1", "content", 3))

	blob := []byte{1, 2, 3, 4} // 1 float32
	if err := db.UpdateEmbedding("emb-1", blob); err != nil {
		t.Fatalf("update embedding: %v", err)
	}

	got, err := db.GetEmbedding("emb-1")
	if err != nil {
		t.Fatalf("get embedding: %v", err)
	}
	if len(got) != 4 {
		t.Errorf("want 4 bytes, got %d", len(got))
	}
}

func TestMigrateEmbeddingsToFloat32(t *testing.T) {
	dir := t.TempDir()
	db, err := Open(dir)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	if err := db.InsertInsight(makeInsight("emb-mig-1", "legacy embedding", 3)); err != nil {
		t.Fatalf("insert insight: %v", err)
	}
	legacy := serializeLegacyEmbedding([]float64{1.5, -2.25})
	if err := db.UpdateEmbedding("emb-mig-1", legacy); err != nil {
		t.Fatalf("update legacy embedding: %v", err)
	}
	if _, err := db.conn.Exec(`PRAGMA user_version = 0`); err != nil {
		t.Fatalf("clear user_version: %v", err)
	}
	db.Close()

	db, err = Open(dir)
	if err != nil {
		t.Fatalf("reopen db: %v", err)
	}
	defer db.Close()

	var userVersion int
	if err := db.conn.QueryRow(`PRAGMA user_version`).Scan(&userVersion); err != nil {
		t.Fatalf("get user_version: %v", err)
	}
	if userVersion != embeddingFloat32UserVersion {
		t.Fatalf("user_version: want %d, got %d", embeddingFloat32UserVersion, userVersion)
	}

	got, err := db.GetEmbedding("emb-mig-1")
	if err != nil {
		t.Fatalf("get migrated embedding: %v", err)
	}
	if len(got) != 8 {
		t.Fatalf("migrated blob length: want 8 bytes, got %d", len(got))
	}
	vec := embed.DeserializeVector(got)
	if len(vec) != 2 {
		t.Fatalf("migrated vector length: want 2, got %d", len(vec))
	}
	if math.Abs(vec[0]-1.5) > 1e-6 || math.Abs(vec[1]-(-2.25)) > 1e-6 {
		t.Fatalf("migrated vector: got %v", vec)
	}
}

func TestMigrateEmbeddingsToFloat32_SkipsUnreadableBlobs(t *testing.T) {
	dir := t.TempDir()
	db, err := Open(dir)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}

	// A genuine legacy float64 embedding — should be migrated normally.
	if err := db.InsertInsight(makeInsight("emb-mig-good", "good", 3)); err != nil {
		t.Fatalf("insert good insight: %v", err)
	}
	good := serializeLegacyEmbedding([]float64{0.5, -0.75})
	if err := db.UpdateEmbedding("emb-mig-good", good); err != nil {
		t.Fatalf("update good embedding: %v", err)
	}

	// A malformed blob whose length isn't a multiple of 8 must not abort the
	// whole migration (and thus block the database from ever opening again).
	if err := db.InsertInsight(makeInsight("emb-mig-malformed", "malformed", 3)); err != nil {
		t.Fatalf("insert malformed insight: %v", err)
	}
	malformed := []byte{1, 2, 3, 4, 5}
	if err := db.UpdateEmbedding("emb-mig-malformed", malformed); err != nil {
		t.Fatalf("update malformed embedding: %v", err)
	}

	// A blob whose bytes decode to NaN as float64 simulates already-migrated
	// float32 (or other non-legacy) data that happens to satisfy len%8==0.
	// It must be left untouched rather than re-encoded as garbage.
	if err := db.InsertInsight(makeInsight("emb-mig-implausible", "implausible", 3)); err != nil {
		t.Fatalf("insert implausible insight: %v", err)
	}
	implausible := []byte{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
	if err := db.UpdateEmbedding("emb-mig-implausible", implausible); err != nil {
		t.Fatalf("update implausible embedding: %v", err)
	}

	if _, err := db.conn.Exec(`PRAGMA user_version = 0`); err != nil {
		t.Fatalf("clear user_version: %v", err)
	}
	db.Close()

	db, err = Open(dir)
	if err != nil {
		t.Fatalf("reopen db: %v", err)
	}
	defer db.Close()

	var userVersion int
	if err := db.conn.QueryRow(`PRAGMA user_version`).Scan(&userVersion); err != nil {
		t.Fatalf("get user_version: %v", err)
	}
	if userVersion != embeddingFloat32UserVersion {
		t.Fatalf("user_version: want %d, got %d", embeddingFloat32UserVersion, userVersion)
	}

	got, err := db.GetEmbedding("emb-mig-good")
	if err != nil {
		t.Fatalf("get migrated embedding: %v", err)
	}
	vec := embed.DeserializeVector(got)
	if len(vec) != 2 || math.Abs(vec[0]-0.5) > 1e-6 || math.Abs(vec[1]-(-0.75)) > 1e-6 {
		t.Fatalf("migrated vector: got %v", vec)
	}

	for id, want := range map[string][]byte{
		"emb-mig-malformed":   malformed,
		"emb-mig-implausible": implausible,
	} {
		gotBlob, err := db.GetEmbedding(id)
		if err != nil {
			t.Fatalf("get %s: %v", id, err)
		}
		if !bytes.Equal(gotBlob, want) {
			t.Fatalf("%s blob: want %v, got %v (should be left untouched)", id, want, gotBlob)
		}
	}
}

func TestGetAllActiveInsights(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("all-1", "a", 3))
	db.InsertInsight(makeInsight("all-2", "b", 3))
	db.InsertInsight(makeInsight("all-3", "c", 3))
	db.SoftDeleteInsight("all-2")

	all, err := db.GetAllActiveInsights()
	if err != nil {
		t.Fatalf("get all: %v", err)
	}
	if len(all) != 2 {
		t.Errorf("want 2 active, got %d", len(all))
	}
}

func TestIncrementAccessCount(t *testing.T) {
	db := testDB(t)
	db.InsertInsight(makeInsight("acc-1", "content", 3))

	db.IncrementAccessCount("acc-1")
	db.IncrementAccessCount("acc-1")

	got, _ := db.GetInsightByID("acc-1")
	if got.AccessCount != 2 {
		t.Errorf("want access_count=2, got %d", got.AccessCount)
	}
}

// --- Store management ---

func TestValidStoreName(t *testing.T) {
	tests := []struct {
		name string
		want bool
	}{
		{"default", true},
		{"my-store", true},
		{"work_2024", true},
		{"A", true},
		{"a1", true},
		{"", false},
		{"-bad", false},
		{"_bad", false},
		{"has space", false},
		{"has/slash", false},
		{"has.dot", false},
		{".hidden", false},
	}
	for _, tt := range tests {
		got := ValidStoreName(tt.name)
		if got != tt.want {
			t.Errorf("ValidStoreName(%q) = %v, want %v", tt.name, got, tt.want)
		}
	}
}

func TestReadWriteActive(t *testing.T) {
	base := t.TempDir()

	// No active file → default
	if got := ReadActive(base); got != DefaultStoreName {
		t.Errorf("ReadActive empty: got %q, want %q", got, DefaultStoreName)
	}

	// Write and read back
	if err := WriteActive(base, "work"); err != nil {
		t.Fatalf("WriteActive: %v", err)
	}
	if got := ReadActive(base); got != "work" {
		t.Errorf("ReadActive after write: got %q, want %q", got, "work")
	}
}

func TestListStores(t *testing.T) {
	base := t.TempDir()

	// Empty → nil
	names, err := ListStores(base)
	if err != nil {
		t.Fatalf("ListStores empty: %v", err)
	}
	if len(names) != 0 {
		t.Errorf("want empty, got %v", names)
	}

	// Create stores
	db1, _ := Open(StoreDir(base, "alpha"))
	db1.Close()
	db2, _ := Open(StoreDir(base, "beta"))
	db2.Close()

	names, err = ListStores(base)
	if err != nil {
		t.Fatalf("ListStores: %v", err)
	}
	if len(names) != 2 || names[0] != "alpha" || names[1] != "beta" {
		t.Errorf("want [alpha beta], got %v", names)
	}
}

func TestStoreExists(t *testing.T) {
	base := t.TempDir()

	if StoreExists(base, "nope") {
		t.Error("should not exist")
	}

	db, _ := Open(StoreDir(base, "yes"))
	db.Close()
	if !StoreExists(base, "yes") {
		t.Error("should exist after Open")
	}
}

func TestMigrateIfNeeded(t *testing.T) {
	base := t.TempDir()

	// Create a legacy DB
	db, err := Open(base)
	if err != nil {
		t.Fatalf("open legacy: %v", err)
	}
	db.InsertInsight(makeInsight("mig-1", "legacy data", 3))
	db.Close()
	if err := os.WriteFile(filepath.Join(base, "mnemon.db-wal"), []byte("wal"), 0o644); err != nil {
		t.Fatalf("write legacy wal: %v", err)
	}
	if err := os.WriteFile(filepath.Join(base, "mnemon.db-shm"), []byte("shm"), 0o644); err != nil {
		t.Fatalf("write legacy shm: %v", err)
	}

	// Run migration
	if err := MigrateIfNeeded(base); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	// Old file should be gone
	if _, err := os.Stat(filepath.Join(base, "mnemon.db")); !os.IsNotExist(err) {
		t.Error("old mnemon.db should be moved")
	}
	if _, err := os.Stat(filepath.Join(base, "mnemon.db-wal")); !os.IsNotExist(err) {
		t.Error("old WAL should be moved")
	}
	if _, err := os.Stat(filepath.Join(base, "mnemon.db-shm")); !os.IsNotExist(err) {
		t.Error("old SHM should be moved")
	}
	if got, err := os.ReadFile(filepath.Join(StoreDir(base, DefaultStoreName), "mnemon.db-wal")); err != nil || string(got) != "wal" {
		t.Fatalf("migrated WAL mismatch: got=%q err=%v", got, err)
	}
	if got, err := os.ReadFile(filepath.Join(StoreDir(base, DefaultStoreName), "mnemon.db-shm")); err != nil || string(got) != "shm" {
		t.Fatalf("migrated SHM mismatch: got=%q err=%v", got, err)
	}
	if err := os.Remove(filepath.Join(StoreDir(base, DefaultStoreName), "mnemon.db-wal")); err != nil {
		t.Fatalf("remove fake migrated WAL: %v", err)
	}
	if err := os.Remove(filepath.Join(StoreDir(base, DefaultStoreName), "mnemon.db-shm")); err != nil {
		t.Fatalf("remove fake migrated SHM: %v", err)
	}

	// New location should work
	db2, err := Open(StoreDir(base, DefaultStoreName))
	if err != nil {
		t.Fatalf("open migrated: %v", err)
	}
	defer db2.Close()
	ins, err := db2.GetInsightByID("mig-1")
	if err != nil || ins.Content != "legacy data" {
		t.Errorf("migrated data lost: err=%v", err)
	}
}

func TestMigrateIfNeeded_AlreadyMigrated(t *testing.T) {
	base := t.TempDir()

	// Create new-layout DB directly
	db, _ := Open(StoreDir(base, DefaultStoreName))
	db.Close()

	// Should be a no-op
	if err := MigrateIfNeeded(base); err != nil {
		t.Fatalf("migrate no-op: %v", err)
	}
}

func TestMigrateIfNeeded_NoLegacy(t *testing.T) {
	base := t.TempDir()
	// Nothing to migrate
	if err := MigrateIfNeeded(base); err != nil {
		t.Fatalf("migrate empty: %v", err)
	}
}

func serializeLegacyEmbedding(v []float64) []byte {
	buf := make([]byte, len(v)*8)
	for i, f := range v {
		binary.LittleEndian.PutUint64(buf[i*8:], math.Float64bits(f))
	}
	return buf
}

// --- LoadKnownEntities ---

func TestLoadKnownEntities_Empty(t *testing.T) {
	db := testDB(t)
	known, err := db.LoadKnownEntities()
	if err != nil {
		t.Fatalf("load known entities on empty DB: %v", err)
	}
	if known == nil {
		t.Error("want non-nil empty map, got nil")
	}
	if len(known) != 0 {
		t.Errorf("want 0 known entities, got %d: %v", len(known), known)
	}
}

func TestLoadKnownEntities_DistinctUnion(t *testing.T) {
	db := testDB(t)
	a := makeInsight("ent-a", "first", 3)
	a.Entities = []string{"Athena", "Hestia"}
	b := makeInsight("ent-b", "second", 3)
	b.Entities = []string{"Hestia", "Mnemon"} // Hestia overlaps with a
	for _, ins := range []*model.Insight{a, b} {
		if err := db.InsertInsight(ins); err != nil {
			t.Fatalf("insert %s: %v", ins.ID, err)
		}
	}

	known, err := db.LoadKnownEntities()
	if err != nil {
		t.Fatalf("load known entities: %v", err)
	}
	for _, want := range []string{"Athena", "Hestia", "Mnemon"} {
		if !known[want] {
			t.Errorf("want %q in known set, got %v", want, known)
		}
	}
	if len(known) != 3 {
		t.Errorf("want 3 distinct entities (Hestia deduped), got %d: %v", len(known), known)
	}
}

func TestLoadKnownEntities_SkipsDeleted(t *testing.T) {
	db := testDB(t)
	live := makeInsight("ent-live", "kept", 3)
	live.Entities = []string{"Athena"}
	dead := makeInsight("ent-dead", "dropped", 3)
	dead.Entities = []string{"Banana"}
	for _, ins := range []*model.Insight{live, dead} {
		if err := db.InsertInsight(ins); err != nil {
			t.Fatalf("insert %s: %v", ins.ID, err)
		}
	}
	if err := db.SoftDeleteInsight("ent-dead"); err != nil {
		t.Fatalf("soft delete: %v", err)
	}

	known, err := db.LoadKnownEntities()
	if err != nil {
		t.Fatalf("load known entities: %v", err)
	}
	if !known["Athena"] {
		t.Errorf("want 'Athena' from live insight, got %v", known)
	}
	if known["Banana"] {
		t.Errorf("'Banana' is on a soft-deleted insight — must not appear, got %v", known)
	}
}
