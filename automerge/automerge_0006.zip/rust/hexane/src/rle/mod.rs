mod decoder;
pub mod edit;
mod load;
pub(crate) mod writer;
pub use load::RleLoadIter;
pub(crate) mod splice;
pub(crate) mod state;
#[cfg(test)]
mod tests;

use crate::encoder::RleEncoder;
pub use decoder::RleDecoder;
pub(crate) use decoder::RleDecoderState;
pub(crate) use load::rle_validate_encoding;
use splice::{do_merge, rle_merge, splice_slab};

use std::marker::PhantomData;
use std::num::NonZeroU32;

use crate::PackError;

type Slab = crate::column::Slab<RleTail>;
use crate::encoding::{ColumnEncoding, RunDecoder, SlabInfo};
use crate::Run;
use crate::{AsColumnRef, Codec, ColumnValueRef, Leb128, RleValue};

// ── Wire-format helpers ───────────────────────────────────────────────────────
//
// The encoding (shared with v0) is a sequence of runs:
//
//   Repeat run : signed_leb128( count > 0 )  packed_value
//   Literal run: signed_leb128( -n      )    v0 v1 … v(n-1)
//   Null run   : signed_leb128( 0       )    unsigned_leb128( count )

// ── RleEncoding ──────────────────────────────────────────────────────────────

/// RLE encoding strategy — used for all non-boolean column value types.
///
/// This is a zero-sized type; all state lives in the slab bytes.
/// `C` is the varint codec used for run headers and value payloads.
pub struct RleEncoding<T: RleValue, C: Codec = Leb128>(PhantomData<fn() -> (T, C)>);

impl<T: RleValue, C: Codec> Default for RleEncoding<T, C> {
    fn default() -> Self {
        Self(PhantomData)
    }
}

/// Compute the RleTail for a slab by scanning to the last segment.
#[cfg(test)]
pub(crate) fn compute_rle_tail<T: RleValue, C: Codec>(data: &[u8]) -> RleTail {
    if data.is_empty() {
        return RleTail::default();
    }
    let mut pos = 0;
    let mut last_start = 0;
    let mut lit_tail: Option<NonZeroU32> = None;
    while pos < data.len() {
        last_start = pos;
        let (cb, raw) = C::read_signed(&data[pos..]).unwrap();
        match raw {
            n if n > 0 => {
                let vl = T::value_len::<C>(&data[pos + cb..]).unwrap();
                lit_tail = None;
                pos += cb + vl;
            }
            n if n < 0 => {
                let total = (-n) as usize;
                let mut sb = pos + cb;
                let mut last_vl = 0;
                for _ in 0..total {
                    last_vl = T::value_len::<C>(&data[sb..]).unwrap();
                    sb += last_vl;
                }
                lit_tail = NonZeroU32::new(last_vl as u32);
                pos = sb;
            }
            _ => {
                let (ncb, _) = C::read_unsigned(&data[pos + cb..]).unwrap();
                lit_tail = None;
                pos += cb + ncb;
            }
        }
    }
    RleTail {
        bytes: (data.len() - last_start) as u32,
        lit_tail,
    }
}

#[doc(hidden)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct RleTail {
    /// Total byte length of the last segment (header + values).
    /// Same meaning for repeat, literal, and null runs.
    ///
    /// `u32` by design: a single segment (one run) must stay under
    /// 4 GiB.  Large blobs belong in [`RawColumn`](crate::RawColumn),
    /// not an RLE column.
    pub(crate) bytes: u32,
    /// For literal runs: byte length of the last value only.
    /// `None` for repeat/null runs.
    pub(crate) lit_tail: Option<NonZeroU32>,
}

impl RleTail {
    pub(crate) fn with_lit_tail(mut self, lit_tail: Option<NonZeroU32>) -> Self {
        self.lit_tail = lit_tail;
        self
    }
}

/// Validate an RLE slab's len, segments, and tail. Panics on mismatch.
#[cfg(debug_assertions)]
fn validate_rle_slab<T: RleValue, C: Codec>(slab: &Slab) {
    let info = rle_validate_encoding::<T, C>(&slab.data)
        .unwrap_or_else(|e| panic!("rle slab encoding invalid: {e}"));
    assert_eq!(slab.len, info.len, "rle slab len mismatch");
    assert_eq!(slab.segments, info.segments, "rle slab segments mismatch");
    assert_eq!(slab.tail, info.tail, "rle slab tail mismatch");
}

impl<T, C> ColumnEncoding for RleEncoding<T, C>
where
    C: Codec,
    T: RleValue + ColumnValueRef<Encoding<C> = RleEncoding<T, C>>,
{
    type Codec = C;
    type Value = T;
    type Tail = RleTail;
    type State = crate::rle::RleDecoderState;

    fn state_at(slab: &crate::rle::Slab, at: usize) -> Self::State {
        let mut d = RleDecoder::<T, C>::new(&slab.data);
        d.advance_by(at);
        d.suspend()
    }

    fn state_peek<'s>(slab: &'s crate::rle::Slab, state: &Self::State) -> Option<T::Get<'s>> {
        RleDecoder::<T, C>::resume(&slab.data, state).next()
    }

    fn state_advance(slab: &crate::rle::Slab, state: &mut Self::State, n: usize) {
        let mut d = RleDecoder::<T, C>::resume(&slab.data, state);
        d.advance_by(n);
        *state = d.suspend();
    }

    fn fill(len: usize, value: T::Get<'_>) -> Slab {
        use state::{RleCow, RleState};
        let mut buf = Vec::new();
        let mut state = RleState::<T, T, C>::empty();
        let mut f = state.append_n(&mut buf, RleCow::Ref(value), len);
        f += state.flush(&mut buf);
        let tail = f.wpos.as_tail(0, buf.len());
        Slab {
            data: buf,
            len,
            segments: f.segments,
            tail,
        }
    }

    fn merge_slabs(a: &mut Slab, b: Slab) {
        if a.len == 0 {
            *a = b;
        } else if b.len > 0 {
            rle_merge::<T, C>(a, &b);
        }
    }

    fn last_run(slab: &Slab) -> Option<Run<T::Get<'_>>> {
        if slab.len == 0 {
            return None;
        }
        // Decode just the last segment using the tail metadata.
        // The tail gives us the byte offset of the last segment.
        let mut dec = Self::decoder(&slab.data);
        let mut last_val = None;
        let mut last_count = 0;
        while let Some(run) = dec.next_run() {
            last_val = Some(run.value);
            last_count = run.count;
        }
        Some(Run {
            count: last_count,
            value: last_val?,
        })
    }

    fn validate_encoding(slab: &[u8]) -> Result<SlabInfo<RleTail>, PackError> {
        rle_validate_encoding::<T, C>(slab)
    }

    fn do_merge(
        acc: &mut Vec<u8>,
        a_tail: RleTail,
        a_segments: usize,
        b: &Slab,
        buf: &mut Vec<u8>,
    ) -> (usize, RleTail) {
        do_merge::<T, C>(acc, a_tail, a_segments, b, buf)
    }

    fn splice_slab<V: AsColumnRef<T>>(
        slab: &mut Slab,
        index: usize,
        del: usize,
        values: impl Iterator<Item = (V, usize)>,
        max_segments: usize,
    ) -> (Vec<Slab>, usize) {
        let slab_del = del.min(slab.len - index);
        let overflow_del = del - slab_del;
        (
            splice_slab::<T, V, C>(slab, index, slab_del, values, max_segments),
            overflow_del,
        )
    }

    type Decoder<'a> = RleDecoder<'a, T, C>;

    fn decoder(slab: &[u8]) -> RleDecoder<'_, T, C> {
        RleDecoder::new(slab)
    }

    type Encoder<'a> = RleEncoder<'a, T, C>;

    fn encoder<'a>() -> Self::Encoder<'a> {
        RleEncoder::new()
    }

    type LoadIter<'a> = load::RleLoadIter<'a, T, C>;

    fn load_iter(data: &[u8], max_segments: usize) -> load::RleLoadIter<'_, T, C> {
        load::RleLoadIter::new(data, max_segments)
    }
}
