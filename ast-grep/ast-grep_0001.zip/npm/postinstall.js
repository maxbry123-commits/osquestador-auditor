const fs = require("fs");
const path = require("path");

const binaryName = process.platform === "win32" ? "ast-grep.exe" : "ast-grep";
const alternativeName = process.platform === "win32" ? "sg.exe" : "sg";

function detectPackageName() {
  const { platform, arch } = process;
  switch (platform) {
    case "darwin":
      if (arch === "arm64") return "@ast-grep/cli-darwin-arm64";
      if (arch === "x64") return "@ast-grep/cli-darwin-x64";
      break;
    case "linux": {
      const { MUSL, familySync } = require("detect-libc");
      if (familySync() === MUSL) return null;
      if (arch === "arm64") return "@ast-grep/cli-linux-arm64-gnu";
      if (arch === "x64") return "@ast-grep/cli-linux-x64-gnu";
      break;
    }
    case "win32":
      if (arch === "arm64") return "@ast-grep/cli-win32-arm64-msvc";
      if (arch === "ia32") return "@ast-grep/cli-win32-ia32-msvc";
      if (arch === "x64") return "@ast-grep/cli-win32-x64-msvc";
      break;
  }
  return null;
}

function resolveBinaryDir() {
  const pkgName = detectPackageName();
  if (pkgName) {
    try {
      const dir = path.dirname(
        require.resolve(`${pkgName}/package.json`, { paths: [__dirname] }),
      );
      if (fs.existsSync(path.join(dir, binaryName))) return dir;
    } catch (_) {
      // fall through to local dev paths
    }
  }
  for (const profile of ["release", "debug"]) {
    const dir = path.join(__dirname, "..", "target", profile);
    if (fs.existsSync(path.join(dir, binaryName))) return dir;
  }
  return null;
}

function resolveBinaryPath() {
  const dir = resolveBinaryDir();
  return dir ? path.join(dir, binaryName) : null;
}

function installBinary(src, dest) {
  try {
    fs.linkSync(src, dest);
  } catch (_) {
    fs.copyFileSync(src, dest);
  }
}

function main() {
  const sourceDir = resolveBinaryDir();
  if (!sourceDir) {
    console.error("Failed to locate @ast-grep/cli native binary.");
    process.exit(1);
  }

  const src = path.join(sourceDir, binaryName);
  const srcAlt = path.join(sourceDir, alternativeName);
  const destBin = path.join(__dirname, binaryName);
  const destAlt = path.join(__dirname, alternativeName);

  try {
    installBinary(src, destBin);
    installBinary(srcAlt, destAlt);
  } catch (_) {
    console.error("Failed to move @ast-grep/cli binaries into place.");
    process.exit(1);
  }

  // Keep the extensionless JS shims on Windows: npm-generated global wrappers
  // call those bin targets through node, so removing them breaks global installs.
}

module.exports = {
  binaryName,
  alternativeName,
  detectPackageName,
  resolveBinaryDir,
  resolveBinaryPath,
};

if (require.main === module) {
  main();
}
