from buildkite_shared.context import BuildkiteContext
from buildkite_shared.step_builders.block_step_builder import BlockStepBuilder
from buildkite_shared.step_builders.command_step_builder import CommandStepBuilder
from buildkite_shared.step_builders.step_builder import StepConfiguration
from dagster_buildkite.steps.packages import _get_uncustomized_pkg_roots


def build_prerelease_package_steps(ctx: BuildkiteContext) -> list[StepConfiguration]:
    steps: list[StepConfiguration] = []

    packages = (
        _get_uncustomized_pkg_roots("python_modules", [])
        + _get_uncustomized_pkg_roots("python_modules/libraries", [])
        + _get_uncustomized_pkg_roots("examples/experimental", [])
    )

    input_step = (
        BlockStepBuilder("choose-package", [":question:"])
        .with_prompt(
            prompt="Choose package and version to publish",
            fields=[
                {
                    "select": "Select a package to publish",
                    "key": "package-to-release-path",
                    "options": [
                        {
                            "label": str(package)[len("python_modules/") :]
                            if str(package).startswith("python_modules/")
                            else str(package),
                            "value": str(package),
                        }
                        for package in packages
                    ],
                    "hint": None,
                    "default": None,
                    "required": True,
                    "multiple": None,
                },
                {
                    "text": "Enter the version to publish",
                    "required": False,
                    "key": "version-to-release",
                    "default": None,
                    "hint": "Leave blank to auto-increment the minor version",
                },
            ],
        )
        .build()
    )
    steps.append(input_step)

    steps.append(
        CommandStepBuilder("build-and-publish-package", [":package:"])
        .run(
            "uv pip install --system build",
            "sh ./scripts/build_and_publish.sh",
        )
        .on_test_image(env=["PYPI_TOKEN"])
        .build()
    )

    return steps
