import os
from collections.abc import Callable
from pathlib import Path

from buildkite_shared.context import BuildkiteContext
from buildkite_shared.packages import (
    PackageSpec,
    PytestExtraCommandsFunction,
    UnsupportedVersionsFunction,
)
from buildkite_shared.python_version import AvailablePythonVersion
from buildkite_shared.step_builders.command_step_builder import BuildkiteQueue, ResourceRequests
from buildkite_shared.step_builders.resource_presets import KIND_TEST_RESOURCES
from buildkite_shared.step_builders.step_builder import TopLevelStepConfiguration
from buildkite_shared.tox import ToxFactor
from buildkite_shared.utils import (
    connect_sibling_docker_container,
    network_buildkite_container,
    oss_path,
)
from dagster_buildkite.defines import (
    GCP_CREDS_FILENAME,
    GCP_CREDS_LOCAL_FILE,
    LATEST_DAGSTER_RELEASE,
)
from dagster_buildkite.steps.test_project import test_project_depends_fn
from dagster_buildkite.utils import library_version_from_core_version

SCRIPT_PATH = os.path.dirname(os.path.abspath(__file__))
DAGSTER_CURRENT_BRANCH = "current_branch"
EARLIEST_TESTED_RELEASE = "0.12.8"

# Spins up a `webserver_service` docker-compose stack (dagster_webserver +
# user-code sidecar) in the dind sidecar. Single-pair compose, comparable to
# dagster-test's fixtures_tests sizing.
_BACKCOMPAT_RESOURCES = ResourceRequests(
    cpu="1000m",
    memory="1Gi",
    docker_memory="2Gi",
    docker_memory_limit="4Gi",
)

# monitoring_daemon_tests cycles a postgres+minio compose stack plus pulls and
# runs the `test_project` image per test. Same dind saturation shape as
# dagster-docker / dagster-celery-docker (see packages.py:1185).
_DAEMON_RESOURCES = ResourceRequests(
    cpu="1000m",
    memory="1Gi",
    docker_cpu="4000m",
    docker_memory="2Gi",
    docker_memory_limit="8Gi",
)


# ########################
# ##### BACKCOMPAT
# ########################


def build_backcompat_suite_steps(ctx: BuildkiteContext) -> list[TopLevelStepConfiguration]:
    tox_factors = [
        ToxFactor("user-code-latest-release"),
        ToxFactor("user-code-earliest-release"),
    ]

    return build_integration_suite_steps(
        oss_path(os.path.join("integration_tests", "test_suites", "backcompat-test-suite")),
        ctx,
        pytest_extra_cmds=backcompat_extra_cmds,
        pytest_tox_factors=tox_factors,
        queue=BuildkiteQueue.KUBERNETES_EKS,
        resources=_BACKCOMPAT_RESOURCES,
    )


def backcompat_extra_cmds(_, factor: ToxFactor | None) -> list[str]:
    tox_factor_map = {
        "user-code-latest-release": LATEST_DAGSTER_RELEASE,
        "user-code-earliest-release": EARLIEST_TESTED_RELEASE,
    }
    assert factor
    factor_str = factor.factor
    webserver_version = DAGSTER_CURRENT_BRANCH
    webserver_library_version = _get_library_version(webserver_version)
    user_code_version = tox_factor_map[factor_str]
    user_code_library_version = _get_library_version(user_code_version)
    user_code_definitions_file = _infer_user_code_definitions_files(user_code_version)

    return [
        f"export EARLIEST_TESTED_RELEASE={EARLIEST_TESTED_RELEASE}",
        f"export USER_CODE_DEFINITIONS_FILE={user_code_definitions_file}",
        f"pushd {oss_path('integration_tests/test_suites/backcompat-test-suite/webserver_service')}",
        " ".join(
            [
                "./build.sh",
                webserver_version,
                webserver_library_version,
                user_code_version,
                user_code_library_version,
                user_code_definitions_file,
            ]
        ),
        "docker compose up -d --remove-orphans",  # clean up in hooks/pre-exit
        *network_buildkite_container("webserver_service_network"),
        *connect_sibling_docker_container(
            "webserver_service_network",
            "dagster_webserver",
            "BACKCOMPAT_TESTS_WEBSERVER_HOST",
        ),
        "popd",
    ]


def _infer_user_code_definitions_files(user_code_release: str) -> str:
    """Returns the definitions file to use for the user code release."""
    if user_code_release == EARLIEST_TESTED_RELEASE:
        return "defs_for_earliest_tested_release.py"
    else:
        return "defs_for_latest_release.py"


def _get_library_version(version: str) -> str:
    if version == DAGSTER_CURRENT_BRANCH:
        return DAGSTER_CURRENT_BRANCH
    else:
        return library_version_from_core_version(version)


# ########################
# ##### CELERY K8S
# ########################


def build_celery_k8s_suite_steps(ctx: BuildkiteContext) -> list[TopLevelStepConfiguration]:
    pytest_tox_factors = [
        ToxFactor("-default"),
        ToxFactor("-markredis"),
    ]
    directory = oss_path(os.path.join("integration_tests", "test_suites", "celery-k8s-test-suite"))
    return build_integration_suite_steps(
        directory,
        ctx,
        pytest_tox_factors,
        queue=BuildkiteQueue.KUBERNETES_EKS,
        resources=KIND_TEST_RESOURCES,
        force_run_fn=BuildkiteContext.has_helm_changes,
        pytest_extra_cmds=celery_k8s_integration_suite_pytest_extra_cmds,
    )


# ########################
# ##### DAEMON
# ########################


def build_daemon_suite_steps(ctx: BuildkiteContext) -> list[TopLevelStepConfiguration]:
    pytest_tox_factors = None
    directory = oss_path(os.path.join("integration_tests", "test_suites", "daemon-test-suite"))
    return build_integration_suite_steps(
        directory,
        ctx,
        pytest_tox_factors,
        pytest_extra_cmds=daemon_pytest_extra_cmds,
        queue=BuildkiteQueue.KUBERNETES_EKS,
        resources=_DAEMON_RESOURCES,
    )


def skip_if_not_azure_commit(ctx: BuildkiteContext) -> str | None:
    """If no dagster-azure files are changed, skip the azure live tests."""
    return (
        None
        if (any("dagster-azure" in str(path) for path in ctx.changed_files))
        else "Not a dagster-azure commit"
    )


def skip_if_not_gcp_commit(ctx: BuildkiteContext) -> str | None:
    """If no dagster-gcp files are changed, skip the gcp live tests."""
    return (
        None
        if (any("dagster-gcp" in str(path) for path in ctx.changed_files))
        else "Not a dagster-gcp commit"
    )


def build_azure_live_test_suite_steps(ctx: BuildkiteContext) -> list[TopLevelStepConfiguration]:
    return PackageSpec(
        oss_path(os.path.join("integration_tests", "test_suites", "dagster-azure-live-tests")),
        skip_run_fn=skip_if_not_azure_commit,
        env_vars=[
            "TEST_AZURE_TENANT_ID",
            "TEST_AZURE_CLIENT_ID",
            "TEST_AZURE_CLIENT_SECRET",
            "TEST_AZURE_STORAGE_ACCOUNT_ID",
            "TEST_AZURE_CONTAINER_ID",
            "TEST_AZURE_ACCESS_KEY",
        ],
    ).build_steps(ctx)


def daemon_pytest_extra_cmds(version: AvailablePythonVersion, _: ToxFactor | None) -> list[str]:
    return [
        "export DAGSTER_DOCKER_IMAGE_TAG=$${BUILDKITE_BUILD_ID}-" + version.value,
        'export DAGSTER_DOCKER_REPOSITORY="$${AWS_ACCOUNT_ID}.dkr.ecr.us-west-2.amazonaws.com"',
    ]


# ########################
# ##### K8S
# ########################


def build_k8s_suite_steps(ctx: BuildkiteContext) -> list[TopLevelStepConfiguration]:
    # `use_durations=False` on the split k8s factors: pytest-split's
    # `.test_durations` data records only test-body time, which for k8s
    # integration tests is dominated by kind-cluster fixture setup that pytest
    # can't see. Empirically, balancing against that data made shards
    # significantly more imbalanced than count-based grouping — see the
    # post-merge regression on builds 155444 / 155446.
    pytest_tox_factors = [
        ToxFactor("-default", splits=2, use_durations=False),
        ToxFactor("-subchart", splits=2, use_durations=False),
        ToxFactor("-default_monitoring"),
        ToxFactor("-subchart_monitoring"),
    ]
    directory = oss_path(os.path.join("integration_tests", "test_suites", "k8s-test-suite"))
    return build_integration_suite_steps(
        directory,
        ctx,
        pytest_tox_factors,
        force_run_fn=BuildkiteContext.has_helm_changes,
        pytest_extra_cmds=k8s_integration_suite_pytest_extra_cmds,
        queue=BuildkiteQueue.KUBERNETES_EKS,
        resources=KIND_TEST_RESOURCES,
    )


# ########################
# ##### UTILITIES
# ########################


def build_integration_suite_steps(
    directory: str | Path,
    ctx: BuildkiteContext,
    pytest_tox_factors: list[ToxFactor] | None = None,
    pytest_extra_cmds: PytestExtraCommandsFunction | None = None,
    queue=None,
    force_run_fn: Callable[[BuildkiteContext], bool] | None = None,
    unsupported_python_versions: list[AvailablePythonVersion]
    | UnsupportedVersionsFunction
    | None = None,
    *,
    resources: ResourceRequests | None,
) -> list[TopLevelStepConfiguration]:
    return PackageSpec(
        directory,
        env_vars=[
            "AIRFLOW_HOME",
            "AWS_ACCOUNT_ID",
            "AWS_ACCESS_KEY_ID",
            "AWS_SECRET_ACCESS_KEY",
            "BUILDKITE_SECRETS_BUCKET",
            "GOOGLE_APPLICATION_CREDENTIALS",
        ],
        pytest_extra_cmds=pytest_extra_cmds,
        pytest_step_dependencies=test_project_depends_fn,
        pytest_tox_factors=pytest_tox_factors,
        timeout_in_minutes=30,
        queue=queue,
        resources=resources,
        force_run_fn=force_run_fn,
        unsupported_python_versions=unsupported_python_versions,
    ).build_steps(ctx)


def k8s_integration_suite_pytest_extra_cmds(version: AvailablePythonVersion, _) -> list[str]:
    # ECR login is handled by the ecr-docker-login init container in the EKS
    # pod-spec-patch (infra/k8s/buildkite/base/conf/buildkite.yaml).
    return [
        # Materialize the IRSA web-identity token into AWS_ACCESS_KEY_ID/SECRET/SESSION_TOKEN
        # env vars so the test fixtures can propagate them into kind step pods, which can
        # reach neither IMDS nor the IRSA token file.
        'eval "$(aws configure export-credentials --format env)"',
        "export DOCKER_API_VERSION=1.41",
        "export DAGSTER_DOCKER_IMAGE_TAG=$${BUILDKITE_BUILD_ID}-" + version.value,
        'export DAGSTER_DOCKER_REPOSITORY="$${AWS_ACCOUNT_ID}.dkr.ecr.us-west-2.amazonaws.com"',
    ]


def celery_k8s_integration_suite_pytest_extra_cmds(version: AvailablePythonVersion, _) -> list[str]:
    # ECR login is handled by the ecr-docker-login init container in the EKS
    # pod-spec-patch (infra/k8s/buildkite/base/conf/buildkite.yaml).
    cmds = [
        # Materialize the IRSA web-identity token into AWS_ACCESS_KEY_ID/SECRET/SESSION_TOKEN
        # env vars so the test fixtures can propagate them into kind step pods, which can
        # reach neither IMDS nor the IRSA token file.
        'eval "$(aws configure export-credentials --format env)"',
        "export DOCKER_API_VERSION=1.41",
        'export AIRFLOW_HOME="/airflow"',
        "mkdir -p $${AIRFLOW_HOME}",
        "export DAGSTER_DOCKER_IMAGE_TAG=$${BUILDKITE_BUILD_ID}-" + version.value,
        'export DAGSTER_DOCKER_REPOSITORY="$${AWS_ACCOUNT_ID}.dkr.ecr.us-west-2.amazonaws.com"',
    ]

    # If integration tests are disabled, we won't have any gcp credentials to download.
    if not os.getenv("CI_DISABLE_INTEGRATION_TESTS"):
        cmds += [
            rf"aws s3 cp s3://\${{BUILDKITE_SECRETS_BUCKET}}/{GCP_CREDS_FILENAME} "
            + GCP_CREDS_LOCAL_FILE,
            "export GOOGLE_APPLICATION_CREDENTIALS=" + GCP_CREDS_LOCAL_FILE,
        ]

    cmds += [
        f"pushd {oss_path('python_modules/libraries/dagster-celery')}",
        # Run the rabbitmq db. We are in docker running docker
        # so this will be a sibling container.
        "docker compose up -d --remove-orphans",  # clean up in hooks/pre-exit,
        # Can't use host networking on buildkite and communicate via localhost
        # between these sibling containers, so pass along the ip.
        *network_buildkite_container("rabbitmq"),
        *connect_sibling_docker_container(
            "rabbitmq", "test-rabbitmq", "DAGSTER_CELERY_BROKER_HOST"
        ),
        "popd",
    ]

    return cmds
