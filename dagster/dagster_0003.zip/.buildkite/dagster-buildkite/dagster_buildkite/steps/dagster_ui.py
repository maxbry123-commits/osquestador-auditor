from buildkite_shared.context import BuildkiteContext
from buildkite_shared.python_version import AvailablePythonVersion
from buildkite_shared.step_builders.command_step_builder import (
    CommandStepBuilder,
    CommandStepConfiguration,
)
from buildkite_shared.utils import oss_path
from dagster_buildkite.steps.packages import PackageSpec


def skip_if_no_dagster_ui_components_changes(ctx: BuildkiteContext) -> str | None:
    if not ctx.is_feature_branch:
        return None

    # If anything changes in the ui-components directory
    if any(oss_path("js_modules/ui-components") in path.parents for path in ctx.changed_files):
        return None

    return "No changes that affect the ui-components JS library"


def build_dagster_ui_components_steps(ctx: BuildkiteContext) -> list[CommandStepConfiguration]:
    return [
        CommandStepBuilder("dagster-ui-components", [":typescript:"])
        .on_test_image()
        .run(
            f"cd {oss_path('js_modules/ui-components')}",
            f"tox -vv -e {AvailablePythonVersion.to_tox_factor(AvailablePythonVersion.get_default())}",
        )
        .skip(skip_if_no_dagster_ui_components_changes(ctx))
        .build(),
    ]


def skip_if_no_dagster_ui_core_changes(ctx: BuildkiteContext) -> str | None:
    if not ctx.is_feature_branch:
        return None
    elif ctx.has_javascript_changes():
        return None
    # If anything changes in python packages that our front end depend on
    # dagster and dagster-graphql might indicate changes to our graphql schema
    elif not PackageSpec(oss_path("python_modules/dagster-graphql")).get_skip_reason(ctx):
        return None

    return "No changes that affect the JS webapp"


def build_dagster_ui_core_steps(ctx: BuildkiteContext) -> list[CommandStepConfiguration]:
    return [
        CommandStepBuilder("dagster-ui-core", [":typescript:"])
        .on_test_image()
        .run(
            f"cd {oss_path('js_modules')}",
            f"tox -vv -e {AvailablePythonVersion.to_tox_factor(AvailablePythonVersion.get_default())}",
        )
        .skip(skip_if_no_dagster_ui_core_changes(ctx))
        .build(),
    ]


def skip_if_no_dagster_ui_changes(ctx: BuildkiteContext) -> str | None:
    return skip_if_no_dagster_ui_components_changes(ctx) or skip_if_no_dagster_ui_core_changes(ctx)
