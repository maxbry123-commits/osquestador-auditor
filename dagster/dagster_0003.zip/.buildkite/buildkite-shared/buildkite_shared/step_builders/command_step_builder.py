import os
from collections.abc import Callable, Mapping, Sequence
from enum import StrEnum
from typing import Any, Self

from buildkite_shared.python_version import AvailablePythonVersion
from buildkite_shared.step_builders.slug import make_label
from buildkite_shared.utils import BUILDKITE_TEST_IMAGE_VERSION, RETRYABLE_INFRA_FAILURE_EXIT_CODE
from typing_extensions import NotRequired, TypedDict

DEFAULT_TIMEOUT_IN_MIN = 35

DOCKER_PLUGIN = "docker#v5.10.0"
ECR_PLUGIN = "ecr#v2.7.0"
SM_PLUGIN = "seek-oss/aws-sm#v2.3.1"
BASE_IMAGE_NAME = "buildkite-test"
BASE_IMAGE_TAG = "2026-05-04T142331"
BUILDKITE_TEST_IMAGE_PY_SLIM = "buildkite-test-image-py-slim:prod-1777949196"

AWS_ACCOUNT_ID = os.getenv("AWS_ACCOUNT_ID")
AWS_ECR_REGION = "us-west-2"


class ResourceRequests:
    def __init__(
        self,
        cpu: str,
        *,
        memory: str | None = None,
        docker_cpu: str = "2000m",
        docker_memory: str = "1Gi",
        docker_memory_limit: str = "2Gi",
        ephemeral_storage: str | None = None,
        docker_storage_size: str | None = None,
    ) -> None:
        self._cpu = cpu
        self._memory = memory
        self._docker_cpu = docker_cpu
        self._docker_memory = docker_memory
        self._docker_memory_limit = docker_memory_limit
        self._ephemeral_storage = ephemeral_storage
        self._docker_storage_size = docker_storage_size

    @property
    def cpu(self) -> str:
        return self._cpu

    @property
    def memory(self) -> str | None:
        return self._memory

    @property
    def docker_cpu(self) -> str:
        return self._docker_cpu

    @property
    def docker_memory(self) -> str:
        return self._docker_memory

    @property
    def docker_memory_limit(self) -> str:
        return self._docker_memory_limit

    @property
    def ephemeral_storage(self) -> str | None:
        return self._ephemeral_storage

    @property
    def docker_storage_size(self) -> str | None:
        # Size of a dedicated emptyDir to mount at /var/lib/docker inside the
        # dind sidecar. EBS-backed (not tmpfs) so it doesn't compete with the
        # dind container's memory cgroup. Counts against the pod's
        # ephemeral_storage, which must be sized to cover it plus the agent's
        # checkout / build artifacts.
        return self._docker_storage_size


class BuildkiteQueue(StrEnum):
    KUBERNETES_EKS = os.getenv("BUILDKITE_KUBERNETES_QUEUE_EKS", "kubernetes-eks")

    @classmethod
    def contains(cls, value: str) -> bool:
        return isinstance(value, cls)


class CommandStepConfiguration(TypedDict, closed=True):
    agents: dict[str, str]
    label: str
    timeout_in_minutes: int
    plugins: list[dict[str, object]]
    retry: dict[str, object]
    commands: NotRequired[list[str]]
    depends_on: NotRequired[list[str]]
    key: NotRequired[str]
    skip: NotRequired[str | None]
    artifact_paths: NotRequired[list[str]]
    concurrency: NotRequired[int]
    concurrency_group: NotRequired[str]
    allow_dependency_failure: NotRequired[bool]
    soft_fail: NotRequired[bool]
    # Covers the "if" key, which is a Python reserved word and cannot be used as
    # a class attribute. Buildkite uses "if" for conditional step execution.
    __extra_items__: str


class CommandStepBuilder:
    _step: CommandStepConfiguration

    def __init__(
        self,
        key: str,
        label_emojis: list[str] | None = None,
        *,
        timeout_in_minutes: int = DEFAULT_TIMEOUT_IN_MIN,
        retry_automatically: bool = True,
        plugins: list[dict[str, object]] | None = None,
    ) -> None:
        self._secrets = {}
        self._k8s_secrets = []
        self._k8s_volume_mounts = []
        self._k8s_volumes = []
        self._docker_settings = None
        # Concrete env vars set via `.with_env({...})`. Source of truth on
        # both queue paths: on k8s these become podSpec container env
        # entries; on docker they're merged into the docker plugin's
        # `environment` list as `KEY=value`. Bare-name passthroughs belong
        # in the `on_*_image(env=[...])` parameter / agent envFrom chain —
        # not here.
        self._env: dict[str, str] = {}

        retry: dict[str, Any] = {
            "manual": {"permit_on_passed": True},
        }

        if retry_automatically:
            # This list contains exit codes that should map only to ephemeral infrastructure issues.
            # Normal test failures (exit code 1), make command failures (exit code 2) and the like
            # should not be included here. Our shell wrappers may exit with
            # RETRYABLE_INFRA_FAILURE_EXIT_CODE (200) to escalate a known-transient failure
            # (e.g. ECR login, pip/uv install) to a fresh-job retry.
            retry["automatic"] = [
                # https://buildkite.com/docs/agent/v3#exit-codes
                {"exit_status": -1, "limit": 2},  # agent lost
                {
                    "exit_status": -10,
                    "limit": 2,
                },  # example: https://buildkite.com/dagster/internal/builds/108316#0196fd13-d816-42e7-bf26-b264385b245d
                {
                    "exit_status": 94,
                    "limit": 2,
                },  # checkout failed (e.g. git-mirror clone lock timeout)
                {"exit_status": 125, "limit": 2},  # docker daemon error
                {"exit_status": 128, "limit": 2},  # k8s git clone error
                {"exit_status": 130, "limit": 2},  # SIGINT (e.g. spot reclamation)
                {"exit_status": 143, "limit": 2},  # agent lost
                {"exit_status": 255, "limit": 2},  # agent forced shut down
                {
                    "exit_status": RETRYABLE_INFRA_FAILURE_EXIT_CODE,
                    "limit": 2,
                },  # our shell wrappers signaling a transient infra failure
                {
                    "exit_status": 28,
                    "limit": 2,
                },  # node ran out of space, try to reschedule
                {
                    "signal_reason": "agent_stop",
                    "limit": 2,
                },  # agent stopped (e.g. spot eviction, pod termination)
            ]

        self._step = {
            "agents": {"queue": BuildkiteQueue.KUBERNETES_EKS.value},
            "key": key,
            "label": make_label(key, label_emojis),
            "timeout_in_minutes": timeout_in_minutes,
            "retry": retry,
            "plugins": plugins or [],
        }
        # Default off: most steps don't need a docker daemon (lints, type-checkers,
        # k8s manifests, helm, kaniko image builds, dashboard publishing). Steps that
        # actually invoke `docker compose`/`docker build`/`docker pull` opt in via
        # `.with_docker()`. Off-by-default avoids attaching a privileged dind sidecar
        # — which costs scheduling resources and is the kubelet's first eviction
        # target under fan-out memory pressure — to steps that don't need one.
        self._requires_docker = False  # used for k8s queue; opt in via .with_docker()
        self._resources = None

    def run(self, *argc: str) -> Self:
        self._step["commands"] = list(argc)
        return self

    def resources(self, resources: ResourceRequests | None) -> Self:
        self._resources = resources
        return self

    def with_docker(self) -> Self:
        self._requires_docker = True
        return self

    def on_python_image(
        self,
        image: str,
        *,
        env: list[str] | None = None,
        account_id: str | None = AWS_ACCOUNT_ID,
        region: str = AWS_ECR_REGION,
    ) -> Self:
        settings = self._base_docker_settings(env)
        settings["image"] = f"{account_id}.dkr.ecr.{region}.amazonaws.com/{image}"
        settings["network"] = "kind"
        self._docker_settings = settings
        return self

    def on_specific_image(
        self, image: str, extra_docker_plugin_args: dict[str, object] = {}
    ) -> Self:
        settings = {"image": image, **extra_docker_plugin_args}
        if self._docker_settings:
            self._docker_settings.update(settings)
        else:
            self._docker_settings = settings
        return self

    def on_test_image(
        self,
        ver: str = AvailablePythonVersion.get_cloud().value,
        image_version: str = BUILDKITE_TEST_IMAGE_VERSION,
        env: list[str] | None = None,
    ) -> Self:
        return self.on_python_image(
            image=f"buildkite-test:py{ver}-{image_version}",
            env=env,
        ).with_ecr_login()

    def on_integration_slim_image(self, env: list[str] | None = None) -> Self:
        return self.on_python_image(
            image=BUILDKITE_TEST_IMAGE_PY_SLIM,
            env=env,
        )

    def on_integration_image(
        self,
        ver: str = AvailablePythonVersion.get_cloud().value,
        env: list[str] | None = None,
        image_name: str = BASE_IMAGE_NAME,
        image_version: str = BASE_IMAGE_TAG,
        ecr_account_ids: list[str | None] = [AWS_ACCOUNT_ID],
    ) -> Self:
        return self.on_python_image(
            image=f"{image_name}:py{ver}-{image_version}",
            env=env,
        ).with_ecr_login(ecr_account_ids)

    def with_ecr_login(self, ecr_account_ids: list[str | None] = [AWS_ACCOUNT_ID]) -> Self:
        assert "plugins" in self._step
        self._step["plugins"].append(
            {
                ECR_PLUGIN: {
                    "login": True,
                    "no-include-email": True,
                    "account_ids": ecr_account_ids,
                    "region": "us-west-2",
                }
            }
        )
        return self

    def with_ecr_passthru(self) -> Self:
        assert self._docker_settings
        assert self._docker_settings["environment"]
        assert self._docker_settings["volumes"]
        self._docker_settings["environment"] = [
            *self._docker_settings["environment"],
            "BUILDKITE_DOCKER_CONFIG_TEMP_DIRECTORY",
            "DOCKER_CONFIG=/tmp/.docker",
        ]
        self._docker_settings["volumes"] = list(
            set(
                [
                    *[v for v in self._docker_settings["volumes"]],
                    # share auth with the docker buildkite-test
                    "$$BUILDKITE_DOCKER_CONFIG_TEMP_DIRECTORY/config.json:/tmp/.docker/config.json",
                ]
            )
        )
        return self

    def with_artifact_paths(self, *paths: str) -> Self:
        if "artifact_paths" not in self._step:
            self._step["artifact_paths"] = []
        self._step["artifact_paths"].extend(paths)
        return self

    def with_condition(self, condition: str) -> Self:
        self._step["if"] = condition  # pyright: ignore[reportGeneralTypeIssues]
        return self

    def with_secret(self, name: str, reference: str) -> Self:
        self._secrets[name] = reference
        return self

    def with_env(self, env_vars: dict[str, str]) -> Self:
        self._env.update(env_vars)
        return self

    def with_timeout(self, num_minutes: int | None) -> Self:
        if num_minutes is not None:
            self._step["timeout_in_minutes"] = num_minutes
        return self

    def on_queue(self, queue: BuildkiteQueue) -> Self:
        self._step["agents"]["queue"] = queue.value
        return self

    def with_kubernetes_secret(self, secret: str) -> Self:
        self._k8s_secrets.append(secret)
        return self

    def with_kubernetes_volume(self, volume: dict[str, Any]) -> Self:
        self._k8s_volumes.append(volume)
        return self

    def with_kubernetes_volume_mount(self, volume_mount: dict[str, Any]) -> Self:
        self._k8s_volume_mounts.append(volume_mount)
        return self

    def concurrency(self, limit: int) -> Self:
        self._step["concurrency"] = limit
        return self

    def concurrency_group(self, concurrency_group_name: str) -> Self:
        self._step["concurrency_group"] = concurrency_group_name
        return self

    def depends_on(self, dependencies: str | Sequence[str] | None) -> Self:
        if dependencies is not None:
            self._step["depends_on"] = (
                [dependencies] if isinstance(dependencies, str) else list(dependencies)
            )
        return self

    def allow_dependency_failure(self) -> Self:
        self._step["allow_dependency_failure"] = True
        return self

    def soft_fail(self, fail: bool = True) -> Self:
        self._step["soft_fail"] = fail
        return self

    def skip(self, skip_reason: str | None = None) -> Self:
        self._step["skip"] = skip_reason
        return self

    def _get_resources(self) -> dict[str, object]:
        cpu = (
            self._resources.cpu
            if self._resources
            else ("1000m" if self._requires_docker else "500m")
        )
        memory = self._resources.memory if self._resources else None
        default_ephemeral_storage = "10Gi" if self._requires_docker else "5Gi"
        ephemeral_storage = (
            self._resources.ephemeral_storage if self._resources else None
        ) or default_ephemeral_storage
        return {
            "requests": {
                "cpu": cpu,
                "memory": memory,
                "ephemeral-storage": ephemeral_storage,
            },
        }

    def _base_docker_settings(self, env: list[str] | None = None) -> dict[str, object]:
        return {
            "shell": ["/bin/bash", "-xeuc"],
            "mount-ssh-agent": True,
            "propagate-environment": False,
            "expand-volume-vars": True,
            "volumes": ["/var/run/docker.sock:/var/run/docker.sock", "/tmp:/tmp"],
            "environment": [
                "PYTEST_ADDOPTS",
                "PYTEST_PLUGINS",
                "BUILDKITE",
                "BUILDKITE_BUILD_CHECKOUT_PATH",
                "BUILDKITE_BUILD_URL",
                "BUILDKITE_ORGANIZATION_SLUG",
                "BUILDKITE_PIPELINE_SLUG",
                "BUILDKITE_BRANCH",
                "BUILDKITE_COMMIT",
                "BUILDKITE_MESSAGE",
            ]
            + [
                # these are exposed via the ECR plugin and then threaded through
                # to kubernetes. see https://github.com/buildkite-plugins/ecr-buildkite-plugin
                "AWS_SECRET_ACCESS_KEY",
                "AWS_ACCESS_KEY_ID",
                "AWS_SESSION_TOKEN",
                "AWS_REGION",
                "AWS_ACCOUNT_ID",
                "UV_DEFAULT_INDEX",
                # `uv`'s 48h-old-package cutoff, set in the buildkite pre-command
                # hook to mirror the workspace's `[tool.uv].exclude-newer`. Has
                # to be allowlisted here or it gets stripped at the docker
                # boundary (`propagate-environment: False` above).
                "UV_EXCLUDE_NEWER",
                # `tox` CLI-override that appends `UV_*` to every testenv's
                # passenv so the cutoff above survives into the test subprocess
                # — same docker-boundary reason.
                "TOX_OVERRIDE",
            ]
            + [
                # needed by our own stuff
                "DAGSTER_INTERNAL_GIT_REPO_DIR",
                "DAGSTER_GIT_REPO_DIR",
                "COMBINED_COMMIT_HASH",
                "DAGSTER_COMMIT_HASH",
                "INTERNAL_COMMIT_HASH",
            ]
            + [
                # tox related env variables. ideally these are in
                # the test specification themselves, but for now this is easier
                "AWS_DEFAULT_REGION",
                "SNOWFLAKE_ACCOUNT",
                "SNOWFLAKE_USER",
                "SNOWFLAKE_PASSWORD",
            ]
            + ["PYTEST_DEBUG_TEMPROOT=/tmp"]
            + (env or []),
            "mount-buildkite-agent": True,
        }

    def _base_k8s_settings(self) -> Mapping[Any, Any]:
        buildkite_shell = "/bin/bash -e -c"
        assert self._docker_settings
        image = str(self._docker_settings["image"])
        # no skip
        if image == "hashicorp/terraform:light" or "/datadog-ci:" in image or "/alpine:" in image:
            buildkite_shell = "/bin/sh -e -c"
        elif "kaniko-project/executor" in image:
            buildkite_shell = "/busybox/sh -e -c"

        sidecars = []
        if self._requires_docker:
            # Determine docker image based on queue (GKE vs EKS)
            queue = self._step.get("agents", {}).get("queue", "")
            is_gke = "gke" in queue
            if is_gke:
                docker_image = "us-central1-docker.pkg.dev/dagster-production/buildkite-images/docker:29.4.3-dind"
            else:
                docker_image = "public.ecr.aws/docker/library/docker:29.4.3-dind"

            # Bump max-concurrent-downloads/uploads from default 3 to 10 to
            # parallelize layer pulls. The dockerd-entrypoint.sh of the
            # docker:dind image execs `dockerd` with whatever args are
            # passed, so these forward through cleanly.
            dind_args = [
                "--max-concurrent-downloads=10",
                "--max-concurrent-uploads=10",
            ]
            if not is_gke:
                # Route docker.io pulls through the in-cluster Docker Hub
                # mirror to avoid Docker Hub 5xx flakes and rate limits. The
                # mirror is a `registry:2` Deployment in the buildkite-agent
                # namespace; see infra/k8s/buildkite/overlays/buildkite-eks/
                # dockerhub-mirror.yaml. dockerd transparently falls back to
                # registry-1.docker.io if the mirror is unreachable.
                dind_args.append(
                    "--registry-mirror=http://dockerhub-mirror.buildkite-agent.svc.cluster.local:5000"
                )

            dind_volume_mounts = [
                {
                    "mountPath": "/var/run",
                    "name": "docker-sock",
                },
                # Shared /tmp with the test container so docker bind
                # mounts of paths like `tempfile.TemporaryDirectory()`
                # resolve to the same files dockerd sees. On EC2 the
                # docker plugin mounted the host's /tmp into the test
                # container and dockerd ran on the host, so /tmp was
                # implicitly shared. On EKS the dind sidecar has its
                # own /tmp by default, breaking that assumption.
                {
                    "mountPath": "/tmp",
                    "name": "shared-tmp",
                },
            ]
            docker_storage_size = self._resources.docker_storage_size if self._resources else None
            if docker_storage_size:
                # See ResourceRequests.docker_storage_size for rationale.
                dind_volume_mounts.append(
                    {
                        "mountPath": "/var/lib/docker",
                        "name": "dind-storage",
                    }
                )
            else:
                # Dedicated pod-private emptyDir for dockerd's image
                # store and container state. Without this, /var/lib/docker
                # falls through to the dind container's writable layer on
                # the node's overlay filesystem, which is shared with every
                # other pod on the node — so heavy snapshot/layer ops
                # serialize at the kernel FS layer and dockerd holds its
                # internal locks across that serialization. The observed
                # symptom is 60s `UnixHTTPConnectionPool` ReadTimeouts on
                # `containers.create` calls during dagster-docker tests
                # (see #24902 / #24936 escalation ladder). Isolating
                # /var/lib/docker to a per-pod mount eliminates the
                # filesystem-layer overlay overhead and the cross-pod
                # contention at that surface.
                dind_volume_mounts.append(
                    {
                        "mountPath": "/var/lib/docker",
                        "name": "docker-data",
                    }
                )
            sidecars.append(
                {
                    "image": docker_image,
                    "command": ["dockerd-entrypoint.sh"],
                    "args": dind_args,
                    # Memory request/limit promote the dind sidecar from
                    # BestEffort to Burstable QoS, so it isn't the first
                    # container the kubelet evicts when a node is under
                    # memory pressure during fan-out waves. Without this,
                    # docker API calls (`containers.create` etc.) can hang
                    # for minutes mid-test before the SDK's read timeout
                    # fires — see test_docker_launcher.py flakes.
                    "resources": {
                        "requests": {
                            "cpu": self._resources.docker_cpu if self._resources else "2000m",
                            "memory": self._resources.docker_memory if self._resources else "1Gi",
                        },
                        "limits": {
                            "memory": self._resources.docker_memory_limit
                            if self._resources
                            else "2Gi",
                        },
                    },
                    "env": [
                        {
                            "name": "DOCKER_TLS_CERTDIR",
                            "value": "",
                        },
                    ],
                    "volumeMounts": dind_volume_mounts,
                    "securityContext": {
                        "privileged": True,
                        "allowPrivilegeEscalation": True,
                    },
                    # Block main containers from starting until dockerd is
                    # actually responding to API calls. agent-stack-k8s only
                    # gates main-container startup on the sidecar's "Started"
                    # signal, which fires once dockerd's binary is running but
                    # not necessarily once the daemon is accepting connections.
                    # `docker info` round-trips to dockerd over the socket, so
                    # it catches the window between bind() (where the socket
                    # file appears) and listen()/accept() — a window that
                    # `test -S /var/run/docker.sock` was passing through,
                    # letting test code race ahead and hit "Cannot connect to
                    # the Docker daemon" when invoking `docker compose up`.
                    "startupProbe": {
                        "exec": {"command": ["docker", "info"]},
                        "periodSeconds": 1,
                        "failureThreshold": 30,
                        "timeoutSeconds": 5,
                    },
                }
            )
            self._k8s_volumes.append(
                {
                    "name": "docker-sock",
                    "emptyDir": {},
                }
            )
            self._k8s_volumes.append(
                {
                    "name": "shared-tmp",
                    "emptyDir": {},
                }
            )
            self._k8s_volumes.append(
                {
                    "name": "docker-data",
                    # 10Gi cap bounds the dind sidecar's footprint on the
                    # node's ephemeral storage. The test-project image is
                    # ~2-3Gi and per-test scratch space is small, so 10Gi is
                    # comfortable headroom. If a job ever blows through, the
                    # eviction blast radius is just that pod.
                    "emptyDir": {
                        "sizeLimit": "10Gi",
                    },
                }
            )
            self._k8s_volume_mounts.append(
                {
                    "mountPath": "/var/run/",
                    "name": "docker-sock",
                },
            )
            self._k8s_volume_mounts.append(
                {
                    "mountPath": "/tmp",
                    "name": "shared-tmp",
                },
            )
            if docker_storage_size:
                self._k8s_volumes.append(
                    {
                        "name": "dind-storage",
                        "emptyDir": {"sizeLimit": docker_storage_size},
                    }
                )

        return {
            "gitEnvFrom": [{"secretRef": {"name": "git-ssh-credentials"}}],
            "mirrorVolumeMounts": True,
            "sidecars": sidecars,
            "podSpec": {
                "serviceAccountName": "buildkite-job",
                "containers": [
                    {
                        "image": self._docker_settings["image"],
                        "env": [
                            {
                                "name": "BUILDKITE_SHELL",
                                "value": buildkite_shell,
                            },
                            # {
                            #     "name": "UV_DEFAULT_INDEX",
                            #     "value": "http://devpi.buildkite-agent.svc.cluster.local/root/pypi",
                            # },
                            {
                                "name": "POD_NAME",
                                "valueFrom": {"fieldRef": {"fieldPath": "metadata.name"}},
                            },
                            {
                                "name": "NODE_NAME",
                                "valueFrom": {"fieldRef": {"fieldPath": "spec.nodeName"}},
                            },
                        ],
                        "envFrom": [
                            {"secretRef": {"name": "buildkite-dagster-secrets"}},
                            {"secretRef": {"name": "honeycomb-api-key"}},
                            *[
                                {"secretRef": {"name": secret_name}}
                                for secret_name in self._k8s_secrets
                            ],
                        ],
                        "resources": self._get_resources(),
                        "volumeMounts": self._k8s_volume_mounts,
                        "securityContext": {"capabilities": {"add": ["SYS_PTRACE"]}},
                    },
                ],
                "volumes": self._k8s_volumes,
            },
        }

    def build(self) -> CommandStepConfiguration:
        assert "agents" in self._step
        on_k8s = self._step["agents"]["queue"] == BuildkiteQueue.KUBERNETES_EKS
        # Note: `self._requires_docker` is k8s-only. On non-k8s queues docker is
        # provided by the host agent regardless of the flag, so we don't gate.

        if not on_k8s and self._k8s_secrets:
            raise Exception(
                "Specified a kubernetes secret on a non-kubernetes queue. Please call .on_queue(BuildkiteQueue.KUBERNETES_EKS) if you want to run on k8s"
            )

        if on_k8s:
            # for k8s we take the image that we were going to run in docker
            # and instead launch it as a pod directly on k8s. to do this
            # we need to patch the image that buildkite will actually run
            # during the test step to match. `buildkite-agent bootstrap` (which
            # is the entrypoint that ends up getting run (via some volume mounting
            # magic) depends on a BUILDKITE_SHELL variable to actually execute
            # the specified command (like "terraform fmt -check -recursive"). some
            # images require /bin/bash, others don't have it, so there's some setting
            # munging done below as well.
            if self._docker_settings:
                k8s_settings = self._base_k8s_settings()
                # Propagate concrete env vars set via .with_env({...}) into
                # the pod's container env. Intentionally do NOT auto-pickup
                # KEY=value entries from self._docker_settings["environment"]:
                # that list holds docker-plugin-specific settings like
                # `DOCKER_CONFIG=/tmp/.docker` (added by with_ecr_passthru())
                # which have no meaning on k8s and actively break ECR auth
                # here — EKS pods get ECR auth via the ecr-docker-login
                # initContainer writing /work/.docker/config.json, not via
                # DOCKER_CONFIG redirection.
                container_env = k8s_settings["podSpec"]["containers"][0]["env"]
                container_env.extend({"name": k, "value": v} for k, v in self._env.items())
                self._step["plugins"] = [{"kubernetes": k8s_settings}]
            if self._secrets:
                # SM_PLUGIN runs as a buildkite-agent bootstrap hook inside
                # the user container under agent-stack-k8s; exported env vars
                # are visible to subsequent command hooks. setdefault guards
                # the unusual case where a step has _secrets without
                # _docker_settings.
                self._step.setdefault("plugins", []).append(
                    {SM_PLUGIN: {"region": "us-west-1", "env": self._secrets}}
                )

            return self._step

        # adding SM and DOCKER plugin in build allows secrets to be passed to docker envs
        assert "plugins" in self._step
        self._step["plugins"].append({SM_PLUGIN: {"region": "us-west-1", "env": self._secrets}})
        if self._docker_settings:
            env_list = self._docker_settings.setdefault("environment", [])
            for secret in self._secrets.keys():
                env_list.append(secret)
            for k, v in self._env.items():
                env_list.append(f"{k}={v}")

            # we need to dedup the env vars to make sure that the ones we set
            # aren't overridden by the ones that are already set in the parent env
            # the last one wins. Use split("=", 1) so values containing "="
            # (e.g. JSON, query strings) don't blow up the unpacking.
            envvar_map = {}
            for ev in env_list:
                k, v = ev.split("=", 1) if "=" in ev else (ev, None)
                envvar_map[k] = v
            self._docker_settings["environment"] = [
                f"{k}={v}" if v is not None else k for k, v in envvar_map.items()
            ]
            assert "plugins" in self._step
            self._step["plugins"].append({DOCKER_PLUGIN: self._docker_settings})
        return self._step


StepBuilderMutator = Callable[[CommandStepBuilder], CommandStepBuilder]
