import logging
import os
import re
import subprocess
import sys
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any, Generic, Literal, TypeAlias, overload

import tomllib
from buildkite_shared.transform import filter_steps, repeat_steps, simplify_steps
from buildkite_shared.utils import oss_path, pushd
from packaging import version
from packaging.requirements import Requirement
from typing_extensions import Self, TypeVar

if TYPE_CHECKING:
    from buildkite_shared.step_builders.step_builder import StepConfiguration

INTERNAL_OSS_PREFIX = "dagster-oss"

# When detecting Python package changes, only look at these filetypes.
_PACKAGE_CHANGE_DETECTION_FILETYPES = [
    ".py",
    ".cfg",
    ".toml",
    ".yaml",
    ".ipynb",
    ".yml",
    ".ini",
    ".jinja",
]

T_Config = TypeVar("T_Config", bound="BuildConfig", default="BuildConfig", covariant=True)


class BuildkiteContext(Generic[T_Config]):
    def __init__(
        self,
        repo_path: Path,
        env: Mapping[str, str],
        config: T_Config,
        changed_files: frozenset[Path],
        packages: dict[str, "PythonPackage"],
    ) -> None:
        self.repo_path = repo_path
        self.env = env
        self.config = config
        self.changed_files = changed_files
        self._packages = packages
        self._has_package_changes_cache: dict[PythonPackage, bool] = {}
        self._has_package_test_changes_cache: dict[PythonPackage, bool] = {}
        self._has_package_dependency_changes_cache: dict[PythonPackage, bool] = {}

    @classmethod
    def create(
        cls,
        env: Mapping[str, str] = os.environ,
        changed_files: Iterable[Path] | None = None,
        packages: dict[str, "PythonPackage"] | None = None,
    ) -> Self:
        repo_path = Path.cwd()
        config = cls.extract_build_config(env)

        # In CI environments, we need to explicitly set up the git repo to be
        # able to detect changed files, since we start with a shallow clone.
        if os.environ.get("BUILDKITE"):
            _setup_git_repo(repo_path)
        resolved_changed_files = (
            frozenset(changed_files)
            if changed_files is not None
            else _discover_changed_files(repo_path)
        )
        resolved_packages = (
            packages
            if packages is not None
            else {pkg.name: pkg for pkg in sorted(discover_python_packages(repo_path))}
        )
        return cls(
            repo_path=repo_path,
            env=env,
            config=config,
            changed_files=resolved_changed_files,
            packages=resolved_packages,
        )

    @classmethod
    def extract_build_config(cls, env: Mapping[str, str]) -> "BuildConfig":
        return BuildConfig.from_env(env)

    @overload
    def get_env(self, var: "BuildkiteEnvVar") -> str | None: ...

    @overload
    def get_env(self, var: "BuildkiteEnvVar", default: None) -> str | None: ...

    @overload
    def get_env(self, var: "BuildkiteEnvVar", default: str) -> str: ...

    def get_env(self, var: "BuildkiteEnvVar", default: str | None = None) -> str | None:
        return self.env.get(var, default)

    def getx_env(self, var: "BuildkiteEnvVar") -> str:
        return _get_required_env_var(var, self.env)

    @property
    def branch(self) -> str:
        return self.getx_env("BUILDKITE_BRANCH")

    @property
    def message(self) -> str:
        return self.getx_env("BUILDKITE_MESSAGE")

    @cached_property
    def commit_hash(self) -> str:
        env_commit = self.getx_env("BUILDKITE_COMMIT")
        return (
            env_commit
            if len(env_commit) == 40
            # not a full commit hash, likely a symbolic ref like HEAD
            else subprocess.check_output(["git", "rev-parse", env_commit]).decode().strip()
        )

    @property
    def is_release_branch(self) -> bool:
        return _is_release_branch(self.branch)

    @property
    def is_master_branch(self) -> bool:
        return _is_master_branch(self.branch)

    @property
    def is_feature_branch(self) -> bool:
        return _is_feature_branch(self.branch)

    @property
    def pipeline_slug(self) -> str:
        return self.getx_env("BUILDKITE_PIPELINE_SLUG")

    def is_triggered_job(self) -> bool:
        # Builds triggered by another Buildkite build have a source of "trigger_job"
        # Builds triggered by commits to a Github repo have a source of "webhook"
        return self.get_env("BUILDKITE_SOURCE") == "trigger_job"

    @property
    def release_version(self) -> version.Version:
        self.require_release_branch()
        return version.parse(self.branch.split("-")[-1])

    def require_release_branch(self) -> None:
        if not self.is_release_branch:
            raise ValueError(f"Branch {self.branch} is not a release branch")

    # ########################
    # ##### CHANGE DETECTION
    # ########################

    def has_oss_changes(self) -> bool:
        """True if any changed files are within the OSS directory."""
        return any(oss_path(".") in (path, *path.parents) for path in self.changed_files)

    def get_package(self, name: str) -> "PythonPackage":
        norm_name = name.replace("_", "-")
        if norm_name not in self._packages:
            all_packages_str = "\n".join([pkg.name for pkg in sorted(self._packages.values())])
            raise Exception(
                f"Could not find {name} in package list. Packages are discovered via"
                " `git ls-files '**/tox.ini'` — ensure the package has a tox.ini file committed"
                f"and tracked by git.\nPackages:\n{all_packages_str}"
            )
        return self._packages[norm_name]

    def has_package(self, name: str) -> bool:
        norm_name = name.replace("_", "-")
        return norm_name in self._packages

    def has_package_changes(self, name: str) -> bool:
        """True if this package has non-test source file changes."""
        pkg = self.get_package(name)
        if pkg not in self._has_package_changes_cache:
            self._has_package_changes_cache[pkg] = self._detect_package_changes(
                pkg, include_test_files=False
            )
        return self._has_package_changes_cache[pkg]

    def has_package_test_changes(self, name: str) -> bool:
        """True if this package has any changes (including test-only changes)."""
        pkg = self.get_package(name)
        if pkg not in self._has_package_test_changes_cache:
            self._has_package_test_changes_cache[pkg] = self._detect_package_changes(
                pkg, include_test_files=True
            )
        return self._has_package_test_changes_cache[pkg]

    def has_package_dependency_changes(self, name: str) -> bool:
        """True if any in-repo dependency of this package has non-test changes."""
        pkg = self.get_package(name)
        if pkg not in self._has_package_dependency_changes_cache:
            result = False
            for dep in pkg.dependencies:
                if not self.has_package(dep.name):
                    continue
                elif self.has_package_changes(dep.name) or self.has_package_dependency_changes(
                    dep.name
                ):
                    result = True
                    break
            self._has_package_dependency_changes_cache[pkg] = result
        return self._has_package_dependency_changes_cache[pkg]

    def _detect_package_changes(
        self,
        package: "PythonPackage",
        include_test_files: bool,
    ) -> bool:
        for path in self.changed_files:
            abs_path = self.repo_path / path
            if not (
                _path_is_relative_to(abs_path, package.directory)
                and path.suffix in _PACKAGE_CHANGE_DETECTION_FILETYPES
            ):
                continue
            if include_test_files:
                return True
            # Check for _tests/ only in the path relative to the package
            # directory, not the full repo path. Otherwise directories like
            # "integration_tests/" in the repo prefix cause false positives.
            rel_path = abs_path.relative_to(package.directory)
            if "_tests/" not in str(rel_path):
                return True
        return False

    def has_python_changes(self) -> bool:
        return any(path.suffix == ".py" for path in self.changed_files)

    def has_javascript_changes(self) -> bool:
        js_root = oss_path("js_modules")
        return any(path.is_relative_to(js_root) for path in self.changed_files)

    def has_yaml_changes(self) -> bool:
        return any(path.suffix in (".yml", ".yaml") for path in self.changed_files)

    def has_helm_changes(self) -> bool:
        return any(oss_path("helm") in path.parents for path in self.changed_files)

    def has_docs_changes(self) -> bool:
        return any(oss_path("docs") in path.parents for path in self.changed_files)

    def has_non_docs_markdown_changes(self) -> bool:
        return any(
            path.suffix == ".md" and Path("docs") not in path.parents for path in self.changed_files
        )

    def has_dagster_airlift_changes(self) -> bool:
        return any("dagster-airlift" in str(path) for path in self.changed_files)

    def has_dg_changes(self) -> bool:
        return any(
            "dagster-dg" in str(path) or "docs_snippets" in str(path) for path in self.changed_files
        )

    def has_component_integration_changes(self) -> bool:
        component_integrations = [
            "dagster-sling",
            "dagster-dbt",
            "dagster-databricks",
            "dagster-airbyte",
            "dagster-powerbi",
            "dagster-omni",
            "dagster-polytomic",
            "dagster-fivetran",
            "dagster-dlt",
        ]
        return any(
            any(integration in str(path) for integration in component_integrations)
            for path in self.changed_files
        )

    def has_rest_resources_changes(self) -> bool:
        return any("dagster-rest-resources" in str(path) for path in self.changed_files)

    def has_dg_or_component_integration_or_rest_resource_changes(self) -> bool:
        return (
            self.has_dg_changes()
            or self.has_component_integration_changes()
            or self.has_rest_resources_changes()
        )

    def has_storage_test_fixture_changes(self) -> bool:
        return any(
            oss_path("python_modules/dagster/dagster_tests/storage_tests/utils") in path.parents
            for path in self.changed_files
        )

    def has_published_python_package_changes(self) -> bool:
        """True if any published (PyPI) Python package has non-test source changes."""
        published_package_root = self.repo_path / oss_path("python_modules")
        return any(
            self.has_package_changes(name)
            for name, pkg in self._packages.items()
            if _path_is_relative_to(pkg.directory, published_package_root)
        )

    # ########################
    # ##### TRANSFORMS
    # ########################

    def apply_transforms(
        self, steps: Sequence["StepConfiguration"]
    ) -> Sequence["StepConfiguration"]:
        # Filter and repeat settings are only applied on feature branches.
        if self.is_feature_branch and self.config.step_filter:
            steps = filter_steps(
                steps, lambda step: self.config.step_filter in step.get("label", "")
            )
        if self.is_feature_branch and self.config.repeat > 1:
            steps = repeat_steps(steps, self.config.repeat)
        return simplify_steps(steps)


@dataclass
class BuildConfig:
    # Forces all steps to run, even if they would normally be skipped by the step filter.
    no_skip: bool
    # A substring that will be used to filter the steps to run. The filter
    # predicate is `substring in step["label"]`.
    step_filter: str | None
    # An integer specifying how many times to run each step. Primarily useful
    # when combined with the STEP_FILTER directive to run a subset of steps
    # multiple times, for example to surface flaky tests.
    repeat: int
    # Collect pytest-split timing data instead of running tests normally. When
    # set, split tox suites are emitted as a single un-sharded step with
    # `--store-durations`, the resulting `.test_durations*` file is uploaded as
    # a Buildkite artifact, and all other pipeline steps are pruned. The
    # internal pipeline appends a final aggregation step that opens a PR with
    # the collected files.
    refresh_durations: bool

    @classmethod
    def from_raw(cls, raw: Mapping[str, str]) -> Self:
        return cls(
            no_skip=bool(raw.get("no_skip")),
            step_filter=raw.get("step_filter"),
            repeat=int(raw.get("repeat", "1")),
            refresh_durations=bool(raw.get("refresh_durations")),
        )

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        """Build config params from environment variables and the build message.

        Config values are resolved from two sources, in order of increasing priority:

        1. Environment variables: Any env var whose name (case-insensitive) matches a
           config field is used as a base value. This is how triggered builds pass config
           -- the parent build sets env vars on the triggered build.
        2. Message magic strings: `[VAR=VALUE]` patterns in BUILDKITE_MESSAGE (usually
           the commit message) override env var values. This is how developers manually
           control builds via commit messages.

        For message magic strings, VALUE can be omitted (equivalent to "TRUE"). VAR and
        VALUE must contain only letters, numbers, and underscores.

        Example: a commit message of "Fix bug [STEP_FILTER=integration] [REPEAT=5]"
        sets the step_filter and repeat config params.
        """
        field_names = {field.name for field in cls.__dataclass_fields__.values()}

        # Base layer: pull config from env vars (case-insensitive).
        params: dict[str, str] = {}
        for key, value in env.items():
            key_norm = key.lower()
            if key_norm in field_names and value:
                logging.info(f"Extracted param from env: {key}={value}")
                params[key_norm] = value

        # Override layer: pull config from message magic strings.
        buildkite_message = env.get("BUILDKITE_MESSAGE", "")
        pattern = r"\[([A-Za-z0-9_]+)(?:=([A-Za-z0-9_]+))?\]"
        matches: list[tuple[str, str]] = re.findall(pattern, buildkite_message)
        for var, value in matches:
            var_norm = var.lower()
            if var_norm not in field_names:
                logging.warning(f"Ignoring unrecognized param in message: {var}")
                continue
            norm_value = value or "TRUE"
            logging.info(f"Extracted param from message: {var}={norm_value}")
            params[var_norm] = norm_value

        return cls.from_raw(params)


# ########################
# ##### BUILDKITE ENV VARS
# ########################

## Buildkite environment variables.
BuildkiteEnvVar: TypeAlias = Literal[
    # Always true
    "BUILDKITE",
    # The value of the debug agent configuration option.
    "BUILDKITE_AGENT_DEBUG",
    # The value of the disconnect-after-job agent configuration option.
    "BUILDKITE_AGENT_DISCONNECT_AFTER_JOB",
    # The value of the disconnect-after-idle-timeout agent configuration option.
    "BUILDKITE_AGENT_DISCONNECT_AFTER_IDLE_TIMEOUT",
    # The value of the endpoint agent configuration option. This is set as an environment variable by the bootstrap and then read by most of the buildkite-agent commands.
    "BUILDKITE_AGENT_ENDPOINT",
    # A list of the experimental agent features that are currently enabled. The value can be set using the --experiment flag on the buildkite-agent start command or in your agent configuration file.
    "BUILDKITE_AGENT_EXPERIMENT",
    # The value of the health-check-addr agent configuration option.
    "BUILDKITE_AGENT_HEALTH_CHECK_ADDR",
    # The UUID of the agent.
    "BUILDKITE_AGENT_ID",
    # The value of each agent tag. The tag name is appended to the end of the variable name. They can be set using the --tags flag on the buildkite-agent start command, or in the agent configuration file. The Queue tag is specifically used for isolating jobs and agents, and appears as the BUILDKITE_AGENT_META_DATA_QUEUE environment variable.
    "BUILDKITE_AGENT_META_DATA_",
    # The name of the agent that ran the job.
    "BUILDKITE_AGENT_NAME",
    # The process ID of the agent.
    "BUILDKITE_AGENT_PID",
    # The artifact paths to upload after the job, if any have been specified. The value can be modified by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_ARTIFACT_PATHS",
    # The path where artifacts will be uploaded. This variable is read by the buildkite-agent artifact upload command, and during the artifact upload phase of command steps. It can only be set by exporting the environment variable in the environment, pre-checkout or pre-command hooks.
    "BUILDKITE_ARTIFACT_UPLOAD_DESTINATION",
    # The path to the directory containing the buildkite-agent binary.
    "BUILDKITE_BIN_PATH",
    # The branch being built. Note that for manually triggered builds, this branch is not guaranteed to contain the commit specified by BUILDKITE_COMMIT.
    "BUILDKITE_BRANCH",
    # The path where the agent has checked out your code for this build. This variable is read by the bootstrap when the agent is started, and can only be set by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_BUILD_CHECKOUT_PATH",
    # The name of the user who authored the commit being built. May be unverified. This value can be blank in some situations, including builds manually triggered using API or Buildkite web interface.
    "BUILDKITE_BUILD_AUTHOR",
    # The notification email of the user who authored the commit being built. May be unverified. This value can be blank in some situations, including builds manually triggered using API or Buildkite web interface.
    "BUILDKITE_BUILD_AUTHOR_EMAIL",
    # The name of the user who created the build.
    "BUILDKITE_BUILD_CREATOR",
    # The notification email of the user who created the build.
    "BUILDKITE_BUILD_CREATOR_EMAIL",
    # A colon separated list of non-private team slugs that the build creator belongs to.
    "BUILDKITE_BUILD_CREATOR_TEAMS",
    # The UUID of the build.
    "BUILDKITE_BUILD_ID",
    # The build number. This number increases with every build, and is guaranteed to be unique within each pipeline.
    "BUILDKITE_BUILD_NUMBER",
    # The value of the build-path agent configuration option.
    "BUILDKITE_BUILD_PATH",
    # The url for this build on Buildkite.
    "BUILDKITE_BUILD_URL",
    # The value of the cancel-grace-period agent configuration option in seconds.
    "BUILDKITE_CANCEL_GRACE_PERIOD",
    # The value of the cancel-signal agent configuration option. The value can be modified by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_CANCEL_SIGNAL",
    # Whether the build should perform a clean checkout. The variable is read during the default checkout phase of the bootstrap and can be overridden in environment or pre-checkout hooks.
    "BUILDKITE_CLEAN_CHECKOUT",
    # The UUID value of the cluster, but only if the build has an associated cluster_queue. Otherwise, this environment variable is not set.
    "BUILDKITE_CLUSTER_ID",
    # The name of the cluster in which the job is running.
    "BUILDKITE_CLUSTER_NAME",
    # The command that will be run for the job.
    "BUILDKITE_COMMAND",
    # The opposite of the value of the no-command-eval agent configuration option.
    "BUILDKITE_COMMAND_EVAL",
    # The exit code from the last command run in the command hook.
    "BUILDKITE_COMMAND_EXIT_STATUS",
    # hosted if the job is running on Hosted Agents, otherwise self-hosted.
    "BUILDKITE_COMPUTE_TYPE",
    # The git commit object of the build. This is usually a 40-byte hexadecimal SHA-1 hash, but can also be a symbolic name like HEAD.
    "BUILDKITE_COMMIT",
    # The path to the agent config file.
    "BUILDKITE_CONFIG_PATH",
    # The path to the file containing the job's environment variables.
    "BUILDKITE_ENV_FILE",
    # The value of the git-clean-flags agent configuration option. The value can be modified by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_GIT_CLEAN_FLAGS",
    # The value of the git-clone-flags agent configuration option. The value can be modified by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_GIT_CLONE_FLAGS",
    # The UUID of the group step the job belongs to. This variable is only available if the job belongs to a group step.
    "BUILDKITE_GROUP_ID",
    # The value of the key attribute of the group step the job belongs to. This variable is only available if the job belongs to a group step.
    "BUILDKITE_GROUP_KEY",
    # The label/name of the group step the job belongs to. This variable is only available if the job belongs to a group step.
    "BUILDKITE_GROUP_LABEL",
    # The value of the hooks-path agent configuration option.
    "BUILDKITE_HOOKS_PATH",
    # A list of environment variables that have been set in your pipeline that are protected and will be overridden, used internally to pass data from the bootstrap to the agent.
    "BUILDKITE_IGNORED_ENV",
    # The internal UUID Buildkite uses for this job.
    "BUILDKITE_JOB_ID",
    # Is initially undefined, but gets defined with the value true by the agent when the job has been canceled. This value can be used by subsequent hooks to opt out of executing.
    "BUILDKITE_JOB_CANCELLED",
    # The path to a temporary file containing the logs for this job. Requires enabling the enable-job-log-tmpfile agent configuration option.
    "BUILDKITE_JOB_LOG_TMPFILE",
    # The label/name of the current job.
    "BUILDKITE_LABEL",
    # The exit code of the last hook that ran, used internally by the hooks.
    "BUILDKITE_LAST_HOOK_EXIT_STATUS",
    # The opposite of the value of the no-local-hooks agent configuration option.
    "BUILDKITE_LOCAL_HOOKS_ENABLED",
    # The message associated with the build, usually the commit message or the message provided when the build is triggered.
    "BUILDKITE_MESSAGE",
    # The UUID of the organization.
    "BUILDKITE_ORGANIZATION_ID",
    # The organization name on Buildkite as used in URLs.
    "BUILDKITE_ORGANIZATION_SLUG",
    # The index of each parallel job created from a parallel build step, starting from 0.
    "BUILDKITE_PARALLEL_JOB",
    # The total number of parallel jobs created from a parallel build step.
    "BUILDKITE_PARALLEL_JOB_COUNT",
    # The default branch for this pipeline.
    "BUILDKITE_PIPELINE_DEFAULT_BRANCH",
    # The UUID of the pipeline.
    "BUILDKITE_PIPELINE_ID",
    # The displayed pipeline name on Buildkite.
    "BUILDKITE_PIPELINE_NAME",
    # The ID of the source code provider for the pipeline's repository.
    "BUILDKITE_PIPELINE_PROVIDER",
    # The pipeline slug on Buildkite as used in URLs.
    "BUILDKITE_PIPELINE_SLUG",
    # A colon separated list of the pipeline's non-private team slugs.
    "BUILDKITE_PIPELINE_TEAMS",
    # A JSON string holding the current plugin's configuration (as opposed to all the plugin configurations in the BUILDKITE_PLUGINS environment variable).
    "BUILDKITE_PLUGIN_CONFIGURATION",
    # The current plugin's name, with all letters in uppercase and any spaces replaced with underscores.
    "BUILDKITE_PLUGIN_NAME",
    # A JSON object containing a list plugins used in the step, and their configuration.
    "BUILDKITE_PLUGINS",
    # The opposite of the value of the no-plugins agent configuration option.
    "BUILDKITE_PLUGINS_ENABLED",
    # The value of the plugins-path agent configuration option.
    "BUILDKITE_PLUGINS_PATH",
    # Whether to validate plugin configuration and requirements.
    "BUILDKITE_PLUGIN_VALIDATION",
    # The number of the pull request or false if not a pull request.
    "BUILDKITE_PULL_REQUEST",
    # The base branch that the pull request is targeting or "" if not a pull request.
    "BUILDKITE_PULL_REQUEST_BASE_BRANCH",
    # Set to true when the pull request is a draft. This variable is only available if a build contains a draft pull request.
    "BUILDKITE_PULL_REQUEST_DRAFT",
    # The repository URL of the pull request or "" if not a pull request.
    "BUILDKITE_PULL_REQUEST_REPO",
    # The UUID of the original build this was rebuilt from or "" if not a rebuild.
    "BUILDKITE_REBUILT_FROM_BUILD_ID",
    # The number of the original build this was rebuilt from or "" if not a rebuild.
    "BUILDKITE_REBUILT_FROM_BUILD_NUMBER",
    # A custom refspec for the buildkite-agent bootstrap script to use when checking out code.
    "BUILDKITE_REFSPEC",
    # The repository of your pipeline. This variable can be set by exporting the environment variable in the environment or pre-checkout hooks.
    "BUILDKITE_REPO",
    # The path to the shared git mirror. Introduced in v3.47.0.
    "BUILDKITE_REPO_MIRROR",
    # How many times this job has been retried.
    "BUILDKITE_RETRY_COUNT",
    # The value of the shell agent configuration option.
    "BUILDKITE_SHELL",
    # The source of the event that created the build.
    "BUILDKITE_SOURCE",
    # The opposite of the value of the no-ssh-keyscan agent configuration option.
    "BUILDKITE_SSH_KEYSCAN",
    # A unique string that identifies a step.
    "BUILDKITE_STEP_ID",
    # The value of the key command step attribute, a unique string set by you to identify a step.
    "BUILDKITE_STEP_KEY",
    # The name of the tag being built, if this build was triggered from a tag.
    "BUILDKITE_TAG",
    # The number of minutes until Buildkite automatically cancels this job, if a timeout has been specified, otherwise it false if no timeout is set.
    "BUILDKITE_TIMEOUT",
    # Set to "datadog" to send metrics to the Datadog APM using localhost:8126, or DD_AGENT_HOST:DD_AGENT_APM_PORT.
    "BUILDKITE_TRACING_BACKEND",
    # The UUID of the build that triggered this build. This will be empty if the build was not triggered from another build.
    "BUILDKITE_TRIGGERED_FROM_BUILD_ID",
    # The number of the build that triggered this build or "" if the build was not triggered from another build.
    "BUILDKITE_TRIGGERED_FROM_BUILD_NUMBER",
    # The slug of the pipeline that was used to trigger this build or "" if the build was not triggered from another build.
    "BUILDKITE_TRIGGERED_FROM_BUILD_PIPELINE_SLUG",
    # The name of the user who unblocked the build.
    "BUILDKITE_UNBLOCKER",
    # The notification email of the user who unblocked the build.
    "BUILDKITE_UNBLOCKER_EMAIL",
    # The UUID of the user who unblocked the build.
    "BUILDKITE_UNBLOCKER_ID",
    # A colon separated list of non-private team slugs that the user who unblocked the build belongs to.
    "BUILDKITE_UNBLOCKER_TEAMS",
    # Always true in a Buildkite job
    "CI",
]

# ########################
# ##### GIT REPO PREP
# ########################


def _setup_git_repo(repo_path: Path) -> None:
    """Set up the git repository for change detection. This is a no-op if the repo is already set up."""
    with pushd(repo_path):
        # Mark directory as safe for git (needed on CI where the Docker container
        # user differs from the repo owner). Uses check=False because $HOME may
        # not be set in some CI environments, causing git config --global to fail.
        cwd = str(repo_path)
        existing = subprocess.run(
            ["git", "config", "--global", "--get-all", "safe.directory"],
            capture_output=True,
            text=True,
            check=False,
        )
        if cwd not in existing.stdout.splitlines():
            subprocess.run(
                ["git", "config", "--global", "--add", "safe.directory", cwd],
                check=False,
            )

        if _is_master_branch(os.environ.get("BUILDKITE_BRANCH", "")):
            # On master we diff HEAD^...HEAD, so ensure the parent commit is
            # present locally. Buildkite's default shallow clone may not include it.
            has_parent = (
                subprocess.run(
                    ["git", "rev-parse", "--verify", "HEAD^"],
                    capture_output=True,
                    check=False,
                ).returncode
                == 0
            )
            if not has_parent:
                subprocess.run(["git", "fetch", "--deepen=1"], check=True)
        else:
            # Only fetch if origin/master doesn't exist locally (e.g. shallow clone on CI).
            # Avoids a slow network call when running locally or in tests.
            has_origin_master = (
                subprocess.run(
                    ["git", "rev-parse", "--verify", "origin/master"],
                    capture_output=True,
                    check=False,
                ).returncode
                == 0
            )
            if not has_origin_master:
                subprocess.run(["git", "fetch", "origin", "master"], check=True)


# ########################
# ##### CHANGED FILES
# ########################


def _discover_changed_files(repo_path: Path) -> frozenset[Path]:
    """Shared logic for loading changed files from git."""
    with pushd(repo_path):
        # On master, diff against the previous commit so that file-change-gated
        # steps (e.g. utility docker image builds) actually run on merges to
        # master. On other branches, diff against origin/master.
        base_ref = (
            "HEAD^"
            if _is_master_branch(os.environ.get("BUILDKITE_BRANCH", ""))
            else "origin/master"
        )
        base = _get_commit(base_ref)
        head = _get_commit("HEAD")
        logging.info(f"Changed files between {base_ref} ({base}) and HEAD ({head}):")

        try:
            result = subprocess.run(
                [
                    "git",
                    "diff",
                    f"{base_ref}...HEAD",
                    "--name-only",
                    "--relative",
                    "--",
                    ".",
                ],
                capture_output=True,
                text=True,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            sys.stderr.write(
                f"git diff failed (exit {e.returncode}); stderr:\n{e.stderr}\nstdout:\n{e.stdout}\n"
            )
            raise

        all_files: set[Path] = set()
        for path in sorted(result.stdout.strip().split("\n")):
            if path:
                logging.info("  - " + path)
                all_files.add(Path(path))

    return frozenset(all_files)


def _get_commit(rev: str) -> str:
    return subprocess.run(
        ["git", "rev-parse", "--short", rev],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()


# ########################
# ##### PYTHON PACKAGES
# ########################


class PythonPackage:
    def __init__(self, directory: Path, project: dict[str, Any]):
        self.directory = directory
        # Use the directory basename for package name since project["name"] is
        # not unique and sometimes does not mtach.
        self.name = directory.name.replace("_", "-")
        all_deps = set(_parse_requirements(project.get("dependencies", [])))
        for extra_reqs in project.get("optional_dependencies", {}).values():
            all_deps.update(_parse_requirements(extra_reqs))
        self.dependencies = all_deps

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"PythonPackage({self.name})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PythonPackage):
            return NotImplemented
        return self.directory == other.directory

    # Because we define __eq__
    # https://docs.python.org/3.1/reference/datamodel.html#object.__hash__
    def __hash__(self) -> int:
        return hash(self.directory)

    def __lt__(self, other: "PythonPackage") -> bool:
        return self.name < other.name


def _parse_requirements(lines: list[str]) -> list[Requirement]:
    return [
        Requirement(line) for line in lines if line.strip() and not line.strip().startswith("#")
    ]


def discover_python_packages(repo_path: Path) -> list[PythonPackage]:
    """Discover all Python packages in the git repository."""
    logging.info("Finding Python packages:")

    output = subprocess.check_output(
        ["git", "ls-files", "**/tox.ini"],
        cwd=str(repo_path),
    ).decode("utf-8")

    packages = []
    for line in output.strip().split("\n"):
        if not line:
            continue
        pkg_path = (repo_path / line).parent

        if (pyproject_path := pkg_path / "pyproject.toml").exists():
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
            project = data.get("project")
            if not project:
                continue
        else:
            # create a synthetic pyproject.toml project entry with empty
            # dependencies
            project = {"name": pkg_path.name, "dependencies": [], "optional-dependencies": {}}

        packages.append(PythonPackage(pyproject_path.parent, project))

    for package in sorted(packages):
        logging.info("  - " + package.name)

    return packages


def _path_is_relative_to(p: Path, u: Path) -> bool:
    # see https://docs.python.org/3/library/pathlib.html#pathlib.PurePath.is_relative_to
    return u == p or u in p.parents


# ########################
# ##### OTHER
# ########################


def _get_required_env_var(var: str, env: Mapping[str, str]) -> str:
    if var not in env:
        raise Exception(f"Missing required environment variable: {var}")
    return env[var]


def _is_release_branch(branch: str) -> bool:
    return branch.startswith("release-")


def _is_master_branch(branch: str) -> bool:
    return branch == "master"


def _is_feature_branch(branch: str) -> bool:
    return not _is_release_branch(branch) and not _is_master_branch(branch)
