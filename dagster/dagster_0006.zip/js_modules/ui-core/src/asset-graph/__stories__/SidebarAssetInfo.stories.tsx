import {MockedProvider, MockedResponse} from '@apollo/client/testing';
import {Box} from '@dagster-io/ui-components';
import * as React from 'react';

import {createAppCache} from '../../app/AppCache';
import {buildPartitionHealthMock} from '../../assets/__fixtures__/PartitionHealthQuery.fixtures';
import {RecentAssetEventsQuery} from '../../assets/types/useRecentAssetEvents.types';
import {RECENT_ASSET_EVENTS_QUERY} from '../../assets/useRecentAssetEvents';
import {
  buildAssetLatestInfo,
  buildAssetNode,
  buildAssetResultEventHistoryConnection,
  buildCompositeConfigType,
  buildFreshnessPolicy,
  buildMaterializationEvent,
  buildObservationEvent,
  buildRegularDagsterType,
  buildRepository,
  buildRepositoryLocation,
  buildRepositoryOrigin,
  buildRun,
  buildRunNotFoundError,
  buildSolidDefinition,
} from '../../graphql/builders';
import {RunStatus} from '../../graphql/types';
import {buildQueryMock} from '../../testing/mocking';
import {SIDEBAR_ASSET_QUERY, SidebarAssetInfo} from '../SidebarAssetInfo';
import {GraphNode} from '../Utils';
import {SidebarAssetQuery} from '../types/SidebarAssetInfo.types';

// eslint-disable-next-line import/no-default-export
export default {
  title: 'Asset Graph/SidebarAssetInfo',
  component: SidebarAssetInfo,
};

const MockRepo = buildRepository({
  __typename: 'Repository',
  id: 'test.py.repo',
  name: 'test.py',
  location: buildRepositoryLocation({id: 'repo', name: 'repo'}),
});

const MockAssetKey = {__typename: 'AssetKey' as const, path: ['asset1']};

const buildGraphNodeMock = (
  definitionOverrides: Partial<ReturnType<typeof buildAssetNode>>,
): GraphNode => ({
  id: 'test.py.repo.["asset1"]',
  assetKey: MockAssetKey,
  definition: buildAssetNode({
    id: 'test.py.repo.["asset1"]',
    assetKey: MockAssetKey,
    jobNames: ['__ASSET_JOB_1'],
    opNames: ['asset1'],
    groupName: 'default',
    graphName: null,
    isPartitioned: false,
    isObservable: false,
    isMaterializable: true,
    dependedByKeys: [],
    ...definitionOverrides,
  }),
});

const buildSidebarQueryMock = (
  overrides: Partial<SidebarAssetQuery['assetNodeOrError']> = {},
): MockedResponse<SidebarAssetQuery> =>
  buildQueryMock({
    query: SIDEBAR_ASSET_QUERY,
    variables: {
      assetKey: {
        path: ['asset1'],
      },
    },
    data: {
      assetNodeOrError: buildAssetNode({
        id: 'test.py.repo.["asset1"]',
        description: null,
        // @ts-expect-error builder return type includes incomplete ConfigTypeField branches
        configField: null,
        jobNames: ['test_job'],
        assetKey: {
          path: ['asset1'],
          __typename: 'AssetKey',
        },
        // @ts-expect-error not sure why the types dont match up, investigate later
        op: buildSolidDefinition({
          name: 'asset1',
          description: null,
          metadata: [
            {
              key: 'compute_kind',
              value: 'pandas',
              __typename: 'MetadataItemDefinition',
            },
            {
              key: 'kind',
              value: 'pandas',
              __typename: 'MetadataItemDefinition',
            },
          ],
        }),
        opVersion: null,
        // @ts-expect-error not sure why the types dont match up, investigate later
        repository: MockRepo,
        requiredResources: [
          {
            __typename: 'ResourceRequirement',
            resourceKey: 'foobar',
          },
          {
            __typename: 'ResourceRequirement',
            resourceKey: 'barbaz',
          },
          {
            __typename: 'ResourceRequirement',
            resourceKey: 'FOO_BAR',
          },
          {
            __typename: 'ResourceRequirement',
            resourceKey: 'just_another_resource',
          },
        ],
        // @ts-expect-error not sure why the types dont match up, investigate later
        type: buildRegularDagsterType({
          key: 'Any',
          name: 'Any',
          displayName: 'Any',
          description: null,
          isNullable: false,
          isList: false,
          isBuiltin: true,
          isNothing: false,
          metadataEntries: [],
          inputSchemaType: buildCompositeConfigType({
            key: 'Selector.f2fe6dfdc60a1947a8f8e7cd377a012b47065bc4',
            description: null,
            isSelector: true,
            typeParamKeys: [],
            fields: [],
            recursiveConfigTypes: [],
          }),
          outputSchemaType: null,
          innerTypes: [],
        }),
        ...overrides,
      }),
    },
  });

const buildEventsMock = ({
  reported,
}: {
  reported: boolean;
}): MockedResponse<RecentAssetEventsQuery> => ({
  request: {
    query: RECENT_ASSET_EVENTS_QUERY,
    variables: {
      assetKey: {path: ['asset1']},
      before: undefined,
      limit: 100,
    },
  },
  result: {
    data: {
      __typename: 'Query',
      assetsLatestInfo: [buildAssetLatestInfo()],
      assetOrError: {
        __typename: 'Asset',
        key: MockAssetKey,
        id: '["asset1"]',
        assetEventHistory: buildAssetResultEventHistoryConnection({
          results: [
            buildMaterializationEvent({
              description: '1234',
              metadataEntries: [],
              partition: null,
              timestamp: '1234567865400',
              assetLineage: [],
              label: null,
              stepKey: 'op',
              tags: [],
              runId: reported ? '' : '12345',
              runOrError: reported
                ? buildRunNotFoundError()
                : buildRun({
                    pipelineName: '__ASSET_JOB_1',
                    mode: 'default',
                    pipelineSnapshotId: null,
                    id: '12345',
                    status: RunStatus.SUCCESS,
                    repositoryOrigin: buildRepositoryOrigin({
                      id: 'test.py',
                      repositoryLocationName: 'repo',
                      repositoryName: 'test.py',
                    }),
                  }),
            }),
            buildObservationEvent({
              description: '1234',
              runId: '12345',
              metadataEntries: [],
              partition: null,
              timestamp: '1234567865400',
              label: null,
              stepKey: 'op',
              tags: [],
              runOrError: buildRun({
                pipelineName: '__ASSET_JOB_1',
                mode: 'default',
                pipelineSnapshotId: null,
                id: '12345',
                status: RunStatus.SUCCESS,
                repositoryOrigin: buildRepositoryOrigin({
                  id: 'test.py',
                  repositoryLocationName: 'repo',
                  repositoryName: 'test.py',
                  repositoryLocationMetadata: [],
                }),
              }),
            }),
          ],
        }),
      },
    },
  },
});

const TestContainer = ({
  children,
  mocks,
}: {
  mocks?: MockedResponse<Record<string, any>>[];
  children: React.ReactNode;
}) => (
  <MockedProvider
    cache={createAppCache()}
    mocks={
      mocks || [
        buildEventsMock({reported: false}),
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        buildPartitionHealthMock(MockAssetKey.path[0]!),
        buildSidebarQueryMock(),
      ]
    }
  >
    <Box style={{width: 400}}>{children}</Box>
  </MockedProvider>
);

export const AssetWithMaterialization = () => {
  return (
    <TestContainer>
      <SidebarAssetInfo graphNode={buildGraphNodeMock({})} />
    </TestContainer>
  );
};

export const AssetWithReportedMaterialization = () => {
  return (
    <TestContainer
      mocks={[
        buildEventsMock({reported: true}),
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        buildPartitionHealthMock(MockAssetKey.path[0]!),
        buildSidebarQueryMock(),
      ]}
    >
      <SidebarAssetInfo graphNode={buildGraphNodeMock({})} />
    </TestContainer>
  );
};

export const AssetWithPolicies = () => {
  return (
    <TestContainer
      mocks={[
        buildEventsMock({reported: false}),
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        buildPartitionHealthMock(MockAssetKey.path[0]!),
        buildSidebarQueryMock({
          freshnessPolicy: buildFreshnessPolicy({
            maximumLagMinutes: 60,
            cronSchedule: '* 1 1 1 1',
          }),
        }),
      ]}
    >
      <SidebarAssetInfo graphNode={buildGraphNodeMock({})} />
    </TestContainer>
  );
};

export const AssetWithGraphName = () => {
  return (
    <TestContainer>
      <SidebarAssetInfo graphNode={buildGraphNodeMock({graphName: 'op_graph'})} />
    </TestContainer>
  );
};

export const AssetWithAssetChecks = () => {
  return (
    <TestContainer>
      <SidebarAssetInfo graphNode={buildGraphNodeMock({})} />
    </TestContainer>
  );
};

export const AssetWithDifferentOpName = () => {
  return (
    <TestContainer>
      <SidebarAssetInfo graphNode={buildGraphNodeMock({opNames: ['not_asset_name']})} />
    </TestContainer>
  );
};

export const ObservableSourceAsset = () => {
  return (
    <TestContainer>
      <SidebarAssetInfo
        graphNode={buildGraphNodeMock({isObservable: true, isMaterializable: false})}
      />
    </TestContainer>
  );
};
