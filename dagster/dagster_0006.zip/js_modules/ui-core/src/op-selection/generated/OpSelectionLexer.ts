// Generated from dagster-oss/js_modules/ui-core/src/op-selection/OpSelection.g4 by ANTLR 4.13.1

import * as antlr from 'antlr4ng';
import {Token} from 'antlr4ng';

export class OpSelectionLexer extends antlr.Lexer {
  public static readonly AND = 1;
  public static readonly OR = 2;
  public static readonly NOT = 3;
  public static readonly STAR = 4;
  public static readonly PLUS = 5;
  public static readonly DIGITS = 6;
  public static readonly COLON = 7;
  public static readonly LPAREN = 8;
  public static readonly RPAREN = 9;
  public static readonly NAME = 10;
  public static readonly SINKS = 11;
  public static readonly ROOTS = 12;
  public static readonly QUOTED_STRING = 13;
  public static readonly UNQUOTED_STRING = 14;
  public static readonly UNQUOTED_WILDCARD_STRING = 15;
  public static readonly WS = 16;

  public static readonly channelNames = ['DEFAULT_TOKEN_CHANNEL', 'HIDDEN'];

  public static readonly literalNames = [
    null,
    null,
    null,
    null,
    "'*'",
    "'+'",
    null,
    "':'",
    "'('",
    "')'",
    "'name'",
    "'sinks'",
    "'roots'",
  ];

  public static readonly symbolicNames = [
    null,
    'AND',
    'OR',
    'NOT',
    'STAR',
    'PLUS',
    'DIGITS',
    'COLON',
    'LPAREN',
    'RPAREN',
    'NAME',
    'SINKS',
    'ROOTS',
    'QUOTED_STRING',
    'UNQUOTED_STRING',
    'UNQUOTED_WILDCARD_STRING',
    'WS',
  ];

  public static readonly modeNames = ['DEFAULT_MODE'];

  public static readonly ruleNames = [
    'AND',
    'OR',
    'NOT',
    'STAR',
    'PLUS',
    'DIGITS',
    'COLON',
    'LPAREN',
    'RPAREN',
    'NAME',
    'SINKS',
    'ROOTS',
    'QUOTED_STRING',
    'UNQUOTED_STRING',
    'UNQUOTED_WILDCARD_STRING',
    'WS',
  ];

  public constructor(input: antlr.CharStream) {
    super(input);
    this.interpreter = new antlr.LexerATNSimulator(
      this,
      OpSelectionLexer._ATN,
      OpSelectionLexer.decisionsToDFA,
      new antlr.PredictionContextCache(),
    );
  }

  public get grammarFileName(): string {
    return 'OpSelection.g4';
  }

  public get literalNames(): (string | null)[] {
    return OpSelectionLexer.literalNames;
  }
  public get symbolicNames(): (string | null)[] {
    return OpSelectionLexer.symbolicNames;
  }
  public get ruleNames(): string[] {
    return OpSelectionLexer.ruleNames;
  }

  public get serializedATN(): number[] {
    return OpSelectionLexer._serializedATN;
  }

  public get channelNames(): string[] {
    return OpSelectionLexer.channelNames;
  }

  public get modeNames(): string[] {
    return OpSelectionLexer.modeNames;
  }

  public static readonly _serializedATN: number[] = [
    4, 0, 16, 117, 6, -1, 2, 0, 7, 0, 2, 1, 7, 1, 2, 2, 7, 2, 2, 3, 7, 3, 2, 4, 7, 4, 2, 5, 7, 5, 2,
    6, 7, 6, 2, 7, 7, 7, 2, 8, 7, 8, 2, 9, 7, 9, 2, 10, 7, 10, 2, 11, 7, 11, 2, 12, 7, 12, 2, 13, 7,
    13, 2, 14, 7, 14, 2, 15, 7, 15, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 3, 0, 40, 8, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 3, 1, 46, 8, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 3, 2, 54, 8, 2, 1, 3, 1, 3, 1,
    4, 1, 4, 1, 5, 4, 5, 61, 8, 5, 11, 5, 12, 5, 62, 1, 6, 1, 6, 1, 7, 1, 7, 1, 8, 1, 8, 1, 9, 1, 9,
    1, 9, 1, 9, 1, 9, 1, 10, 1, 10, 1, 10, 1, 10, 1, 10, 1, 10, 1, 11, 1, 11, 1, 11, 1, 11, 1, 11,
    1, 11, 1, 12, 1, 12, 5, 12, 90, 8, 12, 10, 12, 12, 12, 93, 9, 12, 1, 12, 1, 12, 1, 13, 1, 13, 5,
    13, 99, 8, 13, 10, 13, 12, 13, 102, 9, 13, 1, 14, 1, 14, 5, 14, 106, 8, 14, 10, 14, 12, 14, 109,
    9, 14, 1, 15, 4, 15, 112, 8, 15, 11, 15, 12, 15, 113, 1, 15, 1, 15, 0, 0, 16, 1, 1, 3, 2, 5, 3,
    7, 4, 9, 5, 11, 6, 13, 7, 15, 8, 17, 9, 19, 10, 21, 11, 23, 12, 25, 13, 27, 14, 29, 15, 31, 16,
    1, 0, 7, 1, 0, 48, 57, 4, 0, 10, 10, 13, 13, 34, 34, 92, 92, 3, 0, 65, 90, 95, 95, 97, 122, 4,
    0, 48, 57, 65, 90, 95, 95, 97, 122, 4, 0, 42, 42, 65, 90, 95, 95, 97, 122, 5, 0, 42, 42, 48, 57,
    65, 90, 95, 95, 97, 122, 3, 0, 9, 10, 13, 13, 32, 32, 124, 0, 1, 1, 0, 0, 0, 0, 3, 1, 0, 0, 0,
    0, 5, 1, 0, 0, 0, 0, 7, 1, 0, 0, 0, 0, 9, 1, 0, 0, 0, 0, 11, 1, 0, 0, 0, 0, 13, 1, 0, 0, 0, 0,
    15, 1, 0, 0, 0, 0, 17, 1, 0, 0, 0, 0, 19, 1, 0, 0, 0, 0, 21, 1, 0, 0, 0, 0, 23, 1, 0, 0, 0, 0,
    25, 1, 0, 0, 0, 0, 27, 1, 0, 0, 0, 0, 29, 1, 0, 0, 0, 0, 31, 1, 0, 0, 0, 1, 39, 1, 0, 0, 0, 3,
    45, 1, 0, 0, 0, 5, 53, 1, 0, 0, 0, 7, 55, 1, 0, 0, 0, 9, 57, 1, 0, 0, 0, 11, 60, 1, 0, 0, 0, 13,
    64, 1, 0, 0, 0, 15, 66, 1, 0, 0, 0, 17, 68, 1, 0, 0, 0, 19, 70, 1, 0, 0, 0, 21, 75, 1, 0, 0, 0,
    23, 81, 1, 0, 0, 0, 25, 87, 1, 0, 0, 0, 27, 96, 1, 0, 0, 0, 29, 103, 1, 0, 0, 0, 31, 111, 1, 0,
    0, 0, 33, 34, 5, 97, 0, 0, 34, 35, 5, 110, 0, 0, 35, 40, 5, 100, 0, 0, 36, 37, 5, 65, 0, 0, 37,
    38, 5, 78, 0, 0, 38, 40, 5, 68, 0, 0, 39, 33, 1, 0, 0, 0, 39, 36, 1, 0, 0, 0, 40, 2, 1, 0, 0, 0,
    41, 42, 5, 111, 0, 0, 42, 46, 5, 114, 0, 0, 43, 44, 5, 79, 0, 0, 44, 46, 5, 82, 0, 0, 45, 41, 1,
    0, 0, 0, 45, 43, 1, 0, 0, 0, 46, 4, 1, 0, 0, 0, 47, 48, 5, 110, 0, 0, 48, 49, 5, 111, 0, 0, 49,
    54, 5, 116, 0, 0, 50, 51, 5, 78, 0, 0, 51, 52, 5, 79, 0, 0, 52, 54, 5, 84, 0, 0, 53, 47, 1, 0,
    0, 0, 53, 50, 1, 0, 0, 0, 54, 6, 1, 0, 0, 0, 55, 56, 5, 42, 0, 0, 56, 8, 1, 0, 0, 0, 57, 58, 5,
    43, 0, 0, 58, 10, 1, 0, 0, 0, 59, 61, 7, 0, 0, 0, 60, 59, 1, 0, 0, 0, 61, 62, 1, 0, 0, 0, 62,
    60, 1, 0, 0, 0, 62, 63, 1, 0, 0, 0, 63, 12, 1, 0, 0, 0, 64, 65, 5, 58, 0, 0, 65, 14, 1, 0, 0, 0,
    66, 67, 5, 40, 0, 0, 67, 16, 1, 0, 0, 0, 68, 69, 5, 41, 0, 0, 69, 18, 1, 0, 0, 0, 70, 71, 5,
    110, 0, 0, 71, 72, 5, 97, 0, 0, 72, 73, 5, 109, 0, 0, 73, 74, 5, 101, 0, 0, 74, 20, 1, 0, 0, 0,
    75, 76, 5, 115, 0, 0, 76, 77, 5, 105, 0, 0, 77, 78, 5, 110, 0, 0, 78, 79, 5, 107, 0, 0, 79, 80,
    5, 115, 0, 0, 80, 22, 1, 0, 0, 0, 81, 82, 5, 114, 0, 0, 82, 83, 5, 111, 0, 0, 83, 84, 5, 111, 0,
    0, 84, 85, 5, 116, 0, 0, 85, 86, 5, 115, 0, 0, 86, 24, 1, 0, 0, 0, 87, 91, 5, 34, 0, 0, 88, 90,
    8, 1, 0, 0, 89, 88, 1, 0, 0, 0, 90, 93, 1, 0, 0, 0, 91, 89, 1, 0, 0, 0, 91, 92, 1, 0, 0, 0, 92,
    94, 1, 0, 0, 0, 93, 91, 1, 0, 0, 0, 94, 95, 5, 34, 0, 0, 95, 26, 1, 0, 0, 0, 96, 100, 7, 2, 0,
    0, 97, 99, 7, 3, 0, 0, 98, 97, 1, 0, 0, 0, 99, 102, 1, 0, 0, 0, 100, 98, 1, 0, 0, 0, 100, 101,
    1, 0, 0, 0, 101, 28, 1, 0, 0, 0, 102, 100, 1, 0, 0, 0, 103, 107, 7, 4, 0, 0, 104, 106, 7, 5, 0,
    0, 105, 104, 1, 0, 0, 0, 106, 109, 1, 0, 0, 0, 107, 105, 1, 0, 0, 0, 107, 108, 1, 0, 0, 0, 108,
    30, 1, 0, 0, 0, 109, 107, 1, 0, 0, 0, 110, 112, 7, 6, 0, 0, 111, 110, 1, 0, 0, 0, 112, 113, 1,
    0, 0, 0, 113, 111, 1, 0, 0, 0, 113, 114, 1, 0, 0, 0, 114, 115, 1, 0, 0, 0, 115, 116, 6, 15, 0,
    0, 116, 32, 1, 0, 0, 0, 9, 0, 39, 45, 53, 62, 91, 100, 107, 113, 1, 6, 0, 0,
  ];

  private static __ATN: antlr.ATN;
  public static get _ATN(): antlr.ATN {
    if (!OpSelectionLexer.__ATN) {
      OpSelectionLexer.__ATN = new antlr.ATNDeserializer().deserialize(
        OpSelectionLexer._serializedATN,
      );
    }

    return OpSelectionLexer.__ATN;
  }

  private static readonly vocabulary = new antlr.Vocabulary(
    OpSelectionLexer.literalNames,
    OpSelectionLexer.symbolicNames,
    [],
  );

  public override get vocabulary(): antlr.Vocabulary {
    return OpSelectionLexer.vocabulary;
  }

  private static readonly decisionsToDFA = OpSelectionLexer._ATN.decisionToState.map(
    (ds: antlr.DecisionState, index: number) => new antlr.DFA(ds, index),
  );
}
