import {
  Box,
  Colors,
  Heading,
  HoverButton,
  Icon,
  IconName,
  Intent,
  Popover,
  Skeleton,
  Tag,
  Text,
  ifPlural,
} from '@dagster-io/ui-components';
import {assetHealthEnabled} from '@shared/app/assetHealthEnabled';
import React, {useCallback, useMemo} from 'react';
import {Link} from 'react-router-dom';

import {assetDetailsPathForKey} from './assetDetailsPathForKey';
import {useAllAssetsNodes} from './useAllAssets';
import {assertUnreachable} from '../app/Util';
import {useTrackEvent} from '../app/analytics';
import {useAssetHealthData} from '../asset-data/AssetHealthDataProvider';
import {
  AssetHealthCheckDegradedMetaFragment,
  AssetHealthCheckUnknownMetaFragment,
  AssetHealthCheckWarningMetaFragment,
  AssetHealthFragment,
  AssetHealthFreshnessMetaFragment,
  AssetHealthMaterializationDegradedNotPartitionedMetaFragment,
  AssetHealthMaterializationDegradedPartitionedMetaFragment,
  AssetHealthMaterializationHealthyPartitionedMetaFragment,
  AssetHealthMaterializationWarningNotPartitionedMetaFragment,
  AssetHealthMaterializationWarningPartitionedMetaFragment,
} from '../asset-data/types/AssetHealthDataProvider.types';
import {StatusCase} from '../asset-graph/AssetNodeStatusContent';
import {tokenForAssetKey} from '../asset-graph/Utils';
import {StatusCaseDot} from '../asset-graph/sidebar/util';
import {AssetHealthStatus, AssetKeyInput} from '../graphql/types';
import {TimeFromNow} from '../ui/TimeFromNow';
import {numberFormatter} from '../ui/formatters';

export const AssetHealthSummary = React.memo(
  ({assetKey, iconOnly}: {assetKey: {path: string[]}; iconOnly?: boolean}) => {
    if (!assetHealthEnabled()) {
      return null;
    }

    return <AssetHealthSummaryImpl assetKey={assetKey} iconOnly={iconOnly} />;
  },
);

const AssetHealthSummaryImpl = React.memo(
  ({assetKey, iconOnly}: {assetKey: {path: string[]}; iconOnly?: boolean}) => {
    const {liveData} = useAssetHealthData(assetKey);
    const health = liveData?.assetHealth;

    const {iconName, iconColor, intent, text} = useMemo(() => {
      return statusToIconAndColor[health?.assetHealth ?? 'undefined'];
    }, [health]);

    function content() {
      if (iconOnly) {
        return (
          <HoverButton style={{padding: 8}}>
            <Icon name={iconName} color={iconColor} />
          </HoverButton>
        );
      }
      return (
        <Tag intent={intent} icon={iconName}>
          {text}
        </Tag>
      );
    }

    if (!liveData) {
      if (iconOnly) {
        return (
          <div style={{padding: 11}}>
            <StatusCaseDot statusCase={StatusCase.LOADING} />
          </div>
        );
      }
      return <Skeleton $width={iconOnly ? 16 : 60} $height={16} />;
    }

    return (
      <AssetHealthSummaryPopover assetKey={assetKey} health={health}>
        {content()}
      </AssetHealthSummaryPopover>
    );
  },
);

export const AssetHealthSummaryPopover = ({
  health,
  assetKey,
  children,
}: {
  health: AssetHealthFragment['assetHealth'] | undefined;
  assetKey: AssetKeyInput;
  children: React.ReactNode;
}) => {
  const {iconName, iconColor, text} = useMemo(() => {
    return statusToIconAndColor[health?.assetHealth ?? 'undefined'];
  }, [health]);

  const {allAssetKeys, loading} = useAllAssetsNodes();

  function content() {
    if (!loading && !allAssetKeys.has(tokenForAssetKey(assetKey))) {
      // This asset is not in the workspace.
      return <Criteria assetKey={assetKey} status={health?.assetHealth} type="no-definition" />;
    }
    return (
      <>
        <Criteria
          assetKey={assetKey}
          status={health?.materializationStatus}
          metadata={health?.materializationStatusMetadata}
          type="materialization"
        />
        <Criteria
          assetKey={assetKey}
          status={health?.freshnessStatus}
          metadata={health?.freshnessStatusMetadata}
          type="freshness"
        />
        <Criteria
          assetKey={assetKey}
          status={health?.assetChecksStatus}
          metadata={health?.assetChecksStatusMetadata}
          type="checks"
        />
      </>
    );
  }

  return (
    <Popover
      interactionKind="hover"
      content={
        <div onClick={(e) => e.stopPropagation()}>
          <Box padding={12} flex={{direction: 'row', alignItems: 'center', gap: 6}} border="bottom">
            <Icon name={iconName} color={iconColor} />
            <Heading size={16} weight={500}>
              {text}
            </Heading>
          </Box>
          {content()}
        </div>
      }
    >
      <div>{children}</div>
    </Popover>
  );
};

const Criteria = React.memo(
  ({
    status,
    metadata,
    type,
    assetKey,
  }: {
    assetKey: {path: string[]};
    status: AssetHealthStatus | undefined;
    metadata?:
      | AssetHealthCheckDegradedMetaFragment
      | AssetHealthCheckWarningMetaFragment
      | AssetHealthCheckUnknownMetaFragment
      | AssetHealthMaterializationDegradedNotPartitionedMetaFragment
      | AssetHealthMaterializationDegradedPartitionedMetaFragment
      | AssetHealthMaterializationHealthyPartitionedMetaFragment
      | AssetHealthMaterializationWarningNotPartitionedMetaFragment
      | AssetHealthMaterializationWarningPartitionedMetaFragment
      | AssetHealthFreshnessMetaFragment
      | undefined
      | null;
    type: 'materialization' | 'freshness' | 'checks' | 'no-definition';
  }) => {
    const {subStatusIconName, iconColor, textColor} = statusToIconAndColor[status ?? 'undefined'];

    const trackEvent = useTrackEvent();
    const onClick = useCallback(
      (name: string) => () => {
        trackEvent('asset-health-summary-click', {name});
      },
      [trackEvent],
    );

    const derivedExplanation = useMemo(() => {
      if (type === 'no-definition') {
        return (
          <Text size={14}>
            It may have been deleted or be a stub imported through an integration.
          </Text>
        );
      }

      switch (metadata?.__typename) {
        case 'AssetHealthCheckUnknownMeta':
          if (metadata.numNotExecutedChecks > 0) {
            return (
              <Text size={14}>
                <Link
                  to={assetDetailsPathForKey(assetKey, {view: 'checks'})}
                  onClick={onClick('checks-unknown')}
                >
                  {numberFormatter.format(metadata.numNotExecutedChecks)} /{' '}
                  {numberFormatter.format(metadata.totalNumChecks)} check
                  {ifPlural(metadata.totalNumChecks, '', 's')} not executed
                </Link>
              </Text>
            );
          }
          return 'No checks executed';
        case 'AssetHealthCheckDegradedMeta':
          if (metadata.numWarningChecks > 0 && metadata.numFailedChecks > 0) {
            return (
              <Text size={14}>
                <Link
                  to={assetDetailsPathForKey(assetKey, {view: 'checks'})}
                  onClick={onClick('checks-degraded-all')}
                >
                  {numberFormatter.format(metadata.numWarningChecks)}/
                  {numberFormatter.format(metadata.totalNumChecks)} check
                  {ifPlural(metadata.totalNumChecks, '', 's')} warning,{' '}
                  {numberFormatter.format(metadata.numFailedChecks)}/
                  {numberFormatter.format(metadata.totalNumChecks)} check
                  {ifPlural(metadata.totalNumChecks, '', 's')} failed
                </Link>
              </Text>
            );
          }
          if (metadata.numWarningChecks > 0) {
            return (
              <Text size={14}>
                <Link
                  to={assetDetailsPathForKey(assetKey, {view: 'checks'})}
                  onClick={onClick('checks-degraded-warning')}
                >
                  {numberFormatter.format(metadata.numWarningChecks)}/
                  {numberFormatter.format(metadata.totalNumChecks)} check
                  {ifPlural(metadata.totalNumChecks, '', 's')} warning
                </Link>
              </Text>
            );
          }
          return (
            <Text size={14}>
              <Link
                to={assetDetailsPathForKey(assetKey, {view: 'checks'})}
                onClick={onClick('checks-degraded-failed')}
              >
                {numberFormatter.format(metadata.numFailedChecks)}/
                {numberFormatter.format(metadata.totalNumChecks)} check
                {ifPlural(metadata.totalNumChecks, '', 's')} failed
              </Link>
            </Text>
          );
        case 'AssetHealthCheckWarningMeta':
          return (
            <Text size={14}>
              <Link
                to={assetDetailsPathForKey(assetKey, {view: 'checks'})}
                onClick={onClick('checks-warning')}
              >
                {numberFormatter.format(metadata.numWarningChecks)}/
                {numberFormatter.format(metadata.totalNumChecks)} check
                {ifPlural(metadata.totalNumChecks, '', 's')} warning
              </Link>
            </Text>
          );
        case 'AssetHealthMaterializationDegradedNotPartitionedMeta':
          const toReturn = metadata.failedRunId ? (
            <Text size={14}>
              <Link
                to={`/runs/${metadata.failedRunId}`}
                onClick={onClick('materialization-degraded-not-partitioned')}
              >
                Materialization failed in run {metadata.failedRunId.split('-').shift()}
              </Link>
            </Text>
          ) : null;
          return toReturn;
        case 'AssetHealthMaterializationDegradedPartitionedMeta':
          return (
            <Text size={14}>
              <Link
                to={assetDetailsPathForKey(assetKey, {view: 'partitions', status: 'FAILED'})}
                onClick={onClick('degraded-partitioned')}
              >
                Materialization failed in {numberFormatter.format(metadata.numFailedPartitions)} out
                of {numberFormatter.format(metadata.totalNumPartitions)} partition
                {ifPlural(metadata.totalNumPartitions, '', 's')}
              </Link>
            </Text>
          );
        case 'AssetHealthMaterializationHealthyPartitionedMeta':
          return (
            <Text size={14}>
              <Link
                to={assetDetailsPathForKey(assetKey, {view: 'partitions', status: 'MISSING'})}
                onClick={onClick('healthy-missing-partitioned')}
              >
                Materialization missing in {numberFormatter.format(metadata.numMissingPartitions)}{' '}
                out of {numberFormatter.format(metadata.totalNumPartitions)} partition
                {ifPlural(metadata.totalNumPartitions, '', 's')}
              </Link>
            </Text>
          );
        case 'AssetHealthMaterializationWarningNotPartitionedMeta':
          return metadata.failedRunId ? (
            <Text size={14}>
              <Link
                to={`/runs/${metadata.failedRunId}`}
                onClick={onClick('materialization-warning-not-partitioned')}
              >
                Materialization failed in run {metadata.failedRunId.split('-').shift()}, retry
                pending
              </Link>
            </Text>
          ) : null;
        case 'AssetHealthMaterializationWarningPartitionedMeta':
          return (
            <Text size={14}>
              <Link
                to={assetDetailsPathForKey(assetKey, {view: 'partitions', status: 'FAILED'})}
                onClick={onClick('warning-partitioned')}
              >
                Materialization failed in {numberFormatter.format(metadata.numUpForRetryPartitions)}{' '}
                out of {numberFormatter.format(metadata.totalNumPartitions)} partition
                {ifPlural(metadata.totalNumPartitions, '', 's')}, retries pending
              </Link>
            </Text>
          );
        case 'AssetHealthFreshnessMeta':
          if (metadata.lastMaterializedTimestamp === null) {
            return <Text size={14}>No materializations</Text>;
          }

          return (
            <Text size={14}>
              Last successfully materialized{' '}
              <TimeFromNow unixTimestamp={Number(metadata.lastMaterializedTimestamp)} />
            </Text>
          );
        case undefined:
          return null;
        default:
          // The metadata union can gain members on the server before a deployed bundle knows
          // about them; render no detail line rather than throwing.
          return null;
      }
    }, [type, metadata, assetKey, onClick]);

    const {text, shouldDim} = useMemo(() => {
      switch (type) {
        case 'materialization':
          switch (status) {
            case AssetHealthStatus.DEGRADED:
              return {text: 'Execution failed', shouldDim: false};
            case AssetHealthStatus.HEALTHY:
              return {text: 'Successfully executed', shouldDim: false};
            case AssetHealthStatus.WARNING:
              return {text: 'Execution warning', shouldDim: false};
            case undefined:
            case AssetHealthStatus.NOT_APPLICABLE:
              return {text: 'No executions', shouldDim: true};
            case AssetHealthStatus.UNKNOWN:
              return {text: 'Execution status unknown', shouldDim: true};
            default:
              assertUnreachable(status);
          }
        case 'freshness':
          switch (status) {
            case AssetHealthStatus.HEALTHY:
              return {text: 'Freshness policy passing', shouldDim: false};
            case AssetHealthStatus.DEGRADED:
              return {text: 'Freshness policy failed', shouldDim: false};
            case AssetHealthStatus.WARNING:
              return {text: 'Freshness policy warning', shouldDim: false};
            case undefined:
            case AssetHealthStatus.NOT_APPLICABLE:
              return {text: 'No freshness policy defined', shouldDim: true};
            case AssetHealthStatus.UNKNOWN:
              return {text: 'Freshness policy not evaluated', shouldDim: false};
            default:
              assertUnreachable(status);
          }
        case 'checks':
          switch (status) {
            case AssetHealthStatus.HEALTHY:
              return {text: 'All checks passed', shouldDim: false};
            case AssetHealthStatus.DEGRADED:
              if (metadata && 'numFailedChecks' in metadata && 'totalNumChecks' in metadata) {
                if (metadata.numFailedChecks === metadata.totalNumChecks) {
                  return {text: 'All checks failed', shouldDim: false};
                }
                return {text: 'Some checks failed', shouldDim: false};
              }
              return {text: 'Checks failed', shouldDim: false};
            case AssetHealthStatus.WARNING:
              if (metadata && 'numWarningChecks' in metadata && 'totalNumChecks' in metadata) {
                if (metadata.numWarningChecks === metadata.totalNumChecks) {
                  return {text: 'All checks failed', shouldDim: false};
                }
              }
              return {text: 'Some checks failed', shouldDim: false};
            case undefined:
            case AssetHealthStatus.NOT_APPLICABLE:
              return {text: 'No checks defined', shouldDim: true};
            case AssetHealthStatus.UNKNOWN:
              return {text: 'No checks evaluated', shouldDim: false};
            default:
              assertUnreachable(status);
          }
        case 'no-definition':
          return {
            text: `Missing software definition`,
            shouldDim: false,
          };
      }
    }, [type, status, metadata]);

    return (
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '20px 1fr',
          columnGap: 6,
          rowGap: 2,
          padding: '4px 12px',
          alignItems: 'center',
          opacity: shouldDim ? 0.5 : 1,
          maxWidth: 300,
        }}
      >
        <Icon name={subStatusIconName} color={iconColor} style={{paddingTop: 2}} />
        <Text size={14} style={{color: textColor}}>
          {text}
        </Text>
        <div />
        <Text size={14} color="textLight">
          {derivedExplanation}
        </Text>
      </div>
    );
  },
);

export type AssetHealthStatusString = 'Unknown' | 'Degraded' | 'Warning' | 'Healthy' | 'No data';

export const STATUS_INFO: Record<
  AssetHealthStatusString | 'Not Applicable',
  {
    iconName: IconName;
    iconName2: IconName;
    subStatusIconName: IconName;
    iconColor: string;
    textColor: string;
    borderColor: string;
    text: AssetHealthStatusString;
    intent: Intent;
    backgroundColor: string;
    hoverBackgroundColor: string;
    text2: string;
    materializationText: string;
  }
> = {
  'Not Applicable': {
    iconName: 'status',
    iconName2: 'missing',
    iconColor: Colors.textLight(),
    textColor: Colors.textDefault(),
    text: 'Unknown',
    text2: 'None set',
    materializationText: 'Not applicable',
    intent: 'none',
    subStatusIconName: 'missing',
    borderColor: Colors.accentGray(),
    backgroundColor: Colors.backgroundGray(),
    hoverBackgroundColor: Colors.backgroundGrayHover(),
  },
  Unknown: {
    iconName: 'status',
    iconName2: 'missing',
    iconColor: Colors.textLight(),
    textColor: Colors.textDefault(),
    text: 'Unknown',
    text2: 'Not evaluated',
    intent: 'none',
    materializationText: 'Never materialized',
    subStatusIconName: 'missing',
    borderColor: Colors.accentGray(),
    backgroundColor: Colors.backgroundGray(),
    hoverBackgroundColor: Colors.backgroundGrayHover(),
  },
  'No data': {
    iconName: 'status',
    iconName2: 'missing',
    iconColor: Colors.textLight(),
    textColor: Colors.textDefault(),
    text: 'No data',
    text2: 'No data',
    intent: 'none',
    materializationText: 'Never materialized',
    subStatusIconName: 'missing',
    borderColor: Colors.accentGray(),
    backgroundColor: Colors.backgroundGray(),
    hoverBackgroundColor: Colors.backgroundGrayHover(),
  },
  Degraded: {
    iconName: 'failure_trend',
    iconName2: 'cancel',
    subStatusIconName: 'close',
    materializationText: 'Failed',
    iconColor: Colors.accentRed(),
    textColor: Colors.textRed(),
    text: 'Degraded',
    text2: 'Failed',
    intent: 'danger',
    borderColor: Colors.accentRed(),
    backgroundColor: Colors.backgroundRed(),
    hoverBackgroundColor: Colors.backgroundRedHover(),
  },
  Warning: {
    iconName: 'warning_trend',
    iconName2: 'warning_outline',
    materializationText: 'Not applicable',
    subStatusIconName: 'warning_outline',
    iconColor: Colors.accentYellow(),
    text: 'Warning',
    text2: 'Warning',
    textColor: Colors.textYellow(),
    borderColor: Colors.accentYellow(),
    backgroundColor: Colors.backgroundYellow(),
    hoverBackgroundColor: Colors.backgroundYellowHover(),
    intent: 'warning',
  },
  Healthy: {
    iconName: 'successful_trend',
    iconName2: 'check_circle',
    subStatusIconName: 'done',
    materializationText: 'Success',
    iconColor: Colors.accentGreen(),
    textColor: Colors.textDefault(),
    text: 'Healthy',
    text2: 'Passing',
    intent: 'success',
    borderColor: Colors.accentGreen(),
    backgroundColor: Colors.backgroundGreen(),
    hoverBackgroundColor: Colors.backgroundGreenHover(),
  },
};

export const statusToIconAndColor: Record<
  AssetHealthStatus | 'undefined',
  (typeof STATUS_INFO)[keyof typeof STATUS_INFO]
> = {
  // Callers pass 'undefined' when `health?.assetHealth` is missing
  // (feature gate off, asset not in workspace, or not found in query).
  // We show this as "No data" so that it is distinct + debuggable.
  //
  // `AssetHealthStatus.UNKNOWN` means the backend evaluated the asset and determined it has never
  // been materialized or observed - a distinct, more informative state.
  //
  ['undefined']: STATUS_INFO['No data'],
  [AssetHealthStatus.NOT_APPLICABLE]: STATUS_INFO['Not Applicable'],
  [AssetHealthStatus.UNKNOWN]: STATUS_INFO.Unknown,
  [AssetHealthStatus.DEGRADED]: STATUS_INFO.Degraded,
  [AssetHealthStatus.HEALTHY]: STATUS_INFO.Healthy,
  [AssetHealthStatus.WARNING]: STATUS_INFO.Warning,
};
