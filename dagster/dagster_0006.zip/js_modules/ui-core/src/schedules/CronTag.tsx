import {MetadataTable, Tag, Text, Tooltip} from '@dagster-io/ui-components';
import {useContext} from 'react';

import styles from './css/CronTag.module.css';
import {hourOffsetFromUTC} from './hourOffsetFromUTC';
import {humanCronString} from './humanCronString';
import {TimeContext} from '../app/time/TimeContext';

interface Props {
  cronSchedule: string;
  executionTimezone: string | null;
}

export const CronTag = (props: Props) => {
  const {cronSchedule, executionTimezone} = props;
  const {withHumanTimezone, withExecutionTimezone} = useCronInformation(
    cronSchedule,
    executionTimezone,
  );

  const tooltipContent = (
    <MetadataTable
      rows={[
        {
          key: 'Cron value',
          value: (
            <Text size={12} family="mono">
              {cronSchedule}
            </Text>
          ),
        },
        {key: 'Your time', value: <span>{withHumanTimezone}</span>},
      ]}
    />
  );

  return (
    <div className={styles.container}>
      <Tooltip content={tooltipContent} placement="top">
        <Tag icon="schedule">{withExecutionTimezone}</Tag>
      </Tooltip>
    </div>
  );
};

export const useCronInformation = (
  cronSchedule: string | null,
  executionTimezone: string | null,
) => {
  const {resolvedTimezone} = useContext(TimeContext);

  if (!cronSchedule) {
    return {
      withHumanTimezone: null,
      withExecutionTimezone: null,
    };
  }

  const longTimezoneName = executionTimezone || 'UTC';
  const humanStringWithExecutionTimezone = humanCronString(cronSchedule, {longTimezoneName});
  const userTimezone = resolvedTimezone;

  const userTimezoneOffset = hourOffsetFromUTC(userTimezone);
  const executionTimezoneOffset = hourOffsetFromUTC(longTimezoneName);
  const tzOffset = userTimezoneOffset - executionTimezoneOffset;

  const humanStringWithUserTimezone = humanCronString(cronSchedule, {
    longTimezoneName: userTimezone,
    tzOffset,
  });

  return {
    withHumanTimezone: humanStringWithUserTimezone,
    withExecutionTimezone: humanStringWithExecutionTimezone,
  };
};
