import {AbstractParseTreeVisitor, CharStream, CommonTokenStream} from 'antlr4ng';

import {AssetSelectionLexer} from './generated/AssetSelectionLexer';
import {
  AssetSelectionParser,
  AutomationTypeAttributeExprContext,
  ScheduleAttributeExprContext,
  SensorAttributeExprContext,
  StatusAttributeExprContext,
} from './generated/AssetSelectionParser';
import {AssetSelectionVisitor} from './generated/AssetSelectionVisitor';
import {AntlrInputErrorListener} from './parseAssetSelectionQuery';
import {getValue} from './util';

export type Filter =
  | {field: 'status'; value: string}
  | {field: 'automation_type'; value: string}
  | {field: 'sensor'; value: string}
  | {field: 'schedule'; value: string};

export class AssetSelectionSupplementaryDataVisitor
  extends AbstractParseTreeVisitor<void>
  implements AssetSelectionVisitor<void>
{
  public filters: Filter[] = [];

  constructor() {
    super();
  }

  protected defaultResult() {}

  visitStatusAttributeExpr(ctx: StatusAttributeExprContext) {
    const value: string = getValue(ctx.value()).toUpperCase();
    this.filters.push({field: 'status', value});
  }

  visitAutomationTypeAttributeExpr(ctx: AutomationTypeAttributeExprContext) {
    const value: string = getValue(ctx.value());
    this.filters.push({field: 'automation_type', value});
  }

  visitSensorAttributeExpr(ctx: SensorAttributeExprContext) {
    const value: string = getValue(ctx.value());
    this.filters.push({field: 'sensor', value});
  }

  visitScheduleAttributeExpr(ctx: ScheduleAttributeExprContext) {
    const value: string = getValue(ctx.value());
    this.filters.push({field: 'schedule', value});
  }
}

export const parseExpression = (expression: string) => {
  if (expression === '') {
    return [];
  }

  const inputStream = CharStream.fromString(expression);
  const lexer = new AssetSelectionLexer(inputStream);
  lexer.removeErrorListeners();
  lexer.addErrorListener(new AntlrInputErrorListener());

  const tokenStream = new CommonTokenStream(lexer);
  tokenStream.fill(); // Ensure all tokens are loaded before parsing

  const parser = new AssetSelectionParser(tokenStream);
  parser.removeErrorListeners();
  parser.addErrorListener(new AntlrInputErrorListener());

  const tree = parser.start();
  const visitor = new AssetSelectionSupplementaryDataVisitor();
  tree.accept(visitor);
  return visitor.filters;
};
