import dagster as dg

from snowflake_medallion.definitions import defs


def test_definitions_load():
    assert isinstance(defs, dg.Definitions)


def test_resources_exist():
    repo = defs.get_repository_def()
    resources = set(repo.get_top_level_resources().keys())
    assert "snowflake" in resources
    assert "dbt" in resources
