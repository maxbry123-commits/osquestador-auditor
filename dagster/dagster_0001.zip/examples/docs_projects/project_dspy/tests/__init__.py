"""Tests for DSPy pipeline."""
