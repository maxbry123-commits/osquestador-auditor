import json
import re
import readline
import subprocess
import sys
import termios
import tty
from collections import defaultdict
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, replace
from functools import cached_property
from pathlib import Path
from time import sleep

import click
import git
import requests
from rich import box
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn
from rich.table import Table
from rich.text import Text

console = Console()

# Repository Configuration
# =======================
# After merging the separate dagster (OSS) and internal repositories:
# - dagster-oss is now a subdirectory of the internal repository
# - Both OSS and internal code live in the same git repository
# - Commits are classified as "dagster" (OSS) or "internal" based on which files they touch
#   (dagster-oss/* paths = "dagster", other paths = "internal")
GITHUB_URL = "https://github.com/dagster-io"
OSS_ROOT = Path(__file__).parent.parent  # Points to dagster-oss directory
REPO = git.Repo(OSS_ROOT.parent)  # Git root is one level up (internal repo root)
OSS_REPO = REPO
INTERNAL_REPO = REPO
CHANGELOG_PATH = OSS_ROOT / "CHANGES.md"
INTERNAL_DEFAULT_STR = "If a changelog entry is required"

CHANGELOG_HEADER = "## Changelog"
IGNORE_TOKEN = "NOCHANGELOG"

# Category order for display
CATEGORY_ORDER = [
    "New",
    "Bugfixes",
    "Documentation",
    "Dagster Plus",
]

# Internal author names (use for internal contributors with varying or non-standard email)
INTERNAL_AUTHOR_NAMES = [
    "cmpadden",
    "Joe Braha",
    "Ben Gotow",
    "Isaac Hellendag",
    "Sean Mackesey",
    "Dennis Hume",
]


@dataclass
class Author:
    name: str
    email: str

    def __str__(self) -> str:
        return f"{self.name} ({self.email})"

    @property
    def is_external(self) -> bool:
        # Check if email is from internal domain
        if any(domain in self.email for domain in ["elementl.com", "dagsterlabs.com"]):
            return False

        # Check if name is in internal authors list
        if self.name in INTERNAL_AUTHOR_NAMES:
            return False

        # Check if GitHub username (extracted from noreply email) is in internal authors list
        if self.email and "@users.noreply.github.com" in self.email:
            email_part = self.email.split("@")[0]
            if "+" in email_part:
                github_username = email_part.split("+")[1]
            else:
                github_username = email_part
            if github_username in INTERNAL_AUTHOR_NAMES:
                return False

        return True


@dataclass
class ParsedCommit:
    issue_number: str
    is_community_contribution: bool
    changelog_category: str
    changelog_entry: str | None
    title: str
    authors: list[Author]
    repo_name: str
    prefix: str | None  # Library prefix like [dagster-dbt], [ui], etc.
    ignore: bool
    commit_hash: str = ""  # Git commit SHA
    synced_from_oss: bool = False  # True if commit was synced from dagster-io/dagster

    @property
    def pr_url(self) -> str:
        # Synced OSS commits should link to the original dagster repo
        if self.synced_from_oss:
            return f"{GITHUB_URL}/dagster/pull/{self.issue_number}"
        return f"{GITHUB_URL}/internal/pull/{self.issue_number}"

    @property
    def documented(self) -> bool:
        return bool(self.changelog_entry)

    @property
    def primary_author(self) -> Author:
        # Get first external author if exists, else first author
        # This way community PRs are always credited to the external contributor
        return self.first_external_author or self.authors[0]

    @cached_property
    def first_external_author(self) -> Author | None:
        for author in self.authors:
            if author.is_external:
                return author
        return None

    @cached_property
    def github_pr_author_username(self) -> str | None:
        """Extract GitHub username from commit author email, name, or PR webpage."""
        # Check if email is a GitHub noreply email
        if self.primary_author.email and "@users.noreply.github.com" in self.primary_author.email:
            email_part = self.primary_author.email.split("@")[0]

            # Handle numeric format (12345+username@users.noreply.github.com)
            if "+" in email_part:
                return email_part.split("+")[1]  # "username"

            # Handle simple format (username@users.noreply.github.com)
            return email_part

        # Last resort: try to fetch from the PR webpage
        # Extract the URL from the markdown link [#123](https://github.com/...)
        return _fetch_github_username_from_pr(self.pr_url)


def _clean_changelog_entry(text: str) -> str:
    """Clean up changelog entry by removing leading characters and whitespace."""
    if not text:
        return text

    # Strip whitespace
    text = text.strip()

    # Remove common leading characters people add
    prefixes_to_remove = ["> ", "- ", "* ", "+ "]
    for prefix in prefixes_to_remove:
        if text.startswith(prefix):
            text = text[len(prefix) :].strip()
            break

    # Strip co-authored-by that is auto-inserted by Github at the end of commit messages
    text = re.sub(r"Co-authored-by:.*", "", text)

    return text


def _needs_period_fix(entry: str | None) -> bool:
    """Check if changelog entry needs a period added at the end."""
    if not entry or entry == "<UNDOCUMENTED>":
        return False
    # Strip trailing whitespace and check if it ends with common punctuation
    stripped = entry.rstrip()
    if not stripped:
        return False
    # Allow period, exclamation, question mark, or closing paren/bracket as valid endings
    return stripped[-1] not in ".!?)]"


def _extract_prefix_from_text(text: str) -> tuple[str | None, str]:
    """Extract library prefix from changelog text and return (prefix, cleaned_text).

    Examples:
        "[dagster-dbt] Fixed issue" -> ("dagster-dbt", "Fixed issue")
        "[ui] Updated interface" -> ("ui", "Updated interface")
        "Regular entry" -> (None, "Regular entry")
    """
    if not text:
        return None, text

    # Look for prefix pattern at the start: [something]
    match = re.match(r"^\[([^\]]+)\]\s*(.*)", text.strip())
    if match:
        prefix = match.group(1)
        remaining_text = match.group(2)
        return prefix, remaining_text

    return None, text


def _is_valid_prefix(prefix: str | None) -> bool:
    """Check if prefix is valid: None, 'ui', or 'dagster-*'."""
    if prefix is None:
        return True
    if prefix == "ui":
        return True
    if prefix.startswith("dagster-"):
        return True
    return False


def _fetch_github_username_from_pr(pr_url: str) -> str | None:
    """Fetch GitHub username from PR using GitHub API."""
    try:
        # Parse PR URL to extract owner, repo, and PR number
        # Expected format: https://github.com/owner/repo/pull/123
        # Use regex to ensure github.com is the hostname, not just anywhere in the URL
        if not re.match(r"https?://(?:www\.)?github\.com/", pr_url):
            return None
        url_parts = pr_url.split("/")
        if len(url_parts) >= 6:
            owner = url_parts[-4]  # dagster-io
            repo = url_parts[-3]  # dagster
            pr_number = url_parts[-1]  # 123

            # Use GitHub API to get PR info
            api_url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"

            # Add a small delay to be respectful to GitHub API
            sleep(0.1)

            response = requests.get(api_url, timeout=10)
            response.raise_for_status()

            pr_data = response.json()
            username = pr_data.get("user", {}).get("login")

            if username and 3 <= len(username) <= 39:
                return username

    except Exception:
        # Silently fail - we'll fall back to "could not parse"
        pass

    return None


def _fetch_pr_body(pr_url: str) -> str | None:
    """Fetch PR body/description from GitHub API."""
    try:
        if not re.match(r"https?://(?:www\.)?github\.com/", pr_url):
            return None
        url_parts = pr_url.split("/")
        if len(url_parts) >= 6:
            owner = url_parts[-4]
            repo = url_parts[-3]
            pr_number = url_parts[-1]

            api_url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"
            sleep(0.1)

            response = requests.get(api_url, timeout=10)
            response.raise_for_status()

            pr_data = response.json()
            body = pr_data.get("body", "")

            # Truncate very long bodies to avoid token limits
            if body and len(body) > 3000:
                body = body[:3000] + "\n... (truncated)"

            return body

    except Exception:
        pass

    return None


def _get_previous_version(new_version: str) -> str:
    split = new_version.split(".")
    previous_patch = int(split[-1]) - 1
    assert previous_patch >= 0, "Must explicitly set `previous_version` on major releases."
    return ".".join([*split[:-1], str(previous_patch)])


def _get_libraries_version(new_version: str) -> str:
    split = new_version.split(".")
    new_minor = int(split[1]) + 16
    return ".".join(["0", str(new_minor), split[2]])


def _get_repo_name(commit: git.Commit) -> str:
    """Determine if commit belongs to OSS (dagster) or internal repo for categorization.

    After repo merge, we determine this by checking which files the commit touched.
    If any file is under dagster-oss/, it's considered an OSS commit.

    Note: This is used for changelog categorization (e.g., Dagster Plus category),
    not for PR URLs - all PR URLs now point to the internal repo.
    """
    # Check files touched by this commit
    for file_path in commit.stats.files.keys():
        if str(file_path).startswith("dagster-oss/"):
            return "dagster"

    # If no dagster-oss files were touched, it's an internal commit
    return "internal"


def _get_parsed_commit(commit: git.Commit) -> ParsedCommit:
    """Extracts a set of useful information from the raw commit message."""
    commit_message = str(commit.message)
    title = commit_message.splitlines()[0].strip()
    # me avoiding regex -- titles are formatted as "Lorem ipsum ... (#12345)" so we can just search
    # for the last octothorpe and chop off the closing paren
    repo_name = _get_repo_name(commit)
    issue_number = title.split("#")[-1][:-1]

    # Check if this commit was synced from the OSS dagster repo
    synced_from_oss = "Synced-From-Dagster" in commit_message

    # Extract original author if this is a synced commit
    original_author: Author | None = None
    if synced_from_oss:
        # Look for ORIGINAL_AUTHOR=Name <email> pattern
        match = re.search(r"ORIGINAL_AUTHOR=(.+?) <(.+?)>", commit_message)
        if match:
            original_author = Author(name=match.group(1), email=match.group(2))

    # find the first line that has `CHANGELOG` in the first few characters, then take the next
    # non-empty line
    found_start = False
    ignore = False
    raw_changelog_entry_lines: list[str] = []
    has_testing_section = "## How I Tested These Changes" in commit_message

    for line in commit_message.split("\n"):
        if found_start and line.strip():
            if line.startswith(IGNORE_TOKEN):
                ignore = True
                break
            if INTERNAL_DEFAULT_STR in line:
                # ignore changelog entry if it has not been updated
                raw_changelog_entry_lines = []
                break
            # Stop collecting when we hit sync metadata from OSS repo
            if line.startswith(("ORIGINAL_AUTHOR=", "Synced-From-Dagster", "GitOrigin-RevId:")):
                break
            # Just collect the changelog entry text, ignore category checkboxes
            # Match only actual checkboxes like "- [x]", "- [X]", "- [ ]", not prefixes like "- [dagster]"
            if not re.match(r"^- \[[xX ]\]", line):
                raw_changelog_entry_lines.append(line.strip())
        if line.startswith(CHANGELOG_HEADER):
            found_start = True

    # If there's a "How I Tested These Changes" section but no changelog content, ignore this commit
    if has_testing_section and not raw_changelog_entry_lines:
        ignore = True

    raw_changelog_entry = " ".join(raw_changelog_entry_lines)

    # If changelog entry contains the placeholder text, ignore this commit
    if "Insert changelog entry or delete this section" in raw_changelog_entry:
        ignore = True

    # Clean and extract prefix from changelog entry
    cleaned_entry = None
    detected_prefix = None
    if raw_changelog_entry:
        cleaned_entry = _clean_changelog_entry(raw_changelog_entry)
        detected_prefix, cleaned_entry = _extract_prefix_from_text(cleaned_entry)

    # Simple UI detection
    if not detected_prefix:
        text_to_check = f"{title} {raw_changelog_entry or ''}".lower()
        if any(
            word in text_to_check for word in ["ui", "webserver", "frontend", "react", "graphql"]
        ):
            detected_prefix = "ui"

    # For synced commits, use the original author if available
    if synced_from_oss and original_author:
        authors = [original_author]
    else:
        authors = [
            Author(
                name=str(author.name),
                email=str(author.email),
            )
            for author in [commit.author, *commit.co_authors]
        ]

    # Create the commit object first
    parsed_commit = ParsedCommit(
        issue_number=issue_number,
        is_community_contribution=any(author.is_external for author in authors),
        changelog_category="New",  # Will be set by guessing logic
        changelog_entry=cleaned_entry,
        title=title,
        authors=authors,
        repo_name=repo_name,
        prefix=detected_prefix,
        ignore=ignore,
        commit_hash=commit.hexsha,
        synced_from_oss=synced_from_oss,
    )

    # Use guessing logic to determine category
    guessed_category = _guess_category(parsed_commit)
    return replace(parsed_commit, changelog_category=guessed_category)


def _get_documented_section(documented: Sequence[ParsedCommit]) -> str:
    """Generate documented section without PR links or GitHub profiles (for internal repo changes)."""
    grouped_commits: Mapping[str, list[ParsedCommit]] = defaultdict(list)
    for commit in documented:
        grouped_commits[commit.changelog_category].append(commit)

    documented_text = ""

    for category in CATEGORY_ORDER:
        category_commits = grouped_commits.get(category, [])
        if not category_commits:
            continue  # Skip empty categories

        # Sort commits within category by prefix
        category_commits.sort(key=_prefix_sort_key)

        documented_text += f"\n\n### {category}\n"
        for commit in category_commits:
            entry = commit.changelog_entry or commit.title

            # Add prefix if present
            if commit.prefix:
                entry = f"[{commit.prefix}] {entry}"

            documented_text += f"\n- {entry}"
    return documented_text


def _get_commits(
    repos: Sequence[git.Repo], new_version: str, prev_version: str
) -> Iterator[ParsedCommit]:
    # After repo merge, OSS and INTERNAL repos are the same
    # Use a set to track seen commits and avoid duplicates
    seen_commits = set()
    for repo in repos:
        for commit in repo.iter_commits(rev=f"release-{prev_version}..release-{new_version}"):
            commit_sha = commit.hexsha
            if commit_sha not in seen_commits:
                seen_commits.add(commit_sha)
                yield _get_parsed_commit(commit)


def _colored(text: str, color: str) -> str:
    """Helper to create Rich Text with color."""
    return f"[{color}]{text}[/{color}]"


def _create_commit_display(
    commit: ParsedCommit,
    index: int,
    total: int,
    should_thank: bool,
    is_discarded: bool = False,
    feedback_message: str = "",
) -> Panel:
    """Create a renderable display for commit information using Rich formatting."""
    # Create and display progress bar
    progress = Progress(
        TextColumn("[bold blue]Progress:"),
        BarColumn(bar_width=40),
        MofNCompleteColumn(),
        TextColumn("commits"),
    )
    progress.add_task("Processing", completed=index, total=total)

    # Create header
    header = Text(f"Commit {index}/{total}", style="bold blue")

    # Create main info table
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Field", style="cyan", min_width=15)
    table.add_column("Value", style="white")

    # Add commit info
    table.add_row("PR Link:", commit.pr_url)
    table.add_row(
        "Community Contribution:",
        _colored("YES", "green") if commit.is_community_contribution else _colored("NO", "red"),
    )
    table.add_row("Author:", "\n".join([str(author) for author in commit.authors]))
    table.add_row("Title:", commit.title)
    table.add_row("Category:", f"[yellow]{commit.changelog_category}[/yellow]")
    table.add_row(
        "Prefix:", f"[cyan]{commit.prefix}[/cyan]" if commit.prefix else "[dim]None[/dim]"
    )
    # Show entry with special formatting for undocumented
    entry_text = commit.changelog_entry or _colored("<UNDOCUMENTED>", "red")
    table.add_row("Entry:", entry_text)

    # GitHub username info
    if should_thank:
        pr_author = commit.github_pr_author_username
        if pr_author:
            table.add_row("GitHub PR author:", f"@{pr_author}")
            table.add_row("Thanks:", "[green]YES[/green]")
        else:
            table.add_row("GitHub:", "[dim]Could not parse[/dim]")
            table.add_row("Thanks:", "[yellow]YES (username unavailable)[/yellow]")
    else:
        table.add_row("GitHub:", "[dim]Will load if Thanks is toggled[/dim]")
        table.add_row("Thanks:", "[red]NO[/red]")

    # Determine main panel style based on discard state
    main_border_style = "yellow" if is_discarded else "blue"

    # Create proposed action panel - show what will actually happen
    is_undocumented = not commit.changelog_entry or commit.changelog_entry == "<UNDOCUMENTED>"

    if is_discarded:
        proposed_content = "[red]SKIP THIS COMMIT[/red]\n(Will not appear in changelog)"
        proposed_title = "[bold red]Proposed Action: SKIP[/bold red]"
        proposed_border = "red"
    elif is_undocumented:
        proposed_content = "[red]CANNOT ACCEPT[/red]\n[dim]Must add changelog entry first[/dim]"
        proposed_title = "[bold red]Status: UNDOCUMENTED[/bold red]"
        proposed_border = "red"
    else:
        # Category will be shown in the content

        proposed_entry = commit.changelog_entry or commit.title
        # Add prefix if present
        if commit.prefix:
            proposed_entry = f"[{commit.prefix}] {proposed_entry}"

        # Build colored proposed entry
        colored_category = f"[yellow]### {commit.changelog_category}[/yellow]"
        display_entry = proposed_entry
        if commit.prefix:
            display_entry = (
                f"[cyan]\\[{commit.prefix}][/cyan] {commit.changelog_entry or commit.title}"
            )
        if should_thank:
            username = commit.github_pr_author_username
            if username:
                display_entry += (
                    f" [magenta](Thanks, \\[@{username}](https://github.com/{username})!)[/magenta]"
                )

        proposed_content = (
            f"[green]ADD TO CHANGELOG:[/green]\n\n{colored_category}\n\n- {display_entry}"
        )
        proposed_title = "[bold green]Proposed Entry[/bold green]"
        proposed_border = "green"

    # Show proposed action in a sub-panel
    proposed_panel = Panel(
        proposed_content,
        title=proposed_title,
        border_style=proposed_border,
        padding=(1, 2),
    )

    # Display controls - Enter behavior depends on state
    controls = Text("\nControls: ")
    if is_undocumented and not is_discarded:
        controls.append("[Enter]", style="bold red")
        controls.append(" Cannot Accept  ")
    else:
        controls.append("[Enter]", style="bold green")
        if is_discarded:
            controls.append(" Execute (Skip)  ")
        else:
            controls.append(" Execute (Add)  ")
    controls.append("[c]", style="bold yellow")
    controls.append(" Cycle category  ")
    controls.append("[p]", style="bold cyan")
    controls.append(" Edit prefix  ")
    controls.append("[e]", style="bold green")
    controls.append(" Edit text  ")
    controls.append("[g]", style="bold bright_blue")
    controls.append(" AI generate  ")
    controls.append("[o]", style="bold blue")
    controls.append(" Open PR  ")
    controls.append("[t]", style="bold magenta")
    controls.append(" Toggle thanks  ")
    controls.append("[d]", style="bold red")
    controls.append(" Toggle discard  ")
    controls.append("[q]", style="bold white")
    controls.append(" Quit")

    # Combine all components into a single panel
    main_content = Table(show_header=False, box=None, padding=0)
    main_content.add_column(justify="left")

    # Add progress bar FIRST
    main_content.add_row(progress)
    main_content.add_row("")  # spacing

    # Always add feedback area after progress bar
    feedback_text = feedback_message if feedback_message else "Ready for action"
    feedback_panel = Panel(
        Text(feedback_text, style="bold" if feedback_message else "dim"),
        title="Message",
        border_style="blue",
        padding=(0, 1),
    )
    main_content.add_row(feedback_panel)
    main_content.add_row("")  # spacing

    # Add main info table
    main_content.add_row(Panel(table, title=header, border_style=main_border_style))
    main_content.add_row("")  # spacing

    # Add proposed action panel
    main_content.add_row(proposed_panel)

    # Add controls
    main_content.add_row(controls)

    return Panel(main_content, box=box.SQUARE, padding=(1, 2))


def _cycle_category(current_category: str, is_internal_repo: bool = False) -> str:
    """Cycle to the next category in the list."""
    if is_internal_repo:
        categories = ["New", "Bugfixes", "Documentation", "Dagster Plus"]
    else:
        categories = ["New", "Bugfixes", "Documentation"]

    try:
        current_index = categories.index(current_category)
        next_index = (current_index + 1) % len(categories)
        return categories[next_index]
    except ValueError:
        # If current category not found, default to first one
        return categories[0]


def _get_edited_entry_interactive(current_entry: str) -> str | None:
    """Get user's edited changelog entry with simple prompt."""

    def pre_input_hook():
        readline.insert_text(current_entry)
        readline.redisplay()

    readline.set_pre_input_hook(pre_input_hook)
    try:
        new_entry = input("Edit entry: ")
        return new_entry.strip() if new_entry.strip() else None
    finally:
        readline.set_pre_input_hook(None)


def _update_display_and_refresh(
    live, commit, i, total, should_thank, is_discarded, feedback_message
):
    """Helper to update display and refresh - reduces repetition."""
    display_panel = _create_commit_display(
        commit, i, total, should_thank, is_discarded, feedback_message
    )
    live.update(display_panel)
    live.refresh()


def _get_edited_prefix_interactive(current_prefix: str | None) -> str | None:
    """Get user's edited prefix with simple prompt."""
    current_text = current_prefix or ""

    def pre_input_hook():
        readline.insert_text(current_text)
        readline.redisplay()

    readline.set_pre_input_hook(pre_input_hook)
    try:
        new_prefix = input("Edit prefix (without brackets): ")
        return new_prefix.strip() if new_prefix.strip() else None
    finally:
        readline.set_pre_input_hook(None)


def _guess_category(commit: ParsedCommit) -> str:
    """Simple category detection based on common keywords."""
    text = (commit.changelog_entry or commit.title).lower()

    # Check for documentation keywords
    if any(word in text for word in ["doc", "guide", "tutorial"]):
        return "Documentation"

    # Check for bugfix keywords
    if any(word in text for word in ["fix", "bug", "resolved"]):
        return "Bugfixes"

    # Check for Dagster Plus (internal repo only)
    if commit.repo_name == "internal":
        return "Dagster Plus"

    # Default to New
    return "New"


@dataclass
class AIChangelogSuggestion:
    """AI-generated suggestion for changelog entry fields."""

    description: str
    category: str  # "New", "Bugfixes", "Documentation", "Dagster Plus"
    prefix: str | None  # e.g., "dagster-dbt", "ui", or None
    should_thank: bool
    should_skip: bool
    reasoning: str


def _get_commit_diff(commit_hash: str, max_lines: int = 200) -> str:
    """Get the git diff for a commit, truncated to max_lines."""
    try:
        result = subprocess.run(
            ["git", "show", "--stat", "--patch", commit_hash],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=OSS_ROOT.parent,  # Run from repo root
            check=False,
        )
        if result.returncode == 0 and result.stdout:
            lines = result.stdout.split("\n")
            if len(lines) > max_lines:
                return (
                    "\n".join(lines[:max_lines])
                    + f"\n... (truncated, {len(lines) - max_lines} more lines)"
                )
            return result.stdout
    except Exception:
        pass
    return "(could not fetch diff)"


def _generate_changelog_with_ai(commit: ParsedCommit) -> AIChangelogSuggestion | None:
    """Use Claude CLI to generate changelog entry fields for a commit."""
    # Fetch PR body from GitHub
    pr_body = _fetch_pr_body(commit.pr_url) or "(could not fetch)"

    # Get git diff for the commit
    git_diff = _get_commit_diff(commit.commit_hash)

    # Build the prompt with commit information
    prompt = f"""You are helping generate a changelog entry for a software release. Analyze this commit and suggest the appropriate changelog fields.

## Commit Information
- **PR Title:** {commit.title}
- **PR URL:** {commit.pr_url}
- **Commit Hash:** {commit.commit_hash}
- **Author:** {commit.primary_author.name} ({commit.primary_author.email})
- **Is External Contributor:** {commit.is_community_contribution}
- **Current Entry (if any):** {commit.changelog_entry or "(none)"}
- **Repository Type:** {commit.repo_name} (dagster = open source, internal = Dagster Plus)

## PR Description
{pr_body}

## Code Changes (git diff)
```
{git_diff}
```

## Guidelines
1. **Description**: Write a concise, user-focused changelog entry (1-2 sentences). Start with a verb (Added, Fixed, Improved, etc.). End with a period. Focus on what changed for users, not implementation details.

2. **Category**: Choose exactly one:
   - "New" - New features or capabilities
   - "Bugfixes" - Bug fixes
   - "Documentation" - Documentation changes
   - "Dagster Plus" - Changes specific to Dagster Plus (only for internal repo commits)

3. **Prefix**: If the change is specific to a library or component, include a prefix:
   - Use "ui" for frontend/UI changes
   - Use "dagster-XXX" for library-specific changes (e.g., "dagster-dbt", "dagster-aws")
   - Use null/None if the change is general

4. **should_thank**: Set to true if this is a community contribution (external contributor) that deserves thanks in the changelog.

5. **should_skip**: Set to true ONLY if this commit should NOT appear in the changelog (e.g., internal refactoring, CI changes, or changes with no user-facing impact).

## Response Format
Respond with ONLY a JSON object (no markdown, no explanation outside the JSON):
{{
  "description": "The changelog entry text ending with a period.",
  "category": "New|Bugfixes|Documentation|Dagster Plus",
  "prefix": "dagster-xxx" or "ui" or null,
  "should_thank": true|false,
  "should_skip": true|false,
  "reasoning": "Brief explanation of your choices"
}}"""

    result = None
    try:
        # Call Claude CLI
        result = subprocess.run(
            [
                "claude",
                "-p",
                prompt,
                "--output-format",
                "json",
                "--model",
                "claude-3-5-haiku-latest",
            ],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )

        if result.returncode != 0:
            return None

        # Check for empty output
        if not result.stdout or not result.stdout.strip():
            return None

        # Parse the JSON response - claude outputs a JSON object with a "result" field
        response = json.loads(result.stdout)

        # Extract the actual content from Claude's response
        content = response.get("result", result.stdout)

        # Try to parse the content as JSON (Claude should return raw JSON)
        # Sometimes it might be wrapped in markdown code blocks or have text before/after
        if isinstance(content, str):
            content = content.strip()
            # First try: extract JSON from markdown code block
            code_block_match = re.search(r"```(?:json)?\s*\n([\s\S]*?)\n```", content)
            if code_block_match:
                content = code_block_match.group(1).strip()
            else:
                # Second try: find inline JSON object (text before/after the {})
                json_match = re.search(r"\{[\s\S]*\}", content)
                if json_match:
                    content = json_match.group(0)
            suggestion_data = json.loads(content)
        else:
            suggestion_data = content

        return AIChangelogSuggestion(
            description=suggestion_data.get("description", ""),
            category=suggestion_data.get("category", "New"),
            prefix=suggestion_data.get("prefix"),
            should_thank=suggestion_data.get("should_thank", False),
            should_skip=suggestion_data.get("should_skip", False),
            reasoning=suggestion_data.get("reasoning", ""),
        )

    except (subprocess.TimeoutExpired, json.JSONDecodeError, KeyError, FileNotFoundError) as e:
        console.print(f"[red]AI generation failed: {e}[/red]")
        if result is not None:
            console.print(f"[dim]Claude returncode: {result.returncode}[/dim]")
            console.print(
                f"[dim]Claude stdout: {result.stdout[:500] if result.stdout else '(empty)'}[/dim]"
            )
            console.print(
                f"[dim]Claude stderr: {result.stderr[:500] if result.stderr else '(empty)'}[/dim]"
            )
        return None


def _interactive_changelog_generation(new_version: str, prev_version: str) -> str:
    """Single-pass interactive changelog generation with keyboard shortcuts."""
    # Collect all commits first
    all_commits: list[ParsedCommit] = []
    documented_internal = []

    for commit in _get_commits([OSS_REPO, INTERNAL_REPO], new_version, prev_version):
        if commit.ignore:
            continue
        elif commit.repo_name == "internal" and commit.documented:
            documented_internal.append(commit)
        else:
            # Only include undocumented commits from OSS repo (dagster), not internal
            if not commit.documented and commit.repo_name == "dagster":
                updated_commit = replace(
                    commit,
                    changelog_category="Invalid",
                    changelog_entry="<UNDOCUMENTED>",
                    ignore=False,
                )
                all_commits.append(updated_commit)
            elif commit.documented:
                all_commits.append(commit)

    # All commits already have categories assigned by _get_parsed_commit
    processed_commits = all_commits

    # Show initial summary
    console.print(f"\n🚀 Interactive Changelog Generation for {new_version}", style="bold blue")
    console.print(f"Found {len(processed_commits)} commits to review.", style="green")
    if documented_internal:
        console.print(
            f"Found {len(documented_internal)} internal repo commits (auto-included).", style="blue"
        )
    console.print("Use keyboard shortcuts to quickly modify each commit\n", style="cyan")

    final_commits = []

    # Create single persistent Live display
    current_commit = processed_commits[0] if processed_commits else None

    if not processed_commits or not current_commit:
        return "No commits to process."

    # Initial setup for first commit
    should_thank = current_commit.is_community_contribution
    is_discarded = not current_commit.changelog_entry
    feedback_message = ""

    # Create initial display
    display_panel = _create_commit_display(
        current_commit, 1, len(processed_commits), should_thank, is_discarded, feedback_message
    )

    try:
        with Live(display_panel, auto_refresh=False, console=console, screen=False) as live:
            i = 1
            commit = current_commit
            while i <= len(processed_commits):
                commit = processed_commits[i - 1]  # Convert to 0-based index

                # Setup commit state
                should_thank = commit.is_community_contribution
                is_discarded = not commit.changelog_entry
                # Suggest AI generation for undocumented commits
                feedback_message = (
                    "💡 Press [g] to generate changelog entry with AI"
                    if not commit.changelog_entry
                    else ""
                )

                # Update display for current commit
                _update_display_and_refresh(
                    live,
                    commit,
                    i,
                    len(processed_commits),
                    should_thank,
                    is_discarded,
                    feedback_message,
                )

                while True:  # Allow multiple edits to same commit
                    try:
                        # Get single character input without Enter
                        old_settings = termios.tcgetattr(sys.stdin)
                        try:
                            tty.setraw(sys.stdin.fileno())
                            action = sys.stdin.read(1).lower()
                        finally:
                            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

                        # Handle escape sequences (arrow keys) - ignore them
                        if ord(action) == 27:  # ESC sequence
                            try:
                                sys.stdin.read(2)  # Discard the rest of the sequence
                            except Exception:
                                pass
                            continue

                        # Handle Enter key (carriage return)
                        if ord(action) == 13 or ord(action) == 10:
                            action = "accept"

                        if action in ("a", "accept") or ord(action) in (13, 10):
                            # Check if commit is undocumented and not discarded
                            is_undocumented = (
                                not commit.changelog_entry
                                or commit.changelog_entry == "<UNDOCUMENTED>"
                            )
                            if is_undocumented and not is_discarded:
                                feedback_message = "❌ Cannot accept undocumented commit. Please add changelog entry first or discard it."
                                _update_display_and_refresh(
                                    live,
                                    commit,
                                    i,
                                    len(processed_commits),
                                    should_thank,
                                    is_discarded,
                                    feedback_message,
                                )
                                # Continue loop to show same commit
                            elif not is_discarded:
                                # Check if entry needs period fix
                                if _needs_period_fix(commit.changelog_entry):
                                    feedback_message = (
                                        "⚠️  Entry doesn't end with a period. Add one? [y/n]"
                                    )
                                    _update_display_and_refresh(
                                        live,
                                        commit,
                                        i,
                                        len(processed_commits),
                                        should_thank,
                                        is_discarded,
                                        feedback_message,
                                    )
                                    # Get y/n response
                                    old_settings = termios.tcgetattr(sys.stdin)
                                    try:
                                        tty.setraw(sys.stdin.fileno())
                                        fix_response = sys.stdin.read(1).lower()
                                    finally:
                                        termios.tcsetattr(
                                            sys.stdin, termios.TCSADRAIN, old_settings
                                        )
                                    if fix_response == "y":
                                        # Auto-fix by adding period
                                        assert commit.changelog_entry is not None
                                        fixed_entry = commit.changelog_entry.rstrip() + "."
                                        commit = replace(commit, changelog_entry=fixed_entry)
                                        processed_commits[i - 1] = commit
                                        feedback_message = "✅ Added period, adding to changelog"
                                    else:
                                        feedback_message = "✅ Added to changelog (without period)"

                                # Add to changelog
                                final_commit = replace(
                                    commit, ignore=not should_thank
                                )  # Use ignore field to track thanks
                                final_commits.append(final_commit)
                                if not feedback_message.startswith("✅"):
                                    feedback_message = "✅ Added to changelog"
                                _update_display_and_refresh(
                                    live,
                                    commit,
                                    i,
                                    len(processed_commits),
                                    should_thank,
                                    is_discarded,
                                    feedback_message,
                                )
                                i += 1  # Move to next commit
                                break
                            else:
                                # Skip this commit
                                feedback_message = "⏭️ Skipped"
                                _update_display_and_refresh(
                                    live,
                                    commit,
                                    i,
                                    len(processed_commits),
                                    should_thank,
                                    is_discarded,
                                    feedback_message,
                                )
                                i += 1  # Move to next commit
                                break

                        elif action == "c":
                            # Cycle category
                            is_internal = commit.repo_name == "internal"
                            new_category = _cycle_category(commit.changelog_category, is_internal)

                            commit = replace(commit, changelog_category=new_category, ignore=False)
                            # Update the commit in the processed_commits list
                            processed_commits[i - 1] = commit
                            feedback_message = f"✅ Category cycled to {new_category}"

                            # Update display with new category
                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            # Continue loop to show updated commit

                        elif action == "p":
                            # Edit prefix with simple prompt
                            live.stop()
                            console.clear()
                            console.print(
                                f"\n[bold cyan]Editing Prefix for Commit {i}/{len(processed_commits)}[/bold cyan]"
                            )
                            console.print(f"Current: {commit.prefix or '(none)'}")
                            console.print()

                            new_prefix = _get_edited_prefix_interactive(commit.prefix)
                            if new_prefix != commit.prefix:
                                commit = replace(commit, prefix=new_prefix, ignore=False)
                                processed_commits[i - 1] = commit
                                prefix_display = new_prefix or "(none)"
                                feedback_message = f"✅ Prefix changed to {prefix_display}"
                            else:
                                feedback_message = (
                                    "Prefix edit cancelled"
                                    if new_prefix is None
                                    else "No changes made"
                                )

                            live.start()
                            display_panel = _create_commit_display(
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            live.update(display_panel)
                            live.refresh()

                        elif action == "e":
                            # Edit text with simple prompt
                            live.stop()
                            console.clear()
                            console.print(
                                f"\n[bold cyan]Editing Entry for Commit {i}/{len(processed_commits)}[/bold cyan]"
                            )
                            console.print(f"Current: {commit.changelog_entry or commit.title}")
                            console.print()

                            new_entry = _get_edited_entry_interactive(
                                commit.changelog_entry or commit.title
                            )
                            if new_entry and new_entry != (commit.changelog_entry or commit.title):
                                # Clean and extract prefix from new entry
                                cleaned_entry = _clean_changelog_entry(new_entry)
                                detected_prefix, cleaned_entry = _extract_prefix_from_text(
                                    cleaned_entry
                                )

                                # Only use detected prefix if it's valid
                                final_prefix = (
                                    detected_prefix
                                    if _is_valid_prefix(detected_prefix)
                                    else commit.prefix
                                )

                                commit = replace(
                                    commit,
                                    changelog_entry=cleaned_entry,
                                    prefix=final_prefix,
                                    ignore=False,
                                )
                                processed_commits[i - 1] = commit
                                feedback_message = "✅ Text updated"
                            else:
                                feedback_message = (
                                    "Text edit cancelled" if not new_entry else "No changes made"
                                )

                            live.start()
                            display_panel = _create_commit_display(
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            live.update(display_panel)
                            live.refresh()

                        elif action == "g":
                            # AI generate changelog entry
                            feedback_message = "🤖 Generating with AI..."
                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )

                            suggestion = _generate_changelog_with_ai(commit)
                            if suggestion:
                                # Apply the AI suggestions
                                commit = replace(
                                    commit,
                                    changelog_entry=suggestion.description,
                                    changelog_category=suggestion.category,
                                    prefix=suggestion.prefix,
                                    ignore=False,
                                )
                                processed_commits[i - 1] = commit
                                should_thank = suggestion.should_thank
                                is_discarded = suggestion.should_skip

                                feedback_message = f"🤖 AI suggestion applied. Reasoning: {suggestion.reasoning[:80]}..."
                            else:
                                feedback_message = "❌ AI generation failed"

                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )

                        elif action == "o":
                            # Open PR link in browser
                            import webbrowser

                            webbrowser.open(commit.pr_url)

                        elif action == "t":
                            # Toggle thanks
                            should_thank = not should_thank
                            status = "ON" if should_thank else "OFF"
                            feedback_message = f"✅ Thanks toggled {status}"
                            # Update display with new thanks status
                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            # Continue loop to show updated commit

                        elif action == "d":
                            # Toggle discard state
                            is_discarded = not is_discarded
                            if is_discarded:
                                feedback_message = "🚫 Toggled to discard mode"
                            else:
                                feedback_message = "✅ Toggled out of discard mode"
                            # Update display with new discard status
                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            # Continue loop to show updated display

                        elif action == "q":
                            feedback_message = "⚠️  Quitting early..."
                            display_panel = _create_commit_display(
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                            live.update(display_panel)
                            raise KeyboardInterrupt

                        else:
                            feedback_message = f"Unknown action: {action}. Use: [Enter]=accept, [c]=category, [p]=prefix, [e]=edit, [t]=thanks, [d]=discard, [q]=quit"
                            _update_display_and_refresh(
                                live,
                                commit,
                                i,
                                len(processed_commits),
                                should_thank,
                                is_discarded,
                                feedback_message,
                            )
                    except KeyboardInterrupt:
                        # Handle Ctrl+C gracefully
                        feedback_message = "⚠️  Interrupted by user..."
                        display_panel = _create_commit_display(
                            commit,
                            i,
                            len(processed_commits),
                            should_thank,
                            is_discarded,
                            feedback_message,
                        )
                        live.update(display_panel)
                        live.refresh()
                        raise KeyboardInterrupt

    except KeyboardInterrupt:
        console.print(
            "\n\n⚠️  Interrupted by user. Discarding all changes...",
            style="yellow",
        )
        return "No changelog generated - operation cancelled."

    # Generate final changelog
    header = f"# Changelog\n\n## {new_version} (core) / {_get_libraries_version(new_version)} (libraries)"

    console.print(
        f"\n✅ Processed {len(final_commits)} commits for final changelog.", style="bold green"
    )

    sections = []
    if final_commits:
        sections.append(_get_documented_section_with_thanks(final_commits))

    if documented_internal:
        sections.append(
            f"\n\n## Internal Repository Changes\n{_get_documented_section(documented_internal)}"
        )

    return header + "".join(sections)


def _prefix_sort_key(commit: ParsedCommit) -> tuple:
    """Sort key for commits within a category: no prefix first, then [ui], then others by reverse length."""
    if not commit.prefix:
        return (0, "")  # No prefix comes first
    elif commit.prefix == "ui":
        return (1, commit.prefix)  # [ui] comes second
    else:
        return (
            2,
            -len(commit.prefix),
            commit.prefix,
        )  # Others sorted by reverse length, then alphabetically


def _get_documented_section_with_thanks(documented: Sequence[ParsedCommit]) -> str:
    """Generate documented section with thanks integrated into commit messages."""
    grouped_commits: Mapping[str, list[ParsedCommit]] = defaultdict(list)
    for commit in documented:
        grouped_commits[commit.changelog_category].append(commit)

    documented_text = ""

    for category in CATEGORY_ORDER:
        category_commits = grouped_commits.get(category, [])
        if not category_commits:
            continue  # Skip empty categories

        # Sort commits within category by prefix
        category_commits.sort(key=_prefix_sort_key)

        documented_text += f"\n\n### {category}\n"
        for commit in category_commits:
            entry = commit.changelog_entry or commit.title

            # Add prefix if present
            if commit.prefix:
                entry = f"[{commit.prefix}] {entry}"

            # Add thanks directly to the commit message if user chose to thank
            if not commit.ignore:  # User chose to thank
                github_username = commit.github_pr_author_username
                if github_username:
                    entry += (
                        f" (Thanks, [@{github_username}](https://github.com/{github_username})!)"
                    )

            documented_text += f"\n- {entry}"
    return documented_text


@click.command()
@click.argument("new_version", type=str, required=True)
@click.argument("prev_version", type=str, required=False)
def generate_changelog(new_version: str, prev_version: str | None = None) -> None:
    if prev_version is None:
        prev_version = _get_previous_version(new_version)

    # Save the original branch to restore it later
    original_branch = REPO.active_branch.name

    try:
        # Show loading indicator during setup
        loading_text = Text("Setting up branches and parsing commits...", style="bold blue")
        with Live(loading_text, auto_refresh=True, refresh_per_second=4, console=console) as live:
            # After repo merge, only need to set up branches once
            live.update(
                Text(
                    "Checking out branches for merged repository...",
                    style="bold blue",
                )
            )
            REPO.git.checkout("master")
            REPO.git.pull()
            REPO.git.checkout(f"release-{prev_version}")
            REPO.git.pull()
            REPO.git.checkout(f"release-{new_version}")
            REPO.git.pull()
            REPO.git.checkout("master")

            live.update(
                Text("Parsing commits and preparing interactive review...", style="bold blue")
            )

        # Generate changelog in interactive mode
        try:
            new_text = _interactive_changelog_generation(new_version, prev_version)

            # Only write if generation was successful (not cancelled)
            if new_text and not new_text.startswith("No changelog generated"):
                with open(CHANGELOG_PATH, encoding="utf-8") as f:
                    current_changelog = f.read()

                new_changelog = new_text + current_changelog[1:]

                with open(CHANGELOG_PATH, "w", encoding="utf-8") as f:
                    f.write(new_changelog)

                console.print("\n🎉 Interactive changelog generation complete!", style="bold green")
                console.print(f"📝 Changelog updated in {CHANGELOG_PATH}")
            else:
                console.print(
                    "\n⚠️  Changelog generation cancelled - no changes made.", style="yellow"
                )
        except KeyboardInterrupt:
            console.print(
                "\n\n⚠️  Operation cancelled by user - no changes made to changelog.", style="yellow"
            )
    finally:
        # Always restore the original branch
        console.print(f"\n↩️  Restoring original branch: {original_branch}", style="dim")
        REPO.git.checkout(original_branch)


if __name__ == "__main__":
    generate_changelog()
