# MySQL 数据源

![mysql](../../../../img/new_ui/dev/datasource/mysql.png)

- 数据源：选择 MYSQL
- 数据源名称：输入数据源的名称
- 描述：输入数据源的描述
- IP 主机名：输入连接 MySQL 的 IP
- 端口：输入连接 MySQL 的端口
- 用户名：设置连接 MySQL 的用户名
- 密码：设置连接 MySQL 的密码
- 数据库名：输入连接 MySQL 的数据库名称
- Jdbc 连接参数：用于 MySQL 连接的参数设置，以 JSON 形式填写

## 是否原生支持

- 否，使用前需请参考 [pseudo-cluster](../installation/pseudo-cluster.md) 中的 "下载插件依赖" 章节激活数据源。
- 驱动下载链接，[mysql-connector-j-8.0.33](https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar)

