/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.dolphinscheduler.plugin.datasource.api.datasource;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

import lombok.Builder;

@Builder
public class JdbcDriverConnectionProvider implements JdbcConnectionProvider {

    private final String jdbcDriverClassName;
    private final String jdbcUrl;
    private final String username;
    private final String password;
    private final Properties properties;

    @Override
    public Connection getConnection() throws SQLException {
        try {
            Driver driver = (Driver) Class.forName(jdbcDriverClassName).getDeclaredConstructor().newInstance();
            Properties p = new Properties(properties);
            if (username != null) {
                p.setProperty("user", username);
            }
            if (password != null) {
                p.setProperty("password", password);
            }
            return driver.connect(jdbcUrl, p);
        } catch (ReflectiveOperationException e) {
            throw new SQLException("Failed to instantiate driver: " + jdbcDriverClassName, e);
        }
    }
}
