/*
 * Copyright (c) 2013, Redis Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of Redis nor the names of its contributors may be used
 *     to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "server.h"
#include "module.h"

/* This file implements keyspace events notification via Pub/Sub and
 * described at https://valkey.io/topics/notifications */

/* Turn a string representing notification classes into an integer
 * representing notification classes flags xored.
 *
 * The function returns -1 if the input contains characters not mapping to
 * any class. */
int keyspaceEventsStringToFlags(char *classes) {
    char *p = classes;
    int c, flags = 0;

    while ((c = *p++) != '\0') {
        switch (c) {
        case 'A': flags |= NOTIFY_ALL; break;
        case 'g': flags |= NOTIFY_GENERIC; break;
        case '$': flags |= NOTIFY_STRING; break;
        case 'l': flags |= NOTIFY_LIST; break;
        case 's': flags |= NOTIFY_SET; break;
        case 'h': flags |= NOTIFY_HASH; break;
        case 'z': flags |= NOTIFY_ZSET; break;
        case 'x': flags |= NOTIFY_EXPIRED; break;
        case 'e': flags |= NOTIFY_EVICTED; break;
        case 'K': flags |= NOTIFY_KEYSPACE; break;
        case 'E': flags |= NOTIFY_KEYEVENT; break;
        case 't': flags |= NOTIFY_STREAM; break;
        case 'm': flags |= NOTIFY_KEY_MISS; break;
        case 'd': flags |= NOTIFY_MODULE; break;
        case 'n': flags |= NOTIFY_NEW; break;
        default: return -1;
        }
    }
    return flags;
}

/* This function does exactly the reverse of the function above: it gets
 * as input an integer with the xored flags and returns a string representing
 * the selected classes. The string returned is an sds string that needs to
 * be released with sdsfree(). */
sds keyspaceEventsFlagsToString(int flags) {
    sds res;

    res = sdsempty();
    if ((flags & NOTIFY_ALL) == NOTIFY_ALL) {
        res = sdscatlen(res, "A", 1);
    } else {
        if (flags & NOTIFY_GENERIC) res = sdscatlen(res, "g", 1);
        if (flags & NOTIFY_STRING) res = sdscatlen(res, "$", 1);
        if (flags & NOTIFY_LIST) res = sdscatlen(res, "l", 1);
        if (flags & NOTIFY_SET) res = sdscatlen(res, "s", 1);
        if (flags & NOTIFY_HASH) res = sdscatlen(res, "h", 1);
        if (flags & NOTIFY_ZSET) res = sdscatlen(res, "z", 1);
        if (flags & NOTIFY_EXPIRED) res = sdscatlen(res, "x", 1);
        if (flags & NOTIFY_EVICTED) res = sdscatlen(res, "e", 1);
        if (flags & NOTIFY_STREAM) res = sdscatlen(res, "t", 1);
        if (flags & NOTIFY_MODULE) res = sdscatlen(res, "d", 1);
        if (flags & NOTIFY_NEW) res = sdscatlen(res, "n", 1);
    }
    if (flags & NOTIFY_KEYSPACE) res = sdscatlen(res, "K", 1);
    if (flags & NOTIFY_KEYEVENT) res = sdscatlen(res, "E", 1);
    if (flags & NOTIFY_KEY_MISS) res = sdscatlen(res, "m", 1);
    return res;
}

/* The API provided to the rest of the serer core is a simple function:
 *
 * notifyKeyspaceEvent(int type, char *event, robj *key, int dbid);
 *
 * 'type' is the notification class we define in `server.h`.
 * 'event' is a C string representing the event name.
 * 'key' is an Object representing the key name.
 * 'dbid' is the database ID where the key lives.  */
void notifyKeyspaceEvent(int type, char *event, robj *key, int dbid) {
    sds chan;
    robj *chanobj, *eventobj;
    char buf[24];
    client *c = server.executing_client;
    debugServerAssert(moduleNotifyKeyspaceSubscribersCnt() == 0 ||
                      (type & (NOTIFY_GENERIC | NOTIFY_STRING | NOTIFY_LIST | NOTIFY_SET | NOTIFY_HASH | NOTIFY_ZSET | NOTIFY_STREAM)) == 0 ||
                      c == NULL ||
                      c->cmd == NULL ||
                      (c->cmd->flags & CMD_WRITE) == 0 ||
                      c->flag.buffered_reply == 0 ||
                      c->flag.keyspace_notified == 1 ||
                      c->id == UINT64_MAX || // AOF client
                      getClientType(c) != CLIENT_TYPE_NORMAL);
    /* If any modules are interested in events, notify the module system now.
     * This bypasses the notifications configuration, but the module engine
     * will only call event subscribers if the event type matches the types
     * they are interested in. */
    moduleNotifyKeyspaceEvent(type, event, key, dbid);
    if (c) {
        c->flag.keyspace_notified = 1;
        commitDeferredReplyBuffer(c, 1);
    }

    /* If notifications for this class of events are off, return ASAP. */
    if (!(server.notify_keyspace_events & type)) return;

    /* If neither keyspace nor keyevent notifications are enabled, or there
     * are no clients subscribed to any channel or pattern, there is no point
     * in building the event object and the channel names. */
    if (!(server.notify_keyspace_events & (NOTIFY_KEYSPACE | NOTIFY_KEYEVENT))) return;
    if (serverPubsubSubscriptionCount() == 0) return;

    size_t eventlen = strlen(event);
    int len = ll2string(buf, sizeof(buf), dbid);

    /* __keyspace@<db>__:<key> <event> notifications. */
    if (server.notify_keyspace_events & NOTIFY_KEYSPACE) {
        chan = sdsnewlen(SDS_NOINIT, 11 + len + 3 + sdslen(objectGetVal(key)));
        sdsclear(chan);
        chan = sdscatlen(chan, "__keyspace@", 11);
        chan = sdscatlen(chan, buf, len);
        chan = sdscatlen(chan, "__:", 3);
        chan = sdscatsds(chan, objectGetVal(key));
        chanobj = createObject(OBJ_STRING, chan);
        eventobj = createStringObject(event, eventlen);
        pubsubPublishMessage(chanobj, eventobj, 0);
        decrRefCount(chanobj);
        decrRefCount(eventobj);
    }

    /* __keyevent@<db>__:<event> <key> notifications. */
    if (server.notify_keyspace_events & NOTIFY_KEYEVENT) {
        chan = sdsnewlen(SDS_NOINIT, 11 + len + 3 + eventlen);
        sdsclear(chan);
        chan = sdscatlen(chan, "__keyevent@", 11);
        chan = sdscatlen(chan, buf, len);
        chan = sdscatlen(chan, "__:", 3);
        chan = sdscatlen(chan, event, eventlen);
        chanobj = createObject(OBJ_STRING, chan);
        pubsubPublishMessage(chanobj, key, 0);
        decrRefCount(chanobj);
    }
}
