# Copyright (c) 2026 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any


def snake_to_camel(name: str) -> str:
    components = name.split("_")
    return components[0] + "".join(
        component.capitalize() for component in components[1:]
    )


def convert_params_to_camel(params: dict[str, Any]) -> dict[str, Any]:
    return {snake_to_camel(key): value for key, value in params.items()}
