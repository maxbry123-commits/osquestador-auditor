"""
CLI integration tests package.
"""
