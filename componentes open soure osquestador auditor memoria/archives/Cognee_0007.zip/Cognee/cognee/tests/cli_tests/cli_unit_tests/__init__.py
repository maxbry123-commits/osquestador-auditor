"""
CLI unit tests package.
"""
