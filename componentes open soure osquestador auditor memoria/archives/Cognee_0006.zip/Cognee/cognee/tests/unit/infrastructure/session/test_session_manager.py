import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from cognee.infrastructure.databases.cache.models import SessionQAEntry
from cognee.infrastructure.databases.exceptions import SessionParameterValidationError
from cognee.infrastructure.session.feedback_models import (
    AgentTraceFeedbackSummary,
    FeedbackDetectionResult,
)
from cognee.infrastructure.session.session_manager import SessionManager
from cognee.infrastructure.session.session_turn import compose_session_prompt


class TestComposeSessionPrompt:
    """Characterization tests pinning the exact prompt assembly extracted from the
    inner completion method. These must stay byte-identical to the pre-extraction
    behavior, so changing them means deliberately changing every session prompt."""

    def test_block_precedes_history(self):
        result = compose_session_prompt("BLOCK", "HISTORY")
        assert result == "BLOCK\n\nHISTORY"

    def test_history_only(self):
        assert compose_session_prompt("", "HISTORY") == "HISTORY"

    def test_empty_history_keeps_trailing_separators(self):
        # Pre-extraction behavior prepended onto a possibly-empty history, leaving a
        # trailing "\n\n" when history is empty. Preserved exactly.
        assert compose_session_prompt("BLOCK", "") == "BLOCK\n\n"

    def test_all_empty(self):
        assert compose_session_prompt("", "") == ""


class TestValidateSessionParams:
    """Tests for _validate_session_params."""

    def test_valid_params(self):
        """Valid user_id and session_id do not raise."""
        SessionManager._validate_session_params(user_id="u1", session_id="s1")
        SessionManager._validate_session_params(user_id="u1", session_id="s1", qa_id="q1")

    def test_empty_user_id_raises(self):
        """Empty user_id raises SessionParameterValidationError."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="", session_id="s1")
        assert "user_id" in exc_info.value.message

    def test_empty_session_id_raises(self):
        """Empty session_id raises SessionParameterValidationError."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="u1", session_id="")
        assert "session_id" in exc_info.value.message

    def test_whitespace_user_id_raises(self):
        """Whitespace-only user_id raises."""
        with pytest.raises(SessionParameterValidationError):
            SessionManager._validate_session_params(user_id="  ", session_id="s1")

    def test_empty_qa_id_raises(self):
        """Empty qa_id raises when provided."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="u1", session_id="s1", qa_id="")
        assert "qa_id" in exc_info.value.message

    def test_valid_last_n(self):
        """Valid last_n (positive int or None) does not raise."""
        SessionManager._validate_session_params(user_id="u1", session_id="s1", last_n=5)
        SessionManager._validate_session_params(user_id="u1", session_id="s1", last_n=1)

    def test_invalid_last_n_zero_raises(self):
        """last_n=0 raises SessionParameterValidationError."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="u1", session_id="s1", last_n=0)
        assert "last_n" in exc_info.value.message

    def test_invalid_last_n_negative_raises(self):
        """last_n negative raises."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="u1", session_id="s1", last_n=-1)
        assert "last_n" in exc_info.value.message

    def test_invalid_last_n_not_int_raises(self):
        """last_n not an int raises."""
        with pytest.raises(SessionParameterValidationError) as exc_info:
            SessionManager._validate_session_params(user_id="u1", session_id="s1", last_n="5")
        assert "last_n" in exc_info.value.message


class TestSessionManager:
    """Unit tests for SessionManager with mocked cache."""

    @pytest.fixture(autouse=True)
    def session_vector_mocks(self, monkeypatch):
        index_mock = AsyncMock()
        delete_qa_mock = AsyncMock()
        delete_session_mock = AsyncMock()
        monkeypatch.setattr(
            "cognee.infrastructure.session.session_manager.index_session_qa",
            index_mock,
        )
        monkeypatch.setattr(
            "cognee.infrastructure.session.session_manager.delete_session_qa_vector",
            delete_qa_mock,
        )
        monkeypatch.setattr(
            "cognee.infrastructure.session.session_manager.delete_session_qa_vectors",
            delete_session_mock,
        )
        monkeypatch.setattr(
            "cognee.infrastructure.session.session_turn.search_session_qa_ids",
            AsyncMock(return_value=[]),
        )
        return {
            "index": index_mock,
            "delete_qa": delete_qa_mock,
            "delete_session": delete_session_mock,
        }

    @pytest.fixture
    def mock_cache(self):
        """Mock cache engine."""
        cache = MagicMock()
        cache.create_qa_entry = AsyncMock()
        cache.get_all_qa_entries = AsyncMock(return_value=[])
        cache.get_latest_qa_entries = AsyncMock(return_value=[])
        cache.append_agent_trace_step = AsyncMock()
        cache.get_agent_trace_session = AsyncMock(return_value=[])
        cache.get_agent_trace_feedback = AsyncMock(return_value=[])
        cache.get_agent_trace_count = AsyncMock(return_value=0)
        cache.get_qa_entries_by_ids = AsyncMock(return_value=[])
        cache.update_qa_entry = AsyncMock(return_value=True)
        cache.delete_feedback = AsyncMock(return_value=True)
        cache.delete_qa_entry = AsyncMock(return_value=True)
        cache.delete_session = AsyncMock(return_value=True)
        cache.create_session_context_entry = AsyncMock(return_value=True)
        cache.get_session_context_entries = AsyncMock(return_value=[])
        cache.update_session_context_entry = AsyncMock(return_value=True)
        cache.delete_session_context = AsyncMock(return_value=True)
        return cache

    @pytest.fixture
    def sm(self, mock_cache):
        """SessionManager with mocked cache."""
        return SessionManager(cache_engine=mock_cache)

    @pytest.fixture
    def sm_unavailable(self):
        """SessionManager with no cache."""
        return SessionManager(cache_engine=None)

    def test_is_available(self, sm, sm_unavailable):
        """is_available reflects cache presence."""
        assert sm.is_available is True
        assert sm_unavailable.is_available is False

    @pytest.mark.asyncio
    async def test_add_qa_session_id_none_uses_default(self, sm, mock_cache):
        """add_qa with session_id=None uses default_session_id."""
        qa_id = await sm.add_qa(user_id="u1", question="Q", context="C", answer="A")
        assert qa_id is not None
        call_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert call_kw["session_id"] == "default_session"

    @pytest.mark.asyncio
    async def test_add_qa_returns_qa_id(self, sm, mock_cache, session_vector_mocks):
        """add_qa returns generated qa_id and calls cache."""
        used_ids = {"node_ids": ["n1"], "edge_ids": ["e1"]}
        qa_id = await sm.add_qa(
            user_id="u1",
            question="Q",
            context="C",
            answer="A",
            session_id="s1",
            used_graph_element_ids=used_ids,
        )
        assert qa_id is not None
        mock_cache.create_qa_entry.assert_called_once()
        call_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert call_kw["user_id"] == "u1"
        assert call_kw["session_id"] == "s1"
        assert call_kw["question"] == "Q"
        assert call_kw["answer"] == "A"
        assert call_kw["qa_id"] == qa_id
        assert call_kw["used_graph_element_ids"] == used_ids
        assert "embedding" not in call_kw
        session_vector_mocks["index"].assert_awaited_once_with(
            user_id="u1",
            session_id="s1",
            qa_id=qa_id,
            question="Q",
            answer="A",
        )

    @pytest.mark.asyncio
    async def test_add_qa_unavailable_returns_none(self, sm_unavailable):
        """add_qa returns None when cache unavailable."""
        assert (
            await sm_unavailable.add_qa(
                user_id="u1", question="Q", context="C", answer="A", session_id="s1"
            )
            is None
        )

    @pytest.mark.asyncio
    async def test_add_qa_invalid_params_raises(self, sm):
        """add_qa raises on invalid user_id or session_id."""
        with pytest.raises(SessionParameterValidationError):
            await sm.add_qa(user_id="", question="Q", context="C", answer="A", session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.add_qa(user_id="u1", question="Q", context="C", answer="A", session_id="")

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_session_id_none_uses_default(self, sm, mock_cache):
        """add_agent_trace_step with session_id=None uses default_session_id."""
        trace_id = await sm.add_agent_trace_step(
            user_id="u1",
            origin_function="plan_trip",
            status="success",
        )
        assert trace_id is not None
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_id"] == "default_session"

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_runs_extraction_when_enabled(
        self, sm, mock_cache, monkeypatch
    ):
        """The live agent-context extraction hook fires after the trace row is stored."""
        import cognee.infrastructure.session.agent_context_extraction as ace

        live_spy = AsyncMock(return_value=[])
        pending_spy = AsyncMock(return_value=[])
        monkeypatch.setattr(ace, "extract_live_agent_context", live_spy)
        monkeypatch.setattr(ace, "extract_pending_agent_context", pending_spy)
        monkeypatch.setattr(sm, "is_auto_feedback_enabled", lambda: True)

        trace_id = await sm.add_agent_trace_step(
            user_id="u1",
            origin_function="run_tests",
            status="error",
            session_id="s1",
            error_message="exit 1",
            generate_feedback_with_llm=False,
        )

        live_spy.assert_awaited_once()
        call_kw = live_spy.await_args.kwargs
        assert call_kw["trace_id"] == trace_id
        assert call_kw["status"] == "error"
        assert call_kw["error_message"] == "exit 1"
        assert call_kw["session_id"] == "s1"
        pending_spy.assert_awaited_once_with(
            session_manager=sm,
            user_id="u1",
            session_id="s1",
        )

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_skips_extraction_when_disabled(
        self, sm, mock_cache, monkeypatch
    ):
        """With automatic session context off, no extraction runs."""
        import cognee.infrastructure.session.agent_context_extraction as ace

        live_spy = AsyncMock(return_value=[])
        pending_spy = AsyncMock(return_value=[])
        monkeypatch.setattr(ace, "extract_live_agent_context", live_spy)
        monkeypatch.setattr(ace, "extract_pending_agent_context", pending_spy)
        monkeypatch.setattr(sm, "is_auto_feedback_enabled", lambda: False)

        await sm.add_agent_trace_step(
            user_id="u1",
            origin_function="run_tests",
            status="error",
            session_id="s1",
            error_message="exit 1",
            generate_feedback_with_llm=False,
        )

        live_spy.assert_not_awaited()
        pending_spy.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_returns_trace_id_and_feedback(self, sm, mock_cache):
        """add_agent_trace_step returns generated trace_id and persists generated feedback."""
        with (
            patch(
                "cognee.infrastructure.session.session_agent_trace.read_query_prompt",
                return_value="summarize this",
            ),
            patch(
                "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
                new_callable=AsyncMock,
                return_value=AgentTraceFeedbackSummary(
                    session_feedback="Trip plan created successfully."
                ),
            ),
        ):
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="plan_trip",
                status="success",
                session_id="s1",
                memory_query="trip preferences",
                memory_context="User likes quiet places",
                method_params={"city": "Tokyo"},
                method_return_value="Plan created",
            )
        assert trace_id is not None
        mock_cache.append_agent_trace_step.assert_called_once()
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["trace_id"] == trace_id
        assert call_kw["origin_function"] == "plan_trip"
        assert call_kw["status"] == "success"
        assert call_kw["memory_query"] == "trip preferences"
        assert call_kw["memory_context"] == "User likes quiet places"
        assert call_kw["method_params"] == {"city": "Tokyo"}
        assert call_kw["method_return_value"] == "Plan created"
        assert call_kw["session_feedback"] == "Trip plan created successfully."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_falls_back_when_summary_is_empty(self, sm, mock_cache):
        """Empty LLM summaries fall back to the deterministic feedback string."""
        with (
            patch(
                "cognee.infrastructure.session.session_agent_trace.read_query_prompt",
                return_value="summarize this",
            ),
            patch(
                "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
                new_callable=AsyncMock,
                return_value=AgentTraceFeedbackSummary(session_feedback="   "),
            ),
        ):
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="book_hotel",
                status="error",
                session_id="s1",
                method_return_value={"status": "failed"},
                error_message="No availability",
            )
        assert trace_id is not None
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "book_hotel failed. Reason: No availability."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_falls_back_when_llm_raises(self, sm, mock_cache):
        """LLM failures do not block trace writes and use deterministic fallback feedback."""
        with (
            patch(
                "cognee.infrastructure.session.session_agent_trace.read_query_prompt",
                return_value="summarize this",
            ),
            patch(
                "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
                new_callable=AsyncMock,
                side_effect=RuntimeError("llm unavailable"),
            ),
        ):
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="book_hotel",
                status="error",
                session_id="s1",
                method_return_value={"status": "failed"},
                error_message="No availability",
            )
        assert trace_id is not None
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "book_hotel failed. Reason: No availability."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_falls_back_when_prompt_missing(self, sm, mock_cache):
        """Missing trace feedback prompt uses deterministic fallback feedback."""
        with (
            patch(
                "cognee.infrastructure.session.session_agent_trace.read_query_prompt",
                return_value=None,
            ),
            patch(
                "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
                new_callable=AsyncMock,
            ) as mock_llm,
        ):
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="plan_trip",
                status="success",
                session_id="s1",
                method_return_value="Plan created",
            )

        assert trace_id is not None
        mock_llm.assert_not_awaited()
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "plan_trip succeeded."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_falls_back_when_llm_returns_wrong_type(
        self, sm, mock_cache
    ):
        """Unexpected LLM result types use deterministic fallback feedback."""
        with (
            patch(
                "cognee.infrastructure.session.session_agent_trace.read_query_prompt",
                return_value="summarize this",
            ),
            patch(
                "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
                new_callable=AsyncMock,
                return_value="not-a-model",
            ),
        ):
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="plan_trip",
                status="success",
                session_id="s1",
                method_return_value="Plan created",
            )

        assert trace_id is not None
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "plan_trip succeeded."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_method_return_value_none_uses_fallback_without_llm(
        self, sm, mock_cache
    ):
        """None return values skip LLM generation and use deterministic fallback feedback."""
        with patch(
            "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
            new_callable=AsyncMock,
        ) as mock_llm:
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="plan_trip",
                status="success",
                session_id="s1",
                method_return_value=None,
            )

        assert trace_id is not None
        mock_llm.assert_not_awaited()
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "plan_trip succeeded."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_can_disable_llm_feedback_generation(self, sm, mock_cache):
        """When disabled explicitly, trace feedback uses fallback without touching the LLM."""
        with patch(
            "cognee.infrastructure.session.session_agent_trace.LLMGateway.acreate_structured_output",
            new_callable=AsyncMock,
        ) as mock_llm:
            trace_id = await sm.add_agent_trace_step(
                user_id="u1",
                origin_function="plan_trip",
                status="success",
                session_id="s1",
                method_return_value="Plan created",
                generate_feedback_with_llm=False,
            )

        assert trace_id is not None
        mock_llm.assert_not_awaited()
        call_kw = mock_cache.append_agent_trace_step.call_args.kwargs
        assert call_kw["session_feedback"] == "plan_trip succeeded."

    @pytest.mark.asyncio
    async def test_add_agent_trace_step_unavailable_returns_none(self, sm_unavailable):
        """add_agent_trace_step returns None when cache unavailable."""
        result = await sm_unavailable.add_agent_trace_step(
            user_id="u1",
            origin_function="plan_trip",
            status="success",
            session_id="s1",
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_get_session_invalid_last_n_raises(self, sm):
        """get_session raises on invalid last_n."""
        with pytest.raises(SessionParameterValidationError):
            await sm.get_session(user_id="u1", last_n=0, session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.get_session(user_id="u1", last_n=-1, session_id="s1")

    def test_format_entries_empty(self):
        """format_entries returns empty string for empty list."""
        assert SessionManager.format_entries([]) == ""

    def test_format_entries_formats(self):
        """format_entries produces expected format."""
        entries = [
            {"time": "t1", "question": "Q1", "context": "C1", "answer": "A1"},
        ]
        out = SessionManager.format_entries(entries)
        assert "Previous conversation" in out
        assert "Q1" in out and "A1" in out

    @pytest.mark.asyncio
    async def test_get_session_calls_cache(self, sm, mock_cache):
        """get_session delegates to cache."""
        mock_cache.get_all_qa_entries.return_value = [
            {"qa_id": "1", "question": "Q", "context": "C", "answer": "A", "time": "t"}
        ]
        entries = await sm.get_session(user_id="u1", session_id="s1")
        assert len(entries) == 1
        assert entries[0]["question"] == "Q"
        mock_cache.get_all_qa_entries.assert_called_once_with("u1", "s1")

    @pytest.mark.asyncio
    async def test_get_session_formatted(self, sm, mock_cache):
        """get_session with formatted=True returns string."""
        mock_cache.get_all_qa_entries.return_value = [
            SessionQAEntry(qa_id="1", question="Q", context="C", answer="A", time="t")
        ]
        out = await sm.get_session(user_id="u1", formatted=True, session_id="s1")
        assert isinstance(out, str)
        assert "Previous conversation" in out and "Q" in out

    @pytest.mark.asyncio
    async def test_get_session_unavailable_returns_empty(self, sm_unavailable):
        """get_session returns empty list when cache unavailable."""
        assert await sm_unavailable.get_session(user_id="u1", session_id="s1") == []
        assert await sm_unavailable.get_session(user_id="u1", formatted=True, session_id="s1") == ""

    @pytest.mark.asyncio
    async def test_get_agent_trace_session_calls_cache(self, sm, mock_cache):
        """get_agent_trace_session delegates to cache."""
        mock_cache.get_agent_trace_session.return_value = [
            {
                "trace_id": "t1",
                "origin_function": "plan_trip",
                "status": "success",
                "session_feedback": "plan_trip succeeded.",
            }
        ]
        entries = await sm.get_agent_trace_session(user_id="u1", session_id="s1")
        assert len(entries) == 1
        assert entries[0]["trace_id"] == "t1"
        mock_cache.get_agent_trace_session.assert_called_once_with("u1", "s1", last_n=None)

    @pytest.mark.asyncio
    async def test_get_agent_trace_session_unavailable_returns_empty(self, sm_unavailable):
        """get_agent_trace_session returns empty list when cache unavailable."""
        assert await sm_unavailable.get_agent_trace_session(user_id="u1", session_id="s1") == []

    @pytest.mark.asyncio
    async def test_get_agent_trace_feedback_calls_cache(self, sm, mock_cache):
        """get_agent_trace_feedback delegates to cache and returns feedback only."""
        mock_cache.get_agent_trace_feedback.return_value = [
            "plan_trip succeeded.",
            "book_hotel failed. Reason: No availability.",
        ]
        feedback = await sm.get_agent_trace_feedback(user_id="u1", session_id="s1")
        assert feedback == [
            "plan_trip succeeded.",
            "book_hotel failed. Reason: No availability.",
        ]
        mock_cache.get_agent_trace_feedback.assert_called_once_with("u1", "s1", last_n=None)

    @pytest.mark.asyncio
    async def test_get_agent_trace_feedback_passes_last_n_to_cache(self, sm, mock_cache):
        """get_agent_trace_feedback forwards last_n to cache."""
        mock_cache.get_agent_trace_feedback.return_value = ["book_hotel failed."]

        feedback = await sm.get_agent_trace_feedback(user_id="u1", session_id="s1", last_n=1)

        assert feedback == ["book_hotel failed."]
        mock_cache.get_agent_trace_feedback.assert_called_once_with("u1", "s1", last_n=1)

    @pytest.mark.asyncio
    async def test_get_agent_trace_feedback_unavailable_returns_empty(self, sm_unavailable):
        """get_agent_trace_feedback returns empty list when cache unavailable."""
        assert await sm_unavailable.get_agent_trace_feedback(user_id="u1", session_id="s1") == []

    @pytest.mark.asyncio
    async def test_get_agent_trace_count_calls_cache(self, sm, mock_cache):
        """get_agent_trace_count delegates to cache."""
        mock_cache.get_agent_trace_count.return_value = 3

        count = await sm.get_agent_trace_count(user_id="u1", session_id="s1")

        assert count == 3
        mock_cache.get_agent_trace_count.assert_called_once_with("u1", "s1")

    @pytest.mark.asyncio
    async def test_get_agent_trace_count_unavailable_returns_zero(self, sm_unavailable):
        """get_agent_trace_count returns zero when cache unavailable."""
        assert await sm_unavailable.get_agent_trace_count(user_id="u1", session_id="s1") == 0

    @pytest.mark.asyncio
    async def test_update_qa_calls_cache_and_reindexes_when_text_changes(
        self, sm, mock_cache, session_vector_mocks
    ):
        """update_qa delegates to cache and refreshes the searchable vector text."""
        mock_cache.get_qa_entries_by_ids.return_value = [
            SessionQAEntry(qa_id="q1", question="Q2", context="C", answer="A", time="t")
        ]

        ok = await sm.update_qa(user_id="u1", qa_id="q1", question="Q2", session_id="s1")

        assert ok is True
        mock_cache.update_qa_entry.assert_called_once_with(
            user_id="u1",
            session_id="s1",
            qa_id="q1",
            question="Q2",
            context=None,
            answer=None,
            feedback_text=None,
            feedback_score=None,
            used_graph_element_ids=None,
            memify_metadata=None,
            used_session_context_ids=None,
        )
        mock_cache.get_qa_entries_by_ids.assert_awaited_once_with("u1", "s1", ["q1"])
        session_vector_mocks["delete_qa"].assert_awaited_once_with(qa_id="q1")
        session_vector_mocks["index"].assert_awaited_once_with(
            user_id="u1",
            session_id="s1",
            qa_id="q1",
            question="Q2",
            answer="A",
        )

    @pytest.mark.asyncio
    async def test_update_qa_feedback_only_does_not_touch_vectors(
        self, sm, mock_cache, session_vector_mocks
    ):
        """Feedback-only updates leave QA vector rows unchanged."""
        ok = await sm.update_qa(
            user_id="u1",
            qa_id="q1",
            feedback_text="useful",
            feedback_score=5,
            session_id="s1",
        )

        assert ok is True
        mock_cache.get_qa_entries_by_ids.assert_not_awaited()
        session_vector_mocks["delete_qa"].assert_not_awaited()
        session_vector_mocks["index"].assert_not_awaited()

    @pytest.mark.asyncio
    async def test_delete_feedback_calls_cache(self, sm, mock_cache):
        """delete_feedback delegates to cache."""
        ok = await sm.delete_feedback(user_id="u1", qa_id="q1", session_id="s1")
        assert ok is True
        mock_cache.delete_feedback.assert_called_once_with(
            user_id="u1", session_id="s1", qa_id="q1"
        )

    @pytest.mark.asyncio
    async def test_delete_qa_calls_cache_and_deletes_vector(
        self, sm, mock_cache, session_vector_mocks
    ):
        """delete_qa delegates to cache and removes its vector row."""
        ok = await sm.delete_qa(user_id="u1", qa_id="q1", session_id="s1")
        assert ok is True
        mock_cache.delete_qa_entry.assert_called_once_with(
            user_id="u1", session_id="s1", qa_id="q1"
        )
        session_vector_mocks["delete_qa"].assert_awaited_once_with(qa_id="q1")

    @pytest.mark.asyncio
    async def test_delete_qa_skips_vector_delete_when_cache_delete_misses(
        self, sm, mock_cache, session_vector_mocks
    ):
        """delete_qa leaves vectors alone when the cache row was not deleted."""
        mock_cache.delete_qa_entry.return_value = False

        ok = await sm.delete_qa(user_id="u1", qa_id="q1", session_id="s1")

        assert ok is False
        session_vector_mocks["delete_qa"].assert_not_awaited()

    @pytest.mark.asyncio
    async def test_delete_session_calls_cache_and_deletes_vectors(
        self, sm, mock_cache, session_vector_mocks
    ):
        """delete_session delegates to cache and removes its scoped vector rows."""
        ok = await sm.delete_session(user_id="u1", session_id="s1")
        assert ok is True
        mock_cache.delete_session.assert_called_once_with(user_id="u1", session_id="s1")
        session_vector_mocks["delete_session"].assert_awaited_once_with(
            user_id="u1",
            session_id="s1",
        )

    @pytest.mark.asyncio
    async def test_delete_session_skips_vector_cleanup_when_cache_delete_misses(
        self, sm, mock_cache, session_vector_mocks
    ):
        """delete_session leaves vectors alone when the cache session was not deleted."""
        mock_cache.delete_session.return_value = False

        ok = await sm.delete_session(user_id="u1", session_id="s1")

        assert ok is False
        session_vector_mocks["delete_session"].assert_not_awaited()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_no_user_id_calls_generate_completion_only(
        self, sm, mock_cache
    ):
        """When user_id is None, generate_completion_with_session runs completion only, no add_qa."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch(
                "cognee.infrastructure.session.session_manager.generate_completion",
                new_callable=AsyncMock,
                return_value="Generated answer",
            ) as mock_generate,
        ):
            mock_session_user.get.return_value = None

            result = await sm.generate_completion_with_session(
                query="Q?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_generate.assert_awaited_once()
        mock_cache.create_qa_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_cache_disabled_calls_generate_completion_only(
        self, sm, mock_cache
    ):
        """When caching disabled, generate_completion_with_session runs completion only, no add_qa."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_manager.generate_completion",
                new_callable=AsyncMock,
                return_value="Generated answer",
            ) as mock_generate,
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = False
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                query="Q?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_generate.assert_awaited_once()
        mock_cache.create_qa_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_available_calls_add_qa(self, sm, mock_cache):
        """When session available, generate_completion_with_session gets history, generates, saves QA."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Generated answer", "", None),
            ) as mock_generate,
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = False
            mock_config_cls.return_value = mock_config

            used_ids = {"node_ids": ["n1"]}
            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="Q?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
                used_graph_element_ids=used_ids,
            )

        assert result == "Generated answer"
        mock_generate.assert_awaited_once()
        mock_cache.create_qa_entry.assert_called_once()
        call_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert call_kw["user_id"] == "u1"
        assert call_kw["session_id"] == "s1"
        assert call_kw["question"] == "Q?"
        assert call_kw["answer"] == "Generated answer"
        assert call_kw["context"] == ""
        assert call_kw["used_graph_element_ids"] == used_ids

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_unavailable_returns_completion_only(
        self, sm_unavailable
    ):
        """When cache unavailable, generate_completion_with_session runs completion only."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch(
                "cognee.infrastructure.session.session_manager.generate_completion",
                new_callable=AsyncMock,
                return_value="Generated answer",
            ) as mock_generate,
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user

            result = await sm_unavailable.generate_completion_with_session(
                query="Q?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_generate.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_feedback_only_records_qa(self, sm, mock_cache):
        """When no query_to_answer is present: return the acknowledgement and record it
        as a QA entry (question + acknowledgement, no served context)."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(
                    response_to_user="Thanks for your feedback!",
                ),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config
            mock_cache.get_latest_qa_entries.return_value = [
                SessionQAEntry(qa_id="last-qa-123", question="Q", context="", answer="A", time="t")
            ]

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="thanks, that was helpful!",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Thanks for your feedback!"
        mock_cache.update_qa_entry.assert_not_called()
        mock_cache.create_qa_entry.assert_called_once()
        qa_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert qa_kw["question"] == "thanks, that was helpful!"
        assert qa_kw["answer"] == "Thanks for your feedback!"
        assert qa_kw["used_session_context_ids"] is None

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_feedback_and_followup_persists_and_adds_qa(
        self, sm, mock_cache
    ):
        """When query_to_answer is present: answer it and add QA for the original message."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(
                    response_to_user="Thanks for your feedback!",
                    query_to_answer="What is the capital of France?",
                ),
            ),
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Paris is the capital of France.", "", None),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config
            mock_cache.get_latest_qa_entries.return_value = [
                SessionQAEntry(qa_id="last-qa-456", question="Q", context="", answer="A", time="t")
            ]

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="thanks! What is the capital of France?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Paris is the capital of France."
        mock_cache.update_qa_entry.assert_not_called()
        mock_cache.create_qa_entry.assert_called_once()
        qa_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert qa_kw["question"] == "thanks! What is the capital of France?"
        assert qa_kw["answer"] == "Paris is the capital of France."

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_auto_feedback_disabled_add_qa_no_feedback(
        self, sm, mock_cache
    ):
        """When caching True but auto_feedback False: add_qa called, no add_feedback."""
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Generated answer", "", None),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = False
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="Q?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_cache.create_qa_entry.assert_called_once()
        mock_cache.update_qa_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_query_to_answer_no_last_qa_id_adds_qa(
        self, sm, mock_cache
    ):
        """When query_to_answer is present with empty session: add QA and no feedback write."""
        mock_cache.get_latest_qa_entries.return_value = []
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(
                    query_to_answer="What is X?",
                ),
            ),
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Generated answer", "", None),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="What is X?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_cache.create_qa_entry.assert_called_once()
        mock_cache.update_qa_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_feedback_like_empty_session_answers_and_adds_qa(
        self, sm, mock_cache
    ):
        """Without previous QA, acknowledgement-only analysis still answers the original query."""
        mock_cache.get_latest_qa_entries.return_value = []
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(response_to_user="Got it."),
            ),
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Generated answer", "", None),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="Test default session",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        mock_cache.create_qa_entry.assert_called_once()
        qa_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert qa_kw["question"] == "Test default session"
        mock_cache.update_qa_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_feedback_records_despite_rating_failure(
        self, sm, mock_cache
    ):
        """A no-answer turn still records its QA entry even if rating persistence
        (update_qa_entry) fails — that failure is swallowed fail-open."""
        mock_cache.update_qa_entry = AsyncMock(side_effect=Exception("Cache write failed"))
        mock_cache.get_latest_qa_entries.return_value = [
            SessionQAEntry(qa_id="last-qa-789", question="Q", context="", answer="A", time="t")
        ]
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(
                    response_to_user="Thanks for your feedback!",
                ),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="thanks!",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Thanks for your feedback!"
        mock_cache.create_qa_entry.assert_called_once()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_empty_analysis_answers_original_query(
        self, sm, mock_cache
    ):
        """When analysis has no signals, fail open by answering the original query."""
        mock_cache.get_latest_qa_entries.return_value = [
            SessionQAEntry(qa_id="last-qa-999", question="Q", context="", answer="A", time="t")
        ]
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(),
            ),
            patch(
                "cognee.infrastructure.session.session_turn.generate_session_completion_with_optional_summary",
                new_callable=AsyncMock,
                return_value=("Generated answer", "", None),
            ) as mock_generate,
            patch.object(sm, "add_qa", new_callable=AsyncMock) as mock_add_qa,
            patch(
                "cognee.infrastructure.session.session_turn.build_active_context_block_safe",
                new_callable=AsyncMock,
                return_value=("", []),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="What should I audit?",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Generated answer"
        assert mock_generate.await_args.kwargs["query"] == "What should I audit?"
        mock_add_qa.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_generate_completion_with_session_does_not_auto_write_qa_feedback(
        self, sm, mock_cache
    ):
        """The recorded feedback turn does not auto-populate QA feedback text/score."""
        mock_cache.get_latest_qa_entries.return_value = [
            SessionQAEntry(qa_id="last-qa-norm", question="Q", context="", answer="A", time="t")
        ]
        with (
            patch(
                "cognee.infrastructure.session.session_manager.session_user"
            ) as mock_session_user,
            patch("cognee.infrastructure.session.session_manager.CacheConfig") as mock_config_cls,
            patch(
                "cognee.infrastructure.session.session_turn.analyze_turn_for_session_context",
                new_callable=AsyncMock,
                return_value=FeedbackDetectionResult(
                    response_to_user="Thanks!",
                ),
            ),
        ):
            mock_user = MagicMock()
            mock_user.id = "u1"
            mock_session_user.get.return_value = mock_user
            mock_config = MagicMock()
            mock_config.caching = True
            mock_config.auto_feedback = True
            mock_config_cls.return_value = mock_config

            result = await sm.generate_completion_with_session(
                session_id="s1",
                query="2 stars",
                context="ctx",
                user_prompt_path="user.txt",
                system_prompt_path="sys.txt",
            )

        assert result == "Thanks!"
        mock_cache.update_qa_entry.assert_not_called()
        mock_cache.create_qa_entry.assert_called_once()
        qa_kw = mock_cache.create_qa_entry.call_args.kwargs
        assert qa_kw["feedback_text"] is None
        assert qa_kw["feedback_score"] is None


class TestSessionContextEntryValidation:
    """Validation and fail-open behavior of the session-context entry methods.

    Invalid parameters raise SessionParameterValidationError, in parity with
    add_qa and the rest of SessionManager; infrastructure/cache failures stay
    fail-open (False / [])."""

    @pytest.fixture
    def mock_cache(self):
        """Mock cache engine for the session-context entry methods."""
        cache = MagicMock()
        cache.create_session_context_entry = AsyncMock(return_value=True)
        cache.get_session_context_entries = AsyncMock(return_value=[])
        cache.update_session_context_entry = AsyncMock(return_value=True)
        cache.delete_session_context = AsyncMock(return_value=True)
        return cache

    @pytest.fixture
    def sm(self, mock_cache):
        """SessionManager with mocked cache."""
        return SessionManager(cache_engine=mock_cache)

    @pytest.fixture
    def sm_failing_cache(self, mock_cache):
        """SessionManager whose cache raises a runtime error on every context call."""
        mock_cache.create_session_context_entry.side_effect = RuntimeError("cache down")
        mock_cache.get_session_context_entries.side_effect = RuntimeError("cache down")
        mock_cache.update_session_context_entry.side_effect = RuntimeError("cache down")
        mock_cache.delete_session_context.side_effect = RuntimeError("cache down")
        return SessionManager(cache_engine=mock_cache)

    @pytest.mark.asyncio
    async def test_create_session_context_entry_invalid_params_raises(self, sm, mock_cache):
        """create_session_context_entry raises on invalid user_id or session_id."""
        with pytest.raises(SessionParameterValidationError):
            await sm.create_session_context_entry(
                user_id="", entry_dump={"kind": "context"}, session_id="s1"
            )
        with pytest.raises(SessionParameterValidationError):
            await sm.create_session_context_entry(
                user_id="u1", entry_dump={"kind": "context"}, session_id="  "
            )
        mock_cache.create_session_context_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_get_session_context_entries_invalid_params_raises(self, sm, mock_cache):
        """get_session_context_entries raises on invalid user_id or session_id."""
        with pytest.raises(SessionParameterValidationError):
            await sm.get_session_context_entries(user_id="", session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.get_session_context_entries(user_id="u1", session_id="  ")
        mock_cache.get_session_context_entries.assert_not_called()

    @pytest.mark.asyncio
    async def test_update_session_context_entry_invalid_params_raises(self, sm, mock_cache):
        """update_session_context_entry raises on invalid user_id or session_id."""
        with pytest.raises(SessionParameterValidationError):
            await sm.update_session_context_entry(
                user_id="", entry_id="e1", merge={}, session_id="s1"
            )
        with pytest.raises(SessionParameterValidationError):
            await sm.update_session_context_entry(
                user_id="u1", entry_id="e1", merge={}, session_id="  "
            )
        mock_cache.update_session_context_entry.assert_not_called()

    @pytest.mark.asyncio
    async def test_delete_session_context_invalid_params_raises(self, sm, mock_cache):
        """delete_session_context raises on invalid user_id or session_id."""
        with pytest.raises(SessionParameterValidationError):
            await sm.delete_session_context(user_id="", session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.delete_session_context(user_id="u1", session_id="  ")
        mock_cache.delete_session_context.assert_not_called()

    @pytest.mark.asyncio
    async def test_invalid_params_raise_even_when_cache_unavailable(self):
        """Validation runs before the availability check, matching add_qa's ordering."""
        sm_unavailable = SessionManager(cache_engine=None)
        with pytest.raises(SessionParameterValidationError):
            await sm_unavailable.create_session_context_entry(
                user_id="", entry_dump={"kind": "context"}, session_id="s1"
            )
        with pytest.raises(SessionParameterValidationError):
            await sm_unavailable.get_session_context_entries(user_id="", session_id="s1")

    @pytest.mark.asyncio
    async def test_create_session_context_entry_fail_open_on_cache_error(self, sm_failing_cache):
        """Cache runtime failures stay fail-open: returns False, never raises."""
        result = await sm_failing_cache.create_session_context_entry(
            user_id="u1", entry_dump={"kind": "context"}, session_id="s1"
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_get_session_context_entries_fail_open_on_cache_error(self, sm_failing_cache):
        """Cache runtime failures stay fail-open: returns [], never raises."""
        result = await sm_failing_cache.get_session_context_entries(user_id="u1", session_id="s1")
        assert result == []

    @pytest.mark.asyncio
    async def test_update_session_context_entry_fail_open_on_cache_error(self, sm_failing_cache):
        """Cache runtime failures stay fail-open: returns False, never raises."""
        result = await sm_failing_cache.update_session_context_entry(
            user_id="u1", entry_id="e1", merge={"content": "x"}, session_id="s1"
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_delete_session_context_fail_open_on_cache_error(self, sm_failing_cache):
        """Cache runtime failures stay fail-open: returns False, never raises."""
        result = await sm_failing_cache.delete_session_context(user_id="u1", session_id="s1")
        assert result is False

    @pytest.mark.asyncio
    async def test_validation_error_parity_with_add_qa(self, sm):
        """The context methods raise the same error add_qa raises for the same bad params."""
        with pytest.raises(SessionParameterValidationError):
            await sm.add_qa(user_id=" ", question="Q", context="C", answer="A", session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.create_session_context_entry(
                user_id=" ", entry_dump={"kind": "context"}, session_id="s1"
            )
        with pytest.raises(SessionParameterValidationError):
            await sm.get_session_context_entries(user_id=" ", session_id="s1")
        with pytest.raises(SessionParameterValidationError):
            await sm.update_session_context_entry(
                user_id=" ", entry_id="e1", merge={}, session_id="s1"
            )
        with pytest.raises(SessionParameterValidationError):
            await sm.delete_session_context(user_id=" ", session_id="s1")
