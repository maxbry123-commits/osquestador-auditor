import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4, uuid5

import pytest

from cognee.infrastructure.databases.vector.exceptions import CollectionNotFoundError
from cognee.infrastructure.session.session_manager import SessionTurnPreparation
from cognee.modules.graph.models.EdgeType import EdgeType
from cognee.modules.retrieval.exceptions.exceptions import QueryValidationError
from cognee.modules.retrieval.hybrid.results import empty_hybrid_result
from cognee.modules.retrieval.hybrid_retriever import HybridRetriever


QUERY_VECTOR = [0.1, 0.2, 0.3]


def _result(result_id="result-id", payload=None):
    scored_result = MagicMock()
    scored_result.id = result_id
    scored_result.payload = payload
    return scored_result


def _unified(vector=None, graph=None):
    unified = MagicMock()
    unified.vector = vector or MagicMock()
    unified.vector.embedding_engine.embed_text = AsyncMock(return_value=[QUERY_VECTOR])
    unified.graph = graph or MagicMock()
    unified.graph.is_empty = AsyncMock(return_value=False)
    return unified


def _vector_search(
    chunks=None, entities=None, summaries=None, edge_types=None, missing_collections=None
):
    missing_collections = set(missing_collections or [])

    async def search(collection_name, *args, **kwargs):
        if collection_name in missing_collections:
            raise CollectionNotFoundError("missing")
        if collection_name == "DocumentChunk_text":
            return chunks or []
        if collection_name == "TextSummary_text":
            return summaries or []
        if collection_name == "Entity_name":
            return entities or []
        if collection_name == "EdgeType_relationship_name":
            return edge_types or []
        return []

    return AsyncMock(side_effect=search)


def _search_call(vector, collection_name):
    for call in vector.search.await_args_list:
        if call.args[:1] == (collection_name,):
            return call
    raise AssertionError(f"{collection_name} was not searched")


@pytest.mark.asyncio
async def test_passage_section_formatting():
    retriever = HybridRetriever(text_summaries_top_k=0)
    context = await retriever.get_context_from_objects(
        query="q",
        retrieved_objects={
            "chunks": [
                _result(payload={"text": "First passage"}),
                _result(payload={}),
                _result(payload={"text": "Second passage"}),
            ],
            "entities": [],
        },
    )

    assert context == "## Relevant passages\nFirst passage\n---\nSecond passage"


@pytest.mark.asyncio
async def test_passage_section_formats_paired_summary_and_raw_text():
    retriever = HybridRetriever()
    context = await retriever.get_context_from_objects(
        query="q",
        retrieved_objects={
            "chunks": [_result("chunk-1", {"id": "chunk-1", "text": "Raw passage"})],
            "chunk_summaries": {"chunk-1": "Short summary"},
            "entities": [],
        },
    )

    assert context == "## Relevant passages\nRaw passage"


@pytest.mark.asyncio
async def test_empty_sections_return_empty_context():
    retriever = HybridRetriever()

    context = await retriever.get_context_from_objects(
        query="q", retrieved_objects={"chunks": [], "entities": []}
    )

    assert context == ""


@pytest.mark.asyncio
async def test_empty_neighborhood_does_not_prevent_chunk_search():
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[_result("chunk-1", {"id": "chunk-1", "text": "Chunk text"})],
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})],
    )
    graph = _graph()

    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunks"][0].payload["text"] == "Chunk text"
    assert retrieved["entities"][0]["name"] == "Entity"
    assert retrieved["entities"][0]["edges"] == []
    chunk_call = _search_call(vector, "DocumentChunk_text")
    assert chunk_call.args[:2] == ("DocumentChunk_text", None)
    assert chunk_call.kwargs["query_vector"] == QUERY_VECTOR


@pytest.mark.asyncio
async def test_query_batch_with_session_cache_is_rejected():
    retriever = HybridRetriever()

    with patch.object(retriever, "_use_session_cache", return_value=True):
        with pytest.raises(QueryValidationError, match="batch queries with session cache"):
            await retriever.get_retrieved_objects(query_batch=["q"])


@pytest.mark.asyncio
async def test_empty_graph_returns_empty_channels_without_embedding():
    unified = _unified()
    unified.graph.is_empty = AsyncMock(return_value=True)
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=unified,
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved == empty_hybrid_result()
    unified.vector.embedding_engine.embed_text.assert_not_awaited()


@pytest.mark.asyncio
async def test_missing_document_chunk_collection_returns_empty_channel():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})],
        missing_collections={"DocumentChunk_text"},
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=_graph()),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunks"] == []
    assert retrieved["entities"][0]["name"] == "Entity"


@pytest.mark.asyncio
async def test_chunk_search_receives_nodeset_filters():
    vector = MagicMock()
    vector.search = AsyncMock(return_value=[])
    retriever = HybridRetriever(node_name=["KEN"], node_name_filter_operator="AND")

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        await retriever.get_retrieved_objects(query="q")

    chunk_call = _search_call(vector, "DocumentChunk_text")
    assert chunk_call.args[:2] == ("DocumentChunk_text", None)
    assert chunk_call.kwargs["query_vector"] == QUERY_VECTOR
    assert chunk_call.kwargs["node_name"] == ["KEN"]
    assert chunk_call.kwargs["node_name_filter_operator"] == "AND"


@pytest.mark.asyncio
async def test_default_summary_search_participates_in_chunk_ranking():
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[_result("semantic", {"id": "semantic", "text": "Semantic"})],
        summaries=[
            _result(
                "summary",
                {
                    "id": "summary",
                    "text": "Semantic summary",
                    "source_chunk_id": "semantic",
                },
            )
        ],
    )
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(chunks_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["Semantic"]
    assert retrieved["chunk_summaries"] == {"semantic": "Semantic summary"}


@pytest.mark.asyncio
async def test_summary_retrieval_opt_out_disables_summary_channel_only():
    vector = MagicMock()
    vector.search = _vector_search(chunks=[_result("semantic", {"id": "semantic", "text": "S"})])
    retriever = HybridRetriever(chunks_top_k=2, text_summaries_top_k=0)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["S"]
    assert retrieved["chunk_summaries"] == {}
    assert not any(call.args[:1] == ("TextSummary_text",) for call in vector.search.await_args_list)


@pytest.mark.asyncio
async def test_summary_only_hit_fetches_source_chunk():
    vector = MagicMock()
    vector.search = _vector_search(
        summaries=[
            _result(
                "summary",
                {
                    "id": "summary",
                    "text": "Only summary",
                    "source_chunk_id": "chunk-1",
                    "belongs_to_set": ["KEEP"],
                },
            )
        ]
    )
    vector.retrieve = AsyncMock(
        return_value=[_result("chunk-1", {"id": "chunk-1", "text": "Fetched chunk"})]
    )
    retriever = HybridRetriever(chunks_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    vector.retrieve.assert_awaited_once_with("DocumentChunk_text", ["chunk-1"])
    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["Fetched chunk"]


@pytest.mark.asyncio
async def test_summary_only_hit_respects_source_chunk_nodeset_filter():
    vector = MagicMock()
    vector.search = _vector_search(
        summaries=[
            _result(
                "summary",
                {"id": "summary", "text": "Only summary", "source_chunk_id": "chunk-1"},
            )
        ]
    )
    vector.retrieve = AsyncMock(
        return_value=[
            _result("chunk-1", {"id": "chunk-1", "text": "Filtered", "belongs_to_set": ["DROP"]})
        ]
    )
    retriever = HybridRetriever(chunks_top_k=1, node_name=["KEEP"])

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunks"] == []
    assert retrieved["chunk_summaries"] == {}


@pytest.mark.asyncio
async def test_summary_search_receives_nodeset_filters():
    vector = MagicMock()
    vector.search = _vector_search()
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(node_name=["KEN"], node_name_filter_operator="AND")

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        await retriever.get_retrieved_objects(query="q")

    chunk_call = _search_call(vector, "DocumentChunk_text")
    summary_call = _search_call(vector, "TextSummary_text")
    assert chunk_call.kwargs["node_name"] == ["KEN"]
    assert summary_call.kwargs["node_name"] == ["KEN"]
    assert summary_call.kwargs["node_name_filter_operator"] == "AND"


@pytest.mark.asyncio
async def test_summary_hit_without_source_chunk_id_is_skipped():
    vector = MagicMock()
    vector.search = _vector_search(summaries=[_result("summary", {"id": "summary", "text": "S"})])
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(chunks_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunks"] == []
    assert retrieved["chunk_summaries"] == {}
    vector.retrieve.assert_not_awaited()


@pytest.mark.asyncio
async def test_missing_summary_collection_does_not_fail_hybrid_retrieval():
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[_result("chunk", {"id": "chunk", "text": "Chunk"})],
        missing_collections={"TextSummary_text"},
    )
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(chunks_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["Chunk"]


@pytest.mark.asyncio
async def test_importance_weight_adjusts_summary_enabled_ranking():
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[
            _result("low", {"id": "low", "text": "Low", "importance_weight": 0.0}),
            _result("high", {"id": "high", "text": "High", "importance_weight": 1.0}),
        ]
    )
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(chunks_top_k=2)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["High", "Low"]


@pytest.mark.asyncio
async def test_importance_weight_can_be_disabled_for_summary_enabled_ranking():
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[
            _result("low", {"id": "low", "text": "Low", "importance_weight": 0.0}),
            _result("high", {"id": "high", "text": "High", "importance_weight": 1.0}),
        ]
    )
    vector.retrieve = AsyncMock(return_value=[])
    retriever = HybridRetriever(chunks_top_k=2, use_importance_weight=False)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["Low", "High"]


@pytest.mark.asyncio
async def test_final_raw_chunk_gets_paired_summary_text():
    chunk_id = uuid4()
    summary_id = uuid5(chunk_id, "TextSummary")
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[_result(str(chunk_id), {"id": str(chunk_id), "text": "Raw chunk"})]
    )

    async def retrieve(collection_name, ids):
        if collection_name == "TextSummary_text":
            assert ids == [str(summary_id)]
            return [_result(str(summary_id), {"id": str(summary_id), "text": "Paired summary"})]
        return []

    vector.retrieve = AsyncMock(side_effect=retrieve)
    retriever = HybridRetriever(chunks_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunk_summaries"] == {str(chunk_id): "Paired summary"}


@pytest.mark.asyncio
async def test_paired_summary_text_respects_nodeset_filter():
    chunk_id = uuid4()
    summary_id = uuid5(chunk_id, "TextSummary")
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[
            _result(
                str(chunk_id),
                {"id": str(chunk_id), "text": "Raw chunk", "belongs_to_set": ["KEEP"]},
            )
        ]
    )

    async def retrieve(collection_name, ids):
        if collection_name == "TextSummary_text":
            assert ids == [str(summary_id)]
            return [
                _result(
                    str(summary_id),
                    {"id": str(summary_id), "text": "Out of scope", "belongs_to_set": ["DROP"]},
                )
            ]
        return []

    vector.retrieve = AsyncMock(side_effect=retrieve)
    retriever = HybridRetriever(chunks_top_k=1, node_name=["KEEP"])

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["chunk_summaries"] == {}


@pytest.mark.asyncio
async def test_independent_retrieval_channels_run_concurrently():
    chunk_vector_started = asyncio.Event()
    entity_started = asyncio.Event()

    async def search_vector(collection_name, *args, **kwargs):
        if collection_name == "DocumentChunk_text":
            chunk_vector_started.set()
            await entity_started.wait()
            return []
        if collection_name == "Entity_name":
            entity_started.set()
            await chunk_vector_started.wait()
            return []
        return []

    vector = MagicMock()
    vector.search = AsyncMock(side_effect=search_vector)
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await asyncio.wait_for(retriever.get_retrieved_objects(query="q"), timeout=1)

    assert retrieved == {"chunks": [], "chunk_summaries": {}, "entities": [], "facts": []}


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("payload", "expected_name"),
    [
        ({"id": "entity-1", "name": "Named entity"}, "Named entity"),
        ({"id": "entity-1", "text": "Text entity"}, "Text entity"),
        ({"id": "entity-1"}, "entity-1"),
    ],
)
async def test_entity_fields_fall_back_from_name_to_text_to_id(payload, expected_name):
    vector = MagicMock()
    vector.search = _vector_search(entities=[_result("fallback-id", payload)])
    graph = _graph()
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"][0]["name"] == expected_name


@pytest.mark.asyncio
async def test_entity_header_omits_index_schema_type():
    retriever = HybridRetriever()

    context = await retriever.get_context_from_objects(
        query="q",
        retrieved_objects={
            "chunks": [],
            "entities": [
                {
                    "id": "entity-1",
                    "name": "lisbon office logistics intelligence project",
                    "type": "IndexSchema",
                    "edges": [],
                }
            ],
        },
    )

    assert context == "## Relevant entities\n### lisbon office logistics intelligence project"


@pytest.mark.asyncio
async def test_entity_type_prefers_domain_type_over_index_schema():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[
            _result(
                "entity-1",
                {
                    "id": "entity-1",
                    "name": "Lisbon office",
                    "type": "IndexSchema",
                    "is_a": "Office",
                },
            )
        ]
    )
    graph = _graph()
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"][0]["type"] == "Office"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("edge_properties", "expected_text"),
    [
        ({"edge_text": "Edge text"}, "Edge text"),
        ({}, "Source -- REL -- Target"),
    ],
)
async def test_edge_text_fallbacks(edge_properties, expected_text):
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Source"}), ("target-1", {"name": "Target"})],
        edges=[("entity-1", "target-1", "REL", edge_properties)],
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"][0]["edges"][0]["text"] == expected_text


@pytest.mark.asyncio
async def test_duplicate_edges_are_removed_and_max_edges_caps_results():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Entity"}), ("t1", {"name": "T1"}), ("t2", {"name": "T2"})],
        edges=[
            ("entity-1", "t1", "", {"edge_text": "same"}),
            ("entity-1", "t2", "", {"edge_text": "same"}),
            ("entity-1", "t3", "", {"edge_text": "other"}),
        ],
    )
    retriever = HybridRetriever(max_edges_per_entity=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [edge["text"] for edge in retrieved["entities"][0]["edges"]] == ["same"]


@pytest.mark.asyncio
async def test_same_edge_text_does_not_collapse_distinct_relationships():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Entity"}), ("t1", {"name": "T1"}), ("t2", {"name": "T2"})],
        edges=[
            ("entity-1", "t1", "REL", {"edge_text": "related"}),
            ("entity-1", "t2", "REL", {"edge_text": "related"}),
            ("entity-1", "t1", "REL", {"edge_text": "related"}),
        ],
    )
    retriever = HybridRetriever(max_edges_per_entity=5)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [edge["target_id"] for edge in retrieved["entities"][0]["edges"]] == ["t1", "t2"]


@pytest.mark.asyncio
async def test_is_a_edge_is_prioritized_before_edge_cap():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph(
        nodes=[
            ("entity-1", {"name": "Lisbon office"}),
            ("project-1", {"name": "HarborLens"}),
            ("type-1", {"name": "Office"}),
        ],
        edges=[
            ("entity-1", "project-1", "owns", {"edge_text": "Lisbon office owns HarborLens"}),
            ("entity-1", "type-1", "is_a", {"edge_text": "Lisbon office is a Office"}),
        ],
    )
    retriever = HybridRetriever(max_edges_per_entity=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [edge["text"] for edge in retrieved["entities"][0]["edges"]] == [
        "Lisbon office is a Office"
    ]


@pytest.mark.asyncio
async def test_missing_entity_collection_returns_empty_channel():
    vector = MagicMock()
    vector.search = _vector_search(missing_collections={"Entity_name"})
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved == {"chunks": [], "chunk_summaries": {}, "entities": [], "facts": []}


@pytest.mark.asyncio
async def test_empty_entities_fill_facts_with_entity_edge_budget():
    fact_texts = [f"Alice works at Acme office {index}." for index in range(6)]
    vector = MagicMock()
    vector.search = _vector_search(edge_types=[_edge_hit(text) for text in fact_texts])
    retriever = HybridRetriever(entities_top_k=2, max_edges_per_entity=2, facts_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"] == []
    assert [item["text"] for item in retrieved["facts"]] == fact_texts[:4]


@pytest.mark.asyncio
async def test_scoped_empty_entities_do_not_dump_unscoped_facts():
    vector = MagicMock()
    vector.search = _vector_search(edge_types=[_edge_hit("Alice works at Acme.")])
    retriever = HybridRetriever(node_name=["KEN"], entities_top_k=2, max_edges_per_entity=2)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"] == []
    assert retrieved["facts"] == []


@pytest.mark.asyncio
async def test_entity_search_error_uses_edge_fact_budget():
    async def search(collection_name, *args, **kwargs):
        if collection_name == "Entity_name":
            raise RuntimeError("backend down")
        if collection_name == "EdgeType_relationship_name":
            return [_edge_hit("Alice works at Acme.")]
        return []

    vector = MagicMock()
    vector.search = AsyncMock(side_effect=search)
    retriever = HybridRetriever(entities_top_k=2, max_edges_per_entity=2, facts_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"] == []
    assert [item["text"] for item in retrieved["facts"]] == ["Alice works at Acme."]


@pytest.mark.asyncio
async def test_entity_search_receives_nodeset_filters_and_expands_connections():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph()
    retriever = HybridRetriever(node_name=["KEN"], node_name_filter_operator="AND")

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        await retriever.get_retrieved_objects(query="q")

    entity_call = _search_call(vector, "Entity_name")
    assert entity_call.args[:2] == ("Entity_name", None)
    assert entity_call.kwargs["query_vector"] == QUERY_VECTOR
    assert entity_call.kwargs["node_name"] == ["KEN"]
    assert entity_call.kwargs["node_name_filter_operator"] == "AND"
    graph.get_neighborhood.assert_awaited_once_with(["entity-1"], depth=1)


@pytest.mark.asyncio
async def test_malformed_neighborhood_rows_are_skipped_without_dropping_entity():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Entity"})]
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Source"}), "not-a-tuple"],
        edges=[
            {"not": "a tuple"},
            ("entity-1", "target-1"),
            ("entity-1", "target-1", "REL"),
        ],
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"][0]["name"] == "Entity"
    assert retrieved["entities"][0]["edges"][0]["text"] == "Source -- REL -- target-1"


@pytest.mark.asyncio
async def test_entities_section_omits_missing_optional_fields():
    retriever = HybridRetriever()

    context = await retriever.get_context_from_objects(
        query="q",
        retrieved_objects={
            "chunks": [],
            "entities": [{"id": "entity-1", "name": "Entity", "edges": []}],
        },
    )

    assert context == "## Relevant entities\n### Entity"


@pytest.mark.asyncio
async def test_global_context_is_omitted_by_default():
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.load_root_text",
        new_callable=AsyncMock,
    ) as load_root_text:
        context = await retriever.get_context_from_objects(
            query="q", retrieved_objects={"chunks": [], "entities": []}
        )

    assert context == ""
    load_root_text.assert_not_awaited()


@pytest.mark.asyncio
async def test_global_context_is_prepended_when_enabled():
    vector = MagicMock()
    retriever = HybridRetriever(include_global_context_index=True)

    with (
        patch(
            "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
            new_callable=AsyncMock,
            return_value=_unified(vector=vector),
        ) as get_unified,
        patch(
            "cognee.modules.retrieval.hybrid_retriever.load_root_text",
            new_callable=AsyncMock,
            return_value="Root summary",
        ),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.search_top_global_context_summaries",
            new_callable=AsyncMock,
            return_value=["Area summary"],
        ) as search_summaries,
    ):
        context = await retriever.get_context_from_objects(
            query="q",
            retrieved_objects={"chunks": [_result(payload={"text": "Chunk"})], "entities": []},
        )

    assert context.startswith("## Global context\nWorld summary:\nRoot summary")
    assert "\n\n## Relevant passages\nChunk" in context
    get_unified.assert_awaited_once()
    search_summaries.assert_awaited_once_with("q", 3, vector)


@pytest.mark.asyncio
async def test_global_context_does_not_reuse_previous_retrieval_vector():
    vector = MagicMock()
    vector.search = _vector_search()
    retriever = HybridRetriever(include_global_context_index=True)

    with (
        patch(
            "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
            new_callable=AsyncMock,
            return_value=_unified(vector=vector, graph=_graph()),
        ),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.load_root_text",
            new_callable=AsyncMock,
            return_value="Root summary",
        ),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.search_top_global_context_summaries",
            new_callable=AsyncMock,
            return_value=["Area summary"],
        ) as search_summaries,
    ):
        await retriever.get_retrieved_objects(query="first query")
        await retriever.get_context_from_objects(
            query="second query",
            retrieved_objects={"chunks": [], "entities": []},
        )

    search_summaries.assert_awaited_once_with("second query", 3, vector)


@pytest.mark.asyncio
async def test_no_session_path_calls_generate_completion():
    retriever = HybridRetriever()

    with (
        patch.object(retriever, "_use_session_cache", return_value=False),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.generate_completion",
            new_callable=AsyncMock,
            return_value="answer",
        ) as generate_completion,
    ):
        completion = await retriever.get_completion_from_context(
            query="q",
            retrieved_objects={"chunks": [], "entities": []},
            context="context",
        )

    assert completion == ["answer"]
    generate_completion.assert_awaited_once()


@pytest.mark.asyncio
async def test_session_path_calls_session_manager_with_used_node_ids():
    retriever = HybridRetriever(session_id="session-1")
    session_manager = MagicMock()
    session_manager.generate_completion_with_session = AsyncMock(return_value="answer")
    retrieved_objects = {
        "chunks": [_result("chunk-result", {"id": "chunk-1", "text": "Chunk"})],
        "chunk_summaries": {"chunk-1": "Summary helper text"},
        "entities": [
            {
                "id": "entity-1",
                "name": "Entity",
                "edges": [
                    {
                        "text": "edge",
                        "source_id": "source-1",
                        "target_id": "target-1",
                        "edge_object_id": "edge-1",
                    }
                ],
            }
        ],
    }

    with (
        patch.object(retriever, "_use_session_cache", return_value=True),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.get_session_manager",
            return_value=session_manager,
        ),
    ):
        turn_preparation = SessionTurnPreparation(effective_query="prepared q")
        completion = await retriever.get_completion_from_context(
            query="q",
            retrieved_objects=retrieved_objects,
            context="context",
            effective_query="prepared q",
            turn_preparation=turn_preparation,
        )

    assert completion == ["answer"]
    call_kwargs = session_manager.generate_completion_with_session.call_args.kwargs
    assert call_kwargs["session_id"] == "session-1"
    assert call_kwargs["used_graph_element_ids"] == {
        "node_ids": ["chunk-1", "entity-1", "source-1", "target-1"],
        "edge_ids": ["edge-1"],
    }
    assert call_kwargs["effective_query"] == "prepared q"
    assert call_kwargs["turn_preparation"] is turn_preparation


@pytest.mark.asyncio
async def test_context_object_id_extraction_skips_non_dict_entities():
    retriever = HybridRetriever(session_id="session-1")
    session_manager = MagicMock()
    session_manager.generate_completion_with_session = AsyncMock(return_value="answer")

    with (
        patch.object(retriever, "_use_session_cache", return_value=True),
        patch(
            "cognee.modules.retrieval.hybrid_retriever.get_session_manager",
            return_value=session_manager,
        ),
    ):
        await retriever.get_completion_from_context(
            query="q",
            retrieved_objects={
                "chunks": [_result("chunk-result", {"id": "chunk-1", "text": "Chunk"})],
                "entities": ["not-a-dict"],
            },
            context="context",
        )

    call_kwargs = session_manager.generate_completion_with_session.call_args.kwargs
    assert call_kwargs["used_graph_element_ids"] == {"node_ids": ["chunk-1"]}


def test_context_object_ids_omit_empty_edge_ids():
    retriever = HybridRetriever()
    used_ids = retriever.extract_context_object_ids(
        {
            "chunks": [_result("chunk-result", {"id": "chunk-1"})],
            "entities": [
                {
                    "id": "entity-1",
                    "edges": [{"source_id": "source-1", "target_id": "target-1"}],
                }
            ],
        }
    )

    assert used_ids == {"node_ids": ["chunk-1", "entity-1", "source-1", "target-1"]}
    assert "edge_ids" not in used_ids


@pytest.mark.asyncio
async def test_retrieved_entity_edges_expose_edge_object_id_for_session_ids():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Alice"}), ("acme-id", {"name": "Acme"})],
        edges=[
            (
                "entity-1",
                "acme-id",
                "works_at",
                {"edge_text": "Alice works at Acme.", "edge_object_id": "edge-1"},
            )
        ],
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["entities"][0]["edges"][0]["edge_object_id"] == "edge-1"
    assert retriever.extract_context_object_ids(retrieved)["edge_ids"] == ["edge-1"]


def _payload_text(chunk):
    if isinstance(chunk, dict):
        return chunk.get("text")
    return chunk.payload.get("text")


def _edge_hit(text):
    return _result(str(EdgeType.id_for(text)), {"text": text})


def _graph(nodes=None, edges=None):
    graph = MagicMock()
    graph.get_neighborhood = AsyncMock(return_value=(nodes or [], edges or []))
    return graph


@pytest.mark.asyncio
async def test_edge_hits_rank_entity_bullets_and_fill_facts_section():
    ranked_bullet = "Alice works at Acme."
    unranked_bullet = "Alice plays tennis."
    fact = "Acme acquired Initech."
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
        edge_types=[_edge_hit(fact), _edge_hit(ranked_bullet), _edge_hit("works at")],
    )
    graph = _graph(
        nodes=[
            ("entity-1", {"name": "Alice"}),
            ("tennis-id", {"name": "Tennis"}),
            ("acme-id", {"name": "Acme"}),
            ("person-id", {"name": "Person"}),
        ],
        edges=[
            ("entity-1", "tennis-id", "plays", {"edge_text": unranked_bullet}),
            ("entity-1", "acme-id", "works_at", {"edge_text": ranked_bullet}),
            ("entity-1", "person-id", "is_a", {}),
        ],
    )
    retriever = HybridRetriever(facts_top_k=2)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    bullets = [edge["text"] for edge in retrieved["entities"][0]["edges"]]
    assert bullets == ["Alice -- is_a -- Person", ranked_bullet, unranked_bullet]
    assert [item["text"] for item in retrieved["facts"]] == [fact]


@pytest.mark.asyncio
async def test_edge_between_two_retrieved_entities_appears_under_both():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[
            _result("alice-id", {"id": "alice-id", "name": "Alice"}),
            _result("acme-id", {"id": "acme-id", "name": "Acme"}),
        ]
    )
    graph = _graph(
        nodes=[("alice-id", {"name": "Alice"}), ("acme-id", {"name": "Acme"})],
        edges=[("alice-id", "acme-id", "works_at", {"edge_text": "Alice works at Acme."})],
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    bullet_texts = [[edge["text"] for edge in entity["edges"]] for entity in retrieved["entities"]]
    assert bullet_texts == [["Alice works at Acme."], ["Alice works at Acme."]]
    graph.get_neighborhood.assert_awaited_once_with(["alice-id", "acme-id"], depth=1)


@pytest.mark.asyncio
async def test_scoped_search_keeps_facts_expressed_by_scoped_entity_edges():
    ranked_bullet = "Alice works at Acme."
    capped_fact = "Alice plays tennis professionally."
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
        edge_types=[_edge_hit(ranked_bullet), _edge_hit(capped_fact)],
    )
    graph = _graph(
        nodes=[
            ("entity-1", {"name": "Alice", "belongs_to_set": ["KEN"]}),
            ("tennis-id", {"name": "Tennis", "belongs_to_set": ["KEN"]}),
            ("acme-id", {"name": "Acme", "belongs_to_set": ["KEN"]}),
        ],
        edges=[
            ("entity-1", "tennis-id", "plays", {"edge_text": capped_fact}),
            ("entity-1", "acme-id", "works_at", {"edge_text": ranked_bullet}),
        ],
    )
    retriever = HybridRetriever(node_name=["KEN"], max_edges_per_entity=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [item["text"] for item in retrieved["facts"]] == [capped_fact]
    assert _search_call(vector, "EdgeType_relationship_name").kwargs["node_name"] is None
    bullets = [edge["text"] for edge in retrieved["entities"][0]["edges"]]
    assert bullets == [ranked_bullet]


@pytest.mark.asyncio
async def test_facts_top_k_zero_disables_facts_and_sizes_edge_search_for_ranking():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
        edge_types=[_edge_hit("Alice works at Acme.")],
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Alice"}), ("acme-id", {"name": "Acme"})],
        edges=[("entity-1", "acme-id", "works_at", {"edge_text": "Alice works at Acme."})],
    )
    retriever = HybridRetriever(entities_top_k=4, max_edges_per_entity=3, facts_top_k=0)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["facts"] == []
    assert _search_call(vector, "EdgeType_relationship_name").kwargs["limit"] == 12
    assert retrieved["entities"][0]["edges"][0]["text"] == "Alice works at Acme."


@pytest.mark.asyncio
async def test_missing_edge_collection_keeps_bullets_and_returns_no_facts():
    vector = MagicMock()
    vector.search = _vector_search(
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
        missing_collections={"EdgeType_relationship_name"},
    )
    graph = _graph(
        nodes=[("entity-1", {"name": "Alice"}), ("acme-id", {"name": "Acme"})],
        edges=[("entity-1", "acme-id", "works_at", {"edge_text": "Alice works at Acme."})],
    )
    retriever = HybridRetriever()

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert retrieved["facts"] == []
    assert retrieved["entities"][0]["edges"][0]["text"] == "Alice works at Acme."


@pytest.mark.asyncio
async def test_graph_neighborhood_error_keeps_chunks_entities_and_facts():
    fact = "Acme acquired Initech."
    vector = MagicMock()
    vector.search = _vector_search(
        chunks=[_result("chunk-1", {"id": "chunk-1", "text": "Chunk text"})],
        entities=[_result("entity-1", {"id": "entity-1", "name": "Alice"})],
        edge_types=[_edge_hit(fact)],
    )
    graph = MagicMock()
    graph.get_neighborhood = AsyncMock(side_effect=RuntimeError("graph unavailable"))
    retriever = HybridRetriever(text_summaries_top_k=0, facts_top_k=1)

    with patch(
        "cognee.modules.retrieval.hybrid_retriever.get_unified_engine",
        new_callable=AsyncMock,
        return_value=_unified(vector=vector, graph=graph),
    ):
        retrieved = await retriever.get_retrieved_objects(query="q")

    assert [_payload_text(chunk) for chunk in retrieved["chunks"]] == ["Chunk text"]
    assert retrieved["entities"] == [
        {
            "id": "entity-1",
            "name": "Alice",
            "description": None,
            "type": None,
            "edges": [],
        }
    ]
    assert [item["text"] for item in retrieved["facts"]] == [fact]


@pytest.mark.asyncio
async def test_facts_section_renders_after_entities():
    retriever = HybridRetriever()

    context = await retriever.get_context_from_objects(
        query="q",
        retrieved_objects={
            "chunks": [_result(payload={"text": "Passage"})],
            "entities": [{"name": "Alice", "edges": [{"text": "Alice works at Acme."}]}],
            "facts": [{"id": "fact-1", "text": "Acme acquired Initech."}],
        },
    )

    assert context == (
        "## Relevant passages\nPassage\n\n"
        "## Relevant entities\n### Alice\n- Alice works at Acme.\n\n"
        "## Related facts\n- Acme acquired Initech."
    )
