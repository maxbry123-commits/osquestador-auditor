"""BeautifulSoup-based web crawler for extracting content from web pages.

This module provides the BeautifulSoupCrawler class for fetching and extracting content
from web pages using BeautifulSoup or Playwright for JavaScript-rendered pages. It
supports robots.txt handling, rate limiting, and custom extraction rules.
"""

from dataclasses import dataclass
from typing import Any

from bs4 import BeautifulSoup

from cognee.infrastructure.loaders.LoaderInterface import LoaderInterface
from cognee.shared.logging_utils import get_logger
from cognee.infrastructure.loaders.LoaderInterface import LoaderResult
from cognee.infrastructure.loaders.store_derived_text import store_derived_text

logger = get_logger(__name__)


@dataclass
class ExtractionRule:
    """Normalized extraction rule for web content.

    Attributes:
        selector: CSS selector for extraction (if any).
        xpath: XPath expression for extraction (if any).
        attr: HTML attribute to extract (if any).
        all: If True, extract all matching elements; otherwise, extract first.
        join_with: String to join multiple extracted elements.
    """

    selector: str | None = None
    xpath: str | None = None
    attr: str | None = None
    all: bool = False
    join_with: str = " "


class BeautifulSoupLoader(LoaderInterface):
    """Crawler for fetching and extracting web content using BeautifulSoup.

    Supports asynchronous HTTP requests, Playwright for JavaScript rendering, robots.txt
    compliance, and rate limiting. Extracts content using CSS selectors or XPath rules.

    Attributes:
        concurrency: Number of concurrent requests allowed.
        crawl_delay: Minimum seconds between requests to the same domain.
        max_crawl_delay: Maximum crawl delay to respect from robots.txt (None = no limit).
        timeout: Per-request timeout in seconds.
        max_retries: Number of retries for failed requests.
        retry_delay_factor: Multiplier for exponential backoff on retries.
        headers: HTTP headers for requests (e.g., User-Agent).
        robots_cache_ttl: Time-to-live for robots.txt cache in seconds.
    """

    loader_name = "beautiful_soup_loader"

    @property
    def supported_extensions(self) -> list[str]:
        return ["html"]

    @property
    def supported_mime_types(self) -> list[str]:
        return ["text/html", "text/plain"]

    def can_handle(self, extension: str, mime_type: str) -> bool:
        can = extension in self.supported_extensions and mime_type in self.supported_mime_types
        return can

    def _get_default_extraction_rules(self) -> dict[str, Any]:
        # Comprehensive default extraction rules for common HTML content
        return {
            # Meta information
            "title": {"selector": "title", "all": False},
            "meta_description": {
                "selector": "meta[name='description']",
                "attr": "content",
                "all": False,
            },
            "meta_keywords": {
                "selector": "meta[name='keywords']",
                "attr": "content",
                "all": False,
            },
            # Open Graph meta tags
            "og_title": {
                "selector": "meta[property='og:title']",
                "attr": "content",
                "all": False,
            },
            "og_description": {
                "selector": "meta[property='og:description']",
                "attr": "content",
                "all": False,
            },
            # Main content areas (prioritized selectors)
            "article": {"selector": "article", "all": True, "join_with": "\n\n"},
            "main": {"selector": "main", "all": True, "join_with": "\n\n"},
            # Semantic content sections
            "headers_h1": {"selector": "h1", "all": True, "join_with": "\n"},
            "headers_h2": {"selector": "h2", "all": True, "join_with": "\n"},
            "headers_h3": {"selector": "h3", "all": True, "join_with": "\n"},
            "headers_h4": {"selector": "h4", "all": True, "join_with": "\n"},
            "headers_h5": {"selector": "h5", "all": True, "join_with": "\n"},
            "headers_h6": {"selector": "h6", "all": True, "join_with": "\n"},
            # Text content
            "paragraphs": {"selector": "p", "all": True, "join_with": "\n\n"},
            "blockquotes": {"selector": "blockquote", "all": True, "join_with": "\n\n"},
            "preformatted": {"selector": "pre", "all": True, "join_with": "\n\n"},
            # Lists
            "ordered_lists": {"selector": "ol", "all": True, "join_with": "\n"},
            "unordered_lists": {"selector": "ul", "all": True, "join_with": "\n"},
            "list_items": {"selector": "li", "all": True, "join_with": "\n"},
            "definition_lists": {"selector": "dl", "all": True, "join_with": "\n"},
            # Tables
            "tables": {"selector": "table", "all": True, "join_with": "\n\n"},
            "table_captions": {
                "selector": "caption",
                "all": True,
                "join_with": "\n",
            },
            # Code blocks
            "code_blocks": {"selector": "code", "all": True, "join_with": "\n"},
            # Figures and media descriptions
            "figures": {"selector": "figure", "all": True, "join_with": "\n\n"},
            "figcaptions": {"selector": "figcaption", "all": True, "join_with": "\n"},
            "image_alts": {"selector": "img", "attr": "alt", "all": True, "join_with": " "},
            # Links (text content, not URLs to avoid clutter)
            "link_text": {"selector": "a", "all": True, "join_with": " "},
            # Emphasized text
            "strong": {"selector": "strong", "all": True, "join_with": " "},
            "emphasis": {"selector": "em", "all": True, "join_with": " "},
            "marked": {"selector": "mark", "all": True, "join_with": " "},
            # Time and data elements
            "time": {"selector": "time", "all": True, "join_with": " "},
            "data": {"selector": "data", "all": True, "join_with": " "},
            # Sections and semantic structure
            "sections": {"selector": "section", "all": True, "join_with": "\n\n"},
            "asides": {"selector": "aside", "all": True, "join_with": "\n\n"},
            "details": {"selector": "details", "all": True, "join_with": "\n"},
            "summary": {"selector": "summary", "all": True, "join_with": "\n"},
            # Navigation (may contain important links/structure)
            "nav": {"selector": "nav", "all": True, "join_with": "\n"},
            # Footer information
            "footer": {"selector": "footer", "all": True, "join_with": "\n"},
            # Divs with specific content roles
            "content_divs": {
                "selector": "div[role='main'], div[role='article'], div.content, div#content",
                "all": True,
                "join_with": "\n\n",
            },
        }

    async def load(
        self,
        file_path: str,
        extraction_rules: dict[str, Any] | None = None,
        join_all_matches: bool = False,
        **kwargs: Any,
    ) -> "str | LoaderResult":
        """Load an HTML file, extract content, and save to storage.

        Args:
            file_path: Path to the HTML file
            extraction_rules: Dict of CSS selector rules for content extraction
            join_all_matches: If True, extract all matching elements for each rule
            **kwargs: Additional arguments

        Returns:
            Path to the stored extracted text file
        """
        if extraction_rules is None:
            extraction_rules = self._get_default_extraction_rules()
            logger.info("Using default comprehensive extraction rules for HTML content")

        logger.info(f"Processing HTML file: {file_path}")

        from cognee.infrastructure.files.storage import get_file_storage, get_storage_config
        from cognee.infrastructure.files.utils.get_file_metadata import get_file_metadata

        with open(file_path, "rb") as f:
            file_metadata = await get_file_metadata(f)
            f.seek(0)
            html = f.read()

        storage_file_name = "text_" + file_metadata["content_hash"] + ".txt"

        # Normalize extraction rules
        normalized_rules: list[ExtractionRule] = []
        for _, rule in extraction_rules.items():
            r = self._normalize_rule(rule)
            if join_all_matches:
                r.all = True
            normalized_rules.append(r)

        soup = BeautifulSoup(html, "html.parser")
        pieces = []
        extracted_elements: set[int] = set()
        for rule in normalized_rules:
            text, new_elements = self._extract_from_html(soup, rule, extracted_elements, html)
            if text:
                pieces.append(text)
                extracted_elements.update(id(el) for el in new_elements if el is not None)

        full_content = " ".join(pieces).strip()

        # remove after defaults for extraction rules
        # Fallback: If no content extracted, check if the file is plain text (not HTML)
        if not full_content:
            soup = BeautifulSoup(html, "html.parser")
            # If there are no HTML tags, treat as plain text
            if not soup.find():
                logger.warning(
                    f"No HTML tags found in {file_path}. Treating as plain text. "
                    "This may happen when content is pre-extracted (e.g., via Tavily with text format)."
                )
                full_content = html.decode("utf-8") if isinstance(html, bytes) else html
                full_content = full_content.strip()

        if not full_content:
            logger.warning(f"No content extracted from HTML file: {file_path}")

        if not kwargs.get("persist", True):
            return full_content

        # Store the extracted content
        storage_config = get_storage_config()
        data_root_directory = storage_config["data_root_directory"]
        storage = get_file_storage(data_root_directory)

        logger.info(f"Extracted {len(full_content)} characters from HTML")
        return await store_derived_text(storage, storage_file_name, full_content)

    def _normalize_rule(self, rule: str | dict[str, Any]) -> ExtractionRule:
        """Normalize an extraction rule to an ExtractionRule dataclass.

        Args:
            rule: A string (CSS selector) or dict with extraction parameters.

        Returns:
            ExtractionRule: Normalized extraction rule.

        Raises:
            ValueError: If the rule is invalid.
        """
        if isinstance(rule, str):
            return ExtractionRule(selector=rule)
        if isinstance(rule, dict):
            return ExtractionRule(
                selector=rule.get("selector"),
                xpath=rule.get("xpath"),
                attr=rule.get("attr"),
                all=bool(rule.get("all", False)),
                join_with=rule.get("join_with", " "),
            )
        raise ValueError(f"Invalid extraction rule: {rule}")

    def _extract_from_html(
        self,
        soup: BeautifulSoup,
        rule: ExtractionRule,
        extracted_elements: set[int] | None = None,
        html: bytes | None = None,
    ) -> tuple[str, list[Any]]:
        """Extract content from a BeautifulSoup parsed document.

        Args:
            soup: BeautifulSoup parsed document.
            rule: The extraction rule to apply.
            extracted_elements: Set of element ids already extracted by broader rules.
                Elements that are descendants of these will be skipped.
            html: Raw bytes needed for XPath extraction (lxml parses from bytes).

        Returns:
            tuple[str, list[Any]]: The extracted content and the list of elements extracted.

        Raises:
            RuntimeError: If XPath is used but lxml is not installed.
        """
        extracted_elements = extracted_elements or set()

        if rule.xpath:
            try:
                from lxml import html as lxml_html  # ty:ignore[unresolved-import]
            except ImportError:
                raise RuntimeError(
                    "XPath requested but lxml is not available. Install lxml or use CSS selectors."
                )
            if html is None:
                return "", []
            doc = lxml_html.fromstring(html)
            nodes = doc.xpath(rule.xpath)
            texts = []
            for n in nodes:
                if hasattr(n, "text_content"):
                    texts.append(n.text_content().strip())
                else:
                    texts.append(str(n).strip())
            return rule.join_with.join(t for t in texts if t), []

        if not rule.selector:
            return "", []

        if rule.all:
            nodes = soup.select(rule.selector)
            pieces = []
            used_nodes = []
            for el in nodes:
                if any(ancestor in extracted_elements for ancestor in (id(p) for p in el.parents)):
                    continue
                if rule.attr:
                    val = el.get(rule.attr)
                    if val:
                        pieces.append(val.strip())  # ty:ignore[unresolved-attribute]
                        used_nodes.append(el)
                else:
                    text = el.get_text(strip=True)
                    if text:
                        pieces.append(text)
                        used_nodes.append(el)
            return rule.join_with.join(pieces).strip(), used_nodes
        else:
            el = soup.select_one(rule.selector)
            if el is None:
                return "", []
            if any(ancestor in extracted_elements for ancestor in (id(p) for p in el.parents)):
                return "", []
            if rule.attr:
                val = el.get(rule.attr)
                return (val or "").strip(), [el]  # ty:ignore[unresolved-attribute]
            return el.get_text(strip=True), [el]
