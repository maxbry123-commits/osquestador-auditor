from uuid import UUID

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from fastapi import Depends, status
from pydantic import Field
from typing import List, Optional, Union, Literal

from cognee.api.DTO import InDTO
from cognee.modules.users.models import User
from cognee.modules.users.methods import get_authenticated_user
from cognee.exceptions import CogneeApiError
from cognee.shared.utils import send_telemetry
from cognee.modules.pipelines.models import PipelineRunErrored
from cognee.shared.logging_utils import get_logger
from cognee.shared.usage_logger import log_usage
from cognee import __version__ as cognee_version
from cognee.api.DTO import ErrorResponse

logger = get_logger()


class MemifyPayloadDTO(InDTO):
    extraction_tasks: Optional[List[str]] = Field(
        default=None,
        examples=[[]],
    )
    enrichment_tasks: Optional[List[str]] = Field(default=None, examples=[[]])
    data: Optional[str] = Field(default=None)
    dataset_name: Optional[str] = Field(default=None)
    # Note: Literal is needed for Swagger use
    dataset_id: Union[UUID, Literal[""], None] = Field(default=None, examples=[""])
    node_name: Optional[List[str]] = Field(default=None, examples=[[]])
    run_in_background: Optional[bool] = Field(default=False)


def get_memify_router() -> APIRouter:
    router = APIRouter()

    @router.post(
        "",
        response_model=dict,
        responses={
            400: {"model": ErrorResponse},
            403: {"model": ErrorResponse},
            422: {"model": ErrorResponse},
            500: {"model": ErrorResponse},
        },
    )
    @log_usage(function_name="POST /v1/memify", log_type="api_endpoint")
    async def memify(payload: MemifyPayloadDTO, user: User = Depends(get_authenticated_user)):
        """
        Enrichment pipeline in Cognee, can work with already built graphs. If no data is provided existing knowledge graph will be used as data,
        custom data can also be provided instead which can be processed with provided extraction and enrichment tasks.

        Provided tasks and data will be arranged to run the Cognee pipeline and execute graph enrichment/creation.

        ## Request Parameters
        - **extractionTasks** Optional[List[str]]: Names of built-in Cognee Tasks to execute for graph/data extraction.
              Supported names: extract_subgraph, extract_subgraph_chunks, get_triplet_datapoints,
              extract_user_sessions, extract_agent_trace_feedbacks, detect_entity_duplicates.
              Unknown names are rejected with 422. Tasks requiring parameters are SDK-only.
        - **enrichmentTasks** Optional[List[str]]: Names of built-in Cognee Tasks to handle enrichment of provided graph/data from extraction tasks.
              Supported names: cognify_session, cognify_agent_trace_feedback, apply_feedback_weights,
              apply_frequency_weights, merge_entity_duplicates, index_data_points.
        - **data** Optional[List[str]]: The data to ingest. Can be any text data when custom extraction and enrichment tasks are used.
              Data provided here will be forwarded to the first extraction task in the pipeline as input.
              If no data is provided the whole graph (or subgraph if node_name/node_type is specified) will be forwarded
        - **dataset_name** (Optional[str]): Name of the datasets to memify
        - **dataset_id** (Optional[UUID]): List of UUIDs of an already existing dataset
        - **node_name** (Optional[List[str]]):  Filter graph to specific named entities (for targeted search). Used when no data is provided.
        - **run_in_background** (Optional[bool]): Whether to execute processing asynchronously. Defaults to False (blocking).

        Either datasetName or datasetId must be provided.

        ## Response
        Returns information about the add operation containing:
        - Status of the operation
        - Details about the processed data
        - Any relevant metadata from the ingestion process

        ## Error Codes
        - **400 Bad Request**: Neither datasetId nor datasetName provided
        - **409 Conflict**: Error during memify operation
        - **403 Forbidden**: User doesn't have permission to use dataset
        - **422 Unprocessable Content**: Unknown task name in extractionTasks/enrichmentTasks

        ## Notes
        - To memify datasets not owned by the user, use dataset_id (when ENABLE_BACKEND_ACCESS_CONTROL is set to True)
        - datasetId value can only be the UUID of an already existing dataset
        """

        send_telemetry(
            "Memify API Endpoint Invoked",
            user,
            additional_properties={"endpoint": "POST /v1/memify", "cognee_version": cognee_version},
        )

        if not payload.dataset_id and not payload.dataset_name:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content=ErrorResponse(
                    error="Either datasetId or datasetName must be provided.",
                ).model_dump(),
            )

        try:
            from cognee.modules.memify import memify as cognee_memify

            memify_run = await cognee_memify(
                extraction_tasks=payload.extraction_tasks,
                enrichment_tasks=payload.enrichment_tasks,
                data=payload.data,
                dataset=payload.dataset_id if payload.dataset_id else payload.dataset_name,
                node_name=payload.node_name,
                user=user,
                run_in_background=payload.run_in_background,
            )

            if isinstance(memify_run, PipelineRunErrored):
                # The failing task's error is carried on ``payload`` (set to
                # ``repr(error)`` by the pipeline runner); PipelineRunErrored has
                # no ``error`` attribute. Surface it so the client gets an
                # actionable message instead of the model's repr.
                payload = memify_run.payload if isinstance(memify_run.payload, str) else None
                detail = payload or str(memify_run)

                return JSONResponse(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content=ErrorResponse(
                        error="Pipeline run errored",
                        detail=detail,
                    ).model_dump(),
                )
            return memify_run
        except CogneeApiError as error:
            logger.exception("Memify failed")
            return JSONResponse(
                status_code=error.status_code,
                content=ErrorResponse(
                    error=error.message,
                ).model_dump(),
            )
        except Exception as error:
            logger.exception("Memify failed")
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content=ErrorResponse(
                    error="Internal server error",
                    detail=str(error),
                ).model_dump(),
            )

    return router
