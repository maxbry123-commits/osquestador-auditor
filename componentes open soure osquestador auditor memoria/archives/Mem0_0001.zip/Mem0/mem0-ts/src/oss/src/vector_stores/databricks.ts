import axios, { AxiosInstance } from "axios";
import { VectorStore } from "./base";
import { SearchFilters, VectorStoreConfig, VectorStoreResult } from "../types";

const SAFE_IDENTIFIER_RE = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;
const DEFAULT_PAGE_SIZE = 100;
const MAX_QUERY_RESULTS = 10_000;
const MAX_FULL_TEXT_RESULTS = 200;
const DEFAULT_SYNC_POLL_INTERVAL_MS = 1000;
const DEFAULT_SYNC_TIMEOUT_MS = 5 * 60 * 1000;
const DATABRICKS_SERVER_FILTER_KEYS = new Set([
  "memory_id",
  "user_id",
  "agent_id",
  "run_id",
]);

interface DatabricksConfig extends VectorStoreConfig {
  workspaceUrl?: string;
  host?: string;
  httpPath: string;
  accessToken?: string;
  clientId?: string;
  clientSecret?: string;
  endpointName?: string;
  endpointType?: "STANDARD" | "STORAGE_OPTIMIZED";
  pipelineType?: "TRIGGERED" | "CONTINUOUS";
  queryType?: "ANN" | "HYBRID";
  catalog?: string;
  schema?: string;
  tableName?: string;
  embeddingModelDims?: number;
  syncPollIntervalMs?: number;
  syncTimeoutMs?: number;
  sqlClient?: DatabricksSqlClientLike;
  httpClient?: DatabricksHttpClientLike;
}

interface DatabricksSqlClientLike {
  connect(options: Record<string, any>): Promise<DatabricksSqlClientLike>;
  openSession(): Promise<DatabricksSqlSessionLike>;
  close?(): Promise<any>;
}

interface DatabricksSqlSessionLike {
  executeStatement(statement: string): Promise<DatabricksSqlOperationLike>;
  close?(): Promise<any>;
}

interface DatabricksSqlOperationLike {
  fetchAll(): Promise<Array<Record<string, any>>>;
  close?(): Promise<any>;
}

interface DatabricksHttpClientLike {
  get(url: string, config?: Record<string, any>): Promise<{ data: any }>;
  post(
    url: string,
    data?: any,
    config?: Record<string, any>,
  ): Promise<{ data: any }>;
  delete(url: string, config?: Record<string, any>): Promise<{ data: any }>;
}

interface DatabricksVector {
  id: string;
  payload: Record<string, any>;
}

function buildDatabricksAuthorizationDetails(
  indexName: string,
  operation: "ReadVectorIndex" | "WriteVectorIndex",
): string {
  return JSON.stringify([
    {
      type: "unity_catalog_permission",
      securable_type: "table",
      securable_object_name: indexName,
      operation,
    },
  ]);
}

function validateIdentifier(
  name: string,
  label: string = "identifier",
): string {
  if (!SAFE_IDENTIFIER_RE.test(name)) {
    throw new Error(
      `Invalid ${label} '${name}': only letters, digits, and underscores are allowed, ` +
        `must start with a letter or underscore, and be at most 128 characters.`,
    );
  }
  return name;
}

function extractHostAndWorkspaceUrl(config: DatabricksConfig): {
  host: string;
  workspaceUrl: string;
} {
  if (config.workspaceUrl) {
    const url = new URL(config.workspaceUrl);
    return {
      host: url.host,
      workspaceUrl: `${url.protocol}//${url.host}`,
    };
  }

  if (config.host) {
    return {
      host: config.host,
      workspaceUrl: `https://${config.host}`,
    };
  }

  throw new Error(
    "Databricks vector store requires either workspaceUrl or host.",
  );
}

// `Memory.search()` hands keywordSearch() an already-lemmatized query, so BM25 has to score
// against lemmatized text. Same contract as baidu.ts / pgvector.ts.
function lemmatizedText(payload: Record<string, any>): string {
  const data = typeof payload.data === "string" ? payload.data : "";
  return typeof payload.textLemmatized === "string" &&
    payload.textLemmatized.length > 0
    ? payload.textLemmatized
    : data;
}

function formatSqlValue(value: any): string {
  if (value === null || value === undefined) {
    return "NULL";
  }
  if (typeof value === "boolean") {
    return value ? "TRUE" : "FALSE";
  }
  if (typeof value === "number") {
    if (!Number.isFinite(value)) {
      throw new Error("Databricks vector store only accepts finite numbers.");
    }
    return String(value);
  }
  if (Array.isArray(value)) {
    return `array(${value.map((entry) => formatSqlValue(entry)).join(", ")})`;
  }
  const json =
    typeof value === "string" ? value : JSON.stringify(value ?? {}) || "{}";
  // Databricks/Spark SQL treats backslash as an escape char in string literals,
  // so a trailing "\" would consume the closing quote (breaking out of the
  // literal) and any backslash would be dropped on write. Escape backslashes
  // before doubling quotes so the literal is injection-safe and round-trips.
  const escaped = json.replace(/\\/g, "\\\\").replace(/'/g, "''");
  return `'${escaped}'`;
}

function extractRowValue(row: Record<string, any>, keys: string[]): any {
  for (const key of keys) {
    if (key in row) {
      return row[key];
    }
    const upper = key.toUpperCase();
    if (upper in row) {
      return row[upper];
    }
  }
  return undefined;
}

function isPlainObject(value: any): value is Record<string, any> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeFilterValue(value: any): any {
  if (Array.isArray(value)) {
    return value.map((entry) => normalizeFilterValue(entry));
  }
  return value;
}

function isDatabricksServerFilterKey(key: string): boolean {
  return DATABRICKS_SERVER_FILTER_KEYS.has(key);
}

function mergeDatabricksFilters(
  target: Record<string, any>,
  source: Record<string, any>,
): boolean {
  for (const [key, value] of Object.entries(source)) {
    if (
      key in target &&
      JSON.stringify(target[key]) !== JSON.stringify(value)
    ) {
      return false;
    }
    target[key] = value;
  }
  return true;
}

function buildSimpleDatabricksFilter(
  key: string,
  value: any,
): Record<string, any> | null {
  if (!isDatabricksServerFilterKey(key)) {
    return null;
  }

  const safeKey = validateIdentifier(key, "filter key");

  if (!isPlainObject(value)) {
    return {
      [safeKey]: normalizeFilterValue(value),
    };
  }

  const entries = Object.entries(value);
  if (entries.length !== 1) {
    return null;
  }

  const [operator, operand] = entries[0];
  switch (operator) {
    case "eq":
      return { [safeKey]: normalizeFilterValue(operand) };
    case "ne":
      return { [`${safeKey} NOT`]: normalizeFilterValue(operand) };
    case "gt":
      return { [`${safeKey} >`]: normalizeFilterValue(operand) };
    case "gte":
      return { [`${safeKey} >=`]: normalizeFilterValue(operand) };
    case "lt":
      return { [`${safeKey} <`]: normalizeFilterValue(operand) };
    case "lte":
      return { [`${safeKey} <=`]: normalizeFilterValue(operand) };
    case "in":
      return Array.isArray(operand)
        ? { [safeKey]: normalizeFilterValue(operand) }
        : null;
    case "nin":
      return Array.isArray(operand) && operand.length === 1
        ? { [`${safeKey} NOT`]: normalizeFilterValue(operand[0]) }
        : null;
    default:
      return null;
  }
}

function buildStandardDatabricksFiltersFromClauses(
  clauses: Array<[string, any]>,
): Record<string, any> | undefined {
  const result: Record<string, any> = {};

  for (const [key, value] of clauses) {
    const translated = buildSimpleDatabricksFilter(key, value);
    if (!translated) {
      continue;
    }
    if (!mergeDatabricksFilters(result, translated)) {
      return undefined;
    }
  }

  return Object.keys(result).length > 0 ? result : undefined;
}

function buildStorageOptimizedDatabricksFilterClause(
  key: string,
  value: any,
): string | null {
  if (!isDatabricksServerFilterKey(key)) {
    return null;
  }

  const safeKey = validateIdentifier(key, "filter key");

  if (!isPlainObject(value)) {
    if (Array.isArray(value)) {
      return value.length > 0
        ? `${safeKey} IN (${value
            .map((entry) => formatSqlValue(normalizeFilterValue(entry)))
            .join(", ")})`
        : null;
    }
    return `${safeKey} = ${formatSqlValue(normalizeFilterValue(value))}`;
  }

  const entries = Object.entries(value);
  if (entries.length !== 1) {
    return null;
  }

  const [operator, operand] = entries[0];
  switch (operator) {
    case "eq":
      return `${safeKey} = ${formatSqlValue(normalizeFilterValue(operand))}`;
    case "ne":
      // SQL three-valued logic: `col != x` is NULL (excluded) when col IS NULL,
      // but the local matcher keeps rows with a missing field for `ne`. Match it.
      return `(${safeKey} IS NULL OR ${safeKey} != ${formatSqlValue(normalizeFilterValue(operand))})`;
    case "gt":
      return `${safeKey} > ${formatSqlValue(normalizeFilterValue(operand))}`;
    case "gte":
      return `${safeKey} >= ${formatSqlValue(normalizeFilterValue(operand))}`;
    case "lt":
      return `${safeKey} < ${formatSqlValue(normalizeFilterValue(operand))}`;
    case "lte":
      return `${safeKey} <= ${formatSqlValue(normalizeFilterValue(operand))}`;
    case "in":
      return Array.isArray(operand) && operand.length > 0
        ? `${safeKey} IN (${operand
            .map((entry) => formatSqlValue(normalizeFilterValue(entry)))
            .join(", ")})`
        : null;
    case "nin":
      // Same NULL-handling as `ne` above.
      return Array.isArray(operand) && operand.length > 0
        ? `(${safeKey} IS NULL OR ${safeKey} NOT IN (${operand
            .map((entry) => formatSqlValue(normalizeFilterValue(entry)))
            .join(", ")}))`
        : null;
    default:
      return null;
  }
}

function collectConjunctiveDatabricksFilters(
  filters?: SearchFilters,
): Array<[string, any]> {
  if (!filters || Object.keys(filters).length === 0) {
    return [];
  }

  const clauses: Array<[string, any]> = [];

  for (const [key, value] of Object.entries(filters)) {
    if (key === "$and") {
      if (!Array.isArray(value)) {
        continue;
      }
      for (const entry of value) {
        if (!isPlainObject(entry)) {
          continue;
        }
        clauses.push(...collectConjunctiveDatabricksFilters(entry));
      }
      continue;
    }

    if (key === "$or" || key === "$not") {
      continue;
    }

    clauses.push([key, value]);
  }

  return clauses;
}

// True iff `filters` has no `$or`/`$not` at any nesting depth (recursing through
// `$and`), i.e. every entry is something collectConjunctiveDatabricksFilters can see.
function isFullyConjunctiveDatabricksFilter(filters?: SearchFilters): boolean {
  if (!filters || Object.keys(filters).length === 0) {
    return true;
  }

  for (const [key, value] of Object.entries(filters)) {
    if (key === "$and") {
      if (!Array.isArray(value)) {
        return false;
      }
      if (
        value.some(
          (entry) =>
            !isPlainObject(entry) ||
            !isFullyConjunctiveDatabricksFilter(entry as SearchFilters),
        )
      ) {
        return false;
      }
      continue;
    }

    if (key === "$or" || key === "$not") {
      return false;
    }
  }

  return true;
}

function buildDatabricksServerFilters(
  endpointType: "STANDARD" | "STORAGE_OPTIMIZED",
  filters?: SearchFilters,
): { filters?: string; filters_json?: string } {
  const clauses = collectConjunctiveDatabricksFilters(filters);

  if (clauses.length === 0) {
    return {};
  }

  if (endpointType === "STORAGE_OPTIMIZED") {
    const translatedClauses = clauses
      .map(([key, value]) =>
        buildStorageOptimizedDatabricksFilterClause(key, value),
      )
      .filter((clause): clause is string => Boolean(clause));

    return translatedClauses.length > 0
      ? { filters: translatedClauses.join(" AND ") }
      : {};
  }

  const translatedFilters = buildStandardDatabricksFiltersFromClauses(clauses);

  return translatedFilters
    ? { filters_json: JSON.stringify(translatedFilters) }
    : {};
}

export class DatabricksVectorStore implements VectorStore {
  private readonly host: string;
  private readonly workspaceUrl: string;
  private readonly httpPath: string;
  private readonly accessToken?: string;
  private readonly clientId?: string;
  private readonly clientSecret?: string;
  private readonly endpointName: string;
  private readonly endpointType: "STANDARD" | "STORAGE_OPTIMIZED";
  private readonly pipelineType: "TRIGGERED" | "CONTINUOUS";
  private readonly queryType: "ANN" | "HYBRID";
  private readonly dimension: number;
  private readonly catalog: string;
  private readonly schema: string;
  private readonly tableName: string;
  private readonly indexName: string;
  private readonly fullTableName: string;
  private readonly fullIndexName: string;
  private readonly syncPollIntervalMs: number;
  private readonly syncTimeoutMs: number;
  private sqlClient: DatabricksSqlClientLike | null;
  private readonly httpClient: DatabricksHttpClientLike;
  private session?: DatabricksSqlSessionLike;
  private _sessionPromise?: Promise<DatabricksSqlSessionLike>;
  private _initPromise?: Promise<void>;
  private sqlModulePromise?: Promise<{
    DBSQLClient: new () => DatabricksSqlClientLike;
  }>;
  private indexSyncWait: Promise<void> | null = null;
  private indexSyncRunning = false;
  private indexSyncQueued = false;
  private indexSyncError: unknown = null;
  private readonly oauthTokens = new Map<
    string,
    { accessToken: string; expiresAt: number }
  >();

  constructor(config: DatabricksConfig) {
    const { host, workspaceUrl } = extractHostAndWorkspaceUrl(config);

    this.host = host;
    this.workspaceUrl = workspaceUrl;
    this.httpPath = config.httpPath;
    this.accessToken = config.accessToken;
    this.clientId = config.clientId;
    this.clientSecret = config.clientSecret;
    this.endpointName = config.endpointName || "mem0_vector_search";
    this.endpointType = config.endpointType || "STANDARD";
    this.pipelineType = config.pipelineType || "TRIGGERED";
    this.queryType = config.queryType || "ANN";
    this.dimension = config.embeddingModelDims || config.dimension || 1536;
    this.catalog = validateIdentifier(config.catalog || "main", "catalog");
    this.schema = validateIdentifier(config.schema || "default", "schema");
    this.indexName = validateIdentifier(
      config.collectionName || "mem0",
      "collectionName",
    );
    this.tableName = validateIdentifier(
      config.tableName || this.indexName,
      "tableName",
    );
    this.fullTableName = `${this.catalog}.${this.schema}.${this.tableName}`;
    this.fullIndexName = `${this.catalog}.${this.schema}.${this.indexName}`;
    this.syncPollIntervalMs =
      config.syncPollIntervalMs ?? DEFAULT_SYNC_POLL_INTERVAL_MS;
    this.syncTimeoutMs = config.syncTimeoutMs ?? DEFAULT_SYNC_TIMEOUT_MS;
    this.sqlClient = config.sqlClient ?? null;
    this.httpClient = config.httpClient || this.createHttpClient();

    if (
      this.endpointType === "STORAGE_OPTIMIZED" &&
      this.pipelineType !== "TRIGGERED"
    ) {
      throw new Error(
        "Databricks storage-optimized endpoints only support TRIGGERED pipelineType.",
      );
    }

    if (
      this.endpointType === "STORAGE_OPTIMIZED" &&
      this.dimension % 16 !== 0
    ) {
      throw new Error(
        "Databricks storage-optimized endpoints require dimensions divisible by 16.",
      );
    }

    this.initialize().catch(console.error);
  }

  async initialize(): Promise<void> {
    if (!this._initPromise) {
      this._initPromise = this._doInitialize().catch((error) => {
        // A failed init (e.g. a cold/auto-suspended warehouse at startup) must not be cached
        // forever -- clear it so the next public call retries instead of replaying the
        // rejection. Every step is idempotent (CREATE ... IF NOT EXISTS / ensure*), so a
        // retry is safe.
        this._initPromise = undefined;
        throw error;
      });
    }
    return this._initPromise;
  }

  private async _doInitialize(): Promise<void> {
    await this.executeSql(
      `CREATE SCHEMA IF NOT EXISTS ${this.catalog}.${this.schema}`,
    );
    await this.executeSql(`
      CREATE TABLE IF NOT EXISTS ${this.fullTableName} (
        memory_id STRING,
        embedding ARRAY<FLOAT>,
        payload STRING,
        text_lemmatized STRING,
        user_id STRING,
        agent_id STRING,
        run_id STRING
      ) USING DELTA
      TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    `);
    await this.ensureChangeDataFeedEnabled();
    await this.executeSql(`
      CREATE TABLE IF NOT EXISTS ${this.catalog}.${this.schema}.memory_migrations (
        user_id STRING
      ) USING DELTA
    `);

    await this.ensureEndpointExists();
    await this.waitForEndpointReadiness();
    await this.ensureIndexExists();
    await this.waitForIndexReadiness();
  }

  async insert(
    vectors: number[][],
    ids: string[],
    payloads: Record<string, any>[],
  ): Promise<void> {
    await this.initialize();

    const values = vectors.map((vector, index) => {
      this.assertVectorDimension(vector, "Vector");
      const payload = payloads[index] || {};
      const sessionValues = this.extractSessionValues(payload);
      return `(
        ${formatSqlValue(ids[index])},
        ${formatSqlValue(vector)},
        ${formatSqlValue(JSON.stringify(payload))},
        ${formatSqlValue(lemmatizedText(payload))},
        ${formatSqlValue(sessionValues.user_id)},
        ${formatSqlValue(sessionValues.agent_id)},
        ${formatSqlValue(sessionValues.run_id)}
      )`;
    });

    await this.executeSql(`
      INSERT INTO ${this.fullTableName}
        (memory_id, embedding, payload, text_lemmatized, user_id, agent_id, run_id)
      VALUES ${values.join(", ")}
    `);
    this.requestIndexSync();
  }

  async search(
    query: number[],
    topK: number = 5,
    filters?: SearchFilters,
  ): Promise<VectorStoreResult[]> {
    await this.initialize();
    this.assertVectorDimension(query, "Query");

    if (this.queryType === "HYBRID") {
      throw new Error(
        "Databricks HYBRID search requires query_text, but search() only receives query vectors.",
      );
    }

    const requestFilters = buildDatabricksServerFilters(
      this.endpointType,
      filters,
    );

    return this.queryIndex(
      {
        columns: ["memory_id", "payload"],
        query_type: this.queryType,
        query_vector: query,
        ...requestFilters,
      },
      filters,
      topK,
    );
  }

  async keywordSearch(
    query: string,
    topK: number = 5,
    filters?: SearchFilters,
  ): Promise<VectorStoreResult[] | null> {
    await this.initialize();
    const requestFilters = buildDatabricksServerFilters(
      this.endpointType,
      filters,
    );

    // ponytail: `text_lemmatized` is synced so BM25 has clean text to score, but this query
    // does not scope matching to it -- the `query_columns` parameter that would is Beta and
    // gated behind the Full-Text Search public preview. Until it is GA the serialized
    // `payload` column is also matchable, which adds noise (hashes, JSON keys) to ranking.
    // Upgrade path: add `query_columns: ["text_lemmatized"]` once the preview ships.
    return this.queryIndex(
      {
        columns: ["memory_id", "payload"],
        query_type: "FULL_TEXT",
        query_text: query,
        ...requestFilters,
      },
      filters,
      topK,
    );
  }

  async get(vectorId: string): Promise<VectorStoreResult | null> {
    await this.initialize();

    const rows = await this.executeSql(`
      SELECT memory_id, payload
      FROM ${this.fullTableName}
      WHERE memory_id = ${formatSqlValue(vectorId)}
      LIMIT 1
    `);
    const row = rows[0];

    if (!row) {
      return null;
    }

    return {
      id: String(extractRowValue(row, ["memory_id"]) || vectorId),
      payload: this.parsePayload(extractRowValue(row, ["payload"])),
    };
  }

  async update(
    vectorId: string,
    vector: number[],
    payload: Record<string, any>,
  ): Promise<void> {
    await this.initialize();
    this.assertVectorDimension(vector, "Vector");

    // Session columns (user_id/agent_id/run_id) are the scope keys that search/list filter on and
    // are written once at insert(). Mirror Python's `excluded_keys`: update() must never rewrite
    // them from the payload -- a partial payload that omits these keys would otherwise SET them to
    // NULL and hide the row from every session-scoped search and list().
    await this.executeSql(`
      UPDATE ${this.fullTableName}
      SET embedding = ${formatSqlValue(vector)},
          payload = ${formatSqlValue(JSON.stringify(payload || {}))},
          text_lemmatized = ${formatSqlValue(lemmatizedText(payload || {}))}
      WHERE memory_id = ${formatSqlValue(vectorId)}
    `);
    this.requestIndexSync();
  }

  async delete(vectorId: string): Promise<void> {
    await this.initialize();

    await this.executeSql(`
      DELETE FROM ${this.fullTableName}
      WHERE memory_id = ${formatSqlValue(vectorId)}
    `);
    this.requestIndexSync();
  }

  async deleteCol(): Promise<void> {
    await this.initialize();

    try {
      await this.httpClient.delete(
        `/indexes/${encodeURIComponent(this.fullIndexName)}`,
      );
    } catch (error: any) {
      if (error?.response?.status !== 404) {
        throw error;
      }
    }

    await this.executeSql(`DROP TABLE IF EXISTS ${this.fullTableName}`);
  }

  async list(
    filters?: SearchFilters,
    topK: number = 100,
  ): Promise<[VectorStoreResult[], number]> {
    // `limit` below is interpolated directly into the SQL string (not a bound parameter,
    // and not passed through formatSqlValue()), so a non-integer or non-positive topK must
    // be rejected here rather than reaching the query -- otherwise a caller that skips
    // TypeScript's compile-time check (e.g. anything passing user input straight through)
    // could inject arbitrary SQL via the LIMIT clause.
    if (!Number.isSafeInteger(topK) || topK <= 0) {
      // isSafeInteger (not isInteger): an unsafe/huge integer like 1e21 stringifies as "1e+21",
      // which is meaningless as a LIMIT and would slip past a plain integer check.
      throw new Error(
        `Databricks vector store: topK must be a positive integer, got ${topK}`,
      );
    }

    await this.initialize();

    // Push the SQL-translatable conjunctive filters (session keys) into a WHERE
    // clause so a filtered list does not pull the whole table to the client.
    // filterVector below still enforces the complete filter, so this clause is a
    // best-effort narrowing: untranslatable filters ($or/$not/metadata) yield an
    // empty clause and fall back to a bounded scan (see LIMIT below) + local filtering.
    const conjunctiveFilters = collectConjunctiveDatabricksFilters(filters);
    const clauses = conjunctiveFilters.map(([key, value]) =>
      buildStorageOptimizedDatabricksFilterClause(key, value),
    );
    const whereClause = clauses
      .filter((clause): clause is string => Boolean(clause))
      .join(" AND ");

    // The WHERE clause fully expresses `filters` (so filterVector below is a
    // no-op) only if there's no $or/$not anywhere AND every entry translated.
    const isFullyExpressed =
      isFullyConjunctiveDatabricksFilter(filters) &&
      clauses.every((clause) => clause !== null);
    // ponytail: 10k scan ceiling when the filter can't be fully pushed down; paginate if a user hits it.
    const limit = isFullyExpressed ? topK : MAX_QUERY_RESULTS;

    const rows = await this.executeSql(`
      SELECT memory_id, payload
      FROM ${this.fullTableName}
      ${whereClause ? `WHERE ${whereClause}` : ""}
      LIMIT ${limit}
    `);
    const results: VectorStoreResult[] = [];

    for (const row of rows) {
      const item: DatabricksVector = {
        id: String(extractRowValue(row, ["memory_id"])),
        payload: this.parsePayload(extractRowValue(row, ["payload"])),
      };
      if (!this.filterVector(item, filters)) {
        continue;
      }
      results.push({
        id: item.id,
        payload: item.payload,
      });
    }

    return [results.slice(0, topK), results.length];
  }

  async getUserId(): Promise<string> {
    await this.initialize();

    const rows = await this.executeSql(`
      SELECT user_id
      FROM ${this.catalog}.${this.schema}.memory_migrations
      LIMIT 1
    `);
    const existing = rows[0]
      ? extractRowValue(rows[0], ["user_id"])
      : undefined;

    if (typeof existing === "string" && existing.length > 0) {
      return existing;
    }

    const userId =
      Math.random().toString(36).substring(2, 15) +
      Math.random().toString(36).substring(2, 15);
    await this.setUserId(userId);
    return userId;
  }

  async setUserId(userId: string): Promise<void> {
    await this.initialize();

    await this.executeSql(
      `DELETE FROM ${this.catalog}.${this.schema}.memory_migrations`,
    );
    await this.executeSql(`
      INSERT INTO ${this.catalog}.${this.schema}.memory_migrations (user_id)
      VALUES (${formatSqlValue(userId)})
    `);
  }

  private async ensureEndpointExists(): Promise<void> {
    try {
      await this.httpClient.get(
        `/endpoints/${encodeURIComponent(this.endpointName)}`,
      );
    } catch (error: any) {
      if (error?.response?.status !== 404) {
        throw error;
      }

      await this.httpClient.post("/endpoints", {
        name: this.endpointName,
        endpoint_type: this.endpointType,
      });
    }
  }

  private async ensureIndexExists(): Promise<void> {
    try {
      await this.httpClient.get(
        `/indexes/${encodeURIComponent(this.fullIndexName)}`,
      );
    } catch (error: any) {
      if (error?.response?.status !== 404) {
        throw error;
      }

      await this.httpClient.post("/indexes", {
        name: this.fullIndexName,
        endpoint_name: this.endpointName,
        primary_key: "memory_id",
        index_type: "DELTA_SYNC",
        delta_sync_index_spec: {
          source_table: this.fullTableName,
          pipeline_type: this.pipelineType,
          // ponytail: `payload` stays synced because query results are hydrated straight
          // from it. Drop it here and hydrate by memory_id over SQL if index size bites.
          columns_to_sync:
            this.endpointType === "STANDARD"
              ? [
                  "memory_id",
                  "payload",
                  "text_lemmatized",
                  "user_id",
                  "agent_id",
                  "run_id",
                ]
              : undefined,
          embedding_vector_columns: [
            {
              name: "embedding",
              embedding_dimension: this.dimension,
            },
          ],
        },
      });
    }
  }

  private async ensureChangeDataFeedEnabled(): Promise<void> {
    if (this.endpointType !== "STANDARD") {
      return;
    }

    await this.executeSql(`
      ALTER TABLE ${this.fullTableName}
      SET TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    `);
  }

  private createHttpClient(): AxiosInstance {
    const baseURL = `${this.workspaceUrl}/api/2.0/vector-search`;

    if (this.accessToken) {
      return axios.create({
        baseURL,
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
        },
      });
    }

    if (!this.clientId || !this.clientSecret) {
      throw new Error(
        "Databricks vector store requires accessToken or clientId/clientSecret when httpClient is not provided.",
      );
    }

    const baseClient = axios.create({ baseURL });
    return {
      get: async (url: string, config?: Record<string, any>) =>
        baseClient.get(url, await this.withOAuthHeaders("GET", url, config)),
      post: async (url: string, data?: any, config?: Record<string, any>) =>
        baseClient.post(
          url,
          data,
          await this.withOAuthHeaders("POST", url, config),
        ),
      delete: async (url: string, config?: Record<string, any>) =>
        baseClient.delete(
          url,
          await this.withOAuthHeaders("DELETE", url, config),
        ),
    } as DatabricksHttpClientLike as AxiosInstance;
  }

  private async withOAuthHeaders(
    method: "GET" | "POST" | "DELETE",
    url: string,
    config?: Record<string, any>,
  ): Promise<Record<string, any>> {
    const token = await this.getOAuthAccessToken(
      this.getOAuthAuthorizationDetails(method, url),
    );
    return {
      ...(config || {}),
      headers: {
        ...(config?.headers || {}),
        Authorization: `Bearer ${token}`,
      },
    };
  }

  private getOAuthAuthorizationDetails(
    method: "GET" | "POST" | "DELETE",
    url: string,
  ): string | undefined {
    if (
      method === "POST" &&
      (url.endsWith("/query") || url.endsWith("/query-next-page"))
    ) {
      return buildDatabricksAuthorizationDetails(
        this.fullIndexName,
        "ReadVectorIndex",
      );
    }

    if (
      method === "POST" &&
      (url.endsWith("/sync") ||
        url.endsWith("/upsert-data") ||
        url.endsWith("/delete-data"))
    ) {
      return buildDatabricksAuthorizationDetails(
        this.fullIndexName,
        "WriteVectorIndex",
      );
    }

    return undefined;
  }

  private async getOAuthAccessToken(
    authorizationDetails?: string,
  ): Promise<string> {
    const cacheKey = authorizationDetails || "__management__";
    const cached = this.oauthTokens.get(cacheKey);
    if (cached && Date.now() < cached.expiresAt - 60_000) {
      return cached.accessToken;
    }

    if (!this.clientId || !this.clientSecret) {
      throw new Error(
        "Databricks vector store requires clientId/clientSecret for OAuth token refresh.",
      );
    }

    const formData = new URLSearchParams({
      grant_type: "client_credentials",
      scope: "all-apis",
    });
    if (authorizationDetails) {
      formData.set("authorization_details", authorizationDetails);
    }

    const response = await axios.post(
      `${this.workspaceUrl}/oidc/v1/token`,
      formData,
      {
        auth: {
          username: this.clientId,
          password: this.clientSecret,
        },
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      },
    );

    const token = response?.data?.access_token;
    if (typeof token !== "string" || token.length === 0) {
      throw new Error(
        "Databricks OAuth token response did not include access_token.",
      );
    }

    const expiresInSeconds = Number(response?.data?.expires_in ?? 3600);
    this.oauthTokens.set(cacheKey, {
      accessToken: token,
      expiresAt: Date.now() + Math.max(1, expiresInSeconds) * 1000,
    });
    return token;
  }

  private async getSession(): Promise<DatabricksSqlSessionLike> {
    if (this.session) {
      return this.session;
    }

    if (!this._sessionPromise) {
      this._sessionPromise = this.openSession();
    }

    try {
      this.session = await this._sessionPromise;
    } catch (error) {
      // The first connection attempt failed (cold/auto-suspended warehouse, or a token that
      // expired before first use). This runs before executeSql()'s own try/catch, so drop the
      // rejected promise here too -- otherwise the next call replays it forever.
      this.resetSession();
      throw error;
    }
    return this.session;
  }

  /**
   * `@databricks/sql` is an OPTIONAL peer, and `index.ts` re-exports this module eagerly, so a
   * top-level `import` makes `import "mem0ai/oss"` throw MODULE_NOT_FOUND for every user who
   * never installed the driver -- including everyone who uses a different vector store. Load it
   * on the first SQL call instead, the way milvus.ts and baidu.ts load theirs.
   *
   * This MUST be a dynamic `import()`, never `require()`: tsup/esbuild rewrite `require()` in
   * the published ESM bundle (`dist/oss/index.mjs`) into a `__require` shim that throws
   * `Dynamic require of "..." is not supported`, so every ESM consumer would hit a dead
   * provider even with the driver installed.
   */
  private async getSqlModule(): Promise<{
    DBSQLClient: new () => DatabricksSqlClientLike;
  }> {
    if (!this.sqlModulePromise) {
      this.sqlModulePromise = import("@databricks/sql").then(
        (mod) =>
          mod as unknown as { DBSQLClient: new () => DatabricksSqlClientLike },
        (err) => {
          // Let a later call retry rather than caching the rejection forever.
          this.sqlModulePromise = undefined;
          const detail = err instanceof Error ? err.message : String(err);
          throw new Error(
            "The '@databricks/sql' package is required to use the Databricks vector store. " +
              `Install it with: npm install @databricks/sql (original error: ${detail})`,
          );
        },
      );
    }
    return this.sqlModulePromise;
  }

  private async getSqlClient(): Promise<DatabricksSqlClientLike> {
    if (!this.sqlClient) {
      const { DBSQLClient } = await this.getSqlModule();
      this.sqlClient = new DBSQLClient();
    }
    return this.sqlClient;
  }

  private async openSession(): Promise<DatabricksSqlSessionLike> {
    const sqlClient = await this.getSqlClient();
    const connected = await sqlClient.connect(this.buildSqlConnectionOptions());
    return connected.openSession();
  }

  private buildSqlConnectionOptions(): Record<string, any> {
    const base = {
      host: this.host,
      path: this.httpPath,
    } as Record<string, any>;

    if (this.clientId && this.clientSecret) {
      return {
        ...base,
        authType: "databricks-oauth",
        oauthClientId: this.clientId,
        oauthClientSecret: this.clientSecret,
      };
    }

    if (!this.accessToken) {
      throw new Error(
        "Databricks vector store requires accessToken or clientId/clientSecret for SQL connections.",
      );
    }

    return {
      ...base,
      token: this.accessToken,
    };
  }

  /**
   * Drop the cached session/session-promise so the next `getSession()` opens a fresh one.
   * Called after any SQL failure below -- a stale session (expired token, dropped socket)
   * would otherwise keep being handed out and keep failing forever.
   */
  private resetSession(): void {
    this.session = undefined;
    this._sessionPromise = undefined;
  }

  private async executeSql(
    statement: string,
  ): Promise<Array<Record<string, any>>> {
    const session = await this.getSession();

    let operation;
    try {
      operation = await session.executeStatement(statement);
    } catch (error) {
      // ponytail: no retry here -- statement could be a non-idempotent write, so we only
      // clear the bad session and let the caller's own retry (if any) reconnect.
      this.resetSession();
      throw error;
    }

    try {
      return await operation.fetchAll();
    } catch (error) {
      this.resetSession();
      throw error;
    } finally {
      if (typeof operation.close === "function") {
        await operation.close();
      }
    }
  }

  /**
   * A TRIGGERED pipeline only ingests new rows when it is explicitly synced, so every write
   * must request one. Writers fire the sync and return; only readers wait for it to land.
   * A sync already in flight absorbs later writes -- deleteAll()'s N sequential deletes
   * collapse into far fewer than N pipeline runs.
   */
  private requestIndexSync(): void {
    if (this.pipelineType !== "TRIGGERED") {
      return;
    }

    this.indexSyncQueued = true;
    if (this.indexSyncRunning) {
      // A drain is live and has not yet re-checked the queue, so it will pick this up.
      return;
    }
    this.indexSyncRunning = true;
    this.indexSyncWait = this.drainIndexSync();
  }

  private async drainIndexSync(): Promise<void> {
    try {
      // Re-checking the flag and clearing `indexSyncRunning` both happen with no `await`
      // between them, so a write can never land on a drain that has stopped looking.
      while (this.indexSyncQueued) {
        this.indexSyncQueued = false;
        await this.httpClient.post(
          `/indexes/${encodeURIComponent(this.fullIndexName)}/sync`,
        );
        await this.waitForIndexReadiness();
      }
      this.indexSyncError = null;
    } catch (error) {
      // Surfaced to the next reader: the writer that scheduled this has already returned.
      this.indexSyncError = error;
    } finally {
      this.indexSyncRunning = false;
    }
  }

  private async awaitIndexSync(): Promise<void> {
    while (this.indexSyncWait) {
      const wait = this.indexSyncWait;
      await wait;
      // Only retire the promise we actually awaited; a newer drain may have replaced it,
      // and that one still owes us its rows. Clearing unconditionally would drop it.
      if (this.indexSyncWait === wait) {
        this.indexSyncWait = null;
      }
    }
    if (this.indexSyncError) {
      const error = this.indexSyncError;
      this.indexSyncError = null;
      throw error;
    }
  }

  private async waitForEndpointReadiness(): Promise<void> {
    const deadline = Date.now() + this.syncTimeoutMs;

    while (Date.now() <= deadline) {
      const response = await this.httpClient.get(
        `/endpoints/${encodeURIComponent(this.endpointName)}`,
      );
      const state =
        response?.data?.endpoint_status?.state ?? response?.data?.state;

      if (state === "ONLINE") {
        return;
      }

      if (typeof state !== "string") {
        throw new Error(
          "Databricks endpoint status did not report a state during initialization.",
        );
      }

      if (this.syncPollIntervalMs > 0) {
        await new Promise((resolve) =>
          setTimeout(resolve, this.syncPollIntervalMs),
        );
      }
    }

    throw new Error(
      `Timed out waiting for Databricks endpoint ${this.endpointName} to become ready.`,
    );
  }

  private async waitForIndexReadiness(): Promise<void> {
    const deadline = Date.now() + this.syncTimeoutMs;

    while (Date.now() <= deadline) {
      const response = await this.httpClient.get(
        `/indexes/${encodeURIComponent(this.fullIndexName)}`,
      );
      const ready = response?.data?.status?.ready;

      if (ready === true) {
        return;
      }

      if (ready !== false) {
        throw new Error(
          "Databricks index status did not report a readiness flag after sync.",
        );
      }

      if (this.syncPollIntervalMs > 0) {
        await new Promise((resolve) =>
          setTimeout(resolve, this.syncPollIntervalMs),
        );
      }
    }

    throw new Error(
      `Timed out waiting for Databricks index ${this.fullIndexName} to become ready after sync.`,
    );
  }

  private shouldPaginateForLocalFiltering(filters?: SearchFilters): boolean {
    if (!filters || Object.keys(filters).length === 0) {
      return false;
    }

    for (const [key, value] of Object.entries(filters)) {
      if (key === "$and") {
        if (!Array.isArray(value)) {
          return true;
        }
        if (
          value.some(
            (entry) =>
              !isPlainObject(entry) ||
              this.shouldPaginateForLocalFiltering(entry as SearchFilters),
          )
        ) {
          return true;
        }
        continue;
      }

      if (key === "$or" || key === "$not") {
        return true;
      }

      const translated =
        this.endpointType === "STORAGE_OPTIMIZED"
          ? buildStorageOptimizedDatabricksFilterClause(key, value)
          : buildSimpleDatabricksFilter(key, value);

      if (!translated) {
        return true;
      }
    }

    return false;
  }

  private extractNextPageToken(responseData: any): string | undefined {
    const token =
      responseData?.next_page_token ?? responseData?.result?.next_page_token;
    return typeof token === "string" && token.length > 0 ? token : undefined;
  }

  private async queryIndex(
    requestBody: Record<string, any>,
    filters: SearchFilters | undefined,
    topK: number,
  ): Promise<VectorStoreResult[]> {
    // Read-after-write: writers only request the sync, the reader is what blocks on it.
    // get()/list() skip this -- they read the source Delta table, which is always current.
    await this.awaitIndexSync();
    const requiresLocalFilteringPagination =
      this.shouldPaginateForLocalFiltering(filters);
    const queryResultCap =
      requestBody.query_type === "FULL_TEXT"
        ? MAX_FULL_TEXT_RESULTS
        : MAX_QUERY_RESULTS;
    const response = await this.httpClient.post(
      `/indexes/${encodeURIComponent(this.fullIndexName)}/query`,
      {
        ...requestBody,
        num_results: Math.min(
          requiresLocalFilteringPagination
            ? queryResultCap
            : Math.max(topK, DEFAULT_PAGE_SIZE),
          queryResultCap,
        ),
      },
    );

    const results = this.normalizeQueryResults(
      response.data,
      ["memory_id", "payload"],
      filters,
    );
    if (results.length >= topK) {
      return results.slice(0, topK);
    }

    let nextPageToken = this.extractNextPageToken(response.data);
    while (nextPageToken && results.length < topK) {
      const nextPage = await this.httpClient.post(
        `/indexes/${encodeURIComponent(this.fullIndexName)}/query-next-page`,
        {
          endpoint_name: this.endpointName,
          page_token: nextPageToken,
        },
      );
      results.push(
        ...this.normalizeQueryResults(
          nextPage.data,
          ["memory_id", "payload"],
          filters,
        ),
      );
      nextPageToken = this.extractNextPageToken(nextPage.data);
    }

    return results.slice(0, topK);
  }

  private normalizeQueryResults(
    responseData: any,
    fallbackColumns: string[],
    filters: SearchFilters | undefined,
  ): VectorStoreResult[] {
    const resultData = responseData?.result || responseData;
    const dataArray = Array.isArray(resultData?.data_array)
      ? resultData.data_array
      : [];
    const manifestColumns = Array.isArray(resultData?.manifest?.columns)
      ? resultData.manifest.columns.map((column: any) =>
          typeof column === "string" ? column : column.name,
        )
      : fallbackColumns;
    const results: VectorStoreResult[] = [];

    for (const row of dataArray) {
      const rowDict = this.rowToObject(row, manifestColumns);
      const item: DatabricksVector = {
        id: String(rowDict.memory_id || rowDict.id || rowDict.vector_id),
        payload: this.parsePayload(rowDict.payload),
      };
      if (!this.filterVector(item, filters)) {
        continue;
      }
      const rawScore =
        rowDict.score ??
        (Array.isArray(row) && row.length > manifestColumns.length
          ? row[row.length - 1]
          : undefined);
      results.push({
        id: item.id,
        payload: item.payload,
        score:
          rawScore === undefined || rawScore === null
            ? undefined
            : Number(rawScore),
      });
    }

    return results;
  }

  private rowToObject(row: any, columns: string[]): Record<string, any> {
    if (!Array.isArray(row)) {
      return row || {};
    }

    return Object.fromEntries(
      columns.map((column, index) => [column, row[index]]),
    );
  }

  private parsePayload(rawValue: any): Record<string, any> {
    if (typeof rawValue === "string") {
      try {
        const parsed = JSON.parse(rawValue);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed;
        }
      } catch {
        return {};
      }
    }

    if (rawValue && typeof rawValue === "object" && !Array.isArray(rawValue)) {
      return rawValue;
    }

    return {};
  }

  private extractSessionValues(payload: Record<string, any>): {
    user_id: any;
    agent_id: any;
    run_id: any;
  } {
    return {
      user_id: payload.user_id,
      agent_id: payload.agent_id,
      run_id: payload.run_id,
    };
  }

  private assertVectorDimension(vector: number[], label: string): void {
    if (vector.length !== this.dimension) {
      throw new Error(
        `${label} dimension mismatch. Expected ${this.dimension}, got ${vector.length}`,
      );
    }
    for (const value of vector) {
      if (!Number.isFinite(value)) {
        throw new Error(
          `${label} values must be finite numbers for Databricks vector search.`,
        );
      }
    }
  }

  private matchFieldCondition(
    vector: DatabricksVector,
    key: string,
    value: any,
  ): boolean {
    const fieldValue = key === "memory_id" ? vector.id : vector.payload[key];

    if (typeof value !== "object" || value === null) {
      if (value === "*") {
        return true;
      }
      return fieldValue === value;
    }

    if (Array.isArray(value)) {
      return value.includes(fieldValue);
    }

    let sawOperator = false;

    if ("eq" in value) {
      sawOperator = true;
      if (fieldValue !== value.eq) {
        return false;
      }
    }
    if ("ne" in value) {
      sawOperator = true;
      if (fieldValue === value.ne) {
        return false;
      }
    }
    if ("gt" in value) {
      sawOperator = true;
      if (!(fieldValue > value.gt)) {
        return false;
      }
    }
    if ("gte" in value) {
      sawOperator = true;
      if (!(fieldValue >= value.gte)) {
        return false;
      }
    }
    if ("lt" in value) {
      sawOperator = true;
      if (!(fieldValue < value.lt)) {
        return false;
      }
    }
    if ("lte" in value) {
      sawOperator = true;
      if (!(fieldValue <= value.lte)) {
        return false;
      }
    }
    if ("in" in value) {
      sawOperator = true;
      if (!Array.isArray(value.in) || !value.in.includes(fieldValue)) {
        return false;
      }
    }
    if ("nin" in value) {
      sawOperator = true;
      if (Array.isArray(value.nin) && value.nin.includes(fieldValue)) {
        return false;
      }
    }
    if ("contains" in value) {
      sawOperator = true;
      if (
        typeof fieldValue !== "string" ||
        !fieldValue.includes(value.contains)
      ) {
        return false;
      }
    }
    if ("icontains" in value) {
      sawOperator = true;
      if (
        typeof fieldValue !== "string" ||
        !fieldValue.toLowerCase().includes(value.icontains.toLowerCase())
      ) {
        return false;
      }
    }

    return sawOperator ? true : fieldValue === value;
  }

  private filterVector(
    vector: DatabricksVector,
    filters?: SearchFilters,
  ): boolean {
    if (!filters || Object.keys(filters).length === 0) {
      return true;
    }

    const keyMap: Record<string, string> = {
      $and: "AND",
      $or: "OR",
      $not: "NOT",
    };
    const normalized: Record<string, any> = {};
    for (const [key, value] of Object.entries(filters)) {
      const normalizedKey = keyMap[key] || key;
      if (!(normalizedKey in normalized)) {
        normalized[normalizedKey] = value;
      }
    }

    for (const [key, value] of Object.entries(normalized)) {
      if (key === "AND") {
        if (!Array.isArray(value)) {
          throw new Error(
            `AND filter value must be a list of filter dicts, got ${typeof value}`,
          );
        }
        if (
          !value.every((entry: SearchFilters) =>
            this.filterVector(vector, entry),
          )
        ) {
          return false;
        }
      } else if (key === "OR") {
        if (!Array.isArray(value)) {
          throw new Error(
            `OR filter value must be a list of filter dicts, got ${typeof value}`,
          );
        }
        if (
          !value.some((entry: SearchFilters) =>
            this.filterVector(vector, entry),
          )
        ) {
          return false;
        }
      } else if (key === "NOT") {
        if (!Array.isArray(value)) {
          throw new Error(
            `NOT filter value must be a list of filter dicts, got ${typeof value}`,
          );
        }
        if (
          !value.every(
            (entry: SearchFilters) => !this.filterVector(vector, entry),
          )
        ) {
          return false;
        }
      } else if (!this.matchFieldCondition(vector, key, value)) {
        return false;
      }
    }

    return true;
  }
}
