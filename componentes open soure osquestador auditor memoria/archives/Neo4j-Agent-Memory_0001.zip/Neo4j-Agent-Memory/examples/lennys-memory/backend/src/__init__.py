"""Lenny's Memory Backend."""
