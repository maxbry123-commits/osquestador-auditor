import PageLoading from "@/ui/elements/PageLoading";
export default function Loading() { return <PageLoading name="Search" />; }
