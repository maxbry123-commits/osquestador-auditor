# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

import contextlib
import dataclasses
import uuid
from collections.abc import Iterator
from typing import Any

from haystack.tracing import Span, Tracer
from haystack.tracing.utils import coerce_tag_value


@dataclasses.dataclass
class SpyingSpan(Span):
    operation_name: str
    parent_span: Span | None = None

    tags: dict[str, Any] = dataclasses.field(default_factory=dict)

    trace_id: str | None = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str | None = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))

    def set_tag(self, key: str, value: Any) -> None:
        self.tags[key] = value

    def get_correlation_data_for_logs(self) -> dict[str, Any]:
        return {"trace_id": self.trace_id, "span_id": self.span_id}

    def set_content_tag(self, key: str, value: Any) -> None:
        """
        Set a content tag, but only if content tracing is enabled in the tracer.
        """
        self.set_tag(key, value)


class SpyingTracer(Tracer):
    """
    A tracer that records every span it creates, in creation order, in `spans`.

    Open spans are also kept on a stack, so `current_span` returns the innermost span whose `trace` block has not
    exited yet. The stack lives on the tracer instance rather than in a ContextVar, mirroring tracing backends such
    as Langfuse: code that opens a span while sibling spans are open concurrently sees a sibling as the current span.
    """

    def current_span(self) -> Span | None:
        return self._open_spans[-1] if self._open_spans else None

    def __init__(self) -> None:
        self.spans: list[SpyingSpan] = []
        self._open_spans: list[SpyingSpan] = []

    @contextlib.contextmanager
    def trace(
        self, operation_name: str, tags: dict[str, Any] | None = None, parent_span: Span | None = None
    ) -> Iterator[Span]:
        new_span = SpyingSpan(operation_name, parent_span)
        for key, value in (tags or {}).items():
            new_span.set_tag(key, value)

        self.spans.append(new_span)

        self._open_spans.append(new_span)
        try:
            yield new_span
        finally:
            self._open_spans.remove(new_span)


@dataclasses.dataclass
class EagerSpyingSpan(Span):
    """
    A span that coerces tag values when `set_tag` is called.

    This mirrors real tracing backends (e.g. OpenTelemetry, Datadog), which serialize a tag value eagerly
    when it is set instead of holding a live reference to it. It is useful to catch tags that are set from a
    mutable object before that object has been populated.
    """

    operation_name: str
    parent_span: Span | None = None
    tags: dict[str, Any] = dataclasses.field(default_factory=dict)

    trace_id: str | None = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str | None = dataclasses.field(default_factory=lambda: str(uuid.uuid4()))

    def set_tag(self, key: str, value: Any) -> None:
        self.tags[key] = coerce_tag_value(value)

    def get_correlation_data_for_logs(self) -> dict[str, Any]:
        return {"trace_id": self.trace_id, "span_id": self.span_id}


class EagerSpyingTracer(Tracer):
    """
    A tracer that records every span it creates, in creation order, in `spans`, coercing tag values eagerly.

    Open spans are also kept on a stack, so `current_span` returns the innermost span whose `trace` block has not
    exited yet. The stack lives on the tracer instance rather than in a ContextVar, mirroring tracing backends such
    as Langfuse: code that opens a span while sibling spans are open concurrently sees a sibling as the current span.
    """

    def current_span(self) -> Span | None:
        return self._open_spans[-1] if self._open_spans else None

    def __init__(self) -> None:
        self.spans: list[EagerSpyingSpan] = []
        self._open_spans: list[EagerSpyingSpan] = []

    @contextlib.contextmanager
    def trace(
        self, operation_name: str, tags: dict[str, Any] | None = None, parent_span: Span | None = None
    ) -> Iterator[Span]:
        new_span = EagerSpyingSpan(operation_name, parent_span)
        for key, value in (tags or {}).items():
            new_span.set_tag(key, value)

        self.spans.append(new_span)

        self._open_spans.append(new_span)
        try:
            yield new_span
        finally:
            self._open_spans.remove(new_span)
