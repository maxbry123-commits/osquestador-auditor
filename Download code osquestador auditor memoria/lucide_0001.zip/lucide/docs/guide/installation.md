---
title: Installation
description: A guide on how to install Lucide, an open-source icon library, for various platforms and frameworks.
---

# Installation

## Web

Implementation of the Lucide icon library for web applications.

::: code-group

```sh [pnpm]
pnpm add lucide
```

```sh [yarn]
yarn add lucide
```

```sh [npm]
npm install lucide
```

```sh [bun]
bun add lucide
```

```sh [deno]
deno add lucide
```

:::

For more details, see the [documentation](./lucide/index.md).

## React

Implementation of the Lucide icon library for React applications.

::: code-group

```sh [pnpm]
pnpm add lucide-react
```

```sh [yarn]
yarn add lucide-react
```

```sh [npm]
npm install lucide-react
```

```sh [bun]
bun add lucide-react
```

```sh [deno]
deno add lucide-react
```

:::

For more details, see the [documentation](./react/index.md).
For React Native use the `lucide-react-native` package.

## Vue

Implementation of the Lucide icon library for Vue applications.

::: code-group

```sh [pnpm]
pnpm add @lucide/vue
```

```sh [yarn]
yarn add @lucide/vue
```

```sh [npm]
npm install @lucide/vue
```

```sh [bun]
bun add @lucide/vue
```

```sh [deno]
deno add @lucide/vue
```

:::

For more details, see the [documentation](./vue/index.md).

## Svelte

Implementation of the Lucide icon library for Svelte applications.

::: code-group

```sh [pnpm]
pnpm add @lucide/svelte
```

```sh [yarn]
yarn add @lucide/svelte
```

```sh [npm]
npm install @lucide/svelte
```

```sh [bun]
bun add @lucide/svelte
```

```sh [deno]
deno add @lucide/svelte
```
:::
> `@lucide/svelte` is only for Svelte 5, for Svelte 4 use the `lucide-svelte` package.

For more details, see the [documentation](./svelte/index.md).

## Solid

Implementation of the Lucide icon library for Solid applications.

::: code-group

```sh [pnpm]
pnpm add lucide-solid
```

```sh [yarn]
yarn add lucide-solid
```

```sh [npm]
npm install lucide-solid
```

```sh [bun]
bun add lucide-solid
```

```sh [deno]
deno add lucide-solid
```

:::

For more details, see the [documentation](./solid/index.md).

## Angular

Implementation of the Lucide icon library for Angular applications.

::: code-group

```sh [pnpm]
pnpm add @lucide/angular
```

```sh [yarn]
yarn add @lucide/angular
```

```sh [npm]
npm install @lucide/angular
```

```sh [bun]
bun add @lucide/angular
```

```sh [deno]
deno add @lucide/angular
```

:::

For more details, see the [documentation](./angular/index.md).

## Preact

Implementation of the Lucide icon library for preact applications.

::: code-group

```sh [pnpm]
pnpm add lucide-preact
```

```sh [yarn]
yarn add lucide-preact
```

```sh [npm]
npm install lucide-preact
```

```sh [bun]
bun add lucide-preact
```

```sh [deno]
deno add lucide-preact
```


:::

For more details, see the [documentation](./preact/index.md).

## Astro

Implementation of the Lucide icon library for Astro applications.

::: code-group

```sh [pnpm]
pnpm add @lucide/astro
```

```sh [yarn]
yarn add @lucide/astro
```

```sh [npm]
npm install @lucide/astro
```

```sh [bun]
bun add @lucide/astro
```

```sh [deno]
deno add @lucide/astro
```

:::

For more details, see the [documentation](./astro/index.md).

## Static usage

Implementation of the Lucide icon library for multiple usages that like to use: SVG files icons, SVG Sprite, Icon Fonts and static SVG strings export in Common JS modules (for NodeJS).

::: code-group

```sh [pnpm]
pnpm add lucide-static
```

```sh [yarn]
yarn add lucide-static
```

```sh [npm]
npm install lucide-static
```

```sh [bun]
bun add lucide-static
```

```sh [deno]
deno add lucide-static
```

:::

For more details, see the [documentation](./static/index.md).

## Figma

The Lucide Figma plugin.

Visit [Figma community page](https://www.figma.com/community/plugin/939567362549682242/Lucide-Icons) to install the plugin.

![Setting Page Size](https://www.figma.com/community/plugin/939567362549682242/thumbnail 'Figma Lucide Cover')
