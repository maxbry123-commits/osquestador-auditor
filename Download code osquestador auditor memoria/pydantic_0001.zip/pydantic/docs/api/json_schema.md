::: pydantic.json_schema
