/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ClientInfo } from '../../playwright-core/src/tools/cli-client/registry';
import type { BrowserDescriptor } from '../../playwright-core/src/serverRegistry';

export type SessionStatus = BrowserDescriptor;

export type Tab = {
  browser: string;
  context: string;
  page: string;
  title: string;
  url: string;
  selected: boolean;
  faviconUrl?: string;
  inspectorUrl?: string;
};

export type AnnotationData = { x: number; y: number; width: number; height: number; text: string };

export type SubmittedAnnotationFrame = {
  data: string;
  ariaSnapshot: string;
  annotations: AnnotationData[];
  sessionTitle: string;
  title: string;
  url: string;
  viewportWidth: number;
  viewportHeight: number;
};

export type DashboardChannelEvents = {
  sessions: { sessions: SessionStatus[]; clientInfo: ClientInfo };
  tabs: { tabs: Tab[] };
  frame: { data: string; viewportWidth: number; viewportHeight: number };
  annotate: {};
  cancelAnnotate: {};
  apiCalls: { apiCalls: ApiCall[] };
  debuggerPaused: { paused: boolean };
  debuggerSource: { source: DebuggerSource | null };
};

export type ApiCall = {
  id: string;
  title: string;
  location?: { file: string; line?: number; column?: number };
  logs: string[];
  actionPoint?: { x: number; y: number };
  status: 'running' | 'success' | 'error';
  error?: string;
};

export type DebuggerSource = {
  file: string;
  language: 'javascript' | 'python' | 'java' | 'csharp';
  text: string;
  highlight: { line: number; type: 'running' | 'paused' | 'error' }[];
  revealLine?: number;
};

export type MouseButton = 'left' | 'middle' | 'right';

export interface DashboardChannel {
  selectTab(params: { browser: string; context: string; page: string }): Promise<void>;
  closeTab(params: { browser: string; context: string; page: string }): Promise<void>;
  newTab(params: { browser: string; context: string }): Promise<void>;
  closeSession(params: { browser: string }): Promise<void>;
  setVisible(params: { visible: boolean }): Promise<void>;

  navigate(params: { url: string }): Promise<void>;
  back(): Promise<void>;
  forward(): Promise<void>;
  reload(): Promise<void>;
  mousemove(params: { x: number; y: number }): Promise<void>;
  mousedown(params: { x: number; y: number; button?: MouseButton }): Promise<void>;
  mouseup(params: { x: number; y: number; button?: MouseButton }): Promise<void>;
  wheel(params: { deltaX: number; deltaY: number }): Promise<void>;
  keydown(params: { key: string }): Promise<void>;
  keyup(params: { key: string }): Promise<void>;
  startRecording(): Promise<void>;
  stopRecording(): Promise<{ streamId: string }>;
  readStream(params: { streamId: string }): Promise<{ data: string; eof: boolean }>;
  screenshot(): Promise<{ data: string; viewportWidth: number; viewportHeight: number; ariaSnapshot: string }>;
  submitAnnotation(params: { frames: SubmittedAnnotationFrame[]; feedback: string }): Promise<void>;
  cancelAnnotation(): Promise<void>;
  debuggerResume(): Promise<void>;
  debuggerPause(): Promise<void>;
  debuggerStep(): Promise<void>;

  on<K extends keyof DashboardChannelEvents>(event: K, listener: (params: DashboardChannelEvents[K]) => void): void;
  off<K extends keyof DashboardChannelEvents>(event: K, listener: (params: DashboardChannelEvents[K]) => void): void;
}
