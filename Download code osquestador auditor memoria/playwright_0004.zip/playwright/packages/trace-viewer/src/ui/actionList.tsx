/*
  Copyright (c) Microsoft Corporation.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

import type { ActionTraceEvent } from '@isomorphic/trace/trace';
import { clsx } from '@web/uiUtils';
import { msToString } from '@isomorphic/formatUtils';
import * as React from 'react';
import './actionList.css';
import { buildActionTree } from '@isomorphic/trace/traceModel';
import { type Language } from '@isomorphic/locatorGenerators';
import type { TreeState } from '@web/components/treeView';
import { TreeView } from '@web/components/treeView';
import type { ActionTreeItem, TraceModel } from '@isomorphic/trace/traceModel';
import type { ActionEntry } from '@isomorphic/trace/entries';
import { useTraceModel } from './traceModelContext';
import type { Boundaries } from './geometry';
import { ToolbarButton } from '@web/components/toolbarButton';
import { testStatusIcon } from './testUtils';
import { getMetainfo } from '@isomorphic/protocolMetainfo';
import { formatProtocolParam, renderSubtitleForCall } from '@isomorphic/protocolFormatter';

export interface ActionListProps {
  actions: ActionEntry[],
  selectedAction: ActionEntry | undefined,
  selectedTime: Boundaries | undefined,
  setSelectedTime: (time: Boundaries | undefined) => void,
  treeState: TreeState,
  setTreeState: React.Dispatch<React.SetStateAction<TreeState>>,
  sdkLanguage: Language | undefined;
  onSelected?: (action: ActionEntry) => void,
  onHighlighted?: (action: ActionEntry | undefined) => void,
  revealConsole?: () => void,
  revealActionAttachment?(callId: string): void,
  isLive?: boolean,
  actionFilterText?: string,
}

const ActionTreeView = TreeView<ActionTreeItem>;

export const ActionList: React.FC<ActionListProps> = ({
  actions,
  selectedAction,
  selectedTime,
  setSelectedTime,
  treeState,
  setTreeState,
  sdkLanguage,
  onSelected,
  onHighlighted,
  revealConsole,
  revealActionAttachment,
  isLive,
  actionFilterText,
}) => {
  const model = useTraceModel();
  const { rootItem, itemMap } = React.useMemo(() => buildActionTree(actions), [actions]);

  const { selectedItem } = React.useMemo(() => {
    const selectedItem = selectedAction ? itemMap.get(selectedAction.callId) : undefined;
    return { selectedItem };
  }, [itemMap, selectedAction]);

  const isError = React.useCallback((item: ActionTreeItem) => {
    return !!item.action.error?.message;
  }, []);

  const onAccepted = React.useCallback((item: ActionTreeItem) => {
    return setSelectedTime({ minimum: item.action.startTime, maximum: item.action.endTime });
  }, [setSelectedTime]);

  const render = React.useCallback((item: ActionTreeItem) => {
    const showAttachments = !!revealActionAttachment && !!item.action.attachments?.length;
    return renderAction(item.action, { model, sdkLanguage, revealConsole, revealActionAttachment: () => revealActionAttachment?.(item.action.callId), isLive, showDuration: true, showBadges: true, showAttachments });
  }, [model, isLive, revealConsole, revealActionAttachment, sdkLanguage]);

  const isVisible = React.useCallback((item: ActionTreeItem) => {
    const timeVisible = !selectedTime || !item.action || (item.action.startTime <= selectedTime.maximum && item.action.endTime >= selectedTime.minimum);
    if (!timeVisible)
      return false;
    if (!actionFilterText)
      return true;
    const { title, subtitle } = renderTitleForCall(item.action, sdkLanguage);
    const text = subtitle ? `${title} ${subtitle}` : title;
    const isIncluded = text.toLowerCase().includes(actionFilterText.toLowerCase());
    return isIncluded ? true : 'if-needed';
  }, [selectedTime, actionFilterText, sdkLanguage]);

  const onSelectedAction = React.useCallback((item: ActionTreeItem) => {
    onSelected?.(item.action);
  }, [onSelected]);

  const onHighlightedAction = React.useCallback((item: ActionTreeItem | undefined) => {
    onHighlighted?.(item?.action);
  }, [onHighlighted]);

  const [showAllCounter, setShowAllCounter] = React.useState<number>();
  const onShowAll = React.useCallback(() => {
    setSelectedTime(undefined);
    setShowAllCounter(n => (n ?? 0) + 1);
  }, [setSelectedTime]);

  return <div className='vbox action-list-container'>
    {selectedTime && <ToolbarButton className='action-list-show-all' icon='triangle-left' onClick={onShowAll}>Show all</ToolbarButton>}
    <ActionTreeView
      name='actions'
      rootItem={rootItem}
      treeState={treeState}
      setTreeState={setTreeState}
      selectedItem={selectedItem}
      onSelected={onSelectedAction}
      onHighlighted={onHighlightedAction}
      onAccepted={onAccepted}
      isError={isError}
      isVisible={isVisible}
      render={render}
      autoExpandDepth={actionFilterText?.trim() ? 5 : 0}
      revealSelectedKey={showAllCounter}
    />
  </div>;
};

export const renderAction = (
  action: ActionEntry,
  options: {
    model?: TraceModel,
    sdkLanguage?: Language,
    revealConsole?: () => void,
    revealActionAttachment?(): void,
    isLive?: boolean,
    showDuration?: boolean,
    showBadges?: boolean,
    showAttachments?: boolean,
  }) => {
  const { model, sdkLanguage, revealConsole, revealActionAttachment, isLive, showDuration, showBadges, showAttachments } = options;
  const { errors, warnings } = model?.stats(action) ?? { errors: 0, warnings: 0 };
  const badgeLabel = [pluralize(errors, 'error'), pluralize(warnings, 'warning')].filter(Boolean).join(', ');

  const isSkipped = action.class === 'Test' && action.method === 'test.step' && action.annotations?.some(a => a.type === 'skip');
  let time: string = '';
  if (action.endTime)
    time = msToString(action.endTime - action.startTime);
  else if (action.error)
    time = 'Timed out';
  else if (!isLive)
    time = '-';
  const { elements, title, subtitle } = renderTitleForCall(action, sdkLanguage);
  return <div className='action-title vbox'>
    <div className='hbox'>
      <span className='action-title-method' title={title}>{elements}</span>
      {(showDuration || showBadges || showAttachments || isSkipped) && <div className='spacer'></div>}
      {showAttachments && <ToolbarButton icon='attach' title='Open Attachment' onClick={() => revealActionAttachment?.()} />}
      {showDuration && !isSkipped && <div className='action-duration'>{time || <span className='codicon codicon-loading'></span>}</div>}
      {isSkipped && <span className={clsx('action-skipped', 'codicon', testStatusIcon('skipped'))} title='skipped'></span>}
      {showBadges && !!badgeLabel && <ToolbarButton
        className='action-icons'
        title='Reveal console'
        ariaLabel={`Reveal console, ${badgeLabel}`}
        onClick={() => revealConsole?.()}>
        {!!errors && <span className='action-icon'><span className='codicon codicon-error'></span><span className='action-icon-value'>{errors}</span></span>}
        {!!warnings && <span className='action-icon'><span className='codicon codicon-warning'></span><span className='action-icon-value'>{warnings}</span></span>}
      </ToolbarButton>}
    </div>
    {subtitle && <div className='action-title-subtitle' title={subtitle}>{subtitle}</div>}
  </div>;
};

export function renderTitleForCall(action: ActionTraceEvent, sdkLanguage?: Language): { elements: React.ReactNode[], title: string, subtitle?: string } {
  let titleFormat = action.title ?? getMetainfo({ type: action.class, method: action.method })?.title ?? action.method;
  titleFormat = titleFormat.replace(/\n/g, ' ');

  const elements: React.ReactNode[] = [];
  const title: string[] = [];
  let currentIndex = 0;
  const regex = /\{([^}]+)\}/g;
  let match;

  while ((match = regex.exec(titleFormat)) !== null) {
    const [fullMatch, quotedText] = match;
    const chunk = titleFormat.slice(currentIndex, match.index);

    elements.push(chunk);
    title.push(chunk);

    const param = formatProtocolParam(action.params, quotedText, sdkLanguage);
    if (param === undefined) {
      elements.push(fullMatch);
      title.push(fullMatch);
    } else if (match.index === 0) {
      elements.push(param);
      title.push(param);
    } else {
      elements.push(<span key={elements.length} className='action-title-param'>{param}</span>);
      title.push(param);
    }
    currentIndex = match.index + fullMatch.length;
  }

  if (currentIndex < titleFormat.length) {
    const chunk = titleFormat.slice(currentIndex);
    elements.push(chunk);
    title.push(chunk);
  }

  const subtitle = renderSubtitleForCall({ type: action.class, method: action.method, params: action.params, subtitle: action.subtitle }, sdkLanguage);
  return { elements, title: title.join(''), subtitle };
}

function pluralize(count: number, noun: string): string {
  if (!count)
    return '';
  return `${count} ${noun}${count === 1 ? '' : 's'}`;
}
