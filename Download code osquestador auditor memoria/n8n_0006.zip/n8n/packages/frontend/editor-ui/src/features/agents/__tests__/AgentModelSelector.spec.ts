import { flushPromises, mount, type VueWrapper } from '@vue/test-utils';
import { beforeEach, describe, expect, it, vi } from 'vitest';

import { AI_GATEWAY_MANAGED_TAG } from '@n8n/api-types';

import type { AgentModelOption, AgentModelsByProvider } from '../model-providers';

type Credential = { id: string; name: string; type: string; isManaged?: boolean };
type TestMenuItem = {
	id: string;
	label: string;
	checked?: boolean;
	keepOpen?: boolean;
	header?: boolean;
	disabled?: boolean;
	divided?: boolean;
	children?: TestMenuItem[];
	data?: {
		badgeLabel?: string;
		actionPill?: { text: string; type?: string };
		description?: string;
		descriptionTooltipTeleported?: boolean;
		leadingIcon?: string;
		credentialType?: string;
		provider?: string;
		connectedLabel?: string;
	};
};

const credentialsByType = vi.hoisted(() => ({
	value: {
		anthropicApi: [{ id: 'anthropic-cred', name: 'Anthropic credential', type: 'anthropicApi' }],
	} as Record<string, Credential[]>,
}));

const freeAiCreditsState = vi.hoisted(() => ({
	aiCreditsQuota: { value: 100 },
	userCanClaimOpenAiCredits: { value: false },
	claimingCredits: { value: false },
	claimCreditsAndGetCredential: vi.fn(),
}));
const canCreateCredentials = vi.hoisted(() => ({ value: true }));
const openNewCredential = vi.hoisted(() => vi.fn());
const openModalWithData = vi.hoisted(() => vi.fn());
const aiGatewayState = vi.hoisted(() => ({
	isEnabled: { value: false },
	supportedTypes: new Set<string>(),
	balance: { value: undefined as number | undefined },
	fetchWallet: vi.fn(),
	fetchConfig: vi.fn(),
	creditsLabelKey: { value: 'generic.freeCredits' as 'generic.freeCredits' | 'generic.n8nCredits' },
}));
const baseText = vi.hoisted(() =>
	vi.fn((key: string, options?: { interpolate?: Record<string, string | number> }) => {
		const template =
			{
				'agents.modelSelector.connected': 'Connected',
				'agents.modelSelector.defaultLabel': 'Choose model',
				'agents.modelSelector.includedInN8n': 'Included in n8n',
				'agents.modelSelector.configureCredentials': 'Create credential',
				'agents.modelSelector.connectTo': 'Connect to {provider}',
				'agents.modelSelector.models': 'Models',
				'generic.freeCredits': 'Free credits',
				'generic.n8nCredits': 'Gateway credits',
				'agents.modelSelector.credentialsMissing': 'Credentials missing',
				'agents.modelSelector.noMatch': 'No match',
				'agents.modelSelector.noModels': 'No models',
				'agents.modelSelector.moreModels': 'More models',
				'agents.modelSelector.freeCredits.label': 'Use free OpenAI credits',
				'agents.modelSelector.freeCredits.badge': 'free credits',
				'aiGateway.credentialMode.n8nConnect.title': 'Gateway credits',
				'aiGateway.wallet.balanceRemaining': '{balance} remaining',
				'aiGateway.wallet.noCredits': 'No credits',
				'agents.modelSelector.freeCredits.description':
					'Get {credits} free OpenAI API credits. Try it with gpt-5-mini.',
				'generic.loadingEllipsis': 'Loading...',
			}[key] ?? key;

		return Object.entries(options?.interpolate ?? {}).reduce(
			(text, [name, value]) => text.replace(`{${name}}`, String(value)),
			template,
		);
	}),
);

vi.mock('@n8n/i18n', () => ({
	useI18n: () => ({
		baseText,
	}),
}));

vi.mock('@n8n/permissions', () => ({
	getResourcePermissions: () => ({ credential: { create: canCreateCredentials.value } }),
}));

vi.mock('@n8n/design-system', async () => {
	const { computed, ref } = await import('vue');

	return {
		N8nAiModelSelectorDropdown: {
			name: 'AiModelSelectorDropdown',
			props: [
				'items',
				'selectedLabel',
				'selectedCredentialName',
				'credentialsMissing',
				'noMatchLabel',
				'disabled',
				'dataTestId',
				'credentialDataTestId',
			],
			template: '<div data-testid="ai-model-selector-dropdown" />',
		},
		N8nIcon: { template: '<span />', props: ['icon', 'size'] },
		useDropdownSearch: () => ({
			search: ref(''),
			filteredItems: computed(() => []),
			handleSearch: vi.fn(),
		}),
	};
});

vi.mock('@/features/credentials/components/CredentialIcon.vue', () => ({
	default: { template: '<span />', props: ['credentialTypeName', 'size'] },
}));

vi.mock('@/features/credentials/credentials.store', () => ({
	useCredentialsStore: () => ({
		getCredentialById: (id: string) =>
			Object.values(credentialsByType.value)
				.flat()
				.find((credential) => credential.id === id),
		getCredentialsByType: (type: string) => credentialsByType.value[type] ?? [],
		getCredentialTypeByName: (type: string) => ({ displayName: type }),
	}),
}));

vi.mock('@/app/composables/useFreeAiCredits', () => ({
	useFreeAiCredits: () => freeAiCreditsState,
}));

vi.mock('@/app/composables/useAiGateway', () => ({
	useAiGateway: () => ({
		isEnabled: aiGatewayState.isEnabled,
		isCredentialTypeSupported: (type: string) => aiGatewayState.supportedTypes.has(type),
		canServeCredentialType: (type: string) => aiGatewayState.supportedTypes.has(type),
		balance: aiGatewayState.balance,
		creditsLabelKey: aiGatewayState.creditsLabelKey,
		fetchWallet: aiGatewayState.fetchWallet,
		fetchConfig: aiGatewayState.fetchConfig,
	}),
}));

vi.mock('@/features/collaboration/projects/projects.store', () => ({
	useProjectsStore: () => ({
		currentProject: { id: 'project-1', scopes: [] },
		personalProject: { id: 'project-1', scopes: [] },
		myProjects: [{ id: 'project-1', scopes: [] }],
	}),
}));

vi.mock('@/app/stores/ui.store', () => ({
	useUIStore: () => ({ openNewCredential, openModalWithData }),
}));

vi.mock('../composables/useModelCatalog', () => ({
	useModelCatalog: () => ({
		ensureLoaded: vi.fn(),
		getDefaultModelForPicker: (
			_credentials: Record<string, string | null> | null,
			provider: string,
		) =>
			provider === 'openai'
				? {
						provider: 'openai',
						model: 'gpt-5-mini',
						name: 'GPT-5 mini',
						description: null,
						createdAt: null,
						metadata: { functionCalling: true, available: true },
					}
				: null,
		getVerificationStatus: (_projectId: string, _provider: string, credentialId: string) =>
			credentialId === 'free-openai-credential' ? 'resolved' : 'loading',
	}),
}));

const modelsByProvider: AgentModelsByProvider = {
	anthropic: {
		models: [
			{
				provider: 'anthropic',
				model: 'claude-sonnet-4-5',
				name: 'Claude Sonnet 4.5',
				description: null,
				createdAt: null,
				metadata: { functionCalling: true, available: true },
			},
		],
	},
};

async function mountSelector(
	credentials: Record<string, string | null>,
	extraProps: {
		credentialModalAppendToBody?: boolean;
		boundCredentialId?: string | null;
		selectedModel?: AgentModelOption | null;
	} = {},
) {
	const { default: AgentModelSelector } = await import('../components/AgentModelSelector.vue');
	return mount(AgentModelSelector, {
		props: {
			selectedModel: modelsByProvider.anthropic?.models[0] ?? null,
			credentials,
			modelsByProvider,
			isLoading: false,
			projectId: 'project-1',
			warnMissingCredentials: true,
			...extraProps,
		},
	});
}

function getDropdown(wrapper: VueWrapper) {
	return wrapper.findComponent({ name: 'AiModelSelectorDropdown' });
}

function getProviderItem(wrapper: VueWrapper, provider: string) {
	return (getDropdown(wrapper).props('items') as TestMenuItem[]).find(
		(item) => item.id === provider,
	);
}

function getMenuItemByLabel(items: TestMenuItem[], label: string): TestMenuItem | undefined {
	for (const item of items) {
		if (item.label === label) return item;
		const child = getMenuItemByLabel(item.children ?? [], label);
		if (child) return child;
	}

	return undefined;
}

function getFreeOpenAiCreditsItem(wrapper: VueWrapper) {
	return getMenuItemByLabel(
		getDropdown(wrapper).props('items') as TestMenuItem[],
		'Use free OpenAI credits',
	);
}

describe('AgentModelSelector', () => {
	beforeEach(() => {
		vi.clearAllMocks();
		credentialsByType.value = {
			anthropicApi: [{ id: 'anthropic-cred', name: 'Anthropic credential', type: 'anthropicApi' }],
		};
		freeAiCreditsState.userCanClaimOpenAiCredits.value = false;
		freeAiCreditsState.claimingCredits.value = false;
		freeAiCreditsState.claimCreditsAndGetCredential.mockReset();
		canCreateCredentials.value = true;
		aiGatewayState.isEnabled.value = false;
		aiGatewayState.supportedTypes = new Set<string>();
		aiGatewayState.balance.value = undefined;
		aiGatewayState.creditsLabelKey.value = 'generic.freeCredits';
		aiGatewayState.fetchWallet.mockReset();
		aiGatewayState.fetchConfig.mockReset();
	});

	it('fetches the gateway config on mount so the managed option can be gated', async () => {
		await mountSelector({ anthropic: null });

		expect(aiGatewayState.fetchConfig).toHaveBeenCalled();
	});

	function getN8nCreditsItem(wrapper: VueWrapper, provider: string) {
		return getProviderItem(wrapper, provider)?.children?.find((item) =>
			item.id.includes('::n8nConnect::'),
		);
	}

	it('offers the n8n credits option for a supported provider when the gateway is enabled', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: null });

		expect(getN8nCreditsItem(wrapper, 'anthropic')).toBeDefined();
	});

	it('shows the Free credits pill (same N8nActionPill as the node creator) on covered providers', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: null });

		expect(getProviderItem(wrapper, 'anthropic')?.data?.actionPill).toEqual({
			text: 'Free credits',
			type: 'default',
		});
	});

	it('shows the n8n credits pill on covered providers after a top-up', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);
		aiGatewayState.creditsLabelKey.value = 'generic.n8nCredits';

		const wrapper = await mountSelector({ anthropic: null });

		expect(getProviderItem(wrapper, 'anthropic')?.data?.actionPill).toEqual({
			text: 'Gateway credits',
			type: 'info',
		});
	});

	it('does not show the Free credits pill on unsupported providers', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set<string>();

		const wrapper = await mountSelector({ anthropic: null });

		expect(getProviderItem(wrapper, 'anthropic')?.data?.actionPill).toBeUndefined();
	});

	it('pins the currently selected provider to the top and marks it connected', async () => {
		const wrapper = await mountSelector({ anthropic: null });
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items[0].id).toBe('anthropic');
		expect(items[0].data?.connectedLabel).toBe('Connected');
		expect(items.filter((item) => item.data?.connectedLabel).length).toBe(1);
	});

	it('does not mark anything as connected when there is no selected model', async () => {
		const wrapper = await mountSelector({ anthropic: null }, { selectedModel: null });
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items.some((item) => item.data?.connectedLabel)).toBe(false);
		// No pinned selection, so providers fall back to declaration order.
		expect(items[0].id).toBe('openai');
	});

	it('hoists n8n Connect providers below the selected provider with a header and a single divider', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['openAiApi']);

		const wrapper = await mountSelector({ anthropic: null });
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items[0].id).toBe('anthropic');
		expect(items[1]).toMatchObject({
			id: 'n8nConnect::header',
			header: true,
			label: 'Included in n8n',
		});
		expect(items[2].id).toBe('openai');
		expect(items[2].divided).toBeFalsy();
		// First provider after the n8n Connect group gets the group-boundary divider.
		expect(items[3].divided).toBe(true);
		// Only one divider in the whole list.
		expect(items.filter((item) => item.divided).length).toBe(1);
	});

	it('does not show a header or divider when no other provider is n8n Connect eligible', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set<string>();

		const wrapper = await mountSelector({ anthropic: null });
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items.some((item) => item.id === 'n8nConnect::header')).toBe(false);
		expect(items.some((item) => item.divided)).toBe(false);
	});

	it('does not duplicate a selected provider that is also n8n Connect eligible', async () => {
		aiGatewayState.isEnabled.value = true;
		// anthropic is both the selected provider and n8n Connect eligible here.
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: null });
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items[0].id).toBe('anthropic');
		expect(items[0].data?.connectedLabel).toBe('Connected');
		expect(items.filter((item) => item.id === 'anthropic').length).toBe(1);
		// No other provider is n8n Connect eligible, so the group is empty.
		expect(items.some((item) => item.id === 'n8nConnect::header')).toBe(false);
	});

	it('pins an aggregator provider when it is selected, without duplicating it in the aggregator group', async () => {
		const wrapper = await mountSelector(
			{ anthropic: null },
			{
				selectedModel: {
					provider: 'aws-bedrock',
					model: 'anthropic.claude-3-5-sonnet',
					name: 'Claude 3.5 Sonnet',
					description: null,
					createdAt: null,
					metadata: { functionCalling: true, available: true },
				},
			},
		);
		const items = getDropdown(wrapper).props('items') as TestMenuItem[];

		expect(items[0].id).toBe('aws-bedrock');
		expect(items[0].data?.connectedLabel).toBe('Connected');
		expect(items.filter((item) => item.id === 'aws-bedrock').length).toBe(1);
	});

	it('orders regular providers before aggregators in the remaining list', async () => {
		const wrapper = await mountSelector({ anthropic: null });
		const ids = (getDropdown(wrapper).props('items') as TestMenuItem[])
			.map((item) => item.id)
			.filter((id) => id !== 'n8nConnect::header');

		const aggregatorIds = ['aws-bedrock', 'openrouter', 'vercel'];
		const firstAggregatorIndex = Math.min(...aggregatorIds.map((id) => ids.indexOf(id)));
		const regularIds = ids.filter((id) => id !== 'anthropic' && !aggregatorIds.includes(id));
		const lastRegularIndex = Math.max(...regularIds.map((id) => ids.indexOf(id)));

		expect(lastRegularIndex).toBeLessThan(firstAggregatorIndex);
	});

	it('does not offer n8n credits when the gateway is disabled', async () => {
		aiGatewayState.isEnabled.value = false;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: null });

		expect(getN8nCreditsItem(wrapper, 'anthropic')).toBeUndefined();
	});

	it('does not offer n8n credits for a provider the gateway does not support', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set<string>(); // anthropicApi not supported

		const wrapper = await mountSelector({ anthropic: null });

		expect(getN8nCreditsItem(wrapper, 'anthropic')).toBeUndefined();
	});

	it('offers n8n credits for a multi-credential-type provider when a non-first type is supported', async () => {
		aiGatewayState.isEnabled.value = true;
		// azure-openai exposes ['azureOpenAiApi', 'azureEntraCognitiveServicesOAuth2Api'];
		// support only the second — the gate must check all types, matching the resolver.
		aiGatewayState.supportedTypes = new Set(['azureEntraCognitiveServicesOAuth2Api']);

		const wrapper = await mountSelector({ 'azure-openai': null });

		expect(getN8nCreditsItem(wrapper, 'azure-openai')).toBeDefined();
	});

	it('emits selectCredential with the managed tag when n8n credits is chosen', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: null });
		getDropdown(wrapper).vm.$emit('select', 'anthropic::n8nConnect::anthropicApi');

		expect(wrapper.emitted('selectCredential')).toEqual([['anthropic', AI_GATEWAY_MANAGED_TAG]]);
	});

	it('marks the n8n credits option as a keep-open toggle with no info tooltip', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		const item = getN8nCreditsItem(wrapper, 'anthropic');

		// Selecting keeps the dropdown open and the active state is the right-aligned checkmark.
		expect(item?.keepOpen).toBe(true);
		expect(item?.checked).toBe(true);
		expect(item?.data?.description).toBeUndefined();
	});

	it('re-selects the managed tag (radio-style, no toggle-off) when already selected', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		getDropdown(wrapper).vm.$emit('select', 'anthropic::n8nConnect::anthropicApi');

		expect(wrapper.emitted('selectCredential')).toEqual([['anthropic', AI_GATEWAY_MANAGED_TAG]]);
	});

	it('lists models when the managed tag is the selected credential', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		const anthropicItem = getProviderItem(wrapper, 'anthropic');

		expect(JSON.stringify(anthropicItem?.children ?? [])).toContain('Claude Sonnet 4.5');
	});

	it('shows the remaining balance on the n8n credits option', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);
		aiGatewayState.balance.value = 4.99;

		const wrapper = await mountSelector({ anthropic: null });

		const item = getN8nCreditsItem(wrapper, 'anthropic');
		// Green "remaining" action pill (N8nActionPill), matching the workflow node.
		expect(item?.data?.actionPill).toEqual({ text: '$4.99 remaining', type: 'default' });
	});

	it('fetches the wallet balance on mount when the gateway is enabled', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		await mountSelector({ anthropic: null });

		expect(aiGatewayState.fetchWallet).toHaveBeenCalled();
	});

	it('does not fetch the wallet when the gateway is disabled', async () => {
		aiGatewayState.isEnabled.value = false;

		await mountSelector({ anthropic: null });

		expect(aiGatewayState.fetchWallet).not.toHaveBeenCalled();
	});

	it('shows n8n Connect (not "credentials missing") for a managed credential', async () => {
		// No own credential for the provider, but the selection is the managed tag —
		// derived from `credentials`, so every caller gets this without opting in.
		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		const dropdown = getDropdown(wrapper);

		expect(dropdown.props('credentialsMissing')).toBe(false);
		// Shown as plain text (like an own credential name), not a custom badge.
		expect(dropdown.props('selectedCredentialName')).toBe('Gateway credits');
	});

	it('surfaces a stale selected credential as missing', async () => {
		const wrapper = await mountSelector(
			{ anthropic: 'deleted-credential' },
			{ boundCredentialId: 'deleted-credential' },
		);
		const dropdown = getDropdown(wrapper);
		const anthropicItem = getProviderItem(wrapper, 'anthropic');

		expect(dropdown.props('credentialsMissing')).toBe(true);
		expect(dropdown.props('selectedCredentialName')).toBeUndefined();
		expect(JSON.stringify(anthropicItem?.children ?? [])).not.toContain('Claude Sonnet 4.5');
	});

	it('reports missing credentials when the picker resolves one the config has not bound', async () => {
		const wrapper = await mountSelector(
			{ anthropic: 'anthropic-cred' },
			{ boundCredentialId: null },
		);

		expect(getDropdown(wrapper).props('credentialsMissing')).toBe(true);
	});

	it('uses an available selected credential', async () => {
		const wrapper = await mountSelector(
			{ anthropic: 'anthropic-cred' },
			{ boundCredentialId: 'anthropic-cred' },
		);
		const dropdown = getDropdown(wrapper);
		const anthropicItem = getProviderItem(wrapper, 'anthropic');

		expect(dropdown.props('credentialsMissing')).toBe(false);
		expect(dropdown.props('selectedCredentialName')).toBe('Anthropic credential');
		expect(JSON.stringify(anthropicItem?.children ?? [])).toContain('Claude Sonnet 4.5');
		expect(getMenuItemByLabel(anthropicItem?.children ?? [], 'Claude Sonnet 4.5')?.checked).toBe(
			true,
		);
	});

	it('lists an existing credential as a selectable row and selects it', async () => {
		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		const credentialItem = getMenuItemByLabel(
			getProviderItem(wrapper, 'anthropic')?.children ?? [],
			'Anthropic credential',
		);

		expect(credentialItem?.id).toBe('anthropic::select::anthropic-cred');
		expect(credentialItem?.keepOpen).toBe(true);

		getDropdown(wrapper).vm.$emit('select', 'anthropic::select::anthropic-cred');
		expect(wrapper.emitted('selectCredential')).toEqual([['anthropic', 'anthropic-cred']]);
		expect(wrapper.emitted('change')).toBeUndefined();
	});

	it('selects gpt-5-mini when an existing free OpenAI credits credential is selected', async () => {
		credentialsByType.value = {
			openAiApi: [
				{
					id: 'free-openai-credential',
					name: 'n8n free OpenAI API credits',
					type: 'openAiApi',
					isManaged: true,
				},
			],
		};
		const wrapper = await mountSelector({ openai: null });

		getDropdown(wrapper).vm.$emit('select', 'openai::select::free-openai-credential');
		await wrapper.vm.$nextTick();

		expect(wrapper.emitted('selectCredential')).toEqual([['openai', 'free-openai-credential']]);
		expect(wrapper.emitted('change')).toEqual([[{ provider: 'openai', model: 'gpt-5-mini' }]]);
	});

	it('groups the submenu with "Connect to <provider>" and "Models" section headers', async () => {
		aiGatewayState.isEnabled.value = true;
		aiGatewayState.supportedTypes = new Set(['anthropicApi']);

		const wrapper = await mountSelector({ anthropic: AI_GATEWAY_MANAGED_TAG });
		const children = getProviderItem(wrapper, 'anthropic')?.children ?? [];
		const connectHeader = children.find((item) => item.id === 'anthropic::header::connect');
		const modelsHeader = children.find((item) => item.id === 'anthropic::header::models');

		expect(connectHeader?.header).toBe(true);
		expect(connectHeader?.label).toBe('Connect to Anthropic');
		expect(modelsHeader?.header).toBe(true);
		expect(modelsHeader?.label).toBe('Models');
	});

	it('checks the active credential row', async () => {
		const wrapper = await mountSelector({ anthropic: 'anthropic-cred' });
		const credentialItem = getMenuItemByLabel(
			getProviderItem(wrapper, 'anthropic')?.children ?? [],
			'Anthropic credential',
		);

		expect(credentialItem?.checked).toBe(true);
	});

	it('creates a new credential directly from the create action', async () => {
		credentialsByType.value = {};
		const wrapper = await mountSelector({ anthropic: null });
		const dropdown = wrapper.findComponent({ name: 'AiModelSelectorDropdown' });

		dropdown.vm.$emit('select', 'anthropic::configure::anthropicApi');

		expect(openNewCredential).toHaveBeenCalledWith(
			'anthropicApi',
			false,
			false,
			'project-1',
			undefined,
			undefined,
			undefined,
			{ hideAskAssistant: true, onCredentialCreated: expect.any(Function) },
		);
	});

	it('lets the parent resolve the verified default after creating a credential', async () => {
		credentialsByType.value = {};
		const wrapper = await mountSelector({ anthropic: null }, { selectedModel: null });

		getDropdown(wrapper).vm.$emit('select', 'anthropic::configure::anthropicApi');
		const onCredentialCreated = openNewCredential.mock.calls[0]?.[7]?.onCredentialCreated;
		expect(onCredentialCreated).toBeTypeOf('function');

		onCredentialCreated?.({ id: 'new-anthropic-credential' });

		expect(wrapper.emitted('selectCredential')).toEqual([
			['anthropic', 'new-anthropic-credential'],
		]);
		expect(wrapper.emitted('change')).toBeUndefined();
	});

	it('does not replace the selected model after creating a credential', async () => {
		credentialsByType.value = {};
		const wrapper = await mountSelector({ anthropic: null });

		getDropdown(wrapper).vm.$emit('select', 'anthropic::configure::anthropicApi');
		const onCredentialCreated = openNewCredential.mock.calls[0]?.[7]?.onCredentialCreated;
		onCredentialCreated?.({ id: 'new-anthropic-credential' });

		expect(wrapper.emitted('selectCredential')).toEqual([
			['anthropic', 'new-anthropic-credential'],
		]);
		expect(wrapper.emitted('change')).toBeUndefined();
	});

	it('opens a new model credential at the body level when requested', async () => {
		credentialsByType.value = {};
		const wrapper = await mountSelector({ anthropic: null }, { credentialModalAppendToBody: true });

		getDropdown(wrapper).vm.$emit('select', 'anthropic::configure::anthropicApi');

		expect(openNewCredential).toHaveBeenCalledWith(
			'anthropicApi',
			false,
			false,
			'project-1',
			undefined,
			undefined,
			undefined,
			{
				hideAskAssistant: true,
				appendToBody: true,
				onCredentialCreated: expect.any(Function),
			},
		);
	});

	it('offers free OpenAI credits when the user can claim and has no OpenAI credential', async () => {
		credentialsByType.value = {};
		freeAiCreditsState.userCanClaimOpenAiCredits.value = true;

		const wrapper = await mountSelector({});
		const openAiItem = getProviderItem(wrapper, 'openai');
		const freeCreditsItem = getFreeOpenAiCreditsItem(wrapper);
		const openAiChildLabels = openAiItem?.children?.map((item) => item.label) ?? [];

		// Two independent offers: the badge marks free OpenAI credits, the pill marks
		// n8n Connect. The gateway is disabled here, so only the badge shows.
		expect(openAiItem?.data?.badgeLabel).toBe('free credits');
		expect(openAiItem?.data?.actionPill).toBeUndefined();
		expect(JSON.stringify(openAiItem?.children ?? [])).toContain('Use free OpenAI credits');
		expect(openAiChildLabels.indexOf('Use free OpenAI credits')).toBeLessThan(
			openAiChildLabels.indexOf('Create credential'),
		);
		expect(freeCreditsItem?.data?.description).toBe(
			'Get 100 free OpenAI API credits. Try it with gpt-5-mini.',
		);
		expect(freeCreditsItem?.data?.descriptionTooltipTeleported).toBe(false);
		expect(freeCreditsItem?.data?.description).not.toContain('These free credits are only for');
		expect(baseText).toHaveBeenCalledWith('agents.modelSelector.freeCredits.description', {
			interpolate: { credits: 100 },
		});
	});

	it('offers free OpenAI credits when a different model provider credential exists', async () => {
		freeAiCreditsState.userCanClaimOpenAiCredits.value = true;

		const wrapper = await mountSelector({});
		const openAiItem = getProviderItem(wrapper, 'openai');

		expect(JSON.stringify(openAiItem?.children ?? [])).toContain('Use free OpenAI credits');
	});

	it('does not offer free OpenAI credits when the user cannot claim credits', async () => {
		credentialsByType.value = {};

		const wrapper = await mountSelector({});
		const openAiItem = getProviderItem(wrapper, 'openai');

		expect(openAiItem?.data?.badgeLabel).toBeUndefined();
		expect(JSON.stringify(openAiItem?.children ?? [])).not.toContain('Use free OpenAI credits');
	});

	it('does not offer or claim free OpenAI credits without credential-create permission', async () => {
		credentialsByType.value = {};
		freeAiCreditsState.userCanClaimOpenAiCredits.value = true;
		canCreateCredentials.value = false;

		const wrapper = await mountSelector({});
		const openAiItem = getProviderItem(wrapper, 'openai');

		expect(openAiItem?.data?.badgeLabel).toBeUndefined();
		expect(JSON.stringify(openAiItem?.children ?? [])).not.toContain('Use free OpenAI credits');

		getDropdown(wrapper).vm.$emit('select', 'openai::freeCredits::gpt-5-mini');
		await flushPromises();

		expect(freeAiCreditsState.claimCreditsAndGetCredential).not.toHaveBeenCalled();
	});

	it('keeps free OpenAI credits searchable by provider and action label', async () => {
		credentialsByType.value = {};
		freeAiCreditsState.userCanClaimOpenAiCredits.value = true;

		const wrapper = await mountSelector({});
		const dropdown = getDropdown(wrapper);

		dropdown.vm.$emit('search', 'free');
		await wrapper.vm.$nextTick();
		expect(getFreeOpenAiCreditsItem(wrapper)?.label).toBe('Use free OpenAI credits');

		dropdown.vm.$emit('search', 'openai');
		await wrapper.vm.$nextTick();
		expect(getFreeOpenAiCreditsItem(wrapper)?.label).toBe('Use free OpenAI credits');
	});

	it('claims free OpenAI credits and selects gpt-5-mini', async () => {
		credentialsByType.value = {};
		freeAiCreditsState.userCanClaimOpenAiCredits.value = true;
		freeAiCreditsState.claimCreditsAndGetCredential.mockResolvedValueOnce({
			id: 'free-openai-credential',
			name: 'n8n free OpenAI API credits',
			type: 'openAiApi',
		});

		const wrapper = await mountSelector({});
		getDropdown(wrapper).vm.$emit('select', 'openai::freeCredits::gpt-5-mini');
		await flushPromises();

		expect(freeAiCreditsState.claimCreditsAndGetCredential).toHaveBeenCalledWith(
			'agentBuilderModelSelector',
			'project-1',
		);
		expect(wrapper.emitted('selectCredential')).toEqual([['openai', 'free-openai-credential']]);
		expect(wrapper.emitted('change')).toEqual([[{ provider: 'openai', model: 'gpt-5-mini' }]]);
	});
});
