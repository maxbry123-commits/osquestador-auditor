import { createComponentRenderer } from '@/__tests__/render';
import RedactedDataState from './RedactedDataState.vue';

const renderComponent = createComponentRenderer(RedactedDataState);

describe('RedactedDataState', () => {
	it('should render title', () => {
		const { getByText, getByTestId } = renderComponent({
			props: { title: 'Data is redacted', isDynamicCredentials: false, canReveal: false },
		});

		expect(getByTestId('ndv-data-redacted')).toBeInTheDocument();
		expect(getByText('Data is redacted')).toBeInTheDocument();
	});

	it('should show dynamic credentials description when isDynamicCredentials is true', () => {
		const { getByText, queryByText, getByTestId } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: true, canReveal: false },
		});

		expect(
			getByText(
				'This execution used end-user credentials. Data from end-user credential executions cannot be revealed.',
			),
		).toBeInTheDocument();
		expect(queryByText('Execution data has been redacted.')).not.toBeInTheDocument();
		expect(getByTestId('redacted-data-docs-link').closest('a')).toHaveAttribute(
			'href',
			'https://docs.n8n.io/workflows/executions/execution-data-redaction/',
		);
	});

	it('should show no-permission description when isDynamicCredentials is false and canReveal is false', () => {
		const { getByText, queryByText } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: false },
		});

		expect(
			getByText('Execution data has been redacted. You do not have the permissions to reveal it.'),
		).toBeInTheDocument();
		expect(queryByText('workflow settings')).not.toBeInTheDocument();
	});

	it('should show standard description with workflow settings link when isDynamicCredentials is false and canReveal is true', () => {
		const { getByText } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: true },
		});

		expect(getByText('Execution data has been redacted.')).toBeInTheDocument();
		expect(getByText('workflow settings')).toBeInTheDocument();
	});

	it('should show reveal button when canReveal is true', () => {
		const { getByTestId } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: true },
		});

		expect(getByTestId('ndv-reveal-redacted-data')).toBeInTheDocument();
	});

	it('should not show reveal button when canReveal is false', () => {
		const { queryByTestId } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: false },
		});

		expect(queryByTestId('ndv-reveal-redacted-data')).not.toBeInTheDocument();
	});

	it('should emit "reveal" when reveal button is clicked', async () => {
		const { getByTestId, emitted } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: true },
		});

		getByTestId('ndv-reveal-redacted-data').click();

		expect(emitted('reveal')).toHaveLength(1);
	});

	it('should emit "openSettings" when workflow settings link is clicked', async () => {
		const { getByText, emitted } = renderComponent({
			props: { title: 'Redacted', isDynamicCredentials: false, canReveal: true },
		});

		getByText('workflow settings').click();

		expect(emitted('openSettings')).toHaveLength(1);
	});

	it.each([
		{ isDynamicCredentials: false, canReveal: true },
		{ isDynamicCredentials: false, canReveal: false },
	])(
		'should show docs link regardless of redaction reason (%o)',
		({ isDynamicCredentials, canReveal }) => {
			const { getByTestId } = renderComponent({
				props: { title: 'Redacted', isDynamicCredentials, canReveal },
			});

			expect(getByTestId('redacted-data-docs-link').closest('a')).toHaveAttribute(
				'href',
				'https://docs.n8n.io/workflows/executions/execution-data-redaction/',
			);
		},
	);
});
