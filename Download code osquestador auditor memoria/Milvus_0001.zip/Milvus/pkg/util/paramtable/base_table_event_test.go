// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package paramtable

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/milvus-io/milvus/pkg/v3/config"
)

func TestBaseTable_SaveFiresEvent(t *testing.T) {
	bt := NewBaseTable(SkipRemote(true), SkipEnv(true))

	called := make(chan *config.Event, 1)
	bt.mgr.Dispatcher.RegisterForKeyPrefix("trace", config.NewHandler("test-trace-prefix", func(e *config.Event) {
		select {
		case called <- e:
		default:
		}
	}))

	err := bt.Save("trace.exporter", "stdout")
	assert.NoError(t, err)

	select {
	case e := <-called:
		assert.Equal(t, strings.ToLower("trace.exporter"), e.Key)
		assert.Equal(t, config.UpdateType, e.EventType)
		assert.Equal(t, "stdout", e.Value)
		assert.True(t, e.HasUpdated)
	default:
		t.Fatalf("expected config event to be fired on Save()")
	}
}
