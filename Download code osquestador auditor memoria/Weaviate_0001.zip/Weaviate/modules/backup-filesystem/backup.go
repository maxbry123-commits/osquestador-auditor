//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package modstgfs

import (
	"context"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"

	"github.com/pkg/errors"
	"github.com/weaviate/weaviate/entities/backup"
	"github.com/weaviate/weaviate/usecases/monitoring"
)

func (m *Module) resolvePath(overridePath string) (string, error) {
	p := m.backupsPath
	if overridePath != "" {
		p = overridePath
	}
	if p == "" {
		return "", fmt.Errorf("backup path must not be empty")
	}
	return p, nil
}

func (m *Module) GetObject(ctx context.Context, backupID, key, overrideBucket, overridePath string) ([]byte, error) {
	basePath, err := m.resolvePath(overridePath)
	if err != nil {
		return nil, err
	}
	metaPath, err := m.getObjectPath(ctx, basePath, backupID, key)
	if err != nil {
		return nil, err
	}

	contents, err := os.ReadFile(metaPath)
	if err != nil {
		return nil, backup.NewErrInternal(errors.Wrapf(err, "get object %s", metaPath))
	}

	metric, err := monitoring.GetMetrics().BackupRestoreDataTransferred.GetMetricWithLabelValues(m.Name(), "class")
	if err == nil {
		metric.Add(float64(len(contents)))
	}

	return contents, nil
}

func (m *Module) getObjectPath(ctx context.Context, path, backupID, key string) (string, error) {
	metaPath := filepath.Join(path, backupID, key)

	if err := ctx.Err(); err != nil {
		return "", backup.NewErrContextExpired(errors.Wrapf(err, "get object path expired %s", metaPath))
	}

	if _, err := os.Stat(metaPath); errors.Is(err, os.ErrNotExist) {
		return "", backup.NewErrNotFound(errors.Wrapf(err, "get object path could not find %s", metaPath))
	} else if err != nil {
		return "", backup.NewErrInternal(errors.Wrapf(err, "get object path %s", metaPath))
	}

	return metaPath, nil
}

// writeFileViaTemp collects r in a temp file and renames it onto destPath once it
// is complete, so a write that returns an error leaves no partial file at destPath
// and keeps whatever was already there. A machine crash can still leave the temp
// file behind, as nothing is synced to disk.
func (m *Module) writeFileViaTemp(destPath string, r io.Reader, perm os.FileMode) (int64, error) {
	tmpPath := destPath + ".tmp"
	f, err := os.OpenFile(tmpPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, perm)
	if err != nil {
		return 0, fmt.Errorf("open file %q: %w", tmpPath, err)
	}

	renamed := false
	defer func() {
		if renamed {
			return
		}
		f.Close()
		if rmErr := os.Remove(tmpPath); rmErr != nil && !os.IsNotExist(rmErr) {
			m.logger.Warnf("remove temp file %q: %v", tmpPath, rmErr)
		}
	}()

	written, err := io.Copy(f, r)
	if err != nil {
		return written, fmt.Errorf("write file %q: %w", destPath, err)
	}
	// Close reports write errors that io.Copy is too early to see.
	if err := f.Close(); err != nil {
		return written, fmt.Errorf("close file %q: %w", destPath, err)
	}
	if err := os.Rename(tmpPath, destPath); err != nil {
		return written, fmt.Errorf("rename to %q: %w", destPath, err)
	}
	renamed = true

	return written, nil
}

func (m *Module) PutObject(ctx context.Context, backupID, key, bucket, overridePath string, byes []byte) error {
	if bucket != "" {
		m.logger.Info("bucket parameter not supported for filesystem backup module!")
	}

	basePath, err := m.resolvePath(overridePath)
	if err != nil {
		return err
	}
	backupPath := path.Join(basePath, backupID, key)

	dir := path.Dir(backupPath)

	if err := os.MkdirAll(dir, os.ModePerm); err != nil {
		return errors.Wrapf(err, "make dir %s", dir)
	}

	if err := os.WriteFile(backupPath, byes, os.ModePerm); err != nil {
		return errors.Wrapf(err, "write file %s", backupPath)
	}

	metric, err := monitoring.GetMetrics().BackupStoreDataTransferred.GetMetricWithLabelValues(m.Name(), "class")
	if err == nil {
		metric.Add(float64(len(byes)))
	}

	return nil
}

func (m *Module) Initialize(ctx context.Context, backupID, overrideBucket, overridePath string) error {
	// TODO: does anything need to be done here?
	return nil
}

func (m *Module) Write(ctx context.Context, backupID, key, overrideBucket, overridePath string, r backup.ReadCloserWithError) (written int64, err error) {
	// Close the reader when done. Use CloseWithError to signal any error to the
	// producer so it sees the actual error instead of "closed pipe".
	defer func() {
		r.CloseWithError(err)
	}()

	basePath, err := m.resolvePath(overridePath)
	if err != nil {
		return 0, err
	}
	backupPath := filepath.Join(basePath, backupID, key)
	dir := path.Dir(backupPath)
	if err := os.MkdirAll(dir, os.ModePerm); err != nil {
		return 0, fmt.Errorf("make dir %q: %w", dir, err)
	}
	written, err = m.writeFileViaTemp(backupPath, r, os.ModePerm)
	if err != nil {
		return written, err
	}

	if metric, err := monitoring.GetMetrics().BackupStoreDataTransferred.
		GetMetricWithLabelValues(m.Name(), "class"); err == nil {
		metric.Add(float64(written))
	}

	return written, err
}

func (m *Module) Read(ctx context.Context, backupID, key, overrideBucket, overridePath string, w io.WriteCloser) (int64, error) {
	defer w.Close()

	basePath, err := m.resolvePath(overridePath)
	if err != nil {
		return -1, err
	}
	sourcePath, err := m.getObjectPath(ctx, basePath, backupID, key)
	if err != nil {
		return 0, fmt.Errorf("source path %s/%s: %w", backupID, key, err)
	}

	// open file
	f, err := os.Open(sourcePath)
	if err != nil {
		return 0, fmt.Errorf("open file %q: %w", sourcePath, err)
	}
	defer f.Close()

	// copy file
	read, err := io.Copy(w, f)
	if err != nil {
		return 0, fmt.Errorf("write : %w", err)
	}

	if metric, err := monitoring.GetMetrics().BackupRestoreDataTransferred.
		GetMetricWithLabelValues(m.Name(), "class"); err == nil {
		metric.Add(float64(read))
	}
	return read, err
}

func (m *Module) SourceDataPath() string {
	return m.dataPath
}

func (m *Module) initBackupBackend(ctx context.Context, backupsPath string) error {
	if backupsPath == "" {
		return fmt.Errorf("empty backup path provided")
	}
	backupsPath = filepath.Clean(backupsPath)
	if !filepath.IsAbs(backupsPath) {
		return fmt.Errorf("relative backup path provided")
	}
	if err := m.createBackupsDir(backupsPath); err != nil {
		return errors.Wrap(err, "invalid backup path provided")
	}
	m.backupsPath = backupsPath

	return nil
}

func (m *Module) createBackupsDir(backupsPath string) error {
	if err := os.MkdirAll(backupsPath, os.ModePerm); err != nil {
		m.logger.WithField("module", m.Name()).
			WithField("action", "create_backups_dir").
			WithError(err).
			Errorf("failed creating backups directory %v", backupsPath)
		return backup.NewErrInternal(errors.Wrap(err, "make backups dir"))
	}
	return nil
}
