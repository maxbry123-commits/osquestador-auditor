//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package config

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/weaviate/weaviate/entities/moduletools"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/usecases/config"
)

func Test_classSettings_Validate(t *testing.T) {
	tests := []struct {
		name            string
		cfg             moduletools.ClassConfig
		wantBaseURL     string
		wantModel       string
		wantTemperature *float64
		wantTopP        *float64
		wantMaxTokens   *int
		wantErr         error
	}{
		{
			name: "default settings",
			cfg: fakeClassConfig{
				classConfig: map[string]interface{}{},
			},
			wantBaseURL: "https://integrate.api.nvidia.com",
			wantModel:   "nvidia/llama-3.1-nemotron-51b-instruct",
			wantErr:     nil,
		},
		{
			name: "everything non default configured",
			cfg: fakeClassConfig{
				classConfig: map[string]interface{}{
					"baseURL":     "http://url.com",
					"model":       "nvidia/llama-3.1-nemoguard-8b-topic-control",
					"temperature": 0.5,
					"topP":        1,
					"maxTokens":   1024,
				},
			},
			wantBaseURL:     "http://url.com",
			wantModel:       "nvidia/llama-3.1-nemoguard-8b-topic-control",
			wantTemperature: ptFloat64(0.5),
			wantTopP:        ptFloat64(1),
			wantMaxTokens:   ptInt(1024),
			wantErr:         nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ic := NewClassSettings(tt.cfg)
			if tt.wantErr != nil {
				assert.Equal(t, tt.wantErr.Error(), ic.Validate(nil).Error())
			} else {
				assert.NoError(t, ic.Validate(nil))
				assert.Equal(t, tt.wantModel, ic.Model())
				assert.Equal(t, tt.wantMaxTokens, ic.MaxTokens())
				assert.Equal(t, tt.wantTemperature, ic.Temperature())
				assert.Equal(t, tt.wantBaseURL, ic.BaseURL())
			}
		})
	}
}

type fakeClassConfig struct {
	classConfig map[string]interface{}
}

func (f fakeClassConfig) Class() map[string]interface{} {
	return f.classConfig
}

func (f fakeClassConfig) Tenant() string {
	return ""
}

func (f fakeClassConfig) ClassByModuleName(moduleName string) map[string]interface{} {
	return f.classConfig
}

func (f fakeClassConfig) Property(propName string) map[string]interface{} {
	return nil
}

func (f fakeClassConfig) TargetVector() string {
	return ""
}

func (f fakeClassConfig) PropertiesDataTypes() map[string]schema.DataType {
	return nil
}

func (f fakeClassConfig) Config() *config.Config {
	return nil
}

func ptInt(in int) *int {
	return &in
}

func ptFloat64(in float64) *float64 {
	return &in
}

func Test_classSettings_ValidateBaseURL(t *testing.T) {
	t.Setenv("MODULES_VALIDATE_BASE_URL", "true")
	tests := []struct {
		name    string
		baseURL string
		wantErr bool
	}{
		{
			name:    "valid HTTPS URL",
			baseURL: "https://api.openai.com",
			wantErr: false,
		},
		{
			name:    "HTTP URL is rejected",
			baseURL: "http://api.example.com",
			wantErr: true,
		},
		{
			name:    "loopback address is rejected",
			baseURL: "https://127.0.0.1",
			wantErr: true,
		},
		{
			name:    "private network address is rejected",
			baseURL: "https://192.168.1.1",
			wantErr: true,
		},
		{
			name:    "empty host is rejected",
			baseURL: "https://",
			wantErr: true,
		},
		{
			name:    "localhost is rejected",
			baseURL: "https://localhost",
			wantErr: true,
		},
		{
			name:    "local domain is rejected",
			baseURL: "https://myhost.local",
			wantErr: true,
		},
		{
			name:    "default URL is valid",
			baseURL: DefaultBaseURL,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ic := NewClassSettings(fakeClassConfig{
				classConfig: map[string]interface{}{
					"baseURL": tt.baseURL,
				},
			})
			err := ic.Validate(nil)
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}
