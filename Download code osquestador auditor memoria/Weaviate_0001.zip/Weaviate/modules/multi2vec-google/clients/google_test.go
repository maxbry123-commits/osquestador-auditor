//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package clients

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/weaviate/weaviate/modules/multi2vec-google/ent"
	"github.com/weaviate/weaviate/usecases/modulecomponents/apikey"
)

func TestClient(t *testing.T) {
	t.Run("when all is fine we vectorize text", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "apiKey",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				assert.Equal(t, "location", location)
				assert.Equal(t, "project", projectID)
				assert.Equal(t, "model", model)
				return server.URL
			},
			logger: nullLogger(),
		}
		expected := &ent.VectorizationResult{
			TextVectors: [][]float32{{0.1, 0.2, 0.3}},
		}
		res, err := c.Vectorize(context.Background(), []string{"This is my text"}, nil, nil, nil,
			ent.VectorizationConfig{
				Location:  "location",
				ProjectID: "project",
				Model:     "model",
			})

		assert.Nil(t, err)
		assert.Equal(t, expected, res)
	})

	t.Run("when all is fine we vectorize image", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "apiKey",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				assert.Equal(t, "location", location)
				assert.Equal(t, "project", projectID)
				assert.Equal(t, "model", model)
				return server.URL
			},
			logger: nullLogger(),
		}
		expected := &ent.VectorizationResult{
			ImageVectors: [][]float32{{0.1, 0.2, 0.3}},
		}
		res, err := c.Vectorize(context.Background(), nil, []string{"base64 encoded image"}, nil, nil,
			ent.VectorizationConfig{
				Location:  "location",
				ProjectID: "project",
				Model:     "model",
			})

		assert.Nil(t, err)
		assert.Equal(t, expected, res)
	})

	t.Run("when the context is expired", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "apiKey",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		ctx, cancel := context.WithDeadline(context.Background(), time.Now())
		defer cancel()

		_, err := c.Vectorize(ctx, []string{"This is my text"}, nil, nil, nil, ent.VectorizationConfig{})

		require.NotNil(t, err)
		assert.Contains(t, err.Error(), "context deadline exceeded")
	})

	t.Run("when the server returns an error", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{
			t:           t,
			serverError: errors.Errorf("nope, not gonna happen"),
		})
		defer server.Close()
		c := &google{
			apiKey:     "apiKey",
			httpClient: &http.Client{},
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		_, err := c.Vectorize(context.Background(), []string{"This is my text"}, nil, nil, nil,
			ent.VectorizationConfig{})

		require.NotNil(t, err)
		assert.EqualError(t, err, "connection to Google failed with status: 500 error: nope, not gonna happen")
	})

	t.Run("when Palm key is passed using X-Palm-Api-Key header", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		ctxWithValue := context.WithValue(context.Background(),
			"X-Palm-Api-Key", []string{"some-key"})

		expected := &ent.VectorizationResult{
			TextVectors: [][]float32{{0.1, 0.2, 0.3}},
		}
		res, err := c.Vectorize(ctxWithValue, []string{"This is my text"}, nil, nil, nil, ent.VectorizationConfig{})

		require.Nil(t, err)
		assert.Equal(t, expected, res)
	})

	t.Run("when Palm key is empty", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		ctx, cancel := context.WithDeadline(context.Background(), time.Now())
		defer cancel()

		_, err := c.Vectorize(ctx, []string{"This is my text"}, nil, nil, nil, ent.VectorizationConfig{})

		require.NotNil(t, err)
		assert.Equal(t, "Google API Key: no api key found "+
			"neither in request header: X-Palm-Api-Key or X-Goog-Api-Key or X-Goog-Vertex-Api-Key or X-Goog-Studio-Api-Key "+
			"nor in environment variable under PALM_APIKEY or GOOGLE_APIKEY", err.Error())
	})

	t.Run("when X-Palm-Api-Key header is passed but empty", func(t *testing.T) {
		server := httptest.NewServer(&fakeHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "",
			googleApiKey: apikey.NewGoogleApiKey(),
			httpClient:   &http.Client{},
			urlBuilderFn: buildURL,
			logger:       nullLogger(),
		}
		ctxWithValue := context.WithValue(context.Background(),
			"X-Palm-Api-Key", []string{""})

		_, err := c.Vectorize(ctxWithValue, []string{"This is my text"}, nil, nil, nil, ent.VectorizationConfig{})

		require.NotNil(t, err)
		assert.Equal(t, "Google API Key: no api key found "+
			"neither in request header: X-Palm-Api-Key or X-Goog-Api-Key or X-Goog-Vertex-Api-Key or X-Goog-Studio-Api-Key "+
			"nor in environment variable under PALM_APIKEY or GOOGLE_APIKEY", err.Error())
	})
}

func TestGetApiKeyWithGeminiHeaders(t *testing.T) {
	geminiConfig := ent.VectorizationConfig{
		ApiEndpoint: "generativelanguage.googleapis.com",
		Model:       "gemini-embedding-2",
	}

	tests := []struct {
		name       string
		headerKey  string
		headerVal  string
		envApiKey  string
		wantApiKey string
		wantErr    bool
	}{
		{
			name:       "X-Goog-Studio-Api-Key header",
			headerKey:  "X-Goog-Studio-Api-Key",
			headerVal:  "studio-key-1",
			wantApiKey: "studio-key-1",
		},
		{
			name:       "X-Google-Studio-Api-Key header",
			headerKey:  "X-Google-Studio-Api-Key",
			headerVal:  "studio-key-2",
			wantApiKey: "studio-key-2",
		},
		{
			name:       "X-Goog-Api-Key header falls through for Gemini",
			headerKey:  "X-Goog-Api-Key",
			headerVal:  "goog-key",
			wantApiKey: "goog-key",
		},
		{
			name:       "X-Palm-Api-Key header falls through for Gemini",
			headerKey:  "X-Palm-Api-Key",
			headerVal:  "palm-key",
			wantApiKey: "palm-key",
		},
		{
			name:       "env api key used as fallback",
			envApiKey:  "env-key",
			wantApiKey: "env-key",
		},
		{
			name:    "no key returns error",
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			server := httptest.NewServer(&fakeGeminiHandler{t: t})
			defer server.Close()
			c := &google{
				apiKey:       tt.envApiKey,
				httpClient:   &http.Client{},
				googleApiKey: apikey.NewGoogleApiKey(),
				urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
					return server.URL
				},
				logger: nullLogger(),
			}
			ctx := context.Background()
			if tt.headerKey != "" {
				ctx = context.WithValue(ctx, tt.headerKey, []string{tt.headerVal})
			}

			res, err := c.Vectorize(ctx, []string{"hello"}, nil, nil, nil, geminiConfig)

			if tt.wantErr {
				require.NotNil(t, err)
				assert.Contains(t, err.Error(), "no api key found")
			} else {
				require.Nil(t, err)
				assert.NotNil(t, res)
			}
		})
	}
}

func TestGetApiKeyVertexHeadersNotUsedForGemini(t *testing.T) {
	// Vertex-specific headers (X-Goog-Vertex-Api-Key) should NOT work for Gemini endpoint
	server := httptest.NewServer(&fakeGeminiHandler{t: t})
	defer server.Close()
	c := &google{
		apiKey:       "",
		httpClient:   &http.Client{},
		googleApiKey: apikey.NewGoogleApiKey(),
		urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
			return server.URL
		},
		logger: nullLogger(),
	}
	ctx := context.WithValue(context.Background(), "X-Goog-Vertex-Api-Key", []string{"vertex-key"})

	_, err := c.Vectorize(ctx, []string{"hello"}, nil, nil, nil, ent.VectorizationConfig{
		ApiEndpoint: "generativelanguage.googleapis.com",
		Model:       "gemini-embedding-2",
	})

	require.NotNil(t, err)
	assert.Contains(t, err.Error(), "no api key found")
}

func TestGetApiKeyVertexHeaders(t *testing.T) {
	vertexConfig := ent.VectorizationConfig{
		Location:  "us-central1",
		ProjectID: "my-project",
		Model:     "multimodalembedding",
	}

	tests := []struct {
		name       string
		headerKey  string
		headerVal  string
		envApiKey  string
		wantApiKey string
	}{
		{
			name:       "X-Goog-Vertex-Api-Key header",
			headerKey:  "X-Goog-Vertex-Api-Key",
			headerVal:  "vertex-key-1",
			wantApiKey: "vertex-key-1",
		},
		{
			name:       "X-Google-Vertex-Api-Key header",
			headerKey:  "X-Google-Vertex-Api-Key",
			headerVal:  "vertex-key-2",
			wantApiKey: "vertex-key-2",
		},
		{
			name:       "X-Goog-Api-Key header falls through for Vertex",
			headerKey:  "X-Goog-Api-Key",
			headerVal:  "goog-key",
			wantApiKey: "goog-key",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			server := httptest.NewServer(&fakeHandler{t: t})
			defer server.Close()
			c := &google{
				apiKey:       tt.envApiKey,
				httpClient:   &http.Client{},
				googleApiKey: apikey.NewGoogleApiKey(),
				urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
					return server.URL
				},
				logger: nullLogger(),
			}
			ctx := context.WithValue(context.Background(), tt.headerKey, []string{tt.headerVal})

			res, err := c.Vectorize(ctx, []string{"hello"}, nil, nil, nil, vertexConfig)

			require.Nil(t, err)
			assert.NotNil(t, res)
		})
	}
}

func TestGeminiStudioHeaderNotUsedForVertex(t *testing.T) {
	// Studio-specific headers should NOT work for Vertex endpoint
	server := httptest.NewServer(&fakeHandler{t: t})
	defer server.Close()
	c := &google{
		apiKey:       "",
		httpClient:   &http.Client{},
		googleApiKey: apikey.NewGoogleApiKey(),
		urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
			return server.URL
		},
		logger: nullLogger(),
	}
	ctx := context.WithValue(context.Background(), "X-Goog-Studio-Api-Key", []string{"studio-key"})

	_, err := c.Vectorize(ctx, []string{"hello"}, nil, nil, nil, ent.VectorizationConfig{
		Location:  "us-central1",
		ProjectID: "my-project",
		Model:     "multimodalembedding",
	})

	require.NotNil(t, err)
	assert.Contains(t, err.Error(), "no api key found")
}

func TestGeminiClient(t *testing.T) {
	t.Run("when all is fine we vectorize audio via Gemini API", func(t *testing.T) {
		server := httptest.NewServer(&fakeGeminiHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "apiKey",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		expected := &ent.VectorizationResult{
			AudioVectors: [][]float32{{0.1, 0.2, 0.3}},
		}
		res, err := c.Vectorize(context.Background(), nil, nil, nil, []string{"base64-encoded-audio"},
			ent.VectorizationConfig{
				ApiEndpoint: "generativelanguage.googleapis.com",
				Model:       "gemini-embedding-2",
			})

		assert.Nil(t, err)
		assert.Equal(t, expected, res)
	})

	t.Run("when all is fine we vectorize text and audio via Gemini API", func(t *testing.T) {
		server := httptest.NewServer(&fakeGeminiHandler{t: t})
		defer server.Close()
		c := &google{
			apiKey:       "apiKey",
			httpClient:   &http.Client{},
			googleApiKey: apikey.NewGoogleApiKey(),
			urlBuilderFn: func(apiEndpoint, location, projectID, model string) string {
				return server.URL
			},
			logger: nullLogger(),
		}
		expected := &ent.VectorizationResult{
			TextVectors:  [][]float32{{0.1, 0.2, 0.3}},
			AudioVectors: [][]float32{{0.1, 0.2, 0.3}},
		}
		res, err := c.Vectorize(context.Background(), []string{"some text"}, nil, nil, []string{"base64-encoded-audio"},
			ent.VectorizationConfig{
				ApiEndpoint: "generativelanguage.googleapis.com",
				Model:       "gemini-embedding-2",
			})

		assert.Nil(t, err)
		assert.Equal(t, expected, res)
	})
}

type fakeHandler struct {
	t           *testing.T
	serverError error
}

func (f *fakeHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	assert.Equal(f.t, http.MethodPost, r.Method)

	if f.serverError != nil {
		embeddingResponse := &embeddingsResponse{
			Error: &googleApiError{
				Code:    http.StatusInternalServerError,
				Status:  "error",
				Message: f.serverError.Error(),
			},
		}

		outBytes, err := json.Marshal(embeddingResponse)
		require.Nil(f.t, err)

		w.WriteHeader(http.StatusInternalServerError)
		w.Write(outBytes)
		return
	}

	bodyBytes, err := io.ReadAll(r.Body)
	require.Nil(f.t, err)
	defer r.Body.Close()

	var req embeddingsRequest
	require.Nil(f.t, json.Unmarshal(bodyBytes, &req))

	require.NotNil(f.t, req)
	require.Len(f.t, req.Instances, 1)

	textInput := req.Instances[0].Text
	if textInput != nil {
		assert.NotEmpty(f.t, *textInput)
	}
	imageInput := req.Instances[0].Image
	if imageInput != nil {
		assert.NotEmpty(f.t, *imageInput)
	}

	embedding := []float32{0.1, 0.2, 0.3}

	var resp embeddingsResponse

	if textInput != nil {
		resp = embeddingsResponse{
			Predictions: []prediction{{TextEmbedding: embedding}},
		}
	}
	if imageInput != nil {
		resp = embeddingsResponse{
			Predictions: []prediction{{ImageEmbedding: embedding}},
		}
	}

	outBytes, err := json.Marshal(resp)
	require.Nil(f.t, err)

	w.Write(outBytes)
}

type fakeGeminiHandler struct {
	t           *testing.T
	serverError error
}

func (f *fakeGeminiHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	assert.Equal(f.t, http.MethodPost, r.Method)

	if f.serverError != nil {
		resp := &batchEmbedResponse{
			Error: &googleApiError{
				Code:    http.StatusInternalServerError,
				Status:  "error",
				Message: f.serverError.Error(),
			},
		}
		outBytes, err := json.Marshal(resp)
		require.Nil(f.t, err)
		w.WriteHeader(http.StatusInternalServerError)
		w.Write(outBytes)
		return
	}

	bodyBytes, err := io.ReadAll(r.Body)
	require.Nil(f.t, err)
	defer r.Body.Close()

	var req batchEmbedContents
	require.Nil(f.t, json.Unmarshal(bodyBytes, &req))

	embedding := []float32{0.1, 0.2, 0.3}
	var embeddings []embedContentEmbedding
	for range req.Requests {
		embeddings = append(embeddings, embedContentEmbedding{Values: embedding})
	}

	resp := batchEmbedResponse{Embeddings: embeddings}
	outBytes, err := json.Marshal(resp)
	require.Nil(f.t, err)
	w.Write(outBytes)
}

func nullLogger() logrus.FieldLogger {
	l, _ := test.NewNullLogger()
	return l
}
