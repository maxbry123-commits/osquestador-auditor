//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package config

import (
	"fmt"
	"strings"

	"github.com/pkg/errors"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/moduletools"
	basesettings "github.com/weaviate/weaviate/usecases/modulecomponents/settings"
)

const (
	apiEndpointProperty = "apiEndpoint"
	projectIDProperty   = "projectId"
	endpointIDProperty  = "endpointId"
	regionProperty      = "region"
	locationProperty    = "location"
	modelIDProperty     = "modelId"
	modelProperty       = "model"
	temperatureProperty = "temperature"
	tokenLimitProperty  = "tokenLimit"
	topPProperty        = "topP"
	topKProperty        = "topK"
)

var (
	DefaultGoogleApiEndpoint          = "us-central1-aiplatform.googleapis.com"
	DefaultGoogleModel                = "chat-bison"
	DefaultGoogleRegion               = "us-central1"
	DefaultGoogleLocation             = "us-central1"
	DefaultTokenLimit                 = 1024
	DefaultTokenLimitGemini1_0        = 2048
	DefaultTokenLimitGemini1_0_Vision = 2048
	DefaultTokenLimitGemini1_5        = 8192
	DefaulGenerativeAIApiEndpoint     = "generativelanguage.googleapis.com"
	DefaulGenerativeAIModelID         = "chat-bison-001"
)

type ClassSettings interface {
	Validate(class *models.Class) error
	// Module settings
	ApiEndpoint() string
	ProjectID() string
	EndpointID() string
	Region() string
	Location() string

	ModelID() string
	Model() string
	// parameters
	// 0.0 - 1.0
	Temperature() *float64
	// 1 - 1024 / 2048 Gemini 1.0 / 8192 Gemini 1.5
	TokenLimit() *int
	// 1 -
	TopK() *int
	// 0.0 - 1.0
	TopP() *float64
}

type classSettings struct {
	cfg                  moduletools.ClassConfig
	propertyValuesHelper basesettings.PropertyValuesHelper
}

func NewClassSettings(cfg moduletools.ClassConfig) ClassSettings {
	return &classSettings{
		cfg:                  cfg,
		propertyValuesHelper: basesettings.NewPropertyValuesHelperWithAltNames("generative-google", []string{"generative-palm"}),
	}
}

func (ic *classSettings) Validate(class *models.Class) error {
	if ic.cfg == nil {
		// we would receive a nil-config on cross-class requests, such as Explore{}
		return errors.New("empty config")
	}

	var errorMessages []string

	apiEndpoint := ic.ApiEndpoint()
	projectID := ic.ProjectID()
	if apiEndpoint != DefaulGenerativeAIApiEndpoint && projectID == "" {
		errorMessages = append(errorMessages, fmt.Sprintf("%s cannot be empty", projectIDProperty))
	}
	if temperature := ic.Temperature(); temperature != nil && (*temperature < 0 || *temperature > 1) {
		errorMessages = append(errorMessages, fmt.Sprintf("%s has to be float value between 0 and 1", temperatureProperty))
	}
	if tokenLimit := ic.TokenLimit(); tokenLimit != nil && (*tokenLimit < 1 || *tokenLimit > ic.getDefaultTokenLimit(ic.getModel())) {
		errorMessages = append(errorMessages, fmt.Sprintf("%s has to be an integer value between 1 and %v", tokenLimitProperty, ic.getDefaultTokenLimit(ic.getModel())))
	}
	if topK := ic.TopK(); topK != nil && *topK < 1 {
		errorMessages = append(errorMessages, fmt.Sprintf("%s has to be an integer value above or equal 1", topKProperty))
	}
	if topP := ic.TopP(); topP != nil && (*topP < 0 || *topP > 1) {
		errorMessages = append(errorMessages, fmt.Sprintf("%s has to be float value between 0 and 1", topPProperty))
	}
	if len(errorMessages) > 0 {
		return fmt.Errorf("%s", strings.Join(errorMessages, ", "))
	}

	return nil
}

func (ic *classSettings) getStringProperty(name, defaultValue string) string {
	return ic.propertyValuesHelper.GetPropertyAsString(ic.cfg, name, defaultValue)
}

// getOptionalFloatProperty returns nil when the property is not set, so that no
// default is sent to the provider. wrongVal is an out-of-range sentinel returned
// when the property is present but has an invalid (non-numeric) type, so that
// Validate rejects it instead of silently skipping validation.
func (ic *classSettings) getOptionalFloatProperty(name string, wrongVal float64) *float64 {
	return ic.propertyValuesHelper.GetPropertyAsFloat64WithNotExists(ic.cfg, name, &wrongVal, nil)
}

// getOptionalIntProperty behaves like getOptionalFloatProperty for integer properties.
func (ic *classSettings) getOptionalIntProperty(name string, wrongVal int) *int {
	return ic.propertyValuesHelper.GetPropertyAsIntWithNotExists(ic.cfg, name, &wrongVal, nil)
}

func (ic *classSettings) getApiEndpoint(projectID string) string {
	if projectID == "" {
		return DefaulGenerativeAIApiEndpoint
	}
	return DefaultGoogleApiEndpoint
}

func (ic *classSettings) getDefaultModel(apiEndpoint string) string {
	if apiEndpoint == DefaulGenerativeAIApiEndpoint {
		return DefaulGenerativeAIModelID
	}
	return DefaultGoogleModel
}

func (ic *classSettings) getDefaultTokenLimit(model string) int {
	if strings.HasPrefix(model, "gemini-1.5") {
		return DefaultTokenLimitGemini1_5
	}
	if strings.HasPrefix(model, "gemini-1.0") || strings.HasPrefix(model, "gemini-pro") {
		if strings.Contains(model, "vision") {
			return DefaultTokenLimitGemini1_0_Vision
		}
		return DefaultTokenLimitGemini1_0
	}
	return DefaultTokenLimit
}

// Google params
func (ic *classSettings) ApiEndpoint() string {
	return ic.getStringProperty(apiEndpointProperty, ic.getApiEndpoint(ic.ProjectID()))
}

func (ic *classSettings) ProjectID() string {
	return ic.getStringProperty(projectIDProperty, "")
}

func (ic *classSettings) EndpointID() string {
	return ic.getStringProperty(endpointIDProperty, "")
}

func (ic *classSettings) ModelID() string {
	return ic.getStringProperty(modelIDProperty, ic.getDefaultModel(ic.ApiEndpoint()))
}

func (ic *classSettings) Model() string {
	return ic.getStringProperty(modelProperty, "")
}

// getModel returns the model that will actually be used for a request: Model()
// takes precedence over ModelID(), matching the client's request-building logic.
func (ic *classSettings) getModel() string {
	if model := ic.Model(); model != "" {
		return model
	}
	return ic.ModelID()
}

func (ic *classSettings) Region() string {
	return ic.getStringProperty(regionProperty, DefaultGoogleRegion)
}

func (ic *classSettings) Location() string {
	return ic.getStringProperty(locationProperty, DefaultGoogleLocation)
}

// parameters

// 0.0 - 1.0
func (ic *classSettings) Temperature() *float64 {
	return ic.getOptionalFloatProperty(temperatureProperty, -1.0)
}

// 1 - 1024
func (ic *classSettings) TokenLimit() *int {
	return ic.getOptionalIntProperty(tokenLimitProperty, 0)
}

// 1 - 40
func (ic *classSettings) TopK() *int {
	return ic.getOptionalIntProperty(topKProperty, 0)
}

// 0.0 - 1.0
func (ic *classSettings) TopP() *float64 {
	return ic.getOptionalFloatProperty(topPProperty, -1.0)
}
