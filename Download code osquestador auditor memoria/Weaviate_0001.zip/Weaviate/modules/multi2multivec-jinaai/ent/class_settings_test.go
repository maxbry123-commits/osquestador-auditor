//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package ent

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/weaviate/weaviate/entities/moduletools"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/usecases/config"
)

func Test_classSettings_Validate(t *testing.T) {
	type fields struct {
		cfg moduletools.ClassConfig
	}
	tests := []struct {
		name    string
		fields  fields
		wantErr bool
	}{
		{
			name:    "should not pass with empty config",
			wantErr: true,
		},
		{
			name: "should not pass with nil config",
			fields: fields{
				cfg: nil,
			},
			wantErr: true,
		},
		{
			name: "should not pass with nil imageFields",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("model", "model").addSetting("imageFields", nil).build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with fault imageFields value",
			fields: fields{
				cfg: newConfigBuilder().addSetting("imageFields", []string{}).build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with empty imageFields",
			fields: fields{
				cfg: newConfigBuilder().addSetting("imageFields", []interface{}{}).build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with empty string in imageFields",
			fields: fields{
				cfg: newConfigBuilder().addSetting("imageFields", []interface{}{""}).build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with int value in imageFields",
			fields: fields{
				cfg: newConfigBuilder().addSetting("imageFields", []interface{}{1.0}).build(),
			},
			wantErr: true,
		},
		{
			name: "should pass with proper value in imageFields",
			fields: fields{
				cfg: newConfigBuilder().addSetting("imageFields", []interface{}{"field"}).build(),
			},
		},
		{
			name: "should not pass with both values in imageFields and textFields defined",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("imageFields", []interface{}{"imageField"}).
					addSetting("textFields", []interface{}{"textField"}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with 2 imageFields and 2 textFields",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1", "imageField2"}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with values in 2 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1", "imageField2"}).
					addWeights([]interface{}{1, 2}, []interface{}{1, 2}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with values in 1 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1"}).
					addWeights([]interface{}{1, 2}, []interface{}{1}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with values in 2 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1"}).
					addWeights([]interface{}{1, 2}, []interface{}{1}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with proper value in 1 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1"}).
					addWeights([]interface{}{1}, []interface{}{1}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with not proper weight value in 2 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1"}).
					addWeights([]interface{}{1, "aaaa"}, []interface{}{1}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should not pass with not proper weight value in 2 imageFields and 2 textFields and weights",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"textField1", "textField2"}).
					addSetting("imageFields", []interface{}{"imageField1"}).
					addWeights([]interface{}{json.Number("1"), json.Number("2")}, []interface{}{json.Number("3")}).
					build(),
			},
			wantErr: true,
		},
		{
			name: "should pass with 1 imageFields defined",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("imageFields", []interface{}{"image1"}).
					build(),
			},
			wantErr: false,
		},
		{
			name: "should pass with 1 textFields defined",
			fields: fields{
				cfg: newConfigBuilder().
					addSetting("textFields", []interface{}{"text1"}).
					build(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ic := NewClassSettings(tt.fields.cfg)
			if err := ic.Validate(); (err != nil) != tt.wantErr {
				t.Errorf("classSettings.Validate() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

type builder struct {
	fakeClassConfig *fakeClassConfig
}

func newConfigBuilder() *builder {
	return &builder{
		fakeClassConfig: &fakeClassConfig{config: map[string]interface{}{}},
	}
}

func (b *builder) addSetting(name string, value interface{}) *builder {
	b.fakeClassConfig.config[name] = value
	return b
}

func (b *builder) addWeights(textWeights, imageWeights []interface{}) *builder {
	if textWeights != nil || imageWeights != nil {
		weightSettings := map[string]interface{}{}
		if textWeights != nil {
			weightSettings["textFields"] = textWeights
		}
		if imageWeights != nil {
			weightSettings["imageFields"] = imageWeights
		}
		b.fakeClassConfig.config["weights"] = weightSettings
	}
	return b
}

func (b *builder) build() *fakeClassConfig {
	return b.fakeClassConfig
}

type fakeClassConfig struct {
	config map[string]interface{}
}

func (c fakeClassConfig) Class() map[string]interface{} {
	return c.config
}

func (c fakeClassConfig) ClassByModuleName(moduleName string) map[string]interface{} {
	return c.config
}

func (c fakeClassConfig) Property(propName string) map[string]interface{} {
	return c.config
}

func (f fakeClassConfig) Tenant() string {
	return ""
}

func (f fakeClassConfig) TargetVector() string {
	return ""
}

func (f fakeClassConfig) PropertiesDataTypes() map[string]schema.DataType {
	return nil
}

func (f fakeClassConfig) Config() *config.Config {
	return nil
}

func Test_classSettings_ValidateBaseURL(t *testing.T) {
	t.Setenv("MODULES_VALIDATE_BASE_URL", "true")
	tests := []struct {
		name    string
		baseURL string
		wantErr bool
	}{
		{
			name:    "valid HTTPS URL",
			baseURL: "https://api.openai.com",
			wantErr: false,
		},
		{
			name:    "HTTP URL is rejected",
			baseURL: "http://api.example.com",
			wantErr: true,
		},
		{
			name:    "loopback address is rejected",
			baseURL: "https://127.0.0.1",
			wantErr: true,
		},
		{
			name:    "private network address is rejected",
			baseURL: "https://192.168.1.1",
			wantErr: true,
		},
		{
			name:    "empty host is rejected",
			baseURL: "https://",
			wantErr: true,
		},
		{
			name:    "localhost is rejected",
			baseURL: "https://localhost",
			wantErr: true,
		},
		{
			name:    "local domain is rejected",
			baseURL: "https://myhost.local",
			wantErr: true,
		},
		{
			name:    "default URL is valid",
			baseURL: DefaultBaseURL,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ic := NewClassSettings(newConfigBuilder().
				addSetting("imageFields", []interface{}{"field"}).
				addSetting("baseURL", tt.baseURL).
				build())
			err := ic.Validate()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}
