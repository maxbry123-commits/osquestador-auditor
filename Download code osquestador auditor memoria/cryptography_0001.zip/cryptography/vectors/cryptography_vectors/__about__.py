# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

__all__ = [
    "__version__",
]

__version__ = "51.0.0-dev1"
