// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#include <boost/filesystem/operations.hpp>
#include <fmt/format.h>
#include <gtest/gtest.h>
#include <knowhere/comp/index_param.h>

#include "common/Array.h"
#include "common/CDataType.h"
#include "common/Consts.h"
#include "common/EasyAssert.h"
#include "index/Meta.h"
#include "index/Utils.h"
#include "storage/Util.h"
#include "indexbuilder/IndexFactory.h"
#include "storage/InsertData.h"
#include "storage/PayloadReader.h"
#include "test_utils/indexbuilder_test_utils.h"
#include "test_utils/storage_test_utils.h"

#define private public
#include "indexbuilder/ScalarIndexCreator.h"

constexpr int64_t nb = 100;
namespace schemapb = milvus::proto::schema;
using milvus::indexbuilder::ScalarIndexCreatorPtr;
using ScalarTestParams = std::pair<MapParams, MapParams>;

namespace {
template <typename T,
          typename = std::enable_if_t<std::is_arithmetic_v<T> |
                                      std::is_same_v<T, std::string>>>
inline void
build_index(const ScalarIndexCreatorPtr& creator, const std::vector<T>& arr) {
    const int64_t dim = 8;  // not important here
    auto dataset = knowhere::GenDataSet(arr.size(), dim, arr.data());
    creator->Build(dataset);
}

template <>
inline void
build_index(const ScalarIndexCreatorPtr& creator,
            const std::vector<bool>& arr) {
    schemapb::BoolArray pbarr;
    for (auto b : arr) {
        pbarr.add_data(b);
    }
    auto ds = GenDsFromPB(pbarr);

    creator->Build(ds);

    delete[] (char*)(ds->GetTensor());
}

template <>
inline void
build_index(const ScalarIndexCreatorPtr& creator,
            const std::vector<std::string>& arr) {
    schemapb::StringArray pbarr;
    *(pbarr.mutable_data()) = {arr.begin(), arr.end()};
    auto ds = GenDsFromPB(pbarr);

    creator->Build(ds);

    delete[] (char*)(ds->GetTensor());
}

}  // namespace

template <typename T>
class TypedScalarIndexCreatorTest : public ::testing::Test {
 protected:
    // void
    // SetUp() override {
    // }

    // void
    // TearDown() override {
    // }
};

using ScalarT = ::testing::
    Types<bool, int8_t, int16_t, int32_t, int64_t, float, double, std::string>;

TYPED_TEST_SUITE_P(TypedScalarIndexCreatorTest);

TYPED_TEST_P(TypedScalarIndexCreatorTest, Dummy) {
    using T = TypeParam;
    std::cout << typeid(T()).name() << std::endl;
    PrintMapParams(GenParams<T>());
}

TYPED_TEST_P(TypedScalarIndexCreatorTest, Constructor) {
    using T = TypeParam;
    auto dtype = milvus::GetDType<T>();
    for (const auto& tp : GenParams<T>()) {
        auto type_params = tp.first;
        auto index_params = tp.second;

        milvus::Config config;
        for (auto iter = index_params.begin(); iter != index_params.end();
             ++iter) {
            config[iter->first] = iter->second;
        }
        for (auto iter = type_params.begin(); iter != type_params.end();
             ++iter) {
            config[iter->first] = iter->second;
        }

        auto creator = milvus::indexbuilder::CreateScalarIndex(
            milvus::DataType(dtype),
            config,
            milvus::storage::FileManagerContext());
    }
}

TYPED_TEST_P(TypedScalarIndexCreatorTest, Codec) {
    using T = TypeParam;
    auto dtype = milvus::GetDType<T>();
    for (const auto& tp : GenParams<T>()) {
        auto type_params = tp.first;
        auto index_params = tp.second;

        milvus::Config config;
        for (auto iter = index_params.begin(); iter != index_params.end();
             ++iter) {
            config[iter->first] = iter->second;
        }
        for (auto iter = type_params.begin(); iter != type_params.end();
             ++iter) {
            config[iter->first] = iter->second;
        }
        auto creator = milvus::indexbuilder::CreateScalarIndex(
            milvus::DataType(dtype),
            config,
            milvus::storage::FileManagerContext());
        auto arr = GenSortedArr<T>(nb);
        build_index<T>(creator, arr);
        auto binary_set = creator->Serialize();
        auto copy_creator = milvus::indexbuilder::CreateScalarIndex(
            milvus::DataType(dtype),
            config,
            milvus::storage::FileManagerContext());
        copy_creator->Load(binary_set);
    }
}

REGISTER_TYPED_TEST_SUITE_P(TypedScalarIndexCreatorTest,
                            Dummy,
                            Constructor,
                            Codec);

INSTANTIATE_TYPED_TEST_SUITE_P(ArithmeticCheck,
                               TypedScalarIndexCreatorTest,
                               ScalarT);

TEST(ScalarIndexCreatorTest, CreateTextMatchIndexForTextField) {
    auto storage_config = get_default_local_storage_config();
    auto chunk_manager = milvus::storage::CreateChunkManager(storage_config);
    auto fs = milvus::storage::InitArrowFileSystem(storage_config);

    milvus::storage::FieldDataMeta field_meta{1, 2, 3, 101};
    field_meta.field_schema.set_data_type(
        milvus::proto::schema::DataType::Text);
    field_meta.field_schema.set_fieldid(101);
    field_meta.field_schema.set_name("text");
    field_meta.field_schema.add_type_params()->set_key("enable_analyzer");
    field_meta.field_schema.mutable_type_params(0)->set_value("true");
    field_meta.field_schema.add_type_params()->set_key("analyzer_params");
    field_meta.field_schema.mutable_type_params(1)->set_value(
        R"({"tokenizer":"standard"})");

    milvus::storage::IndexMeta index_meta{3, 101, 1000, 0};
    milvus::storage::FileManagerContext ctx(
        field_meta, index_meta, chunk_manager, fs);

    milvus::Config config;
    config[milvus::index::INDEX_TYPE] = milvus::index::INVERTED_INDEX_TYPE;
    config["is_text_match"] = "true";
    config[milvus::index::SCALAR_INDEX_ENGINE_VERSION] = 3;
    config[milvus::index::TANTIVY_INDEX_VERSION] =
        milvus::index::TANTIVY_INDEX_LATEST_VERSION;

    auto creator =
        milvus::indexbuilder::IndexFactory::GetInstance().CreateIndex(
            milvus::DataType::TEXT, config, ctx);
    ASSERT_NE(creator, nullptr);
}

TEST(ScalarIndexCreatorTest, EmptyNestedIndexBuildSkipsPersistence) {
    constexpr int64_t row_count = 8;
    constexpr int64_t field_id = 101;

    struct TestCase {
        const char* index_type;
        schemapb::DataType element_type;
    };
    const std::vector<TestCase> test_cases = {
        {milvus::index::ASCENDING_SORT, schemapb::DataType::Int32},
        {milvus::index::ASCENDING_SORT, schemapb::DataType::String},
        {milvus::index::BITMAP_INDEX_TYPE, schemapb::DataType::Int32},
        {milvus::index::BITMAP_INDEX_TYPE, schemapb::DataType::String},
    };

    auto storage_config = get_default_local_storage_config();
    auto chunk_manager = milvus::storage::CreateChunkManager(storage_config);
    auto fs = milvus::storage::InitArrowFileSystem(storage_config);

    int64_t build_id = 2000;
    for (const auto& test_case : test_cases) {
        for (const auto engine_version : {1, 3}) {
            SCOPED_TRACE(
                fmt::format("index={}, element={}, version={}",
                            test_case.index_type,
                            schemapb::DataType_Name(test_case.element_type),
                            engine_version));

            schemapb::FieldSchema field_schema;
            field_schema.set_fieldid(field_id);
            field_schema.set_name("profile[values]");
            field_schema.set_data_type(schemapb::DataType::Array);
            field_schema.set_element_type(test_case.element_type);

            milvus::storage::FieldDataMeta field_meta{
                1, 2, 3, field_id, field_schema};
            milvus::storage::IndexMeta index_meta{3, field_id, build_id, 1};

            std::vector<schemapb::ScalarField> scalar_arrays(row_count);
            std::vector<milvus::Array> arrays;
            arrays.reserve(row_count);
            for (auto& scalar_array : scalar_arrays) {
                if (test_case.element_type == schemapb::DataType::String) {
                    scalar_array.mutable_string_data();
                } else {
                    scalar_array.mutable_int_data();
                }
                arrays.emplace_back(scalar_array);
            }

            auto field_data = milvus::storage::CreateFieldData(
                milvus::DataType::ARRAY, milvus::DataType::NONE, false);
            field_data->FillFieldData(arrays.data(), arrays.size());

            auto payload_reader =
                std::make_shared<milvus::storage::PayloadReader>(field_data);
            milvus::storage::InsertData insert_data(payload_reader);
            insert_data.SetFieldDataMeta(field_meta);
            insert_data.SetTimestamps(0, 100);
            auto serialized =
                insert_data.Serialize(milvus::storage::StorageType::Remote);

            auto log_root = fmt::format(
                "{}/scalar_creator_empty_nested_{}", TestRemotePath, build_id);
            boost::filesystem::remove_all(log_root);
            auto log_path = fmt::format("{}/insert_log", log_root);
            chunk_manager->Write(
                log_path, serialized.data(), serialized.size());

            milvus::storage::FileManagerContext ctx(
                field_meta, index_meta, chunk_manager, fs);
            milvus::Config config;
            config[milvus::index::INDEX_TYPE] = test_case.index_type;
            config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
            config[INDEX_NUM_ROWS_KEY] = row_count;
            config[milvus::index::SCALAR_INDEX_ENGINE_VERSION] = engine_version;

            auto creator = milvus::indexbuilder::CreateScalarIndex(
                milvus::DataType::ARRAY, config, ctx);
            ASSERT_NO_THROW(creator->Build());

            auto binary_set = creator->Serialize();
            EXPECT_TRUE(binary_set.binary_map_.empty());

            auto stats = creator->Upload();
            ASSERT_NE(stats, nullptr);
            EXPECT_EQ(stats->GetMemSize(), 0);
            EXPECT_EQ(stats->GetSerializedSize(), 0);
            EXPECT_TRUE(stats->GetIndexFiles().empty());

            boost::filesystem::remove_all(log_root);
            ++build_id;
        }
    }
}

TEST(ScalarIndexCreatorTest, EmptyRawIndexBuildSkipsPersistence) {
    for (const auto* index_type :
         {milvus::index::ASCENDING_SORT, milvus::index::BITMAP_INDEX_TYPE}) {
        SCOPED_TRACE(fmt::format("index={}", index_type));

        milvus::Config config;
        config[milvus::index::INDEX_TYPE] = index_type;
        auto creator = milvus::indexbuilder::CreateScalarIndex(
            milvus::DataType::INT32,
            config,
            milvus::storage::FileManagerContext());

        const std::vector<int32_t> data;
        ASSERT_NO_THROW(build_index<int32_t>(creator, data));
        EXPECT_TRUE(creator->Serialize().binary_map_.empty());

        auto stats = creator->Upload();
        ASSERT_NE(stats, nullptr);
        EXPECT_EQ(stats->GetMemSize(), 0);
        EXPECT_EQ(stats->GetSerializedSize(), 0);
        EXPECT_TRUE(stats->GetIndexFiles().empty());
    }
}

TEST(ScalarIndexCreatorTest, FMIndexParamsRejectInvalidValuesWithInputCode) {
    auto expect_invalid = [](const std::string& key,
                             const nlohmann::json& value) {
        milvus::Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[key] = value;

        try {
            (void)milvus::indexbuilder::CreateScalarIndex(
                milvus::DataType::VARCHAR,
                config,
                milvus::storage::FileManagerContext());
            FAIL() << "expected invalid FMINDEX parameter " << key << "="
                   << value.dump();
        } catch (const milvus::SegcoreError& e) {
            EXPECT_EQ(e.get_error_code(), milvus::ErrorCode::InvalidParameter);
        }
    };

    for (const auto& value : {nlohmann::json("abc"),
                              nlohmann::json("3"),
                              nlohmann::json("257"),
                              nlohmann::json("8junk"),
                              nlohmann::json(-1),
                              nlohmann::json(8.5)}) {
        expect_invalid(milvus::index::FM_SA_SAMPLE_RATE, value);
    }
    for (const auto& value : {nlohmann::json("abc"),
                              nlohmann::json("4"),
                              nlohmann::json("24"),
                              nlohmann::json("256"),
                              nlohmann::json("64junk"),
                              nlohmann::json(-1),
                              nlohmann::json(64.5)}) {
        expect_invalid(milvus::index::FM_BLOCK_BYTES, value);
    }
}

TEST(ScalarIndexCreatorTest, FMIndexParamsMatchGoLeadingPlusValidation) {
    milvus::Config config;
    config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
    config[milvus::index::FM_SA_SAMPLE_RATE] = "+8";
    config[milvus::index::FM_BLOCK_BYTES] = "+64";

    EXPECT_NO_THROW({
        auto index = milvus::indexbuilder::CreateScalarIndex(
            milvus::DataType::VARCHAR,
            config,
            milvus::storage::FileManagerContext());
        EXPECT_NE(index, nullptr);
    });
}
