// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "common/EasyAssert.h"
#include "common/Geometry.h"
#include "common/Types.h"
#include "geos_c.h"
#include "log/Log.h"

namespace milvus {
namespace exec {

// Cache key: the OWNING SEGMENT OBJECT (segment_instance_uid) plus the field.
//
// Keying on the logical segment id is not enough, because more than one live
// object can carry the same id -- and a cache entry's lifetime is tied to the
// object that built it, not to the logical segment:
//   * a growing and a sealed twin coexist during handoff (querynode keeps two
//     maps keyed by the same id), and
//   * two sealed instances of different versions coexist while the replaced
//     one is released asynchronously (segments/manager.go:409-441).
// In both cases a shared key means the arriving instance reuses the departing
// instance's entry, and the departing instance's destructor then erases the
// cache the still-serving instance depends on. The cache is only ever built
// during load, so it is never rebuilt: every later GIS predicate silently
// falls back to per-row bulk_subscript + WKB re-parsing, with no error and no
// log. The segment id stays in the key for diagnosability only.
inline std::string
MakeCacheKey(uint64_t segment_instance_uid,
             int64_t segment_id,
             FieldId field_id) {
    return std::to_string(segment_instance_uid) + "_" +
           std::to_string(segment_id) + "_" + std::to_string(field_id.get());
}

// Prefix covering every field cache owned by one segment OBJECT, so a
// destructor erases only the entries that object created.
inline std::string
MakeSegmentCachePrefix(uint64_t segment_instance_uid, int64_t segment_id) {
    return std::to_string(segment_instance_uid) + "_" +
           std::to_string(segment_id) + "_";
}

// Vector-based Geometry cache that maintains original field data order.
//
// The cache owns its own GEOS context: every cached Geometry is built and
// destroyed with ctx_, so the cache is fully self-contained and its lifetime
// is independent of the segment that populated it. Combined with the manager
// handing out shared_ptr<SimpleGeometryCache>, an in-flight query keeps the
// cache (and its context) alive even if the owning segment is dropped and
// RemoveSegmentCaches() runs concurrently.
class SimpleGeometryCache {
 public:
    // InitGEOSContext translates an allocation failure into a retriable
    // MemAllocateFailed (GEOS_init_r throws bad_alloc on OOM, it never
    // returns nullptr -- see the helper's comment).
    SimpleGeometryCache() : ctx_(InitGEOSContext("geometry cache")) {
    }

    ~SimpleGeometryCache() {
        // Destroy the cached geometries (each calls GEOSGeom_destroy_r(ctx_,
        // ...)) while ctx_ is still alive, then release the context.
        {
            std::lock_guard<std::shared_mutex> lock(mutex_);
            geometries_.clear();
        }
        if (ctx_ != nullptr) {
            GEOS_finish_r(ctx_);
            ctx_ = nullptr;
        }
    }

    // The cache owns a GEOS context, so it is neither copyable nor movable.
    SimpleGeometryCache(const SimpleGeometryCache&) = delete;
    SimpleGeometryCache&
    operator=(const SimpleGeometryCache&) = delete;

    // Store the WKB for one row at its ABSOLUTE segment offset.
    //
    // Offset-addressed on purpose (this used to be a tail append): readers
    // resolve rows by absolute segment offset (GetByOffsetUnsafe), while a
    // write can throw a retriable MemAllocateFailed mid-batch (TryParseFromWkb
    // on a transient GEOS reader-allocation failure). With a tail append the
    // rows already written before the throw stayed in the vector, so the
    // retried load/insert appended AFTER them and every later row shifted to
    // the wrong offset -- silently returning the wrong geometry. Writing at
    // the reserved absolute offset makes the operation idempotent: a retry
    // overwrites the same slots and alignment can never drift, which is also
    // why publishing the cache in the manager map before it is fully
    // populated (GetOrCreateCache) is safe. Slots skipped over by an
    // out-of-order or failed batch stay default-invalid and readers skip
    // them; such rows are never acked/readable until their write lands.
    //
    // A row with corrupt (unparseable) WKB is stored as an INVALID entry --
    // GetByOffsetUnsafe() returns nullptr for it and every reader skips it --
    // instead of throwing. Throwing here would make a single corrupt row fail
    // the whole segment load whenever the geometry cache is enabled (the write
    // paths deliberately keep such rows: add_geometry / bulk_load index a
    // placeholder MBR rather than dropping them, so they DO reach the cache).
    // A transient resource failure (reader allocation) still throws a
    // retriable system error via TryParseFromWkb -- that is not bad data. One
    // exception we cannot tell apart: an OOM INSIDE GEOS parsing surfaces as
    // the same nullptr as corrupt WKB and is deliberately classified as bad
    // data here (see the KNOWN LIMIT note on TryParseFromWkb).
    void
    AppendDataAt(size_t absolute_offset, const char* wkb_data, size_t size) {
        std::lock_guard<std::shared_mutex> lock(mutex_);

        if (geometries_.size() <= absolute_offset) {
            // Default-constructed gap entries are invalid; a reader that
            // somehow reaches one skips the row, and the owning batch's
            // (re)write fills it in place.
            geometries_.resize(absolute_offset + 1);
        }

        if (size == 0 || wkb_data == nullptr) {
            // Null/empty geometry - store an invalid entry
            geometries_[absolute_offset] = Geometry();
            return;
        }
        Geometry geometry;
        if (!geometry.TryParseFromWkb(ctx_, wkb_data, size)) {
            static std::atomic<int64_t> last_cache_parse_log_us{0};
            if (ShouldLogGeometryThrottled(last_cache_parse_log_us)) {
                LOG_WARN(
                    "unparseable WKB at cache offset {}; caching an invalid "
                    "placeholder entry, readers will skip it (further "
                    "occurrences suppressed briefly)",
                    absolute_offset);
            } else {
                LOG_DEBUG("unparseable WKB at cache offset {}",
                          absolute_offset);
            }
            geometries_[absolute_offset] = Geometry();
            return;
        }
        geometries_[absolute_offset] = std::move(geometry);
    }

    // Get shared lock for batch operations (RAII)
    std::shared_lock<std::shared_mutex>
    AcquireReadLock() const {
        return std::shared_lock<std::shared_mutex>(mutex_);
    }

    // Get Geometry by offset without locking (use with AcquireReadLock).
    //
    // An out-of-range offset returns nullptr, the same "no geometry here,
    // skip the row" answer as an invalid entry -- it must NOT throw. On a
    // growing segment there is a real window where a reader legitimately
    // outruns this cache: SegmentGrowingImpl::Insert feeds the R-Tree
    // (AppendingIndex) before it fills the cache (BuildGeometryCacheForInsert),
    // so a concurrent query whose coarse bitmap is sized by the index's
    // Count() can probe an offset the cache has not reached yet. Those rows
    // are not yet acked, so reporting them as non-matching is correct;
    // throwing a non-retriable UnexpectedError out of a read path is not.
    const Geometry*
    GetByOffsetUnsafe(size_t offset) const {
        if (offset >= geometries_.size()) {
            return nullptr;
        }

        const auto& geometry = geometries_[offset];
        return geometry.IsValid() ? &geometry : nullptr;
    }

    // Get total number of loaded geometries
    size_t
    Size() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return geometries_.size();
    }

    // Get total number of loaded geometries without locking (use with
    // AcquireReadLock). Calling Size() while already holding the read lock
    // would recursively acquire the non-reentrant shared_mutex: that is
    // undefined behavior per [thread.sharedmutex.requirements] regardless of
    // platform, and becomes a real deadlock on writer-preferring
    // implementations once a writer is queued. (Not a claim about this
    // build's std::shared_mutex: on Linux libstdc++ maps it to
    // pthread_rwlock_t, whose glibc default is reader-preferring.)
    size_t
    SizeUnsafe() const {
        return geometries_.size();
    }

 private:
    // ctx_ is declared first so it is destroyed last (after geometries_),
    // guaranteeing the Geometry destructors still see a live context.
    GEOSContextHandle_t ctx_{nullptr};  // Context owned by this cache
    mutable std::shared_mutex mutex_;   // For read/write operations
    std::vector<Geometry> geometries_;  // Direct storage of Geometry objects
};

// Global cache instance per segment+field
class SimpleGeometryCacheManager {
 public:
    static SimpleGeometryCacheManager&
    Instance() {
        static SimpleGeometryCacheManager instance;
        return instance;
    }

    SimpleGeometryCacheManager() = default;

    // Returns a shared_ptr so callers keep the cache alive for the duration of
    // their use even if RemoveSegmentCaches drops it concurrently.
    std::shared_ptr<SimpleGeometryCache>
    GetOrCreateCache(uint64_t segment_instance_uid,
                     int64_t segment_id,
                     FieldId field_id) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto key = MakeCacheKey(segment_instance_uid, segment_id, field_id);
        auto it = caches_.find(key);
        if (it != caches_.end()) {
            return it->second;
        }

        auto cache = std::make_shared<SimpleGeometryCache>();
        caches_.emplace(key, cache);
        return cache;
    }

    std::shared_ptr<SimpleGeometryCache>
    GetCache(uint64_t segment_instance_uid,
             int64_t segment_id,
             FieldId field_id) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto key = MakeCacheKey(segment_instance_uid, segment_id, field_id);
        auto it = caches_.find(key);
        if (it != caches_.end()) {
            return it->second;
        }
        return nullptr;
    }

    // Remove all caches owned by one segment OBJECT -- called from that
    // object's destructor, and deliberately NOT matching any other live
    // instance that shares the same logical segment id (growing/sealed twin,
    // or an older/newer version of the same sealed segment).
    void
    RemoveSegmentCaches(uint64_t segment_instance_uid, int64_t segment_id) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto segment_prefix =
            MakeSegmentCachePrefix(segment_instance_uid, segment_id);
        auto it = caches_.begin();
        while (it != caches_.end()) {
            if (it->first.substr(0, segment_prefix.length()) ==
                segment_prefix) {
                it = caches_.erase(it);
            } else {
                ++it;
            }
        }
    }

 private:
    SimpleGeometryCacheManager(const SimpleGeometryCacheManager&) = delete;
    SimpleGeometryCacheManager&
    operator=(const SimpleGeometryCacheManager&) = delete;

    mutable std::mutex mutex_;
    std::unordered_map<std::string, std::shared_ptr<SimpleGeometryCache>>
        caches_;
};

}  // namespace exec

}  // namespace milvus
