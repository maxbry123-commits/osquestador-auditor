// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include "common/Chunk.h"
#include "common/EasyAssert.h"
#include "common/Types.h"
#include "pb/schema.pb.h"

namespace milvus {

using ArrayOffset = uint64_t;
using ArrayOffsets = std::vector<ArrayOffset>;

class ArrayValue;
class ArrayValueView;

namespace array_detail {

std::shared_ptr<const Chunk>
CreateColumnarArrayChildChunk(
    const std::shared_ptr<const proto::schema::TypeSchema>& array_type,
    ArrayOffset row_count,
    char* data,
    uint64_t size,
    const std::shared_ptr<ChunkMmapGuard>& chunk_mmap_guard);

}  // namespace array_detail

// A read-only view over one recursively serialized Array column chunk.
//
// Physical layout:
//   Array node:
//     [validity bitmap, when this node's TypeSchema is nullable]
//     [alignment padding, when needed][offsets: row_count + 1][child node]
//   Complete root block:
//     [Array node][MMAP_ARRAY_PADDING]
//
// Bitmap bits follow the Chunk convention: 1 means valid and 0 means null.
// Null and empty Arrays have the same repeated offset; the bitmap distinguishes
// them. The terminal array offset is the child row count. The child node
// describes its own physical representation: another Array node, a
// fixed-width payload, or a StringChunk-compatible [byte offsets][chars]
// payload. Each node's TypeSchema supplies its child type and nullability.
//
// Construction flow (implemented in ColumnarArrayChunkBuilder.cpp):
//   1. Sealed, growing mmap, and single-row ArrayValue inputs are normalized
//      into a temporary ColumnarArrayBuildNode tree. BuildNodeFromProtoRows
//      and BuildNodeFromViews recursively build one node per Array level. Each
//      node records its offsets and validity bitmap, while the leaf node
//      collects the flattened scalar payload.
//   2. The builder calculates the serialized size and writes the tree into one
//      contiguous target buffer. A complete column block serializes the root
//      node, including its recursively serialized child, and appends trailing
//      padding. A single-row ArrayValue stores its root length directly and
//      serializes only the child.
//   3. ColumnarArrayChunk::InitializeNodeView reads the current node's offsets,
//      then CreateColumnarArrayChildChunk recursively creates non-owning child
//      Chunk views over the same buffer.
//
// The returned chunk does not own its bytes. Its mmap descriptor (or the
// owning ArrayValueStorage in the single-row heap path) must outlive the chunk
// and all ArrayValueViews derived from it.
class ColumnarArrayChunk final : public Chunk {
    friend class ArrayValue;
    friend class ArrayValueView;
    friend std::shared_ptr<const Chunk>
    array_detail::CreateColumnarArrayChildChunk(
        const std::shared_ptr<const proto::schema::TypeSchema>& array_type,
        ArrayOffset row_count,
        char* data,
        uint64_t size,
        const std::shared_ptr<ChunkMmapGuard>& chunk_mmap_guard);

 public:
    using Ptr = std::shared_ptr<const ColumnarArrayChunk>;

    // Construct a view over a complete root block, whose serialized bytes end
    // with MMAP_ARRAY_PADDING.
    ColumnarArrayChunk(
        int64_t row_nums,
        char* data,
        uint64_t size,
        std::shared_ptr<const proto::schema::TypeSchema> type,
        std::shared_ptr<ChunkMmapGuard> chunk_mmap_guard = nullptr)
        : ColumnarArrayChunk(row_nums,
                             data,
                             size,
                             std::move(type),
                             std::move(chunk_mmap_guard),
                             MMAP_ARRAY_PADDING) {
    }

    size_t
    row_count() const {
        return static_cast<size_t>(RowNums());
    }

    size_t
    byte_size() const {
        return static_cast<size_t>(Size());
    }

    bool
    is_valid(size_t row) const {
        AssertInfo(row < row_count(),
                   "ColumnarArrayChunk row {} out of range {}",
                   row,
                   row_count());
        return isValid(static_cast<int>(row));
    }

    // ViewType is intentionally dependent because ArrayValueView is only
    // completed after this header has been parsed.
    template <typename ViewType = ArrayValueView>
    ViewType
    View(size_t row) const {
        AssertInfo(row < row_count(),
                   "ColumnarArrayChunk row {} out of range {}",
                   row,
                   row_count());
        return ViewType::FromValidated(type_.get(),
                                       child_.get(),
                                       offsets_[row],
                                       offsets_[row + 1],
                                       !isValid(static_cast<int>(row)));
    }

    template <typename ViewType = ArrayValueView>
    std::pair<std::vector<ViewType>, ValidityView>
    Views(std::optional<std::pair<int64_t, int64_t>> offset_len =
              std::nullopt) const {
        int64_t start_offset = 0;
        int64_t len = row_nums_;
        if (offset_len.has_value()) {
            start_offset = offset_len->first;
            len = offset_len->second;
            AssertInfo(
                start_offset >= 0 && start_offset < row_nums_,
                "Retrieve array value views with out-of-bound offset:{}, "
                "len:{}, wrong",
                start_offset,
                len);
            AssertInfo(
                len > 0 && len <= row_nums_,
                "Retrieve array value views with out-of-bound offset:{}, "
                "len:{}, wrong",
                start_offset,
                len);
            AssertInfo(
                start_offset + len <= row_nums_,
                "Retrieve array value views with out-of-bound offset:{}, "
                "len:{}, wrong",
                start_offset,
                len);
        }

        std::vector<ViewType> views;
        views.reserve(len);
        const auto end_offset = start_offset + len;
        for (auto i = start_offset; i < end_offset; ++i) {
            views.emplace_back(View<ViewType>(i));
        }
        return {std::move(views), Validity(start_offset)};
    }

    template <typename ViewType = ArrayValueView>
    std::pair<std::vector<ViewType>, FixedVector<bool>>
    ViewsByOffsets(const FixedVector<int32_t>& offsets) const {
        std::vector<ViewType> views;
        views.reserve(offsets.size());
        FixedVector<bool> valid_data;
        if (nullable_) {
            valid_data.reserve(offsets.size());
        }
        for (auto offset : offsets) {
            AssertInfo(offset >= 0 && offset < row_nums_,
                       "Retrieve array value view with out-of-bound offset:{} "
                       "for chunk rows:{}",
                       offset,
                       row_nums_);
            views.emplace_back(View<ViewType>(offset));
            if (nullable_) {
                valid_data.push_back(isValid(offset));
            }
        }
        return {std::move(views), std::move(valid_data)};
    }

    void
    output_data(size_t row, ScalarFieldProto& output) const {
        AssertInfo(row < row_count(),
                   "ColumnarArrayChunk row {} out of range {}",
                   row,
                   row_count());
        if (!isValid(static_cast<int>(row))) {
            output.Clear();
            return;
        }
        OutputRange(*type_, *child_, offsets_[row], offsets_[row + 1], output);
    }

    ScalarFieldProto
    output_data(size_t row) const {
        ScalarFieldProto output;
        output_data(row, output);
        return output;
    }

    const char*
    ValueAt(int64_t idx) const override {
        ThrowInfo(ErrorCode::Unsupported,
                  "ColumnarArrayChunk::ValueAt is not supported, index {}",
                  idx);
    }

    const proto::schema::TypeSchema&
    type() const {
        return *type_;
    }

    std::span<const ArrayOffset>
    offsets() const {
        return offsets_;
    }

    const Chunk&
    child() const {
        return *child_;
    }

    static size_t
    NodeDataOffset(int64_t row_nums, bool nullable) {
        if (!nullable) {
            return 0;
        }
        const auto rows = static_cast<size_t>(row_nums);
        const auto null_bitmap_bytes = rows / 8 + (rows % 8 != 0);
        return AlignUp(null_bitmap_bytes, alignof(ArrayOffset));
    }

 private:
    // A complete column block includes trailing padding, whether its backing
    // storage is memory or mmap. A child node occupies only its recursive node
    // bytes, so the child Chunk's logical size excludes that block-level
    // padding.
    static constexpr uint64_t kNoTrailingPadding = 0;

    ColumnarArrayChunk(int64_t row_nums,
                       char* data,
                       uint64_t size,
                       std::shared_ptr<const proto::schema::TypeSchema> type,
                       std::shared_ptr<ChunkMmapGuard> chunk_mmap_guard,
                       uint64_t trailing_padding)
        : Chunk(row_nums,
                data,
                size,
                type != nullptr && type->nullable(),
                std::move(chunk_mmap_guard)),
          type_(std::move(type)) {
        AssertInfo(type_ != nullptr,
                   "ColumnarArrayChunk type must not be null");
        ValidateArrayType(*type_);
        const auto node_data_offset =
            NodeDataOffset(row_nums, type_->nullable());
        AssertInfo(size >= node_data_offset + trailing_padding,
                   "columnar array chunk size {} is too small for node "
                   "offset {} and trailing padding {}",
                   size,
                   node_data_offset,
                   trailing_padding);
        InitializeNodeView(data_ + node_data_offset,
                           size_ - node_data_offset - trailing_padding);
    }

    template <typename>
    inline static constexpr bool AlwaysFalse = false;

    static size_t
    AlignUp(size_t value, size_t alignment) {
        return (value + alignment - 1) & ~(alignment - 1);
    }

    static bool
    IsSupportedLeafType(DataType data_type) {
        switch (data_type) {
            case DataType::BOOL:
            case DataType::INT8:
            case DataType::INT16:
            case DataType::INT32:
            case DataType::INT64:
            case DataType::FLOAT:
            case DataType::DOUBLE:
            case DataType::STRING:
            case DataType::VARCHAR:
                return true;
            default:
                return false;
        }
    }

    static size_t
    ExpectedFixedWidth(DataType data_type) {
        switch (data_type) {
            case DataType::BOOL:
                return sizeof(uint8_t);
            case DataType::INT8:
            case DataType::INT16:
            case DataType::INT32:
                // ScalarField stores small integer Array values as int32.
                return sizeof(int32_t);
            case DataType::INT64:
                return sizeof(int64_t);
            case DataType::FLOAT:
                return sizeof(float);
            case DataType::DOUBLE:
                return sizeof(double);
            default:
                ThrowInfo(Unsupported,
                          "ArrayValue leaf type {} is not fixed width",
                          data_type);
        }
    }

    static DataType
    GetElementType(const proto::schema::TypeSchema& type) {
        const auto& element = type.array_element();
        return element.has_array_element() ? DataType::ARRAY
                                           : DataType(element.leaf_type());
    }

 public:
    static void
    ValidateArrayType(const proto::schema::TypeSchema& type) {
        AssertInfo(type.has_array_element(), "ArrayValue type must be ARRAY");

        const auto& element = type.array_element();
        if (element.has_array_element()) {
            ValidateArrayType(element);
            return;
        }

        AssertInfo(element.has_leaf_type(),
                   "ArrayValue element type must be ARRAY or a leaf type");
        const auto element_type = DataType(element.leaf_type());
        AssertInfo(element_type != DataType::NONE,
                   "leaf ArrayValue type must not be NONE");
        AssertInfo(element_type != DataType::ARRAY,
                   "nested ArrayValue must use array_element");
        AssertInfo(IsSupportedLeafType(element_type),
                   "unsupported ArrayValue leaf type {}",
                   element_type);
    }

 private:
    static int32_t
    CheckedLeafRowCount(ArrayOffset row_count) {
        AssertInfo(row_count <= static_cast<ArrayOffset>(
                                    std::numeric_limits<int32_t>::max()),
                   "array leaf row count {} exceeds int32 range",
                   row_count);
        return static_cast<int32_t>(row_count);
    }

    void
    ValidateOffsets() const {
        AssertInfo(offsets_.front() == 0,
                   "ColumnarArrayChunk offsets must start at zero, got {}",
                   offsets_.front());
        AssertInfo(std::is_sorted(offsets_.begin(), offsets_.end()),
                   "ColumnarArrayChunk offsets must be monotonic");
        AssertInfo(offsets_.back() <= static_cast<ArrayOffset>(
                                          std::numeric_limits<int64_t>::max()),
                   "ColumnarArrayChunk child row count {} exceeds int64 range",
                   offsets_.back());
        for (size_t row = 0; row < row_count(); ++row) {
            AssertInfo(isValid(static_cast<int>(row)) ||
                           offsets_[row] == offsets_[row + 1],
                       "null array row {} must have an empty offset range",
                       row);
        }
    }

    static void
    ValidateStringPayload(const char* data,
                          uint64_t size,
                          ArrayOffset row_count) {
        const auto rows = CheckedLeafRowCount(row_count);
        const auto offset_count = static_cast<size_t>(rows) + 1;
        const auto offsets_bytes = offset_count * sizeof(uint32_t);
        AssertInfo(size >= offsets_bytes,
                   "string leaf size {} is smaller than offsets size {}",
                   size,
                   offsets_bytes);
        AssertInfo(size <= std::numeric_limits<uint32_t>::max(),
                   "string leaf size {} exceeds uint32 offset range",
                   size);

        const auto* offsets = reinterpret_cast<const uint32_t*>(data);
        AssertInfo(offsets[0] == offsets_bytes,
                   "string leaf first offset {} does not match header size {}",
                   offsets[0],
                   offsets_bytes);
        AssertInfo(std::is_sorted(offsets, offsets + offset_count),
                   "string leaf offsets must be monotonic");
        AssertInfo(offsets[offset_count - 1] == size,
                   "string leaf terminal offset {} does not match size {}",
                   offsets[offset_count - 1],
                   size);
    }

    void
    InitializeNodeView(char* node_data, uint64_t node_size) {
        AssertInfo(node_data != nullptr,
                   "ColumnarArrayChunk data must not be null");
        AssertInfo(
            reinterpret_cast<uintptr_t>(node_data) % alignof(ArrayOffset) == 0,
            "ColumnarArrayChunk offsets are not {}-byte aligned",
            alignof(ArrayOffset));

        const auto rows = static_cast<size_t>(row_nums_);
        const auto offset_count = rows + 1;
        AssertInfo(offset_count <=
                       std::numeric_limits<size_t>::max() / sizeof(ArrayOffset),
                   "ColumnarArrayChunk offset count {} overflows byte size",
                   offset_count);
        const auto offsets_bytes = offset_count * sizeof(ArrayOffset);
        AssertInfo(node_size >= offsets_bytes,
                   "ColumnarArrayChunk node size {} is smaller than offsets "
                   "size {}",
                   node_size,
                   offsets_bytes);

        offsets_ = std::span<const ArrayOffset>(
            reinterpret_cast<const ArrayOffset*>(node_data), offset_count);
        ValidateOffsets();

        const auto child_rows = offsets_.back();
        auto* child_data = node_data + offsets_bytes;
        const auto child_size = node_size - offsets_bytes;
        child_ = array_detail::CreateColumnarArrayChildChunk(
            type_, child_rows, child_data, child_size, chunk_mmap_guard_);
    }

    static int
    ProtoReserveSize(size_t size) {
        AssertInfo(size <= static_cast<size_t>(std::numeric_limits<int>::max()),
                   "protobuf array size {} exceeds int range",
                   size);
        return static_cast<int>(size);
    }

    template <typename T>
    static T
    ReadScalarElement(const proto::schema::TypeSchema& type,
                      const Chunk& child,
                      size_t index) {
        using ValueType = std::decay_t<T>;

        if constexpr (std::is_same_v<ValueType, bool>) {
            const auto& chunk = static_cast<const FixedWidthChunk&>(child);
            return *reinterpret_cast<const uint8_t*>(
                       chunk.ValueAt(static_cast<int64_t>(index))) != 0;
        } else if constexpr (std::is_same_v<ValueType, int> ||
                             std::is_same_v<ValueType, int64_t> ||
                             std::is_same_v<ValueType, int8_t> ||
                             std::is_same_v<ValueType, int16_t> ||
                             std::is_same_v<ValueType, int32_t> ||
                             std::is_same_v<ValueType, float> ||
                             std::is_same_v<ValueType, double>) {
            const auto element_type = GetElementType(type);
            const auto& chunk = static_cast<const FixedWidthChunk&>(child);
            const auto* value = chunk.ValueAt(static_cast<int64_t>(index));
            switch (element_type) {
                case DataType::INT8:
                case DataType::INT16:
                case DataType::INT32:
                    return static_cast<T>(
                        *reinterpret_cast<const int32_t*>(value));
                case DataType::INT64:
                    return static_cast<T>(
                        *reinterpret_cast<const int64_t*>(value));
                case DataType::FLOAT:
                    return static_cast<T>(
                        *reinterpret_cast<const float*>(value));
                case DataType::DOUBLE:
                    return static_cast<T>(
                        *reinterpret_cast<const double*>(value));
                default:
                    ThrowInfo(Unsupported,
                              "unsupported array element type {}",
                              element_type);
            }
        } else if constexpr (std::is_same_v<ValueType, std::string_view> ||
                             std::is_same_v<ValueType, std::string>) {
            const auto& chunk = static_cast<const StringChunk&>(child);
            const auto value = chunk[static_cast<int>(index)];
            return T(value.data(), value.size());
        } else {
            static_assert(AlwaysFalse<T>,
                          "unsupported scalar element value type");
        }
    }

    static void
    OutputRange(const proto::schema::TypeSchema& type,
                const Chunk& child,
                ArrayOffset begin,
                ArrayOffset end,
                ScalarFieldProto& output) {
        output.Clear();

        const auto element_type = GetElementType(type);
        if (element_type == DataType::ARRAY) {
            const auto& child_type = type.array_element();
            const auto& nested = static_cast<const ColumnarArrayChunk&>(child);
            auto* data = output.mutable_array_data();
            data->set_element_type(static_cast<proto::schema::DataType>(
                GetElementType(child_type)));
            data->mutable_data()->Reserve(
                ProtoReserveSize(static_cast<size_t>(end - begin)));
            for (auto row = begin; row < end; ++row) {
                auto* child_output = data->add_data();
                if (!nested.isValid(static_cast<int>(row))) {
                    child_output->Clear();
                    continue;
                }
                OutputRange(nested.type(),
                            nested.child(),
                            nested.offsets()[row],
                            nested.offsets()[row + 1],
                            *child_output);
            }
            return;
        }

        const auto begin_index = static_cast<size_t>(begin);
        const auto end_index = static_cast<size_t>(end);
        const auto element_count = end_index - begin_index;
        switch (element_type) {
            case DataType::BOOL: {
                auto* data = output.mutable_bool_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const FixedWidthChunk&>(child);
                const auto* values =
                    reinterpret_cast<const uint8_t*>(chunk.Data());
                data->Add(values + begin_index, values + end_index);
                return;
            }
            case DataType::INT8:
            case DataType::INT16:
            case DataType::INT32: {
                auto* data = output.mutable_int_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const FixedWidthChunk&>(child);
                const auto* values =
                    reinterpret_cast<const int32_t*>(chunk.Data());
                data->Add(values + begin_index, values + end_index);
                return;
            }
            case DataType::INT64: {
                auto* data = output.mutable_long_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const FixedWidthChunk&>(child);
                const auto* values =
                    reinterpret_cast<const int64_t*>(chunk.Data());
                data->Add(values + begin_index, values + end_index);
                return;
            }
            case DataType::FLOAT: {
                auto* data = output.mutable_float_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const FixedWidthChunk&>(child);
                const auto* values =
                    reinterpret_cast<const float*>(chunk.Data());
                data->Add(values + begin_index, values + end_index);
                return;
            }
            case DataType::DOUBLE: {
                auto* data = output.mutable_double_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const FixedWidthChunk&>(child);
                const auto* values =
                    reinterpret_cast<const double*>(chunk.Data());
                data->Add(values + begin_index, values + end_index);
                return;
            }
            case DataType::STRING:
            case DataType::VARCHAR: {
                auto* data = output.mutable_string_data()->mutable_data();
                data->Reserve(ProtoReserveSize(element_count));
                const auto& chunk = static_cast<const StringChunk&>(child);
                for (auto i = begin; i < end; ++i) {
                    const auto value = chunk[static_cast<int>(i)];
                    data->Add()->assign(value.data(), value.size());
                }
                return;
            }
            default:
                ThrowInfo(Unsupported,
                          "unsupported ArrayValue leaf type {}",
                          element_type);
        }
    }

 private:
    std::shared_ptr<const proto::schema::TypeSchema> type_;
    std::span<const ArrayOffset> offsets_;
    std::shared_ptr<const Chunk> child_;
};

namespace array_detail {

inline std::shared_ptr<const Chunk>
CreateColumnarArrayChildChunk(
    const std::shared_ptr<const proto::schema::TypeSchema>& array_type,
    ArrayOffset row_count,
    char* data,
    uint64_t size,
    const std::shared_ptr<ChunkMmapGuard>& chunk_mmap_guard) {
    AssertInfo(array_type != nullptr,
               "columnar array child type must not be null");
    if (ColumnarArrayChunk::GetElementType(*array_type) == DataType::ARRAY) {
        AssertInfo(row_count <= static_cast<ArrayOffset>(
                                    std::numeric_limits<int64_t>::max()),
                   "nested array row count {} exceeds int64 range",
                   row_count);
        auto child_type = std::shared_ptr<const proto::schema::TypeSchema>(
            array_type, &array_type->array_element());
        return std::shared_ptr<const ColumnarArrayChunk>(
            new ColumnarArrayChunk(static_cast<int64_t>(row_count),
                                   data,
                                   size,
                                   std::move(child_type),
                                   chunk_mmap_guard,
                                   ColumnarArrayChunk::kNoTrailingPadding));
    }

    const auto element_type = ColumnarArrayChunk::GetElementType(*array_type);
    const auto leaf_rows = ColumnarArrayChunk::CheckedLeafRowCount(row_count);
    if (IsStringDataType(element_type)) {
        ColumnarArrayChunk::ValidateStringPayload(data, size, row_count);
        return std::make_shared<const StringChunk>(
            leaf_rows, data, size, false, chunk_mmap_guard);
    }

    const auto width = ColumnarArrayChunk::ExpectedFixedWidth(element_type);
    AssertInfo(row_count <= std::numeric_limits<uint64_t>::max() / width,
               "fixed-width array leaf byte size overflows");
    const auto expected_size = row_count * width;
    AssertInfo(size == expected_size,
               "fixed-width array leaf size {} does not match expected {}",
               size,
               expected_size);
    return std::make_shared<const FixedWidthChunk>(
        leaf_rows, 1, data, size, width, false, chunk_mmap_guard);
}

}  // namespace array_detail

}  // namespace milvus
