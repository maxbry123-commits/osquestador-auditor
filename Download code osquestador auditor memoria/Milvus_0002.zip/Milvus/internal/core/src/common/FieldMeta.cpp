// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#include "common/FieldMeta.h"

#include <boost/lexical_cast.hpp>
#include <ctype.h>
#include <algorithm>
#include <atomic>
#include <istream>
#include <optional>

#include "Consts.h"
#include "NamedType/named_type_impl.hpp"
#include "boost/cstdint.hpp"
#include "common/Common.h"
#include "common/SystemProperty.h"
#include "common/Types.h"
#include "common/protobuf_utils.h"
#include "fmt/core.h"
#include "pb/common.pb.h"

namespace milvus {
namespace {

struct TypeSchemaTypes {
    DataType data_type;
    DataType element_type;
};

TypeSchemaTypes
ValidateTypeSchemaNode(const proto::schema::TypeSchema& type_schema,
                       const std::string& field_name) {
    if (type_schema.has_array_element()) {
        const auto child =
            ValidateTypeSchemaNode(type_schema.array_element(), field_name);
        return {DataType::ARRAY, child.data_type};
    }

    AssertInfo(type_schema.has_leaf_type(),
               "type_schema kind is not set for field {}",
               field_name);
    AssertInfo(proto::schema::DataType_IsValid(type_schema.leaf_type()),
               "type_schema leaf_type {} is not valid for field {}",
               static_cast<int>(type_schema.leaf_type()),
               field_name);
    const auto leaf_type = DataType(type_schema.leaf_type());
    AssertInfo(leaf_type != DataType::NONE,
               "type_schema leaf_type NONE is not valid for field {}",
               field_name);
    AssertInfo(leaf_type != DataType::ARRAY,
               "type_schema leaf_type ARRAY must use array_element for field "
               "{}",
               field_name);
    switch (leaf_type) {
        case DataType::BOOL:
        case DataType::INT8:
        case DataType::INT16:
        case DataType::INT32:
        case DataType::INT64:
        case DataType::FLOAT:
        case DataType::DOUBLE:
        case DataType::VARCHAR:
            break;
        default:
            ThrowInfo(DataTypeInvalid,
                      "type_schema leaf_type {} is not supported for ARRAY "
                      "field {}",
                      leaf_type,
                      field_name);
    }
    return {leaf_type, DataType::NONE};
}

}  // namespace

TokenizerParams
ParseTokenizerParams(const TypeParams& params) {
    auto iter = params.find("analyzer_params");
    if (iter == params.end()) {
        return "{}";
    }
    return iter->second;
}

bool
FieldMeta::enable_match() const {
    if (!IsStringDataType(type_)) {
        return false;
    }
    if (!string_info_.has_value()) {
        return false;
    }
    return string_info_->enable_match;
}

bool
FieldMeta::enable_analyzer() const {
    if (!IsStringDataType(type_)) {
        return false;
    }
    if (!string_info_.has_value()) {
        return false;
    }
    return string_info_->enable_analyzer;
}

TokenizerParams
FieldMeta::get_analyzer_params() const {
    if (!enable_analyzer()) {
        ThrowInfo(
            Unsupported,
            fmt::format("unsupported text index when not enable analyzer"));
    }
    auto params = string_info_->params;
    return ParseTokenizerParams(params);
}

milvus::proto::schema::FieldSchema
FieldMeta::ToProto() const {
    milvus::proto::schema::FieldSchema proto;
    proto.set_fieldid(id_.get());
    proto.set_name(name_.get());
    proto.set_data_type(ToProtoDataType(type_));
    proto.set_nullable(nullable_);

    if (has_default_value()) {
        *proto.mutable_default_value() = *default_value_;
    }

    if (element_type_ != DataType::NONE) {
        proto.set_element_type(ToProtoDataType(element_type_));
    }
    if (type_schema_.has_value()) {
        *proto.mutable_type_schema() = *type_schema_;
    }

    auto add_type_param = [&proto](const std::string& key,
                                   const std::string& value) {
        auto* param = proto.add_type_params();
        param->set_key(key);
        param->set_value(value);
    };
    auto add_index_param = [&proto](const std::string& key,
                                    const std::string& value) {
        auto* param = proto.add_index_params();
        param->set_key(key);
        param->set_value(value);
    };

    if (type_ == DataType::VECTOR_ARRAY) {
        add_type_param("dim", std::to_string(get_dim()));
        if (auto metric = get_metric_type(); metric.has_value()) {
            add_index_param("metric_type", metric.value());
        }
    } else if (IsVectorDataType(type_)) {
        if (!IsSparseFloatVectorDataType(type_)) {
            add_type_param("dim", std::to_string(get_dim()));
        }
        if (auto metric = get_metric_type(); metric.has_value()) {
            add_index_param("metric_type", metric.value());
        }
    } else if (IsStringDataType(type_)) {
        std::map<std::string, std::string> params;
        if (string_info_.has_value()) {
            params = string_info_->params;
        }
        params.erase(LOCAL_FORMAT_KEY);
        params[MAX_LENGTH] = std::to_string(get_max_len());
        params["enable_match"] = enable_match() ? "true" : "false";
        params["enable_analyzer"] = enable_analyzer() ? "true" : "false";
        for (const auto& [key, value] : params) {
            add_type_param(key, value);
        }
    } else if (IsArrayDataType(type_)) {
        // element_type already populated above
    }

    if (local_format_ != LOCAL_FORMAT_RAW) {
        add_type_param(LOCAL_FORMAT_KEY, local_format_);
    }

    return proto;
}

FieldMeta
FieldMeta::ParseFrom(const milvus::proto::schema::FieldSchema& schema_proto) {
    auto field_id = FieldId(schema_proto.fieldid());
    auto name = FieldName(schema_proto.name());
    auto nullable = schema_proto.nullable();
    if (field_id.get() < START_USER_FIELDID) {
        // system field id
        auto is_system =
            SystemProperty::Instance().SystemFieldVerify(name, field_id);
        AssertInfo(is_system,
                   "invalid system type: name({}), id({})",
                   name.get(),
                   field_id.get());
    }

    auto data_type = DataType(schema_proto.data_type());
    auto element_type = DataType(schema_proto.element_type());
    auto external_field_mapping = schema_proto.external_field();

    const bool has_array_type_pair =
        data_type == DataType::ARRAY && element_type == DataType::ARRAY;
    AssertInfo(schema_proto.has_type_schema() == has_array_type_pair,
               "type_schema, data_type ARRAY, and element_type ARRAY must be "
               "specified together for nested ARRAY field {}",
               name.get());

    if (schema_proto.has_type_schema()) {
        const auto schema_types =
            ValidateTypeSchemaNode(schema_proto.type_schema(), name.get());
        AssertInfo(schema_types.data_type == DataType::ARRAY &&
                       schema_types.element_type == DataType::ARRAY,
                   "type_schema is only supported for nested ARRAY field {}",
                   name.get());
    }

    if (data_type == DataType::VECTOR_ARRAY) {
        AssertInfo(element_type != DataType::NONE,
                   "element_type must be specified for VECTOR_ARRAY");
    }

    auto default_value = [&]() -> std::optional<DefaultValueType> {
        if (!schema_proto.has_default_value()) {
            return std::nullopt;
        }
        return schema_proto.default_value();
    }();

    auto type_map = RepeatedKeyValToMap(schema_proto.type_params());
    auto local_format = [&]() -> std::string {
        if (auto it = type_map.find(LOCAL_FORMAT_KEY); it != type_map.end()) {
            return it->second;
        }
        return LOCAL_FORMAT_RAW;
    };

    if (data_type == DataType::VECTOR_ARRAY) {
        // todo(SpadeA): revisit the code when index build for vector array is ready
        int64_t dim = 0;
        AssertInfo(type_map.count("dim"), "dim not found");
        dim = boost::lexical_cast<int64_t>(type_map.at("dim"));

        return FieldMeta{name,
                         field_id,
                         data_type,
                         element_type,
                         dim,
                         std::nullopt,
                         nullable,
                         external_field_mapping,
                         local_format()};
    }

    if (IsVectorDataType(data_type)) {
        AssertInfo(!default_value.has_value(),
                   "vector fields do not support default values");
        auto index_map = RepeatedKeyValToMap(schema_proto.index_params());

        int64_t dim = 0;
        if (!IsSparseFloatVectorDataType(data_type)) {
            AssertInfo(type_map.count("dim"), "dim not found");
            dim = boost::lexical_cast<int64_t>(type_map.at("dim"));
        }

        if (!index_map.count("metric_type")) {
            return FieldMeta{name,
                             field_id,
                             data_type,
                             dim,
                             std::nullopt,
                             nullable,
                             default_value,
                             external_field_mapping,
                             local_format()};
        }
        auto metric_type = index_map.at("metric_type");
        return FieldMeta{name,
                         field_id,
                         data_type,
                         dim,
                         metric_type,
                         nullable,
                         default_value,
                         external_field_mapping,
                         local_format()};
    }

    if (IsStringDataType(data_type)) {
        int64_t max_len = 0;
        if (type_map.count(MAX_LENGTH)) {
            max_len = boost::lexical_cast<int64_t>(type_map.at(MAX_LENGTH));
        } else {
            AssertInfo(data_type == DataType::TEXT,
                       "max_length not found for non-Text string field");
        }

        auto get_bool_value = [&](const std::string& key) -> bool {
            if (!type_map.count(key)) {
                return false;
            }
            auto param_str = type_map.at(key);
            std::transform(param_str.begin(),
                           param_str.end(),
                           param_str.begin(),
                           ::tolower);
            std::istringstream ss(param_str);
            bool b;
            ss >> std::boolalpha >> b;
            return b;
        };

        bool enable_analyzer = get_bool_value("enable_analyzer");
        bool enable_match = get_bool_value("enable_match");
        auto string_params = type_map;
        string_params.erase(LOCAL_FORMAT_KEY);

        return FieldMeta{name,
                         field_id,
                         data_type,
                         max_len,
                         nullable,
                         enable_match,
                         enable_analyzer,
                         string_params,
                         default_value,
                         external_field_mapping,
                         local_format()};
    }

    if (data_type == DataType::ARRAY) {
        std::optional<proto::schema::TypeSchema> type_schema;
        if (schema_proto.has_type_schema()) {
            type_schema = schema_proto.type_schema();
        }
        return FieldMeta{name,
                         field_id,
                         data_type,
                         element_type,
                         nullable,
                         default_value,
                         external_field_mapping,
                         local_format(),
                         std::move(type_schema)};
    }

    return FieldMeta{name,
                     field_id,
                     data_type,
                     nullable,
                     default_value,
                     external_field_mapping,
                     local_format()};
}

}  // namespace milvus
