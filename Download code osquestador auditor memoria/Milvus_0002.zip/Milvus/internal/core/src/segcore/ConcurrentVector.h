// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once

#include <fmt/core.h>
#include <tbb/concurrent_vector.h>

#include <algorithm>
#include <atomic>
#include <cassert>
#include <deque>
#include <memory>
#include <mutex>
#include <span>
#include <shared_mutex>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "common/EasyAssert.h"
#include "common/FieldMeta.h"
#include "common/FieldData.h"
#include "common/GrowingOffsetMapping.h"
#include "common/Json.h"
#include "common/OffsetMapping.h"
#include "common/Span.h"
#include "common/Types.h"
#include "common/Utils.h"
#include "mmap/ChunkVector.h"

namespace milvus::segcore {

// Validity (null bitmap) storage for growing segments.
//
// Backed by fixed-size per-chunk buffers held in a std::deque so that, once a
// chunk is appended, its buffer never moves. A raw pointer returned by
// get_chunk_data() therefore stays valid across concurrent inserts (which only
// append — never relocate existing chunks). This replaces a single resizable
// FixedVector<bool> whose reallocation on insert could dangle a validity
// pointer that a concurrent query had cached.
//
// Contract: a get_chunk_data() borrow may only be read within its own chunk
// ([offset, chunk end)). All current readers apply validity per chunk (see
// ApplyFieldValidData and InsertRecord::get_span_base), so this holds.
class ThreadSafeValidData {
 public:
    explicit ThreadSafeValidData(int64_t size_per_chunk)
        : size_per_chunk_(size_per_chunk) {
        AssertInfo(size_per_chunk_ > 0,
                   "size_per_chunk must be positive, got {}",
                   size_per_chunk_);
    }

    void
    set_data_raw(const std::vector<FieldDataPtr>& datas) {
        std::unique_lock<std::shared_mutex> lck(mutex_);
        for (auto& field_data : datas) {
            auto num_row = field_data->get_num_rows();
            reserve_to(length_ + num_row);
            write_bits(length_, num_row, [&field_data](size_t i) {
                return field_data->is_valid(i);
            });
            length_ += num_row;
        }
    }

    void
    set_data_raw(size_t num_rows,
                 const DataArray* data,
                 const FieldMeta& field_meta) {
        std::unique_lock<std::shared_mutex> lck(mutex_);
        if (field_meta.is_nullable()) {
            check_source_span(num_rows, data, field_meta);
            reserve_to(length_ + num_rows);
            write_from(
                length_, num_rows, GetFieldDataRowValidData(*data).data());
            length_ += num_rows;
        }
    }

    // Write validity at the logical offset the caller reserved, rather than
    // appending at the current length. The two agree only as long as inserts
    // arrive in reserved order; writing at the reserved offset states the
    // contract in the code instead of relying on it silently.
    void
    set_data_raw(size_t element_offset,
                 size_t num_rows,
                 const DataArray* data,
                 const FieldMeta& field_meta) {
        std::unique_lock<std::shared_mutex> lck(mutex_);
        if (field_meta.is_nullable()) {
            // This is the overload the ingest path uses (SegmentGrowingImpl's
            // Insert and fill_empty_field backfill), so the source-span check
            // has to live here too, not only on the appending overload above.
            check_source_span(num_rows, data, field_meta);
            const auto end = element_offset + num_rows;
            // No gaps. length_ advances to `end`, and is_valid() admits every
            // offset below it, so a write that starts past the current length
            // would publish a range nobody ever wrote -- validity bits read
            // back as garbage rather than as null. Overwriting an already
            // written range IS allowed: that is what makes a Reopen backfill
            // retry idempotent.
            AssertInfo(element_offset <= length_,
                       "validity write leaves a gap: element_offset={}, "
                       "length={}",
                       element_offset,
                       length_);
            reserve_to(end);
            write_from(element_offset,
                       num_rows,
                       GetFieldDataRowValidData(*data).data());
            length_ = std::max(length_, end);
        }
    }

    bool
    is_valid(size_t offset) const {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        AssertInfo(offset < length_,
                   "offset out of range, offset={}, length_={}",
                   offset,
                   length_);
        return chunks_[offset / size_per_chunk_][offset % size_per_chunk_];
    }

    // Borrow a pointer into the validity bitmap at `offset`. Valid only for
    // reads within the same chunk ([offset, chunk end)); the pointed-to chunk
    // buffer never moves, so the borrow survives concurrent inserts.
    bool*
    get_chunk_data(size_t offset) {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        AssertInfo(offset < length_,
                   "offset out of range, offset={}, length_={}",
                   offset,
                   length_);
        return &chunks_[offset / size_per_chunk_][offset % size_per_chunk_];
    }

    // Fill out[i] with the validity of offsets[i] for `count` offsets under a
    // single lock acquisition. Out-of-range offsets yield false (not an
    // assert), matching the tolerant semantics of offset-driven read paths.
    void
    bulk_is_valid(const int64_t* offsets, int64_t count, bool* out) const {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        for (int64_t i = 0; i < count; ++i) {
            auto offset = offsets[i];
            out[i] = offset >= 0 && static_cast<size_t>(offset) < length_ &&
                     chunks_[offset / spc][offset % spc];
        }
    }

    // Same, for a contiguous range. The compact-storage write path needs the
    // validity of every row in the batch it is about to append and would
    // otherwise take the lock once per row.
    void
    bulk_is_valid_range(int64_t start, int64_t count, bool* out) const {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        for (int64_t i = 0; i < count; ++i) {
            const auto offset = start + i;
            out[i] = offset >= 0 && static_cast<size_t>(offset) < length_ &&
                     chunks_[offset / spc][offset % spc];
        }
    }

    // WARNING: materializes a flat copy of the WHOLE bitmap (O(segment rows))
    // — avoid on hot paths. Prefer empty() for emptiness checks,
    // is_valid()/bulk_is_valid() for point/batch lookups, or get_chunk_data()
    // to borrow within a chunk.
    FixedVector<bool>
    get_data() const {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        FixedVector<bool> out(length_);
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        size_t copied = 0;
        for (const auto& chunk : chunks_) {
            if (copied >= length_) {
                break;
            }
            const size_t n = std::min(spc, length_ - copied);
            std::copy_n(chunk.begin(), n, out.begin() + copied);
            copied += n;
        }
        return out;
    }

    bool
    empty() const {
        std::shared_lock<std::shared_mutex> lck(mutex_);
        return length_ == 0;
    }

 private:
    // write_from reads exactly num_rows entries from the source, so a producer
    // payload shorter than the row count is an out-of-bounds read. Reject it at
    // the boundary rather than silently treating the missing tail as NULL
    // further down the ingest path.
    static void
    check_source_span(size_t num_rows,
                      const DataArray* data,
                      const FieldMeta& field_meta) {
        // Resolve validity the same way write_from's caller does
        // (GetFieldDataRowValidData): new payloads carry it in the
        // field-specific ScalarField/VectorField, legacy ones in
        // FieldData.valid_data. Checking the top-level field alone would
        // reject every new-format payload as empty.
        const auto valid_size =
            static_cast<size_t>(GetFieldDataRowValidData(*data).size());
        AssertInfo(valid_size == num_rows,
                   "nullable field {} valid_data size {} must match "
                   "num_rows {}",
                   field_meta.get_id().get(),
                   valid_size,
                   num_rows);
    }

    // Ensure enough chunks exist to hold `n` elements. Caller holds the lock.
    void
    reserve_to(size_t n) {
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        const size_t need = (n + spc - 1) / spc;
        while (chunks_.size() < need) {
            chunks_.emplace_back(spc, false);
        }
    }

    // Write `count` bits starting at global offset `at` from a contiguous
    // source array, chunk by chunk via copy_n. Caller holds the lock and has
    // already reserved capacity.
    void
    write_from(size_t at, size_t count, const bool* src) {
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        size_t written = 0;
        while (written < count) {
            const size_t g = at + written;
            const size_t ci = g / spc;
            const size_t oi = g % spc;
            const size_t n = std::min(count - written, spc - oi);
            std::copy_n(src + written, n, chunks_[ci].begin() + oi);
            written += n;
        }
    }

    // Write `count` bits starting at global offset `at`, taking bit k from
    // f(k). Splits across chunk boundaries. Caller holds the lock and has
    // already reserved capacity.
    template <typename F>
    void
    write_bits(size_t at, size_t count, F&& f) {
        const size_t spc = static_cast<size_t>(size_per_chunk_);
        size_t written = 0;
        while (written < count) {
            const size_t g = at + written;
            const size_t ci = g / spc;
            const size_t oi = g % spc;
            const size_t room = spc - oi;
            const size_t n =
                (count - written < room) ? (count - written) : room;
            auto& chunk = chunks_[ci];
            for (size_t k = 0; k < n; ++k) {
                chunk[oi + k] = f(written + k);
            }
            written += n;
        }
    }

    mutable std::shared_mutex mutex_{};
    // Fixed-size (size_per_chunk_) buffers; deque keeps existing buffers put.
    std::deque<FixedVector<bool>> chunks_;
    const int64_t size_per_chunk_;
    // number of actual elements
    size_t length_{0};
};
using ThreadSafeValidDataPtr = std::shared_ptr<ThreadSafeValidData>;

class VectorBase {
 public:
    explicit VectorBase(int64_t size_per_chunk)
        : size_per_chunk_(size_per_chunk) {
    }
    virtual ~VectorBase() = default;

    virtual void
    set_data_raw(ssize_t element_offset,
                 const void* source,
                 ssize_t element_count) = 0;

    virtual void
    set_data_raw(ssize_t element_offset,
                 const std::vector<FieldDataPtr>& data) = 0;

    virtual void
    set_data_raw(ssize_t element_offset,
                 ssize_t element_count,
                 const DataArray* data,
                 const FieldMeta& field_meta);

    // used only by sealed segment to load system field
    virtual void
    fill_chunk_data(const std::vector<FieldDataPtr>& data) = 0;

    virtual SpanBase
    get_span_base(int64_t chunk_id) const = 0;

    int64_t
    get_size_per_chunk() const {
        return size_per_chunk_;
    }

    virtual const void*
    get_chunk_data(ssize_t chunk_index) const = 0;

    virtual int64_t
    get_chunk_size(ssize_t chunk_index) const = 0;

    virtual int64_t
    get_element_size() const = 0;

    virtual int64_t
    get_element_offset(ssize_t chunk_index) const = 0;

    virtual ssize_t
    num_chunk() const = 0;

    virtual bool
    empty() = 0;

    virtual void
    clear() = 0;

    virtual bool
    is_mapping_storage() const {
        return false;
    }

    // Get physical offset from logical offset. Returns -1 if not found.
    virtual int64_t
    get_physical_offset(int64_t logical_offset) const {
        return logical_offset;  // default: no mapping
    }

    // Get logical offset from physical offset. Returns -1 if not found.
    virtual int64_t
    get_logical_offset(int64_t physical_offset) const {
        return physical_offset;  // default: no mapping
    }

    virtual int64_t
    get_valid_count() const {
        return 0;
    }

    virtual FixedVector<bool>
    get_valid_data() const {
        return FixedVector<bool>{};
    }

    virtual void
    bulk_is_valid_range(int64_t start, int64_t count, bool* out) const {
        std::fill_n(out, count, true);
    }

    // Non-nullable fields have no mapping at all; hand back the shared no-op
    // so callers never have to branch on a null pointer.
    virtual const OffsetMapping&
    get_offset_mapping() const {
        static const NoOpOffsetMapping empty;
        return empty;
    }

    // Shared ownership of the chunk storage, for consumers that keep raw
    // pointers into chunk buffers beyond their lock scope (Knowhere
    // brute-force iterators). clear() swaps the container's INTERNAL
    // collection under the container's own mutex, so a holder of this
    // reference keeps the buffers it points into alive while reclamation
    // proceeds immediately for the segment.
    //
    // Take it BEFORE reading any chunk pointers, and read them only through
    // it: acquire() latches {storage, count} as one generation under the
    // container's own internal mutex, and that latch is the only thing that
    // orders this call against a concurrent try_remove_chunks swap -- there
    // is no external chunk lock. A snapshot taken after raw pointers were
    // read could pin a newer generation than the buffers those pointers
    // address.
    //
    // Pure, not defaulted: a column that cannot hand out a snapshot cannot
    // protect a reader either, and an empty handle would let the caller
    // believe it had pinned something. An implementation that grows a new
    // storage kind must answer this question deliberately.
    virtual ChunkSnapshot
    acquire_chunks() const = 0;

    // Snapshot-addressed reads. No lock: `snap` pins the generation, so
    // reclamation cannot pull the chunks out from under the caller, and the
    // caller's MVCC bound governs which rows inside them are visible.
    virtual const void*
    get_chunk_data(const ChunkSnapshot& snap, ssize_t chunk_index) const = 0;
    virtual int64_t
    get_chunk_size(const ChunkSnapshot& snap, ssize_t chunk_index) const = 0;
    virtual SpanBase
    get_span_base(const ChunkSnapshot& snap, int64_t chunk_id) const = 0;

 protected:
    const int64_t size_per_chunk_;
};

template <typename Type, bool is_type_entire_row = false>
class ConcurrentVectorImpl : public VectorBase {
 public:
    ConcurrentVectorImpl(ConcurrentVectorImpl&&) = delete;
    ConcurrentVectorImpl(const ConcurrentVectorImpl&) = delete;

    ConcurrentVectorImpl&
    operator=(ConcurrentVectorImpl&&) = delete;
    ConcurrentVectorImpl&
    operator=(const ConcurrentVectorImpl&) = delete;

    using TraitType = std::conditional_t<
        is_type_entire_row,
        Type,
        std::conditional_t<
            std::is_same_v<Type, float>,
            FloatVector,
            std::conditional_t<
                std::is_same_v<Type, float16>,
                Float16Vector,
                std::conditional_t<
                    std::is_same_v<Type, bfloat16>,
                    BFloat16Vector,
                    std::conditional_t<std::is_same_v<Type, int8>,
                                       Int8Vector,
                                       BinaryVector>>>>>;

 public:
    explicit ConcurrentVectorImpl(
        ssize_t elements_per_row,
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr,
        bool use_mapping_storage = false)
        : VectorBase(size_per_chunk),
          elements_per_row_(is_type_entire_row ? 1 : elements_per_row),
          valid_data_ptr_(valid_data_ptr),
          use_mapping_storage_(use_mapping_storage) {
        chunks_ptr_ = SelectChunkVectorPtr<Type>(mmap_descriptor);
    }

    SpanBase
    get_span_base(int64_t chunk_id) const override {
        return get_span_base(acquire_chunks(), chunk_id);
    }

    SpanBase
    get_span_base(const ChunkSnapshot& snap, int64_t chunk_id) const override {
        if constexpr (std::is_same_v<Type, VectorArray>) {
            ThrowInfo(NotImplemented, "unimplemented");
        } else if constexpr (is_type_entire_row) {
            return chunks_ptr_->get_span(snap, chunk_id);
        } else if constexpr (std::is_same_v<Type, int64_t> ||  // NOLINT
                             std::is_same_v<Type, int>) {
            // only for testing
            ThrowInfo(NotImplemented, "unimplemented");
        } else {
            auto chunk_data = chunks_ptr_->get_chunk_data(snap, chunk_id);
            auto chunk_size = chunks_ptr_->get_chunk_size(snap, chunk_id);
            static_assert(
                std::is_same_v<typename TraitType::embedded_type, Type>);
            return Span<TraitType>(
                static_cast<Type*>(chunk_data), chunk_size, elements_per_row_);
        }
    }

    void
    fill_chunk_data(const std::vector<FieldDataPtr>& datas) override {
        AssertInfo(chunks_ptr_->size() == 0, "non empty concurrent vector");
        set_data_raw(0, datas);
    }

    void
    set_data_raw(ssize_t element_offset,
                 const std::vector<FieldDataPtr>& datas) override {
        for (auto& field_data : datas) {
            auto num_rows = field_data->get_num_rows();
            set_data_raw(element_offset, field_data->Data(), num_rows);
            element_offset += num_rows;
        }
    }

    void
    set_data_raw(ssize_t element_offset,
                 const void* source,
                 ssize_t element_count) override {
        ssize_t valid_count = 0;
        ssize_t storage_offset = 0;
        if (use_mapping_storage_) {
            if constexpr (!std::is_same_v<Type, bool>) {
                storage_offset = offset_mapping_.GetValidCount();
                // Build valid_data array for offset mapping
                std::unique_ptr<bool[]> valid_data(new bool[element_count]);
                // One lock acquisition for the batch. The caller has already
                // written this range's validity (SegmentGrowingImpl::Insert
                // and fill_empty_field both do so before touching the column),
                // which is what makes reading it back here well-defined.
                valid_data_ptr_->bulk_is_valid_range(
                    element_offset, element_count, valid_data.get());
                valid_count = std::count(
                    valid_data.get(), valid_data.get() + element_count, true);
                offset_mapping_.Append(valid_data.get(),
                                       element_count,
                                       element_offset,
                                       storage_offset);
            } else {
                // Unreachable today: only vector fields enable compact
                // storage, and no vector type maps to bool. Guard it anyway --
                // falling through here would leave valid_count at 0 and write
                // nothing at all, silently dropping the batch.
                ThrowInfo(NotImplemented,
                          "compact mapping storage is not supported for bool "
                          "columns");
            }
        } else {
            valid_count = element_count;
            storage_offset = element_offset;
        }
        if (valid_count > 0) {
            auto size = size_per_chunk_ == MAX_ROW_COUNT ? valid_count
                                                         : size_per_chunk_;
            chunks_ptr_->emplace_to_at_least(
                upper_div(storage_offset + valid_count, size),
                elements_per_row_ * size);
            set_data(
                storage_offset, static_cast<const Type*>(source), valid_count);
        }
    }

    const void*
    get_chunk_data(ssize_t chunk_index) const override {
        return (const void*)chunks_ptr_->get_chunk_data(chunk_index);
    }

    const void*
    get_chunk_data(const ChunkSnapshot& snap,
                   ssize_t chunk_index) const override {
        return (const void*)chunks_ptr_->get_chunk_data(snap, chunk_index);
    }

    int64_t
    get_chunk_size(ssize_t chunk_index) const override {
        return chunks_ptr_->get_chunk_size(chunk_index);
    }

    int64_t
    get_chunk_size(const ChunkSnapshot& snap,
                   ssize_t chunk_index) const override {
        return chunks_ptr_->get_chunk_size(snap, chunk_index);
    }

    int64_t
    get_element_size() const override {
        if constexpr (std::is_same_v<Type, VectorArray>) {
            ThrowInfo(NotImplemented, "unimplemented");
        } else if constexpr (is_type_entire_row) {
            return chunks_ptr_->get_element_size();
        } else if constexpr (std::is_same_v<Type, int64_t> ||  // NOLINT
                             std::is_same_v<Type, int>) {
            // only for testing
            ThrowInfo(NotImplemented, "unimplemented");
        } else {
            static_assert(
                std::is_same_v<typename TraitType::embedded_type, Type>);
            return elements_per_row_;
        }
    }

    int64_t
    get_element_offset(ssize_t chunk_index) const override {
        return chunks_ptr_->get_element_offset(chunk_index);
    }

    // just for fun, don't use it directly
    const Type*
    get_element(ssize_t element_index) const {
        auto physical_index = offset_mapping_.GetPhysicalOffset(element_index);
        if (physical_index == -1) {
            return nullptr;
        }
        auto chunk_id = physical_index / size_per_chunk_;
        auto chunk_offset = physical_index % size_per_chunk_;
        auto data =
            static_cast<const Type*>(chunks_ptr_->get_chunk_data(chunk_id));
        return data + chunk_offset * elements_per_row_;
    }

    const Type*
    get_physical_element(ssize_t physical_index) const {
        if (physical_index == -1) {
            return nullptr;
        }
        auto chunk_id = physical_index / size_per_chunk_;
        auto chunk_offset = physical_index % size_per_chunk_;
        auto data =
            static_cast<const Type*>(chunks_ptr_->get_chunk_data(chunk_id));
        return data + chunk_offset * elements_per_row_;
    }

    // Snapshot-addressed: reads the generation the caller pinned, so a
    // concurrent try_remove_chunks cannot free the buffer mid-read.
    const Type*
    get_physical_element(const ChunkSnapshot& snap,
                         ssize_t physical_index) const {
        if (physical_index == -1) {
            return nullptr;
        }
        auto chunk_id = physical_index / size_per_chunk_;
        auto chunk_offset = physical_index % size_per_chunk_;
        auto data = static_cast<const Type*>(
            chunks_ptr_->get_chunk_data(snap, chunk_id));
        return data + chunk_offset * elements_per_row_;
    }

    const Type&
    operator[](ssize_t element_index) const {
        AssertInfo(
            elements_per_row_ == 1,
            fmt::format(
                "The value of elements_per_row_ is not 1, elements_per_row_={}",
                elements_per_row_));
        if constexpr (std::is_same_v<Type, ArrayValue>) {
            AssertInfo(!chunks_ptr_->is_mmap(),
                       "mmap nested ARRAY rows must be accessed through "
                       "view_element()");
        }
        auto chunk_id = element_index / size_per_chunk_;
        auto chunk_offset = element_index % size_per_chunk_;
        auto data =
            static_cast<const Type*>(chunks_ptr_->get_chunk_data(chunk_id));
        return data[chunk_offset];
    }

    ssize_t
    num_chunk() const override {
        return chunks_ptr_->size();
    }

    bool
    empty() override {
        // One snapshot for the whole scan. Pairing size() (a bare counter_
        // load) with the per-index accessor (which asserts against a freshly
        // loaded counter_) is a TOCTOU: a try_remove_chunks landing between
        // the two turns an emptiness check into a thrown assertion. That is
        // reachable from HasFieldData on any query thread, and reclamation no
        // longer waits for a chunk lock, so the window is no longer rare.
        auto snap = chunks_ptr_->acquire();
        for (int64_t i = 0; i < snap.count; i++) {
            if (chunks_ptr_->get_chunk_size(snap, i) > 0) {
                return false;
            }
        }

        return true;
    }

    void
    clear() override {
        // The container swaps its internal chunk collection under its own
        // mutex; acquire_chunks() holders keep the swapped-out buffers alive.
        // chunks_ptr_ itself is never reassigned, so num_chunk()'s bare
        // counter_ load stays safe (it may go stale, never torn). Anything
        // that follows a count with a chunk access must go through one
        // snapshot instead -- see empty() above.
        chunks_ptr_->clear();
    }

    ChunkSnapshot
    acquire_chunks() const override {
        return chunks_ptr_->acquire();
    }

    bool
    is_mmap() const {
        return chunks_ptr_->is_mmap();
    }

    bool
    is_mapping_storage() const override {
        return use_mapping_storage_;
    }

    int64_t
    get_physical_offset(int64_t logical_offset) const override {
        return offset_mapping_.GetPhysicalOffset(logical_offset);
    }

    int64_t
    get_logical_offset(int64_t physical_offset) const override {
        return offset_mapping_.GetLogicalOffset(physical_offset);
    }

    int64_t
    get_valid_count() const override {
        return offset_mapping_.GetValidCount();
    }

    const milvus::OffsetMapping&
    get_offset_mapping() const override {
        return offset_mapping_;
    }

    FixedVector<bool>
    get_valid_data() const override {
        if (valid_data_ptr_ != nullptr) {
            return valid_data_ptr_->get_data();
        }
        return FixedVector<bool>{};
    }

    void
    bulk_is_valid_range(int64_t start,
                        int64_t count,
                        bool* out) const override {
        if (valid_data_ptr_ != nullptr) {
            valid_data_ptr_->bulk_is_valid_range(start, count, out);
            return;
        }
        std::fill_n(out, count, true);
    }

 private:
    void
    set_data(ssize_t element_offset,
             const Type* source,
             ssize_t element_count) {
        auto chunk_id = element_offset / size_per_chunk_;
        auto chunk_offset = element_offset % size_per_chunk_;
        ssize_t source_offset = 0;
        // first partition:
        if (chunk_offset + element_count <= size_per_chunk_) {
            // only first
            fill_chunk(
                chunk_id, chunk_offset, element_count, source, source_offset);
            return;
        }

        auto first_size = size_per_chunk_ - chunk_offset;
        fill_chunk(chunk_id, chunk_offset, first_size, source, source_offset);

        source_offset += size_per_chunk_ - chunk_offset;
        element_count -= first_size;
        ++chunk_id;

        // the middle
        while (element_count >= size_per_chunk_) {
            fill_chunk(chunk_id, 0, size_per_chunk_, source, source_offset);
            source_offset += size_per_chunk_;
            element_count -= size_per_chunk_;
            ++chunk_id;
        }

        // the final
        if (element_count > 0) {
            fill_chunk(chunk_id, 0, element_count, source, source_offset);
        }
    }
    void
    fill_chunk(ssize_t chunk_id,
               ssize_t chunk_offset,
               ssize_t element_count,
               const Type* source,
               ssize_t source_offset) {
        if (element_count <= 0) {
            return;
        }
        auto chunk_num = chunks_ptr_->size();
        AssertInfo(
            chunk_id < chunk_num,
            fmt::format("chunk_id out of chunk num, chunk_id={}, chunk_num={}",
                        chunk_id,
                        chunk_num));
        std::optional<CheckDataValid> check_data_valid = std::nullopt;
        if (valid_data_ptr_ != nullptr && !use_mapping_storage_) {
            size_t chunk_id_offset =
                chunk_id * size_per_chunk_ * elements_per_row_;
            check_data_valid = [valid_data_ptr = valid_data_ptr_,
                                beg_id = chunk_id_offset](size_t offset) {
                return valid_data_ptr->is_valid(beg_id + offset);
            };
        }
        chunks_ptr_->copy_to_chunk(chunk_id,
                                   chunk_offset * elements_per_row_,
                                   source + source_offset * elements_per_row_,
                                   element_count * elements_per_row_,
                                   check_data_valid);
    }

 protected:
    const ssize_t elements_per_row_;
    // Stable for the column's lifetime -- some readers (flush-path
    // HasFieldData/empty) dereference it without holding chunk locks. The
    // swap that backs share_chunk_storage() happens INSIDE the container,
    // under its own mutex.
    ChunkVectorPtr<Type> chunks_ptr_ = nullptr;
    ThreadSafeValidDataPtr valid_data_ptr_ = nullptr;

    const bool use_mapping_storage_;
    milvus::GrowingOffsetMapping offset_mapping_;
};

template <typename Type>
class ConcurrentVector : public ConcurrentVectorImpl<Type, true> {
 public:
    static_assert(IsScalar<Type> || std::is_same_v<Type, PkType>);
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr)
        : ConcurrentVectorImpl<Type, true>::ConcurrentVectorImpl(
              1, size_per_chunk, mmap_descriptor, valid_data_ptr) {
    }
};

template <>
class ConcurrentVector<std::string>
    : public ConcurrentVectorImpl<std::string, true> {
 public:
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr)
        : ConcurrentVectorImpl<std::string, true>::ConcurrentVectorImpl(
              1, size_per_chunk, std::move(mmap_descriptor), valid_data_ptr) {
    }

    std::string_view
    view_element(ssize_t element_index) const {
        auto chunk_id = element_index / size_per_chunk_;
        auto chunk_offset = element_index % size_per_chunk_;
        return chunks_ptr_->view_element(chunk_id, chunk_offset);
    }
};

template <>
class ConcurrentVector<Json> : public ConcurrentVectorImpl<Json, true> {
 public:
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr)
        : ConcurrentVectorImpl<Json, true>::ConcurrentVectorImpl(
              1, size_per_chunk, std::move(mmap_descriptor), valid_data_ptr) {
    }

    std::string_view
    view_element(ssize_t element_index) const {
        auto chunk_id = element_index / size_per_chunk_;
        auto chunk_offset = element_index % size_per_chunk_;
        return std::string_view(
            chunks_ptr_->view_element(chunk_id, chunk_offset).data());
    }
};

template <>
class ConcurrentVector<Array> : public ConcurrentVectorImpl<Array, true> {
 public:
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr)
        : ConcurrentVectorImpl<Array, true>::ConcurrentVectorImpl(
              1, size_per_chunk, std::move(mmap_descriptor), valid_data_ptr) {
    }

    ArrayView
    view_element(ssize_t element_index) const {
        auto chunk_id = element_index / size_per_chunk_;
        auto chunk_offset = element_index % size_per_chunk_;
        return chunks_ptr_->view_element(chunk_id, chunk_offset);
    }
};

template <>
class ConcurrentVector<ArrayValue>
    : public ConcurrentVectorImpl<ArrayValue, true> {
    using Base = ConcurrentVectorImpl<ArrayValue, true>;

 public:
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr)
        : Base(1,
               size_per_chunk,
               std::move(mmap_descriptor),
               std::move(valid_data_ptr)) {
    }

    using Base::set_data_raw;

    void
    set_data_raw(ssize_t element_offset,
                 ssize_t element_count,
                 const DataArray* data,
                 const FieldMeta& field_meta) override;

    ArrayValueView
    view_element(ssize_t element_index) const {
        auto chunk_id = element_index / size_per_chunk_;
        auto chunk_offset = element_index % size_per_chunk_;
        return chunks_ptr_->view_element(chunk_id, chunk_offset);
    }

 private:
    void
    set_mmap_proto_rows(ssize_t element_offset,
                        std::span<const ScalarFieldProto* const> rows);

    std::once_flag array_type_once_;
    std::shared_ptr<const proto::schema::TypeSchema> array_type_;
};

template <>
class ConcurrentVector<VectorArray>
    : public ConcurrentVectorImpl<VectorArray, true> {
 public:
    explicit ConcurrentVector(
        int64_t dim /* not use it*/,
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr,
        bool use_mapping_storage = false)
        : ConcurrentVectorImpl<VectorArray, true>::ConcurrentVectorImpl(
              1,
              size_per_chunk,
              std::move(mmap_descriptor),
              valid_data_ptr,
              use_mapping_storage) {
    }
};

template <>
class ConcurrentVector<SparseFloatVector>
    : public ConcurrentVectorImpl<knowhere::sparse::SparseRow<SparseValueType>,
                                  true> {
 public:
    explicit ConcurrentVector(
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr,
        bool use_mapping_storage = false)
        : ConcurrentVectorImpl<knowhere::sparse::SparseRow<SparseValueType>,
                               true>::ConcurrentVectorImpl(1,
                                                           size_per_chunk,
                                                           std::move(
                                                               mmap_descriptor),
                                                           valid_data_ptr,
                                                           use_mapping_storage),
          dim_(0) {
    }

    void
    set_data_raw(ssize_t element_offset,
                 const void* source,
                 ssize_t element_count) override {
        auto* src =
            static_cast<const knowhere::sparse::SparseRow<SparseValueType>*>(
                source);
        ssize_t source_count = element_count;
        if (this->use_mapping_storage_) {
            source_count = 0;
            for (ssize_t i = 0; i < element_count; ++i) {
                if (this->valid_data_ptr_->is_valid(element_offset + i)) {
                    source_count++;
                }
            }
        }
        for (ssize_t i = 0; i < source_count; ++i) {
            dim_ = std::max(dim_, src[i].dim());
        }
        ConcurrentVectorImpl<knowhere::sparse::SparseRow<SparseValueType>,
                             true>::set_data_raw(element_offset,
                                                 source,
                                                 element_count);
    }

    int64_t
    Dim() const {
        return dim_;
    }

 private:
    int64_t dim_;
};

template <>
class ConcurrentVector<FloatVector>
    : public ConcurrentVectorImpl<float, false> {
 public:
    ConcurrentVector(int64_t dim,
                     int64_t size_per_chunk,
                     storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
                     ThreadSafeValidDataPtr valid_data_ptr = nullptr,
                     bool use_mapping_storage = false)
        : ConcurrentVectorImpl<float, false>::ConcurrentVectorImpl(
              dim,
              size_per_chunk,
              std::move(mmap_descriptor),
              valid_data_ptr,
              use_mapping_storage) {
    }
};

template <>
class ConcurrentVector<BinaryVector>
    : public ConcurrentVectorImpl<uint8_t, false> {
 public:
    explicit ConcurrentVector(
        int64_t dim,
        int64_t size_per_chunk,
        storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
        ThreadSafeValidDataPtr valid_data_ptr = nullptr,
        bool use_mapping_storage = false)
        : ConcurrentVectorImpl(dim / 8,
                               size_per_chunk,
                               std::move(mmap_descriptor),
                               valid_data_ptr,
                               use_mapping_storage) {
        AssertInfo(dim % 8 == 0,
                   fmt::format("dim is not a multiple of 8, dim={}", dim));
    }
};

template <>
class ConcurrentVector<Float16Vector>
    : public ConcurrentVectorImpl<float16, false> {
 public:
    ConcurrentVector(int64_t dim,
                     int64_t size_per_chunk,
                     storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
                     ThreadSafeValidDataPtr valid_data_ptr = nullptr,
                     bool use_mapping_storage = false)
        : ConcurrentVectorImpl<float16, false>::ConcurrentVectorImpl(
              dim,
              size_per_chunk,
              std::move(mmap_descriptor),
              valid_data_ptr,
              use_mapping_storage) {
    }
};

template <>
class ConcurrentVector<BFloat16Vector>
    : public ConcurrentVectorImpl<bfloat16, false> {
 public:
    ConcurrentVector(int64_t dim,
                     int64_t size_per_chunk,
                     storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
                     ThreadSafeValidDataPtr valid_data_ptr = nullptr,
                     bool use_mapping_storage = false)
        : ConcurrentVectorImpl<bfloat16, false>::ConcurrentVectorImpl(
              dim,
              size_per_chunk,
              std::move(mmap_descriptor),
              valid_data_ptr,
              use_mapping_storage) {
    }
};

template <>
class ConcurrentVector<Int8Vector> : public ConcurrentVectorImpl<int8, false> {
 public:
    ConcurrentVector(int64_t dim,
                     int64_t size_per_chunk,
                     storage::MmapChunkDescriptorPtr mmap_descriptor = nullptr,
                     ThreadSafeValidDataPtr valid_data_ptr = nullptr,
                     bool use_mapping_storage = false)
        : ConcurrentVectorImpl<int8, false>::ConcurrentVectorImpl(
              dim,
              size_per_chunk,
              std::move(mmap_descriptor),
              valid_data_ptr,
              use_mapping_storage) {
    }
};

[[maybe_unused]] static bool
ConcurrentDenseVectorCheck(const VectorBase* vec_base, DataType data_type) {
    if (data_type == DataType::VECTOR_FLOAT) {
        return dynamic_cast<const ConcurrentVector<FloatVector>*>(vec_base);
    } else if (data_type == DataType::VECTOR_FLOAT16) {
        return dynamic_cast<const ConcurrentVector<Float16Vector>*>(vec_base);
    } else if (data_type == DataType::VECTOR_BFLOAT16) {
        return dynamic_cast<const ConcurrentVector<BFloat16Vector>*>(vec_base);
    } else {
        return false;
    }
}

}  // namespace milvus::segcore
