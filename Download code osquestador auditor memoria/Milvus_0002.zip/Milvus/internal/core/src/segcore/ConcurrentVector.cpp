// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#include "segcore/ConcurrentVector.h"

#include <algorithm>
#include <cstdint>

#include "common/Types.h"
#include "common/Utils.h"
#include "fmt/core.h"
#include "pb/schema.pb.h"
#include "simdjson/padded_string.h"

namespace milvus::segcore {

void
VectorBase::set_data_raw(ssize_t element_offset,
                         ssize_t element_count,
                         const DataArray* data,
                         const FieldMeta& field_meta) {
    if (field_meta.is_vector()) {
        if (field_meta.get_data_type() == DataType::VECTOR_FLOAT) {
            return set_data_raw(element_offset,
                                VEC_FIELD_DATA(data, float).data(),
                                element_count);
        } else if (field_meta.get_data_type() == DataType::VECTOR_BINARY) {
            return set_data_raw(
                element_offset, VEC_FIELD_DATA(data, binary), element_count);
        } else if (field_meta.get_data_type() == DataType::VECTOR_FLOAT16) {
            return set_data_raw(
                element_offset, VEC_FIELD_DATA(data, float16), element_count);
        } else if (field_meta.get_data_type() == DataType::VECTOR_BFLOAT16) {
            return set_data_raw(
                element_offset, VEC_FIELD_DATA(data, bfloat16), element_count);
        } else if (field_meta.get_data_type() ==
                   DataType::VECTOR_SPARSE_U32_F32) {
            return set_data_raw(
                element_offset,
                SparseBytesToRows(
                    data->vectors().sparse_float_vector().contents())
                    .get(),
                element_count);
        } else if (field_meta.get_data_type() == DataType::VECTOR_INT8) {
            return set_data_raw(
                element_offset, VEC_FIELD_DATA(data, int8), element_count);
        } else if (field_meta.get_data_type() == DataType::VECTOR_ARRAY) {
            auto& vector_array = data->vectors().vector_array().data();
            const auto& valid_data = GetFieldDataRowValidData(*data);
            std::vector<VectorArray> data_raw{};
            if (field_meta.is_nullable() &&
                valid_data.size() == element_count) {
                ssize_t valid_count = 0;
                for (ssize_t i = 0; i < element_count; ++i) {
                    if (valid_data[i]) {
                        ++valid_count;
                    }
                }
                data_raw.reserve(valid_count);
                if (vector_array.size() == element_count) {
                    for (ssize_t i = 0; i < element_count; ++i) {
                        if (valid_data[i]) {
                            data_raw.emplace_back(VectorArray(vector_array[i]));
                        }
                    }
                } else {
                    AssertInfo(
                        vector_array.size() == valid_count,
                        "compact nullable VECTOR_ARRAY data size {} must "
                        "match valid count {}",
                        vector_array.size(),
                        valid_count);
                    for (auto& e : vector_array) {
                        data_raw.emplace_back(VectorArray(e));
                    }
                }
            } else {
                AssertInfo(vector_array.size() == element_count,
                           "VECTOR_ARRAY data size {} must match element "
                           "count {} when not using compact nullable format",
                           vector_array.size(),
                           element_count);
                data_raw.reserve(vector_array.size());
                for (auto& e : vector_array) {
                    data_raw.emplace_back(VectorArray(e));
                }
            }
            return set_data_raw(element_offset, data_raw.data(), element_count);
        } else {
            ThrowInfo(DataTypeInvalid, "unsupported vector type");
        }
    }

    switch (field_meta.get_data_type()) {
        case DataType::BOOL: {
            return set_data_raw(
                element_offset, FIELD_DATA(data, bool).data(), element_count);
        }
        case DataType::INT8: {
            auto& src_data = FIELD_DATA(data, int);
            std::vector<int8_t> data_raw(src_data.size());
            std::copy_n(src_data.data(), src_data.size(), data_raw.data());
            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        case DataType::INT16: {
            auto& src_data = FIELD_DATA(data, int);
            std::vector<int16_t> data_raw(src_data.size());
            std::copy_n(src_data.data(), src_data.size(), data_raw.data());
            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        case DataType::INT32: {
            return set_data_raw(
                element_offset, FIELD_DATA(data, int).data(), element_count);
        }
        case DataType::INT64: {
            return set_data_raw(
                element_offset, FIELD_DATA(data, long).data(), element_count);
        }
        case DataType::FLOAT: {
            return set_data_raw(
                element_offset, FIELD_DATA(data, float).data(), element_count);
        }
        case DataType::DOUBLE: {
            return set_data_raw(
                element_offset, FIELD_DATA(data, double).data(), element_count);
        }
        case DataType::TIMESTAMPTZ: {
            return set_data_raw(element_offset,
                                FIELD_DATA(data, timestamptz).data(),
                                element_count);
        }
        case DataType::STRING:
        case DataType::VARCHAR:
        case DataType::TEXT: {
            auto& field_data = FIELD_DATA(data, string);
            std::vector<std::string> data_raw(field_data.begin(),
                                              field_data.end());
            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        case DataType::JSON: {
            auto& json_data = FIELD_DATA(data, json);
            std::vector<Json> data_raw{};
            data_raw.reserve(json_data.size());
            for (auto& json_bytes : json_data) {
                data_raw.emplace_back(simdjson::padded_string(json_bytes));
            }

            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        case DataType::GEOMETRY: {
            // get the geometry array of a column from proto message
            auto& geometry_data = FIELD_DATA(data, geometry);
            AssertInfo(geometry_data.size() == element_count,
                       "geometry payload size {} must match element count {}",
                       geometry_data.size(),
                       element_count);
            std::vector<std::string> data_raw{};
            data_raw.reserve(geometry_data.size());
            for (auto& geometry_bytes : geometry_data) {
                //this geometry_bytes consider as wkt strings from milvus-proto
                data_raw.emplace_back(
                    std::string(geometry_bytes.data(), geometry_bytes.size()));
            }
            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        case DataType::ARRAY: {
            auto& array_data = FIELD_DATA(data, array);
            std::vector<Array> data_raw{};
            data_raw.reserve(array_data.size());
            for (auto& array_bytes : array_data) {
                data_raw.emplace_back(Array(array_bytes));
            }

            return set_data_raw(element_offset, data_raw.data(), element_count);
        }
        default: {
            ThrowInfo(DataTypeInvalid,
                      fmt::format("unsupported datatype {}",
                                  field_meta.get_data_type()));
        }
    }
}

void
ConcurrentVector<ArrayValue>::set_data_raw(ssize_t element_offset,
                                           ssize_t element_count,
                                           const DataArray* data,
                                           const FieldMeta& field_meta) {
    const auto& array_data = FIELD_DATA(data, array);
    std::call_once(array_type_once_, [&] {
        array_type_ = std::make_shared<const proto::schema::TypeSchema>(
            field_meta.get_array_type_schema());
    });

    if (!is_mmap()) {
        std::vector<ArrayValue> data_raw;
        data_raw.reserve(element_count);
        for (ssize_t i = 0; i < element_count; ++i) {
            const auto& row = array_data.Get(static_cast<int>(i));
            data_raw.emplace_back(ArrayValue(row, array_type_));
        }
        return Base::set_data_raw(
            element_offset, data_raw.data(), element_count);
    }

    std::vector<const ScalarFieldProto*> rows;
    rows.reserve(element_count);
    for (ssize_t i = 0; i < element_count; ++i) {
        rows.push_back(&array_data.Get(static_cast<int>(i)));
    }

    set_mmap_proto_rows(
        element_offset,
        std::span<const ScalarFieldProto* const>(rows.data(), rows.size()));
}

void
ConcurrentVector<ArrayValue>::set_mmap_proto_rows(
    ssize_t element_offset, std::span<const ScalarFieldProto* const> rows) {
    if (rows.empty()) {
        return;
    }

    const auto element_count = static_cast<ssize_t>(rows.size());
    const auto end_offset = element_offset + element_count;

    int64_t chunk_num;
    int64_t allocation_chunk_size;
    if (size_per_chunk_ == MAX_ROW_COUNT) {
        chunk_num = 1;
        allocation_chunk_size = end_offset;
    } else {
        chunk_num = upper_div(end_offset, size_per_chunk_);
        allocation_chunk_size = size_per_chunk_;
    }
    chunks_ptr_->emplace_to_at_least(chunk_num, allocation_chunk_size);

    using MmapArrayChunkVector =
        ThreadSafeChunkVector<ArrayValue,
                              VariableLengthChunk<ArrayValue>,
                              true>;
    auto* mmap_chunks = static_cast<MmapArrayChunkVector*>(chunks_ptr_.get());

    ssize_t current_offset = element_offset;
    size_t source_offset = 0;
    while (source_offset < rows.size()) {
        const auto chunk_id = current_offset / size_per_chunk_;
        const auto chunk_offset = current_offset % size_per_chunk_;
        const auto remaining_in_chunk =
            static_cast<ssize_t>(size_per_chunk_ - chunk_offset);
        const auto remaining_rows =
            static_cast<ssize_t>(rows.size() - source_offset);
        const auto copy_count = std::min(remaining_in_chunk, remaining_rows);
        mmap_chunks->copy_array_rows_to_chunk(
            chunk_id,
            static_cast<size_t>(chunk_offset),
            rows.subspan(source_offset, static_cast<size_t>(copy_count)),
            *array_type_);
        current_offset += copy_count;
        source_offset += static_cast<size_t>(copy_count);
    }
}

}  // namespace milvus::segcore
