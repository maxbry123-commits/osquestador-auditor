// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once

#include <stdint.h>
#include <stdbool.h>

#include "common/common_type_c.h"

#ifdef __cplusplus
extern "C" {
#endif

void
SegcoreInit(const char*);

void
SegcoreSetChunkRows(const int64_t);

void
SegcoreSetEnableInterminSegmentIndex(const bool);

CStatus
SegcoreSetInterimIndexTargetVersion(const int64_t target_version);

void
SegcoreSetStorageV3Enabled(const bool);

void
SegcoreSetEnableGrowingSourceFlush(const bool);

void
SegcoreSetEnableGeometryCache(const bool);

void
SegcoreSetEnableGISSplitFusion(const bool);

void
SegcoreSetNlist(const int64_t);

// FM-index count-first guard threshold (queryNode.fmindexCostRatio).
void
SegcoreSetFMIndexCostRatio(const float);

void
SegcoreSetNprobe(const int64_t);

CStatus
SegcoreSetDenseVectorInterminIndexType(const char*);

void
SegcoreSetSubDim(const int64_t);

void
SegcoreSetRefineRatio(const float);

void
SegcoreSetIndexBuildRatio(const float);

void
SegcoreSetGrowingIndexBuildThreadRate(const float);

CStatus
SegcoreSetDenseVectorInterminIndexRefineQuantType(const char*);

void
SegcoreSetDenseVectorInterminIndexRefineWithQuantFlag(const bool);

void
SegcoreSetInterimIndexMemExpansionRate(const float);

void
SegcoreSetMaxGroupByGroups(const int64_t);

// return value must be freed by the caller
char*
SegcoreSetSimdType(const char*);

void
SegcoreEnableKnowhereScoreConsistency();

void
SegcoreSetKnowhereBuildThreadPoolNum(const uint32_t num_threads);

void
SegcoreSetKnowhereSearchThreadPoolNum(const uint32_t num_threads);

void
SegcoreSetKnowhereFetchThreadPoolNum(const uint32_t num_threads);

void
SegcoreSetPrefetchThreadPoolNum(const uint32_t num_threads);

void
SegcoreSetKnowhereGpuMemoryPoolSize(const uint32_t init_size,
                                    const uint32_t max_size);

// Deprecated: row visibility filtering is always enforced; the value is
// ignored. Kept so callers built against the v3.0.0 interface keep linking.
void
SegcoreSetVisibilityFilterEnabled(const bool value);

void
SegcoreSetPreferFieldDataWhenIndexHasRawData(const bool value);

void
SegcoreSetTakeForOutputResultCountLimit(const int64_t value);

int64_t
SegcoreGetTakeForOutputResultCountLimit();

void
SegcoreCloseGlog();

int32_t
GetCurrentIndexVersion();

int32_t
GetMinimalIndexVersion();

int32_t
GetMaximumIndexVersion();

void
SetThreadName(const char*);

void
ConfigureTieredStorage(
    // Cache warmup policies
    const CacheWarmupPolicy scalarFieldCacheWarmupPolicy,
    const CacheWarmupPolicy vectorFieldCacheWarmupPolicy,
    const CacheWarmupPolicy scalarIndexCacheWarmupPolicy,
    const CacheWarmupPolicy vectorIndexCacheWarmupPolicy,
    // watermarks
    const int64_t memory_low_watermark_bytes,
    const int64_t memory_high_watermark_bytes,
    const int64_t memory_max_bytes,
    const int64_t disk_low_watermark_bytes,
    const int64_t disk_high_watermark_bytes,
    const int64_t disk_max_bytes,
    // storage usage tracking enabled
    const bool storage_usage_tracking_enabled,
    // eviction enabled
    const bool eviction_enabled,
    // eviction configs
    const int64_t cache_touch_window_ms,
    const bool background_eviction_enabled,
    const int64_t eviction_interval_ms,
    const int64_t cache_cell_unaccessed_survival_time,
    const float overloaded_memory_threshold_percentage,
    const float loading_resource_factor,
    const float max_disk_usage_percentage,
    const char* disk_path,
    const int64_t loading_timeout_ms,
    const int64_t warmup_loading_timeout_ms,
    const bool reject_remote_vector_output,
    // async warmup prefetch pool threads
    const uint32_t prefetch_pool_threads);

void
UpdateTieredStorageConfig(const int64_t loading_timeout_ms,
                          const int64_t warmup_loading_timeout_ms,
                          const bool storage_usage_tracking_enabled,
                          const bool reject_remote_vector_output,
                          const CacheWarmupPolicy scalarFieldCacheWarmupPolicy,
                          const CacheWarmupPolicy vectorFieldCacheWarmupPolicy,
                          const CacheWarmupPolicy scalarIndexCacheWarmupPolicy,
                          const CacheWarmupPolicy vectorIndexCacheWarmupPolicy);

#ifdef __cplusplus
}
#endif
