#include "segcore/storagev1translator/InterimSealedIndexTranslator.h"

#include <algorithm>
#include <exception>
#include <map>
#include <memory>
#include <optional>
#include <type_traits>

#include "cachinglayer/CacheSlot.h"
#include "common/Chunk.h"
#include "common/OffsetMapping.h"
#include "fmt/core.h"
#include "folly/FBVector.h"
#include "index/Index.h"
#include "index/Utils.h"
#include "index/VectorIndex.h"
#include "index/VectorIndexValidDataUtils.h"
#include "index/VectorMemIndex.h"
#include "knowhere/dataset.h"
#include "knowhere/expected.h"
#include "knowhere/object.h"
#include "knowhere/operands.h"
#include "mmap/ChunkedColumnInterface.h"
#include "nlohmann/json.hpp"
#include "segcore/Utils.h"

namespace milvus::segcore::storagev1translator {
InterimSealedIndexTranslator::InterimSealedIndexTranslator(
    std::shared_ptr<ChunkedColumnInterface> vec_data,
    int64_t segment_id,
    int64_t field_id,
    knowhere::IndexType index_type,
    knowhere::MetricType metric_type,
    IndexVersion index_version,
    knowhere::Json build_config,
    int64_t dim,
    bool is_sparse,
    DataType vec_data_type,
    const std::string& warmup_policy)
    : vec_data_(vec_data),
      segment_id_(segment_id),
      index_type_(index_type),
      metric_type_(metric_type),
      index_version_(index_version),
      build_config_(build_config),
      dim_(dim),
      is_sparse_(is_sparse),
      vec_data_type_(vec_data_type),
      index_key_(fmt::format("seg_{}_ii_{}", segment_id, field_id)),
      meta_(milvus::cachinglayer::StorageType::MEMORY,
            milvus::cachinglayer::CellIdMappingMode::ALWAYS_ZERO,
            milvus::segcore::getCellDataType(
                /* is_vector */ true,
                /* is_index */ true),
            milvus::segcore::getCacheWarmupPolicy(warmup_policy,
                                                  /* is_vector */ true,
                                                  /* is_index */ true),
            /* support_eviction */ false) {
}

size_t
InterimSealedIndexTranslator::num_cells() const {
    return 1;
}

milvus::cachinglayer::cid_t
InterimSealedIndexTranslator::cell_id_of(
    milvus::cachinglayer::uid_t uid) const {
    return 0;
}

std::pair<milvus::cachinglayer::ResourceUsage,
          milvus::cachinglayer::ResourceUsage>
InterimSealedIndexTranslator::estimated_byte_size_of_cell(
    milvus::cachinglayer::cid_t cid) const {
    int64_t size = vec_data_->DataByteSize();
    int64_t row_count = vec_data_->NumRows();
    // TODO: hack, move these estimate logic to knowhere
    // ignore the size of centroids
    if (index_type_ == knowhere::IndexEnum::INDEX_FAISS_SCANN_DVR) {
        int64_t vec_size =
            int64_t(index::GetValueFromConfig<int>(
                        build_config_, knowhere::indexparam::SUB_DIM)
                        .value() /
                    8 * dim_);
        if (build_config_[knowhere::indexparam::REFINE_TYPE] ==
            knowhere::RefineType::UINT8_QUANT) {
            vec_size += dim_ * 1;
        } else if (build_config_[knowhere::indexparam::REFINE_TYPE] ==
                       knowhere::RefineType::FLOAT16_QUANT ||
                   build_config_[knowhere::indexparam::REFINE_TYPE] ==
                       knowhere::RefineType::BFLOAT16_QUANT) {
            vec_size += dim_ * 2;
        }  // else knowhere::RefineType::DATA_VIEW, no extra size
        return {{vec_size * row_count, 0},
                {static_cast<int64_t>(vec_size * row_count + size * 0.5), 0}};
    } else if (index_type_ == knowhere::IndexEnum::INDEX_FAISS_IVFFLAT_CC) {
        // fp16/bf16 all use float32 to build index
        int64_t fp32_size = row_count * sizeof(float) * dim_;
        return {{fp32_size, 0}, {static_cast<int64_t>(fp32_size * 0.5), 0}};
    } else {
        // SPARSE_WAND_CC and SPARSE_INVERTED_INDEX_CC basically has the same size as the
        // raw data.
        return {{size, 0}, {static_cast<int64_t>(size * 2.0), 0}};
    }
}

const std::string&
InterimSealedIndexTranslator::key() const {
    return index_key_;
}

std::vector<std::pair<milvus::cachinglayer::cid_t,
                      std::unique_ptr<milvus::index::IndexBase>>>
InterimSealedIndexTranslator::get_cells(
    milvus::OpContext* ctx,
    const std::vector<milvus::cachinglayer::cid_t>& cids) {
    // Check for cancellation before building interim index
    CheckCancellation(
        ctx, segment_id_, "InterimSealedIndexTranslator::get_cells()");

    std::unique_ptr<index::VectorIndex> vec_index = nullptr;
    auto num_chunk = vec_data_->num_chunks();
    if (vec_data_->IsNullable()) {
        vec_data_->BuildValidRowIds(ctx);
    }
    const auto& offset_mapping = vec_data_->GetOffsetMapping();
    bool nullable = offset_mapping.IsEnabled();
    const FixedVector<bool>* valid_data = nullptr;
    if (nullable) {
        valid_data = &vec_data_->GetValidData();
    }

    if (!is_sparse_) {
        auto rows_until_chunk = std::make_shared<std::vector<int64_t>>();
        rows_until_chunk->reserve(num_chunk + 1);
        rows_until_chunk->push_back(0);
        for (int64_t chunk_id = 0; chunk_id < num_chunk; ++chunk_id) {
            const auto chunk_rows =
                nullable ? vec_data_->GetValidCountInChunk(chunk_id)
                         : vec_data_->chunk_row_nums(chunk_id);
            rows_until_chunk->push_back(rows_until_chunk->back() + chunk_rows);
        }

        knowhere::ViewDataOp view_data = [field_raw_data_ptr = vec_data_,
                                          rows_until_chunk,
                                          num_chunk](size_t id) {
            auto compact_offset = static_cast<int64_t>(id);
            auto it = std::upper_bound(rows_until_chunk->begin(),
                                       rows_until_chunk->end(),
                                       compact_offset);
            AssertInfo(it != rows_until_chunk->begin(),
                       "Compact offset {} is out of range",
                       id);
            const auto chunk_id =
                std::distance(rows_until_chunk->begin(), it) - 1;
            AssertInfo(
                chunk_id < num_chunk, "Compact offset {} is out of range", id);
            compact_offset -= (*rows_until_chunk)[chunk_id];

            auto pw = field_raw_data_ptr->GetChunk(nullptr, chunk_id);
            auto chunk = pw.get();
            return static_cast<const void*>(chunk->ValueAt(compact_offset));
        };

        if (vec_data_type_ == DataType::VECTOR_FLOAT) {
            vec_index =
                std::make_unique<index::VectorMemIndex<float>>(DataType::NONE,
                                                               index_type_,
                                                               metric_type_,
                                                               index_version_,
                                                               view_data,
                                                               false);
        } else if (vec_data_type_ == DataType::VECTOR_FLOAT16) {
            vec_index = std::make_unique<index::VectorMemIndex<knowhere::fp16>>(
                DataType::NONE,
                index_type_,
                metric_type_,
                index_version_,
                view_data,
                false);
        } else if (vec_data_type_ == DataType::VECTOR_BFLOAT16) {
            vec_index = std::make_unique<index::VectorMemIndex<knowhere::bf16>>(
                DataType::NONE,
                index_type_,
                metric_type_,
                index_version_,
                view_data,
                false);
        }
    } else {
        // sparse vector case
        vec_index = std::make_unique<index::VectorMemIndex<sparse_u32_f32>>(
            DataType::NONE, index_type_, metric_type_, index_version_, false);
    }

    int64_t total_valid_count =
        nullable ? offset_mapping.GetValidCount() : vec_data_->NumRows();
    if (nullable) {
        vec_index->SetIdMapType(knowhere::IdMap::Type::GROWING);
    }

    if (total_valid_count == 0) {
        if (nullable) {
            auto dataset = knowhere::GenDataSet(0, dim_, nullptr);
            dataset->SetIsSparse(is_sparse_);
            dataset->SetIdMapData(knowhere::IdMapData::FromValidData(
                valid_data->data(), valid_data->size()));
            vec_index->BuildWithDataset(dataset, build_config_);
        }
        std::vector<std::pair<cid_t, std::unique_ptr<milvus::index::IndexBase>>>
            result;
        result.emplace_back(std::make_pair(0, std::move(vec_index)));
        return result;
    }

    bool first_build = true;
    for (int i = 0; i < num_chunk; ++i) {
        auto pw = vec_data_->GetChunk(ctx, i);
        auto chunk = pw.get();

        const int64_t logical_begin = vec_data_->GetNumRowsUntilChunk(i);
        const int64_t logical_rows = vec_data_->chunk_row_nums(i);
        int64_t actual_row_count =
            nullable ? vec_data_->GetValidCountInChunk(i) : logical_rows;

        if (actual_row_count == 0) {
            if (nullable && !first_build) {
                auto dataset = knowhere::GenDataSet(0, dim_, nullptr);
                dataset->SetIsSparse(is_sparse_);
                dataset->SetIdMapData(knowhere::IdMapData::FromValidData(
                    valid_data->data() + logical_begin,
                    static_cast<size_t>(logical_rows)));
                vec_index->AddWithDataset(dataset, build_config_);
            }
            continue;
        }

        auto dataset =
            knowhere::GenDataSet(actual_row_count, dim_, chunk->Data());
        dataset->SetIsOwner(false);
        dataset->SetIsSparse(is_sparse_);

        if (first_build) {
            if (nullable) {
                const auto logical_prefix = logical_begin + logical_rows;
                dataset->SetIdMapData(knowhere::IdMapData::FromValidData(
                    valid_data->data(), static_cast<size_t>(logical_prefix)));
            }
            vec_index->BuildWithDataset(dataset, build_config_);
            first_build = false;
        } else {
            if (nullable) {
                dataset->SetIdMapData(knowhere::IdMapData::FromValidData(
                    valid_data->data() + logical_begin,
                    static_cast<size_t>(logical_rows)));
            }
            vec_index->AddWithDataset(dataset, build_config_);
        }
    }

    std::vector<std::pair<cid_t, std::unique_ptr<milvus::index::IndexBase>>>
        result;
    result.emplace_back(std::make_pair(0, std::move(vec_index)));
    return result;
}

Meta*
InterimSealedIndexTranslator::meta() {
    return &meta_;
}

}  // namespace milvus::segcore::storagev1translator
