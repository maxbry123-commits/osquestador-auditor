// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#include <boost/algorithm/string/predicate.hpp>
#include <boost/container/vector.hpp>
#include <boost/regex.hpp>
#include <boost/cstdint.hpp>
#include <boost/filesystem/operations.hpp>
#include <fmt/core.h>
#include <folly/FBVector.h>
#include <gtest/gtest.h>
#include <nlohmann/json.hpp>
#include <stdlib.h>
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <tuple>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <random>

#include "bitset/bitset.h"
#include "bitset/detail/proxy.h"
#include "common/Consts.h"
#include "common/FieldDataInterface.h"
#include "common/Tracer.h"
#include "common/RegexQuery.h"
#include "common/TracerBase.h"
#include "common/Types.h"
#include "common/protobuf_utils.h"
#include "gtest/gtest.h"
#include "index/Index.h"
#include "index/InvertedIndexTantivy.h"
#include "index/IndexFactory.h"
#include "index/IndexInfo.h"
#include "index/IndexStats.h"
#include "index/Meta.h"
#include "index/ScalarIndex.h"
#include "indexbuilder/IndexCreatorBase.h"
#include "indexbuilder/IndexFactory.h"
#include "knowhere/dataset.h"
#include "pb/common.pb.h"
#include "pb/plan.pb.h"
#include "pb/schema.pb.h"
#include "segcore/Collection.h"
#include "storage/ChunkManager.h"
#include "storage/FileManager.h"
#include "storage/InsertData.h"
#include "storage/PayloadReader.h"
#include "storage/ThreadPools.h"
#include "storage/Types.h"
#include "storage/Util.h"
#include "test_utils/Constants.h"
#include "test_utils/DataGen.h"
#include "test_utils/indexbuilder_test_utils.h"
#include "test_utils/storage_test_utils.h"

using namespace milvus;
using namespace milvus::segcore;

namespace milvus::test {

TEST(InvertedIndex, PatternMatchPlannerPolicy) {
    index::InvertedIndexTantivy<std::string> index;

    EXPECT_TRUE(index.SupportPatternMatch());
    EXPECT_TRUE(index.ShouldUseOp(proto::plan::OpType::PrefixMatch));
    EXPECT_FALSE(index.ShouldUseOp(proto::plan::OpType::RegexMatch));
    EXPECT_TRUE(index.ShouldUseOp(proto::plan::OpType::Equal));
    EXPECT_TRUE(index.ShouldUseOp(proto::plan::OpType::Match));
    EXPECT_FALSE(index.ShouldUseOp(proto::plan::OpType::InnerMatch));
    EXPECT_FALSE(index.ShouldUseOp(proto::plan::OpType::PostfixMatch));

    index::InvertedIndexTantivy<int64_t> int_index;
    EXPECT_FALSE(int_index.SupportPatternMatch());
    EXPECT_FALSE(int_index.ShouldUseOp(proto::plan::OpType::Match));
    EXPECT_FALSE(int_index.ShouldUseOp(proto::plan::OpType::PrefixMatch));
    EXPECT_FALSE(int_index.ShouldUseOp(proto::plan::OpType::RegexMatch));
    EXPECT_TRUE(int_index.ShouldUseOp(proto::plan::OpType::Equal));
}

struct ChunkManagerWrapper {
    ChunkManagerWrapper(storage::ChunkManagerPtr cm) : cm_(cm) {
    }

    ~ChunkManagerWrapper() {
        for (const auto& file : written_) {
            cm_->Remove(file);
        }

        boost::system::error_code ec;
        boost::filesystem::remove_all(cm_->GetRootPath(), ec);
    }

    void
    Write(const std::string& filepath, void* buf, uint64_t len) {
        written_.insert(filepath);
        cm_->Write(filepath, buf, len);
    }

    const storage::ChunkManagerPtr cm_;
    std::unordered_set<std::string> written_;
};

struct FileSliceSizeGuard {
    explicit FileSliceSizeGuard(int64_t slice_size)
        : old_slice_size_(FILE_SLICE_SIZE.load()) {
        FILE_SLICE_SIZE.store(slice_size);
    }

    ~FileSliceSizeGuard() {
        FILE_SLICE_SIZE.store(old_slice_size_);
    }

    int64_t old_slice_size_;
};
}  // namespace milvus::test

template <typename T,
          DataType dtype,
          DataType element_type = DataType::NONE,
          bool nullable = false,
          bool has_lack_binlog_row_ = false,
          bool has_default_value_ = false>
void
test_run() {
    int64_t collection_id = 1;
    int64_t partition_id = 2;
    int64_t segment_id = 3;
    int64_t field_id = 101;
    int64_t index_build_id = 4000;
    int64_t index_version = 4000;
    int64_t lack_binlog_row = 100;

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id,
                                                      dtype,
                                                      element_type,
                                                      nullable);
    auto index_meta =
        gen_index_meta(segment_id, field_id, index_build_id, index_version);

    if (has_default_value_) {
        auto default_value = field_meta.field_schema.mutable_default_value();
        if constexpr (std::is_same_v<int8_t, T> || std::is_same_v<int16_t, T> ||
                      std::is_same_v<int32_t, T>) {
            default_value->set_int_data(20);
        } else if constexpr (std::is_same_v<int64_t, T>) {
            default_value->set_long_data(20);
        } else if constexpr (std::is_same_v<float, T>) {
            default_value->set_float_data(20);
        } else if constexpr (std::is_same_v<double, T>) {
            default_value->set_double_data(20);
        } else if constexpr (std::is_same_v<bool, T>) {
            default_value->set_bool_data(true);
        }
    }

    std::string root_path = TestLocalPath;
    auto storage_config = gen_local_storage_config(root_path);
    auto cm = storage::CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);

    size_t nb = 10000;
    std::vector<T> data_gen;
    boost::container::vector<T> data;
    FixedVector<bool> valid_data;
    if constexpr (!std::is_same_v<T, bool>) {
        data_gen = GenSortedArr<T>(nb);
    } else {
        for (size_t i = 0; i < nb; i++) {
            data_gen.push_back(rand() % 2 == 0);
        }
    }
    if (nullable) {
        valid_data.reserve(nb);
        for (size_t i = 0; i < nb; i++) {
            valid_data.push_back(rand() % 2 == 0);
        }
    }
    for (auto x : data_gen) {
        data.push_back(x);
    }

    auto field_data = storage::CreateFieldData(dtype, DataType::NONE, nullable);
    if (nullable) {
        int byteSize = (nb + 7) / 8;
        uint8_t* valid_data_ = new uint8_t[byteSize];
        for (int i = 0; i < nb; i++) {
            bool value = valid_data[i];
            int byteIndex = i / 8;
            int bitIndex = i % 8;
            if (value) {
                valid_data_[byteIndex] |= (1 << bitIndex);
            } else {
                valid_data_[byteIndex] &= ~(1 << bitIndex);
            }
        }
        field_data->FillFieldData(data.data(), valid_data_, data.size(), 0);
        delete[] valid_data_;
    } else {
        field_data->FillFieldData(data.data(), data.size());
    }
    // std::cout << "length:" << field_data->get_num_rows() << std::endl;
    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);

    auto serialized_bytes = insert_data.Serialize(storage::Remote);

    auto get_binlog_path = [=](int64_t log_id) {
        return fmt::format("{}{}/{}/{}/{}/{}",
                           TestLocalPath,
                           collection_id,
                           partition_id,
                           segment_id,
                           field_id,
                           log_id);
    };

    auto log_path = get_binlog_path(0);

    auto cm_w = test::ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;

    {
        Config config;
        config["index_type"] = milvus::index::INVERTED_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        config[INDEX_NUM_ROWS_KEY] = nb;
        config[milvus::index::SCALAR_INDEX_ENGINE_VERSION] = 3;
        if (has_lack_binlog_row_) {
            config[INDEX_NUM_ROWS_KEY] = nb + lack_binlog_row;
        }

        auto index = indexbuilder::IndexFactory::GetInstance().CreateIndex(
            dtype, config, ctx);
        index->Build();

        auto create_index_result = index->Upload();
        auto memSize = create_index_result->GetMemSize();
        auto serializedSize = create_index_result->GetSerializedSize();
        ASSERT_GT(memSize, 0);
        ASSERT_GT(serializedSize, 0);
        index_files = create_index_result->GetIndexFiles();
    }

    {
        index::CreateIndexInfo index_info{};
        index_info.index_type = milvus::index::INVERTED_INDEX_TYPE;
        index_info.field_type = dtype;

        Config config;
        config["index_files"] = index_files;
        config[milvus::LOAD_PRIORITY] =
            milvus::proto::common::LoadPriority::HIGH;
        ctx.set_for_loading_index(true);
        auto index =
            index::IndexFactory::GetInstance().CreateIndex(index_info, ctx);
        index->LoadUnified(config);

        auto cnt = index->Count();
        if (has_lack_binlog_row_) {
            ASSERT_EQ(cnt, nb + lack_binlog_row);
        } else {
            ASSERT_EQ(cnt, nb);
        }

        using IndexType = index::ScalarIndex<T>;
        auto real_index = dynamic_cast<IndexType*>(index.get());

        if constexpr (!std::is_floating_point_v<T>) {
            // hard to compare floating-point value.
            {
                boost::container::vector<T> test_data;
                std::unordered_set<T> s;
                size_t nq = 10;
                for (size_t i = 0; i < nq && i < nb; i++) {
                    test_data.push_back(data[i]);
                    s.insert(data[i]);
                }
                auto bitset =
                    real_index->In(test_data.size(), test_data.data());
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (!has_default_value_) {
                            ASSERT_EQ(bitset[i], false);
                        } else {
                            ASSERT_EQ(bitset[i], s.find(20) != s.end());
                        }
                    }
                    start += lack_binlog_row;
                }
                for (size_t i = start; i < bitset.size(); i++) {
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(bitset[i], false);
                    } else {
                        ASSERT_EQ(bitset[i],
                                  s.find(data[i - start]) != s.end());
                    }
                }
            }

            {
                boost::container::vector<T> test_data;
                std::unordered_set<T> s;
                size_t nq = 10;
                for (size_t i = 0; i < nq && i < nb; i++) {
                    test_data.push_back(data[i]);
                    s.insert(data[i]);
                }
                auto bitset =
                    real_index->NotIn(test_data.size(), test_data.data());
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (!has_default_value_) {
                            ASSERT_EQ(bitset[i], false);
                        } else {
                            ASSERT_EQ(bitset[i], s.find(20) == s.end());
                        }
                    }
                    start += lack_binlog_row;
                }
                for (size_t i = start; i < bitset.size(); i++) {
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(bitset[i], false);
                    } else {
                        ASSERT_NE(bitset[i],
                                  s.find(data[i - start]) != s.end());
                    }
                }
            }

            {
                auto bitset = real_index->IsNull();
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (has_default_value_) {
                            ASSERT_EQ(bitset[i], false);
                        } else {
                            ASSERT_EQ(bitset[i], true);
                        }
                    }
                    start += lack_binlog_row;
                }
                for (size_t i = start; i < bitset.size(); i++) {
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(bitset[i], true);
                    } else {
                        ASSERT_EQ(bitset[i], false);
                    }
                }
            }

            {
                auto bitset = real_index->IsNotNull();
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (has_default_value_) {
                            ASSERT_EQ(bitset[i], true);
                        } else {
                            ASSERT_EQ(bitset[i], false);
                        }
                    }
                    start += lack_binlog_row;
                }

                for (size_t i = start; i < bitset.size(); i++) {
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(bitset[i], false);
                    } else {
                        ASSERT_EQ(bitset[i], true);
                    }
                }
            }
        }

        using RefFunc = std::function<bool(int64_t)>;

        if constexpr (!std::is_same_v<T, bool>) {
            // range query on boolean is not reasonable.

            {
                std::vector<std::tuple<T, OpType, RefFunc, bool>> test_cases{
                    {
                        20,
                        OpType::GreaterThan,
                        [&](int64_t i) -> bool { return data[i] > 20; },
                        false,
                    },
                    {
                        20,
                        OpType::GreaterEqual,
                        [&](int64_t i) -> bool { return data[i] >= 20; },
                        true,
                    },
                    {
                        20,
                        OpType::LessThan,
                        [&](int64_t i) -> bool { return data[i] < 20; },
                        false,
                    },
                    {
                        20,
                        OpType::LessEqual,
                        [&](int64_t i) -> bool { return data[i] <= 20; },
                        true,
                    },
                };
                for (const auto& [test_value, op, ref, default_value_res] :
                     test_cases) {
                    auto bitset = real_index->Range(test_value, op);
                    ASSERT_EQ(cnt, bitset.size());
                    size_t start = 0;
                    if (has_lack_binlog_row_) {
                        for (int i = 0; i < lack_binlog_row; i++) {
                            if (has_default_value_) {
                                ASSERT_EQ(bitset[i], default_value_res);
                            } else {
                                ASSERT_EQ(bitset[i], false);
                            }
                        }
                        start += lack_binlog_row;
                    }
                    for (size_t i = start; i < bitset.size(); i++) {
                        auto ans = bitset[i];
                        auto should = ref(i - start);
                        if (nullable && !valid_data[i - start]) {
                            ASSERT_EQ(ans, false);
                        } else {
                            ASSERT_EQ(ans, should)
                                << "op: " << op << ", @" << i
                                << ", ans: " << ans << ", ref: " << should;
                        }
                    }
                }
            }

            {
                std::vector<std::tuple<T, bool, T, bool, RefFunc, bool>>
                    test_cases{
                        {
                            1,
                            false,
                            20,
                            false,
                            [&](int64_t i) -> bool {
                                return 1 < data[i] && data[i] < 20;
                            },
                            false,
                        },
                        {
                            1,
                            false,
                            20,
                            true,
                            [&](int64_t i) -> bool {
                                return 1 < data[i] && data[i] <= 20;
                            },
                            true,
                        },
                        {
                            1,
                            true,
                            20,
                            false,
                            [&](int64_t i) -> bool {
                                return 1 <= data[i] && data[i] < 20;
                            },
                            false,
                        },
                        {
                            1,
                            true,
                            20,
                            true,
                            [&](int64_t i) -> bool {
                                return 1 <= data[i] && data[i] <= 20;
                            },
                            true,
                        },
                    };
                for (const auto& [lb,
                                  lb_inclusive,
                                  ub,
                                  ub_inclusive,
                                  ref,
                                  default_value_res] : test_cases) {
                    auto bitset =
                        real_index->Range(lb, lb_inclusive, ub, ub_inclusive);
                    ASSERT_EQ(cnt, bitset.size());
                    size_t start = 0;
                    if (has_lack_binlog_row_) {
                        for (int i = 0; i < lack_binlog_row; i++) {
                            if (has_default_value_) {
                                ASSERT_EQ(bitset[i], default_value_res);
                            } else {
                                ASSERT_EQ(bitset[i], false);
                            }
                        }
                        start += lack_binlog_row;
                    }
                    for (size_t i = start; i < bitset.size(); i++) {
                        auto ans = bitset[i];
                        auto should = ref(i - start);
                        if (nullable && !valid_data[i - start]) {
                            ASSERT_EQ(ans, false);
                        } else {
                            ASSERT_EQ(ans, should)
                                << "@" << i << ", ans: " << ans
                                << ", ref: " << should;
                        }
                    }
                }
            }
        }
    }
}

template <bool nullable = false,
          bool has_lack_binlog_row_ = false,
          bool has_default_value_ = false>
void
test_string() {
    using T = std::string;
    DataType dtype = DataType::VARCHAR;

    int64_t collection_id = 1;
    int64_t partition_id = 2;
    int64_t segment_id = 3;
    int64_t field_id = 101;
    int64_t index_build_id = 4001;
    int64_t index_version = 4001;
    int64_t lack_binlog_row = 100;

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id,
                                                      dtype,
                                                      DataType::NONE,
                                                      nullable);
    auto index_meta =
        gen_index_meta(segment_id, field_id, index_build_id, index_version);

    if (has_default_value_) {
        auto default_value = field_meta.field_schema.mutable_default_value();
        default_value->set_string_data("20");
    }

    std::string root_path = TestLocalPath;
    auto storage_config = gen_local_storage_config(root_path);
    auto cm = storage::CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);

    size_t nb = 10000;
    boost::container::vector<T> data;
    FixedVector<bool> valid_data;
    for (size_t i = 0; i < nb; i++) {
        data.push_back(std::to_string(rand()));
    }
    if (nullable) {
        valid_data.reserve(nb);
        for (size_t i = 0; i < nb; i++) {
            valid_data.push_back(rand() % 2 == 0);
        }
    }

    auto field_data = storage::CreateFieldData(dtype, DataType::NONE, nullable);
    if (nullable) {
        int byteSize = (nb + 7) / 8;
        uint8_t* valid_data_ = new uint8_t[byteSize];
        for (int i = 0; i < nb; i++) {
            bool value = valid_data[i];
            int byteIndex = i / 8;
            int bitIndex = i % 8;
            if (value) {
                valid_data_[byteIndex] |= (1 << bitIndex);
            } else {
                valid_data_[byteIndex] &= ~(1 << bitIndex);
            }
        }
        field_data->FillFieldData(data.data(), valid_data_, data.size(), 0);
        delete[] valid_data_;
    } else {
        field_data->FillFieldData(data.data(), data.size());
    }
    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);

    auto serialized_bytes = insert_data.Serialize(storage::Remote);

    auto get_binlog_path = [=](int64_t log_id) {
        return fmt::format("{}{}/{}/{}/{}/{}",
                           TestLocalPath,
                           collection_id,
                           partition_id,
                           segment_id,
                           field_id,
                           log_id);
    };

    auto log_path = get_binlog_path(0);

    auto cm_w = test::ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;

    {
        Config config;
        config["index_type"] = milvus::index::INVERTED_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        config[INDEX_NUM_ROWS_KEY] = nb;
        config[milvus::index::SCALAR_INDEX_ENGINE_VERSION] = 3;
        if (has_lack_binlog_row_) {
            config[INDEX_NUM_ROWS_KEY] = nb + lack_binlog_row;
        }

        auto index = indexbuilder::IndexFactory::GetInstance().CreateIndex(
            dtype, config, ctx);
        index->Build();

        auto create_index_result = index->Upload();
        auto memSize = create_index_result->GetMemSize();
        auto serializedSize = create_index_result->GetSerializedSize();
        ASSERT_GT(memSize, 0);
        ASSERT_GT(serializedSize, 0);
        index_files = create_index_result->GetIndexFiles();
    }

    {
        index::CreateIndexInfo index_info{};
        index_info.index_type = milvus::index::INVERTED_INDEX_TYPE;
        index_info.field_type = dtype;

        Config config;
        config["index_files"] = index_files;
        config[milvus::LOAD_PRIORITY] =
            milvus::proto::common::LoadPriority::HIGH;
        ctx.set_for_loading_index(true);
        auto index =
            index::IndexFactory::GetInstance().CreateIndex(index_info, ctx);
        index->LoadUnified(config);

        auto cnt = index->Count();
        if (has_lack_binlog_row_) {
            ASSERT_EQ(cnt, nb + lack_binlog_row);
        } else {
            ASSERT_EQ(cnt, nb);
        }

        using IndexType = index::ScalarIndex<T>;
        auto real_index = dynamic_cast<IndexType*>(index.get());

        {
            boost::container::vector<T> test_data;
            std::unordered_set<T> s;
            size_t nq = 10;
            for (size_t i = 0; i < nq && i < nb; i++) {
                test_data.push_back(data[i]);
                s.insert(data[i]);
            }
            auto bitset = real_index->In(test_data.size(), test_data.data());
            ASSERT_EQ(cnt, bitset.size());
            size_t start = 0;
            if (has_lack_binlog_row_) {
                for (int i = 0; i < lack_binlog_row; i++) {
                    if (!has_default_value_) {
                        ASSERT_EQ(bitset[i], false);
                    } else {
                        ASSERT_EQ(bitset[i], s.find("20") != s.end());
                    }
                }
                start += lack_binlog_row;
            }
            for (size_t i = start; i < bitset.size(); i++) {
                if (nullable && !valid_data[i - start]) {
                    ASSERT_EQ(bitset[i], false);
                } else {
                    ASSERT_EQ(bitset[i], s.find(data[i - start]) != s.end());
                }
            }
        }

        {
            boost::container::vector<T> test_data;
            std::unordered_set<T> s;
            size_t nq = 10;
            for (size_t i = 0; i < nq && i < nb; i++) {
                test_data.push_back(data[i]);
                s.insert(data[i]);
            }
            auto bitset = real_index->NotIn(test_data.size(), test_data.data());
            ASSERT_EQ(cnt, bitset.size());
            size_t start = 0;
            if (has_lack_binlog_row_) {
                for (int i = 0; i < lack_binlog_row; i++) {
                    if (!has_default_value_) {
                        ASSERT_EQ(bitset[i], false);
                    } else {
                        ASSERT_NE(bitset[i], s.find("20") != s.end());
                    }
                }
                start += lack_binlog_row;
            }
            for (size_t i = start; i < bitset.size(); i++) {
                if (nullable && !valid_data[i - start]) {
                    ASSERT_EQ(bitset[i], false);
                } else {
                    ASSERT_NE(bitset[i], s.find(data[i - start]) != s.end());
                }
            }
        }

        using RefFunc = std::function<bool(int64_t)>;

        {
            std::vector<std::tuple<T, OpType, RefFunc, bool>> test_cases{
                {
                    "20",
                    OpType::GreaterThan,
                    [&](int64_t i) -> bool { return data[i] > "20"; },
                    false,
                },
                {
                    "20",
                    OpType::GreaterEqual,
                    [&](int64_t i) -> bool { return data[i] >= "20"; },
                    true,
                },
                {
                    "20",
                    OpType::LessThan,
                    [&](int64_t i) -> bool { return data[i] < "20"; },
                    false,
                },
                {
                    "20",
                    OpType::LessEqual,
                    [&](int64_t i) -> bool { return data[i] <= "20"; },
                    true,
                },
            };
            for (const auto& [test_value, op, ref, default_value_res] :
                 test_cases) {
                auto bitset = real_index->Range(test_value, op);
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (has_default_value_) {
                            ASSERT_EQ(bitset[i], default_value_res);
                        } else {
                            ASSERT_EQ(bitset[i], false);
                        }
                    }
                    start += lack_binlog_row;
                }
                for (size_t i = start; i < bitset.size(); i++) {
                    auto ans = bitset[i];
                    auto should = ref(i - start);
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(ans, false);
                    } else {
                        ASSERT_EQ(ans, should)
                            << "op: " << op << ", @" << i << ", ans: " << ans
                            << ", ref: " << should;
                    }
                }
            }
        }

        {
            std::vector<std::tuple<T, bool, T, bool, RefFunc, bool>> test_cases{
                {
                    "1",
                    false,
                    "20",
                    false,
                    [&](int64_t i) -> bool {
                        return "1" < data[i] && data[i] < "20";
                    },
                    false,
                },
                {
                    "1",
                    false,
                    "20",
                    true,
                    [&](int64_t i) -> bool {
                        return "1" < data[i] && data[i] <= "20";
                    },
                    true,
                },
                {
                    "1",
                    true,
                    "20",
                    false,
                    [&](int64_t i) -> bool {
                        return "1" <= data[i] && data[i] < "20";
                    },
                    false,
                },
                {
                    "1",
                    true,
                    "20",
                    true,
                    [&](int64_t i) -> bool {
                        return "1" <= data[i] && data[i] <= "20";
                    },
                    true,
                },
            };
            for (const auto& [lb,
                              lb_inclusive,
                              ub,
                              ub_inclusive,
                              ref,
                              default_value_res] : test_cases) {
                auto bitset =
                    real_index->Range(lb, lb_inclusive, ub, ub_inclusive);
                ASSERT_EQ(cnt, bitset.size());
                size_t start = 0;
                if (has_lack_binlog_row_) {
                    for (int i = 0; i < lack_binlog_row; i++) {
                        if (has_default_value_) {
                            ASSERT_EQ(bitset[i], default_value_res);
                        } else {
                            ASSERT_EQ(bitset[i], false);
                        }
                    }
                    start += lack_binlog_row;
                }
                for (size_t i = start; i < bitset.size(); i++) {
                    auto ans = bitset[i];
                    auto should = ref(i - start);
                    if (nullable && !valid_data[i - start]) {
                        ASSERT_EQ(ans, false);
                    } else {
                        ASSERT_EQ(ans, should) << "@" << i << ", ans: " << ans
                                               << ", ref: " << should;
                    }
                }
            }
        }

        {
            auto dataset = std::make_shared<Dataset>();
            auto prefix = data[0];
            dataset->Set(index::OPERATOR_TYPE, OpType::PrefixMatch);
            dataset->Set(index::MATCH_VALUE, prefix);
            auto bitset = real_index->Query(dataset);
            ASSERT_EQ(cnt, bitset.size());
            size_t start = 0;
            if (has_lack_binlog_row_) {
                for (int i = 0; i < lack_binlog_row; i++) {
                    if (has_default_value_) {
                        ASSERT_EQ(bitset[i], boost::starts_with("20", prefix));
                    } else {
                        ASSERT_EQ(bitset[i], false);
                    }
                }
                start += lack_binlog_row;
            }
            for (size_t i = start; i < bitset.size(); i++) {
                auto should = boost::starts_with(data[i - start], prefix);
                if (nullable && !valid_data[i - start]) {
                    should = false;
                }
                ASSERT_EQ(bitset[i], should);
            }
        }

        {
            auto prefix = data[0];
            auto bitset =
                real_index->PatternMatch(prefix + "%", proto::plan::Match);
            ASSERT_EQ(cnt, bitset.size());
            size_t start = 0;
            if (has_lack_binlog_row_) {
                for (int i = 0; i < lack_binlog_row; i++) {
                    if (has_default_value_) {
                        ASSERT_EQ(bitset[i], boost::starts_with("20", prefix));
                    } else {
                        ASSERT_EQ(bitset[i], false);
                    }
                }
                start += lack_binlog_row;
            }
            for (size_t i = start; i < bitset.size(); i++) {
                auto should = boost::starts_with(data[i - start], prefix);
                if (nullable && !valid_data[i - start]) {
                    should = false;
                }
                ASSERT_EQ(bitset[i], should);
            }
        }
    }
}

TEST(InvertedIndex, Naive) {
    test_run<int8_t, DataType::INT8>();
    test_run<int16_t, DataType::INT16>();
    test_run<int32_t, DataType::INT32>();
    test_run<int64_t, DataType::INT64>();

    test_run<bool, DataType::BOOL>();

    test_run<float, DataType::FLOAT>();
    test_run<double, DataType::DOUBLE>();

    test_string();
    test_run<int8_t, DataType::INT8, DataType::NONE, true>();
    test_run<int16_t, DataType::INT16, DataType::NONE, true>();
    test_run<int32_t, DataType::INT32, DataType::NONE, true>();
    test_run<int64_t, DataType::INT64, DataType::NONE, true>();

    test_run<bool, DataType::BOOL, DataType::NONE, true>();

    test_run<float, DataType::FLOAT, DataType::NONE, true>();
    test_run<double, DataType::DOUBLE, DataType::NONE, true>();

    test_string<true>();
}

TEST(InvertedIndex, LoadSlicedNullOffsets) {
    milvus::test::FileSliceSizeGuard slice_size_guard(64);
    test_run<int64_t, DataType::INT64, DataType::NONE, true>();
}

TEST(InvertedIndex, HasLackBinlogRows) {
    // lack binlog is null
    test_run<int8_t, DataType::INT8, DataType::NONE, true, true>();
    test_run<int16_t, DataType::INT16, DataType::NONE, true, true>();
    test_run<int32_t, DataType::INT32, DataType::NONE, true, true>();
    test_run<int64_t, DataType::INT64, DataType::NONE, true, true>();

    test_run<bool, DataType::BOOL, DataType::NONE, true, true>();

    test_run<float, DataType::FLOAT, DataType::NONE, true, true>();
    test_run<double, DataType::DOUBLE, DataType::NONE, true, true>();

    test_string<true, true>();

    // lack binlog is default_value
    test_run<int8_t, DataType::INT8, DataType::NONE, true, true, true>();
    test_run<int16_t, DataType::INT16, DataType::NONE, true, true, true>();
    test_run<int32_t, DataType::INT32, DataType::NONE, true, true, true>();
    test_run<int64_t, DataType::INT64, DataType::NONE, true, true, true>();

    test_run<bool, DataType::BOOL, DataType::NONE, true, true, true>();

    test_run<float, DataType::FLOAT, DataType::NONE, true, true, true>();
    test_run<double, DataType::DOUBLE, DataType::NONE, true, true, true>();

    test_string<true, true, true>();
}

// ============== Unified Pattern Matching Consistency Tests ==============
// These tests verify that ALL THREE execution paths produce identical results:
// 1. RE2 regex (RegexMatcher) - used for sealed segments without index
// 2. LikePatternMatcher - used for growing data (brute-force scan)
// 3. Tantivy index - used for sealed segments with inverted index
//
// This is critical for query correctness across different segment states.

namespace {

// Helper to build Tantivy index for testing
std::unique_ptr<index::InvertedIndexTantivy<std::string>>
BuildTantivyStringIndex(const std::vector<std::string>& data) {
    auto index = std::make_unique<index::InvertedIndexTantivy<std::string>>();
    index->BuildWithRawDataForUT(data.size(), data.data(), Config());
    return index;
}

TEST(InvertedIndexTest, SealedAllValidDoesNotRetainValidityBitmap) {
    std::vector<std::string> data = {"alpha", "beta", "gamma"};
    auto index = BuildTantivyStringIndex(data);

    EXPECT_EQ(index->ValidityBitmapByteSize(), 0);
    auto valid = index->IsNotNull();
    ASSERT_EQ(valid.size(), data.size());
    EXPECT_EQ(valid.count(), data.size());
    auto nulls = index->IsNull();
    EXPECT_EQ(nulls.count(), 0);
}

// Verify all three matchers agree for a pattern against test data
void
VerifyPatternMatchConsistency(
    const std::string& pattern,
    const std::vector<std::string>& test_data,
    index::InvertedIndexTantivy<std::string>* tantivy_index,
    const std::string& test_category) {
    PatternMatchTranslator translator;
    auto regex_pattern = translator(pattern);

    RegexMatcher re2_matcher(regex_pattern);
    LikePatternMatcher like_matcher(pattern);
    auto tantivy_result =
        tantivy_index->PatternMatch(pattern, proto::plan::OpType::Match);

    for (size_t i = 0; i < test_data.size(); i++) {
        bool re2_result = re2_matcher(test_data[i]);
        bool like_result = like_matcher(test_data[i]);
        bool tantivy_bit = tantivy_result[i];

        EXPECT_EQ(re2_result, like_result)
            << test_category << " - RE2/LikePatternMatcher mismatch:\n"
            << "  pattern=\"" << pattern << "\"\n"
            << "  data=\"" << test_data[i] << "\" (len=" << test_data[i].size()
            << ")\n"
            << "  RE2=" << re2_result << ", Like=" << like_result;

        EXPECT_EQ(re2_result, tantivy_bit)
            << test_category << " - RE2/Tantivy mismatch:\n"
            << "  pattern=\"" << pattern << "\"\n"
            << "  data=\"" << test_data[i] << "\" (len=" << test_data[i].size()
            << ")\n"
            << "  RE2=" << re2_result << ", Tantivy=" << tantivy_bit;
    }
}

}  // namespace

// ============== Comprehensive Pattern Matching Consistency Test ==============
// This single test verifies consistency across ALL THREE execution paths:
// 1. RE2 regex (RegexMatcher) - sealed segments without index
// 2. LikePatternMatcher - growing data brute-force scan
// 3. Tantivy index - sealed segments with inverted index

TEST(PatternMatchConsistency, AllMatchersMustAgree) {
    // Comprehensive test data covering all scenarios
    std::vector<std::string> test_data = {
        // Basic strings
        "hello",
        "world",
        "hello world",
        "HELLO",
        "hello123",
        "123hello",
        "h3ll0",
        "test",
        "testing",
        "tested",
        "tester",
        "apple",
        "application",
        "apply",
        "banana",

        // Overlapping pattern test data
        "a",
        "aa",
        "aaa",
        "aaaa",
        "aaaaa",
        "aba",
        "abba",
        "aab",
        "baa",
        "abab",
        "ababab",
        "abc",
        "abcbc",
        "abcab",
        "xaax",
        "xaaax",
        "ab",
        "ba",

        // UTF-8 test data (2-byte, 3-byte, 4-byte)
        "café",                       // 2-byte UTF-8 (é)
        "\xE4\xBD\xA0\xE5\xA5\xBD",   // 你好 (3-byte UTF-8)
        "test\xE4\xBD\xA0test",       // Mixed ASCII and CJK
        "\xF0\x9F\x98\x80",           // 😀 (4-byte UTF-8)
        "emoji\xF0\x9F\x98\x80test",  // Mixed with emoji
        "a\xC3\xA9"
        "b",                 // aéb
        "\xC3\xA9\xC3\xA9",  // éé (consecutive 2-byte)
        "normal",

        // Special characters for escape tests
        "100%",
        "50%off",
        "file_name",
        "file_name.txt",
        "path\\to\\file",
        "%percent%",
        "_underscore_",
        "back\\slash",

        // Edge cases
        "",      // Empty string
        "   ",   // Whitespace
        "\t\n",  // Tab and newline
        "123",   // Numbers only
        "!@#$",  // Special chars
    };

    // Build Tantivy index with all test data
    auto tantivy_index = BuildTantivyStringIndex(test_data);

    // Comprehensive pattern list covering all scenarios
    std::vector<std::string> patterns = {
        // Basic patterns
        "hello",   // Exact match
        "hello%",  // Prefix match
        "%world",  // Suffix match
        "%llo%",   // Inner match
        "h_llo",   // Single char wildcard
        "h%o",     // Prefix + suffix with gap
        "%",       // Match all
        "test%",   // Prefix
        "%ing",    // Suffix
        "%est%",   // Inner

        // Overlapping patterns (key regression tests)
        "%aa%aa%",     // Two overlapping "aa"
        "%aa%aa%aa%",  // Three overlapping "aa"
        "%ab%ba%",     // Different overlapping segments
        "%ab%ab%",     // Same segment twice
        "%ab%ab%ab%",  // Same segment three times
        "a%aa",        // Prefix with repeated suffix
        "aa%a",        // Repeated prefix with suffix
        "%a%a%",       // Single char segments
        "%a%a%a%",     // Three single char segments
        "a%a",         // Simple overlapping

        // UTF-8 patterns
        "caf_",                // Underscore matches 2-byte UTF-8
        "%\xE4\xBD\xA0%",      // Contains 你
        "a_b",                 // Single UTF-8 char in middle
        "%\xF0\x9F\x98\x80%",  // Contains emoji
        "\xE4\xBD\xA0%",       // Starts with 你
        "%\xE5\xA5\xBD",       // Ends with 好

        // Escape sequences
        "100\\%",            // Literal %
        "%\\%",              // Ends with %
        "\\%%",              // Starts with %
        "file\\_name%",      // Literal _
        "%\\\\%",            // Contains backslash
        "\\%percent\\%",     // Literal % on both sides
        "\\_underscore\\_",  // Literal _ on both sides

        // Edge case patterns
        "_",    // Single char
        "__",   // Two chars
        "___",  // Three chars
        "%%",   // Multiple percent
        "_%",   // One char then anything
        "%_",   // Anything then one char
        "",     // Empty pattern
    };

    int total_tests = 0;
    int passed_tests = 0;

    for (const auto& pattern : patterns) {
        PatternMatchTranslator translator;
        auto regex_pattern = translator(pattern);

        RegexMatcher re2_matcher(regex_pattern);
        LikePatternMatcher like_matcher(pattern);
        auto tantivy_result =
            tantivy_index->PatternMatch(pattern, proto::plan::OpType::Match);

        for (size_t i = 0; i < test_data.size(); i++) {
            total_tests++;

            bool re2_result = re2_matcher(test_data[i]);
            bool like_result = like_matcher(test_data[i]);
            bool tantivy_bit = tantivy_result[i];

            // All three must agree
            bool all_agree =
                (re2_result == like_result) && (re2_result == tantivy_bit);

            if (all_agree) {
                passed_tests++;
            }

            EXPECT_EQ(re2_result, like_result)
                << "RE2/LikePatternMatcher MISMATCH:\n"
                << "  Pattern: \"" << pattern << "\"\n"
                << "  Data: \"" << test_data[i]
                << "\" (len=" << test_data[i].size() << ")\n"
                << "  RE2=" << re2_result << ", Like=" << like_result;

            EXPECT_EQ(re2_result, tantivy_bit)
                << "RE2/Tantivy MISMATCH:\n"
                << "  Pattern: \"" << pattern << "\"\n"
                << "  Data: \"" << test_data[i]
                << "\" (len=" << test_data[i].size() << ")\n"
                << "  RE2=" << re2_result << ", Tantivy=" << tantivy_bit;
        }
    }

    // Summary
    std::cout << "Pattern Match Consistency: " << passed_tests << "/"
              << total_tests << " tests passed across all three matchers\n";
}

// Test OpType-specific matching (PrefixMatch, PostfixMatch, InnerMatch)
TEST(PatternMatchConsistency, OpTypeMatchersMustAgree) {
    std::vector<std::string> test_data = {
        "hello",
        "hello world",
        "world hello",
        "say hello there",
        "helloworld",
        "worldhello",
        "HELLO",
        "Hello",
        "test",
        "testing",
        "pretest",
        "pretesting",
    };

    auto tantivy_index = BuildTantivyStringIndex(test_data);

    std::vector<std::string> search_terms = {"hello", "test", "world"};

    for (const auto& term : search_terms) {
        // Test PrefixMatch (equivalent to "term%")
        {
            std::string like_pattern = term + "%";
            PatternMatchTranslator translator;
            RegexMatcher re2_matcher(translator(like_pattern));
            LikePatternMatcher like_matcher(like_pattern);
            auto tantivy_result = tantivy_index->PatternMatch(
                term, proto::plan::OpType::PrefixMatch);

            for (size_t i = 0; i < test_data.size(); i++) {
                bool re2_result = re2_matcher(test_data[i]);
                bool like_result = like_matcher(test_data[i]);
                bool tantivy_bit = tantivy_result[i];

                EXPECT_EQ(re2_result, like_result)
                    << "PrefixMatch RE2/Like mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
                EXPECT_EQ(re2_result, tantivy_bit)
                    << "PrefixMatch RE2/Tantivy mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
            }
        }

        // Test PostfixMatch (equivalent to "%term")
        {
            std::string like_pattern = "%" + term;
            PatternMatchTranslator translator;
            RegexMatcher re2_matcher(translator(like_pattern));
            LikePatternMatcher like_matcher(like_pattern);
            auto tantivy_result = tantivy_index->PatternMatch(
                term, proto::plan::OpType::PostfixMatch);

            for (size_t i = 0; i < test_data.size(); i++) {
                bool re2_result = re2_matcher(test_data[i]);
                bool like_result = like_matcher(test_data[i]);
                bool tantivy_bit = tantivy_result[i];

                EXPECT_EQ(re2_result, like_result)
                    << "PostfixMatch RE2/Like mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
                EXPECT_EQ(re2_result, tantivy_bit)
                    << "PostfixMatch RE2/Tantivy mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
            }
        }

        // Test InnerMatch (equivalent to "%term%")
        {
            std::string like_pattern = "%" + term + "%";
            PatternMatchTranslator translator;
            RegexMatcher re2_matcher(translator(like_pattern));
            LikePatternMatcher like_matcher(like_pattern);
            auto tantivy_result = tantivy_index->PatternMatch(
                term, proto::plan::OpType::InnerMatch);

            for (size_t i = 0; i < test_data.size(); i++) {
                bool re2_result = re2_matcher(test_data[i]);
                bool like_result = like_matcher(test_data[i]);
                bool tantivy_bit = tantivy_result[i];

                EXPECT_EQ(re2_result, like_result)
                    << "InnerMatch RE2/Like mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
                EXPECT_EQ(re2_result, tantivy_bit)
                    << "InnerMatch RE2/Tantivy mismatch: term=\"" << term
                    << "\", data=\"" << test_data[i] << "\"";
            }
        }
    }
}

// Test special byte handling consistency (tabs, newlines, CRLF)
TEST(PatternMatchConsistency, SpecialByteHandling) {
    std::vector<std::string> test_data;

    test_data.push_back("helloworld");
    test_data.push_back("hello world");
    test_data.push_back("ab");
    test_data.push_back("a\tb");    // Tab character
    test_data.push_back("a\nb");    // Newline character
    test_data.push_back("a\r\nb");  // CRLF

    auto tantivy_index = BuildTantivyStringIndex(test_data);

    std::vector<std::string> patterns = {
        "hello%",
        "%world",
        "hello%world",
        "a%b",
        "a__b",
        "%",
    };

    for (const auto& pattern : patterns) {
        VerifyPatternMatchConsistency(
            pattern, test_data, tantivy_index.get(), "SpecialByte");
    }
}

// Test NUL byte (\x00) handling consistency across all three matchers.
// NUL is a valid UTF-8 character (U+0000) and must be handled correctly
// in data strings, patterns, and wildcard matching.
TEST(PatternMatchConsistency, NulByteHandling) {
    using namespace std::string_literals;

    std::vector<std::string> test_data;

    // Strings without NUL (for baseline comparison)
    test_data.push_back("ab");
    test_data.push_back("hello");
    test_data.push_back("");

    // Strings with embedded NUL bytes
    test_data.push_back("a\0b"s);     // NUL in middle
    test_data.push_back("\0hello"s);  // NUL at start
    test_data.push_back("hello\0"s);  // NUL at end
    test_data.push_back("a\0\0b"s);   // Double NUL
    test_data.push_back("\0"s);       // Just NUL
    test_data.push_back("\0\0"s);     // Two NULs
    test_data.push_back("a\0b\0c"s);  // Multiple NULs interleaved
    test_data.push_back("he\0llo"s);  // NUL inside word

    auto tantivy_index = BuildTantivyStringIndex(test_data);

    std::vector<std::string> patterns = {
        // Patterns that use % wildcard with NUL data
        "%",       // Match everything
        "a%b",     // Should match "a\0b"
        "a%",      // Should match "a\0b", "a\0\0b", "a\0b\0c"
        "%b",      // Should match "a\0b"
        "a%c",     // Should match "a\0b\0c"
        "hello%",  // Should match "hello\0"
        "%hello",  // Should match "\0hello"

        // Patterns that use _ wildcard (matches one UTF-8 char, including NUL)
        "a_b",     // _ should match NUL: "a\0b"
        "_hello",  // _ should match NUL: "\0hello"
        "hello_",  // _ should match NUL: "hello\0"
        "a__b",    // __ should match \0\0: "a\0\0b"
        "_",       // Should match single NUL: "\0"
        "__",      // Should match two NULs: "\0\0"

        // Exact match patterns (no wildcards)
        "ab",  // Should match "ab" but not "a\0b"

        // Patterns with NUL as literal character
        "a\0b"s,  // Exact match with NUL
        "a\0%"s,  // NUL in pattern followed by %
        "%\0b"s,  // % followed by NUL
        "\0%"s,   // NUL at start of pattern
        "%\0"s,   // NUL at end of pattern
        "%\0%"s,  // NUL surrounded by %
        "a\0_"s,  // NUL followed by _
    };

    for (const auto& pattern : patterns) {
        VerifyPatternMatchConsistency(
            pattern, test_data, tantivy_index.get(), "NulByte");
    }
}

// ============== Performance Benchmark: Tantivy Index vs Brute-Force ==============
// Compares query time for index-based vs brute-force pattern matching:
// - Tantivy inverted index: single PatternMatch() call returns bitset for ALL rows
// - RE2/Boost/LikePatternMatcher: iterate over each string individually
// Run with: --gtest_filter="*IndexBenchmark*"

namespace {

std::vector<std::string>
GenerateBenchStrings(size_t count, size_t avg_len, unsigned seed = 42) {
    std::mt19937 rng(seed);
    std::uniform_int_distribution<int> char_dist('a', 'z');
    std::uniform_int_distribution<int> len_dist(avg_len / 2, avg_len * 3 / 2);
    std::vector<std::string> result;
    result.reserve(count);
    for (size_t i = 0; i < count; i++) {
        size_t len = len_dist(rng);
        std::string s;
        s.reserve(len);
        for (size_t j = 0; j < len; j++) s += static_cast<char>(char_dist(rng));
        result.push_back(std::move(s));
    }
    return result;
}

struct BenchRes {
    double us;
    int64_t count;
};

template <typename Fn>
BenchRes
TimeBench(Fn&& fn, int warmup, int iters) {
    volatile int64_t total = 0;
    for (int w = 0; w < warmup; w++) total += fn();
    total = 0;
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iters; i++) total += fn();
    double us = std::chrono::duration<double, std::micro>(
                    std::chrono::high_resolution_clock::now() - t0)
                    .count() /
                iters;
    return {us, total / iters};
}

void
PrintRow(const std::string& name, double us, int64_t matches) {
    std::cout << "  " << std::left << std::setw(25) << name << std::right
              << std::setw(12) << std::fixed << std::setprecision(0) << us
              << " us" << std::setw(12) << matches << "\n";
}

void
PrintHeader(const std::string& title) {
    std::cout << "\n  " << title << "\n"
              << "  " << std::string(60, '-') << "\n"
              << std::left << "  " << std::setw(25) << "Matcher" << std::right
              << std::setw(15) << "total(us)" << std::setw(12) << "matches"
              << "\n"
              << "  " << std::string(60, '-') << "\n";
}

}  // namespace

// BoostRegexMatcher - used for benchmark comparison only
namespace {
inline std::string
adapt_regex_for_boost_utf8(const std::string& pattern) {
    static const std::string kUtf8OneChar =
        "(?:[\\x00-\\x7F]"
        "|[\\xC0-\\xDF][\\x80-\\xBF]"
        "|[\\xE0-\\xEF][\\x80-\\xBF]{2}"
        "|[\\xF0-\\xF7][\\x80-\\xBF]{3})";
    const std::string needle = "[\\s\\S]";
    std::string result;
    result.reserve(pattern.size() * 4);
    size_t pos = 0;
    while (pos < pattern.size()) {
        size_t found = pattern.find(needle, pos);
        if (found == std::string::npos) {
            result.append(pattern, pos, std::string::npos);
            break;
        }
        result.append(pattern, pos, found - pos);
        result.append(kUtf8OneChar);
        pos = found + needle.size();
    }
    return result;
}

struct BoostRegexMatcher {
    template <typename T>
    inline bool
    operator()(const T&) {
        return false;
    }
    explicit BoostRegexMatcher(const std::string& pattern) {
        r_ = boost::regex(adapt_regex_for_boost_utf8(pattern));
    }

 private:
    boost::regex r_;
};

template <>
inline bool
BoostRegexMatcher::operator()(const std::string& operand) {
    return boost::regex_match(operand, r_);
}
}  // namespace

TEST(IndexBenchmark, TantivyVsBruteForce) {
    const size_t N = 100000;
    auto data = GenerateBenchStrings(N, 50);
    auto tantivy_index = BuildTantivyStringIndex(data);

    std::vector<std::pair<std::string, std::string>> patterns = {
        {"prefix: abc%", "abc%"},
        {"suffix: %xyz", "%xyz"},
        {"inner: %hello%", "%hello%"},
        {"complex: %ab%cd%ef%", "%ab%cd%ef%"},
        {"exact: abcdefghij", "abcdefghij"},
        {"single-char: a_c_e_g", "a_c_e_g"},
        {"multi-seg: %a%b%c%d%", "%a%b%c%d%"},
        {"mixed: test%_abc%", "test%_abc%"},
    };

    std::cout << "\n====== Tantivy Index vs Brute-Force (" << N
              << " strings, avg 50 bytes) ======\n";

    PatternMatchTranslator translator;
    const int W = 3, I = 10;

    for (const auto& pc : patterns) {
        const auto& name = pc.first;
        const auto& pattern = pc.second;
        auto rp = translator(pattern);
        RegexMatcher re2(rp);
        BoostRegexMatcher boost(rp);
        LikePatternMatcher like(pattern);

        auto re2_r = TimeBench(
            [&]() {
                int64_t c = 0;
                for (const auto& s : data) c += re2(s) ? 1 : 0;
                return c;
            },
            W,
            I);
        auto boost_r = TimeBench(
            [&]() {
                int64_t c = 0;
                for (const auto& s : data) c += boost(s) ? 1 : 0;
                return c;
            },
            W,
            I);
        auto like_r = TimeBench(
            [&]() {
                int64_t c = 0;
                for (const auto& s : data) c += like(s) ? 1 : 0;
                return c;
            },
            W,
            I);
        auto tantivy_r = TimeBench(
            [&]() {
                auto r = tantivy_index->PatternMatch(
                    pattern, proto::plan::OpType::Match);
                return static_cast<int64_t>(r.count());
            },
            W,
            I);

        PrintHeader(name);
        PrintRow("RE2 (brute-force)", re2_r.us, re2_r.count);
        PrintRow("Boost (brute-force)", boost_r.us, boost_r.count);
        PrintRow("LikePatternMatcher", like_r.us, like_r.count);
        PrintRow("Tantivy (index)", tantivy_r.us, tantivy_r.count);
    }
}

TEST(IndexBenchmark, TantivyDataScaling) {
    PatternMatchTranslator translator;
    std::string pattern = "%abc%def%";
    auto rp = translator(pattern);

    std::vector<size_t> sizes = {1000, 10000, 100000};
    const int W = 3, I = 10;

    std::cout << "\n====== Data Size Scaling (pattern: %abc%def%) ======\n"
              << std::left << "  " << std::setw(10) << "N" << std::right
              << std::setw(15) << "RE2(us)" << std::setw(18) << "LikePat(us)"
              << std::setw(18) << "Tantivy(us)"
              << "\n"
              << "  " << std::string(60, '-') << "\n";

    for (size_t N : sizes) {
        auto data = GenerateBenchStrings(N, 50);
        auto ti = BuildTantivyStringIndex(data);
        RegexMatcher re2(rp);
        LikePatternMatcher like(pattern);

        auto re2_r = TimeBench(
            [&]() {
                int64_t c = 0;
                for (const auto& s : data) c += re2(s) ? 1 : 0;
                return c;
            },
            W,
            I);
        auto like_r = TimeBench(
            [&]() {
                int64_t c = 0;
                for (const auto& s : data) c += like(s) ? 1 : 0;
                return c;
            },
            W,
            I);
        auto tantivy_r = TimeBench(
            [&]() {
                auto r = ti->PatternMatch(pattern, proto::plan::OpType::Match);
                return static_cast<int64_t>(r.count());
            },
            W,
            I);

        std::cout << "  " << std::left << std::setw(10) << N << std::right
                  << std::setw(12) << std::fixed << std::setprecision(0)
                  << re2_r.us << " us" << std::setw(15) << like_r.us << " us"
                  << std::setw(15) << tantivy_r.us << " us"
                  << "\n";
    }
}

// ============== PostfixMatch/InnerMatch Escaping Bug Test ==============
// Verifies that PostfixMatch and InnerMatch correctly handle patterns
// containing LIKE metacharacters (% and _).
// When the pattern itself contains % or _, those should be treated as
// literal characters, not as LIKE wildcards.

TEST(PatternMatchEscaping, PostfixMatchWithMetacharacters) {
    // Test data: some strings end with literal "%a", others just end with "a"
    std::vector<std::string> test_data = {
        "hello%a",  // ends with "%a" — should match
        "100%a",    // ends with "%a" — should match
        "helloa",   // ends with "a" but NOT "%a" — should NOT match
        "banana",   // ends with "a" but NOT "%a" — should NOT match
        "xyz",      // no match
        "%a",       // exact "%a" — should match
    };

    auto tantivy_index = BuildTantivyStringIndex(test_data);

    // PostfixMatch with pattern "%a" — should find strings ending with literal "%a"
    auto result =
        tantivy_index->PatternMatch("%a", proto::plan::OpType::PostfixMatch);

    // Expected: indices 0,1,5 match (strings ending with literal "%a")
    // If the bug exists, indices 2,3 will also match (anything ending with "a")
    EXPECT_TRUE(result[0]) << "hello%a should match PostfixMatch('%a')";
    EXPECT_TRUE(result[1]) << "100%a should match PostfixMatch('%a')";
    EXPECT_FALSE(result[2]) << "helloa should NOT match PostfixMatch('%a') — "
                               "% in pattern must be literal, not wildcard";
    EXPECT_FALSE(result[3]) << "banana should NOT match PostfixMatch('%a') — "
                               "% in pattern must be literal, not wildcard";
    EXPECT_FALSE(result[4]) << "xyz should not match";
    EXPECT_TRUE(result[5]) << "%a should match PostfixMatch('%a')";
}

TEST(PatternMatchEscaping, InnerMatchWithMetacharacters) {
    std::vector<std::string> test_data = {
        "hello_world",  // contains literal "_" — should match
        "test_case",    // contains literal "_" — should match
        "helloXworld",  // does NOT contain "_" — should NOT match
        "no match",     // no match
        "_",            // exact "_" — should match
    };

    auto tantivy_index = BuildTantivyStringIndex(test_data);

    // InnerMatch with pattern "_" — should find strings containing literal "_"
    auto result =
        tantivy_index->PatternMatch("_", proto::plan::OpType::InnerMatch);

    EXPECT_TRUE(result[0]) << "hello_world should match InnerMatch('_')";
    EXPECT_TRUE(result[1]) << "test_case should match InnerMatch('_')";
    EXPECT_FALSE(result[2]) << "helloXworld should NOT match InnerMatch('_') — "
                               "_ in pattern must be literal, not wildcard";
    EXPECT_FALSE(result[3]) << "no match should not match";
    EXPECT_TRUE(result[4]) << "_ should match InnerMatch('_')";
}
