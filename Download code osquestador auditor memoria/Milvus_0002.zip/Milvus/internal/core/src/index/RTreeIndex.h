// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once

#include <folly/SharedMutex.h>
#include <stdint.h>
#include <algorithm>
#include <cstddef>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <shared_mutex>
#include <string>
#include <vector>

#include "common/EasyAssert.h"
#include "common/FieldData.h"
#include "common/Geometry.h"
#include "common/Tracer.h"
#include "common/Types.h"
#include "common/protobuf_utils.h"
#include "index/IndexStats.h"
#include "index/Meta.h"
#include "index/RTreeIndexWrapper.h"
#include "index/ScalarIndex.h"
#include "pb/plan.pb.h"
#include "pb/schema.pb.h"
#include "storage/DiskFileManagerImpl.h"
#include "storage/FileManager.h"
#include "storage/MemFileManagerImpl.h"

namespace milvus::index {

using RTreeIndexWrapper = milvus::index::RTreeIndexWrapper;

template <typename T>
class RTreeIndex : public ScalarIndex<T> {
 public:
    using MemFileManager = storage::MemFileManagerImpl;
    using MemFileManagerPtr = std::shared_ptr<MemFileManager>;
    using DiskFileManager = storage::DiskFileManagerImpl;
    using DiskFileManagerPtr = std::shared_ptr<DiskFileManager>;

    RTreeIndex() : ScalarIndex<T>(RTREE_INDEX_TYPE) {
    }

    explicit RTreeIndex(
        const storage::FileManagerContext& ctx = storage::FileManagerContext());

    ~RTreeIndex();

    void
    InitForBuildIndex(bool is_growing);

    void
    Load(milvus::tracer::TraceContext ctx, const Config& config = {}) override;

    // Load index from an already assembled BinarySet (not used by RTree yet)
    void
    Load(const BinarySet& binary_set, const Config& config = {}) override;

    ScalarIndexType
    GetIndexType() const override {
        return ScalarIndexType::RTREE;
    }

    void
    Build(const Config& config = {}) override;

    // Build index directly from in-memory value array (required by ScalarIndex)
    void
    Build(size_t n, const T* values, const bool* valid_data = nullptr) override;

    int64_t
    Count() override {
        // On a growing segment AddGeometry() mutates null_offset_ and publishes
        // wrapper_ under mutex_, concurrently with searches calling Count(); take
        // the shared lock and snapshot wrapper_ before dereferencing it.
        std::shared_ptr<RTreeIndexWrapper> wrapper;
        int64_t null_count = 0;
        int64_t total_num_rows = 0;
        {
            std::shared_lock<folly::SharedMutexWritePriority> lock(mutex_);
            if (is_built_) {
                return total_num_rows_;
            }
            wrapper = wrapper_;
            null_count = static_cast<int64_t>(null_offset_.size());
            total_num_rows = total_num_rows_;
        }
        // Callers size row-addressed bitmaps by Count() (see Query()), so it
        // must report the row space, not how many rows happen to be indexed.
        // AddGeometry() is offset-addressed and keeps total_num_rows_ at
        // max(row_offset) + 1, so with sparse or out-of-order offsets it
        // outgrows wrapper->count() + nulls -- returning the smaller value
        // would make Query() clip live candidates. Keep the max so neither
        // counter can under-report.
        auto indexed_count =
            wrapper ? wrapper->count() + null_count : null_count;
        return std::max(total_num_rows, indexed_count);
    }

    // BuildWithRawDataForUT should be only used in ut. Only string is supported.
    void
    BuildWithRawDataForUT(size_t n,
                          const void* values,
                          const Config& config = {}) override;

    // Build index with string data (WKB format) for growing segment
    void
    BuildWithStrings(const std::vector<std::string>& geometries);

    // Add single geometry incrementally (for growing segment).
    //
    // `is_valid` is the row's nullability from the caller's valid_data and is
    // the ONLY signal that classifies the row as NULL: a valid row whose WKB
    // payload is empty or unparseable is indexed with a placeholder MBR (like
    // the sealed bulk_load path, which also checks is_valid first), NOT pushed
    // into null_offset_. Inferring nullness from wkb_data.empty() would make
    // ST_ISNOTNULL / Count() disagree between growing and sealed for such a
    // row.
    void
    AddGeometry(const std::string& wkb_data, int64_t row_offset, bool is_valid);

    BinarySet
    Serialize(const Config& config) override;

    IndexStatsPtr
    Upload(const Config& config = {}) override;

    const TargetBitmap
    In(size_t n, const T* values) override;

    const TargetBitmap
    IsNull() override;

    TargetBitmap
    IsNotNull() override;

    // Build validity in the caller's absolute row space. Legacy R-Tree files
    // can contain null offsets beyond Count() when older builders dropped
    // non-null empty/corrupt geometries, so sizing only by Count() loses those
    // tail NULLs.
    TargetBitmap
    IsNotNull(int64_t row_count) override;

    const TargetBitmap
    InApplyFilter(
        size_t n,
        const T* values,
        const std::function<bool(size_t /* offset */)>& filter) override;

    void
    InApplyCallback(
        size_t n,
        const T* values,
        const std::function<void(size_t /* offset */)>& callback) override;

    const TargetBitmap
    NotIn(size_t n, const T* values) override;

    const TargetBitmap
    Range(const T& value, OpType op) override;

    const TargetBitmap
    Range(const T& lower_bound_value,
          bool lb_inclusive,
          const T& upper_bound_value,
          bool ub_inclusive) override;

    const bool
    HasRawData() const override {
        return false;
    }

    std::optional<T>
    Reverse_Lookup(size_t offset) const override {
        ThrowInfo(ErrorCode::NotImplemented,
                  "Reverse_Lookup should not be handled by R-Tree index");
    }

    int64_t
    Size() override {
        return Count();
    }

    void
    ComputeByteSize() override {
        ScalarIndex<T>::ComputeByteSize();
        int64_t total = this->cached_byte_size_;

        std::shared_ptr<RTreeIndexWrapper> wrapper;
        {
            std::shared_lock<folly::SharedMutexWritePriority> lock(mutex_);
            // null_offset_ vector
            total += null_offset_.capacity() * sizeof(size_t);
            wrapper = wrapper_;
        }

        // wrapper_ (RTreeIndexWrapper)
        if (wrapper) {
            total += wrapper->ByteSize();
        }

        this->cached_byte_size_ = total;
    }

    // GIS-specific query methods
    /**
     * @brief Query candidates based on spatial operation
     * @param op Spatial operation type
     * @param query_geom Query geometry in WKB format
     * @param candidate_offsets Output vector of candidate row offsets
     */
    // Takes the query geometry by reference: by value it deep-cloned the whole
    // GEOS geometry on every call (once per query per segment), and each clone
    // is an allocation that can fail under memory pressure. The callee only
    // reads it.
    void
    QueryCandidates(proto::plan::GISFunctionFilterExpr_GISOp op,
                    const Geometry& query_geometry,
                    std::vector<int64_t>& candidate_offsets);

    const TargetBitmap
    Query(const DatasetPtr& dataset) override;

    void
    BuildWithFieldData(const std::vector<FieldDataPtr>& datas) override;

    void
    WriteEntries(storage::IndexEntryWriter* writer) override;

    void
    LoadEntries(storage::IndexEntryReader& reader,
                const Config& config) override;

 protected:
    void
    finish();

    std::shared_ptr<RTreeIndexWrapper> wrapper_;
    std::string path_;
    proto::schema::FieldSchema schema_;

    MemFileManagerPtr mem_file_manager_;
    DiskFileManagerPtr disk_file_manager_;

    // Index state
    bool is_built_ = false;
    int64_t total_num_rows_ = 0;

    // Track null rows to support IsNull/IsNotNull just like other scalar indexes
    folly::SharedMutexWritePriority mutex_{};
    std::vector<size_t> null_offset_;
};
}  // namespace milvus::index
