// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#include <fmt/core.h>
#include <gtest/gtest.h>

#include <array>
#include <cstring>
#include <filesystem>
#include <functional>
#include <map>
#include <memory>
#include <random>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>

#include "common/Consts.h"
#include "common/FieldData.h"
#include "common/RegexQuery.h"
#include "common/Schema.h"
#include "common/Types.h"
#include "exec/QueryContext.h"
#include "exec/expression/Expr.h"
#include "exec/expression/ExprBatchTestUtils.h"
#include "expr/ITypeExpr.h"
#include "index/FMIndex.h"
#include "index/IndexInfo.h"
#include "index/Meta.h"
#include "common/type_c.h"
#include "pb/common.pb.h"
#include "pb/plan.pb.h"
#include "pb/schema.pb.h"
#include "plan/PlanNode.h"
#include "query/ExecPlanNodeVisitor.h"
#include "query/PlanProto.h"
#include "segcore/SegmentSealed.h"
#include "segcore/Types.h"
#include "segcore/load_index_c.h"
#include "storage/FileManager.h"
#include "storage/InsertData.h"
#include "storage/PayloadReader.h"
#include "storage/RemoteChunkManagerSingleton.h"
#include "storage/Types.h"
#include "storage/Util.h"
#include "test_utils/Constants.h"
#include "test_utils/DataGen.h"
#include "test_utils/GenExprProto.h"
#include "test_utils/storage_test_utils.h"

using namespace milvus;

namespace {

// Collect the set-bit positions of a bitmap into a sorted vector, for readable
// equality assertions against an expected id list.
std::vector<int64_t>
SetBits(const TargetBitmap& bitmap) {
    std::vector<int64_t> out;
    for (size_t i = 0; i < bitmap.size(); i++) {
        if (bitmap[i]) {
            out.push_back(static_cast<int64_t>(i));
        }
    }
    return out;
}

// Build an in-memory FM index over `data` via the unit-test path (no storage),
// which is enough to exercise the query routing (prefix/infix/suffix, In/NotIn).
std::unique_ptr<index::FMIndex>
MakeRawDataIndex(const std::vector<std::string>& data) {
    index::FMIndexParams params{.sa_sample_rate = 32};
    auto idx =
        std::make_unique<index::FMIndex>(storage::FileManagerContext(), params);
    idx->BuildWithRawDataForUT(data.size(), data.data());
    return idx;
}

// TargetBitmap's copy ctor is deleted, so these return the set-bit id list
// directly (binding the returned bitmap by const ref, never copying it).
std::vector<int64_t>
Prefix(index::FMIndex* idx, const std::string& p) {
    const auto& bm = idx->PatternMatch(p, proto::plan::OpType::PrefixMatch);
    return SetBits(bm);
}
std::vector<int64_t>
Suffix(index::FMIndex* idx, const std::string& p) {
    const auto& bm = idx->PatternMatch(p, proto::plan::OpType::PostfixMatch);
    return SetBits(bm);
}
std::vector<int64_t>
Inner(index::FMIndex* idx, const std::string& p) {
    const auto& bm = idx->PatternMatch(p, proto::plan::OpType::InnerMatch);
    return SetBits(bm);
}
std::vector<int64_t>
Match(index::FMIndex* idx, const std::string& p) {
    const auto& bm = idx->PatternMatch(p, proto::plan::OpType::Match);
    return SetBits(bm);
}

// PatternMatch(Match) returns rarest-fragment candidates. Exactness is the
// intersection with LikePatternMatcher on the original strings, the same
// recheck ExecFMMatch performs on sealed VARCHAR.
std::vector<int64_t>
RecheckedMatch(index::FMIndex* idx,
               const std::vector<std::string>& data,
               const std::string& p) {
    LikePatternMatcher matcher(p);
    auto candidates = Match(idx, p);
    std::vector<int64_t> got;
    got.reserve(candidates.size());
    size_t ci = 0;
    for (size_t i = 0; i < data.size(); ++i) {
        const bool hit = matcher(data[i]);
        const bool cand =
            ci < candidates.size() && candidates[ci] == static_cast<int64_t>(i);
        if (cand) {
            ++ci;
            if (hit) {
                got.push_back(static_cast<int64_t>(i));
            }
        } else {
            EXPECT_FALSE(hit)
                << "candidate miss pattern=[" << p << "] row " << i;
        }
    }
    return got;
}

}  // namespace

// ---- query routing over raw data (no storage) ----

TEST(FMIndex, PrefixInfixSuffixRouting) {
    // idx:   0        1        2         3        4              5      6
    std::vector<std::string> data{
        "apple", "apply", "banana", "grape", "application", "app", ""};
    auto idx = MakeRawDataIndex(data);

    EXPECT_EQ(idx->Count(), 7);

    // prefix "app": apple, apply, application, app (not "" / banana / grape)
    EXPECT_EQ(Prefix(idx.get(), "app"), (std::vector<int64_t>{0, 1, 4, 5}));
    // suffix "e": apple, grape
    EXPECT_EQ(Suffix(idx.get(), "e"), (std::vector<int64_t>{0, 3}));
    // infix "pp": apple, apply, application, app
    EXPECT_EQ(Inner(idx.get(), "pp"), (std::vector<int64_t>{0, 1, 4, 5}));
    // infix "an": only banana
    EXPECT_EQ(Inner(idx.get(), "an"), (std::vector<int64_t>{2}));
    // infix that matches nothing
    EXPECT_TRUE(Inner(idx.get(), "xyz").empty());
}

// `LIKE '%'` lowers to an anchored op with an EMPTY literal (PrefixMatch("") /
// InnerMatch("") / PostfixMatch("")). Every string has "" as a prefix, substring
// and suffix, so all (non-null) rows must match — the FM library short-circuits
// an empty needle to zero hits, and PatternMatch must not let that leak through
// as an empty result.
TEST(FMIndex, EmptyPatternMatchesAllRows) {
    std::vector<std::string> data{
        "apple", "apply", "banana", "grape", "application", "app", ""};
    auto idx = MakeRawDataIndex(data);

    std::vector<int64_t> all{0, 1, 2, 3, 4, 5, 6};
    EXPECT_EQ(Prefix(idx.get(), ""), all);
    EXPECT_EQ(Suffix(idx.get(), ""), all);
    EXPECT_EQ(Inner(idx.get(), ""), all);
}

// ShouldUseOp is the executor's routing gate (UnaryIndexFunc): true routes the
// op to this index, false downgrades to the raw-data scan. Range ops MUST be
// declined. Range() throws Unsupported, so routing them here would fail the
// query (`field > "x"`, BETWEEN) instead of scanning. RegexMatch stays declined
// (required-literal extraction is a later follow-up). Equal/NotEqual (== and
// IN/NOT IN) are intentionally declined too: a set of exact values is served
// better by the raw-data scan or an equality-oriented index (INVERTED), not by
// FMINDEX's prefix enumeration. General LIKE (Match) is on the allowlist.
TEST(FMIndex, ShouldUseOpDeclinesRangeAndRegex) {
    auto idx = MakeRawDataIndex({"apple", "banana"});

    // The allowlist is the three anchored pattern ops plus general LIKE.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PrefixMatch));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PostfixMatch));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch));
    // Match is on the allowlist, but unlike the anchored ops it is never
    // accepted without a literal fragment: a zero-occurrence fragment proves
    // the op itself is routed here, while the empty pattern declines because
    // there is nothing to seed phase 1 with.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%ZZZ%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, ""));

    // Equality family declines. Routed to the scan / an equality index.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Equal));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::NotEqual));

    // Everything else declines (falls back to the raw-data scan). Wrongly
    // accepting would route into Range() overloads that throw.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::GreaterThan));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::GreaterEqual));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::LessThan));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::LessEqual));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::RegexMatch));

    EXPECT_THROW(idx->Range("m", OpType::GreaterThan), SegcoreError);
    EXPECT_EQ(RecheckedMatch(idx.get(), {"apple", "banana"}, "a%e"),
              (std::vector<int64_t>{0}));
}

// Count-first guard, folded into ShouldUseOp(op, pattern): for the anchored
// pattern ops with a literal in hand, accelerate iff occ x sa_sample_rate <
// fmindexCostRatio x total_tokens (default 0.001). With 1000 rows x
// ~500 B (~500k tokens) and the test helper's sa_sample_rate = 32, the
// decline threshold is occ >= 500k x 0.001 / 32 ~= 15.6 occurrences.
TEST(FMIndex, CountFirstGuardDeclinesHighHitPatterns) {
    std::vector<std::string> data;
    std::string filler(500, 'x');  // marker letters never occur in the filler
    data.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        std::string row = filler;
        if (i % 200 == 0) {
            row += "RARE";  // 5 rows -> occ 5, well under the threshold
        }
        if (i % 2 == 0) {
            row += "COMMON";  // 500 rows -> occ 500, well over
        }
        data.push_back(std::move(row));
    }
    auto idx = MakeRawDataIndex(data);

    // Low-hit pattern: index wins, guard accelerates.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "RARE"));
    // High-hit pattern (50% of rows): enumeration loses to the scan, decline.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "COMMON"));
    // Degenerate single-char pattern (~500k occurrences): decline.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "x"));
    // Absent pattern: occ = 0, cheapest possible index answer — accelerate.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "QQQQ"));
    // Empty literal (LIKE '%', or a caller without literal information):
    // always accelerate. Answered by an O(rows) bitmap clone.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PrefixMatch, ""));
    // General LIKE: occ 0 still accelerates. Locate-only: %RARE% (5 hits x
    // sa_sample_rate 32 = 160 < 0.001 x ~500k tokens) accepts. High-hit
    // fragments and patterns with no literal fragment decline.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%QQQQ%"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%RARE%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%COMMON%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%x%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%_%"));
    // Anchored variants count docs, not occurrences.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::PrefixMatch,
                                  "x"));  // every row starts with x
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PostfixMatch, "RARE"));
    // Equal/NotEqual always decline regardless of literal — the equality family
    // is not routed to FMINDEX (In/NotIn falls back to scan / equality index).
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Equal, "COMMON"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::NotEqual, "RARE"));
}

// POSITIVE accelerated path: on a large, low-hit corpus the count-first guard
// ACCEPTS the pattern (unlike the tiny-corpus executor test, where a 50-byte scan
// always beats enumeration so every non-empty pattern declines). This pins that
// the guard-accepted branch actually runs the FM backward search and returns the
// exact, NON-EMPTY matching rows — the leg no small-corpus test can reach. Two
// rare markers keep every anchored op demonstrable: "ZEBRA" is appended (suffix
// + infix) to rows 0/250/500/750, "QOP" is prepended (prefix + infix) to rows
// 100/350/600/850. 1000 rows x ~500 B (~500k tokens), helper sa_sample_rate = 32:
// occ 4 gives 4 x 32 = 128 < 0.001 x 500k ~= 500, so each marker accelerates.
TEST(FMIndex, CountFirstGuardAcceleratesLowHitAndMatchesAreExact) {
    std::vector<std::string> data;
    std::string filler(500, 'y');  // markers never occur in the filler
    data.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        std::string row = filler;
        if (i % 250 == 0) {
            row += "ZEBRA";  // rows 0/250/500/750: suffix + infix marker
        }
        if (i >= 100 && (i - 100) % 250 == 0) {
            row = "QOP" + row;  // rows 100/350/600/850: prefix + infix marker
        }
        data.push_back(std::move(row));
    }
    auto idx = MakeRawDataIndex(data);
    std::vector<int64_t> zebra{0, 250, 500, 750};
    std::vector<int64_t> qop{100, 350, 600, 850};

    // Guard ACCEPTS each low-hit marker for its anchored ops...
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "ZEBRA"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PostfixMatch, "ZEBRA"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PrefixMatch, "QOP"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "QOP"));

    // ...and the accelerated FM query returns exactly the marked rows.
    EXPECT_EQ(Inner(idx.get(), "ZEBRA"), zebra);  // infix: ...yZEBRA
    EXPECT_EQ(Suffix(idx.get(), "ZEBRA"),
              zebra);                          // suffix: rows end with ZEBRA
    EXPECT_EQ(Prefix(idx.get(), "QOP"), qop);  // prefix: rows start with QOP
    EXPECT_EQ(Inner(idx.get(), "QOP"), qop);   // infix: QOPyyy...

    // A marker absent from the corpus still accelerates (occ 0) and yields none.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "QUOKKA"));
    EXPECT_TRUE(Inner(idx.get(), "QUOKKA").empty());

    // Locate-only Match accepts the same rare markers. PatternMatch returns
    // candidates; RecheckedMatch is the VARCHAR recheck.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%ZEBRA%"));
    EXPECT_EQ(RecheckedMatch(idx.get(), data, "%ZEBRA%"), zebra);
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "QOP%ZEBRA"));
    EXPECT_TRUE(RecheckedMatch(idx.get(), data, "QOP%ZEBRA").empty());
}

// Degenerate corpus: every non-null row is the empty string, so
// ComputeTotalTokens() ((bwt_size - 1) - total_rows) yields 0 total tokens.
// The count-first guard compares occ x sa_sample_rate < ratio x total_tokens;
// with a zero right-hand side a strict `<` can never hold, so without the
// occ == 0 short-circuit EVERY non-empty pattern would decline and the segment
// would be handed to a row-by-row scan that can only ever return nothing.
// occ == 0 is the cheapest answer the index has (O(|pattern|) backward search,
// no locate), so it must accelerate no matter how few tokens the segment holds.
TEST(FMIndex, CountFirstGuardAcceleratesZeroHitOnZeroTokenSegment) {
    std::vector<std::string> data(8, "");
    auto idx = MakeRawDataIndex(data);
    EXPECT_EQ(idx->Count(), 8);

    // No pattern can occur, so every anchored op must still route to the index.
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PrefixMatch, "abc"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::PostfixMatch, "abc"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "abc"));

    // ...and answering through it is exact: no row matches a non-empty pattern.
    EXPECT_TRUE(Prefix(idx.get(), "abc").empty());
    EXPECT_TRUE(Suffix(idx.get(), "abc").empty());
    EXPECT_TRUE(Inner(idx.get(), "abc").empty());

    // The empty literal (LIKE '%') still matches all rows — "" is a prefix,
    // suffix and substring of "" — and is unaffected by the short-circuit.
    std::vector<int64_t> all{0, 1, 2, 3, 4, 5, 6, 7};
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, ""));
    EXPECT_EQ(Inner(idx.get(), ""), all);

    // Declined ops are still declined. The short-circuit only relaxes the cost
    // model for the three anchored ops and for Match when a fragment has occ 0.
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Equal, "abc"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "abc"));
    EXPECT_TRUE(RecheckedMatch(idx.get(), data, "abc").empty());
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%_%"));
}

// Library-level: a LoadView'd (zero-copy) index must answer doc queries with
// nothing but the mapped bytes, and Extract — the only consumer of the lazily
// built ISA table — must still work after the view-load (first call builds it).
TEST(FMIndex, LibraryLoadViewZeroCopyAndLazyExtract) {
    std::vector<std::string> data{"apple", "banana", "grape"};
    std::vector<std::string_view> docs(data.begin(), data.end());
    index::fmindex::FMIndex built;
    built.Build(docs, /*sa_sample_rate=*/4);
    std::string blob = built.Serialize();

    // LoadView requires 8-byte alignment; std::string does not guarantee it.
    std::vector<uint64_t> aligned((blob.size() + 7) / 8);
    std::memcpy(aligned.data(), blob.data(), blob.size());
    auto viewed = index::fmindex::FMIndex::LoadView(
        reinterpret_cast<const uint8_t*>(aligned.data()), blob.size());
    ASSERT_TRUE(viewed.valid());
    EXPECT_EQ(viewed.document_count(), docs.size());

    auto p = [](const char* s) { return reinterpret_cast<const uint8_t*>(s); };
    EXPECT_EQ(viewed.MatchingDocs(p("an"), 2), (std::vector<uint64_t>{1}));
    EXPECT_EQ(viewed.CountPrefixDocs(p("gr"), 2), 1u);
    // Extract triggers the lazy ISA build on the viewed index.
    const auto heap_before_extract = viewed.resident_heap_bytes();
    EXPECT_EQ(viewed.Extract(0, 0, 5), "apple");
    EXPECT_EQ(viewed.Extract(1, 2, 4), "nana");
    EXPECT_GT(viewed.resident_heap_bytes(), heap_before_extract);
    // Round-trip: re-serializing the viewed index reproduces the blob.
    EXPECT_EQ(viewed.Serialize(), blob);
}

// LoadView keeps the serialized payload in the caller-owned mapping and only
// retains rebuilt rank directories plus small metadata on the heap. The
// resident accounting must reflect that distinction, and it must follow the
// persisted block granularity because that controls wavelet-directory size.
TEST(FMIndex, LibraryResidentHeapAccountingForLoadView) {
    std::vector<std::string> data;
    data.reserve(512);
    for (size_t i = 0; i < 512; ++i) {
        std::string row(512, static_cast<char>('a' + i % 26));
        for (size_t j = 0; j < row.size(); j += 31) {
            row[j] = static_cast<char>((i + j) & 0xFF);
        }
        data.push_back(std::move(row));
    }
    std::vector<std::string_view> docs(data.begin(), data.end());

    auto load_view = [&](uint32_t block_bytes) {
        index::fmindex::FMIndex built;
        built.Build(docs,
                    /*sa_sample_rate=*/8,
                    /*case_insensitive=*/false,
                    /*force_wide=*/false,
                    block_bytes);
        std::string blob = built.Serialize();
        std::vector<uint64_t> aligned((blob.size() + 7) / 8);
        std::memcpy(aligned.data(), blob.data(), blob.size());
        auto viewed = index::fmindex::FMIndex::LoadView(
            reinterpret_cast<const uint8_t*>(aligned.data()), blob.size());
        EXPECT_TRUE(viewed.valid());
        return std::make_tuple(
            std::move(viewed), std::move(blob), std::move(aligned));
    };

    auto [fine, fine_blob, fine_backing] = load_view(/*block_bytes=*/8);
    auto [coarse, coarse_blob, coarse_backing] = load_view(/*block_bytes=*/128);
    ASSERT_TRUE(fine.valid());
    ASSERT_TRUE(coarse.valid());

    EXPECT_GT(fine.rank_directory_bytes(), coarse.rank_directory_bytes());
    EXPECT_GT(fine.resident_heap_bytes(), coarse.resident_heap_bytes());
    // The mapped payload is disk accounting, not heap accounting. With coarse
    // directories, the heap retained by LoadView is only a small fraction of
    // the serialized blob rather than the previous full-blob estimate.
    EXPECT_LT(coarse.resident_heap_bytes(), coarse_blob.size());

    auto owned = index::fmindex::FMIndex::Deserialize(coarse_blob);
    ASSERT_TRUE(owned.valid());
    EXPECT_GE(owned.resident_heap_bytes(),
              coarse.resident_heap_bytes() + coarse_blob.size());
}

TEST(FMIndex, LibraryRejectsCorruptHeaderMetadata) {
    index::fmindex::FMIndex built;
    std::vector<std::string_view> docs{"alpha", "beta", "gamma"};
    built.Build(docs, /*sa_sample_rate=*/4);
    std::string blob = built.Serialize();

    // Header layout starts with magic (4), format version (4), sample rate (4).
    // A zero rate would divide by zero in locate/extract; a different non-zero
    // rate no longer matches the persisted sample count/positions. Both must be
    // rejected as structural corruption rather than accepted with wrong answers.
    uint32_t corrupt_rate = 0;
    std::memcpy(blob.data() + 8, &corrupt_rate, sizeof(corrupt_rate));
    EXPECT_FALSE(index::fmindex::FMIndex::Deserialize(blob).valid());

    blob = built.Serialize();
    corrupt_rate = 16;
    std::memcpy(blob.data() + 8, &corrupt_rate, sizeof(corrupt_rate));
    EXPECT_FALSE(index::fmindex::FMIndex::Deserialize(blob).valid());

    // text_len is the uint64 immediately after six uint32 header fields.
    // Build rejects corpora >= 2^63; load must reject the same domain before
    // any size-derived allocation instead of misclassifying corruption as OOM.
    blob = built.Serialize();
    uint64_t corrupt_text_len = uint64_t{1} << 63;
    std::memcpy(blob.data() + 24, &corrupt_text_len, sizeof(corrupt_text_len));
    EXPECT_FALSE(index::fmindex::FMIndex::Deserialize(blob).valid());
}

// Load-time validation constrains the sampled-SA array only element-wise (range
// + divisibility) and by count; it cannot tie a sampled value to the row it was
// sampled from, because that would need the suffix array the sampling exists to
// avoid. So a blob can load cleanly and still drive locateRow past text_len_,
// at which point docOf saturates at document_count() — one past the last valid
// document id. The two document-anchored locate paths must bound-check like the
// other four call sites do, or that id escapes into DocsToBitmap's
// TargetBitmap(total_rows_) and, when total_rows_ % 64 == 0, writes past the
// allocation (its own range check is an assert, gone under NDEBUG).
TEST(FMIndex, LibraryDocLocateBoundsOutOfRangePositions) {
    std::vector<std::string> data{"alpha", "beta", "gamma", "delta"};
    std::vector<std::string_view> docs(data.begin(), data.end());
    index::fmindex::FMIndex built;
    // Sample rate 1 makes every row sampled, so locateRow returns a stored
    // sample value with zero LF steps — the tampered value reaches the call
    // sites verbatim. force_wide pins samples to 8 bytes so the trailing
    // sections are exactly sized with no alignment padding between them.
    built.Build(docs,
                /*sa_sample_rate=*/1,
                /*case_insensitive=*/false,
                /*force_wide=*/true);
    const std::string clean = built.Serialize();

    size_t text_len = docs.size();  // one separator per document
    for (const auto& d : docs) {
        text_len += d.size();
    }
    // Trailing payload sections: sampled-SA values (n_samples * 8) then the
    // document boundaries (n_docs * 8).
    const size_t n_samples = text_len + 1;  // rate 1: text_len/1 + 1
    const size_t n_docs = docs.size() + 1;  // boundaries, not documents
    ASSERT_GT(clean.size(), (n_samples + n_docs) * sizeof(uint64_t));
    const size_t docs_off = clean.size() - n_docs * sizeof(uint64_t);
    const size_t samples_off = docs_off - n_samples * sizeof(uint64_t);

    // Pin the assumed layout before poking at it: the boundary list runs
    // 0 .. text_len. If serialization ever moves these sections, this fails
    // loudly here instead of silently tampering with unrelated bytes.
    auto read_u64 = [&clean](size_t off) {
        uint64_t v = 0;
        std::memcpy(&v, clean.data() + off, sizeof(v));
        return v;
    };
    ASSERT_EQ(read_u64(docs_off), 0u);
    ASSERT_EQ(read_u64(clean.size() - sizeof(uint64_t)), text_len);

    auto p = [](const char* s) { return reinterpret_cast<const uint8_t*>(s); };
    auto load_view = [](const std::string& blob) {
        std::vector<uint64_t> backing((blob.size() + 7) / 8);
        std::memcpy(backing.data(), blob.data(), blob.size());
        auto idx = index::fmindex::FMIndex::LoadView(
            reinterpret_cast<const uint8_t*>(backing.data()), blob.size());
        return std::make_pair(std::move(idx), std::move(backing));
    };

    // Baseline: the guards must not reject anything on a well-formed index.
    {
        auto [ok, backing] = load_view(clean);
        ASSERT_TRUE(ok.valid());
        EXPECT_EQ(ok.LocatePrefixDocs(p("gam"), 3), (std::vector<uint64_t>{2}));
        EXPECT_EQ(ok.LocateSuffixDocs(p("lta"), 3), (std::vector<uint64_t>{3}));
        EXPECT_EQ(ok.LocatePrefixDocs(p("alp"), 3), (std::vector<uint64_t>{0}));
    }

    // Every sample now claims the sentinel position. text_len is <= text_len and
    // divisible by rate 1, and neither the count nor sampled_bv_ changed, so
    // this passes load validation unchanged — which is the point.
    std::string tampered = clean;
    for (size_t i = 0; i < n_samples; ++i) {
        const uint64_t v = text_len;
        std::memcpy(tampered.data() + samples_off + i * sizeof(uint64_t),
                    &v,
                    sizeof(v));
    }

    auto [bad, bad_backing] = load_view(tampered);
    ASSERT_TRUE(bad.valid()) << "load validation cannot catch this; the bound "
                                "check at the locate call sites is the fix";

    // Suffix hits locate to text_len (== text_len, out of range) and must be
    // dropped entirely rather than mapped to document_count().
    EXPECT_TRUE(bad.LocateSuffixDocs(p("lta"), 3).empty());
    // Prefix adds one before mapping, so it must be checked after the +1.
    for (const char* pat : {"gam", "bet", "del", "alp"}) {
        for (const auto& got : {bad.LocatePrefixDocs(p(pat), 3),
                                bad.LocateSuffixDocs(p(pat), 3)}) {
            for (uint64_t d : got) {
                EXPECT_LT(d, bad.document_count())
                    << "out-of-range document id escaped locate for " << pat;
            }
        }
    }
}

TEST(FMIndex, UnsupportedSchemaUsesDataTypeInvalidCode) {
    storage::FileManagerContext ctx;
    ctx.fieldDataMeta.field_id = 101;
    ctx.fieldDataMeta.field_schema.set_data_type(
        proto::schema::DataType::Int64);
    index::FMIndexParams params{};
    index::FMIndex idx(ctx, params);

    try {
        idx.BuildWithFieldData({});
        FAIL() << "expected FMINDEX to reject an INT64 schema";
    } catch (const SegcoreError& e) {
        EXPECT_EQ(e.get_error_code(), ErrorCode::DataTypeInvalid);
    }
}

// InnerMatch over rows that each contain the pattern MANY times: the result is
// per-row (each matching row set once), and the streaming visitor path must
// dedup repeated in-row occurrences without materializing them.
TEST(FMIndex, InnerMatchDedupsRepeatedOccurrences) {
    // row 0: "ababababab..." (50 occurrences of "ab")
    // row 1: no match; row 2: one occurrence; row 3: "ab" x 200
    std::string many0, many3;
    for (int i = 0; i < 50; i++) {
        many0 += "ab";
    }
    for (int i = 0; i < 200; i++) {
        many3 += "ab";
    }
    auto idx = MakeRawDataIndex({many0, "zzzz", "xxabxx", many3});

    EXPECT_EQ(Inner(idx.get(), "ab"), (std::vector<int64_t>{0, 2, 3}));
    // single-char patterns, the degenerate high-frequency case
    EXPECT_EQ(Inner(idx.get(), "a"), (std::vector<int64_t>{0, 2, 3}));
    EXPECT_EQ(Inner(idx.get(), "z"), (std::vector<int64_t>{1}));
    EXPECT_EQ(Inner(idx.get(), "x"), (std::vector<int64_t>{2}));
}

// Differential oracle: build FMINDEX over random rows (small alphabet so needles
// collide, plus a few full-byte rows, both including embedded '\0') and check
// prefix/infix/suffix against a brute-force std::string oracle for many random
// and row-derived patterns. This pins the Milvus-specific query path (zero-copy
// views, streaming visitor, and '\0'-as-content) to ground truth — coverage the
// external fm-index-lite suite does not exercise in Milvus CI. Fixed RNG seed:
// deterministic, reproducible on failure.
TEST(FMIndex, DifferentialOracleRandomBytes) {
    std::mt19937 rng(0xF3A1u);
    auto rand_str = [&](size_t maxlen, int alphabet) {
        size_t len = rng() % (maxlen + 1);
        std::string s;
        s.reserve(len);
        for (size_t i = 0; i < len; i++) {
            s.push_back(static_cast<char>(rng() % alphabet));  // may be '\0'
        }
        return s;
    };
    std::vector<std::string> data;
    data.reserve(300);
    for (int i = 0; i < 280; i++) {
        data.push_back(rand_str(12, 4));  // small alphabet {0,1,2,3}
    }
    for (int i = 0; i < 20; i++) {
        data.push_back(rand_str(20, 256));  // full byte range
    }
    auto idx = MakeRawDataIndex(data);

    auto oracle = [&](const std::string& p, char kind) {
        std::vector<int64_t> out;
        for (size_t d = 0; d < data.size(); d++) {
            const auto& row = data[d];
            bool hit = false;
            if (kind == 'p') {
                hit =
                    row.size() >= p.size() && row.compare(0, p.size(), p) == 0;
            } else if (kind == 's') {
                hit = row.size() >= p.size() &&
                      row.compare(row.size() - p.size(), p.size(), p) == 0;
            } else {
                hit = row.find(p) != std::string::npos;
            }
            if (hit) {
                out.push_back(static_cast<int64_t>(d));
            }
        }
        return out;
    };

    for (int q = 0; q < 200; q++) {
        std::string pat = rand_str(3, 4);
        if (pat.empty()) {
            continue;  // empty pattern is a separate (all-non-null-rows) contract
        }
        EXPECT_EQ(Prefix(idx.get(), pat), oracle(pat, 'p')) << "prefix q=" << q;
        EXPECT_EQ(Suffix(idx.get(), pat), oracle(pat, 's')) << "suffix q=" << q;
        EXPECT_EQ(Inner(idx.get(), pat), oracle(pat, 'i')) << "inner q=" << q;
    }
    // Patterns lifted from actual rows guarantee non-empty hits and exercise
    // longer needles over the full-byte rows.
    for (int q = 0; q < 40; q++) {
        const std::string& row = data[rng() % data.size()];
        if (row.empty()) {
            continue;
        }
        size_t start = rng() % row.size();
        size_t len = 1 + rng() % (row.size() - start);
        std::string pat = row.substr(start, len);
        EXPECT_EQ(Inner(idx.get(), pat), oracle(pat, 'i'))
            << "row-substr q=" << q;
    }
}

// In/NotIn are required ScalarIndex<std::string> overrides, but FMINDEX declines
// the equality family (ShouldUseOp returns false for Equal/NotEqual, and the
// TermExpr gate declines IN/NOT IN), so the executor never routes ==/IN/NOT IN
// here. The overrides therefore throw Unsupported (like Range), so an accidental
// future route fails loudly instead of returning wrong rows. This also documents
// why FMINDEX carries no per-row length array (it existed only for this path).
TEST(FMIndex, InNotInDeclinedThrowUnsupported) {
    std::vector<std::string> data{
        "apple", "apply", "banana", "grape", "application", "app", ""};
    auto idx = MakeRawDataIndex(data);

    std::string app = "app";
    EXPECT_THROW(idx->In(1, &app), SegcoreError);
    EXPECT_THROW(idx->NotIn(1, &app), SegcoreError);
    std::vector<std::string> vs{"apple", "grape"};
    EXPECT_THROW(idx->In(2, vs.data()), SegcoreError);
}

// ---- full storage round-trip (Build -> Upload -> Load), mmap on and off ----

namespace {

void
CheckLoadedQueries(index::FMIndex* idx) {
    EXPECT_EQ(Prefix(idx, "app"), (std::vector<int64_t>{0, 1, 4, 5}));
    EXPECT_EQ(Suffix(idx, "e"), (std::vector<int64_t>{0, 3}));
    EXPECT_EQ(Inner(idx, "pp"), (std::vector<int64_t>{0, 1, 4, 5}));
    // `LIKE '%'` (empty pattern) returns all rows on this non-nullable field,
    // including the genuine empty-string row (6). Together with IsNotNull() this
    // exercises the null-bitmap load path for the all-valid (non-nullable) case.
    EXPECT_EQ(Inner(idx, ""),
              (std::vector<int64_t>{0, 1, 2, 3, 4, 5, 6, 7, 8}));
    EXPECT_EQ(SetBits(idx->IsNotNull()),
              (std::vector<int64_t>{0, 1, 2, 3, 4, 5, 6, 7, 8}));
}

std::vector<std::filesystem::path>
FindFMIndexStagingFiles(int64_t build_id,
                        int64_t index_version,
                        int64_t segment_id,
                        int64_t field_id) {
    std::vector<std::filesystem::path> files;
    auto index_root = std::filesystem::path(TestLocalPath) / INDEX_ROOT_PATH;
    std::error_code ec;
    if (!std::filesystem::exists(index_root, ec) || ec) {
        return files;
    }

    auto identifier = storage::GenIndexPathIdentifier(
        build_id, index_version, segment_id, field_id);
    while (!identifier.empty() &&
           (identifier.back() == '/' || identifier.back() == '\\')) {
        identifier.pop_back();
    }
    const auto generated_prefix = identifier + "_";
    for (std::filesystem::recursive_directory_iterator it(index_root, ec), end;
         it != end && !ec;
         it.increment(ec)) {
        if (!it->is_regular_file(ec) || ec ||
            it->path().filename() != index::FMINDEX_BLOB_FILE_NAME) {
            continue;
        }
        const auto parent_name = it->path().parent_path().filename().string();
        if (parent_name.rfind(generated_prefix, 0) == 0) {
            files.push_back(it->path());
        }
    }
    return files;
}

// Build -> Upload -> Load through one shared cm/fs/ctx (the test chunk manager
// keeps index files under an instance-local root, so a load routed through a
// second manager instance would not find them). Exercises WriteEntries and
// LoadEntries for both the mmap (LoadView) and the copy (Deserialize) paths.
void
RunRoundTrip(bool enable_mmap) {
    int64_t collection_id = 1, partition_id = 2, segment_id = 3;
    int64_t index_build_id = 4000, index_version = 4000;

    auto schema = std::make_shared<Schema>();
    auto field_id = schema->AddDebugField("fm", DataType::VARCHAR, false);
    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id.get(),
                                                      DataType::VARCHAR,
                                                      DataType::NONE,
                                                      false);
    auto index_meta = gen_index_meta(
        segment_id, field_id.get(), index_build_id, index_version);

    auto storage_config = gen_local_storage_config(TestLocalPath);
    auto cm = CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);
    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);

    std::vector<std::string> data{"apple",
                                  "apply",
                                  "banana",
                                  "grape",
                                  "application",
                                  "app",
                                  "",
                                  "MISMATCH" + std::string(20000, 'x'),
                                  "MISMATCH" + std::string(20000, 'y')};
    auto field_data =
        storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, false);
    field_data->FillFieldData(data.data(), data.size());

    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);
    auto serialized_bytes = insert_data.Serialize(storage::Remote);

    auto log_path = fmt::format("{}{}/{}/{}/{}/{}",
                                TestLocalPath,
                                collection_id,
                                partition_id,
                                segment_id,
                                field_id.get(),
                                0);
    auto cm_w = ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    std::vector<std::string> index_files;
    {
        Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        index::FMIndexParams params{.sa_sample_rate = 32};
        auto index = std::make_shared<index::FMIndex>(ctx, params);
        index->Build(config);
        index_files = index->UploadUnified({})->GetIndexFiles();
    }

    Config config;
    config[milvus::index::INDEX_FILES] = index_files;
    config[milvus::LOAD_PRIORITY] = milvus::proto::common::LoadPriority::HIGH;
    config[milvus::index::ENABLE_MMAP] = enable_mmap;
    // Deliberately disagree with the blob, which was built at rate 32. The cost
    // guard must use the serialized rate, not this external load parameter.
    index::FMIndexParams params{.sa_sample_rate = 8};
    auto idx = std::make_unique<index::FMIndex>(ctx, params);
    const auto packed_path =
        (std::filesystem::path(cm->GetRootPath()) / index_files.front())
            .string();
    const int64_t kEstimatedMemory =
        static_cast<int64_t>(cm->Size(packed_path));
    constexpr int64_t kEstimatedFile = 1234567;
    idx->SetCellSize({kEstimatedMemory, kEstimatedFile});
    idx->LoadUnified(config);

    EXPECT_EQ(idx->Count(), 9);
    if (enable_mmap) {
        EXPECT_EQ(idx->CellByteSize().memory_bytes, idx->ByteSize());
        EXPECT_EQ(idx->CellByteSize().file_bytes, kEstimatedFile);
        const auto bytes_after_load = idx->ByteSize();
        EXPECT_GT(bytes_after_load, 0);
        EXPECT_LT(idx->CellByteSize().memory_bytes, kEstimatedMemory / 2);
        // Match does not Extract. Recompute so this would fail if a future
        // change materialized ISA and grew resident heap.
        (void)Match(idx.get(), "%app%");
        idx->ComputeByteSize();
        EXPECT_EQ(idx->ByteSize(), bytes_after_load);
        EXPECT_EQ(idx->CellByteSize().memory_bytes, bytes_after_load);
    } else {
        // This change targets LoadView: the copy path keeps its pre-load cache
        // accounting unchanged.
        EXPECT_EQ(idx->CellByteSize().memory_bytes, kEstimatedMemory);
        EXPECT_EQ(idx->CellByteSize().file_bytes, kEstimatedFile);
    }
    CheckLoadedQueries(idx.get());
    // Two prefix hits over ~40K tokens: rate 32 declines (64 >= ~40), while the
    // stale load parameter 8 would incorrectly accept (16 < ~40).
    EXPECT_FALSE(
        idx->ShouldUseOp(proto::plan::OpType::PrefixMatch, "MISMATCH"));

    // Only the mmap path stages a flat FM-index blob locally. It remains while
    // queries use the mapping, then FMIndex destruction removes the generated
    // directory through DiskFileManagerImpl (not merely the file itself).
    auto staged_files = FindFMIndexStagingFiles(
        index_build_id, index_version, segment_id, field_id.get());
    if (enable_mmap) {
        ASSERT_EQ(staged_files.size(), 1);
        auto staged_dir = staged_files.front().parent_path();
        EXPECT_TRUE(std::filesystem::exists(staged_dir));
        idx.reset();
        EXPECT_FALSE(std::filesystem::exists(staged_dir));
    } else {
        EXPECT_TRUE(staged_files.empty());
    }
}

}  // namespace

TEST(FMIndex, SerializeLoadRoundTripMmap) {
    RunRoundTrip(/*enable_mmap=*/true);
}

TEST(FMIndex, SerializeLoadRoundTripNoMmap) {
    RunRoundTrip(/*enable_mmap=*/false);
}

// A genuine empty string must stay distinct from null across a serialize/load
// cycle. Since a null row and an empty-string row are the same empty document
// inside the FM blob, the persisted null bitmap is what keeps them apart:
// IsNull() marks only the null row, and `LIKE '%'` (empty pattern) / IsNotNull()
// include the empty-string row but exclude the null row.
TEST(FMIndex, NullVsEmptyStringDistinctAfterReload) {
    // idx:   0        1     2(null)  3
    std::vector<std::string> values{"apple", "", "", "banana"};
    std::vector<bool> valid{true, true, false, true};
    // Pack validity into a bitmap (bit i set == row i is valid), as the nullable
    // FillFieldData overload expects.
    std::vector<uint8_t> valid_bitmap((values.size() + 7) / 8, 0);
    for (size_t i = 0; i < valid.size(); i++) {
        if (valid[i]) {
            valid_bitmap[i >> 3] |= (1u << (i & 0x07));
        }
    }

    auto schema = std::make_shared<Schema>();
    auto field_id = schema->AddDebugField("fm", DataType::VARCHAR, true);
    int64_t collection_id = 1, partition_id = 2, segment_id = 3;
    int64_t index_build_id = 4001, index_version = 4001;

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id.get(),
                                                      DataType::VARCHAR,
                                                      DataType::NONE,
                                                      true);
    auto index_meta = gen_index_meta(
        segment_id, field_id.get(), index_build_id, index_version);

    auto storage_config = gen_local_storage_config(TestLocalPath);
    auto cm = CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);

    auto field_data =
        storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, true);
    field_data->FillFieldData(
        values.data(), valid_bitmap.data(), values.size(), 0);

    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);
    auto serialized_bytes = insert_data.Serialize(storage::Remote);

    auto log_path = fmt::format("{}{}/{}/{}/{}/{}",
                                TestLocalPath,
                                collection_id,
                                partition_id,
                                segment_id,
                                field_id.get(),
                                0);
    auto cm_w = ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;
    {
        Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        index::FMIndexParams params{.sa_sample_rate = 32};
        auto index = std::make_shared<index::FMIndex>(ctx, params);
        index->Build(config);
        index_files = index->UploadUnified({})->GetIndexFiles();
    }

    Config config;
    config[milvus::index::INDEX_FILES] = index_files;
    config[milvus::LOAD_PRIORITY] = milvus::proto::common::LoadPriority::HIGH;
    config[milvus::index::ENABLE_MMAP] = false;
    index::FMIndexParams params{.sa_sample_rate = 32};
    auto idx = std::make_unique<index::FMIndex>(ctx, params);
    idx->LoadUnified(config);

    EXPECT_EQ(idx->Count(), 4);
    // null-ness is carried by the persisted null bitmap (a null row and the
    // genuine empty-string row are the same empty document inside the FM blob,
    // so the bitmap is what keeps them distinct across a reload): only row 2 is
    // null; the empty-string row (1) is NOT null.
    EXPECT_EQ(SetBits(idx->IsNull()), (std::vector<int64_t>{2}));
    EXPECT_EQ(SetBits(idx->IsNotNull()), (std::vector<int64_t>{0, 1, 3}));

    // `LIKE '%'` (empty literal) matches every NON-NULL row and excludes the
    // null row (2), matching IsNotNull() — including the genuine empty-string
    // row (1).
    EXPECT_EQ(SetBits(idx->PatternMatch("", proto::plan::OpType::PrefixMatch)),
              (std::vector<int64_t>{0, 1, 3}));
    EXPECT_EQ(SetBits(idx->PatternMatch("", proto::plan::OpType::InnerMatch)),
              (std::vector<int64_t>{0, 1, 3}));
    EXPECT_EQ(SetBits(idx->PatternMatch("", proto::plan::OpType::PostfixMatch)),
              (std::vector<int64_t>{0, 1, 3}));
}

// ---- executor path: declined ops downgrade to the scan, accepted ops agree --

// Run real filter expressions through ExecuteQueryExpr on a sealed segment that
// has BOTH the raw VARCHAR column and a loaded FMINDEX. This pins the routing
// contract at the execution layer, not just at ShouldUseOp's return value:
//   - ops the index declines (unary and binary ranges, general LIKE `a%e`, and
//     the equality family `==`/IN) must transparently fall back to the raw-data
//     scan — correct rows, NO throw;
//   - ops it accepts (anchored LIKE, `LIKE '%'` lowered to PrefixMatch(""))
//     must return exactly the scan's rows.
// Note on the count-first guard: on this tiny corpus (~50 tokens) the guard
// declines every non-empty anchored pattern (a scan of 50 bytes always beats
// enumeration), so the anchored cases below ALSO exercise the guard-declined
// RawData path end-to-end; the empty-literal case (always accelerated) keeps
// the index path covered. Either path must produce identical rows — that
// invariance is exactly what this test pins.
TEST(FMIndex, ExecutorPathDeclinedOpsFallBackToScan) {
    int64_t collection_id = 1, partition_id = 2, segment_id = 3;
    int64_t index_build_id = 6001, index_version = 6001, index_id = 7001;

    auto schema = std::make_shared<Schema>();
    auto field_id = schema->AddDebugField("fm_exec", DataType::VARCHAR);

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id.get(),
                                                      DataType::VARCHAR,
                                                      DataType::NONE,
                                                      false);
    auto index_meta = gen_index_meta(
        segment_id, field_id.get(), index_build_id, index_version);
    auto storage_config = gen_local_storage_config(TestLocalPath);
    auto cm = CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);

    std::vector<std::string> data{
        "apple", "banana", "grape", "melon", "zebra", "apse", "ane", ""};
    const size_t nb = data.size();

    auto field_data =
        storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, false);
    field_data->FillFieldData(data.data(), data.size());

    // Sealed segment with the raw column loaded (the scan path's data source).
    auto segment = milvus::segcore::CreateSealedSegment(schema);
    auto field_data_info = PrepareSingleFieldInsertBinlog(collection_id,
                                                          partition_id,
                                                          segment_id,
                                                          field_id.get(),
                                                          {field_data},
                                                          cm);
    segment->LoadFieldData(field_data_info);

    // Binlog for the index build.
    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);
    auto serialized_bytes = insert_data.Serialize(storage::Remote);
    auto log_path = fmt::format("{}{}/{}/{}/{}/{}",
                                TestLocalPath,
                                collection_id,
                                partition_id,
                                segment_id,
                                field_id.get(),
                                1);
    auto cm_w = ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;
    int64_t index_size = 0;
    {
        Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        index::FMIndexParams params{.sa_sample_rate = 8};
        auto built = std::make_shared<index::FMIndex>(ctx, params);
        built->Build(config);
        auto stats = built->UploadUnified({});
        index_size = stats->GetSerializedSize();
        index_files = stats->GetIndexFiles();
    }

    // Load the index INTO the segment through the production entry point
    // (AppendIndexV2 -> IndexFactory -> LoadUnified), so queries route through
    // the real pinned-index path.
    std::map<std::string, std::string> index_params{
        {milvus::index::INDEX_TYPE, milvus::index::FMINDEX_INDEX_TYPE},
        {milvus::index::FM_SA_SAMPLE_RATE, "8"},
        {milvus::LOAD_PRIORITY, "HIGH"},
        {milvus::index::SCALAR_INDEX_ENGINE_VERSION, "3"},
    };
    milvus::segcore::LoadIndexInfo load_index_info{};
    load_index_info.collection_id = collection_id;
    load_index_info.partition_id = partition_id;
    load_index_info.segment_id = segment_id;
    load_index_info.field_id = field_id.get();
    load_index_info.field_type = DataType::VARCHAR;
    load_index_info.enable_mmap = true;
    load_index_info.mmap_dir_path = TestLocalPath + "mmap";
    load_index_info.index_id = index_id;
    load_index_info.index_build_id = index_build_id;
    load_index_info.index_version = index_version;
    load_index_info.index_params = index_params;
    load_index_info.index_files = index_files;
    load_index_info.schema = field_meta.field_schema;
    load_index_info.index_size = index_size;
    uint8_t trace_id[16] = {1};
    uint8_t span_id[8] = {2};
    CTraceContext trace{};
    trace.traceID = trace_id;
    trace.spanID = span_id;
    trace.traceFlags = 0;
    AppendIndexV2(trace, static_cast<CLoadIndexInfo>(&load_index_info));
    segment->LoadIndex(load_index_info);

    auto run = [&](proto::plan::OpType op, std::string value) {
        auto* unary = test::GenUnaryRangeExpr(op, value);
        unary->set_allocated_column_info(test::GenColumnInfo(
            field_id.get(), proto::schema::DataType::VarChar, false, false));
        auto expr = test::GenExpr();
        expr->set_allocated_unary_range_expr(unary);
        auto parser = milvus::query::ProtoParser(schema);
        auto typed_expr = parser.ParseExprs(*expr);
        auto node = std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID,
                                                           typed_expr);
        return milvus::query::ExecuteQueryExpr(
            node, segment.get(), nb, MAX_TIMESTAMP);
    };
    auto run_binary = [&](const std::string& lower, const std::string& upper) {
        proto::plan::GenericValue lower_val;
        lower_val.set_string_val(lower);
        proto::plan::GenericValue upper_val;
        upper_val.set_string_val(upper);
        auto typed_expr = std::make_shared<milvus::expr::BinaryRangeFilterExpr>(
            milvus::expr::ColumnInfo(field_id, DataType::VARCHAR),
            lower_val,
            upper_val,
            false,
            false);
        auto node = std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID,
                                                           typed_expr);
        return milvus::query::ExecuteQueryExpr(
            node, segment.get(), nb, MAX_TIMESTAMP);
    };
    auto expect_rows =
        [&](const BitsetType& got,
            const std::function<bool(const std::string&)>& oracle,
            const char* what) {
            for (size_t i = 0; i < nb; i++) {
                EXPECT_EQ(got[i], oracle(data[i]))
                    << what << " row " << i << " (" << data[i] << ")";
            }
        };

    // DECLINED: lexicographic range — must scan, not throw.
    expect_rows(
        run(proto::plan::OpType::GreaterThan, "m"),
        [](const std::string& s) { return s > "m"; },
        "GreaterThan");
    expect_rows(
        run(proto::plan::OpType::LessEqual, "banana"),
        [](const std::string& s) { return s <= "banana"; },
        "LessEqual");
    expect_rows(
        run_binary("a", "z"),
        [](const std::string& s) { return s > "a" && s < "z"; },
        "BinaryRange a-z");
    // General LIKE 'a%e' (interior wildcard -> Match). Either the candidate
    // recheck path or the scan (tiny corpus often trips the cost guard) must
    // equal the brute-force oracle.
    expect_rows(
        run(proto::plan::OpType::Match, "a%e"),
        [](const std::string& s) {
            return !s.empty() && s.front() == 'a' && s.back() == 'e';
        },
        "Match a%e");
    // ACCEPTED: anchored ops answered by the index, must equal the scan.
    expect_rows(
        run(proto::plan::OpType::InnerMatch, "an"),
        [](const std::string& s) { return s.find("an") != std::string::npos; },
        "InnerMatch an");
    expect_rows(
        run(proto::plan::OpType::PrefixMatch, "ap"),
        [](const std::string& s) { return s.rfind("ap", 0) == 0; },
        "PrefixMatch ap");
    // DECLINED: equality (`==`, lowered from `== "banana"`) is not accelerated
    // by FMINDEX — must fall back to the scan and still return correct rows.
    expect_rows(
        run(proto::plan::OpType::Equal, "banana"),
        [](const std::string& s) { return s == "banana"; },
        "Equal banana");
    // ACCEPTED: `LIKE '%'` lowers to PrefixMatch("") — all rows (no nulls here),
    // the empty-pattern fix exercised end-to-end.
    expect_rows(
        run(proto::plan::OpType::PrefixMatch, ""),
        [](const std::string&) { return true; },
        "PrefixMatch empty");
}

// Large enough corpus that Match is accepted. Phase 2 must recheck VARCHAR
// so a candidate superset (QOP%ZEBRA) is exact after ExecFMMatch.
TEST(FMIndex, ExecutorPathMatchRechecksVarchar) {
    int64_t collection_id = 11, partition_id = 12, segment_id = 13;
    int64_t index_build_id = 6101, index_version = 6101, index_id = 7101;

    auto schema = std::make_shared<Schema>();
    auto field_id = schema->AddDebugField("fm_match", DataType::VARCHAR);

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      field_id.get(),
                                                      DataType::VARCHAR,
                                                      DataType::NONE,
                                                      false);
    auto index_meta = gen_index_meta(
        segment_id, field_id.get(), index_build_id, index_version);
    auto storage_config = gen_local_storage_config(TestLocalPath);
    auto cm = CreateChunkManager(storage_config);
    auto fs = storage::InitArrowFileSystem(storage_config);

    std::vector<std::string> data;
    std::string filler(500, 'y');
    data.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        std::string row = filler;
        if (i % 250 == 0) {
            row += "ZEBRA";
        }
        if (i >= 100 && (i - 100) % 250 == 0) {
            row = "QOP" + row;
        }
        if (i == 0) {
            row = "QOP" + row;
        }
        data.push_back(std::move(row));
    }
    const size_t nb = data.size();

    auto field_data =
        storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, false);
    field_data->FillFieldData(data.data(), data.size());

    auto segment = milvus::segcore::CreateSealedSegment(schema);
    auto field_data_info = PrepareSingleFieldInsertBinlog(collection_id,
                                                          partition_id,
                                                          segment_id,
                                                          field_id.get(),
                                                          {field_data},
                                                          cm);
    segment->LoadFieldData(field_data_info);

    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(field_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);
    auto serialized_bytes = insert_data.Serialize(storage::Remote);
    auto log_path = fmt::format("{}{}/{}/{}/{}/{}",
                                TestLocalPath,
                                collection_id,
                                partition_id,
                                segment_id,
                                field_id.get(),
                                1);
    auto cm_w = ChunkManagerWrapper(cm);
    cm_w.Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;
    int64_t index_size = 0;
    {
        Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        index::FMIndexParams params{.sa_sample_rate = 8};
        auto built = std::make_shared<index::FMIndex>(ctx, params);
        built->Build(config);
        auto stats = built->UploadUnified({});
        index_size = stats->GetSerializedSize();
        index_files = stats->GetIndexFiles();
        EXPECT_TRUE(built->ShouldUseOp(proto::plan::OpType::Match, "%ZEBRA%"));
        EXPECT_TRUE(
            built->ShouldUseOp(proto::plan::OpType::Match, "QOP%ZEBRA"));
    }

    std::map<std::string, std::string> index_params{
        {milvus::index::INDEX_TYPE, milvus::index::FMINDEX_INDEX_TYPE},
        {milvus::index::FM_SA_SAMPLE_RATE, "8"},
        {milvus::LOAD_PRIORITY, "HIGH"},
        {milvus::index::SCALAR_INDEX_ENGINE_VERSION, "3"},
    };
    milvus::segcore::LoadIndexInfo load_index_info{};
    load_index_info.collection_id = collection_id;
    load_index_info.partition_id = partition_id;
    load_index_info.segment_id = segment_id;
    load_index_info.field_id = field_id.get();
    load_index_info.field_type = DataType::VARCHAR;
    load_index_info.enable_mmap = true;
    load_index_info.mmap_dir_path = TestLocalPath + "mmap";
    load_index_info.index_id = index_id;
    load_index_info.index_build_id = index_build_id;
    load_index_info.index_version = index_version;
    load_index_info.index_params = index_params;
    load_index_info.index_files = index_files;
    load_index_info.schema = field_meta.field_schema;
    load_index_info.index_size = index_size;
    uint8_t trace_id[16] = {3};
    uint8_t span_id[8] = {4};
    CTraceContext trace{};
    trace.traceID = trace_id;
    trace.spanID = span_id;
    trace.traceFlags = 0;
    AppendIndexV2(trace, static_cast<CLoadIndexInfo>(&load_index_info));
    segment->LoadIndex(load_index_info);

    auto make_typed_expr = [&](const std::string& value) {
        auto* unary =
            test::GenUnaryRangeExpr(proto::plan::OpType::Match, value);
        unary->set_allocated_column_info(test::GenColumnInfo(
            field_id.get(), proto::schema::DataType::VarChar, false, false));
        auto expr = test::GenExpr();
        expr->set_allocated_unary_range_expr(unary);
        auto parser = milvus::query::ProtoParser(schema);
        return parser.ParseExprs(*expr);
    };
    auto run = [&](const std::string& value) {
        auto typed_expr = make_typed_expr(value);
        auto node = std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID,
                                                           typed_expr);
        return milvus::query::ExecuteQueryExpr(
            node, segment.get(), nb, MAX_TIMESTAMP);
    };
    auto expect_rows =
        [&](const BitsetType& got,
            const std::function<bool(const std::string&)>& oracle,
            const char* what) {
            for (size_t i = 0; i < nb; i++) {
                EXPECT_EQ(got[i], oracle(data[i]))
                    << what << " row " << i << " (" << data[i] << ")";
            }
        };

    expect_rows(
        run("%ZEBRA%"),
        [](const std::string& s) {
            return s.find("ZEBRA") != std::string::npos;
        },
        "Match %ZEBRA%");
    expect_rows(
        run("QOP%ZEBRA"),
        [](const std::string& s) {
            return s.rfind("QOP", 0) == 0 &&
                   s.find("ZEBRA") != std::string::npos;
        },
        "Match QOP%ZEBRA");

    // LIKE syntax is expression semantics, so reject an invalid pattern while
    // compiling the physical expression, before an empty FMINDEX candidate set
    // can skip exact recheck and silently turn the error into an empty result.
    auto invalid_expr = make_typed_expr("ABSENT\\");
    auto query_context = std::make_shared<exec::QueryContext>(
        DEAFULT_QUERY_ID, segment.get(), nb, MAX_TIMESTAMP);
    exec::ExecContext exec_context(query_context.get());
    try {
        (void)exec::CompileExpressions(
            {invalid_expr}, &exec_context, {}, false);
        FAIL() << "expected invalid LIKE pattern to fail during compilation";
    } catch (const SegcoreError& error) {
        EXPECT_EQ(error.get_error_code(), ErrorCode::ExprInvalid);
    }
}

namespace {

struct SealedFMMatch {
    SchemaPtr schema;
    FieldId varchar_id;
    FieldId int_id;
    std::unique_ptr<segcore::SegmentSealed> segment;
    // Owns the insert-log write and keeps TestLocalPath alive until the
    // loaded segment is destroyed. ChunkManagerWrapper::dtor wipes the
    // chunk-manager root.
    std::unique_ptr<ChunkManagerWrapper> cm_w;
};

expr::TypedExprPtr
MakeMatchTypedExpr(const SchemaPtr& schema,
                   FieldId field_id,
                   const std::string& pattern,
                   bool nullable) {
    auto* unary = test::GenUnaryRangeExpr(proto::plan::OpType::Match, pattern);
    unary->set_allocated_column_info(
        test::GenColumnInfo(field_id.get(),
                            proto::schema::DataType::VarChar,
                            false,
                            false,
                            proto::schema::DataType::None,
                            nullable));
    auto expr = test::GenExpr();
    expr->set_allocated_unary_range_expr(unary);
    auto parser = milvus::query::ProtoParser(schema);
    return parser.ParseExprs(*expr);
}

bool
CompiledUseIndexCursor(const expr::TypedExprPtr& typed_expr,
                       const segcore::SegmentInternalInterface* segment,
                       int64_t active_count) {
    auto query_context = std::make_shared<exec::QueryContext>(
        DEAFULT_QUERY_ID, segment, active_count, MAX_TIMESTAMP);
    exec::ExecContext exec_context(query_context.get());
    auto compiled =
        exec::CompileExpressions({typed_expr}, &exec_context, {}, false);
    auto* seg_expr = dynamic_cast<exec::SegmentExpr*>(compiled[0].get());
    if (seg_expr == nullptr) {
        return false;
    }
    return seg_expr->UseIndexCursor();
}

SealedFMMatch
LoadSealedFMMatch(int64_t collection_id,
                  int64_t partition_id,
                  int64_t segment_id,
                  int64_t index_build_id,
                  const std::vector<std::string>& rows,
                  const std::vector<FieldDataPtr>& varchar_chunks,
                  bool nullable,
                  const uint8_t* valid_bitmap,
                  const std::vector<int64_t>* ints) {
    SealedFMMatch out;
    out.schema = std::make_shared<Schema>();
    out.varchar_id =
        out.schema->AddDebugField("fm_match", DataType::VARCHAR, nullable);
    if (ints != nullptr) {
        out.int_id = out.schema->AddDebugField("fm_int", DataType::INT64);
    }

    auto field_meta = milvus::segcore::gen_field_meta(collection_id,
                                                      partition_id,
                                                      segment_id,
                                                      out.varchar_id.get(),
                                                      DataType::VARCHAR,
                                                      DataType::NONE,
                                                      nullable,
                                                      /*max_length=*/65535);
    auto index_meta = gen_index_meta(
        segment_id, out.varchar_id.get(), index_build_id, index_build_id);
    auto storage_config = gen_local_storage_config(TestLocalPath);
    auto cm = CreateChunkManager(storage_config);
    // Same FS handle as ExecutorPathMatchRechecksVarchar. UploadUnified writes
    // through StorageV2FSCache; AppendIndexV2 reads through the process Arrow
    // FS. Both are rooted at TestLocalPath, so the packed file is visible.
    auto fs = storage::InitArrowFileSystem(storage_config);
    out.cm_w = std::make_unique<ChunkManagerWrapper>(cm);

    std::vector<FieldDataPtr> chunks = varchar_chunks;
    if (chunks.empty()) {
        auto field_data = storage::CreateFieldData(
            DataType::VARCHAR, DataType::NONE, nullable);
        if (nullable) {
            field_data->FillFieldData(
                rows.data(), valid_bitmap, rows.size(), 0);
        } else {
            field_data->FillFieldData(rows.data(), rows.size());
        }
        chunks.push_back(field_data);
    }

    out.segment = milvus::segcore::CreateSealedSegment(out.schema);
    auto varchar_info = PrepareSingleFieldInsertBinlog(collection_id,
                                                       partition_id,
                                                       segment_id,
                                                       out.varchar_id.get(),
                                                       chunks,
                                                       cm);
    out.segment->LoadFieldData(varchar_info);

    if (ints != nullptr) {
        auto int_data =
            storage::CreateFieldData(DataType::INT64, DataType::NONE, false);
        int_data->FillFieldData(ints->data(), ints->size());
        auto int_info = PrepareSingleFieldInsertBinlog(collection_id,
                                                       partition_id,
                                                       segment_id,
                                                       out.int_id.get(),
                                                       {int_data},
                                                       cm);
        out.segment->LoadFieldData(int_info);
    }

    auto build_data =
        storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, nullable);
    if (nullable) {
        build_data->FillFieldData(rows.data(), valid_bitmap, rows.size(), 0);
    } else {
        build_data->FillFieldData(rows.data(), rows.size());
    }
    auto payload_reader =
        std::make_shared<milvus::storage::PayloadReader>(build_data);
    storage::InsertData insert_data(payload_reader);
    insert_data.SetFieldDataMeta(field_meta);
    insert_data.SetTimestamps(0, 100);
    auto serialized_bytes = insert_data.Serialize(storage::Remote);
    auto log_path = fmt::format("{}{}/{}/{}/{}/{}",
                                TestLocalPath,
                                collection_id,
                                partition_id,
                                segment_id,
                                out.varchar_id.get(),
                                1);
    out.cm_w->Write(log_path, serialized_bytes.data(), serialized_bytes.size());

    storage::FileManagerContext ctx(field_meta, index_meta, cm, fs);
    std::vector<std::string> index_files;
    int64_t index_size = 0;
    {
        Config config;
        config[milvus::index::INDEX_TYPE] = milvus::index::FMINDEX_INDEX_TYPE;
        config[INSERT_FILES_KEY] = std::vector<std::string>{log_path};
        index::FMIndexParams params{.sa_sample_rate = 8};
        auto built = std::make_shared<index::FMIndex>(ctx, params);
        built->Build(config);
        auto stats = built->UploadUnified({});
        index_size = stats->GetSerializedSize();
        index_files = stats->GetIndexFiles();
        AssertInfo(!index_files.empty(), "FMINDEX upload produced no files");
    }

    std::map<std::string, std::string> index_params{
        {milvus::index::INDEX_TYPE, milvus::index::FMINDEX_INDEX_TYPE},
        {milvus::index::FM_SA_SAMPLE_RATE, "8"},
        {milvus::LOAD_PRIORITY, "HIGH"},
        {milvus::index::SCALAR_INDEX_ENGINE_VERSION, "3"},
    };
    milvus::segcore::LoadIndexInfo load_index_info{};
    load_index_info.collection_id = collection_id;
    load_index_info.partition_id = partition_id;
    load_index_info.segment_id = segment_id;
    load_index_info.field_id = out.varchar_id.get();
    load_index_info.field_type = DataType::VARCHAR;
    load_index_info.enable_mmap = true;
    load_index_info.mmap_dir_path = TestLocalPath + "mmap";
    load_index_info.index_id = index_build_id + 1000;
    load_index_info.index_build_id = index_build_id;
    load_index_info.index_version = index_build_id;
    load_index_info.index_params = index_params;
    load_index_info.index_files = index_files;
    load_index_info.schema = field_meta.field_schema;
    load_index_info.index_size = index_size;
    uint8_t trace_id[16] = {5};
    uint8_t span_id[8] = {6};
    CTraceContext trace{};
    trace.traceID = trace_id;
    trace.spanID = span_id;
    trace.traceFlags = 0;
    AppendIndexV2(trace, static_cast<CLoadIndexInfo>(&load_index_info));
    out.segment->LoadIndex(load_index_info);
    return out;
}

std::vector<std::string>
MakeLongTextZebraRows(size_t nb) {
    std::string filler(500, 'y');
    std::vector<std::string> data;
    data.reserve(nb);
    for (size_t i = 0; i < nb; i++) {
        std::string row = filler;
        if (i % 250 == 0) {
            row += "ZEBRA";
        }
        if (i >= 100 && (i - 100) % 250 == 0) {
            row = "QOP" + row;
        }
        if (i == 0) {
            row = "QOP" + row;
        }
        data.push_back(std::move(row));
    }
    return data;
}

}  // namespace

TEST(FMIndex, ExecutorPathMatchBatchesAndBitmap) {
    const size_t nb = 1000;
    auto rows = MakeLongTextZebraRows(nb);
    constexpr size_t kLateFalsePositive = 500;
    constexpr size_t kLateTrueMatch = 750;
    rows[kLateTrueMatch] = "QOP" + rows[kLateTrueMatch];
    std::vector<int64_t> ints(nb);
    for (size_t i = 0; i < nb; i++) {
        ints[i] = static_cast<int64_t>(i);
    }
    auto loaded =
        LoadSealedFMMatch(21, 22, 23, 8101, rows, {}, false, nullptr, &ints);

    auto match_expr = MakeMatchTypedExpr(
        loaded.schema, loaded.varchar_id, "QOP%ZEBRA", false);
    EXPECT_TRUE(CompiledUseIndexCursor(
        match_expr, loaded.segment.get(), static_cast<int64_t>(nb)));
    auto declined =
        MakeMatchTypedExpr(loaded.schema, loaded.varchar_id, "%%", false);
    EXPECT_FALSE(CompiledUseIndexCursor(
        declined, loaded.segment.get(), static_cast<int64_t>(nb)));

    proto::plan::GenericValue match_val;
    match_val.set_string_val("QOP%ZEBRA");
    auto match = std::make_shared<expr::UnaryRangeFilterExpr>(
        expr::ColumnInfo(loaded.varchar_id, DataType::VARCHAR),
        proto::plan::OpType::Match,
        match_val);
    proto::plan::GenericValue int_val;
    int_val.set_int64_val(500);
    auto numeric = std::make_shared<expr::UnaryRangeFilterExpr>(
        expr::ColumnInfo(loaded.int_id, DataType::INT64),
        proto::plan::OpType::GreaterEqual,
        int_val);
    auto conjunction = std::make_shared<expr::LogicalBinaryExpr>(
        expr::LogicalBinaryExpr::OpType::And, match, numeric);

    milvus::test::ExprBatchSizeGuard batch_size_guard(64);
    EXPECT_FALSE(milvus::test::CanExprExecuteAllAtOnce(
        conjunction, loaded.segment.get(), static_cast<int64_t>(nb)));
    auto node = std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID,
                                                       conjunction);
    auto got = milvus::query::ExecuteQueryExpr(
        node, loaded.segment.get(), nb, MAX_TIMESTAMP);
    LikePatternMatcher matcher("QOP%ZEBRA");
    ASSERT_NE(rows[kLateFalsePositive].find("ZEBRA"), std::string::npos);
    ASSERT_EQ(rows[kLateFalsePositive].find("QOP"), std::string::npos);
    ASSERT_FALSE(matcher(rows[kLateFalsePositive]));
    ASSERT_TRUE(matcher(rows[kLateTrueMatch]));
    for (size_t i = 0; i < nb; i++) {
        const bool want = matcher(rows[i]) && ints[i] >= 500;
        EXPECT_EQ(got[i], want) << "row " << i;
    }
    EXPECT_FALSE(got[kLateFalsePositive]);
    EXPECT_TRUE(got[kLateTrueMatch]);
}

TEST(FMIndex, ExecutorPathMatchMultiChunk) {
    const size_t nb = 300;
    std::string filler(500, 'y');
    std::vector<std::string> rows;
    rows.reserve(nb);
    for (size_t i = 0; i < nb; i++) {
        if (i % 100 == 25) {
            rows.push_back(filler + "ZEBRA");
        } else {
            rows.push_back(filler);
        }
    }
    auto chunk_of = [&](size_t begin, size_t end) {
        auto field_data =
            storage::CreateFieldData(DataType::VARCHAR, DataType::NONE, false);
        field_data->FillFieldData(rows.data() + begin, end - begin);
        return field_data;
    };
    std::vector<FieldDataPtr> chunks{
        chunk_of(0, 100), chunk_of(100, 200), chunk_of(200, 300)};
    auto loaded = LoadSealedFMMatch(
        31, 32, 33, 8201, rows, chunks, false, nullptr, nullptr);

    auto match_expr =
        MakeMatchTypedExpr(loaded.schema, loaded.varchar_id, "%ZEBRA%", false);
    EXPECT_TRUE(CompiledUseIndexCursor(
        match_expr, loaded.segment.get(), static_cast<int64_t>(nb)));
    EXPECT_TRUE(milvus::test::CanExprExecuteAllAtOnce(
        match_expr, loaded.segment.get(), static_cast<int64_t>(nb)));

    // FilterBits executes this scalar-index expression all at once. Hits at 25,
    // 125, and 225 therefore force one ProcessDataByOffsets call to read
    // candidates from all three raw chunks.
    auto node =
        std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID, match_expr);
    auto got = milvus::query::ExecuteQueryExpr(
        node, loaded.segment.get(), nb, MAX_TIMESTAMP);
    LikePatternMatcher matcher("%ZEBRA%");
    size_t hits = 0;
    std::array<size_t, 3> chunk_hits{};
    for (size_t i = 0; i < nb; i++) {
        const bool want = matcher(rows[i]);
        EXPECT_EQ(got[i], want) << "row " << i;
        hits += want;
        chunk_hits[i / 100] += want;
    }
    EXPECT_EQ(hits, 3u);
    EXPECT_EQ(chunk_hits, (std::array<size_t, 3>{1, 1, 1}));
    EXPECT_LT(hits, nb);
}

TEST(FMIndex, ExecutorPathMatchNullableAndOffsets) {
    std::string filler(500, 'y');
    std::vector<std::string> rows(200, filler);
    rows[0] = filler + "ZEBRA";
    rows[50] = filler + "ZEBRA";
    rows[51] = "";
    std::vector<uint8_t> valid_bitmap((rows.size() + 7) / 8, 0);
    for (size_t i = 0; i < rows.size(); i++) {
        if (i != 51 && i != 52) {
            valid_bitmap[i >> 3] |= static_cast<uint8_t>(1u << (i & 0x07));
        }
    }
    rows[52] = filler + "ZEBRA";
    auto loaded = LoadSealedFMMatch(
        41, 42, 43, 8301, rows, {}, true, valid_bitmap.data(), nullptr);
    const size_t nb = rows.size();
    auto match_expr =
        MakeMatchTypedExpr(loaded.schema, loaded.varchar_id, "%ZEBRA%", true);
    EXPECT_TRUE(CompiledUseIndexCursor(
        match_expr, loaded.segment.get(), static_cast<int64_t>(nb)));

    auto node =
        std::make_shared<plan::FilterBitsNode>(DEFAULT_PLANNODE_ID, match_expr);
    auto full = milvus::query::ExecuteQueryExpr(
        node, loaded.segment.get(), nb, MAX_TIMESTAMP);
    LikePatternMatcher matcher("%ZEBRA%");
    for (size_t i = 0; i < nb; i++) {
        const bool valid = (valid_bitmap[i >> 3] & (1u << (i & 0x07))) != 0;
        const bool want = valid && matcher(rows[i]);
        EXPECT_EQ(full[i], want) << "row " << i;
    }

    exec::OffsetVector offsets;
    for (int32_t i = 0; i < static_cast<int32_t>(nb); i += 2) {
        offsets.push_back(i);
    }
    auto offset_res = milvus::test::gen_filter_res(
        node.get(), loaded.segment.get(), nb, MAX_TIMESTAMP, &offsets);
    ASSERT_EQ(offset_res->size(), offsets.size());
    TargetBitmapView offset_view(offset_res->GetRawData(), offsets.size());
    for (size_t j = 0; j < offsets.size(); j++) {
        const auto i = static_cast<size_t>(offsets[j]);
        EXPECT_EQ(offset_view[j], full[i]) << "offset row " << i;
    }
}

// PatternMatch returns candidates. RecheckedMatch on the fixture strings must
// equal LikePatternMatcher brute force for every pattern, including those
// ShouldUseOp declines.
TEST(FMIndex, MatchOracleEqualsBruteForce) {
    std::vector<std::string> data{
        "apple",
        "apply",
        "banana",
        "grape",
        "application",
        "app",
        "",
        "foo bar",
        "fooXbar",
        "café",
        "caf\xC3\xA9 extra",
        "你好世界",
        "hello你好world",
        "a_b",
        "a%b",
        "100%",
        std::string(200, 'z') + "NEEDLE" + std::string(200, 'z'),
        std::string(80, 'q'),
    };
    auto idx = MakeRawDataIndex(data);

    const std::vector<std::string> patterns{
        "a%e",       "%foo%bar%", "foo%bar",     "%app%",       "app%",
        "%app",      "a_c",       "a_pple",      "%_%",         "%",
        "%%",        "_",         "a\\_b",       "%\\%%",       "100\\%",
        "%café%",    "%你好%",    "hello%world", "%NEEDLE%",    "%q%",
        "nope%nope", "",          "app",         "%zz%NEEDLE%", "application",
        "%X%",
    };

    for (const auto& pattern : patterns) {
        LikePatternMatcher matcher(pattern);
        std::vector<int64_t> expected;
        for (size_t i = 0; i < data.size(); ++i) {
            if (matcher(data[i])) {
                expected.push_back(static_cast<int64_t>(i));
            }
        }
        EXPECT_EQ(RecheckedMatch(idx.get(), data, pattern), expected)
            << "pattern=[" << pattern << "]";
    }
}

TEST(FMIndex, MatchGuardDeclinesUnselectiveAndStillExact) {
    std::vector<std::string> data;
    std::string filler(500, 'x');
    data.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        std::string row = filler;
        if (i % 200 == 0) {
            row += "RARE";
        }
        data.push_back(std::move(row));
    }
    auto idx = MakeRawDataIndex(data);

    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%x%"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%RARE%"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%RARE%x%"));
    EXPECT_FALSE(idx->ShouldUseOp(proto::plan::OpType::Match, "%_%"));

    LikePatternMatcher rare("%RARE%");
    std::vector<int64_t> expected;
    for (size_t i = 0; i < data.size(); ++i) {
        if (rare(data[i])) {
            expected.push_back(static_cast<int64_t>(i));
        }
    }
    EXPECT_EQ(RecheckedMatch(idx.get(), data, "%RARE%"), expected);
    LikePatternMatcher every("%x%");
    std::vector<int64_t> every_expected;
    for (size_t i = 0; i < data.size(); ++i) {
        if (every(data[i])) {
            every_expected.push_back(static_cast<int64_t>(i));
        }
    }
    EXPECT_EQ(RecheckedMatch(idx.get(), data, "%x%"), every_expected);
}

// Locate-only accepts a single rare hit on long rows (occ x sr < ratio x
// tokens). Phase 2 is a sequential VARCHAR read of that one row.
TEST(FMIndex, MatchGuardAcceptsRareHitOnLongRows) {
    std::vector<std::string> data;
    std::string filler(2000, 'y');
    data.reserve(100);
    for (int i = 0; i < 100; i++) {
        std::string row = filler;
        if (i == 0) {
            row += "RARE";
        }
        data.push_back(std::move(row));
    }
    auto idx = MakeRawDataIndex(data);
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::InnerMatch, "RARE"));
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%RARE%"));
    EXPECT_EQ(RecheckedMatch(idx.get(), data, "%RARE%"),
              (std::vector<int64_t>{0}));
}

// Short rows, one rare hit: locate is cheap, Match accelerates.
TEST(FMIndex, MatchGuardAcceptsRareFragmentOnShortRows) {
    std::vector<std::string> data;
    std::string filler(200, 'y');
    data.reserve(5000);
    for (int i = 0; i < 5000; i++) {
        std::string row = filler;
        if (i == 0) {
            row += "RARE";
        }
        data.push_back(std::move(row));
    }
    auto idx = MakeRawDataIndex(data);
    EXPECT_TRUE(idx->ShouldUseOp(proto::plan::OpType::Match, "%RARE%"));
    EXPECT_EQ(RecheckedMatch(idx.get(), data, "%RARE%"),
              (std::vector<int64_t>{0}));
}
