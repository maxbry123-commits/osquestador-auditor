// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "Meta.h"
#include "bitset/bitset.h"
#include "common/Array.h"
#include "common/EasyAssert.h"
#include "common/FastMem.h"
#include "common/FieldDataInterface.h"
#include "common/File.h"
#include "common/Slice.h"
#include "common/Tracer.h"
#include "common/Types.h"
#include "fmt/core.h"
#include "glog/logging.h"
#include "index/ScalarIndex.h"
#include "index/ScalarIndexSort.h"
#include "index/Utils.h"
#include "knowhere/binaryset.h"
#include "log/Log.h"
#include "nlohmann/json.hpp"
#include "pb/common.pb.h"
#include "pb/schema.pb.h"
#include "storage/DiskFileManagerImpl.h"
#include "storage/FileWriter.h"
#include "storage/IndexEntryReader.h"
#include "storage/IndexEntryWriter.h"
#include "storage/MemFileManagerImpl.h"
#include "storage/ThreadPools.h"
#include "storage/Types.h"
#include "storage/Util.h"

namespace milvus::index {

const std::string MMAP_PATH_FOR_TEST = "/tmp/milvus/mmap_test";

const std::string STLSORT_INDEX_FILE_NAME = "stlsort-index";

constexpr size_t SCALAR_SORT_ALIGNMENT = 32;  // 32-byte alignment

const uint64_t SCALAR_SORT_MMAP_INDEX_PADDING = 1;

namespace {

bool
IsScalarArrayField(const storage::FileManagerContext& file_manager_context) {
    return file_manager_context.Valid() &&
           file_manager_context.fieldDataMeta.field_schema.data_type() ==
               proto::schema::DataType::Array;
}

}  // namespace

template <typename T>
ScalarIndexSort<T>::ScalarIndexSort(
    const storage::FileManagerContext& file_manager_context,
    bool is_nested_index)
    : ScalarIndex<T>(ASCENDING_SORT),
      is_nested_index_(is_nested_index),
      is_array_field_(IsScalarArrayField(file_manager_context)),
      is_built_(false),
      data_() {
    // not valid means we are in unit test
    if (file_manager_context.Valid()) {
        field_id_ = file_manager_context.fieldDataMeta.field_id;
        this->file_manager_ =
            std::make_shared<storage::MemFileManagerImpl>(file_manager_context);
        disk_file_manager_ = std::make_shared<storage::DiskFileManagerImpl>(
            file_manager_context);
    }
}

template <typename T>
void
ScalarIndexSort<T>::Build(const Config& config) {
    if (is_built_) {
        return;
    }
    auto field_datas = storage::CacheRawDataAndFillMissing(
        std::static_pointer_cast<storage::MemFileManagerImpl>(
            this->file_manager_),
        config);

    BuildWithFieldData(field_datas);
}

template <typename T>
void
ScalarIndexSort<T>::Build(size_t n, const T* values, const bool* valid_data) {
    if (is_built_)
        return;
    if (n == 0) {
        ThrowInfo(DataIsEmpty, "ScalarIndexSort cannot build null values!");
    }
    index_build_begin_ = std::chrono::system_clock::now();

    data_.reserve(n);
    total_num_rows_ = n;
    valid_bitset_ = TargetBitmap(total_num_rows_, false);
    idx_to_offsets_.resize(n);

    T* p = const_cast<T*>(values);
    for (size_t i = 0; i < n; ++i, ++p) {
        if (!valid_data || valid_data[i]) {
            data_.emplace_back(IndexStructure(*p, i));
            valid_bitset_.set(i);
        }
    }

    std::sort(data_.begin(), data_.end());
    for (size_t i = 0; i < data_.size(); ++i) {
        idx_to_offsets_[data_[i].idx_] = i;
    }
    idx_to_offsets_ptr_ = idx_to_offsets_.data();
    idx_to_offsets_size_ = idx_to_offsets_.size();
    is_built_ = true;

    setup_data_pointers();
    ComputeByteSize();
}

template <typename T>
void
ScalarIndexSort<T>::BuildWithFieldData(
    const std::vector<milvus::FieldDataPtr>& field_datas) {
    index_build_begin_ = std::chrono::system_clock::now();

    if (is_nested_index_) {
        BuildWithArrayDataNested(field_datas);
        return;
    }

    int64_t length = 0;
    for (const auto& data : field_datas) {
        total_num_rows_ += data->get_num_rows();
        length += data->get_num_rows() - data->get_null_count();
    }
    if (total_num_rows_ == 0) {
        ThrowInfo(DataIsEmpty, "ScalarIndexSort cannot build null values!");
    }

    data_.reserve(length);
    valid_bitset_ = TargetBitmap(total_num_rows_, false);
    int64_t offset = 0;
    for (const auto& data : field_datas) {
        auto slice_num = data->get_num_rows();
        for (size_t i = 0; i < slice_num; ++i) {
            if (data->is_valid(i)) {
                auto value = reinterpret_cast<const T*>(data->RawValue(i));
                data_.emplace_back(IndexStructure(*value, offset));
                valid_bitset_.set(offset);
            }
            offset++;
        }
    }
    std::sort(data_.begin(), data_.end());
    idx_to_offsets_.resize(total_num_rows_);
    for (size_t i = 0; i < length; ++i) {
        // TODO: there is an existing bug here, data_[i].idx_ is out of range, should be fixed
        if (data_[i].idx_ < 0 || data_[i].idx_ >= total_num_rows_) {
            continue;
        }
        idx_to_offsets_[data_[i].idx_] = i;
    }
    idx_to_offsets_ptr_ = idx_to_offsets_.data();
    idx_to_offsets_size_ = idx_to_offsets_.size();
    is_built_ = true;

    setup_data_pointers();
    ComputeByteSize();
}

template <typename T>
void
ScalarIndexSort<T>::BuildWithArrayDataNested(
    const std::vector<FieldDataPtr>& datas) {
    // calculate total_num_rows_
    for (const auto& data : datas) {
        auto n = data->get_num_rows();
        for (int64_t i = 0; i < n; i++) {
            if (data->is_valid(i)) {
                // RawValue maps logical->physical so compact nullable array
                // FieldData is read correctly (Data()[i] would overrun).
                total_num_rows_ +=
                    reinterpret_cast<const Array*>(data->RawValue(i))->length();
            }
        }
    }

    if (total_num_rows_ == 0) {
        ThrowInfo(DataIsEmpty, "ScalarIndexSort cannot build null values!");
    }

    data_.reserve(total_num_rows_);
    // all values are valid for nested index because any given slot in a valid_bitset_ denotes one element in a valid row
    valid_bitset_ = TargetBitmap(total_num_rows_, true);
    int64_t offset = 0;
    for (const auto& data : datas) {
        auto n = data->get_num_rows();
        for (int64_t i = 0; i < n; i++) {
            if (!data->is_valid(i)) {
                continue;
            }
            auto* array = reinterpret_cast<const Array*>(data->RawValue(i));
            auto length = array->length();
            for (int64_t j = 0; j < length; j++) {
                data_.emplace_back(
                    IndexStructure(array->get_data<T>(j), offset));
                offset++;
            }
        }
    }
    std::sort(data_.begin(), data_.end());
    idx_to_offsets_.resize(total_num_rows_);
    for (size_t i = 0; i < total_num_rows_; ++i) {
        idx_to_offsets_[data_[i].idx_] = i;
    }
    idx_to_offsets_ptr_ = idx_to_offsets_.data();
    idx_to_offsets_size_ = idx_to_offsets_.size();
    is_built_ = true;

    setup_data_pointers();
    ComputeByteSize();
}

template <typename T>
BinarySet
ScalarIndexSort<T>::Serialize(const Config& config) {
    AssertInfo(is_built_, "index has not been built");

    auto index_data_size = data_.size() * sizeof(IndexStructure<T>);
    std::shared_ptr<uint8_t[]> index_data(new uint8_t[index_data_size]);
    milvus::fastmem::FastMemcpy(
        index_data.get(), data_.data(), index_data_size);

    std::shared_ptr<uint8_t[]> index_length(new uint8_t[sizeof(size_t)]);
    auto index_size = data_.size();
    milvus::fastmem::FastMemcpy(
        index_length.get(), &index_size, sizeof(size_t));

    std::shared_ptr<uint8_t[]> index_num_rows(new uint8_t[sizeof(size_t)]);
    milvus::fastmem::FastMemcpy(
        index_num_rows.get(), &total_num_rows_, sizeof(size_t));

    std::shared_ptr<uint8_t[]> is_nested_data(new uint8_t[sizeof(bool)]);
    milvus::fastmem::FastMemcpy(
        is_nested_data.get(), &is_nested_index_, sizeof(bool));

    BinarySet res_set;
    res_set.Append("index_data", index_data, index_data_size);
    res_set.Append("index_length", index_length, sizeof(size_t));
    res_set.Append("index_num_rows", index_num_rows, sizeof(size_t));
    res_set.Append("is_nested_index", is_nested_data, sizeof(bool));

    milvus::Disassemble(res_set);

    return res_set;
}

template <typename T>
IndexStatsPtr
ScalarIndexSort<T>::Upload(const Config& config) {
    auto index_build_duration =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now() - index_build_begin_)
            .count();
    LOG_INFO(
        "index build done for ScalarIndexSort, field_id: {}, is_nested_index: "
        "{}, duration: "
        "{}ms",
        field_id_,
        is_nested_index_,
        index_build_duration);

    auto binary_set = Serialize(config);
    this->file_manager_->AddFile(binary_set);

    auto remote_paths_to_size = this->file_manager_->GetRemotePathsToFileSize();
    return IndexStats::NewFromSizeMap(
        this->file_manager_->GetAddedTotalMemSize(), remote_paths_to_size);
}

template <typename T>
void
ScalarIndexSort<T>::SetupMmapFromData(
    const uint8_t* data,
    size_t size,
    milvus::proto::common::LoadPriority priority) {
    // Setup mmap file path
    mmap_filepath_ = disk_file_manager_ != nullptr
                         ? disk_file_manager_->GetLocalIndexObjectPrefix() +
                               STLSORT_INDEX_FILE_NAME
                         : MMAP_PATH_FOR_TEST;
    std::filesystem::create_directories(
        std::filesystem::path(mmap_filepath_).parent_path());

    auto aligned_size =
        ((size + SCALAR_SORT_ALIGNMENT - 1) / SCALAR_SORT_ALIGNMENT) *
        SCALAR_SORT_ALIGNMENT;

    // Write data to file with alignment padding
    {
        auto file_writer = storage::FileWriter(
            mmap_filepath_, storage::io::GetPriorityFromLoadPriority(priority));
        file_writer.Write(data, size);

        if (aligned_size > size) {
            std::vector<uint8_t> padding(aligned_size - size, 0);
            file_writer.Write(padding.data(), padding.size());
        }
        // Write extra padding for safety
        std::vector<uint8_t> padding(SCALAR_SORT_MMAP_INDEX_PADDING, 0);
        file_writer.Write(padding.data(), padding.size());
        file_writer.Finish();
    }

    // mmap the file
    auto file = File::Open(mmap_filepath_, O_RDONLY);
    mmap_data_ =
        static_cast<char*>(mmap(NULL,
                                aligned_size + SCALAR_SORT_MMAP_INDEX_PADDING,
                                PROT_READ,
                                MAP_PRIVATE,
                                file.Descriptor(),
                                0));

    if (mmap_data_ == MAP_FAILED) {
        file.Close();
        remove(mmap_filepath_.c_str());
        ThrowInfo(
            ErrorCode::UnexpectedError, "failed to mmap: {}", strerror(errno));
    }

    mmap_size_ = aligned_size + SCALAR_SORT_MMAP_INDEX_PADDING;
    data_size_ = size;
    file.Close();
}

template <typename T>
void
ScalarIndexSort<T>::LoadWithoutAssemble(const BinarySet& index_binary,
                                        const Config& config) {
    size_t index_size;
    auto index_length = index_binary.GetByName("index_length");
    milvus::fastmem::FastMemcpy(
        &index_size, index_length->data.get(), (size_t)index_length->size);

    auto is_nested_index = index_binary.GetByName("is_nested_index");
    if (is_nested_index) {
        bool loaded_is_nested_index = false;
        milvus::fastmem::FastMemcpy(&loaded_is_nested_index,
                                    is_nested_index->data.get(),
                                    (size_t)is_nested_index->size);
        is_nested_index_ = is_nested_index_ || loaded_is_nested_index;
    }

    is_mmap_ = GetValueFromConfig<bool>(config, ENABLE_MMAP).value_or(true);

    auto index_data = index_binary.GetByName("index_data");

    if (is_mmap_) {
        auto load_priority =
            GetValueFromConfig<milvus::proto::common::LoadPriority>(
                config, milvus::LOAD_PRIORITY)
                .value_or(milvus::proto::common::LoadPriority::HIGH);
        SetupMmapFromData(
            reinterpret_cast<const uint8_t*>(index_data->data.get()),
            index_data->size,
            load_priority);
    } else {
        data_.resize(index_size);
        milvus::fastmem::FastMemcpy(
            data_.data(), index_data->data.get(), (size_t)index_data->size);
    }

    setup_data_pointers();

    auto index_num_rows = index_binary.GetByName("index_num_rows");
    if (index_num_rows) {
        milvus::fastmem::FastMemcpy(&total_num_rows_,
                                    index_num_rows->data.get(),
                                    (size_t)index_num_rows->size);
    } else {
        total_num_rows_ = index_size;
    }

    idx_to_offsets_.resize(total_num_rows_);
    valid_bitset_ = TargetBitmap(total_num_rows_, false);

    for (size_t i = 0; i < Size(); ++i) {
        const auto& item = operator[](i);
        idx_to_offsets_[item.idx_] = i;
        valid_bitset_.set(item.idx_);
    }
    idx_to_offsets_ptr_ = idx_to_offsets_.data();
    idx_to_offsets_size_ = idx_to_offsets_.size();

    is_built_ = true;
    ComputeByteSize();

    LOG_INFO("load ScalarIndexSort done, field_id: {}, is_mmap:{}",
             field_id_,
             is_mmap_);
}

template <typename T>
void
ScalarIndexSort<T>::Load(const BinarySet& index_binary, const Config& config) {
    milvus::Assemble(const_cast<BinarySet&>(index_binary));
    LoadWithoutAssemble(index_binary, config);
}

template <typename T>
void
ScalarIndexSort<T>::Load(milvus::tracer::TraceContext ctx,
                         const Config& config) {
    auto index_files =
        GetValueFromConfig<std::vector<std::string>>(config, "index_files");
    AssertInfo(index_files.has_value(),
               "index file paths is empty when load disk ann index");
    auto load_priority =
        GetValueFromConfig<milvus::proto::common::LoadPriority>(
            config, milvus::LOAD_PRIORITY)
            .value_or(milvus::proto::common::LoadPriority::HIGH);
    auto index_datas = this->file_manager_->LoadIndexToMemory(
        index_files.value(), load_priority);
    BinarySet binary_set;
    AssembleIndexDatas(index_datas, binary_set);
    // clear index_datas to free memory early
    index_datas.clear();
    LoadWithoutAssemble(binary_set, config);
}

template <typename T>
const TargetBitmap
ScalarIndexSort<T>::In(const size_t n, const T* values) {
    AssertInfo(is_built_, "index has not been built");
    TargetBitmap bitset(Count());
    for (size_t i = 0; i < n; ++i) {
        const auto target = IndexStructure<T>(*(values + i));
        auto lb = std::lower_bound(begin(), end(), target);
        auto ub = std::upper_bound(lb, end(), target);
        for (; lb < ub; ++lb) {
            if (lb->a_ != target.a_) {
                LOG_ERROR(
                    "error happens in ScalarIndexSort<T>::In, "
                    "expected value is: {}, but real value is: {}",
                    target.a_,
                    lb->a_);
            }
            bitset[lb->idx_] = true;
        }
    }
    return bitset;
}

template <typename T>
const TargetBitmap
ScalarIndexSort<T>::NotIn(const size_t n, const T* values) {
    AssertInfo(is_built_, "index has not been built");
    // NotIn must keep null rows false, so start from the validity bitmap.
    auto bitset = valid_bitset_.clone();
    for (size_t i = 0; i < n; ++i) {
        const auto target = IndexStructure<T>(*(values + i));
        auto lb = std::lower_bound(begin(), end(), target);
        auto ub = std::upper_bound(lb, end(), target);
        for (; lb < ub; ++lb) {
            if (lb->a_ != target.a_) {
                LOG_ERROR(
                    "error happens in ScalarIndexSort<T>::NotIn, "
                    "expected value is: {}, but real value is: {}",
                    target.a_,
                    lb->a_);
            }
            bitset[lb->idx_] = false;
        }
    }
    return bitset;
}

template <typename T>
const TargetBitmap
ScalarIndexSort<T>::IsNull() {
    AssertInfo(is_built_, "index has not been built");
    auto bitset = valid_bitset_.clone();
    bitset.flip();
    return bitset;
}

template <typename T>
TargetBitmap
ScalarIndexSort<T>::IsNotNull() {
    AssertInfo(is_built_, "index has not been built");
    return valid_bitset_.clone();
}

template <typename T>
const TargetBitmap
ScalarIndexSort<T>::Range(const T& value, const OpType op) {
    AssertInfo(is_built_, "index has not been built");
    auto lb = begin();
    auto ub = end();
    if (ShouldSkip(value, value, op)) {
        TargetBitmap bitset(Count());
        return bitset;
    }
    switch (op) {
        case OpType::LessThan:
            ub = std::lower_bound(begin(), end(), IndexStructure<T>(value));
            break;
        case OpType::LessEqual:
            ub = std::upper_bound(begin(), end(), IndexStructure<T>(value));
            break;
        case OpType::GreaterThan:
            lb = std::upper_bound(begin(), end(), IndexStructure<T>(value));
            break;
        case OpType::GreaterEqual:
            lb = std::lower_bound(begin(), end(), IndexStructure<T>(value));
            break;
        default:
            ThrowInfo(OpTypeInvalid,
                      fmt::format("Invalid OperatorType: {}", op));
    }

    size_t hit_count = ub - lb;
    size_t total_count = Count();

    if (hit_count > total_count / 2) {
        // Most elements are in range, initialize with `valid_bitset` and set non-matching to false
        TargetBitmap bitset = valid_bitset_.clone();
        // Set elements before lb to false
        for (auto it = begin(); it < lb; ++it) {
            bitset[it->idx_] = false;
        }
        // Set elements after ub to false
        for (auto it = ub; it < end(); ++it) {
            bitset[it->idx_] = false;
        }
        return bitset;
    } else {
        // Fewer elements are in range, initialize with false and set matching to true
        TargetBitmap bitset(total_count);
        for (; lb < ub; ++lb) {
            bitset[lb->idx_] = true;
        }
        return bitset;
    }
}

template <typename T>
const TargetBitmap
ScalarIndexSort<T>::Range(const T& lower_bound_value,
                          bool lb_inclusive,
                          const T& upper_bound_value,
                          bool ub_inclusive) {
    AssertInfo(is_built_, "index has not been built");
    if (lower_bound_value > upper_bound_value ||
        (lower_bound_value == upper_bound_value &&
         !(lb_inclusive && ub_inclusive))) {
        TargetBitmap bitset(Count());
        return bitset;
    }
    if (ShouldSkip(lower_bound_value, upper_bound_value, OpType::Range)) {
        TargetBitmap bitset(Count());
        return bitset;
    }
    auto lb = begin();
    auto ub = end();
    if (lb_inclusive) {
        lb = std::lower_bound(
            begin(), end(), IndexStructure<T>(lower_bound_value));
    } else {
        lb = std::upper_bound(
            begin(), end(), IndexStructure<T>(lower_bound_value));
    }
    if (ub_inclusive) {
        ub = std::upper_bound(
            begin(), end(), IndexStructure<T>(upper_bound_value));
    } else {
        ub = std::lower_bound(
            begin(), end(), IndexStructure<T>(upper_bound_value));
    }

    size_t hit_count = ub - lb;
    size_t total_count = Count();

    if (hit_count > total_count / 2) {
        // Most elements are in range, initialize with `valid_bitset_` and set non-matching to false
        TargetBitmap bitset = valid_bitset_.clone();
        // Set elements before lb to false
        for (auto it = begin(); it < lb; ++it) {
            bitset[it->idx_] = false;
        }
        // Set elements after ub to false
        for (auto it = ub; it < end(); ++it) {
            bitset[it->idx_] = false;
        }
        return bitset;
    } else {
        // Fewer elements are in range, initialize with false and set matching to true
        TargetBitmap bitset(total_count);
        for (; lb < ub; ++lb) {
            bitset[lb->idx_] = true;
        }
        return bitset;
    }
}

template <typename T>
std::optional<T>
ScalarIndexSort<T>::Reverse_Lookup(size_t idx) const {
    AssertInfo(idx < idx_to_offsets_size_, "out of range of total count");
    AssertInfo(is_built_, "index has not been built");

    if (!valid_bitset_[idx]) {
        return std::nullopt;
    }
    auto offset = idx_to_offsets_ptr_[idx];
    return operator[](offset).a_;
}

template <typename T>
bool
ScalarIndexSort<T>::ShouldSkip(const T lower_value,
                               const T upper_value,
                               const milvus::OpType op) {
    if (!Empty()) {
        auto lower_bound = begin();
        auto upper_bound = rbegin();
        bool shouldSkip = false;
        switch (op) {
            case OpType::LessThan: {
                shouldSkip = upper_value <= lower_bound->a_;
                break;
            }
            case OpType::LessEqual: {
                shouldSkip = upper_value < lower_bound->a_;
                break;
            }
            case OpType::GreaterThan: {
                shouldSkip = lower_value >= upper_bound->a_;
                break;
            }
            case OpType::GreaterEqual: {
                shouldSkip = lower_value > upper_bound->a_;
                break;
            }
            case OpType::Range: {
                shouldSkip = (lower_value > upper_bound->a_) ||
                             (upper_value < lower_bound->a_);
                break;
            }
            default:
                ThrowInfo(OpTypeInvalid,
                          fmt::format("Invalid OperatorType for "
                                      "checking scalar index optimization: {}",
                                      op));
        }
        return shouldSkip;
    }
    return true;
}

template <typename T>
void
ScalarIndexSort<T>::WriteEntries(storage::IndexEntryWriter* writer) {
    AssertInfo(is_built_, "index has not been built");

    writer->PutMeta("index_length", data_.size());
    writer->PutMeta("num_rows", total_num_rows_);
    writer->PutMeta("is_nested", is_nested_index_);

    writer->WriteEntry(
        "index_data", data_.data(), data_.size() * sizeof(IndexStructure<T>));

    // Persist idx_to_offsets and valid_bitset to avoid recomputation at load.
    writer->WriteEntry("idx_to_offsets",
                       idx_to_offsets_.data(),
                       idx_to_offsets_.size() * sizeof(int32_t));
    writer->WriteEntry("valid_bitset",
                       reinterpret_cast<const uint8_t*>(valid_bitset_.data()),
                       valid_bitset_.size_in_bytes());
}

template <typename T>
void
ScalarIndexSort<T>::LoadEntries(storage::IndexEntryReader& reader,
                                const Config& config) {
    size_t index_size = reader.GetMeta<size_t>("index_length");
    total_num_rows_ = reader.GetMeta<size_t>("num_rows");
    is_nested_index_ = is_nested_index_ || reader.GetMeta<bool>("is_nested");

    is_mmap_ = GetValueFromConfig<bool>(config, ENABLE_MMAP).value_or(true);

    auto load_priority =
        GetValueFromConfig<milvus::proto::common::LoadPriority>(
            config, milvus::LOAD_PRIORITY)
            .value_or(milvus::proto::common::LoadPriority::HIGH);

    if (is_mmap_) {
        // Stream index_data entry to disk file, then mmap
        mmap_filepath_ = disk_file_manager_ != nullptr
                             ? disk_file_manager_->GetLocalIndexObjectPrefix() +
                                   STLSORT_INDEX_FILE_NAME
                             : MMAP_PATH_FOR_TEST;
        std::filesystem::create_directories(
            std::filesystem::path(mmap_filepath_).parent_path());

        size_t total_data_size = 0;
        {
            auto file_writer = storage::FileWriter(
                mmap_filepath_,
                storage::io::GetPriorityFromLoadPriority(load_priority));

            reader.ReadEntryStream("index_data",
                                   [&](const uint8_t* data, size_t len) {
                                       file_writer.Write(data, len);
                                       total_data_size += len;
                                   });

            auto aligned_size = ((total_data_size + SCALAR_SORT_ALIGNMENT - 1) /
                                 SCALAR_SORT_ALIGNMENT) *
                                SCALAR_SORT_ALIGNMENT;
            if (aligned_size > total_data_size) {
                std::vector<uint8_t> padding(aligned_size - total_data_size, 0);
                file_writer.Write(padding.data(), padding.size());
            }
            std::vector<uint8_t> mmap_pad(SCALAR_SORT_MMAP_INDEX_PADDING, 0);
            file_writer.Write(mmap_pad.data(), mmap_pad.size());
            file_writer.Finish();

            data_size_ = total_data_size;
            mmap_size_ = aligned_size + SCALAR_SORT_MMAP_INDEX_PADDING;
        }

        auto file = File::Open(mmap_filepath_, O_RDONLY);
        mmap_data_ = static_cast<char*>(mmap(
            NULL, mmap_size_, PROT_READ, MAP_PRIVATE, file.Descriptor(), 0));
        if (mmap_data_ == MAP_FAILED) {
            file.Close();
            remove(mmap_filepath_.c_str());
            ThrowInfo(ErrorCode::UnexpectedError,
                      "failed to mmap: {}",
                      strerror(errno));
        }
        file.Close();
    } else {
        // Stream index_data entry to pre-allocated memory
        data_.resize(index_size);
        size_t write_offset = 0;
        reader.ReadEntryStream(
            "index_data", [&](const uint8_t* data, size_t len) {
                milvus::fastmem::FastMemcpy(
                    reinterpret_cast<uint8_t*>(data_.data()) + write_offset,
                    data,
                    len);
                write_offset += len;
            });
        AssertInfo(write_offset == index_size * sizeof(IndexStructure<T>),
                   "stream read size mismatch: got {}, expected {}",
                   write_offset,
                   index_size * sizeof(IndexStructure<T>));
    }

    setup_data_pointers();

    auto load_valid_bitset = [&]() {
        valid_bitset_ = TargetBitmap(total_num_rows_, false);
        auto bitset_entry = reader.ReadEntry("valid_bitset");
        auto bitset_bytes = valid_bitset_.size_in_bytes();
        AssertInfo(bitset_entry.data.size() >= bitset_bytes,
                   "invalid valid_bitset size: expected at least {}, got {}",
                   bitset_bytes,
                   bitset_entry.data.size());
        memcpy(reinterpret_cast<uint8_t*>(valid_bitset_.data()),
               bitset_entry.data.data(),
               bitset_bytes);
    };
    auto get_idx_to_offsets_bytes = [&]() {
        auto offsets_bytes = reader.GetEntrySize("idx_to_offsets");
        auto expected_offsets_bytes = total_num_rows_ * sizeof(int32_t);
        AssertInfo(offsets_bytes == expected_offsets_bytes,
                   "invalid idx_to_offsets size: expected {}, got {}",
                   expected_offsets_bytes,
                   offsets_bytes);
        return offsets_bytes;
    };

    // Load persisted idx_to_offsets and valid_bitset if both are available,
    // otherwise recompute (backward compat with older V3 files).
    if (reader.HasEntry("idx_to_offsets") && reader.HasEntry("valid_bitset") &&
        is_mmap_) {
        // mmap path: stream idx_to_offsets to disk, then mmap it. valid_bitset
        // stays heap-resident for query masking, matching StringIndexSort.
        mmap_meta_filepath_ =
            (disk_file_manager_ != nullptr
                 ? disk_file_manager_->GetLocalIndexObjectPrefix()
                 : MMAP_PATH_FOR_TEST) +
            "stlsort-meta";
        std::filesystem::create_directories(
            std::filesystem::path(mmap_meta_filepath_).parent_path());

        auto offsets_bytes = get_idx_to_offsets_bytes();

        {
            auto fw = storage::FileWriter(
                mmap_meta_filepath_,
                storage::io::GetPriorityFromLoadPriority(load_priority));

            reader.ReadEntryStream(
                "idx_to_offsets",
                [&](const uint8_t* d, size_t len) { fw.Write(d, len); });
            fw.Finish();
        }

        mmap_meta_size_ = offsets_bytes;
        auto meta_file = File::Open(mmap_meta_filepath_, O_RDONLY);
        mmap_meta_data_ = static_cast<char*>(mmap(NULL,
                                                  mmap_meta_size_,
                                                  PROT_READ,
                                                  MAP_PRIVATE,
                                                  meta_file.Descriptor(),
                                                  0));
        if (mmap_meta_data_ == MAP_FAILED) {
            meta_file.Close();
            remove(mmap_meta_filepath_.c_str());
            ThrowInfo(ErrorCode::UnexpectedError,
                      "failed to mmap meta: {}",
                      strerror(errno));
        }
        meta_file.Close();

        idx_to_offsets_ptr_ = reinterpret_cast<const int32_t*>(mmap_meta_data_);
        idx_to_offsets_size_ = offsets_bytes / sizeof(int32_t);

        load_valid_bitset();
    } else if (reader.HasEntry("idx_to_offsets") &&
               reader.HasEntry("valid_bitset")) {
        // memory path: stream into vector
        auto offsets_bytes = get_idx_to_offsets_bytes();
        idx_to_offsets_.resize(total_num_rows_);
        size_t wo = 0;
        reader.ReadEntryStream(
            "idx_to_offsets", [&](const uint8_t* d, size_t len) {
                memcpy(reinterpret_cast<uint8_t*>(idx_to_offsets_.data()) + wo,
                       d,
                       len);
                wo += len;
            });
        AssertInfo(wo == offsets_bytes,
                   "idx_to_offsets stream read size mismatch: got {}, "
                   "expected {}",
                   wo,
                   offsets_bytes);
        idx_to_offsets_ptr_ = idx_to_offsets_.data();
        idx_to_offsets_size_ = idx_to_offsets_.size();

        load_valid_bitset();
    } else {
        // Backward compat: recompute from index_data
        idx_to_offsets_.resize(total_num_rows_);
        valid_bitset_ = TargetBitmap(total_num_rows_, false);
        for (size_t i = 0; i < Size(); ++i) {
            const auto& item = operator[](i);
            idx_to_offsets_[item.idx_] = i;
            valid_bitset_.set(item.idx_);
        }
        idx_to_offsets_ptr_ = idx_to_offsets_.data();
        idx_to_offsets_size_ = idx_to_offsets_.size();
    }

    is_built_ = true;
    ComputeByteSize();

    LOG_INFO("LoadEntries ScalarIndexSort done, field_id: {}, is_mmap:{}",
             field_id_,
             is_mmap_);
}

template class ScalarIndexSort<bool>;
template class ScalarIndexSort<int8_t>;
template class ScalarIndexSort<int16_t>;
template class ScalarIndexSort<int32_t>;
template class ScalarIndexSort<int64_t>;
template class ScalarIndexSort<float>;
template class ScalarIndexSort<double>;
}  // namespace milvus::index
