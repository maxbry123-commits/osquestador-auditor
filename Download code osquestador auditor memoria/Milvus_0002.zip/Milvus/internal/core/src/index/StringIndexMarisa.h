// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <marisa.h>
#include "index/StringIndex.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include "storage/MemFileManagerImpl.h"

namespace milvus::index {

class StringIndexMarisa : public StringIndex {
 public:
    explicit StringIndexMarisa(
        const storage::FileManagerContext& file_manager_context =
            storage::FileManagerContext());

    ~StringIndexMarisa() {
        if (str_ids_mmap_data_ != nullptr && str_ids_mmap_data_ != MAP_FAILED) {
            munmap(str_ids_mmap_data_, str_ids_mmap_size_);
        }
        if (csr_mmap_data_ != nullptr && csr_mmap_data_ != MAP_FAILED) {
            munmap(csr_mmap_data_, csr_mmap_size_);
        }
    }

    int64_t
    Size() override;

    void
    ComputeByteSize() override;

    BinarySet
    Serialize(const Config& config) override;

    void
    Load(const BinarySet& set, const Config& config = {}) override;

    void
    Load(milvus::tracer::TraceContext ctx, const Config& config = {}) override;

    int64_t
    Count() override {
        return str_ids_size_;
    }

    ScalarIndexType
    GetIndexType() const override {
        return ScalarIndexType::MARISA;
    }

    void
    Build(size_t n,
          const std::string* values,
          const bool* valid_data = nullptr) override;

    void
    Build(const Config& config = {}) override;

    void
    BuildWithFieldData(const std::vector<FieldDataPtr>& field_datas) override;

    const TargetBitmap
    In(size_t n, const std::string* values) override;

    const TargetBitmap
    NotIn(size_t n, const std::string* values) override;

    const TargetBitmap
    IsNull() override;

    // Declaring IsNotNull() here hides the base's row-count-aware
    // IsNotNull(int64_t) overload; keep it visible so a call through this
    // static type still finds it.
    using ScalarIndex<std::string>::IsNotNull;

    TargetBitmap
    IsNotNull() override;

    const TargetBitmap
    Range(const std::string& value, OpType op) override;

    const TargetBitmap
    Range(const std::string& lower_bound_value,
          bool lb_inclusive,
          const std::string& upper_bound_value,
          bool ub_inclusive) override;

    const TargetBitmap
    PrefixMatch(const std::string_view prefix) override;

    bool
    SupportPatternMatch() const override {
        return true;
    }

    const TargetBitmap
    PatternMatch(const std::string& pattern, proto::plan::OpType op) override;

    std::optional<std::string>
    Reverse_Lookup(size_t offset) const override;

    IndexStatsPtr
    Upload(const Config& config = {}) override;

    const bool
    HasRawData() const override {
        return true;
    }

 private:
    void
    fill_str_ids(size_t n, const std::string* values, const bool* valid_data);

    void
    fill_offsets();

    // get str_id by str, if str not found, -1 was returned.
    size_t
    lookup(const std::string_view str);

    std::vector<size_t>
    prefix_match(const std::string_view prefix);

    bool
    in_lexicographic_order();

    void
    SetNull(TargetBitmap& bitset);

    void
    ResetNull(TargetBitmap& bitset);

    void
    LoadWithoutAssemble(const BinarySet& binary_set,
                        const Config& config) override;

    int64_t
    CalculateTotalSize() const;

    void
    WriteEntries(storage::IndexEntryWriter* writer) override;

    void
    LoadEntries(storage::IndexEntryReader& reader,
                const Config& config) override;

 private:
    Config config_;
    marisa::Trie trie_;

    // str_ids: maps offset → trie key id.
    // Build/memory-load paths use the vector; mmap-load points into mmap'd file.
    std::vector<int64_t> str_ids_;          // memory mode owner
    const int64_t* str_ids_ptr_ = nullptr;  // read accessor (vec or mmap)
    size_t str_ids_size_ = 0;
    char* str_ids_mmap_data_ = nullptr;  // mmap region
    int64_t str_ids_mmap_size_ = 0;
    std::unique_ptr<MmapFileRAII> str_ids_mmap_raii_;  // file cleanup

    // CSR (Compressed Sparse Row) format for str_id → offsets mapping.
    // csr_index_[key_id] .. csr_index_[key_id+1] = range in csr_offsets_.
    // Values are row indices within a single segment. uint32_t is safe
    // because Milvus segments never approach 2^32 rows; fill_offsets and
    // LoadEntries assert the bound on the build / load paths.
    std::vector<uint32_t> csr_index_;    // size = num_keys + 1 (memory mode)
    std::vector<uint32_t> csr_offsets_;  // size = total_num_rows (memory mode)
    const uint32_t* csr_index_ptr_ = nullptr;    // read accessor (vec or mmap)
    const uint32_t* csr_offsets_ptr_ = nullptr;  // read accessor (vec or mmap)
    size_t csr_num_keys_ = 0;
    char* csr_mmap_data_ = nullptr;  // mmap region for csr_index + csr_offsets
    int64_t csr_mmap_size_ = 0;
    std::unique_ptr<MmapFileRAII> csr_mmap_raii_;  // file cleanup
    bool built_ = false;
    int64_t total_size_ = 0;  // Cached total size to avoid runtime calculation
};

using StringIndexMarisaPtr = std::unique_ptr<StringIndexMarisa>;

inline StringIndexPtr
CreateStringIndexMarisa(
    const storage::FileManagerContext& file_manager_context =
        storage::FileManagerContext()) {
    return std::make_unique<StringIndexMarisa>(file_manager_context);
}
}  // namespace milvus::index
