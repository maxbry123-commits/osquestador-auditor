// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "index/VectorMemIndex.h"

#include <assert.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <exception>
#include <filesystem>
#include <initializer_list>
#include <iosfwd>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "common/BitsetView.h"
#include "common/Common.h"
#include "common/Consts.h"
#include "common/EasyAssert.h"
#include "common/FastMem.h"
#include "common/FieldData.h"
#include "common/FieldDataInterface.h"
#include "common/File.h"
#include "common/QueryInfo.h"
#include "common/QueryResult.h"
#include "common/RangeSearchHelper.h"
#include "common/Slice.h"
#include "common/Tracer.h"
#include "common/Types.h"
#include "common/Utils.h"
#include "common/VectorArray.h"
#include "common/VectorTrait.h"
#include "common/protobuf_utils.h"
#include "glog/logging.h"
#include "index/Meta.h"
#include "index/Utils.h"
#include "index/VectorIndexValidDataUtils.h"
#include "knowhere/binaryset.h"
#include "knowhere/comp/index_param.h"
#include "knowhere/comp/time_recorder.h"
#include "knowhere/dataset.h"
#include "knowhere/emb_list_utils.h"
#include "knowhere/index/index_factory.h"
#include "knowhere/sparse_utils.h"
#include "log/Log.h"
#include "monitor/Monitor.h"
#include "nlohmann/json.hpp"
#include "opentelemetry/trace/span.h"
#include "opentelemetry/trace/tracer.h"
#include "pb/common.pb.h"
#include "prometheus/histogram.h"
#include "storage/DataCodec.h"
#include "storage/FileWriter.h"
#include "storage/MemFileManagerImpl.h"
#include "storage/ThreadPools.h"

namespace milvus::index {

namespace {

constexpr const char* EMPTY_EMB_LIST_OFFSET_KEY = "empty_emb_list_offsets";

struct EmptyEmbListState {
    int64_t dim;
    std::vector<size_t> offsets;
};

class EmptyVectorIterator : public knowhere::IndexNode::iterator {
 public:
    knowhere::expected<std::pair<int64_t, float>>
    Next() noexcept override {
        return knowhere::expected<std::pair<int64_t, float>>::Err(
            knowhere::Status::knowhere_inner_error,
            "empty vector iterator has no next result");
    }

    knowhere::expected<bool>
    HasNext() noexcept override {
        return false;
    }
};

EmptyEmbListState
LoadEmptyEmbListOffsetsFromPayload(const uint8_t* data, size_t size) {
    AssertInfo(data != nullptr, "empty emb_list offset data is null");
    AssertInfo(size >= sizeof(int64_t) + sizeof(uint64_t),
               "empty emb_list offset file is invalid");
    const auto* ptr = data;
    int64_t dim = 0;
    std::memcpy(&dim, ptr, sizeof(int64_t));
    ptr += sizeof(int64_t);

    uint64_t wire_count = 0;
    std::memcpy(&wire_count, ptr, sizeof(uint64_t));
    ptr += sizeof(uint64_t);

    auto count = FromValidDataCount(wire_count);
    AssertInfo(count > 0, "empty emb_list offset count is invalid");
    auto expected_size =
        sizeof(int64_t) + sizeof(uint64_t) + count * sizeof(size_t);
    AssertInfo(size >= expected_size,
               "empty emb_list offset file is too small");

    std::vector<size_t> offsets(count);
    std::memcpy(offsets.data(), ptr, count * sizeof(size_t));
    AssertInfo(offsets.front() == 0, "empty emb_list offset must start at 0");
    AssertInfo(offsets.back() == 0,
               "empty emb_list offset must have no flattened vectors");
    return EmptyEmbListState{dim, std::move(offsets)};
}

void
AppendEmptyEmbListOffsetsToBinarySet(int64_t dim,
                                     const std::vector<size_t>& offsets,
                                     BinarySet& binary_set) {
    if (offsets.empty()) {
        return;
    }

    auto count = static_cast<uint64_t>(offsets.size());
    auto bytes =
        sizeof(int64_t) + sizeof(uint64_t) + offsets.size() * sizeof(size_t);
    std::shared_ptr<uint8_t[]> data(new uint8_t[bytes]);
    auto* ptr = data.get();
    std::memcpy(ptr, &dim, sizeof(int64_t));
    ptr += sizeof(int64_t);
    std::memcpy(ptr, &count, sizeof(uint64_t));
    ptr += sizeof(uint64_t);
    std::memcpy(ptr, offsets.data(), offsets.size() * sizeof(size_t));
    binary_set.Append(EMPTY_EMB_LIST_OFFSET_KEY, data, bytes);
}

std::optional<EmptyEmbListState>
LoadEmptyEmbListOffsetsFromBinarySet(const BinarySet& binary_set) {
    auto data = binary_set.GetByName(EMPTY_EMB_LIST_OFFSET_KEY);
    if (data == nullptr) {
        return std::nullopt;
    }
    return LoadEmptyEmbListOffsetsFromPayload(data->data.get(), data->size);
}

}  // namespace

template <typename T>
VectorMemIndex<T>::VectorMemIndex(
    DataType elem_type,
    const IndexType& index_type,
    const MetricType& metric_type,
    const IndexVersion& version,
    bool use_knowhere_build_pool,
    const storage::FileManagerContext& file_manager_context)
    : VectorIndex(index_type, metric_type),
      elem_type_(elem_type),
      use_knowhere_build_pool_(use_knowhere_build_pool) {
    CheckMetricTypeSupport<T>(metric_type);
    AssertInfo(!is_unsupported(index_type, metric_type),
               "{} doesn't support metric: {}",
               index_type,
               metric_type);
    if (file_manager_context.Valid()) {
        file_manager_ =
            std::make_shared<storage::MemFileManagerImpl>(file_manager_context);
        AssertInfo(file_manager_ != nullptr, "create file manager failed!");
    }
    CheckCompatible(version);
    auto get_index_obj =
        knowhere::IndexFactory::Instance().Create<T>(GetIndexType(), version);
    if (get_index_obj.has_value()) {
        index_ = get_index_obj.value();
    } else {
        auto err = get_index_obj.error();
        if (err == knowhere::Status::invalid_index_error) {
            ThrowInfo(ErrorCode::Unsupported, get_index_obj.what());
        }
        ThrowInfo(ErrorCode::KnowhereError, get_index_obj.what());
    }
}

template <typename T>
VectorMemIndex<T>::VectorMemIndex(DataType elem_type,
                                  const IndexType& index_type,
                                  const MetricType& metric_type,
                                  const IndexVersion& version,
                                  const knowhere::ViewDataOp view_data,
                                  bool use_knowhere_build_pool)
    : VectorIndex(index_type, metric_type),
      elem_type_(elem_type),
      use_knowhere_build_pool_(use_knowhere_build_pool) {
    CheckMetricTypeSupport<T>(metric_type);
    AssertInfo(!is_unsupported(index_type, metric_type),
               "{} doesn't support metric: {}",
               index_type,
               metric_type);

    auto view_data_pack = knowhere::Pack(view_data);
    auto get_index_obj = knowhere::IndexFactory::Instance().Create<T>(
        GetIndexType(), version, view_data_pack);
    if (get_index_obj.has_value()) {
        index_ = get_index_obj.value();
    } else {
        auto err = get_index_obj.error();
        if (err == knowhere::Status::invalid_index_error) {
            ThrowInfo(ErrorCode::Unsupported, get_index_obj.what());
        }
        ThrowInfo(ErrorCode::KnowhereError, get_index_obj.what());
    }
}

template <typename T>
knowhere::expected<std::vector<knowhere::IndexNode::IteratorPtr>>
VectorMemIndex<T>::VectorIterators(const milvus::DatasetPtr dataset,
                                   const knowhere::Json& conf,
                                   const milvus::BitsetView& bitset,
                                   milvus::OpContext* op_context) const {
    auto make_empty_iterators = [](int64_t num_queries) {
        std::vector<knowhere::IndexNode::IteratorPtr> iterators;
        iterators.reserve(num_queries);
        for (int64_t i = 0; i < num_queries; ++i) {
            iterators.emplace_back(std::make_shared<EmptyVectorIterator>());
        }
        return iterators;
    };

    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map)) {
        auto offsets =
            dataset->Get<const size_t*>(knowhere::meta::EMB_LIST_OFFSET);
        auto num_queries = dataset->GetRows();
        if (offsets != nullptr) {
            num_queries = dataset->Get<int64_t>(knowhere::meta::NQ);
            AssertInfo(num_queries > 0,
                       "embedding list query count is missing");
            auto total_vectors = static_cast<size_t>(dataset->GetRows());
            AssertInfo(
                offsets[num_queries] == total_vectors,
                "embedding list query offsets are inconsistent with flattened "
                "rows: nq={}, terminal_offset={}, rows={}",
                num_queries,
                offsets[num_queries],
                total_vectors);
        }
        return make_empty_iterators(num_queries);
    }

    if (IsEmptyEmbListIndex()) {
        auto offsets =
            dataset->Get<const size_t*>(knowhere::meta::EMB_LIST_OFFSET);
        auto num_queries = dataset->GetRows();
        if (offsets != nullptr) {
            num_queries = dataset->Get<int64_t>(knowhere::meta::NQ);
            AssertInfo(num_queries > 0,
                       "embedding list query count is missing");
            auto total_vectors = static_cast<size_t>(dataset->GetRows());
            AssertInfo(
                offsets[num_queries] == total_vectors,
                "embedding list query offsets are inconsistent with flattened "
                "rows: nq={}, terminal_offset={}, rows={}",
                num_queries,
                offsets[num_queries],
                total_vectors);
        }
        return make_empty_iterators(num_queries);
    }
    return this->index_.AnnIterator(dataset, conf, bitset, false, op_context);
}

template <typename T>
IndexStatsPtr
VectorMemIndex<T>::Upload(const Config& config) {
    auto binary_set = Serialize(config);
    file_manager_->AddFile(binary_set);

    auto remote_paths_to_size = file_manager_->GetRemotePathsToFileSize();
    return IndexStats::NewFromSizeMap(file_manager_->GetAddedTotalMemSize(),
                                      remote_paths_to_size);
}

template <typename T>
BinarySet
VectorMemIndex<T>::Serialize(const Config& config) {
    knowhere::BinarySet ret;
    const auto& id_map = GetIdMap();
    bool all_null_nullable = IsAllNullNullable(id_map);
    if (IsEmptyEmbListIndex()) {
        AppendEmptyEmbListOffsetsToBinarySet(
            GetDim(), empty_emb_list_offsets_, ret);
    } else if (!all_null_nullable) {
        auto stat = index_.Serialize(ret);
        if (stat != knowhere::Status::success)
            ThrowInfo(ErrorCode::UnexpectedError,
                      "failed to serialize index: {}",
                      KnowhereStatusString(stat));
    }

    AppendValidDataToBinarySet(id_map, ret);
    Disassemble(ret);

    return ret;
}

template <typename T>
void
VectorMemIndex<T>::LoadWithoutAssemble(const BinarySet& binary_set,
                                       const Config& config) {
    const auto restored_id_map =
        RestoreIdMapFromBinarySet(binary_set, index_.GetIdMap());
    auto empty_emb_list_state =
        LoadEmptyEmbListOffsetsFromBinarySet(binary_set);
    if (empty_emb_list_state.has_value()) {
        SetDim(empty_emb_list_state->dim);
        empty_emb_list_offsets_ = std::move(empty_emb_list_state->offsets);
        if (restored_id_map.has_valid_data) {
            FinalizeRestoredIdMap(index_.Node(),
                                  ErrorCode::UnexpectedError,
                                  "empty emb-list load");
        }
    } else if (ContainsOnlyValidData(binary_set)) {
        if (config.contains(DIM_KEY)) {
            SetDim(GetDimFromConfig(config));
        }
        if (restored_id_map.has_valid_data) {
            FinalizeRestoredIdMap(
                index_.Node(), ErrorCode::UnexpectedError, "all-null load");
        }
    } else {
        auto stat = index_.Deserialize(binary_set, config);
        if (stat != knowhere::Status::success)
            ThrowInfo(ErrorCode::UnexpectedError,
                      "failed to Deserialize index: {}",
                      KnowhereStatusString(stat));
        auto dim = index_.Dim();
        SetDim(dim > 0 ? dim : GetDim());
    }
}

template <typename T>
void
VectorMemIndex<T>::Load(const BinarySet& binary_set, const Config& config) {
    milvus::Assemble(const_cast<BinarySet&>(binary_set));
    LoadWithoutAssemble(binary_set, config);
}

template <typename T>
void
VectorMemIndex<T>::Load(milvus::tracer::TraceContext ctx,
                        const Config& config) {
    if (config.contains(MMAP_FILE_PATH)) {
        return LoadFromFile(config);
    }

    auto index_files =
        GetValueFromConfig<std::vector<std::string>>(config, "index_files");
    AssertInfo(index_files.has_value(),
               "index file paths is empty when load index");

    std::unordered_set<std::string> pending_index_files(index_files->begin(),
                                                        index_files->end());

    LOG_INFO("load index files: {}", index_files.value().size());
    std::map<std::string, IndexDataCodec> index_data_codecs{};
    // try to read slice meta first
    std::string slice_meta_filepath;
    for (auto& file : pending_index_files) {
        auto file_name = file.substr(file.find_last_of('/') + 1);
        if (file_name == INDEX_FILE_SLICE_META) {
            slice_meta_filepath = file;
            pending_index_files.erase(file);
            break;
        }
    }

    // start read file span with active scope
    {
        auto read_file_span =
            milvus::tracer::StartSpan("SegCoreReadIndexFile", &ctx);
        opentelemetry::nostd::shared_ptr<opentelemetry::trace::Span>
            read_file_nostd_span(read_file_span);
        auto read_scope =
            opentelemetry::trace::Tracer::WithActiveSpan(read_file_nostd_span);
        LOG_INFO("load with slice meta: {}", !slice_meta_filepath.empty());

        auto load_priority =
            GetValueFromConfig<milvus::proto::common::LoadPriority>(
                config, milvus::LOAD_PRIORITY)
                .value_or(milvus::proto::common::LoadPriority::HIGH);

        if (!slice_meta_filepath
                 .empty()) {  // load with the slice meta info, then we can load batch by batch
            std::string index_file_prefix = slice_meta_filepath.substr(
                0, slice_meta_filepath.find_last_of('/') + 1);

            auto result = file_manager_->LoadIndexToMemory(
                {slice_meta_filepath}, load_priority);
            auto raw_slice_meta = std::move(result[INDEX_FILE_SLICE_META]);
            Config meta_data = Config::parse(std::string(
                reinterpret_cast<const char*>(raw_slice_meta->PayloadData()),
                raw_slice_meta->PayloadSize()));
            for (auto& item : meta_data[META]) {
                std::string prefix = item[NAME];
                int slice_num = item[SLICE_NUM];
                auto total_len = static_cast<size_t>(item[TOTAL_LEN]);

                std::vector<std::string> batch;
                batch.reserve(slice_num);
                for (auto i = 0; i < slice_num; ++i) {
                    std::string file_name = GenSlicedFileName(prefix, i);
                    batch.push_back(index_file_prefix + file_name);
                }

                auto batch_data =
                    file_manager_->LoadIndexToMemory(batch, load_priority);
                int64_t payload_size = 0;
                index_data_codecs.insert({prefix, IndexDataCodec{}});
                auto& index_data_codec = index_data_codecs.at(prefix);
                for (const auto& file_path : batch) {
                    const std::string file_name =
                        file_path.substr(file_path.find_last_of('/') + 1);
                    AssertInfo(batch_data.find(file_name) != batch_data.end(),
                               "lost index slice data: {}",
                               file_name);
                    payload_size += batch_data[file_name]->PayloadSize();
                    index_data_codec.codecs_.push_back(
                        std::move(batch_data[file_name]));
                }
                for (auto& file : batch) {
                    pending_index_files.erase(file);
                }
                AssertInfo(
                    payload_size == total_len,
                    "index len is inconsistent after disassemble and assemble");
                index_data_codec.size_ = payload_size;
            }
        }

        if (!pending_index_files.empty()) {
            auto result = file_manager_->LoadIndexToMemory(
                std::vector<std::string>(pending_index_files.begin(),
                                         pending_index_files.end()),
                load_priority);
            for (auto&& index_data : result) {
                const auto& prefix = index_data.first;
                index_data_codecs.insert({prefix, IndexDataCodec{}});
                auto& index_data_codec = index_data_codecs.at(prefix);
                index_data_codec.size_ = index_data.second->PayloadSize();
                index_data_codec.codecs_.push_back(
                    std::move(index_data.second));
            }
        }

        read_file_span->End();
    }

    LOG_INFO("construct binary set...");
    BinarySet binary_set;
    AssembleIndexDatas(index_data_codecs, binary_set);
    // clear index_data_codecs to free memory early
    index_data_codecs.clear();

    // start engine load index span
    auto span_load_engine =
        milvus::tracer::StartSpan("SegCoreEngineLoadIndex", &ctx);
    opentelemetry::nostd::shared_ptr<opentelemetry::trace::Span>
        nostd_span_load_engine(span_load_engine);
    auto engine_scope =
        opentelemetry::trace::Tracer::WithActiveSpan(nostd_span_load_engine);
    LOG_INFO("load index into Knowhere...");
    LoadWithoutAssemble(binary_set, config);
    span_load_engine->End();
    LOG_INFO("load vector index done");
}

template <typename T>
void
VectorMemIndex<T>::BuildWithDataset(const DatasetPtr& dataset,
                                    const Config& config) {
    knowhere::Json index_config;
    index_config.update(config);

    if (dataset != nullptr && dataset->HasIdMapData() &&
        !index_.GetIdMap().IsEnabled()) {
        index_.GetIdMap().SetType(knowhere::IdMap::Type::SEALED);
    }
    SetDim(dataset->GetDim());
    const auto id_map_only_build =
        GetIdMapOnlyBuildPlan(dataset, elem_type_ != DataType::NONE);
    if (id_map_only_build.empty_embedding_list) {
        empty_emb_list_offsets_ = {0};
    }

    knowhere::TimeRecorder rc("BuildWithoutIds", 1);
    LOG_INFO("start build memory index with KNOWHERE, build_id: {}",
             config.value("build_id", "unknown"));
    auto stat = index_.Build(dataset, index_config, use_knowhere_build_pool_);
    if (stat != knowhere::Status::success)
        ThrowInfo(ErrorCode::IndexBuildError,
                  "failed to build index, {}",
                  KnowhereStatusString(stat));
    rc.ElapseFromBegin("Done");
    LOG_INFO("build memory index with KNOWHERE done, build_id: {}",
             config.value("build_id", "unknown"));
    if (id_map_only_build.enabled) {
        return;
    }
    auto dim = index_.Dim();
    SetDim(dim > 0 ? dim : dataset->GetDim());
}

template <typename T>
void
VectorMemIndex<T>::Build(const Config& config) {
    LOG_INFO("start build memory index, build_id: {}",
             config.value("build_id", "unknown"));
    auto field_datas = file_manager_->CacheRawDataToMemory(config);
    LOG_INFO("CacheRawDataToMemory success, build_id: {}",
             config.value("build_id", "unknown"));
    auto opt_fields = GetValueFromConfig<OptFieldT>(config, VEC_OPT_FIELDS);
    std::unordered_map<int64_t, std::vector<std::vector<uint32_t>>> scalar_info;
    auto is_partition_key_isolation =
        GetValueFromConfig<bool>(config, "partition_key_isolation");
    if (opt_fields.has_value() &&
        index_.IsAdditionalScalarSupported(
            is_partition_key_isolation.value_or(false))) {
        scalar_info = file_manager_->CacheOptFieldToMemory(config);
    }

    Config build_config;
    build_config.update(config);
    build_config.erase(INSERT_FILES_KEY);
    build_config.erase(VEC_OPT_FIELDS);

    bool nullable = false;
    int64_t total_valid_rows = 0;
    int64_t total_num_rows = 0;
    for (const auto& data : field_datas) {
        auto num_rows = data->get_num_rows();
        auto valid_rows = data->get_valid_rows();
        total_valid_rows += valid_rows;
        total_num_rows += num_rows;
        if (data->IsNullable()) {
            nullable = true;
        }
    }
    std::unique_ptr<bool[]> valid_data;
    if (nullable) {
        valid_data.reset(new bool[total_num_rows]);
        int64_t chunk_offset = 0;
        for (const auto& data : field_datas) {
            auto rows = data->get_num_rows();
            // Copy valid data from FieldData (bitmap format to bool array)
            auto src_bitmap = data->ValidData();
            for (int64_t i = 0; i < rows; ++i) {
                valid_data[chunk_offset + i] =
                    (src_bitmap[i >> 3] >> (i & 7)) & 1;
            }
            chunk_offset += rows;
        }
    }
    auto make_dataset = [&](int64_t rows,
                            int64_t dim,
                            const void* tensor,
                            bool is_sparse = false) {
        auto dataset = GenDataset(rows, dim, tensor);
        if (is_sparse) {
            dataset->SetIsSparse(true);
        }
        if (nullable) {
            dataset->SetIdMapData(knowhere::IdMapData::FromValidData(
                valid_data.get(), static_cast<size_t>(total_num_rows)));
        }
        return dataset;
    };

    if (!IndexIsSparse(GetIndexType())) {
        int64_t dim = 0;
        int64_t total_size = 0;
        for (const auto& data : field_datas) {
            AssertInfo(dim == 0 || dim == data->get_dim(),
                       "inconsistent dim value between field datas!");
            dim = data->get_dim();
            if (elem_type_ == DataType::NONE) {
                total_size += data->DataSize();
            } else {
                total_size += data->Size();
            }
        }
        if (nullable && total_valid_rows == 0) {
            auto dataset = make_dataset(0, dim, nullptr);
            BuildWithDataset(dataset, build_config);
            return;
        }
        auto buf = std::shared_ptr<uint8_t[]>(new uint8_t[total_size]);

        size_t lim_offset = 0;
        std::vector<size_t> offsets;

        int64_t offset = 0;
        // For embedding list index, elem_type_ is not NONE
        if (elem_type_ == DataType::NONE) {
            // TODO: avoid copying
            for (auto& data : field_datas) {
                auto valid_size = data->DataSize();
                milvus::fastmem::FastMemcpy(
                    buf.get() + offset, data->Data(), valid_size);
                offset += valid_size;
                data.reset();
            }
        } else {
            offsets.reserve((nullable ? total_valid_rows : total_num_rows) + 1);
            offsets.push_back(lim_offset);
            auto bytes_per_vec = vector_bytes_per_element(elem_type_, dim);
            for (auto& data : field_datas) {
                auto vec_array_data =
                    dynamic_cast<FieldData<VectorArray>*>(data.get());
                AssertInfo(vec_array_data != nullptr,
                           "failed to cast field data to vector array");

                auto rows = vec_array_data->get_num_rows();
                auto data_offset_before = offset;
                int64_t physical_row = 0;
                for (auto i = 0; i < rows; ++i) {
                    if (vec_array_data->IsNullable() &&
                        !vec_array_data->is_valid(i)) {
                        continue;
                    }
                    auto size = vec_array_data->DataSize(physical_row);
                    assert(size % bytes_per_vec == 0);
                    assert(bytes_per_vec != 0);

                    auto vec_array = vec_array_data->value_at(physical_row);

                    if (size > 0) {
                        milvus::fastmem::FastMemcpy(
                            buf.get() + offset, vec_array->data(), size);
                    }
                    offset += size;

                    lim_offset += size / bytes_per_vec;
                    offsets.push_back(lim_offset);
                    physical_row++;
                }

                AssertInfo(data->DataSize() == offset - data_offset_before,
                           "inconsistent vector array data size");

                data.reset();
            }

            const auto total_vectors = static_cast<int64_t>(lim_offset);
            if (total_vectors == 0) {
                if (nullable) {
                    auto dataset = make_dataset(0, dim, nullptr);
                    BuildWithDataset(dataset, build_config);
                } else {
                    empty_emb_list_offsets_ = std::move(offsets);
                    SetDim(dim);
                }
                return;
            }
        }

        field_datas.clear();

        auto rows = elem_type_ == DataType::NONE
                        ? total_valid_rows
                        : static_cast<int64_t>(lim_offset);
        auto dataset = make_dataset(rows, dim, buf.get());
        if (!scalar_info.empty()) {
            dataset->Set(knowhere::meta::SCALAR_INFO, std::move(scalar_info));
        }
        if (!offsets.empty()) {
            dataset->Set(knowhere::meta::EMB_LIST_OFFSET,
                         const_cast<const size_t*>(offsets.data()));
        }
        BuildWithDataset(dataset, build_config);
    } else {
        // sparse
        int64_t dim = 0;
        for (const auto& field_data : field_datas) {
            dim = std::max(
                dim,
                std::dynamic_pointer_cast<FieldData<SparseFloatVector>>(
                    field_data)
                    ->Dim());
        }
        if (nullable && total_valid_rows == 0) {
            auto dataset = make_dataset(0, dim, nullptr, true);
            BuildWithDataset(dataset, build_config);
            return;
        }
        std::vector<knowhere::sparse::SparseRow<SparseValueType>> vec(
            total_valid_rows);
        int64_t offset = 0;
        for (const auto& field_data : field_datas) {
            auto ptr = static_cast<
                const knowhere::sparse::SparseRow<SparseValueType>*>(
                field_data->Data());
            AssertInfo(ptr, "failed to cast field data to sparse rows");
            for (size_t i = 0; i < field_data->get_valid_rows(); ++i) {
                // this does a deep copy of field_data's data.
                // TODO: avoid copying by enforcing field data to give up
                // ownership.
                dim = std::max(dim, static_cast<int64_t>(ptr[i].dim()));
                vec[offset + i] = ptr[i];
            }
            offset += field_data->get_valid_rows();
        }
        auto dataset = make_dataset(total_valid_rows, dim, vec.data(), true);
        if (!scalar_info.empty()) {
            dataset->Set(knowhere::meta::SCALAR_INFO, std::move(scalar_info));
        }
        BuildWithDataset(dataset, build_config);
    }
}

template <typename T>
void
VectorMemIndex<T>::AddWithDataset(const DatasetPtr& dataset,
                                  const Config& config) {
    knowhere::Json index_config;
    index_config.update(config);

    knowhere::TimeRecorder rc("AddWithDataset", 1);
    auto stat = index_.Add(dataset, index_config, use_knowhere_build_pool_);
    if (stat != knowhere::Status::success)
        ThrowInfo(ErrorCode::IndexBuildError,
                  "failed to append index, {}",
                  KnowhereStatusString(stat));
    rc.ElapseFromBegin("Done");
}

template <typename T>
void
VectorMemIndex<T>::Query(const DatasetPtr dataset,
                         const SearchInfo& search_info,
                         const BitsetView& bitset,
                         milvus::OpContext* op_context,
                         SearchResult& search_result) const {
    //    AssertInfo(GetMetricType() == search_info.metric_type_,
    //               "Metric type of field index isn't the same with search info");

    auto num_vectors = dataset->GetRows();
    knowhere::Json search_conf = PrepareSearchParams(search_info);
    auto topk = search_info.topk_;
    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map) || IsEmptyEmbListIndex()) {
        auto offsets =
            dataset->Get<const size_t*>(knowhere::meta::EMB_LIST_OFFSET);
        auto num_queries = dataset->GetRows();
        if (offsets != nullptr) {
            num_queries = dataset->Get<int64_t>(knowhere::meta::NQ);
            AssertInfo(num_queries > 0,
                       "embedding list query count is missing");
            auto total_vectors = static_cast<size_t>(dataset->GetRows());
            AssertInfo(
                offsets[num_queries] == total_vectors,
                "embedding list query offsets are inconsistent with flattened "
                "rows: nq={}, terminal_offset={}, rows={}",
                num_queries,
                offsets[num_queries],
                total_vectors);
        }
        auto total_num = num_queries * topk;
        search_result.seg_offsets_.assign(total_num, INVALID_SEG_OFFSET);
        search_result.distances_.assign(total_num, 0.0F);
        search_result.total_nq_ = num_queries;
        search_result.unity_topK_ = topk;
        return;
    }
    // TODO :: check dim of search data
    auto final = [&] {
        auto index_type = GetIndexType();
        if (CheckAndUpdateKnowhereRangeSearchParam(
                search_info, topk, GetMetricType(), search_conf)) {
            milvus::tracer::AddEvent("start_knowhere_index_range_search");
            auto res =
                index_.RangeSearch(dataset, search_conf, bitset, op_context);
            milvus::tracer::AddEvent("finish_knowhere_index_range_search");
            if (!res.has_value()) {
                ThrowInfo(ErrorCode::UnexpectedError,
                          "failed to range search: {}: {}",
                          KnowhereStatusString(res.error()),
                          res.what());
            }
            auto result = ReGenRangeSearchResult(
                res.value(), topk, num_vectors, GetMetricType());
            milvus::tracer::AddEvent("finish_ReGenRangeSearchResult");
            return result;
        } else {
            milvus::tracer::AddEvent("start_knowhere_index_search");
            auto res = index_.Search(dataset, search_conf, bitset, op_context);
            milvus::tracer::AddEvent("finish_knowhere_index_search");
            if (!res.has_value()) {
                ThrowInfo(
                    ErrorCode::UnexpectedError,
                    // escape json brace in case of using message as format
                    "failed to search: config={} {}: {}",
                    milvus::EscapeBraces(search_conf.dump()),
                    KnowhereStatusString(res.error()),
                    res.what());
            }
            return res.value();
        }
    }();

    auto ids = final->GetIds();
    // In embedding list query, final->GetRows() can be different from dataset->GetRows().
    auto num_queries = final->GetRows();
    float* distances = const_cast<float*>(final->GetDistance());
    final->SetIsOwner(true);
    auto total_num = num_queries * topk;

    search_result.seg_offsets_.resize(total_num);
    search_result.distances_.resize(total_num);
    search_result.total_nq_ = num_queries;
    search_result.unity_topK_ = topk;
    milvus::fastmem::FastMemcpy(
        search_result.seg_offsets_.data(),
        ids,
        total_num * sizeof(*search_result.seg_offsets_.data()));
    milvus::fastmem::FastMemcpy(
        search_result.distances_.data(),
        distances,
        total_num * sizeof(*search_result.distances_.data()));
}

template <typename T>
const bool
VectorMemIndex<T>::HasRawData() const {
    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map) || IsEmptyEmbListIndex()) {
        return true;
    }
    return index_.HasRawData(GetMetricType());
}

template <typename T>
bool
VectorMemIndex<T>::IsIndexRefineEnabled() const {
    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map) || IsEmptyEmbListIndex()) {
        return false;
    }
    return index_.IsIndexRefineEnabled();
}

template <typename T>
std::vector<uint8_t>
VectorMemIndex<T>::GetVector(const DatasetPtr dataset) const {
    auto index_type = GetIndexType();
    if (IndexIsSparse(index_type)) {
        ThrowInfo(ErrorCode::UnexpectedError,
                  "failed to get vector, index is sparse");
    }

    // if dataset is empty, return empty vector
    if (dataset->GetRows() == 0) {
        return {};
    }

    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map)) {
        ThrowInfo(ErrorCode::UnexpectedError,
                  "failed to get vector, nullable vector index contains no "
                  "valid vectors");
    }

    auto res = index_.GetVectorByIds(dataset);
    if (!res.has_value()) {
        ThrowInfo(ErrorCode::UnexpectedError,
                  "failed to get vector, {}",
                  KnowhereStatusString(res.error()));
    }
    return this->template DecodeVectorByIdsResult<T>(res.value());
}

template <typename T>
std::pair<std::vector<uint8_t>, std::vector<size_t>>
VectorMemIndex<T>::GetEmbListByIds(const DatasetPtr dataset,
                                   const std::string& metric_type) const {
    if (dataset->GetRows() == 0) {
        return {{}, {0}};
    }
    if (IsEmptyEmbListIndex()) {
        auto ids = dataset->GetIds();
        auto rows = dataset->GetRows();
        auto emb_list_count =
            static_cast<int64_t>(empty_emb_list_offsets_.size()) - 1;
        CheckEmptyEmbListIds(ids, rows, emb_list_count);
        return {{}, std::vector<size_t>(rows + 1, 0)};
    }

    auto res = index_.GetEmbListByIds(dataset, metric_type);
    if (!res.has_value()) {
        ThrowInfo(
            ErrorCode::UnexpectedError,
            "failed to get emb list, " + KnowhereStatusString(res.error()));
    }
    return this->template DecodeEmbListByIdsResult<T>(res.value());
}

template <typename T>
std::unique_ptr<const knowhere::sparse::SparseRow<SparseValueType>[]>
VectorMemIndex<T>::GetSparseVector(const DatasetPtr dataset) const {
    if (dataset->GetRows() == 0) {
        return nullptr;
    }

    const auto& id_map = GetIdMap();
    if (IsAllNullNullable(id_map)) {
        ThrowInfo(ErrorCode::UnexpectedError,
                  "failed to get vector, nullable vector index contains no "
                  "valid vectors");
    }

    auto res = index_.GetVectorByIds(dataset);
    if (!res.has_value()) {
        ThrowInfo(ErrorCode::UnexpectedError,
                  "failed to get vector, {}",
                  KnowhereStatusString(res.error()));
    }
    // release and transfer ownership to the result unique ptr.
    res.value()->SetIsOwner(false);
    return std::unique_ptr<
        const knowhere::sparse::SparseRow<SparseValueType>[]>(
        static_cast<const knowhere::sparse::SparseRow<SparseValueType>*>(
            res.value()->GetTensor()));
}

template <typename T>
void
VectorMemIndex<T>::LoadFromFile(const Config& config) {
    auto local_filepath =
        GetValueFromConfig<std::string>(config, MMAP_FILE_PATH);
    AssertInfo(local_filepath.has_value(),
               "mmap filepath is empty when load index");

    std::filesystem::create_directories(
        std::filesystem::path(local_filepath.value()).parent_path());

    auto load_priority =
        GetValueFromConfig<milvus::proto::common::LoadPriority>(
            config, milvus::LOAD_PRIORITY)
            .value_or(milvus::proto::common::LoadPriority::HIGH);
    auto is_embedding_list = (elem_type_ != DataType::NONE);
    std::unique_ptr<storage::FileWriter> embedding_list_meta_writer_ptr =
        nullptr;
    std::unique_ptr<storage::FileWriter> embedding_list_raw_index_writer_ptr =
        nullptr;
    auto embedding_list_meta_path =
        GetValueFromConfig<std::string>(config, EMB_LIST_META_PATH);
    auto embedding_list_raw_index_path =
        GetValueFromConfig<std::string>(config, EMB_LIST_RAW_INDEX_PATH);
    if (is_embedding_list) {
        AssertInfo(embedding_list_meta_path.has_value(),
                   "emb list meta mmap filepath is empty when load index");
        std::filesystem::create_directories(
            std::filesystem::path(embedding_list_meta_path.value())
                .parent_path());
        embedding_list_meta_writer_ptr = std::make_unique<storage::FileWriter>(
            embedding_list_meta_path.value());
        if (embedding_list_raw_index_path.has_value()) {
            std::filesystem::create_directories(
                std::filesystem::path(embedding_list_raw_index_path.value())
                    .parent_path());
            embedding_list_raw_index_writer_ptr =
                std::make_unique<storage::FileWriter>(
                    embedding_list_raw_index_path.value());
        }
    }

    auto file_writer = storage::FileWriter(
        local_filepath.value(),
        storage::io::GetPriorityFromLoadPriority(load_priority));

    auto index_files =
        GetValueFromConfig<std::vector<std::string>>(config, "index_files");
    AssertInfo(index_files.has_value(),
               "index file paths is empty when load index");

    std::unordered_set<std::string> pending_index_files(index_files->begin(),
                                                        index_files->end());

    LOG_INFO("load index files: {}", index_files.value().size());

    auto parallel_degree =
        static_cast<uint64_t>(DEFAULT_FIELD_MAX_MEMORY_LIMIT / FILE_SLICE_SIZE);

    // try to read slice meta first
    std::string slice_meta_filepath;
    for (auto& idx_filepath : pending_index_files) {
        auto file_name =
            idx_filepath.substr(idx_filepath.find_last_of('/') + 1);
        if (file_name == INDEX_FILE_SLICE_META) {
            slice_meta_filepath = idx_filepath;
            pending_index_files.erase(idx_filepath);
            break;
        }
    }

    LOG_INFO("load with slice meta: {}", !slice_meta_filepath.empty());
    std::chrono::duration<double> load_duration_sum;
    std::chrono::duration<double> write_disk_duration_sum;
    std::unique_ptr<storage::DataCodec> valid_data_count_codec;
    std::unique_ptr<storage::DataCodec> valid_data_codec;
    std::unique_ptr<storage::DataCodec> empty_emb_list_offsets_codec;
    std::map<std::string, IndexDataCodec> deferred_index_data_codecs;
    bool wrote_index_data = false;
    auto DeferIndexData = [&](const std::string& prefix,
                              std::unique_ptr<storage::DataCodec>& index_data) {
        auto& codec = deferred_index_data_codecs[prefix];
        codec.size_ += index_data->PayloadSize();
        codec.codecs_.push_back(std::move(index_data));
    };
    auto AssembleDeferredIndexData =
        [&](const std::string& prefix) -> std::unique_ptr<storage::DataCodec> {
        auto it = deferred_index_data_codecs.find(prefix);
        if (it == deferred_index_data_codecs.end()) {
            return nullptr;
        }
        return AssembleIndexDataCodec(std::move(it->second));
    };
    // load files in two parts:
    // 1. Emb-list sidecar files: written separately so knowhere can mmap them.
    // 2. All other binaries: Merged and written to file_writer, forming a unified index file for knowhere.
    auto WriteIndexData = [&](const std::string& prefix,
                              std::unique_ptr<storage::DataCodec>& index_data) {
        if (prefix == knowhere::meta::EMB_LIST_META &&
            embedding_list_meta_writer_ptr) {
            embedding_list_meta_writer_ptr->Write(index_data->PayloadData(),
                                                  index_data->PayloadSize());
        } else if (prefix == knowhere::meta::EMB_LIST_RAW_INDEX) {
            AssertInfo(embedding_list_raw_index_writer_ptr,
                       "emb list raw index mmap filepath is empty when load "
                       "index");
            embedding_list_raw_index_writer_ptr->Write(
                index_data->PayloadData(), index_data->PayloadSize());
        } else if (prefix == VALID_DATA_COUNT_KEY) {
            DeferIndexData(prefix, index_data);
        } else if (prefix == VALID_DATA_KEY) {
            DeferIndexData(prefix, index_data);
        } else if (prefix == EMPTY_EMB_LIST_OFFSET_KEY) {
            DeferIndexData(prefix, index_data);
        } else {
            file_writer.Write(index_data->PayloadData(),
                              index_data->PayloadSize());
            wrote_index_data = true;
        }
    };

    if (!slice_meta_filepath
             .empty()) {  // load with the slice meta info, then we can load batch by batch
        std::string index_file_prefix = slice_meta_filepath.substr(
            0, slice_meta_filepath.find_last_of('/') + 1);
        std::vector<std::string> batch{};
        batch.reserve(parallel_degree);

        auto result = file_manager_->LoadIndexToMemory({slice_meta_filepath},
                                                       load_priority);
        auto raw_slice_meta = std::move(result[INDEX_FILE_SLICE_META]);
        Config meta_data = Config::parse(std::string(
            reinterpret_cast<const char*>(raw_slice_meta->PayloadData()),
            raw_slice_meta->PayloadSize()));

        for (auto& item : meta_data[META]) {
            std::string prefix = item[NAME];
            int slice_num = item[SLICE_NUM];
            auto HandleBatch = [&](int index) {
                auto start_load2_mem = std::chrono::system_clock::now();
                auto batch_data =
                    file_manager_->LoadIndexToMemory(batch, load_priority);
                load_duration_sum +=
                    (std::chrono::system_clock::now() - start_load2_mem);
                for (int j = index - batch.size() + 1; j <= index; j++) {
                    std::string file_name = GenSlicedFileName(prefix, j);
                    AssertInfo(batch_data.find(file_name) != batch_data.end(),
                               "lost index slice data");
                    auto&& data = batch_data[file_name];
                    auto start_write_file = std::chrono::system_clock::now();
                    WriteIndexData(prefix, data);
                    write_disk_duration_sum +=
                        (std::chrono::system_clock::now() - start_write_file);
                }
                for (auto& file : batch) {
                    pending_index_files.erase(file);
                }
                batch.clear();
            };

            for (auto i = 0; i < slice_num; ++i) {
                std::string file_name = GenSlicedFileName(prefix, i);
                batch.push_back(index_file_prefix + file_name);
                if (batch.size() >= parallel_degree) {
                    HandleBatch(i);
                }
            }
            if (batch.size() > 0) {
                HandleBatch(slice_num - 1);
            }
        }
    }
    if (!pending_index_files.empty()) {
        //1. load files into memory
        auto start_load_files2_mem = std::chrono::system_clock::now();
        auto result = file_manager_->LoadIndexToMemory(
            std::vector<std::string>(pending_index_files.begin(),
                                     pending_index_files.end()),
            load_priority);
        load_duration_sum +=
            (std::chrono::system_clock::now() - start_load_files2_mem);
        //2. write data into files
        auto start_write_file = std::chrono::system_clock::now();
        for (auto& [prefix, index_data] : result) {
            WriteIndexData(prefix, index_data);
        }
        write_disk_duration_sum +=
            (std::chrono::system_clock::now() - start_write_file);
    }
    valid_data_count_codec = AssembleDeferredIndexData(VALID_DATA_COUNT_KEY);
    valid_data_codec = AssembleDeferredIndexData(VALID_DATA_KEY);
    empty_emb_list_offsets_codec =
        AssembleDeferredIndexData(EMPTY_EMB_LIST_OFFSET_KEY);
    milvus::monitor::internal_storage_download_duration.Observe(
        std::chrono::duration_cast<std::chrono::milliseconds>(load_duration_sum)
            .count());
    milvus::monitor::internal_storage_write_disk_duration.Observe(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            write_disk_duration_sum)
            .count());
    file_writer.Finish();
    if (embedding_list_meta_writer_ptr) {
        embedding_list_meta_writer_ptr->Finish();
    }
    if (embedding_list_raw_index_writer_ptr) {
        embedding_list_raw_index_writer_ptr->Finish();
    }

    auto conf = config;
    conf.erase(MMAP_FILE_PATH);
    conf[ENABLE_MMAP] = true;
    if (is_embedding_list) {
        conf[EMB_LIST_META_PATH] = embedding_list_meta_path.value();
        if (embedding_list_raw_index_path.has_value()) {
            conf[EMB_LIST_RAW_INDEX_PATH] =
                embedding_list_raw_index_path.value();
        }
    }
    auto restore_id_map = [&]() -> RestoredIdMap {
        if (!valid_data_count_codec && !valid_data_codec) {
            return {};
        }
        AssertInfo(valid_data_count_codec && valid_data_codec,
                   "nullable vector index valid_data files are incomplete");
        return RestoreIdMapFromValidDataPayload(
            index_.GetIdMap(),
            valid_data_count_codec->PayloadData(),
            valid_data_count_codec->PayloadSize(),
            valid_data_codec->PayloadData(),
            valid_data_codec->PayloadSize(),
            &conf,
            std::filesystem::path(local_filepath.value())
                .parent_path()
                .string());
    };
    const auto restored_id_map = restore_id_map();

    auto start_deserialize = std::chrono::system_clock::now();
    std::chrono::duration<double> deserialize_duration{};
    if (wrote_index_data) {
        LOG_INFO("load index into Knowhere...");
        auto stat = index_.DeserializeFromFile(local_filepath.value(), conf);
        deserialize_duration =
            std::chrono::system_clock::now() - start_deserialize;
        if (stat != knowhere::Status::success) {
            ThrowInfo(ErrorCode::UnexpectedError,
                      "failed to Deserialize index: {}",
                      KnowhereStatusString(stat));
        }
        this->SetDim(index_.Dim());
    } else if (empty_emb_list_offsets_codec) {
        LOG_INFO("load empty emb_list vector index metadata only...");
        auto empty_emb_list_state = LoadEmptyEmbListOffsetsFromPayload(
            empty_emb_list_offsets_codec->PayloadData(),
            static_cast<size_t>(empty_emb_list_offsets_codec->PayloadSize()));
        this->SetDim(empty_emb_list_state.dim);
        empty_emb_list_offsets_ = std::move(empty_emb_list_state.offsets);
        if (restored_id_map.has_valid_data) {
            FinalizeRestoredIdMap(index_.Node(),
                                  ErrorCode::UnexpectedError,
                                  "empty emb-list mmap load");
        }
    } else {
        LOG_INFO("load all-null nullable vector index valid data only...");
        AssertInfo(valid_data_count_codec && valid_data_codec,
                   "nullable vector index valid_data files are incomplete");
        if (conf.contains(DIM_KEY)) {
            this->SetDim(GetDimFromConfig(conf));
        }
        if (restored_id_map.has_valid_data) {
            FinalizeRestoredIdMap(index_.Node(),
                                  ErrorCode::UnexpectedError,
                                  "all-null mmap load");
        }
    }
    milvus::monitor::internal_storage_deserialize_duration.Observe(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            deserialize_duration)
            .count());

    this->mmap_file_raii_ =
        std::make_unique<MmapFileRAII>(local_filepath.value());
    LOG_INFO(
        "load vector index done, mmap_file_path:{}, download_duration:{}, "
        "write_files_duration:{}, deserialize_duration:{}",
        local_filepath.value(),
        std::chrono::duration_cast<std::chrono::milliseconds>(load_duration_sum)
            .count(),
        std::chrono::duration_cast<std::chrono::milliseconds>(
            write_disk_duration_sum)
            .count(),
        std::chrono::duration_cast<std::chrono::milliseconds>(
            deserialize_duration)
            .count());
}

template <typename T>
knowhere::expected<knowhere::DataSetPtr>
VectorMemIndex<T>::CalcDistByIDs(const knowhere::DataSetPtr query_dataset,
                                 const BitsetView& bitset,
                                 const int64_t* labels,
                                 size_t labels_len,
                                 bool is_cosine,
                                 milvus::OpContext* op_context) const {
    return index_.CalcDistByIDs(
        query_dataset, bitset, labels, labels_len, is_cosine, op_context);
}

template class VectorMemIndex<float>;
template class VectorMemIndex<bin1>;
template class VectorMemIndex<float16>;
template class VectorMemIndex<bfloat16>;
template class VectorMemIndex<int8>;
template class VectorMemIndex<sparse_u32_f32>;

}  // namespace milvus::index
