use core::slice;
use std::sync::Arc;

use futures::executor::block_on;
use libc::c_char;
use log::info;
use tantivy::indexer::UserOperation;
use tantivy::schema::{
    Field, IndexRecordOption, NumericOptions, Schema, SchemaBuilder, TextFieldIndexing,
    TextOptions, FAST, STRING,
};
use tantivy::{doc, Index, IndexWriter, TantivyDocument};

use crate::convert_to_rust_slice;
use crate::data_type::TantivyDataType;

use crate::error::{Result, TantivyBindingError};
use crate::index_reader::IndexReaderWrapper;
use crate::index_reader_c::SetBitsetFn;
use crate::index_writer::TantivyValue;
use crate::util::{c_ptr_to_str, ptr_len_to_str};

#[inline]
pub(crate) fn schema_builder_add_field(
    schema_builder: &mut SchemaBuilder,
    field_name: &str,
    data_type: TantivyDataType,
) -> Field {
    match data_type {
        TantivyDataType::I64 => {
            schema_builder.add_i64_field(field_name, NumericOptions::default().set_indexed())
        }
        TantivyDataType::F64 => {
            schema_builder.add_f64_field(field_name, NumericOptions::default().set_indexed())
        }
        TantivyDataType::Bool => {
            schema_builder.add_bool_field(field_name, NumericOptions::default().set_indexed())
        }
        TantivyDataType::Keyword => {
            let text_field_indexing = TextFieldIndexing::default()
                .set_tokenizer("raw")
                .set_fieldnorms(false)
                .set_index_option(IndexRecordOption::Basic);
            let text_options = TextOptions::default().set_indexing_options(text_field_indexing);
            schema_builder.add_text_field(field_name, text_options)
        }
        TantivyDataType::Text => {
            panic!("text should be indexed with analyzer");
        }
        TantivyDataType::JSON => schema_builder.add_json_field(&field_name, STRING | FAST),
    }
}

impl TantivyValue<TantivyDocument> for i64 {
    #[inline]
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_i64(Field::from_field_id(field), *self);
    }
}

impl TantivyValue<TantivyDocument> for u64 {
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_u64(Field::from_field_id(field), *self);
    }
}

impl TantivyValue<TantivyDocument> for f64 {
    #[inline]
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_f64(Field::from_field_id(field), *self);
    }
}

impl TantivyValue<TantivyDocument> for &str {
    #[inline]
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_text(Field::from_field_id(field), *self);
    }
}

impl TantivyValue<TantivyDocument> for bool {
    #[inline]
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_bool(Field::from_field_id(field), *self);
    }
}

impl TantivyValue<TantivyDocument> for serde_json::Value {
    #[inline]
    fn add_to_document(&self, field: u32, document: &mut TantivyDocument) {
        document.add_field_value(Field::from_field_id(field), self);
    }
}

pub struct IndexWriterWrapperImpl {
    pub(crate) field: Field,
    pub(crate) index_writer: IndexWriter,
    pub(crate) index: Arc<Index>,
    pub(crate) id_field: Option<Field>,
    pub(crate) enable_user_specified_doc_id: bool,
    pub(crate) enable_background_merge: bool,
}

impl IndexWriterWrapperImpl {
    pub fn new(
        field_name: &str,
        data_type: TantivyDataType,
        path: String,
        num_threads: usize,
        overall_memory_budget_in_bytes: usize,
        enable_user_specified_doc_id: bool,
        enable_background_merge: bool,
    ) -> Result<IndexWriterWrapperImpl> {
        info!(
            "create index writer, field_name: {}, data_type: {:?}, tantivy_index_version 7, enable_background_merge: {}",
            field_name, data_type, enable_background_merge
        );
        let mut schema_builder = Schema::builder();
        let field = schema_builder_add_field(&mut schema_builder, field_name, data_type);
        let id_field = if enable_user_specified_doc_id {
            schema_builder.enable_user_specified_doc_id();
            None
        } else {
            Some(schema_builder.add_i64_field("doc_id", FAST))
        };
        let schema = schema_builder.build();
        let index = Index::create_in_dir(path.clone(), schema)?;
        let index_writer =
            index.writer_with_num_threads(num_threads, overall_memory_budget_in_bytes)?;
        if !enable_background_merge {
            // Sealed index builds end with an explicit merge-all in finish();
            // background policy-driven merges would only waste IO and race
            // with it, so disable them entirely for build-mode writers.
            index_writer.set_merge_policy(Box::new(tantivy::merge_policy::NoMergePolicy));
        }
        Ok(IndexWriterWrapperImpl {
            field,
            index_writer,
            index: Arc::new(index),
            id_field,
            enable_user_specified_doc_id,
            enable_background_merge,
        })
    }

    pub fn create_reader(&self, set_bitset: SetBitsetFn) -> Result<IndexReaderWrapper> {
        IndexReaderWrapper::from_index(self.index.clone(), set_bitset)
    }

    #[inline]
    fn add_document(&mut self, mut document: TantivyDocument, offset: u32) -> Result<()> {
        if self.enable_user_specified_doc_id {
            self.index_writer
                .add_document_with_doc_id(offset as u32, document)?;
        } else {
            document.add_i64(self.id_field.unwrap(), offset as i64);
            self.index_writer.add_document(document)?;
        }
        Ok(())
    }

    pub fn add<T: TantivyValue<TantivyDocument>>(&mut self, data: T, offset: u32) -> Result<()> {
        let mut document = TantivyDocument::default();
        data.add_to_document(self.field.field_id(), &mut document);

        self.add_document(document, offset)
    }

    pub fn add_array<T: TantivyValue<TantivyDocument>, I>(
        &mut self,
        data: I,
        offset: u32,
    ) -> Result<()>
    where
        I: IntoIterator<Item = T>,
    {
        let mut document = TantivyDocument::default();
        data.into_iter()
            .for_each(|d| d.add_to_document(self.field.field_id(), &mut document));

        self.add_document(document, offset)
    }

    pub fn add_array_keywords(&mut self, datas: &[*const c_char], offset: u32) -> Result<()> {
        let mut document = TantivyDocument::default();
        for element in datas {
            let data = c_ptr_to_str(*element)?;
            document.add_field_value(self.field, data);
        }

        self.add_document(document, offset)
    }

    pub fn add_array_keywords_with_len(
        &mut self,
        ptrs: &[*const u8],
        lens: &[usize],
        offset: u32,
    ) -> Result<()> {
        debug_assert_eq!(ptrs.len(), lens.len());
        let mut document = TantivyDocument::default();
        for i in 0..ptrs.len() {
            let data = ptr_len_to_str(ptrs[i], lens[i])?;
            document.add_field_value(self.field, data);
        }

        self.add_document(document, offset)
    }

    pub fn add_json(&mut self, data: &str, offset: u32) -> Result<()> {
        let j = serde_json::from_str::<serde_json::Value>(data)?;
        let mut document = TantivyDocument::default();
        j.add_to_document(self.field.field_id(), &mut document);

        self.add_document(document, offset)
    }

    /// Batch add multiple JSON documents, each as a separate document with sequential offsets.
    pub fn add_json_batch(&mut self, datas: &[*const c_char], offset_begin: u32) -> Result<()> {
        for (i, &data_ptr) in datas.iter().enumerate() {
            let data = c_ptr_to_str(data_ptr)?;
            let j = serde_json::from_str::<serde_json::Value>(data)?;
            let mut document = TantivyDocument::default();
            j.add_to_document(self.field.field_id(), &mut document);
            self.add_document(document, offset_begin + i as u32)?;
        }
        Ok(())
    }

    pub fn add_array_json(&mut self, datas: &[*const c_char], offset: u32) -> Result<()> {
        let mut document = TantivyDocument::default();
        for element in datas {
            let data = c_ptr_to_str(*element)?;
            let j = serde_json::from_str::<serde_json::Value>(data)?;
            j.add_to_document(self.field.field_id(), &mut document);
        }

        self.add_document(document, offset)
    }

    /// Add json key stats - adds documents one by one
    /// Tantivy's IndexWriter has internal buffering, so external batching is unnecessary
    pub fn add_json_key_stats(
        &mut self,
        keys: &[*const c_char],
        json_offsets: &[*const i64],
        json_offsets_len: &[usize],
    ) -> Result<()> {
        let id_field = self.id_field.unwrap();

        for i in 0..keys.len() {
            let key = c_ptr_to_str(keys[i])
                .map_err(|e| TantivyBindingError::InternalError(e.to_string()))?;

            let offsets = unsafe { convert_to_rust_slice!(json_offsets[i], json_offsets_len[i]) };

            for offset in offsets {
                self.index_writer.add_document(doc!(
                    id_field => *offset,
                    self.field => key,
                ))?;
            }
        }

        Ok(())
    }

    pub fn manual_merge(&mut self) -> Result<()> {
        let metas = self.index_writer.index().searchable_segment_metas()?;
        let policy = self.index_writer.get_merge_policy();
        let candidates = policy.compute_merge_candidates(metas.as_slice());
        for candidate in candidates {
            self.index_writer.merge(candidate.0.as_slice()).wait()?;
        }
        Ok(())
    }

    pub fn finish(mut self) -> Result<()> {
        self.index_writer.commit()?;

        if !self.enable_background_merge {
            // Build-mode writers use NoMergePolicy (set in new()), so no
            // background merge can race this explicit merge-all. Collapse the
            // auto-flushed segments into a single one. Background-merge writers
            // (e.g. growing segments) are left to their own policy and are not
            // forced to a single segment here.
            let segment_ids = self.index.searchable_segment_ids()?;
            if segment_ids.len() > 1 {
                self.index_writer.merge(&segment_ids).wait()?;
            }
        }
        block_on(self.index_writer.garbage_collect_files())?;
        self.index_writer.wait_merging_threads()?;

        // TODO: remove this log when #45590 is solved
        let metas = self.index.searchable_segment_metas()?;
        let segment_ids: Vec<_> = metas.iter().map(|m| m.id().uuid_string()).collect();
        info!("tantivy index_writer finish, segments: {:?}", segment_ids);

        Ok(())
    }

    pub(crate) fn commit(&mut self) -> Result<()> {
        self.index_writer.commit()?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use tantivy::Index;
    use tempfile::TempDir;

    use super::IndexWriterWrapperImpl;
    use crate::data_type::TantivyDataType;

    // tantivy's smallest per-thread arena (MEMORY_BUDGET_NUM_BYTES_MIN = 15 MB).
    // With a single indexing thread this is tight enough that the doc count below
    // spills into several auto-flushed segments before the finish-time commit,
    // which is exactly the multi-segment build this test needs to exercise.
    const MIN_MEMORY_BUDGET: usize = 15_000_000;
    const NUM_DOCS: i64 = 1_000_000;

    fn build_i64_writer(path: &str, enable_background_merge: bool) -> IndexWriterWrapperImpl {
        IndexWriterWrapperImpl::new(
            "number",
            TantivyDataType::I64,
            path.to_string(),
            1, // single thread -> smallest arena -> forces multiple flushed segments
            MIN_MEMORY_BUDGET,
            false, // enable_user_specified_doc_id
            enable_background_merge,
        )
        .unwrap()
    }

    /// A build-mode (enable_background_merge == false) V7 writer must collapse the
    /// auto-flushed segments into exactly one searchable segment in finish().
    ///
    /// Regression guard for the finish-time merge-all (issue #51054): the V7 writer
    /// previously shipped sealed indexes as many ~15 MB segments, and if the merge
    /// is ever dropped again the index silently regresses to multi-segment with only
    /// perf/logs to reveal it. The precondition assert keeps the test honest — it
    /// proves the workload really produced >1 segment before finish() merged them.
    #[test]
    fn test_sealed_build_finishes_single_segment() {
        let dir = TempDir::new().unwrap();
        let mut writer = build_i64_writer(dir.path().to_str().unwrap(), false);
        for i in 0..NUM_DOCS {
            writer.add::<i64>(i, i as u32).unwrap();
        }
        writer.commit().unwrap();

        // Precondition: the build workload genuinely auto-flushes multiple segments,
        // so the single-segment assertion after finish() is meaningful.
        let before = writer.index.searchable_segment_metas().unwrap();
        assert!(
            before.len() > 1,
            "expected the build workload to auto-flush multiple segments, got {}",
            before.len()
        );

        // finish() on a build-mode writer must merge them down to exactly one.
        writer.finish().unwrap();

        let index = Index::open_in_dir(dir.path()).unwrap();
        let after = index.searchable_segment_metas().unwrap();
        assert_eq!(
            after.len(),
            1,
            "sealed build must produce exactly one tantivy segment, got {}",
            after.len()
        );
    }
}
