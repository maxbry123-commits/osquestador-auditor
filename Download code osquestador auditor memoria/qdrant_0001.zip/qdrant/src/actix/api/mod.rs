use collection::shards::shard::ShardId;
use common::validation::{validate_collection_name, validate_collection_name_legacy};
use serde::Deserialize;
use validator::Validate;

pub mod audit_api;
pub mod cluster_api;
pub mod collections_api;
pub mod count_api;
pub mod debug_api;
pub mod discover_api;
pub mod facet_api;
pub mod issues_api;
pub mod local_shard_api;
pub mod profiler_api;
pub mod query_api;
pub mod quota_api;
pub mod read_params;
pub mod recommend_api;
pub mod retrieve_api;
pub mod routing_token;
pub mod search_api;
pub mod service_api;
pub mod shards_api;
pub mod snapshot_api;
pub mod update_api;
pub mod vector_name_api;

/// A collection path with stricter validation
///
/// Validation for collection paths has been made more strict over time.
/// To prevent breaking changes on existing collections, this is only enforced for newly created
/// collections. Basic validation is enforced everywhere else.
#[derive(Deserialize, Validate)]
struct StrictCollectionPath {
    #[validate(
        length(min = 1, max = 255),
        custom(function = "validate_collection_name")
    )]
    collection_name: String,
}

/// A collection path with basic validation
///
/// Validation for collection paths has been made more strict over time.
/// To prevent breaking changes on existing collections, this is only enforced for newly created
/// collections. Basic validation is enforced everywhere else.
#[derive(Deserialize, Validate)]
struct CollectionPath {
    #[validate(
        length(min = 1, max = 255),
        custom(function = "validate_collection_name_legacy")
    )]
    collection_name: String,
}

/// Collection + snapshot name path with basic collection name validation.
#[derive(Deserialize, Validate)]
struct CollectionSnapshotPath {
    #[validate(
        length(min = 1, max = 255),
        custom(function = "validate_collection_name_legacy")
    )]
    collection_name: String,
    snapshot_name: String,
}

/// Collection + shard path with basic collection name validation.
#[derive(Deserialize, Validate)]
struct CollectionShardPath {
    #[validate(
        length(min = 1, max = 255),
        custom(function = "validate_collection_name_legacy")
    )]
    collection_name: String,
    shard: ShardId,
}

/// Collection + shard + snapshot path with basic collection name validation.
#[derive(Deserialize, Validate)]
struct CollectionShardSnapshotPath {
    #[validate(
        length(min = 1, max = 255),
        custom(function = "validate_collection_name_legacy")
    )]
    collection_name: String,
    shard: ShardId,
    snapshot: String,
}
