#![expect(dead_code)]

use api::rest::models::{CollectionsResponse, ShardKeysResponse, Usage, VersionInfo};
use api::rest::schema::PointInsertOperations;
use api::rest::{
    FacetRequest, FacetResponse, QueryGroupsRequest, QueryRequest, QueryRequestBatch,
    QueryResponse, Record, ScoredPoint, SearchMatrixOffsetsResponse, SearchMatrixPairsResponse,
    SearchMatrixRequest, UpdateVectors,
};
use collection::operations::cluster_ops::ClusterOperations;
use collection::operations::consistency_params::ReadConsistency;
use collection::operations::payload_ops::{DeletePayload, SetPayload};
use collection::operations::point_ops::{PointsSelector, WriteOrdering};
use collection::operations::snapshot_ops::{
    ShardSnapshotRecover, SnapshotDescription, SnapshotRecover,
};
use collection::operations::types::{
    AliasDescription, CollectionClusterInfo, CollectionExistence, CollectionInfo,
    CollectionsAliasesResponse, CountRequest, CountResult, GroupsResult, PointGroup, PointRequest,
    ScrollRequest, ScrollResult, UpdateResult,
};
use collection::operations::vector_ops::DeleteVectors;
use schemars::JsonSchema;
use schemars::r#gen::SchemaSettings;
use serde::Serialize;
use shard::operations::optimization::OptimizationsResponse;
use storage::content_manager::collection_meta_ops::{
    ChangeAliasesOperation, CreateCollection, UpdateCollection,
};
use storage::quota::QuotaStatus;
use storage::types::ClusterStatus;

use crate::common::telemetry::TelemetryData;
use crate::common::telemetry_ops::distributed_telemetry::DistributedTelemetryData;
use crate::common::update::{CreateFieldIndex, UpdateOperations};

mod actix;
mod common;
mod settings;
mod tracing;

#[derive(Serialize, JsonSchema)]
struct AllDefinitions {
    a1: CollectionsResponse,
    a2: CollectionInfo,
    // a3: CollectionMetaOperations,
    a4: PointRequest,
    a5: Record,
    a7: ScoredPoint,
    a8: UpdateResult,
    ab: ScrollRequest,
    ac: ScrollResult,
    ad: CreateCollection,
    ae: UpdateCollection,
    af: ChangeAliasesOperation,
    ag: CreateFieldIndex,
    ah: PointsSelector,
    ai: PointInsertOperations,
    aj: SetPayload,
    ak: DeletePayload,
    al: ClusterStatus,
    am: SnapshotDescription,
    an: CountRequest,
    ao: CountResult,
    ap: CollectionClusterInfo,
    aq: TelemetryData,
    ar: ClusterOperations,
    aw: SnapshotRecover,
    ax: CollectionsAliasesResponse,
    ay: AliasDescription,
    az: WriteOrdering,
    b1: ReadConsistency,
    b2: UpdateVectors,
    b3: DeleteVectors,
    b4: PointGroup,
    b7: GroupsResult,
    b8: UpdateOperations,
    b9: ShardSnapshotRecover,
    bc: VersionInfo,
    bd: CollectionExistence,
    be: QueryRequest,
    bf: QueryRequestBatch,
    bg: QueryResponse,
    bh: QueryGroupsRequest,
    bi: SearchMatrixRequest,
    bj: SearchMatrixOffsetsResponse,
    bk: SearchMatrixPairsResponse,
    bl: FacetRequest,
    bm: FacetResponse,
    bn: Usage,
    bo: ShardKeysResponse,
    bp: OptimizationsResponse,
    bq: DistributedTelemetryData,
    br: segment::data_types::vector_name_config::VectorNameConfig,
    bs: QuotaStatus,
}

fn save_schema<T: JsonSchema>() {
    let settings = SchemaSettings::draft07();
    let generator = settings.into_generator();
    let schema = generator.into_root_schema_for::<T>();
    let schema_str = serde_json::to_string_pretty(&schema).unwrap();
    println!("{schema_str}")
}

fn main() {
    save_schema::<AllDefinitions>();
}
