//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	"errors"
	"fmt"
	"io"
	"maps"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"regexp"
	"slices"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/assert"
	mock "github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/weaviate/weaviate/adapters/clients"
	"github.com/weaviate/weaviate/cluster/router/types"
	"github.com/weaviate/weaviate/entities/aggregation"
	enterrors "github.com/weaviate/weaviate/entities/errors"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/entities/storagestate"
	esync "github.com/weaviate/weaviate/entities/sync"
	"github.com/weaviate/weaviate/usecases/cluster"
	"github.com/weaviate/weaviate/usecases/monitoring"
	"github.com/weaviate/weaviate/usecases/replica"
	schemaUC "github.com/weaviate/weaviate/usecases/schema"
	"github.com/weaviate/weaviate/usecases/sharding"
)

func TestIndex_aggregateCount(t *testing.T) {
	logger, _ := test.NewNullLogger()
	metrics, err := NewMetrics(logger, monitoring.GetMetrics(), "Abc", "n/a")
	require.NoError(t, err, "create index metrics")

	replicaMetrics, err := replica.NewMetrics(monitoring.GetMetrics())
	require.NoError(t, err, "create replica metrics")

	shardRegex := regexp.MustCompile(`\/shards\/([^\/]*)`)
	addReplicas := func(t *testing.T, id int, shards map[string]int) []types.Replica {
		t.Helper()
		srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			groups := shardRegex.FindStringSubmatch(r.URL.Path)
			count := shards[groups[1]]
			if count < 0 { // sentinel: this replica cannot serve that shard
				w.WriteHeader(http.StatusInternalServerError)
				return
			}
			io.WriteString(w, strconv.Itoa(count))
		}))
		t.Cleanup(srv.Close)

		var replicas []types.Replica
		for name := range shards {
			replicas = append(replicas, types.Replica{
				NodeName:  fmt.Sprintf("node-%d", id),
				HostAddr:  srv.URL[7:],
				ShardName: name,
			})
		}
		return replicas
	}

	// Each test case will spin up N test HTTP servers, where N=len(counts).
	// Each server mocks a replica and reports its counts[i].
	// To simplify the setup, we assume the test collection "Abc" is
	// fully contained within a single shard "abc" if tt.nodes is nil.
	// Otherwise [tt.nodes] defines the counts for each shard and [tt.shards]
	// defines all shards belonging to "Abc".
	// The aggregation requests satisfies [aggregate.IsCountStar], so we expect
	// each of the replicas to be queried and their results "averaged".
	for _, tt := range []struct {
		name   string // Test case name
		counts []int  // Counts reported by each replica.

		nodes  []map[string]int // Per-shard count in each node.
		shards []string         // Complete list of shards in collection.
		tenant string

		planErr error         // Error the collection-wide routing plan build fails with.
		timeout time.Duration // Caller deadline; zero for none.

		want    int    // Expected aggregated count
		wantErr string // Substring the aggregation must fail with; empty if it must succeed
	}{
		{
			name:   "consistent count",
			counts: []int{92, 92, 92},
			want:   92,
		},
		{
			name:   "mode (2/3 replicas agree)",
			counts: []int{92, 13, 92},
			want:   92,
		},
		{
			name:   "median (3 replicas disagree)",
			counts: []int{80085, 33, 92},
			want:   92,
		},
		{
			name:   "shifted median (4 replicas disagree)",
			counts: []int{1, 2, 3, 4},
			want:   3,
		},
		{
			name:   "multiple shards",
			shards: []string{"abc", "xyz"},
			nodes: []map[string]int{
				{
					"abc": 1,
					"xyz": 2,
				},
				{
					"abc": 1,
					"xyz": 2,
				},
			},
			want: 3,
		},
		{
			name: "counts above MaxInt32",
			nodes: []map[string]int{
				{"abc": 1200000000, "xyz": 1000000000},
				{"abc": 1200000000, "xyz": 1000000000},
			},
			want: 2200000000,
		},
		{
			name: "a failing routing plan",
			nodes: []map[string]int{
				{"abc": 1, "xyz": 2},
				{"abc": 1, "xyz": 2},
			},
			planErr: errors.New("no read replica found"),
			wantErr: "no read replica found",
		},
		{
			// ShardPlans exists to resolve a level per shard, which a
			// collection-wide plan of unequal width cannot carry.
			name:   "shards with different replica counts",
			shards: []string{"abc", "xyz"},
			nodes: []map[string]int{
				{"abc": 1, "xyz": 2},
				{"xyz": 2},
				{"xyz": 2},
			},
			want: 3,
		},
		{
			// The reachable shard must not be reported on its own: a count is
			// either complete or an error.
			name:   "a shard no replica can count",
			shards: []string{"abc", "xyz"},
			nodes: []map[string]int{
				{"abc": 1, "xyz": -1},
				{"abc": 1, "xyz": -1},
			},
			timeout: time.Second,
			wantErr: `shard "xyz"`,
		},
		{
			name:   "one tenant",
			shards: []string{"john_doe", "jane_doe"},
			nodes: []map[string]int{
				{
					"john_doe": 1,
					"jane_doe": 2,
				},
				{
					"john_doe": 1,
					"jane_doe": 2,
				},
			},
			tenant: "john_doe",
			want:   1,
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			// Arrange
			if tt.shards == nil {
				tt.shards = append(tt.shards, "abc")
			}

			var replicas []types.Replica
			for i, totalCount := range tt.counts {
				replicas = append(replicas, addReplicas(t, i, map[string]int{"abc": totalCount})...)
			}
			for i, shards := range tt.nodes {
				replicas = append(replicas, addReplicas(t, i, shards)...)
			}
			slices.SortFunc(replicas, func(r1, r2 types.Replica) int {
				return strings.Compare(r1.ShardName, r2.ShardName)
			})

			router := &fakeRouter{
				planErr: tt.planErr,
				readPlan: types.ReadRoutingPlan{
					IntConsistencyLevel: len(tt.counts) + len(tt.nodes),
					ConsistencyLevel:    types.ConsistencyLevelAll,
					ReplicaSet: types.ReadReplicaSet{
						Replicas: replicas,
					},
				},
			}
			index := Index{
				router: router,
				replicator: &replica.Replicator{
					Finder: replica.NewFinder(
						"Abc",
						router,
						cluster.NewMockNodeResolver(t),
						"node-1",
						func() replica.Client {
							c, err := clients.NewReplicationClient(&http.Client{})
							require.NoError(t, err)
							return c
						}(),
						replicaMetrics,
						logger,
						func() string { return "Delete" }),
				},
				shardCreateLocks: esync.NewKeyRWLocker(),
				Config:           IndexConfig{ClassName: schema.ClassName("Abc")},
				metrics:          metrics,
				logger:           logger,
			}

			// Act
			ctx := t.Context()
			if tt.timeout > 0 {
				var cancel context.CancelFunc
				ctx, cancel = context.WithTimeout(ctx, tt.timeout)
				defer cancel()
			}
			start := time.Now()
			res, err := index.aggregate(ctx, nil, aggregation.Params{
				IncludeMetaCount: true,
				Tenant:           tt.tenant,
			}, nil)

			// Assert
			if tt.timeout > 0 {
				// CountObjects retries a failing replica for a minute of its own;
				// the caller's deadline has to cut that short.
				require.Less(t, time.Since(start), 5*time.Second, "aggregate outlived the caller deadline")
			}
			if tt.wantErr != "" {
				require.ErrorContains(t, err, tt.wantErr, "aggregate")
			} else {
				require.NoError(t, err, "aggregate")
				require.Len(t, res.Groups, 1, "number of groups")
				require.Equal(t, tt.want, res.Groups[0].Count, "object count")
			}
		})
	}
}

type fakeRouter struct {
	hostnames map[string]string
	options   types.RoutingPlanBuildOptions
	readPlan  types.ReadRoutingPlan
	writePlan types.WriteRoutingPlan
	readSet   types.ReadReplicaSet
	writeSet  types.WriteReplicaSet
	planErr   error
}

// AllHostnames implements [types.Router].
func (f *fakeRouter) AllHostnames() []string {
	return slices.Collect(maps.Values(f.hostnames))
}

var _ types.Router = (*fakeRouter)(nil)

func (f *fakeRouter) BuildReadRoutingPlan(opt types.RoutingPlanBuildOptions) (types.ReadRoutingPlan, error) {
	if f.planErr != nil {
		return types.ReadRoutingPlan{}, f.planErr
	}

	readPlan := f.readPlan
	readPlan.Shard = opt.Shard
	readPlan.Tenant = opt.Tenant

	if opt.Tenant != "" {
		var filtered []types.Replica
		for _, r := range readPlan.ReplicaSet.Replicas {
			if r.ShardName == opt.Tenant {
				filtered = append(filtered, r)
			}
		}
		readPlan.ReplicaSet.Replicas = filtered
	}
	return readPlan, nil
}

func (f *fakeRouter) BuildRoutingPlanOptions(tenant, shard string, cl types.ConsistencyLevel, directCandidate string) types.RoutingPlanBuildOptions {
	opt := f.options
	opt.Shard = shard
	return opt
}

func (f *fakeRouter) BuildWriteRoutingPlan(params types.RoutingPlanBuildOptions) (types.WriteRoutingPlan, error) {
	return f.writePlan, nil
}

func (f *fakeRouter) GetReadReplicasLocation(collection, tenant, shard string) (types.ReadReplicaSet, error) {
	return f.readSet, nil
}

func (f *fakeRouter) GetReadWriteReplicasLocation(collection, tenant, shard string) (types.ReadReplicaSet, types.WriteReplicaSet, error) {
	return f.readSet, f.writeSet, nil
}

func (f *fakeRouter) GetWriteReplicasLocation(collection, tenant, shard string) (types.WriteReplicaSet, error) {
	panic("unimplemented")
}

func (f *fakeRouter) NodeHostname(nodeName string) (string, bool) {
	host, ok := f.hostnames[nodeName]
	return host, ok
}

func TestIndex_getShardsStatus(t *testing.T) {
	logger, _ := test.NewNullLogger()
	clusterNodes := []string{"node-0", "node-1", "node-2"}
	targetNode := clusterNodes[0]
	shardReplicas := map[string][]string{
		"shard_local":          clusterNodes,
		"shard_not_local":      clusterNodes[1:],
		"remote_not_reachable": clusterNodes,
	}
	shardStatus := map[string]map[string]string{
		"shard_local": {
			"node-0": storagestate.StatusReady.String(),
			"node-1": storagestate.StatusLazyLoading.String(),
			"node-2": storagestate.StatusIndexing.String(),
		},
		"shard_not_local": {
			"node-1": storagestate.StatusIndexing.String(),
			"node-2": storagestate.StatusIndexing.String(),
		},
		"remote_not_reachable": {
			"node-0": storagestate.StatusReady.String(),
			"node-1": storagestate.StatusReady.String(),
			"node-2": NodeUnresponsive, // Remote replica failed to report status.
		},
	}

	// NodeUnresponsive should not be in the final response.
	want := maps.Clone(shardStatus)
	want["remote_not_reachable"] = maps.Clone(want["remote_not_reachable"])
	delete(want["remote_not_reachable"], "node-2")

	wantLegacy := map[string]string{
		"shard_local":          storagestate.StatusReady.String(),
		"shard_not_local":      storagestate.StatusIndexing.String(),
		"remote_not_reachable": storagestate.StatusReady.String(),
	}

	var replicas []types.Replica
	for shard, nodes := range shardReplicas {
		for _, node := range nodes {
			replicas = append(replicas, types.Replica{
				ShardName: shard,
				NodeName:  node,
				HostAddr:  node,
			})
		}
	}

	router := &fakeRouter{
		readSet: types.ReadReplicaSet{
			Replicas: replicas,
		},
	}

	replicator := &replica.Replicator{
		Finder: replica.NewFinder(
			"Songs", nil, nil,
			targetNode, nil, nil,
			logger, nil,
		),
	}

	// Arrange
	schemaReader := schemaUC.NewMockSchemaReader(t)
	schemaReader.EXPECT().
		Shards("Songs").
		RunAndReturn(func(collectionName string) (shards []string, _ error) {
			for s := range shardReplicas {
				shards = append(shards, s)
			}
			return
		}).Maybe()
	schemaReader.EXPECT().
		ShardReplicas("Songs", mock.Anything).
		RunAndReturn(func(collectionName, shardName string) ([]string, error) {
			assert.Contains(t, shardReplicas, shardName)
			return shardReplicas[shardName], nil
		}).Maybe()

	nodeResolver := cluster.NewMockNodeResolver(t)
	nodeResolver.EXPECT().
		NodeHostname(mock.Anything).
		RunAndReturn(func(s string) (string, bool) { return s, true }).Maybe()

	index := Index{
		Config:           IndexConfig{ClassName: schema.ClassName("Songs")},
		getSchema:        &fakeSchemaGetter{nodeName: targetNode},
		schemaReader:     schemaReader,
		shardCreateLocks: esync.NewKeyRWLocker(),
		router:           router,
		replicator:       replicator,
		logger:           logger,
	}

	index.remote = sharding.NewRemoteIndex(
		"Songs",
		index.getSchema,
		nodeResolver,
		&FakeRemoteClient{shardStatus: shardStatus},
	)

	for shardName, statusByNode := range shardStatus {
		mockShard := NewMockShardLike(t)
		mockShard.EXPECT().
			preventShutdown().
			Return(func() {}, nil).Maybe()
		mockShard.EXPECT().
			Name().
			Return(shardName).Maybe()
		mockShard.EXPECT().
			GetStatus().
			Return(storagestate.Status(statusByNode[targetNode])).Maybe()
		index.shards.Store(shardName, mockShard)
	}

	// Act
	got, gotLegacy, err := index.getShardsStatus(t.Context(), "")

	// Assert
	assert.NoError(t, err)
	require.Equal(t, want, got, "shard statuses")
	require.Equal(t, wantLegacy, gotLegacy, "legacy statuses")
}

// TestIndex_ShardHasMultipleReplicasWrite_RoutesThroughReplicatorDuringMovement pins the
// rf=1 scale-out lost-write fix: while a replica movement is active for the shard, a write
// must be routed through the replicator (so it registers in the in-flight fence and the
// source's change-capture log cannot be sealed over it), even at replicationFactor=1 with a
// single-node write-set. Without the fix the "active movement, single replica" row returns
// false — the write would take the direct-local path that bypasses the fence.
func TestIndex_ShardHasMultipleReplicasWrite_RoutesThroughReplicatorDuringMovement(t *testing.T) {
	const (
		className = "MoveClass"
		shardName = "shard1"
		tenant    = ""
	)

	tests := []struct {
		name           string
		replicationF   int64
		movementActive bool
		// writeReplicas is the router's write-set node names. nil means the router must NOT
		// be consulted (the call should short-circuit before GetWriteReplicasLocation).
		writeReplicas []string
		want          bool
	}{
		{
			name:           "rf=1, no movement, single replica -> direct-local",
			replicationF:   1,
			movementActive: false,
			writeReplicas:  []string{"node-A"},
			want:           false,
		},
		{
			name:           "rf=1, ACTIVE movement, single replica -> replicator (regression pin)",
			replicationF:   1,
			movementActive: true,
			writeReplicas:  nil, // movement short-circuits before the router is consulted
			want:           true,
		},
		{
			name:           "rf=1, no movement, two replicas -> replicator",
			replicationF:   1,
			movementActive: false,
			writeReplicas:  []string{"node-A", "node-B"},
			want:           true,
		},
		{
			name:           "rf>1 -> replicator (short-circuit, FSM+router untouched)",
			replicationF:   3,
			movementActive: false,
			writeReplicas:  nil,
			want:           true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fsm := &fakeFSMReader{active: tt.movementActive}

			mockRouter := types.NewMockRouter(t)
			if tt.writeReplicas != nil {
				replicas := make([]types.Replica, 0, len(tt.writeReplicas))
				for _, n := range tt.writeReplicas {
					replicas = append(replicas, types.Replica{NodeName: n, ShardName: shardName})
				}
				mockRouter.EXPECT().
					GetWriteReplicasLocation(className, tenant, shardName).
					Return(types.WriteReplicaSet{Replicas: replicas}, nil).
					Once()
			}
			// When writeReplicas is nil we set no expectation, so any router call fails the
			// test — proving the call short-circuited before consulting the router.

			idx := &Index{
				Config: IndexConfig{ClassName: schema.ClassName(className), ReplicationFactor: tt.replicationF},
				router: mockRouter,
			}
			idx.SetReplicationFSMReader(fsm)

			got := idx.shardHasMultipleReplicasWrite(tenant, shardName)
			require.Equal(t, tt.want, got)

			if tt.replicationF > 1 {
				require.Zero(t, fsm.callCount, "rf>1 must short-circuit before consulting the replication FSM")
			}
			if tt.movementActive {
				require.Equal(t, className, fsm.gotColl)
				require.Equal(t, shardName, fsm.gotShard)
			}
		})
	}
}

// newDropLocalShardTestIndex builds a bare Index that is just wired enough to exercise
// dropShards' unloaded-shard branch (os.RemoveAll fallback) without a full DB.
func newDropLocalShardTestIndex(t *testing.T, logger logrus.FieldLogger) *Index {
	t.Helper()
	idx := &Index{
		Config:           IndexConfig{RootPath: t.TempDir(), ClassName: schema.ClassName("DropTestClass")},
		logger:           logger,
		backupLock:       esync.NewKeyRWLocker(),
		shardCreateLocks: esync.NewKeyRWLocker(),
	}
	require.NoError(t, os.MkdirAll(idx.path(), 0o755))
	return idx
}

// TestIndexDropLocalShard covers the local drop primitive that backs the
// cancelled-op target teardown, including the nil-deref pin in dropShards'
// unloaded-shard error branch.
func TestIndexDropLocalShard(t *testing.T) {
	t.Run("absent shard is an idempotent no-op", func(t *testing.T) {
		logger, _ := test.NewNullLogger()
		idx := newDropLocalShardTestIndex(t, logger)

		require.NoError(t, idx.DropLocalShard("never-existed"))
	})

	t.Run("unloaded shard files are actually removed", func(t *testing.T) {
		logger, _ := test.NewNullLogger()
		idx := newDropLocalShardTestIndex(t, logger)

		shardDir := shardPath(idx.path(), "shard1")
		require.NoError(t, os.MkdirAll(shardDir, 0o755))
		require.NoError(t, os.WriteFile(filepath.Join(shardDir, "store.db"), []byte("data"), 0o644))

		require.NoError(t, idx.DropLocalShard("shard1"))

		_, statErr := os.Stat(shardDir)
		require.True(t, os.IsNotExist(statErr), "target shard dir must be gone after drop, stat err: %v", statErr)
	})

	t.Run("unloaded shard drop error logs the name, does not panic", func(t *testing.T) {
		if os.Getuid() == 0 {
			t.Skip("chmod-based permission denial is a no-op for root")
		}
		logger, hook := test.NewNullLogger()
		idx := newDropLocalShardTestIndex(t, logger)

		shardDir := shardPath(idx.path(), "shard1")
		require.NoError(t, os.MkdirAll(shardDir, 0o755))

		// Deny write/traverse on the index dir so os.RemoveAll(shardDir) fails.
		require.NoError(t, os.Chmod(idx.path(), 0o000))
		t.Cleanup(func() { _ = os.Chmod(idx.path(), 0o755) })

		err := idx.DropLocalShard("shard1")
		require.Error(t, err, "drop must surface the os.RemoveAll failure")

		var sawNamedDropLog bool
		for _, e := range hook.AllEntries() {
			require.NotContains(t, e.Message, "Recovered from panic",
				"dropShards must not panic on the unloaded-shard error branch")
			if e.Data["action"] == "drop_shard" {
				require.Equal(t, "shard1", e.Data["shard"],
					"drop error must be logged against the requested name, not a nil shard")
				sawNamedDropLog = true
			}
		}
		require.True(t, sawNamedDropLog, "expected a drop_shard error log naming the shard")
	})
}

// addProperty and updateProperty only schedule the bucket work onto an error
// group, so the pins must outlive the walk and drop after eg.Wait().
//
// Two shards because shardMap.Range is sequential: the second callback firing
// proves the first returned, which is when a per-shard release would happen.
func TestPropertyWorkPinsShardAgainstTeardown(t *testing.T) {
	prop := &models.Property{
		Name:         "pinned",
		DataType:     schema.DataTypeText.PropString(),
		Tokenization: models.PropertyTokenizationWord,
	}

	const shardCount = 2

	tests := []struct {
		name   string
		expect func(shard *MockShardLike, schedule func(*enterrors.ErrorGroupWrapper))
		run    func(idx *Index) error
	}{
		{
			name: "addProperty",
			expect: func(shard *MockShardLike, schedule func(*enterrors.ErrorGroupWrapper)) {
				shard.EXPECT().initPropertyBuckets(mock.Anything, mock.Anything, mock.Anything, mock.Anything).
					Run(func(_ context.Context, eg *enterrors.ErrorGroupWrapper, _ bool, _ ...*models.Property) {
						schedule(eg)
					})
			},
			run: func(idx *Index) error { return idx.addProperty(context.Background(), prop) },
		},
		{
			name: "updateProperty",
			expect: func(shard *MockShardLike, schedule func(*enterrors.ErrorGroupWrapper)) {
				shard.EXPECT().updatePropertyBuckets(mock.Anything, mock.Anything, mock.Anything, mock.Anything).
					Run(func(_ context.Context, eg *enterrors.ErrorGroupWrapper, _ *models.Property, _ *atomic.Int64) {
						schedule(eg)
					})
			},
			run: func(idx *Index) error { return idx.updateProperty(context.Background(), prop) },
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			idx, _ := newDropTestIndex(t)

			var (
				activePins atomic.Int32
				remaining  atomic.Int32
				allWalked  = make(chan struct{})
			)
			remaining.Store(shardCount)

			schedule := func(eg *enterrors.ErrorGroupWrapper) {
				eg.Go(func() error {
					<-allWalked
					if pins := activePins.Load(); pins != shardCount {
						return fmt.Errorf("%d of %d pins released before the scheduled bucket work ran",
							shardCount-pins, shardCount)
					}
					return nil
				})
			}

			for i := range shardCount {
				shard := NewMockShardLike(t)
				shard.EXPECT().preventShutdown().RunAndReturn(func() (func(), error) {
					activePins.Add(1)
					return func() { activePins.Add(-1) }, nil
				})
				tt.expect(shard, func(eg *enterrors.ErrorGroupWrapper) {
					schedule(eg)
					if remaining.Add(-1) == 0 {
						close(allWalked)
					}
				})
				idx.shards.Store(fmt.Sprintf("t%d", i), shard)
			}

			require.NoError(t, tt.run(idx))
			require.Zero(t, activePins.Load(), "%s leaked a pin", tt.name)
		})
	}
}
