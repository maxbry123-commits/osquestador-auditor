//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	"fmt"
	"io"
	"sync"
	"sync/atomic"
	"time"

	"github.com/weaviate/weaviate/entities/loadlimiter"

	"github.com/go-openapi/strfmt"
	"github.com/pkg/errors"

	"github.com/weaviate/weaviate/adapters/repos/db/indexcheckpoint"
	"github.com/weaviate/weaviate/adapters/repos/db/indexcounter"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv"
	"github.com/weaviate/weaviate/adapters/repos/db/queue"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringset"
	shardusage "github.com/weaviate/weaviate/adapters/repos/db/shard_usage"
	"github.com/weaviate/weaviate/cluster/replication/changelog"
	"github.com/weaviate/weaviate/cluster/router/types"
	"github.com/weaviate/weaviate/entities/additional"
	"github.com/weaviate/weaviate/entities/aggregation"
	"github.com/weaviate/weaviate/entities/backup"
	"github.com/weaviate/weaviate/entities/dto"
	enterrors "github.com/weaviate/weaviate/entities/errors"
	"github.com/weaviate/weaviate/entities/filters"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/multi"
	"github.com/weaviate/weaviate/entities/schema"
	schemaConfig "github.com/weaviate/weaviate/entities/schema/config"
	"github.com/weaviate/weaviate/entities/search"
	"github.com/weaviate/weaviate/entities/searchparams"
	"github.com/weaviate/weaviate/entities/storagestate"
	"github.com/weaviate/weaviate/entities/storobj"
	"github.com/weaviate/weaviate/usecases/file"
	"github.com/weaviate/weaviate/usecases/memwatch"
	"github.com/weaviate/weaviate/usecases/modules"
	"github.com/weaviate/weaviate/usecases/monitoring"
	"github.com/weaviate/weaviate/usecases/objects"
	"github.com/weaviate/weaviate/usecases/replica"
	"github.com/weaviate/weaviate/usecases/replica/hashtree"
)

type LazyLoadShard struct {
	shardOpts *deferredShardOpts
	shard     *Shard
	loaded    bool
	// unloadedCount caches the object count read off disk while the shard is
	// cold, which a cold shard cannot change without loading first. nil means
	// not read yet; Load clears it.
	unloadedCount    *int64
	mutex            sync.Mutex
	memMonitor       memwatch.AllocChecker
	shardLoadLimiter *loadlimiter.LoadLimiter
	lazyLoadSegments bool
}

func NewLazyLoadShard(ctx context.Context, promMetrics *monitoring.PrometheusMetrics,
	shardName string, index *Index, class *models.Class, jobQueueCh chan job,
	indexCheckpoints *indexcheckpoint.Checkpoints, memMonitor memwatch.AllocChecker,
	shardLoadLimiter *loadlimiter.LoadLimiter, shardReindexer ShardReindexerV3,
	lazyLoadSegments bool, bitmapBufPool roaringset.BitmapBufPool,
) *LazyLoadShard {
	if memMonitor == nil {
		memMonitor = memwatch.NewDummyMonitor()
	}
	promMetrics.NewUnloadedshard()
	return &LazyLoadShard{
		shardOpts: &deferredShardOpts{
			promMetrics:      promMetrics,
			name:             shardName,
			index:            index,
			class:            class,
			jobQueueCh:       jobQueueCh,
			scheduler:        index.scheduler,
			indexCheckpoints: indexCheckpoints,
			shardReindexer:   shardReindexer,
			bitmapBufPool:    bitmapBufPool,
		},
		memMonitor:       memMonitor,
		shardLoadLimiter: shardLoadLimiter,
		lazyLoadSegments: lazyLoadSegments,
	}
}

type deferredShardOpts struct {
	promMetrics      *monitoring.PrometheusMetrics
	name             string
	index            *Index
	class            *models.Class
	jobQueueCh       chan job
	scheduler        *queue.Scheduler
	indexCheckpoints *indexcheckpoint.Checkpoints
	shardReindexer   ShardReindexerV3
	bitmapBufPool    roaringset.BitmapBufPool
}

func (l *LazyLoadShard) mustLoad() {
	l.mustLoadCtx(context.Background())
}

func (l *LazyLoadShard) mustLoadCtx(ctx context.Context) {
	if err := l.Load(ctx); err != nil {
		panic(err.Error())
	}
}

func (l *LazyLoadShard) Load(ctx context.Context) error {
	_, err := l.loadIfCold(ctx)
	return err
}

// loadIfCold builds the shard unless it is loaded already, and reports whether
// this call is the one that built it. The startup sweep counts only the loads it
// performed, and a request can take the shard first.
func (l *LazyLoadShard) loadIfCold(ctx context.Context) (bool, error) {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if l.loaded {
		return false, nil
	}

	if err := l.memMonitor.CheckMappingAndReserve(3, int(lsmkv.FlushAfterDirtyDefault.Seconds())); err != nil {
		return false, errors.Wrap(err, "memory pressure: cannot load shard")
	}

	if err := l.shardLoadLimiter.Acquire(ctx); err != nil {
		return false, fmt.Errorf("acquiring permit to load shard: %w", err)
	}
	defer l.shardLoadLimiter.Release()

	l.shardOpts.promMetrics.StartLoadingShard()

	// Re-read the class so schema changes made while the shard was cold take
	// effect at load. Fall back to the captured snapshot if it was dropped.
	class := l.shardOpts.index.getClass()
	if class == nil {
		class = l.shardOpts.class
	}

	// NewShard writes the segment sidecars a cold count reads and recovers the
	// write-ahead log into segments, so the cached cold count is stale from here
	// on — including when the load fails partway and leaves the shard cold.
	l.unloadedCount = nil

	shard, err := NewShard(ctx, l.shardOpts.promMetrics, l.shardOpts.name, l.shardOpts.index,
		class, l.shardOpts.jobQueueCh, l.shardOpts.scheduler,
		l.shardOpts.indexCheckpoints, l.shardOpts.shardReindexer, l.lazyLoadSegments,
		l.shardOpts.bitmapBufPool, monitoring.ShardRegistrationLazy)
	if err != nil {
		l.shardOpts.promMetrics.FailLoadingShard()
		msg := fmt.Sprintf("Unable to load shard %s: %v", l.shardOpts.name, err)
		l.shardOpts.index.logger.WithField("error", "shard_load").WithError(err).Error(msg)
		return false, errors.New(msg)
	}

	l.shardOpts.promMetrics.FinishLoadingShard()
	shard.metricsRegistered.Store(true)

	l.shard = shard
	l.loaded = true

	return true, nil
}

func (l *LazyLoadShard) Index() *Index {
	return l.shardOpts.index
}

func (l *LazyLoadShard) Name() string {
	return l.shardOpts.name
}

func (l *LazyLoadShard) Store() *lsmkv.Store {
	l.mustLoad()
	return l.shard.Store()
}

// Unwrap loads the shard if necessary and returns the underlying concrete *Shard.
func (l *LazyLoadShard) Unwrap(ctx context.Context) (*Shard, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard, nil
}

func (l *LazyLoadShard) NotifyReady() {
	l.mustLoad()
	l.shard.NotifyReady()
}

func (l *LazyLoadShard) GetStatus() storagestate.Status {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if l.loaded {
		return l.shard.GetStatus()
	}
	return storagestate.StatusLazyLoading
}

func (l *LazyLoadShard) GetStatusReason() string {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if l.loaded {
		return l.shard.GetStatusReason()
	}
	return storagestate.StatusLazyLoading.String()
}

func (l *LazyLoadShard) UpdateStatus(status, reason string) error {
	l.mustLoad()
	return l.shard.UpdateStatus(status, reason)
}

// UpdateStatusIf leaves an unloaded shard alone instead of loading it: the
// status lives in the loaded shard, and loading one to record a status would
// resurrect a shard that was deliberately unloaded.
func (l *LazyLoadShard) UpdateStatusIf(cond func(ShardStatus) bool, status, reason string) error {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if !l.loaded {
		return nil
	}
	return l.shard.UpdateStatusIf(cond, status, reason)
}

func (l *LazyLoadShard) SetStatusReadonly(reason string) error {
	l.mustLoad()
	return l.shard.SetStatusReadonly(reason)
}

func (l *LazyLoadShard) FindUUIDs(ctx context.Context, filters *filters.LocalFilter, limit int) ([]strfmt.UUID, error) {
	if err := l.Load(ctx); err != nil {
		return []strfmt.UUID{}, err
	}
	return l.shard.FindUUIDs(ctx, filters, limit)
}

func (l *LazyLoadShard) Counter() *indexcounter.Counter {
	l.mustLoad()
	return l.shard.Counter()
}

func (l *LazyLoadShard) ObjectCount(ctx context.Context) (int, error) {
	l.mustLoad()
	return l.shard.ObjectCount(ctx)
}

func (l *LazyLoadShard) ObjectCountAsync(ctx context.Context) (int64, error) {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if l.loaded {
		return l.shard.ObjectCountAsync(ctx)
	}
	if l.unloadedCount != nil {
		return *l.unloadedCount, nil
	}

	// The disk read stays under the lock: a load writes segment sidecars and
	// recovers the write-ahead log, so a read overlapping one can sum a mix of
	// old and new segments and then cache the result. Everything else on this
	// shard waits for one directory listing. A failed read caches nothing, so a
	// shard whose sidecars stay unreadable repeats that listing on every call.
	idx := l.shardOpts.index
	objectUsage, err := shardusage.CalculateUnloadedObjectsMetrics(idx.logger, idx.path(), l.shardOpts.name, true)
	if err != nil {
		return 0, fmt.Errorf("error while getting object count for shard %s: %w", l.shardOpts.name, err)
	}

	count := objectUsage.Count
	l.unloadedCount = &count

	return count, nil
}

func (l *LazyLoadShard) GetPropertyLengthTracker() *inverted.JsonShardMetaData {
	l.mustLoad()
	return l.shard.GetPropertyLengthTracker()
}

func (l *LazyLoadShard) PutObject(ctx context.Context, object *storobj.Object) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.PutObject(ctx, object)
}

func (l *LazyLoadShard) PutObjectBatch(ctx context.Context, objects []*storobj.Object) []error {
	if err := l.Load(ctx); err != nil {
		return duplicateErr(err, len(objects))
	}
	return l.shard.PutObjectBatch(ctx, objects)
}

func (l *LazyLoadShard) ObjectByID(ctx context.Context, id strfmt.UUID, props search.SelectProperties, additional additional.Properties) (*storobj.Object, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ObjectByID(ctx, id, props, additional)
}

func (l *LazyLoadShard) ObjectDigestErrDeleted(ctx context.Context, id strfmt.UUID) (types.RepairResponse, error) {
	if err := l.Load(ctx); err != nil {
		return types.RepairResponse{}, err
	}
	return l.shard.ObjectDigestErrDeleted(ctx, id)
}

func (l *LazyLoadShard) Exists(ctx context.Context, id strfmt.UUID) (bool, error) {
	if err := l.Load(ctx); err != nil {
		return false, err
	}
	return l.shard.Exists(ctx, id)
}

func (l *LazyLoadShard) ObjectSearch(ctx context.Context, limit int, filters *filters.LocalFilter, keywordRanking *searchparams.KeywordRanking, sort []filters.Sort, cursor *filters.Cursor, additional additional.Properties, properties []string) ([]*storobj.Object, []float32, error) {
	if err := l.Load(ctx); err != nil {
		return nil, nil, err
	}
	return l.shard.ObjectSearch(ctx, limit, filters, keywordRanking, sort, cursor, additional, properties)
}

func (l *LazyLoadShard) ObjectVectorSearch(ctx context.Context, searchVectors []models.Vector, targetVectors []string, targetDist float32, limit int, filters *filters.LocalFilter, sort []filters.Sort, groupBy *searchparams.GroupBy, additional additional.Properties, targetCombination *dto.TargetCombination, properties []string) ([]*storobj.Object, []float32, error) {
	if err := l.Load(ctx); err != nil {
		return nil, nil, err
	}
	return l.shard.ObjectVectorSearch(ctx, searchVectors, targetVectors, targetDist, limit, filters, sort, groupBy, additional, targetCombination, properties)
}

func (l *LazyLoadShard) UpdateVectorIndexConfig(ctx context.Context, updated schemaConfig.VectorIndexConfig) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.UpdateVectorIndexConfig(ctx, updated)
}

func (l *LazyLoadShard) UpdateVectorIndexConfigs(ctx context.Context, updated map[string]schemaConfig.VectorIndexConfig) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.UpdateVectorIndexConfigs(ctx, updated)
}

func (l *LazyLoadShard) enableAsyncReplication(ctx context.Context, config AsyncReplicationConfig) error {
	// Never load (init applies config at load); isLoaded takes l.mutex, so callers must not hold replicationConfigLock.
	if !l.isLoaded() {
		return nil
	}
	return l.shard.enableAsyncReplication(ctx, config)
}

func (l *LazyLoadShard) disableAsyncReplication(ctx context.Context) error {
	l.mutex.Lock()
	loaded := l.loaded
	l.mutex.Unlock()
	if !loaded {
		return nil
	}
	return l.shard.disableAsyncReplication(ctx)
}

func (l *LazyLoadShard) hasActiveAsyncReplicationTargetOverrides() bool {
	l.mutex.Lock()
	loaded := l.loaded
	l.mutex.Unlock()
	if !loaded {
		// An unloaded shard holds no in-memory overrides.
		return false
	}
	return l.shard.hasActiveAsyncReplicationTargetOverrides()
}

func (l *LazyLoadShard) removePersistedHashtree() error {
	l.mutex.Lock()
	loaded := l.loaded
	l.mutex.Unlock()
	if !loaded {
		return nil // unloaded shards take no writes, so a persisted .ht stays valid; init scrubs it when async is off
	}
	return l.shard.removePersistedHashtree()
}

func (l *LazyLoadShard) rebuildAsyncReplicationFromScratch(ctx context.Context, enabled bool, config AsyncReplicationConfig) error {
	// Never load: matches resumeAfterAbortedOffload's no-op-when-unloaded contract.
	if !l.isLoaded() {
		return nil
	}
	return l.shard.rebuildAsyncReplicationFromScratch(ctx, enabled, config)
}

func (l *LazyLoadShard) addTargetNodeOverride(ctx context.Context, targetNodeOverride additional.AsyncReplicationTargetNodeOverride) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.addTargetNodeOverride(ctx, targetNodeOverride)
}

func (l *LazyLoadShard) removeTargetNodeOverride(ctx context.Context, targetNodeOverride additional.AsyncReplicationTargetNodeOverride) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.removeTargetNodeOverride(ctx, targetNodeOverride)
}

func (l *LazyLoadShard) removeAllTargetNodeOverrides(ctx context.Context) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.removeAllTargetNodeOverrides(ctx)
}

func (l *LazyLoadShard) getAsyncReplicationStats(ctx context.Context) []*models.AsyncReplicationStatus {
	if err := l.Load(ctx); err != nil {
		return nil
	}
	return l.shard.getAsyncReplicationStats(ctx)
}

func (l *LazyLoadShard) ActivateChangeLog(ctx context.Context, opID string) (*changelog.ChangeLog, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ActivateChangeLog(ctx, opID)
}

func (l *LazyLoadShard) SnapshotChangeLogLSN(ctx context.Context, opID string) (uint64, error) {
	if err := l.Load(ctx); err != nil {
		return 0, err
	}
	return l.shard.SnapshotChangeLogLSN(ctx, opID)
}

func (l *LazyLoadShard) FinalizeChangeLog(ctx context.Context, opID string) (uint64, error) {
	if err := l.Load(ctx); err != nil {
		return 0, err
	}
	return l.shard.FinalizeChangeLog(ctx, opID)
}

func (l *LazyLoadShard) StopChangeCapture(ctx context.Context, opID string) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.StopChangeCapture(ctx, opID)
}

func (l *LazyLoadShard) GetChangeLog(ctx context.Context, opID string) (*changelog.ChangeLog, bool) {
	if err := l.Load(ctx); err != nil {
		return nil, false
	}
	return l.shard.GetChangeLog(ctx, opID)
}

func (l *LazyLoadShard) AddReferencesBatch(ctx context.Context, refs objects.BatchReferences) []error {
	if err := l.Load(ctx); err != nil {
		return duplicateErr(err, len(refs))
	}
	return l.shard.AddReferencesBatch(ctx, refs)
}

func (l *LazyLoadShard) DeleteObjectBatch(ctx context.Context, ids []strfmt.UUID, deletionTime time.Time, dryRun bool) objects.BatchSimpleObjects {
	l.mustLoadCtx(ctx)
	return l.shard.DeleteObjectBatch(ctx, ids, deletionTime, dryRun)
}

func (l *LazyLoadShard) DeleteObject(ctx context.Context, id strfmt.UUID, deletionTime time.Time) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.DeleteObject(ctx, id, deletionTime)
}

func (l *LazyLoadShard) MultiObjectByID(ctx context.Context, query []multi.Identifier) ([]*storobj.Object, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.MultiObjectByID(ctx, query)
}

func (l *LazyLoadShard) ObjectDigests(ctx context.Context, query []multi.Identifier) ([]types.RepairResponse, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ObjectDigests(ctx, query)
}

func (l *LazyLoadShard) ObjectDigestsInRange(ctx context.Context,
	initialUUID, finalUUID strfmt.UUID, limit int,
) (objs []types.RepairDigest, err error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ObjectDigestsInRange(ctx, initialUUID, finalUUID, limit)
}

func (l *LazyLoadShard) ID() string {
	return shardId(l.shardOpts.index.ID(), l.shardOpts.name)
}

func (l *LazyLoadShard) drop(keepFiles bool) error {
	// if not loaded, execute simplified drop without loading shard:
	// - perform required actions
	// - remove entire shard directory
	// use lock to prevent eventual concurrent droping and loading
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if !l.loaded {
		// The shard is out of the shard map before drop runs, so it stops being
		// counted even when the cleanup below fails partway.
		defer l.shardOpts.promMetrics.DeleteUnloadedShard(monitoring.ShardRegistrationLazy)

		idx := l.shardOpts.index
		className := idx.Config.ClassName.String()
		shardName := l.shardOpts.name

		// cleanup metrics
		metrics, err := NewMetrics(idx.logger, l.shardOpts.promMetrics, className, shardName)
		if err != nil {
			return fmt.Errorf("shard metrics: %w", err)
		}

		metrics.DeleteShardLabels(className, shardName)

		// cleanup dimensions: not deleted in s.metrics.DeleteShardLabels
		clearDimensionMetrics(idx.Config, l.shardOpts.promMetrics, className, shardName)

		// cleanup index checkpoints
		if l.shardOpts.indexCheckpoints != nil {
			if err := l.shardOpts.index.indexCheckpoints.DeleteShard(l.ID()); err != nil {
				return fmt.Errorf("delete shard index checkpoints: %w", err)
			}
		}

		// The registry tracks open buckets in memory, not files, so purge the
		// shard's residual entries before deleting the files
		lsmkv.GlobalBucketRegistry.RemoveByPrefixes(shardPathLSM(idx.path(), shardName))

		// rename sync (must complete even if ctx is expired); RemoveAll async.
		// Mirrors Shard.drop so the unloaded path doesn't reintroduce the
		// blocking RemoveAll the loaded path was changed to avoid.
		if !keepFiles {
			path := shardPath(idx.path(), shardName)
			deleted, err := renameForAsyncDelete(path, idx.logger)
			if err != nil {
				return fmt.Errorf("rename shard for async delete: %w", err)
			}
			if deleted != "" {
				spawnAsyncDelete(deleted, idx.logger)
			}
		}

		return nil
	}

	return l.shard.drop(keepFiles)
}

func (l *LazyLoadShard) DebugResetVectorIndex(ctx context.Context, targetVector string) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.DebugResetVectorIndex(ctx, targetVector)
}

func (l *LazyLoadShard) initPropertyBuckets(ctx context.Context, eg *enterrors.ErrorGroupWrapper,
	lazyLoadSegments bool, props ...*models.Property,
) {
	l.mustLoad()
	l.shard.initPropertyBuckets(ctx, eg, lazyLoadSegments, props...)
}

func (l *LazyLoadShard) updatePropertyBuckets(ctx context.Context, eg *enterrors.ErrorGroupWrapper,
	property *models.Property, payloadReads *atomic.Int64,
) {
	if l.isLoaded() {
		l.shard.updatePropertyBuckets(ctx, eg, property, payloadReads)
	} else {
		// The unloaded path removes bucket dirs by name and reads no payloads.
		l.updateUnloadedPropertyBuckets(ctx, eg, property)
	}
}

func (l *LazyLoadShard) updateUnloadedPropertyBuckets(ctx context.Context,
	eg *enterrors.ErrorGroupWrapper,
	prop *models.Property,
) {
	eg.Go(func() error {
		// Shares the loaded path's index types so Index.updateProperty's summary
		// log names what this branch removed too. Not its body: this path
		// removes the main bucket dir by name and nothing else, so a cold
		// tenant's migration and sidecar dirs outlive the property delete.
		// That is a gap, not a property of unloaded shards.
		for _, indexType := range disabledIndexTypes(prop) {
			mainBucket, ok := mainBucketForPropertyIndex(prop.Name, indexType)
			if !ok {
				return fmt.Errorf("cannot remove unloaded %s index for %s property: no main bucket for this index type", indexType, prop.Name)
			}
			if err := l.shard.removeDirIfExists(l.pathLSM(), mainBucket); err != nil {
				return fmt.Errorf("cannot remove unloaded %s index for %s property: %w", indexType, prop.Name, err)
			}
		}
		return nil
	})
}

func (l *LazyLoadShard) DropVectorIndex(ctx context.Context, targetVector string) error {
	if l.isLoaded() {
		return l.shard.DropVectorIndex(ctx, targetVector)
	} else {
		return l.dropUnloadedVectorIndex(targetVector)
	}
}

func (l *LazyLoadShard) dropUnloadedVectorIndex(targetVector string) error {
	// Shard is not loaded — remove files directly from disk. Delegate to the
	// shared helper so file path logic is defined in one place.
	// The collection's other vector names guard against removing a sibling whose
	// own bucket collides with one of this target's artifact names.
	class := l.shardOpts.index.getClass()
	if class == nil {
		class = l.shardOpts.class
	}
	if err := newVectorDropIndexHelper().removeVectorIndexFiles(
		l.shardOpts.index.path(), l.shardOpts.name, targetVector,
		otherTargetVectors(class, targetVector)); err != nil {
		return err
	}

	// Remove the index checkpoint entry for this vector.
	if l.shardOpts.indexCheckpoints != nil {
		if err := l.shardOpts.indexCheckpoints.Delete(l.ID(), targetVector); err != nil {
			return fmt.Errorf("delete checkpoint for vector %q: %w", targetVector, err)
		}
	}
	return nil
}

func (l *LazyLoadShard) HaltForTransfer(ctx context.Context, offloading bool, inactivityTimeout time.Duration) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.HaltForTransfer(ctx, offloading, inactivityTimeout)
}

// Skips Load: a never-loaded shard can't be halted, so there's no timer.
func (l *LazyLoadShard) MayResetTransferInactivityTimer() {
	l.mutex.Lock()
	defer l.mutex.Unlock()
	if l.shard == nil {
		return
	}
	l.shard.MayResetTransferInactivityTimer()
}

func (l *LazyLoadShard) ListBackupFiles(ctx context.Context, ret *backup.ShardDescriptor) ([]string, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ListBackupFiles(ctx, ret)
}

func (l *LazyLoadShard) CreateBackupSnapshot(ctx context.Context, sd *backup.ShardDescriptor, stagingRoot string) ([]string, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.CreateBackupSnapshot(ctx, sd, stagingRoot)
}

func (l *LazyLoadShard) CreateReplicaSnapshot(ctx context.Context, stagingRoot string) ([]string, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.CreateReplicaSnapshot(ctx, stagingRoot)
}

func (l *LazyLoadShard) ListReplicaSnapshotFiles(ctx context.Context, stagingRoot string) ([]string, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ListReplicaSnapshotFiles(ctx, stagingRoot)
}

func (l *LazyLoadShard) resumeMaintenanceCycles(ctx context.Context) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.resumeMaintenanceCycles(ctx)
}

func (l *LazyLoadShard) GetFileMetadata(ctx context.Context, relativeFilePath string) (file.FileMetadata, error) {
	if err := l.Load(ctx); err != nil {
		return file.FileMetadata{}, err
	}
	return l.shard.GetFileMetadata(ctx, relativeFilePath)
}

func (l *LazyLoadShard) GetFile(ctx context.Context, relativeFilePath string) (io.ReadCloser, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.GetFile(ctx, relativeFilePath)
}

func (l *LazyLoadShard) SetPropertyLengths(props []inverted.Property) error {
	l.mustLoad()
	return l.shard.SetPropertyLengths(props)
}

func (l *LazyLoadShard) AnalyzeObject(object *storobj.Object) ([]inverted.Property, []inverted.NilProperty, []inverted.NestedProperty, error) {
	l.mustLoad()
	return l.shard.AnalyzeObject(object)
}

func (l *LazyLoadShard) AnalyzeObjectForMigrationWithOverlay(object *storobj.Object,
	overlay map[string]inverted.PropertyOverlay,
) ([]inverted.Property, []inverted.NilProperty, error) {
	l.mustLoad()
	return l.shard.AnalyzeObjectForMigrationWithOverlay(object, overlay)
}

func (l *LazyLoadShard) Dimensions(ctx context.Context, targetVector string) (int, error) {
	l.mutex.Lock()
	if l.loaded {
		l.mutex.Unlock()
		return l.shard.Dimensions(ctx, targetVector)
	}
	l.mutex.Unlock()

	// For unloaded shards, get dimensions from unloaded shard/tenant calculation
	idx := l.shardOpts.index
	dimensionality, err := shardusage.CalculateUnloadedDimensionsUsage(ctx, idx.logger, idx.path(), l.shardOpts.name, targetVector)
	if err != nil {
		return 0, err
	}
	return dimensionality.Count * dimensionality.Dimensions, nil
}

func (l *LazyLoadShard) QuantizedDimensions(ctx context.Context, targetVector string, segments int) (int, error) {
	l.mustLoad()
	return l.shard.QuantizedDimensions(ctx, targetVector, segments)
}

func (l *LazyLoadShard) resetDimensionsLSM(ctx context.Context) error {
	l.mustLoad()
	return l.shard.resetDimensionsLSM(ctx)
}

func (l *LazyLoadShard) Aggregate(ctx context.Context, params aggregation.Params, modules *modules.Provider) (*aggregation.Result, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.Aggregate(ctx, params, modules)
}

func (l *LazyLoadShard) MergeObject(ctx context.Context, object objects.MergeDocument) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.MergeObject(ctx, object)
}

func (l *LazyLoadShard) GetVectorIndexQueue(targetVector string) (*VectorIndexQueue, bool) {
	l.mustLoad()
	return l.shard.GetVectorIndexQueue(targetVector)
}

func (l *LazyLoadShard) GetVectorIndex(targetVector string) (VectorIndex, bool) {
	l.mustLoad()
	return l.shard.GetVectorIndex(targetVector)
}

func (l *LazyLoadShard) ForEachVectorIndex(f func(targetVector string, index VectorIndex) error) error {
	l.mustLoad()
	return l.shard.ForEachVectorIndex(f)
}

func (l *LazyLoadShard) ForEachVectorQueue(f func(targetVector string, queue *VectorIndexQueue) error) error {
	l.mustLoad()
	return l.shard.ForEachVectorQueue(f)
}

func (l *LazyLoadShard) ForEachGeoQueue(f func(propName string, queue *VectorIndexQueue) error) error {
	l.mustLoad()
	return l.shard.ForEachGeoQueue(f)
}

func (l *LazyLoadShard) VectorDistanceForQuery(ctx context.Context, id uint64, searchVectors []models.Vector, targets []string) ([]float32, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.VectorDistanceForQuery(ctx, id, searchVectors, targets)
}

func (l *LazyLoadShard) ConvertQueue(targetVector string) error {
	l.mustLoad()
	return l.shard.ConvertQueue(targetVector)
}

func (l *LazyLoadShard) FillQueue(targetVector string, from uint64) error {
	l.mustLoad()
	return l.shard.FillQueue(targetVector, from)
}

func (l *LazyLoadShard) RepairIndex(ctx context.Context, targetVector string) error {
	l.mustLoad()
	return l.shard.RepairIndex(ctx, targetVector)
}

func (l *LazyLoadShard) RequantizeIndex(ctx context.Context, targetVector string) error {
	l.mustLoad()
	return l.shard.RequantizeIndex(ctx, targetVector)
}

func (l *LazyLoadShard) Shutdown(ctx context.Context) error {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	if !l.loaded {
		return nil
	}

	if err := l.shard.Shutdown(ctx); err != nil {
		return err
	}

	// Mark as unloaded so drop() knows the correct state
	l.loaded = false
	return nil
}

func (l *LazyLoadShard) preventShutdown() (release func(), err error) {
	if err := l.Load(context.Background()); err != nil {
		return func() {}, fmt.Errorf("LazyLoadShard::preventShutdown: %w", err)
	}
	return l.shard.preventShutdown()
}

// HashTreeLevel maps unloaded to ErrAsyncReplicationNotActive; an empty level would read as convergence.
func (l *LazyLoadShard) HashTreeLevel(ctx context.Context, level int, discriminant *hashtree.Bitset) (digests []hashtree.Digest, err error) {
	if !l.isLoaded() {
		return nil, errAsyncReplicationNotActive
	}
	return l.shard.HashTreeLevel(ctx, level, discriminant)
}

// CreateAsyncCheckpoint maps unloaded to ErrAsyncReplicationNotActive so transports
// return REST 412 / gRPC FailedPrecondition (matching the loaded path).
func (l *LazyLoadShard) CreateAsyncCheckpoint(ctx context.Context, cutoffMs int64, createdAt time.Time) error {
	if !l.isLoaded() {
		return errAsyncReplicationNotActive
	}
	return l.shard.CreateAsyncCheckpoint(ctx, cutoffMs, createdAt)
}

func (l *LazyLoadShard) DeleteAsyncCheckpoint(ctx context.Context) error {
	if !l.isLoaded() {
		return nil
	}
	return l.shard.DeleteAsyncCheckpoint(ctx)
}

func (l *LazyLoadShard) AsyncCheckpointRoot(ctx context.Context) (root hashtree.Digest, cutoffMs int64, createdAt time.Time, ok bool) {
	if !l.isLoaded() {
		return hashtree.Digest{}, 0, time.Time{}, false
	}
	return l.shard.AsyncCheckpointRoot(ctx)
}

// IsAsyncCheckpointHostable lets Index.GetAsyncCheckpointShardStatus
// distinguish unloaded shards from "loaded but inactive".
func (l *LazyLoadShard) IsAsyncCheckpointHostable() bool {
	return l.isLoaded()
}

func (l *LazyLoadShard) HashTreeRoot() (root hashtree.Digest, ok bool) {
	if !l.isLoaded() {
		return hashtree.Digest{}, false
	}
	return l.shard.HashTreeRoot()
}

func (l *LazyLoadShard) CompareDigests(ctx context.Context, sourceDigests []types.RepairDigest) ([]types.RepairDigest, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.CompareDigests(ctx, sourceDigests)
}

func (l *LazyLoadShard) ObjectList(ctx context.Context, limit int, sort []filters.Sort, cursor *filters.Cursor, additional additional.Properties, className schema.ClassName) ([]*storobj.Object, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.ObjectList(ctx, limit, sort, cursor, additional, className)
}

func (l *LazyLoadShard) WasDeleted(ctx context.Context, id strfmt.UUID) (bool, time.Time, error) {
	if err := l.Load(ctx); err != nil {
		return false, time.Time{}, err
	}
	return l.shard.WasDeleted(ctx, id)
}

func (l *LazyLoadShard) Versioner() *shardVersioner {
	l.mustLoad()
	return l.shard.Versioner()
}

func (l *LazyLoadShard) isReadOnly() error {
	l.mustLoad()
	return l.shard.isReadOnly()
}

func (l *LazyLoadShard) preparePutObject(ctx context.Context, shardID string, object *storobj.Object) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.preparePutObject(ctx, shardID, object)
}

func (l *LazyLoadShard) preparePutObjects(ctx context.Context, shardID string, objects []*storobj.Object) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.preparePutObjects(ctx, shardID, objects)
}

func (l *LazyLoadShard) prepareMergeObject(ctx context.Context, shardID string, object *objects.MergeDocument) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.prepareMergeObject(ctx, shardID, object)
}

func (l *LazyLoadShard) prepareDeleteObject(ctx context.Context, shardID string, id strfmt.UUID, deletionTime time.Time) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.prepareDeleteObject(ctx, shardID, id, deletionTime)
}

func (l *LazyLoadShard) prepareDeleteObjects(ctx context.Context, shardID string,
	ids []strfmt.UUID, deletionTime time.Time, dryRun bool,
) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.prepareDeleteObjects(ctx, shardID, ids, deletionTime, dryRun)
}

func (l *LazyLoadShard) prepareAddReferences(ctx context.Context, shardID string, refs []objects.BatchReference) replica.SimpleResponse {
	l.mustLoadCtx(ctx)
	return l.shard.prepareAddReferences(ctx, shardID, refs)
}

func (l *LazyLoadShard) commitReplication(ctx context.Context, shardID string) interface{} {
	l.mustLoad()
	return l.shard.commitReplication(ctx, shardID)
}

func (l *LazyLoadShard) abortReplication(ctx context.Context, shardID string) replica.SimpleResponse {
	l.mustLoad()
	return l.shard.abortReplication(ctx, shardID)
}

func (l *LazyLoadShard) filePutter(ctx context.Context, shardID string) (io.WriteCloser, error) {
	if err := l.Load(ctx); err != nil {
		return nil, err
	}
	return l.shard.filePutter(ctx, shardID)
}

func (l *LazyLoadShard) extendDimensionTrackerLSM(dimLength int, docID uint64, targetVector string) error {
	if err := l.Load(context.Background()); err != nil {
		return err
	}
	return l.shard.extendDimensionTrackerLSM(dimLength, docID, targetVector)
}

func (l *LazyLoadShard) addToPropertySetBucket(bucket *lsmkv.Bucket, docID uint64, key []byte) error {
	l.mustLoad()
	return l.shard.addToPropertySetBucket(bucket, docID, key)
}

func (l *LazyLoadShard) addToPropertyMapBucket(bucket *lsmkv.Bucket, pair lsmkv.MapPair, key []byte) error {
	l.mustLoad()
	return l.shard.addToPropertyMapBucket(bucket, pair, key)
}

func (l *LazyLoadShard) pairPropertyWithFrequency(docID uint64, freq, propLen float32) lsmkv.MapPair {
	l.mustLoad()
	return l.shard.pairPropertyWithFrequency(docID, freq, propLen)
}

func (l *LazyLoadShard) setFallbackToSearchable(fallback bool) {
	l.mustLoad()
	l.shard.setFallbackToSearchable(fallback)
}

func (l *LazyLoadShard) addJobToQueue(job job) {
	l.mustLoad()
	l.shard.addJobToQueue(job)
}

func (l *LazyLoadShard) batchDeleteObject(ctx context.Context, id strfmt.UUID, deletionTime time.Time) error {
	if err := l.Load(ctx); err != nil {
		return err
	}
	return l.shard.batchDeleteObject(ctx, id, deletionTime)
}

func (l *LazyLoadShard) putObjectLSM(ctx context.Context, object *storobj.Object, idBytes []byte) (objectInsertStatus, error) {
	l.mustLoad()
	return l.shard.putObjectLSM(ctx, object, idBytes)
}

func (l *LazyLoadShard) mutableMergeObjectLSM(ctx context.Context, merge objects.MergeDocument, idBytes []byte) (mutableMergeResult, error) {
	l.mustLoad()
	return l.shard.mutableMergeObjectLSM(ctx, merge, idBytes)
}

func (l *LazyLoadShard) updatePropertySpecificIndices(ctx context.Context, object *storobj.Object, status objectInsertStatus) error {
	l.mustLoad()
	return l.shard.updatePropertySpecificIndices(ctx, object, status)
}

func (l *LazyLoadShard) updateVectorIndexIgnoreDelete(ctx context.Context, vector []float32, status objectInsertStatus) error {
	l.mustLoad()
	return l.shard.updateVectorIndexIgnoreDelete(ctx, vector, status)
}

func (l *LazyLoadShard) updateVectorIndexesIgnoreDelete(ctx context.Context, vectors map[string][]float32, status objectInsertStatus) error {
	l.mustLoad()
	return l.shard.updateVectorIndexesIgnoreDelete(ctx, vectors, status)
}

func (l *LazyLoadShard) updateMultiVectorIndexesIgnoreDelete(ctx context.Context, multiVectors map[string][][]float32, status objectInsertStatus) error {
	l.mustLoad()
	return l.shard.updateMultiVectorIndexesIgnoreDelete(ctx, multiVectors, status)
}

func (l *LazyLoadShard) hasGeoIndex() bool {
	l.mustLoad()
	return l.shard.hasGeoIndex()
}

// A cold shard reports false rather than loading: the only caller reaches this
// through ForEachLoadedShard, and the addProperty that false triggers skips cold
// shards too.
func (l *LazyLoadShard) hasGeoIndexForProp(propName string) bool {
	if !l.isLoaded() {
		return false
	}
	return l.shard.hasGeoIndexForProp(propName)
}

func (l *LazyLoadShard) Metrics() *Metrics {
	l.mustLoad()
	return l.shard.Metrics()
}

func (l *LazyLoadShard) isLoaded() bool {
	l.mutex.Lock()
	defer l.mutex.Unlock()

	return l.loaded
}

func (l *LazyLoadShard) Activity() (int32, int32) {
	var loaded bool
	l.mutex.Lock()
	loaded = l.loaded
	l.mutex.Unlock()

	if !loaded {
		// don't force-load the shard, just report the same number every time, so
		// the caller can figure out there was no activity
		return 0, 0
	}

	return l.shard.Activity()
}

func (l *LazyLoadShard) pathLSM() string {
	return shardPathLSM(l.shardOpts.index.path(), l.shardOpts.name)
}

func (l *LazyLoadShard) blockLoading() func() {
	l.mutex.Lock()

	return func() {
		l.mutex.Unlock()
	}
}

// canSkipUnloadedSweep reports whether the cleanup sweep can leave this
// shard alone; a loaded shard is never skipped, since sweeping it costs no
// load. The loading mutex covers the disk read and is released before
// returning — the hydration that follows takes it itself.
//
// A completed migration's leftovers are the second reason not to skip: a
// load is what runs [FinalizeCompletedMigrations], so a shard that keeps its
// data under the ingest sidecar name plus a full backup copy of the bucket it
// replaced reclaims neither until something hydrates it. One load per tenant
// per completed migration settles that — finalize removes the tracker dir it
// answers from, so the next sweep skips the tenant again. A tenant with no
// migration leftovers at all, which is the population this gate is for, is
// never loaded.
//
// Skipping holds only while reindex state arrives through a load. Shutdown does
// not remove the shard from the index map — [Index.Shutdown] shuts its shards
// down in place — so what keeps the gate off a shard being shut down is the
// mutex: [LazyLoadShard.Shutdown] takes the one held across this disk read. A
// sweep racing an index shutdown then comes back truncated from
// [Index.forEachShardStrict] rather than as a walk that reached every shard.
//
// The second return is how many tracker payloads this call had to read, for
// the caller's log; a loaded shard reads none, and so does a shard a previous
// tuple of the same run already answered from props.
func (l *LazyLoadShard) canSkipUnloadedSweep(
	propName, indexType string, dirs *dirNamesCache, props *taskPropsCache,
) (bool, int) {
	release := l.blockLoading()
	defer release()

	if l.loaded {
		return false, 0
	}
	if props == nil {
		// No run-wide memo. Substituted here rather than left to the probe, so
		// the count below is taken off the cache the probe actually used.
		props = &taskPropsCache{}
	}
	// props is a running total over the whole run, so the caller gets the delta.
	before := props.count()
	stale, finalizable := hasStalePartialReindexState(
		l.pathLSM(), propName, indexType, dirs, props)
	return !stale && !finalizable, props.count() - before
}
