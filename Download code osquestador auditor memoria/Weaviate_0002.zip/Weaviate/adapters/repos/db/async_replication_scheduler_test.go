//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"container/heap"
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"sync"
	"testing"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/weaviate/weaviate/entities/additional"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/replication"
	entschema "github.com/weaviate/weaviate/entities/schema"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"
	"github.com/weaviate/weaviate/usecases/replica"
	replicaerrors "github.com/weaviate/weaviate/usecases/replica/errors"
	"github.com/weaviate/weaviate/usecases/replica/hashtree"
)

// TestInitRetryBackoff verifies that initRetryBackoff never produces a negative
// or zero duration, even for large i values that caused int64 overflow in the
// naive formulation (time.Duration(1<<i)*100*time.Millisecond overflows at i=37,
// wrapping to a negative value and turning the retry loop into a busy-loop).
func TestInitRetryBackoff(t *testing.T) {
	cases := []struct {
		i    int
		want time.Duration
	}{
		{0, 100 * time.Millisecond},
		{1, 200 * time.Millisecond},
		{2, 400 * time.Millisecond},
		{10, time.Duration(1<<10) * 100 * time.Millisecond}, // 102.4 s, below the 5 min cap
		{11, time.Duration(1<<11) * 100 * time.Millisecond}, // 204.8 s, below the 5 min cap
		{12, 5 * time.Minute},                               // 2^12 × 100 ms = 409.6 s > 5 min → capped
		{36, 5 * time.Minute},                               // just below the old overflow boundary
		{37, 5 * time.Minute},                               // previously caused int64 overflow → negative duration
		{38, 5 * time.Minute},
		{100, 5 * time.Minute}, // well above any reasonable value
	}
	for _, tc := range cases {
		got := initRetryBackoff(tc.i)
		assert.Equal(t, tc.want, got, "i=%d: unexpected backoff duration", tc.i)
		assert.Greater(t, int64(got), int64(0), "i=%d: backoff must always be positive", tc.i)
	}
}

// TestAsyncRepRebuildBackoffDuration verifies the exponential backoff schedule
// for hashtree rebuild failures. The schedule is: 0 (no backoff on first call
// before any failure), 30 s, 60 s, 2 m, 4 m, 8 m, 16 m, capped at 30 m.
// It also verifies that the uint32 overflow guard prevents a negative or zero
// duration for large consecutiveFailures values.
func TestAsyncRepRebuildBackoffDuration(t *testing.T) {
	cases := []struct {
		failures uint32
		want     time.Duration
	}{
		{0, 0},                         // 0 failures → no backoff (called before any failure)
		{1, 30 * time.Second},          // 1st failure
		{2, 60 * time.Second},          // 2nd
		{3, 2 * time.Minute},           // 3rd
		{4, 4 * time.Minute},           // 4th
		{5, 8 * time.Minute},           // 5th
		{6, 16 * time.Minute},          // 6th
		{7, 30 * time.Minute},          // 7th → capped at maxBackoff
		{8, 30 * time.Minute},          // still capped
		{100, 30 * time.Minute},        // well above cap
		{^uint32(0), 30 * time.Minute}, // max uint32: overflow guard must fire
	}
	for _, tc := range cases {
		got := asyncRepRebuildBackoffDuration(tc.failures)
		assert.Equal(t, tc.want, got, "failures=%d", tc.failures)
		if tc.failures > 0 {
			assert.Greater(t, int64(got), int64(0),
				"failures=%d: backoff must always be positive", tc.failures)
		}
	}
}

// TestEffectivePropagationDelay verifies that:
//   - propagationDelay=0 set via per-class API survives Effective() when no
//     global DynamicValue is configured.
//   - a sub-second propagationDelay set via global runtime config is correctly
//     applied (it was silently ignored before the applyDurPositive fix because
//     the old applyDur required v >= a frequency floor, which propagationDelay
//     does not share).
func TestEffectivePropagationDelay(t *testing.T) {
	zero := time.Duration(0)
	fifty := 50 * time.Millisecond

	t.Run("zero_delay_via_class_api_preserved", func(t *testing.T) {
		cfg := AsyncReplicationConfig{
			propagationDelay: defaultPropagationDelay,
			classOverrides: asyncReplicationClassOverrides{
				propagationDelay: &zero,
			},
		}
		result := cfg.Effective(replication.GlobalConfig{})
		assert.Equal(t, time.Duration(0), result.propagationDelay,
			"propagationDelay=0 set via per-class API must survive Effective()")
	})

	t.Run("sub_100ms_delay_via_global_config_applied", func(t *testing.T) {
		cfg := AsyncReplicationConfig{
			propagationDelay: defaultPropagationDelay,
		}
		globals := replication.GlobalConfig{
			AsyncReplicationPropagationDelay: configRuntime.NewDynamicValue(fifty),
		}
		result := cfg.Effective(globals)
		assert.Equal(t, fifty, result.propagationDelay,
			"propagationDelay=50ms via global runtime config must be applied (was silently ignored before fix)")
	})
}

// TestEffectivePrecedence pins the merge order: explicitly-set global (env or runtime override, same DynamicValue) > per-class asyncConfig > code default.
func TestEffectivePrecedence(t *testing.T) {
	classHeight := 12
	classFreq := 20 * time.Second

	tests := []struct {
		name       string
		class      asyncReplicationClassOverrides
		globals    replication.GlobalConfig
		wantHeight int
		wantFreq   time.Duration
	}{
		{
			name:       "neither set -> code defaults",
			wantHeight: defaultHashtreeHeightSingleTenant,
			wantFreq:   defaultFrequency,
		},
		{
			name:       "class only -> class",
			class:      asyncReplicationClassOverrides{hashtreeHeight: &classHeight, frequency: &classFreq},
			wantHeight: classHeight,
			wantFreq:   classFreq,
		},
		{
			name: "global only -> global",
			globals: replication.GlobalConfig{
				AsyncReplicationHashtreeHeight: configRuntime.NewDynamicValue(8),
				AsyncReplicationFrequency:      configRuntime.NewDynamicValue(7 * time.Second),
			},
			wantHeight: 8,
			wantFreq:   7 * time.Second,
		},
		{
			name:  "both set -> global wins",
			class: asyncReplicationClassOverrides{hashtreeHeight: &classHeight, frequency: &classFreq},
			globals: replication.GlobalConfig{
				AsyncReplicationHashtreeHeight: configRuntime.NewDynamicValue(8),
				AsyncReplicationFrequency:      configRuntime.NewDynamicValue(7 * time.Second),
			},
			wantHeight: 8,
			wantFreq:   7 * time.Second,
		},
		{
			name:  "global sub-min -> clamped and still beats class",
			class: asyncReplicationClassOverrides{hashtreeHeight: &classHeight, frequency: &classFreq},
			globals: replication.GlobalConfig{
				AsyncReplicationFrequency: configRuntime.NewDynamicValue(time.Millisecond),
			},
			wantHeight: classHeight,
			wantFreq:   minFrequency,
		},
		{
			name:  "global zero sentinel -> class preserved",
			class: asyncReplicationClassOverrides{hashtreeHeight: &classHeight, frequency: &classFreq},
			globals: replication.GlobalConfig{
				AsyncReplicationHashtreeHeight: configRuntime.NewDynamicValue(0),
				AsyncReplicationFrequency:      configRuntime.NewDynamicValue(time.Duration(0)),
			},
			wantHeight: classHeight,
			wantFreq:   classFreq,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cfg := AsyncReplicationConfig{
				hashtreeHeight: defaultHashtreeHeightSingleTenant,
				frequency:      defaultFrequency,
				classOverrides: tt.class,
			}
			result := cfg.Effective(tt.globals)
			assert.Equal(t, tt.wantHeight, result.hashtreeHeight)
			assert.Equal(t, tt.wantFreq, result.frequency)
		})
	}
}

// newSchedulerForUnitTest returns a fully-running scheduler whose dispatcher
// and single worker are torn down via t.Cleanup. Internal-method tests that
// hold sched.mu serialise naturally with the dispatcher; tests with empty or
// future-dated heaps see no background dispatch.
func newSchedulerForUnitTest(t *testing.T) *AsyncReplicationScheduler {
	t.Helper()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)
	t.Cleanup(sched.Close)
	return sched
}

// newNullLogger returns a discard logger; live loggers here spill expected recovered-panic stacks into CI output.
func newNullLogger() *logrus.Logger {
	logger, _ := test.NewNullLogger()
	return logger
}

// newWorkerPoolTestScheduler builds a scheduler at the given target with no running pool, so adjustWorkers' token/spawn accounting can be driven deterministically.
func newWorkerPoolTestScheduler(t *testing.T, target int) *AsyncReplicationScheduler {
	t.Helper()
	ctx, cancel := context.WithCancel(context.Background())
	s := &AsyncReplicationScheduler{
		ctx:           ctx,
		cancel:        cancel,
		targetWorkers: target,
		scaleDownCh:   make(chan struct{}, maxMaxWorkers),
		workCh:        make(chan *[]*asyncSchedulerEntry, maxMaxWorkers),
		logger:        newNullLogger(),
	}
	t.Cleanup(func() {
		cancel()
		s.wg.Wait()
	})
	return s
}

// TestAsyncSchedulerHeap verifies the min-heap invariants:
//   - entries are popped in ascending nextRunAt order
//   - heapIdx is correct after Push, Pop, Fix, and Remove
func TestAsyncSchedulerHeap(t *testing.T) {
	t.Run("MinHeapOrdering", func(t *testing.T) {
		now := time.Now()
		e1 := &asyncSchedulerEntry{nextRunAt: now.Add(3 * time.Second)}
		e2 := &asyncSchedulerEntry{nextRunAt: now.Add(1 * time.Second)}
		e3 := &asyncSchedulerEntry{nextRunAt: now.Add(2 * time.Second)}

		h := make(asyncSchedulerHeap, 0)
		heap.Push(&h, e1)
		heap.Push(&h, e2)
		heap.Push(&h, e3)

		require.Equal(t, 3, h.Len())
		assert.Equal(t, e2, heap.Pop(&h), "smallest nextRunAt first")
		assert.Equal(t, e3, heap.Pop(&h))
		assert.Equal(t, e1, heap.Pop(&h), "largest nextRunAt last")
	})

	t.Run("HeapIdxAfterPush", func(t *testing.T) {
		h := make(asyncSchedulerHeap, 0)
		for i := range 5 {
			heap.Push(&h, &asyncSchedulerEntry{nextRunAt: time.Now().Add(time.Duration(5-i) * time.Second)})
		}
		for i, e := range h {
			assert.Equal(t, i, e.heapIdx, "heapIdx must equal slice position after push (pos %d)", i)
		}
	})

	t.Run("HeapIdxAfterPop", func(t *testing.T) {
		h := make(asyncSchedulerHeap, 0)
		for i := range 5 {
			heap.Push(&h, &asyncSchedulerEntry{nextRunAt: time.Now().Add(time.Duration(i) * time.Second)})
		}
		heap.Pop(&h)
		for i, e := range h {
			assert.Equal(t, i, e.heapIdx, "heapIdx must equal slice position after pop (pos %d)", i)
		}
	})

	t.Run("FixMovesEntryToTop", func(t *testing.T) {
		now := time.Now()
		e1 := &asyncSchedulerEntry{nextRunAt: now.Add(10 * time.Second)}
		e2 := &asyncSchedulerEntry{nextRunAt: now.Add(20 * time.Second)}

		h := make(asyncSchedulerHeap, 0)
		heap.Push(&h, e1)
		heap.Push(&h, e2)

		// Move e2 into the past → it should become the new minimum.
		e2.nextRunAt = now.Add(-1 * time.Second)
		heap.Fix(&h, e2.heapIdx)

		assert.Equal(t, e2, heap.Pop(&h), "after Fix, e2 (past) must be at top")
	})

	t.Run("HeapIdxAfterRemoveFromMiddle", func(t *testing.T) {
		now := time.Now()
		entries := make([]*asyncSchedulerEntry, 5)
		h := make(asyncSchedulerHeap, 0)
		for i := range 5 {
			entries[i] = &asyncSchedulerEntry{nextRunAt: now.Add(time.Duration(i+1) * time.Second)}
			heap.Push(&h, entries[i])
		}
		heap.Remove(&h, entries[2].heapIdx) // remove the 3 s entry
		require.Equal(t, 4, h.Len())
		for i, e := range h {
			assert.Equal(t, i, e.heapIdx, "heapIdx must be consistent after Remove (pos %d)", i)
		}
	})
}

// TestRegisterDeregisterLifecycle verifies the public Register/Deregister contract:
// entries appear after Register, disappear after Deregister, double-Register is
// idempotent, and Deregister of an unregistered shard is a no-op.
func TestRegisterDeregisterLifecycle(t *testing.T) {
	t.Run("RegisterCreatesEntry", func(t *testing.T) {
		sched := newSchedulerForUnitTest(t)
		s := &Shard{}
		require.NoError(t, sched.Register(s))

		sched.mu.Lock()
		n := len(sched.entries)
		_, ok := sched.entries[s]
		sched.mu.Unlock()
		assert.Equal(t, 1, n)
		assert.True(t, ok, "shard must be present in entries after Register")
	})

	t.Run("RegisterIsIdempotent", func(t *testing.T) {
		sched := newSchedulerForUnitTest(t)
		s := &Shard{}
		require.NoError(t, sched.Register(s))
		require.NoError(t, sched.Register(s))

		sched.mu.Lock()
		n := len(sched.entries)
		sched.mu.Unlock()
		assert.Equal(t, 1, n, "double Register must not create a second entry")
	})

	t.Run("RegisterMultipleShards", func(t *testing.T) {
		sched := newSchedulerForUnitTest(t)
		s1, s2 := &Shard{}, &Shard{}
		require.NoError(t, sched.Register(s1))
		require.NoError(t, sched.Register(s2))

		sched.mu.Lock()
		n := len(sched.entries)
		sched.mu.Unlock()
		assert.Equal(t, 2, n)
	})

	t.Run("DeregisterRemovesEntry", func(t *testing.T) {
		sched := newSchedulerForUnitTest(t)
		s := &Shard{}
		require.NoError(t, sched.Register(s))
		require.NoError(t, sched.Deregister(s))

		sched.mu.Lock()
		n := len(sched.entries)
		sched.mu.Unlock()
		assert.Equal(t, 0, n)
	})

	t.Run("DeregisterUnregisteredIsNoOp", func(t *testing.T) {
		sched := newSchedulerForUnitTest(t)
		assert.NoError(t, sched.Deregister(&Shard{}))
	})
}

// TestHeapFIFOTieBreakingSeq verifies that when multiple entries share the same
// nextRunAt the heap pops them in ascending seq order (i.e. FIFO on enqueue
// time). This exercises the Less() tie-break that was added to prevent
// arbitrary heap-internal ordering from starving recently-enqueued shards.
func TestHeapFIFOTieBreakingSeq(t *testing.T) {
	now := time.Now()
	seqValues := []uint64{10, 3, 7, 1, 5}

	h := make(asyncSchedulerHeap, 0)
	for _, seq := range seqValues {
		heap.Push(&h, &asyncSchedulerEntry{nextRunAt: now, seq: seq})
	}

	var got []uint64
	for h.Len() > 0 {
		e := heap.Pop(&h).(*asyncSchedulerEntry)
		got = append(got, e.seq)
	}

	require.Equal(t, len(seqValues), len(got))
	for i := 1; i < len(got); i++ {
		assert.Less(t, got[i-1], got[i],
			"entries with equal nextRunAt must pop in ascending seq (FIFO) order; "+
				"got seq[%d]=%d before seq[%d]=%d", i-1, got[i-1], i, got[i])
	}
}

// Deleted: TestOnResultLockedEpochRelativeScheduling.
//
// The epoch-relative scheduling property (a late shard climbs the heap back
// against on-time shards; the look-back floor caps catch-up bursts) is a
// timing invariant of the internal onResultLocked path that has no direct
// behavioural observation point. The standalone heap tests (TestAsyncSchedulerHeap,
// TestHeapFIFOTieBreakingSeq) cover the underlying ordering guarantees, and the
// integration tests in async_replication_scheduler_integration_test.go exercise
// the dispatcher with real shards. Removed during the constructor-spawns-workers
// migration where direct mutation of sched.h races with the live dispatcher.

// TestAsyncSchedulerNextInterval is a table-driven test covering all branches
// of nextInterval: success paths and the four error variants.
func TestAsyncSchedulerNextInterval(t *testing.T) {
	const (
		freq     = 10 * time.Second
		freqProp = 2 * time.Second
	)
	cfg := AsyncReplicationConfig{
		frequency:                 freq,
		frequencyWhilePropagating: freqProp,
	}

	cancelledCtx, cancel := context.WithCancel(context.Background())
	cancel()

	newEntry := func(ctx context.Context) *asyncSchedulerEntry {
		return &asyncSchedulerEntry{
			shard: &Shard{asyncRepCtx: ctx},
		}
	}

	sched := newSchedulerForUnitTest(t)

	tests := []struct {
		name         string
		ctx          context.Context
		err          error
		propagated   bool
		wantInterval time.Duration
	}{
		{
			name:         "no error not propagated returns frequency",
			ctx:          context.Background(),
			wantInterval: freq,
		},
		{
			name:         "no error propagated returns frequencyWhilePropagating",
			ctx:          context.Background(),
			propagated:   true,
			wantInterval: freqProp,
		},
		{
			name:         "ErrNoDiffFound returns frequency",
			ctx:          context.Background(),
			err:          replicaerrors.ErrNoDiffFound,
			wantInterval: freq,
		},
		{
			name:         "context cancelled returns 24h",
			ctx:          cancelledCtx,
			err:          context.Canceled,
			wantInterval: 24 * time.Hour,
		},
		{
			name:         "generic transient error returns frequency",
			ctx:          context.Background(),
			err:          errors.New("transient error"),
			wantInterval: freq,
		},
	}

	// Nil-context guard: a shard registered before initAsyncReplication sets
	// asyncRepCtx must not panic when nextInterval is called with an error.
	t.Run("nil asyncRepCtx with error does not panic", func(t *testing.T) {
		entry := &asyncSchedulerEntry{
			shard: &Shard{asyncRepCtx: nil},
		}
		result := asyncSchedulerResult{entry: entry, err: errors.New("some error")}
		assert.NotPanics(t, func() { sched.nextInterval(cfg, entry, result) })
	})

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			entry := newEntry(tc.ctx)
			result := asyncSchedulerResult{entry: entry, propagated: tc.propagated, err: tc.err, ctx: tc.ctx}

			got := sched.nextInterval(cfg, entry, result)

			assert.Equal(t, tc.wantInterval, got)
		})
	}
}

// TestAdjustWorkersCapAtMaxMaxWorkers verifies that adjustWorkers never sets
// targetWorkers above maxMaxWorkers, even when called with a larger value.
// This is a safety property: resultCh is sized maxMaxWorkers*2 and must never
// be smaller than the number of concurrent workers.
func TestAdjustWorkersCapAtMaxMaxWorkers(t *testing.T) {
	sched := newSchedulerForUnitTest(t) // helper registers t.Cleanup(sched.Close)

	sched.adjustWorkers(maxMaxWorkers + 100)

	sched.workersMu.Lock()
	got := sched.targetWorkers
	sched.workersMu.Unlock()

	assert.Equal(t, maxMaxWorkers, got,
		"adjustWorkers must cap targetWorkers at maxMaxWorkers (%d)", maxMaxWorkers)
}

// TestRebuildInFlightSerializationAtomics documents and exercises the CAS
// pattern used in runEntry's defer to prevent concurrent hashtree rebuilds.
//
// When asyncRepRebuildInFlight is already true (first rebuild goroutine
// running), a second attempt must NOT start a new rebuild. Instead it must
// re-arm asyncRepNeedsRebuild so that the next completed hashbeat cycle retries.
func TestRebuildInFlightSerializationAtomics(t *testing.T) {
	s := &Shard{}

	// First rebuild goroutine acquires the flag (CAS false→true succeeds).
	firstAcquired := s.asyncRepRebuildInFlight.CompareAndSwap(false, true)
	require.True(t, firstAcquired, "first CAS must succeed when flag is clear")

	// Second concurrent attempt (the same CAS in runEntry's defer) must fail.
	secondAcquired := s.asyncRepRebuildInFlight.CompareAndSwap(false, true)
	require.False(t, secondAcquired, "second CAS must fail while first rebuild is in-flight")

	// The else-branch re-arms asyncRepNeedsRebuild so the next cycle retries.
	if !secondAcquired {
		s.asyncRepNeedsRebuild.Store(true)
	}

	assert.True(t, s.asyncRepNeedsRebuild.Load(),
		"asyncRepNeedsRebuild must be re-armed when a rebuild is already in-flight")
	assert.True(t, s.asyncRepRebuildInFlight.Load(),
		"asyncRepRebuildInFlight must remain set (first rebuild still running)")

	// First rebuild goroutine finishes; flag is cleared.
	s.asyncRepRebuildInFlight.Store(false)

	// asyncRepNeedsRebuild remains set — a future cycle will trigger a new rebuild.
	assert.True(t, s.asyncRepNeedsRebuild.Load(),
		"asyncRepNeedsRebuild must remain set after first rebuild completes")
}

// Deleted: TestDispatchDueLocked_AllWorkersBusy, TestDispatchDueLocked_InFlightEntryIsReset,
// TestOnResultLocked_DeregisteredMidFlight.
//
// These tests poked the heap and inFlight state directly to exercise three
// internal paths:
//   - workCh-full backpressure with asyncRepWg balance
//   - defensive recovery from an inFlight-in-heap invariant violation
//   - discarding a result for a deregistered shard
//
// The first property is covered behaviorally by TestWorkerDrainsWorkChOnCtxCancel
// and TestSchedulerCloseWithConcurrentDispatches (Close completes promptly with
// asyncRepWg balanced). The second is dead-code recovery for a state that
// cannot occur via the public API. The third is covered transitively by the
// concurrent Register/Deregister/Close integration test
// (TestAsyncSchedulerConcurrentRegisterDeregisterAndClose) — a deregistered
// shard whose cycle was in-flight will not be re-enqueued or the test would
// deadlock during shutdown. Removed during the constructor-spawns-workers
// migration where direct mutation of sched.h races with the live dispatcher.

// ─── adjustWorkers ────────────────────────────────────────────────────────────

// TestAdjustWorkersClampToDefault verifies that zero and negative arguments are
// mapped to defaultAsyncReplicationSchedulerWorkers, matching the construction-time
// behaviour of NewAsyncReplicationScheduler.
func TestAdjustWorkersClampToDefault(t *testing.T) {
	cases := []struct {
		name    string
		initial int
		arg     int
	}{
		{"zero_from_one", 1, 0},
		{"zero_from_three", 3, 0},
		{"negative_from_three", 3, -5},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
				AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(tc.initial),
				AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
			}, nil, nil)
			require.NoError(t, err)
			t.Cleanup(sched.Close)

			sched.adjustWorkers(tc.arg)

			sched.workersMu.Lock()
			got := sched.targetWorkers
			sched.workersMu.Unlock()
			assert.Equal(t, defaultAsyncReplicationSchedulerWorkers, got,
				"adjustWorkers(%d) from %d must map to defaultAsyncReplicationSchedulerWorkers", tc.arg, tc.initial)
		})
	}
}

// TestAdjustWorkersUpdatesTargetWorkers verifies the observable contract of
// adjustWorkers: targetWorkers is updated to the requested value (clamped to
// the valid range). The previous tests asserted exact pending-token counts in
// scaleDownCh, which depended on no-running-workers semantics that no longer
// exist. With a live worker pool, tokens are consumed concurrently and only
// the post-condition (targetWorkers == requested) is race-free.
func TestAdjustWorkersUpdatesTargetWorkers(t *testing.T) {
	t.Run("ScaleDown", func(t *testing.T) {
		sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
			AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(5),
			AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
		}, nil, nil)
		require.NoError(t, err)
		t.Cleanup(sched.Close)

		sched.adjustWorkers(2)

		sched.workersMu.Lock()
		got := sched.targetWorkers
		sched.workersMu.Unlock()
		assert.Equal(t, 2, got, "targetWorkers must reflect the scale-down target")
	})

	t.Run("ScaleUp", func(t *testing.T) {
		sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
			AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(2),
			AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
		}, nil, nil)
		require.NoError(t, err)
		t.Cleanup(sched.Close)

		sched.adjustWorkers(8)

		sched.workersMu.Lock()
		got := sched.targetWorkers
		sched.workersMu.Unlock()
		assert.Equal(t, 8, got, "targetWorkers must reflect the scale-up target")
	})

	t.Run("RapidDownUp", func(t *testing.T) {
		sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
			AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(5),
			AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
		}, nil, nil)
		require.NoError(t, err)
		t.Cleanup(sched.Close)

		sched.adjustWorkers(2)
		sched.adjustWorkers(8)

		sched.workersMu.Lock()
		got := sched.targetWorkers
		sched.workersMu.Unlock()
		assert.Equal(t, 8, got, "after down-then-up, targetWorkers must be 8")
	})
}

// TestAdjustWorkersGrowReclaimsPendingTokensBeforeSpawning pins the grow-path leak: growing must reclaim at most delta stale scale-down tokens and spawn only the shortfall, never drain all tokens and spawn delta on top.
func TestAdjustWorkersGrowReclaimsPendingTokensBeforeSpawning(t *testing.T) {
	cases := []struct {
		name          string
		initialTarget int
		pending       int
		growTo        int
		wantSpawned   int64
		wantRemaining int
	}{
		{"full_reclaim_no_spawn", 2, 8, 10, 0, 0},
		{"partial_reclaim", 2, 4, 10, 4, 0},
		{"no_pending_spawns_all", 2, 0, 10, 8, 0},
		{"reclaim_capped_at_delta", 2, 8, 6, 0, 4},
		{"cap_then_reclaim", 2, 8, maxMaxWorkers + 50, int64(maxMaxWorkers - 2 - 8), 0},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			sched := newWorkerPoolTestScheduler(t, tc.initialTarget)
			for range tc.pending {
				sched.scaleDownCh <- struct{}{}
			}
			// Physical pool state: pending retirements imply that many still-live workers on top of the target.
			seeded := int64(tc.initialTarget + tc.pending)
			sched.liveWorkers.Store(seeded)

			sched.adjustWorkers(tc.growTo)

			assert.Equal(t, tc.wantSpawned, sched.liveWorkers.Load()-seeded,
				"grow must spawn only the shortfall after reclaiming pending tokens")
			assert.Equal(t, tc.wantRemaining, len(sched.scaleDownCh),
				"grow must reclaim at most delta tokens, not all of them")
		})
	}
}

// Deleted: TestAdjustWorkersScaleDownUpdatesTargetAndSendsTokens,
// TestAdjustWorkersScaleUpDrainsStaleTokens, TestAdjustWorkersRapidDownUp.
//
// These asserted exact scaleDownCh token counts, which is only meaningful when
// no worker goroutines are running to consume them. With the constructor now
// spawning the worker pool, tokens are consumed concurrently and the count
// becomes racy. The observable post-condition (targetWorkers reaches the
// requested value, tests above) is preserved.

// TestAdjustWorkersCapWarnsWithLogger verifies that when adjustWorkers clamps a
// requested count above maxMaxWorkers, a warning is logged (logger non-nil path).
func TestAdjustWorkersCapWarnsWithLogger(t *testing.T) {
	logger, hook := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)
	t.Cleanup(sched.Close)

	sched.adjustWorkers(maxMaxWorkers + 5)

	sched.workersMu.Lock()
	got := sched.targetWorkers
	sched.workersMu.Unlock()
	assert.Equal(t, maxMaxWorkers, got, "targetWorkers must be capped at maxMaxWorkers")

	var warned bool
	for _, entry := range hook.Entries {
		if entry.Level == logrus.WarnLevel {
			warned = true
			break
		}
	}
	assert.True(t, warned, "a warning must be logged when the worker count is clamped")
}

// TestRebuildHashtreeEnableFailureRetriesUntilShutdown: a failed enable is retried with backoff; the loop exits once the shard shuts down.
func TestRebuildHashtreeEnableFailureRetriesUntilShutdown(t *testing.T) {
	prevBackoff := asyncRepRebuildBaseBackoff.Load()
	asyncRepRebuildBaseBackoff.Store(int64(time.Millisecond))
	t.Cleanup(func() { asyncRepRebuildBaseBackoff.Store(prevBackoff) })

	sched := newSchedulerForUnitTest(t)

	// Nil store on the shard → enableAsyncReplication returns an error immediately.
	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	done := make(chan struct{})
	go func() {
		sched.rebuildHashtree(s)
		close(done)
	}()

	require.Eventually(t, func() bool { return s.asyncRepRebuildFailures.Load() >= 2 },
		5*time.Second, time.Millisecond, "a failed enable must be retried")

	s.shut.Store(true)
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("retry loop did not exit after the shard shut down")
	}
}

// TestTryRebuildHashtreeYieldsWhileApplyLockHeld: a rebuild attempt must not queue behind a running config fan-out — it yields immediately with the contention backoff.
func TestTryRebuildHashtreeYieldsWhileApplyLockHeld(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	idx.asyncReplicationApplyLock.Lock()
	defer idx.asyncReplicationApplyLock.Unlock()

	type attempt struct {
		retry bool
		delay time.Duration
	}
	attemptDone := make(chan attempt, 1)
	go func() {
		retry, delay, _, _ := sched.tryRebuildHashtree(s)
		attemptDone <- attempt{retry, delay}
	}()

	select {
	case a := <-attemptDone:
		require.True(t, a.retry)
		require.Equal(t, asyncRepRebuildContentionBackoff, a.delay)
		require.Zero(t, s.asyncRepRebuildFailures.Load(), "yield is not a failure")
	case <-time.After(5 * time.Second):
		t.Fatal("tryRebuildHashtree queued behind the apply lock instead of yielding")
	}
}

// TestTryRebuildHashtreeYieldsToPendingWaiter: a blocking apply-lock acquirer waiting in Lock() makes the attempt abort with the contention backoff instead of running a full rebuild.
func TestTryRebuildHashtreeYieldsToPendingWaiter(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	idx.asyncReplicationApplyWaiters.Store(1)

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.True(t, retry)
	require.Equal(t, asyncRepRebuildContentionBackoff, delay)
	require.False(t, rebuilt)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "yield is not a failure")
}

// TestTryRebuildHashtreeIgnoresShutdownLock: an attempt proceeds into disable→enable while a writer holds shutdownLock — the rebuild neither blocks on nor delays shard teardown locking.
func TestTryRebuildHashtreeIgnoresShutdownLock(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	s.shutdownLock.Lock()
	defer s.shutdownLock.Unlock()

	type attempt struct {
		retry bool
		delay time.Duration
	}
	attemptDone := make(chan attempt, 1)
	go func() {
		retry, delay, _, _ := sched.tryRebuildHashtree(s)
		attemptDone <- attempt{retry, delay}
	}()

	select {
	case a := <-attemptDone:
		require.True(t, a.retry, "the enable failure (nil store on the shard) must request a retry")
		require.Positive(t, a.delay)
		require.EqualValues(t, 1, s.asyncRepRebuildFailures.Load(), "the attempt must reach enableAsyncReplication")
	case <-time.After(5 * time.Second):
		t.Fatal("tryRebuildHashtree blocked on a held shutdownLock")
	}
}

// TestTryRebuildHashtreeStopsWhenGloballyDisabled: a kill-switch flip between attempts must terminate the rebuild instead of resurrecting async replication.
func TestTryRebuildHashtreeStopsWhenGloballyDisabled(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	idx.globalreplicationConfig = &replication.GlobalConfig{
		AsyncReplicationDisabled: configRuntime.NewDynamicValue(true),
	}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.False(t, retry, "a disabled decision is terminal, not retried")
	require.Zero(t, delay)
	require.False(t, rebuilt)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "the attempt must stop before disable/enable")
}

// TestTryRebuildHashtreeYieldsWhileShutdownRequested: teardown intent makes the attempt stand down before touching any state.
func TestTryRebuildHashtreeYieldsWhileShutdownRequested(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}
	s.shutdownRequested.Store(true)

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.True(t, retry)
	require.Equal(t, asyncRepRebuildContentionBackoff, delay)
	require.False(t, rebuilt)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "standing down is not a failure")
}

// TestTryRebuildHashtreeYieldsWhileHaltedForTransfer: a backup/offload halt makes the attempt stand down instead of re-enabling mid-transfer.
func TestTryRebuildHashtreeYieldsWhileHaltedForTransfer(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}
	s.haltForTransferCount.Store(1)

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.True(t, retry)
	require.Equal(t, asyncRepRebuildContentionBackoff, delay)
	require.False(t, rebuilt)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "standing down is not a failure")
}

// TestTryRebuildHashtreePinnedWorkerYieldsBeforeDisable: a wedged in-flight cycle makes the attempt yield with the tree still installed, never after tearing it down.
func TestTryRebuildHashtreePinnedWorkerYieldsBeforeDisable(t *testing.T) {
	prevDrain := asyncReplicationWorkerDrainTimeout.Load()
	asyncReplicationWorkerDrainTimeout.Store(int64(50 * time.Millisecond))
	t.Cleanup(func() { asyncReplicationWorkerDrainTimeout.Store(prevDrain) })

	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	ht, err := hashtree.NewHashTree(4)
	require.NoError(t, err)
	s := &Shard{
		class:                    &models.Class{Class: "TestClass"},
		index:                    idx,
		shutdownLock:             new(sync.RWMutex),
		hashtree:                 ht,
		hashtreeFullyInitialized: true,
	}

	s.asyncRepWg.Add(1)
	t.Cleanup(s.asyncRepWg.Done)

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.True(t, retry)
	require.Equal(t, asyncRepRebuildContentionBackoff, delay)
	require.False(t, rebuilt)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "a wedged drain before any state change is a yield, not a failure")
	require.NotNil(t, s.hashtree, "the shard must stay in the repair mesh when the pre-drain times out")
	require.True(t, s.hashtreeFullyInitialized)
}

// TestTryRebuildHashtreePreDrainDoesNotHoldApplyLock: the bounded pre-drain wait must not sit inside the apply lock, or every schema apply on the index stalls behind a wedged cycle.
func TestTryRebuildHashtreePreDrainDoesNotHoldApplyLock(t *testing.T) {
	prevDrain := asyncReplicationWorkerDrainTimeout.Load()
	asyncReplicationWorkerDrainTimeout.Store(int64(2 * time.Second))
	t.Cleanup(func() { asyncReplicationWorkerDrainTimeout.Store(prevDrain) })

	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	ht, err := hashtree.NewHashTree(4)
	require.NoError(t, err)
	s := &Shard{
		class:                    &models.Class{Class: "TestClass"},
		index:                    idx,
		shutdownLock:             new(sync.RWMutex),
		hashtree:                 ht,
		hashtreeFullyInitialized: true,
	}

	s.asyncRepWg.Add(1)
	t.Cleanup(s.asyncRepWg.Done)

	retryCh := make(chan bool, 1)
	go func() {
		retry, _, _, _ := sched.tryRebuildHashtree(s)
		retryCh <- retry
	}()

	require.Eventually(t, func() bool {
		s.asyncRepDrainMu.Lock()
		defer s.asyncRepDrainMu.Unlock()
		return s.asyncRepDrainObserver != nil
	}, 5*time.Second, time.Millisecond, "the attempt never entered its pre-drain wait")

	if idx.asyncReplicationApplyLock.TryLock() {
		idx.asyncReplicationApplyLock.Unlock()
	} else {
		t.Fatal("the apply lock is held during the pre-drain wait — schema applies stall behind a wedged cycle")
	}

	require.True(t, <-retryCh, "a wedged pre-drain must yield")
}

// TestNextRebuildRetryDelay pins the yield-escalation schedule: constant below the threshold, failure-backoff growth past it, failures untouched.
func TestNextRebuildRetryDelay(t *testing.T) {
	tests := []struct {
		name   string
		delay  time.Duration
		yields uint32
		want   time.Duration
	}{
		{"first yield stays constant", asyncRepRebuildContentionBackoff, 1, asyncRepRebuildContentionBackoff},
		{"below threshold stays constant", asyncRepRebuildContentionBackoff, asyncRepRebuildYieldEscalationThreshold - 1, asyncRepRebuildContentionBackoff},
		{"threshold starts the backoff schedule", asyncRepRebuildContentionBackoff, asyncRepRebuildYieldEscalationThreshold, asyncRepRebuildBackoffDuration(1)},
		{"past threshold doubles", asyncRepRebuildContentionBackoff, asyncRepRebuildYieldEscalationThreshold + 3, asyncRepRebuildBackoffDuration(4)},
		{"escalation caps at max backoff", asyncRepRebuildContentionBackoff, asyncRepRebuildYieldEscalationThreshold + 100, asyncRepRebuildMaxBackoff},
		{"failure backoff passes through", 8 * time.Minute, asyncRepRebuildYieldEscalationThreshold + 5, 8 * time.Minute},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.want, nextRebuildRetryDelay(tc.delay, tc.yields))
		})
	}
}

func waitAsyncRepDrained(t *testing.T, s *Shard, msg string) {
	t.Helper()
	select {
	case <-s.asyncRepDrained(newNullLogger()):
	case <-time.After(5 * time.Second):
		t.Fatal(msg)
	}
}

// TestWorkerPoolSelfHealsAfterWorkerDeath: a worker lost without a target change must be respawned by the periodic reconcile, or a single escaped panic kills all dispatching forever at the default pool size of 1.
func TestWorkerPoolSelfHealsAfterWorkerDeath(t *testing.T) {
	sched := newSchedulerForUnitTest(t)
	require.Eventually(t, func() bool { return sched.liveWorkers.Load() == 1 }, 5*time.Second, time.Millisecond)

	sched.scaleDownCh <- struct{}{}
	require.Eventually(t, func() bool { return sched.liveWorkers.Load() == 0 }, 5*time.Second, time.Millisecond)

	sched.adjustWorkers(sched.maxWorkersConfig.Get())
	require.Eventually(t, func() bool { return sched.liveWorkers.Load() == 1 }, 3*time.Second, time.Millisecond,
		"the pool must heal back to target on the watcher's periodic reconcile")
}

type panicOnErrorHook struct{}

func (panicOnErrorHook) Levels() []logrus.Level { return []logrus.Level{logrus.ErrorLevel} }

func (panicOnErrorHook) Fire(*logrus.Entry) error { panic("hook exploded") }

func newPanicHookScheduler(t *testing.T) *AsyncReplicationScheduler {
	t.Helper()
	logger := logrus.New()
	logger.SetOutput(io.Discard)
	logger.AddHook(panicOnErrorHook{})
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)
	t.Cleanup(sched.Close)
	return sched
}

type panickingHeightTree struct{ hashtree.AggregatedHashTree }

func (panickingHeightTree) Height() int { panic("height exploded") }

// TestRunEntryOwnedDoneSurvivesPanickingLogger: a panic inside the recover block's logging must not leak the owned Done and pin the shard's drains forever.
func TestRunEntryOwnedDoneSurvivesPanickingLogger(t *testing.T) {
	sched := newPanicHookScheduler(t)
	s := &Shard{class: &models.Class{Class: "C"}, index: &Index{}, hashtree: panickingHeightTree{}}
	entry := &asyncSchedulerEntry{shard: s}

	s.asyncRepWg.Add(1)
	require.Panics(t, func() { sched.runEntry(entry, false) })
	waitAsyncRepDrained(t, s, "the owned Done leaked: a panicking log hook must not skip asyncRepWg.Done")
}

// TestRunBatchSettlesEntriesBeforePanickingLogger: the batch panic path must settle unfinished entries before logging, or a panicking hook leaks every Done in the batch.
func TestRunBatchSettlesEntriesBeforePanickingLogger(t *testing.T) {
	sched := newPanicHookScheduler(t)
	s1 := &Shard{name: "s1", class: &models.Class{Class: "C"}, index: &Index{}}
	s2 := &Shard{name: "s2", class: &models.Class{Class: "C"}, index: &Index{}}
	e1 := &asyncSchedulerEntry{shard: s1}
	e2 := &asyncSchedulerEntry{shard: s2}
	for _, e := range []*asyncSchedulerEntry{e1, e2} {
		e.shard.asyncRepWg.Add(1)
		e.pendingDone.Store(true)
	}

	prevSeam := asyncRepBatchEntrySeam
	asyncRepBatchEntrySeam = func(*asyncSchedulerEntry) { panic("seam exploded") }
	t.Cleanup(func() { asyncRepBatchEntrySeam = prevSeam })

	batch := []*asyncSchedulerEntry{e1, e2}
	require.Panics(t, func() { sched.runBatch(&batch, newBatchScratch()) })
	waitAsyncRepDrained(t, s1, "s1's Done leaked in the batch panic path")
	waitAsyncRepDrained(t, s2, "s2's Done leaked in the batch panic path")
}

// TestDispatchInvariantRecoverySettlesPendingDone: the inFlight-in-heap recovery must settle a still-pending Done before re-queuing, or the next dispatch overwrites the token and leaks one count forever.
func TestDispatchInvariantRecoverySettlesPendingDone(t *testing.T) {
	sched := newSchedulerForUnitTest(t)
	s := &Shard{class: &models.Class{Class: "C"}, index: &Index{}}
	entry := &asyncSchedulerEntry{shard: s, inFlight: true, nextRunAt: time.Now().Add(-time.Second)}
	s.asyncRepWg.Add(1)
	entry.pendingDone.Store(true)

	sched.mu.Lock()
	sched.entries[s] = entry
	heap.Push(&sched.h, entry)
	sched.dispatchDueLocked()
	sched.mu.Unlock()

	waitAsyncRepDrained(t, s, "the invariant recovery leaked the pending Done")
}

// TestAsyncRepDrainObserverSharedAcrossAttempts: bounded waits during one pinned episode share a single waiter goroutine and the observer resets once drained.
func TestAsyncRepDrainObserverSharedAcrossAttempts(t *testing.T) {
	s := &Shard{index: &Index{}}
	logger := newNullLogger()

	s.asyncRepWg.Add(1)
	ch1 := s.asyncRepDrained(logger)
	ch2 := s.asyncRepDrained(logger)
	require.True(t, ch1 == ch2, "waits during one pinned episode must share the observer")

	s.asyncRepWg.Done()
	select {
	case <-ch1:
	case <-time.After(5 * time.Second):
		t.Fatal("observer did not close after the WaitGroup drained")
	}

	require.Eventually(t, func() bool {
		s.asyncRepDrainMu.Lock()
		defer s.asyncRepDrainMu.Unlock()
		return s.asyncRepDrainObserver == nil
	}, 5*time.Second, time.Millisecond)
}

// TestTryRebuildHashtreePostDisableDrainTimeoutIsFailure: a straggler pinning the drain after the disable must count as a rebuild failure with growing backoff.
func TestTryRebuildHashtreePostDisableDrainTimeoutIsFailure(t *testing.T) {
	prevDrain := asyncReplicationWorkerDrainTimeout.Load()
	asyncReplicationWorkerDrainTimeout.Store(int64(50 * time.Millisecond))
	t.Cleanup(func() { asyncReplicationWorkerDrainTimeout.Store(prevDrain) })

	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	asyncRepRebuildAfterDisable = func(pinned *Shard) { pinned.asyncRepWg.Add(1) }
	t.Cleanup(func() {
		asyncRepRebuildAfterDisable = nil
		s.asyncRepWg.Done()
	})

	retry, delay, rebuilt, _ := sched.tryRebuildHashtree(s)
	require.True(t, retry)
	require.False(t, rebuilt)
	require.Positive(t, delay)
	require.EqualValues(t, 1, s.asyncRepRebuildFailures.Load(), "a post-disable drain timeout is a real failure, not a silent yield")
}

// TestTryRebuildHashtreeRetriesWhenEnableSkippedByHalt: a halt racing the disable→enable window must leave the attempt retrying, never silently disabled.
func TestTryRebuildHashtreeRetriesWhenEnableSkippedByHalt(t *testing.T) {
	prevDrain := asyncReplicationWorkerDrainTimeout.Load()
	asyncReplicationWorkerDrainTimeout.Store(int64(50 * time.Millisecond))
	t.Cleanup(func() { asyncReplicationWorkerDrainTimeout.Store(prevDrain) })

	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	ht, err := hashtree.NewHashTree(4)
	require.NoError(t, err)
	s := &Shard{
		class:                      &models.Class{Class: "TestClass"},
		index:                      idx,
		shutdownLock:               new(sync.RWMutex),
		hashtree:                   ht,
		hashtreeFullyInitialized:   true,
		asyncReplicationCancelFunc: func() {},
	}

	asyncRepRebuildAfterDisable = func(halted *Shard) { halted.haltForTransferCount.Store(1) }
	t.Cleanup(func() {
		asyncRepRebuildAfterDisable = nil
		s.haltForTransferCount.Store(0)
	})

	retry, delay, rebuilt, yielded := sched.tryRebuildHashtree(s)
	require.True(t, retry, "a skipped enable must retry, not silently leave async replication off")
	require.True(t, yielded)
	require.False(t, rebuilt)
	require.Equal(t, asyncRepRebuildContentionBackoff, delay)
	require.Zero(t, s.asyncRepRebuildFailures.Load(), "a raced halt is a yield, not a failure")
}

// TestMayStopAsyncReplicationDrainsWithNilHashtree: teardown must wait for in-flight workers even when it lands in a rebuild's hashtree-nil window.
func TestMayStopAsyncReplicationDrainsWithNilHashtree(t *testing.T) {
	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}, logger: newNullLogger()}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	s.asyncRepWg.Add(1)
	done := make(chan struct{})
	go func() {
		require.Nil(t, s.mayStopAsyncReplication(true))
		close(done)
	}()

	select {
	case <-done:
		t.Fatal("mayStopAsyncReplication returned without draining the in-flight worker")
	case <-time.After(150 * time.Millisecond):
	}

	s.asyncRepWg.Done()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("mayStopAsyncReplication did not return after the worker drained")
	}
}

// TestApplyLockFreeWhileRebuildRetries: a schema apply acquires the apply lock promptly while the rebuild loop retries against a shard whose teardown holds shutdownLock.
func TestApplyLockFreeWhileRebuildRetries(t *testing.T) {
	prevBackoff := asyncRepRebuildBaseBackoff.Load()
	asyncRepRebuildBaseBackoff.Store(int64(time.Millisecond))
	t.Cleanup(func() { asyncRepRebuildBaseBackoff.Store(prevBackoff) })

	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass", ReplicationFactor: 3}}
	idx.asyncReplicationScheduler = sched
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	s.shutdownLock.Lock()
	defer s.shutdownLock.Unlock()

	done := make(chan struct{})
	go func() {
		sched.rebuildHashtree(s)
		close(done)
	}()

	require.Eventually(t, func() bool { return s.asyncRepRebuildFailures.Load() >= 1 },
		5*time.Second, time.Millisecond, "the attempt must run despite the held shutdownLock")

	acquired := make(chan struct{})
	go func() {
		idx.asyncReplicationApplyWaiters.Add(1)
		idx.asyncReplicationApplyLock.Lock()
		idx.asyncReplicationApplyWaiters.Add(-1)
		idx.asyncReplicationApplyLock.Unlock()
		close(acquired)
	}()

	select {
	case <-acquired:
	case <-time.After(5 * time.Second):
		t.Fatal("a schema apply blocked behind the rebuild while a teardown held shutdownLock")
	}

	s.shut.Store(true)
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("retry loop did not exit after the shard shut down")
	}
}

// TestNextIntervalErrNoDiffFoundWithPropagatedTrue verifies that ErrNoDiffFound
// always returns the base frequency — even when propagated=true — because an
// empty diff means there is nothing to propagate in the next cycle.
func TestNextIntervalErrNoDiffFoundWithPropagatedTrue(t *testing.T) {
	const (
		freq     = 10 * time.Second
		freqProp = 2 * time.Second
	)
	cfg := AsyncReplicationConfig{
		frequency:                 freq,
		frequencyWhilePropagating: freqProp,
	}
	sched := newSchedulerForUnitTest(t)

	entry := &asyncSchedulerEntry{shard: &Shard{asyncRepCtx: context.Background()}}
	result := asyncSchedulerResult{
		entry:      entry,
		err:        replicaerrors.ErrNoDiffFound,
		propagated: true, // propagated=true must NOT override the error path
		ctx:        context.Background(),
	}

	got := sched.nextInterval(cfg, entry, result)
	assert.Equal(t, freq, got,
		"ErrNoDiffFound must return base frequency regardless of propagated flag")
}

// TestAdjustWorkersConcurrent verifies that concurrent adjustWorkers calls do
// not produce data races (run with -race). Final targetWorkers must be within
// the valid range [1, maxMaxWorkers].
func TestAdjustWorkersConcurrent(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(3),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)
	t.Cleanup(sched.Close)

	const goroutines = 10
	ready := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(goroutines)
	for i := range goroutines {
		n := i + 1 // vary between 1 and goroutines
		go func() {
			defer wg.Done()
			<-ready
			sched.adjustWorkers(n)
		}()
	}
	close(ready)
	wg.Wait()

	sched.workersMu.Lock()
	got := sched.targetWorkers
	sched.workersMu.Unlock()
	assert.GreaterOrEqual(t, got, 1, "targetWorkers must be >= 1 after concurrent adjustWorkers")
	assert.LessOrEqual(t, got, maxMaxWorkers, "targetWorkers must be <= maxMaxWorkers after concurrent adjustWorkers")
}

// TestAsyncReplicationConfigFromModelFrequencyFloor verifies that
// asyncReplicationConfigFromModel clamps sub-minimum frequency /
// frequencyWhilePropagating values up to the minimum (logging a Warn) and
// preserves values at or above it. The lenient clamp-and-warn behavior is
// required for backwards compatibility with collections persisted before the
// minimums were raised.
func TestAsyncReplicationConfigFromModelFrequencyFloor(t *testing.T) {
	// pick boundary inputs relative to each field's own minimum.
	freqBelow := int64(minFrequency/time.Millisecond) - 1 // just below 5s
	freqExact := int64(minFrequency / time.Millisecond)   // exactly at 5s
	freqAbove := int64(minFrequency/time.Millisecond) + 1 // just above 5s

	fwpBelow := int64(minFrequencyWhilePropagating/time.Millisecond) - 1 // just below 1s
	fwpExact := int64(minFrequencyWhilePropagating / time.Millisecond)   // exactly at 1s
	fwpAbove := int64(minFrequencyWhilePropagating/time.Millisecond) + 1 // just above 1s

	newLogger := func() (logrus.FieldLogger, *test.Hook) {
		l, h := test.NewNullLogger()
		return l, h
	}

	t.Run("frequency_below_min_clamped_and_warned", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &freqBelow,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequency)
		assert.Equal(t, minFrequency, *cfg.classOverrides.frequency,
			"sub-minimum frequency must be clamped to minFrequency")
		require.Len(t, hook.Entries, 1, "exactly one Warn entry expected")
		assert.Equal(t, logrus.WarnLevel, hook.LastEntry().Level)
		assert.Equal(t, "frequency", hook.LastEntry().Data["field"])
	})

	t.Run("frequency_at_min_accepted_no_warn", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &freqExact,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequency)
		assert.Equal(t, minFrequency, *cfg.classOverrides.frequency)
		assert.Empty(t, hook.Entries, "no warning expected at minimum")
	})

	t.Run("frequency_above_min_accepted_no_warn", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &freqAbove,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequency)
		assert.Equal(t, time.Duration(freqAbove)*time.Millisecond, *cfg.classOverrides.frequency)
		assert.Empty(t, hook.Entries, "no warning expected above minimum")
	})

	t.Run("frequencyWhilePropagating_below_min_clamped_and_warned", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &fwpBelow,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequencyWhilePropagating)
		assert.Equal(t, minFrequencyWhilePropagating, *cfg.classOverrides.frequencyWhilePropagating,
			"sub-minimum frequencyWhilePropagating must be clamped to minFrequencyWhilePropagating")
		require.Len(t, hook.Entries, 1, "exactly one Warn entry expected")
		assert.Equal(t, logrus.WarnLevel, hook.LastEntry().Level)
		assert.Equal(t, "frequencyWhilePropagating", hook.LastEntry().Data["field"])
	})

	t.Run("frequencyWhilePropagating_at_min_accepted_no_warn", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &fwpExact,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequencyWhilePropagating)
		assert.Equal(t, minFrequencyWhilePropagating, *cfg.classOverrides.frequencyWhilePropagating)
		assert.Empty(t, hook.Entries, "no warning expected at minimum")
	})

	t.Run("frequencyWhilePropagating_above_min_accepted_no_warn", func(t *testing.T) {
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &fwpAbove,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequencyWhilePropagating)
		assert.Equal(t, time.Duration(fwpAbove)*time.Millisecond, *cfg.classOverrides.frequencyWhilePropagating)
		assert.Empty(t, hook.Entries, "no warning expected above minimum")
	})

	// Policy for raw API inputs (ReplicationAsyncConfig has no minimum checks
	// of its own on these int64 fields, so any value can reach this helper):
	//   - zero: treated as below-minimum, clamped up to the minimum with a Warn,
	//   - negative: rejected with an error (no meaningful interpretation),
	//   - overflow (ms value > maxDurationMillis): rejected to avoid wrapping
	//     to a negative time.Duration and silently clamping to the minimum.
	t.Run("frequency_zero_clamped_and_warned", func(t *testing.T) {
		zero := int64(0)
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &zero,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequency)
		assert.Equal(t, minFrequency, *cfg.classOverrides.frequency)
		require.Len(t, hook.Entries, 1, "exactly one Warn entry expected")
		assert.Equal(t, logrus.WarnLevel, hook.LastEntry().Level)
		assert.Equal(t, "frequency", hook.LastEntry().Data["field"])
	})

	t.Run("frequency_negative_rejected", func(t *testing.T) {
		neg := int64(-1)
		logger, hook := newLogger()
		_, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &neg,
		}, logger)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "frequency must be >= 0")
		assert.Empty(t, hook.Entries, "no clamp warning expected for negative input")
	})

	t.Run("frequencyWhilePropagating_zero_clamped_and_warned", func(t *testing.T) {
		zero := int64(0)
		logger, hook := newLogger()
		cfg, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &zero,
		}, logger)
		require.NoError(t, err)
		require.NotNil(t, cfg.classOverrides.frequencyWhilePropagating)
		assert.Equal(t, minFrequencyWhilePropagating, *cfg.classOverrides.frequencyWhilePropagating)
		require.Len(t, hook.Entries, 1, "exactly one Warn entry expected")
		assert.Equal(t, logrus.WarnLevel, hook.LastEntry().Level)
		assert.Equal(t, "frequencyWhilePropagating", hook.LastEntry().Data["field"])
	})

	t.Run("frequencyWhilePropagating_negative_rejected", func(t *testing.T) {
		neg := int64(-100)
		logger, hook := newLogger()
		_, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &neg,
		}, logger)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "frequencyWhilePropagating must be >= 0")
		assert.Empty(t, hook.Entries, "no clamp warning expected for negative input")
	})

	// Inputs whose value in milliseconds does not fit in time.Duration would
	// silently wrap to a negative duration on conversion and then be clamped
	// to the minimum. Reject them explicitly so callers don't end up with the
	// fastest cadence when they asked for the slowest.
	t.Run("frequency_overflow_rejected", func(t *testing.T) {
		overflow := int64(math.MaxInt64)
		logger, hook := newLogger()
		_, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			Frequency: &overflow,
		}, logger)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "frequency too large")
		assert.Empty(t, hook.Entries, "no clamp warning expected for overflow input")
	})

	t.Run("frequencyWhilePropagating_overflow_rejected", func(t *testing.T) {
		overflow := int64(math.MaxInt64)
		logger, hook := newLogger()
		_, err := asyncReplicationConfigFromModel(false, &models.ReplicationAsyncConfig{
			FrequencyWhilePropagating: &overflow,
		}, logger)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "frequencyWhilePropagating too large")
		assert.Empty(t, hook.Entries, "no clamp warning expected for overflow input")
	})
}

// TestAsyncReplicationClampWarner verifies the warner's consecutive-duplicate
// suppression for positive-but-below-minimum runtime overrides on the two
// Frequency fields. A stable sub-minimum value logs once; changing to a new
// sub-minimum value re-arms the warning. Only the last warned value per field
// is remembered, so an A→B→A alternation would log A twice — see the type's
// doc comment for the tradeoff.
func TestAsyncReplicationClampWarner(t *testing.T) {
	makeWarner := func() (*asyncReplicationClampWarner, *test.Hook) {
		l, h := test.NewNullLogger()
		return &asyncReplicationClampWarner{logger: l}, h
	}

	t.Run("subfloor_frequency_warns_once_per_unique_value", func(t *testing.T) {
		w, hook := makeWarner()
		subfloor := minFrequency / 2
		globals := replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(subfloor),
		}
		w.checkGlobals(globals)
		w.checkGlobals(globals)
		w.checkGlobals(globals)
		require.Len(t, hook.Entries, 1, "repeat checks with the same value must dedup")
		assert.Equal(t, "frequency", hook.LastEntry().Data["field"])
		assert.Equal(t, subfloor, hook.LastEntry().Data["requested"])
		assert.Equal(t, minFrequency, hook.LastEntry().Data["applied"])
		assert.Contains(t, hook.LastEntry().Message, "below minimum")
	})

	t.Run("changed_subfloor_value_warns_again", func(t *testing.T) {
		w, hook := makeWarner()
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(minFrequency / 2),
		})
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(minFrequency / 3),
		})
		require.Len(t, hook.Entries, 2, "a different sub-minimum value must re-arm the warning")
	})

	t.Run("above_floor_value_does_not_warn", func(t *testing.T) {
		w, hook := makeWarner()
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(minFrequency * 2),
		})
		assert.Empty(t, hook.Entries)
	})

	t.Run("zero_value_does_not_warn", func(t *testing.T) {
		// Zero is the DynamicValue "not configured" sentinel — not a sub-minimum
		// override that warrants a Warn.
		w, hook := makeWarner()
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(time.Duration(0)),
		})
		assert.Empty(t, hook.Entries)
	})

	t.Run("negative_value_does_not_warn", func(t *testing.T) {
		// Negative runtime overrides are silently ignored by the apply helpers
		// (the prior cadence is preserved). The warner intentionally does not
		// cover them — the right place to reject typos is the env-var / YAML
		// loader at startup.
		w, hook := makeWarner()
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(-1 * time.Second),
		})
		assert.Empty(t, hook.Entries)
	})

	t.Run("each_field_warns_with_its_own_floor", func(t *testing.T) {
		// Pick a value above minFrequencyWhilePropagating but below minFrequency.
		// Both fields share the same value, but only frequency is considered
		// sub-minimum.
		w, hook := makeWarner()
		shared := 2 * time.Second
		w.checkGlobals(replication.GlobalConfig{
			AsyncReplicationFrequency:                 configRuntime.NewDynamicValue(shared),
			AsyncReplicationFrequencyWhilePropagating: configRuntime.NewDynamicValue(shared),
		})
		require.Len(t, hook.Entries, 1)
		assert.Equal(t, "frequency", hook.LastEntry().Data["field"])
	})
}

// TestRebuildHashtreeCancelledContext verifies that rebuildHashtree returns
// safely without panicking or modifying asyncRepNeedsRebuild when the
// scheduler's context is already cancelled.
func TestRebuildHashtreeCancelledContext(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	sched, err := NewAsyncReplicationScheduler(ctx, replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	// Cancel the context before calling rebuildHashtree.
	cancel()

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	require.False(t, s.asyncRepNeedsRebuild.Load(), "precondition: rebuild not needed yet")

	assert.NotPanics(t, func() { sched.rebuildHashtree(s) },
		"rebuildHashtree must not panic with a cancelled context")

	// With a cancelled context, both early-return guards fire before
	// enableAsyncReplication is reached, so asyncRepNeedsRebuild is not re-armed.
	assert.False(t, s.asyncRepNeedsRebuild.Load(),
		"asyncRepNeedsRebuild must not be set when context is already cancelled at entry")
}

// TestRebuildHashtreeSkipsWhileShutdownHoldsLock verifies rebuildHashtree skips a shard already marked shut promptly, while performShutdown still holds the write lock.
func TestRebuildHashtreeSkipsWhileShutdownHoldsLock(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	idx := &Index{Config: IndexConfig{ClassName: "TestClass"}}
	s := &Shard{
		class:        &models.Class{Class: "TestClass"},
		index:        idx,
		shutdownLock: new(sync.RWMutex),
	}

	s.shut.Store(true)
	s.shutdownLock.Lock()
	defer s.shutdownLock.Unlock()

	done := make(chan struct{})
	go func() {
		sched.rebuildHashtree(s)
		close(done)
	}()

	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("rebuildHashtree blocked on shutdownLock instead of skipping the shut shard")
	}

	assert.False(t, s.asyncRepNeedsRebuild.Load(), "skip path must not reach enableAsyncReplication")
}

// TestRegisterAfterCloseReturnsErrSchedulerClosed verifies that Register returns
// ErrSchedulerClosed promptly (does not deadlock) once Close has been called.
func TestRegisterAfterCloseReturnsErrSchedulerClosed(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)
	sched.Close()

	type result struct{ err error }
	resultCh := make(chan result, 1)
	go func() {
		resultCh <- result{err: sched.Register(&Shard{})}
	}()

	select {
	case res := <-resultCh:
		assert.ErrorIs(t, res.err, ErrSchedulerClosed)

		sched.mu.Lock()
		n := len(sched.entries)
		sched.mu.Unlock()
		assert.Equal(t, 0, n, "shard must not appear in registry when Register returns an error")
	case <-time.After(100 * time.Millisecond):
		t.Fatal("Register blocked — closed guard did not fire after Close()")
	}
}

// TestDeregisterAfterCloseReturnsErrSchedulerClosed verifies that Deregister
// returns ErrSchedulerClosed promptly (does not deadlock) once Close has been called.
func TestDeregisterAfterCloseReturnsErrSchedulerClosed(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)
	sched.Close()

	type result struct{ err error }
	resultCh := make(chan result, 1)
	go func() {
		resultCh <- result{err: sched.Deregister(&Shard{})}
	}()

	select {
	case res := <-resultCh:
		assert.ErrorIs(t, res.err, ErrSchedulerClosed)
	case <-time.After(100 * time.Millisecond):
		t.Fatal("Deregister blocked — closed guard did not fire after Close()")
	}
}

// TestCloseIsIdempotent verifies that calling Close() twice is safe: the
// second call returns without panic and does not change observable state.
func TestCloseIsIdempotent(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	sched.Close()
	assert.True(t, sched.closed.Load(), "closed must be set after first Close()")

	// Second call must not panic, must complete promptly.
	done := make(chan struct{})
	go func() { sched.Close(); close(done) }()
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("second Close() blocked")
	}
	assert.True(t, sched.closed.Load(), "closed must remain set after second Close()")
}

// entriesContains is a small helper that snapshots whether `s` is present in
// sched.entries under sched.mu. Used by the strict-postcondition tests.
func entriesContains(sched *AsyncReplicationScheduler, s *Shard) bool {
	sched.mu.Lock()
	_, ok := sched.entries[s]
	sched.mu.Unlock()
	return ok
}

// TestRegisterStrictPostconditionPresent verifies the documented postcondition:
// Register returning nil implies the shard is present in the scheduler's
// internal registry once the call returns.
func TestRegisterStrictPostconditionPresent(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	s := &Shard{}
	require.NoError(t, sched.Register(s))
	assert.True(t, entriesContains(sched, s),
		"Register returning nil must imply the shard is in entries")
}

// TestDeregisterStrictPostconditionAbsent verifies the documented postcondition:
// Deregister returning nil implies the shard is not present in the scheduler's
// internal registry once the call returns.
func TestDeregisterStrictPostconditionAbsent(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	s := &Shard{}
	require.NoError(t, sched.Register(s))
	require.True(t, entriesContains(sched, s), "precondition: shard must be registered")

	require.NoError(t, sched.Deregister(s))
	assert.False(t, entriesContains(sched, s),
		"Deregister returning nil must imply the shard is not in entries")
}

// TestRegisterReregisterAfterDeregister verifies that a Register/Deregister/
// Register sequence on the same shard works as expected and leaves the shard
// registered after the second Register.
func TestRegisterReregisterAfterDeregister(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	s := &Shard{}
	require.NoError(t, sched.Register(s))
	require.NoError(t, sched.Deregister(s))
	require.False(t, entriesContains(sched, s))

	require.NoError(t, sched.Register(s))
	assert.True(t, entriesContains(sched, s),
		"shard must be registered again after Deregister + Register")
}

// TestConcurrentRegisterDeregisterStress hammers the public Register/Deregister
// API from many goroutines and checks two end-state invariants:
//   - No panic / deadlock under sustained concurrent use.
//   - After all goroutines finish and a final reconciliation pass deregisters
//     every shard, the registry is empty (no leaked entries).
func TestConcurrentRegisterDeregisterStress(t *testing.T) {
	sched := newSchedulerForUnitTest(t)

	const goroutines = 16
	const iterationsPerGoroutine = 50

	// Each goroutine flips a private shard between registered and not, so a
	// `Register` returning nil on one goroutine cannot be undone by another.
	shards := make([]*Shard, goroutines)
	for i := range shards {
		shards[i] = &Shard{}
	}

	var wg sync.WaitGroup
	wg.Add(goroutines)
	start := make(chan struct{})
	for i := range goroutines {
		s := shards[i]
		go func() {
			defer wg.Done()
			<-start
			for range iterationsPerGoroutine {
				if err := sched.Register(s); err == nil {
					// Strict: post-Register, shard must be registered.
					if !entriesContains(sched, s) {
						t.Errorf("Register returned nil but shard is not in entries")
						return
					}
				}
				if err := sched.Deregister(s); err == nil {
					// Strict: post-Deregister, shard must not be registered.
					if entriesContains(sched, s) {
						t.Errorf("Deregister returned nil but shard is still in entries")
						return
					}
				}
			}
		}()
	}
	close(start)
	wg.Wait()

	// Final reconciliation: every shard left in any state must be deregister-able.
	for _, s := range shards {
		_ = sched.Deregister(s)
	}
	sched.mu.Lock()
	final := len(sched.entries)
	sched.mu.Unlock()
	assert.Equal(t, 0, final, "no entries must remain after final Deregister sweep")
}

// TestRegisterRacingCloseStrict spawns Register goroutines concurrently with
// Close and verifies that Register's strict postcondition holds across the
// dispatcher race window:
//
//   - Every Register that returned nil → its shard is in entries.
//   - Every Register that returned ErrSchedulerClosed → its shard is NOT in
//     entries (the dispatcher's addCh branch dropped it because closed was
//     set before onAddLocked could run).
//
// Close does not clear entries, so the post-condition is checkable after
// every goroutine has returned and Close has completed.
func TestRegisterRacingCloseStrict(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(2),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	const n = 100
	shards := make([]*Shard, n)
	for i := range shards {
		shards[i] = &Shard{}
	}
	results := make([]error, n)

	var registerWg sync.WaitGroup
	registerWg.Add(n)
	start := make(chan struct{})
	for i := range n {
		idx := i
		go func() {
			defer registerWg.Done()
			<-start
			results[idx] = sched.Register(shards[idx])
		}()
	}
	close(start)

	closeDone := make(chan struct{})
	go func() {
		// Brief jitter so some Registers complete before Close starts; the
		// rest race against closed.Store(true).
		time.Sleep(time.Millisecond)
		sched.Close()
		close(closeDone)
	}()

	registerWg.Wait()
	<-closeDone

	// Snapshot the registry once. It is only mutated by the dispatcher
	// goroutine, which has exited by this point (Close waits on wg).
	sched.mu.Lock()
	finalEntries := make(map[*Shard]struct{}, len(sched.entries))
	for s := range sched.entries {
		finalEntries[s] = struct{}{}
	}
	sched.mu.Unlock()

	for i, err := range results {
		_, present := finalEntries[shards[i]]
		switch {
		case err == nil:
			assert.True(t, present,
				"Register returning nil must imply the shard is in entries (strict postcondition)")
		case errors.Is(err, ErrSchedulerClosed):
			// Asymmetric contract: the strict postcondition is one-sided —
			// nil ⟹ shard added. The error branch makes no positive claim
			// because the inner <-ctx.Done() panic backstop can fire after
			// the dispatcher already ran onAddLocked, producing a "false
			// negative" (operation succeeded, error reported). The shard
			// being either present or absent is consistent with the API.
		default:
			t.Errorf("unexpected error from Register: %v", err)
		}
	}
}

// TestDeregisterRacingCloseStrict mirrors TestRegisterRacingCloseStrict for
// Deregister: each goroutine pre-registers its shard, then races a Deregister
// call against Close. Strict nil-postcondition: nil → shard absent. The error
// branch makes no positive claim — the inner ctx.Done() backstop can fire
// after the dispatcher ran onRemoveLocked, producing a benign false negative.
func TestDeregisterRacingCloseStrict(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(2),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	const n = 100
	shards := make([]*Shard, n)
	for i := range shards {
		shards[i] = &Shard{}
		require.NoError(t, sched.Register(shards[i]))
	}
	results := make([]error, n)

	var deregisterWg sync.WaitGroup
	deregisterWg.Add(n)
	start := make(chan struct{})
	for i := range n {
		idx := i
		go func() {
			defer deregisterWg.Done()
			<-start
			results[idx] = sched.Deregister(shards[idx])
		}()
	}
	close(start)

	closeDone := make(chan struct{})
	go func() {
		time.Sleep(time.Millisecond)
		sched.Close()
		close(closeDone)
	}()

	deregisterWg.Wait()
	<-closeDone

	sched.mu.Lock()
	finalEntries := make(map[*Shard]struct{}, len(sched.entries))
	for s := range sched.entries {
		finalEntries[s] = struct{}{}
	}
	sched.mu.Unlock()

	for i, err := range results {
		_, present := finalEntries[shards[i]]
		switch {
		case err == nil:
			assert.False(t, present,
				"Deregister returning nil must imply the shard is NOT in entries (strict postcondition)")
		case errors.Is(err, ErrSchedulerClosed):
			// Asymmetric contract — see the Register variant above.
		default:
			t.Errorf("unexpected error from Deregister: %v", err)
		}
	}
}

// TestEffectiveThreeTierPrecedence verifies the three-tier override hierarchy
// of Effective(): global runtime config > per-class schema override > code default.
//
// Uses frequency as the test field because it has both an enforced minimum
// (minFrequency) and no non-zero code default for easy isolation.
func TestEffectiveThreeTierPrecedence(t *testing.T) {
	const codeDefault = 5 * time.Second
	const classOverride = 2 * time.Minute
	const globalOverride = 3 * time.Minute

	t.Run("code_default_wins_when_no_overrides", func(t *testing.T) {
		cfg := AsyncReplicationConfig{frequency: codeDefault}
		result := cfg.Effective(replication.GlobalConfig{})
		assert.Equal(t, codeDefault, result.frequency,
			"code default must be preserved when no class or global override is set")
	})

	t.Run("class_override_beats_code_default", func(t *testing.T) {
		cfg := AsyncReplicationConfig{
			frequency: codeDefault,
			classOverrides: asyncReplicationClassOverrides{
				frequency: durationPtr(classOverride),
			},
		}
		result := cfg.Effective(replication.GlobalConfig{})
		assert.Equal(t, classOverride, result.frequency,
			"per-class override must beat the code default")
	})

	t.Run("global_config_beats_class_override", func(t *testing.T) {
		cfg := AsyncReplicationConfig{
			frequency: codeDefault,
			classOverrides: asyncReplicationClassOverrides{
				frequency: durationPtr(classOverride),
			},
		}
		globals := replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(globalOverride),
		}
		result := cfg.Effective(globals)
		assert.Equal(t, globalOverride, result.frequency,
			"global runtime config must beat both class override and code default")
	})

	t.Run("global_config_zero_preserves_class_override", func(t *testing.T) {
		// A zero DynamicValue means "not configured at cluster level" and must not
		// overwrite a class override.
		cfg := AsyncReplicationConfig{
			frequency: codeDefault,
			classOverrides: asyncReplicationClassOverrides{
				frequency: durationPtr(classOverride),
			},
		}
		globals := replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(time.Duration(0)),
		}
		result := cfg.Effective(globals)
		assert.Equal(t, classOverride, result.frequency,
			"zero global DynamicValue must not override a class-level setting")
	})

	t.Run("global_config_subfloor_clamps_to_floor", func(t *testing.T) {
		// A positive but sub-minimum global DynamicValue must clamp up to the
		// minimum rather than being silently dropped — otherwise an operator who
		// tried to dial frequency down past the minimum would get the previous
		// (class or default) value with no signal that their override was
		// ineffective.
		cfg := AsyncReplicationConfig{
			frequency: codeDefault,
			classOverrides: asyncReplicationClassOverrides{
				frequency: durationPtr(classOverride),
			},
		}
		globals := replication.GlobalConfig{
			AsyncReplicationFrequency: configRuntime.NewDynamicValue(minFrequency - time.Second),
		}
		result := cfg.Effective(globals)
		assert.Equal(t, minFrequency, result.frequency,
			"sub-minimum global DynamicValue must clamp to minFrequency, not be ignored")
	})

	t.Run("global_config_frequencyWhilePropagating_subfloor_clamps_to_its_own_floor", func(t *testing.T) {
		// Symmetric to frequency, but guards against a regression where a future
		// edit might clamp this field against minFrequency instead of its own
		// distinct minFrequencyWhilePropagating minimum.
		const fwpClassOverride = 10 * time.Second
		cfg := AsyncReplicationConfig{
			frequencyWhilePropagating: defaultFrequencyWhilePropagating,
			classOverrides: asyncReplicationClassOverrides{
				frequencyWhilePropagating: durationPtr(fwpClassOverride),
			},
		}
		globals := replication.GlobalConfig{
			AsyncReplicationFrequencyWhilePropagating: configRuntime.NewDynamicValue(minFrequencyWhilePropagating - time.Millisecond),
		}
		result := cfg.Effective(globals)
		assert.Equal(t, minFrequencyWhilePropagating, result.frequencyWhilePropagating,
			"sub-minimum global DynamicValue must clamp to minFrequencyWhilePropagating, not minFrequency, and not be ignored")
	})
}

// TestSchedulerCloseWithConcurrentDispatches verifies that Close() returns
// promptly and does not deadlock when workers are actively dispatching entries.
// This is a regression test for the unconditional resultCh send introduced in
// runEntry(): before the fix, the select-with-ctx.Done() alternative could drop
// results on shutdown, leaving entry.inFlight stuck as true. While the stuck
// state had no practical impact (the scheduler shuts down entirely), it
// represented a logical invariant violation and the select created an
// unnecessary 50/50 race between the send and ctx cancellation.
func TestSchedulerCloseWithConcurrentDispatches(t *testing.T) {
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(5),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	// Register shards with nil asyncRepCtx so runEntry returns immediately
	// via the "shard not yet initialized" fast path, then unconditionally sends
	// a result. The scheduler re-dispatches them at minDispatchInterval, keeping
	// workers active and maximising the chance that a send races with ctx
	// cancellation when Close() fires.
	const n = 20
	for range n {
		require.NoError(t, sched.Register(&Shard{}))
	}

	// Gate on nextSeq growth: sampling len(workCh)/len(resultCh) misses sends handed off directly to parked receivers.
	sched.mu.Lock()
	baseSeq := sched.nextSeq
	sched.mu.Unlock()
	require.Eventually(t, func() bool {
		sched.mu.Lock()
		defer sched.mu.Unlock()
		return sched.nextSeq > baseSeq
	}, 5*time.Second, time.Millisecond,
		"dispatcher did not complete any dispatch round-trip within 5s")

	done := make(chan struct{})
	go func() {
		sched.Close()
		close(done)
	}()

	select {
	case <-done:
		// Close() returned: no goroutine leak, no deadlock in result-send path.
	case <-time.After(2 * time.Second):
		t.Fatal("Close() blocked — goroutine leak or deadlock in result-send path")
	}
}

// Deleted: TestSingleCyclePerShard_InFlightEntryNotRedispatched.
//
// The single-cycle-per-shard invariant (an entry cannot be dispatched twice
// concurrently) was asserted by directly poking entry.inFlight and the heap.
// The invariant is exercised end-to-end by the integration tests that register
// real shards and run real cycles; a violation would manifest as concurrent
// runHashbeatCycle invocations and shard-state corruption visible in those
// tests. Removed during the constructor-spawns-workers migration where direct
// heap mutation races with the live dispatcher.

// TestWorkerDrainsWorkChOnCtxCancel is a regression test for the asyncRepWg
// imbalance that occurs when Close() fires while work items are buffered in
// workCh. Before the fix, workers exited on ctx.Done() without draining the
// channel, leaving Add(1) calls without a matching Done(). Any subsequent
// asyncRepWg.Wait() — in particular the one inside rebuildHashtree — would
// block forever, stalling DB.Shutdown().
//
// The test verifies that after Close() returns, asyncRepWg.Wait() on every
// shard completes within a short deadline, proving the WaitGroup is balanced.
func TestWorkerDrainsWorkChOnCtxCancel(t *testing.T) {
	const numShards = 10
	const numWorkers = 2

	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(numWorkers),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, nil)
	require.NoError(t, err)

	shards := make([]*Shard, numShards)
	for i := range shards {
		shards[i] = &Shard{}
	}

	// Register all shards so the dispatcher enqueues them immediately.
	for _, s := range shards {
		require.NoError(t, sched.Register(s))
	}

	// Gate on nextSeq growth: sampling len(workCh)/len(resultCh) misses sends handed off directly to parked receivers.
	sched.mu.Lock()
	baseSeq := sched.nextSeq
	sched.mu.Unlock()
	require.Eventually(t, func() bool {
		sched.mu.Lock()
		defer sched.mu.Unlock()
		return sched.nextSeq > baseSeq
	}, 5*time.Second, time.Millisecond,
		"dispatcher did not complete any dispatch round-trip within 5s")

	// Close cancels the scheduler context. Workers must drain any remaining
	// buffered workCh items and call Done() for each to keep asyncRepWg balanced.
	done := make(chan struct{})
	go func() { sched.Close(); close(done) }()

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("Close() blocked — scheduler goroutine leak or deadlock")
	}

	// After Close() the WaitGroup for every shard must reach zero promptly.
	// A timeout here means a worker exited ctx.Done() without calling Done()
	// for a buffered item, leaving the WaitGroup permanently positive.
	for i, s := range shards {
		wgDone := make(chan struct{})
		go func() { s.asyncRepWg.Wait(); close(wgDone) }()
		select {
		case <-wgDone:
		case <-time.After(2 * time.Second):
			t.Fatalf("asyncRepWg.Wait() timed out for shard %d — WaitGroup is unbalanced", i)
		}
	}
}

// TestSchedulerClose_BoundedAndCancelsContextsWhenShardsStillRegistered verifies
// two safety properties of Close() when called without prior deregistration:
//
//  1. Close() completes within a reasonable bound (it must not block forever).
//  2. Close() force-cancels the asyncReplicationCancelFunc of every shard still
//     registered at shutdown time, so that any in-flight hashbeat RPC using the
//     per-shard context aborts promptly instead of blocking until
//     diffPerNodeTimeout.
//  3. Close() logs an error to surface the ordering bug.
//
// The shards are constructed with nil asyncRepCtx (so runEntry returns
// immediately via the "not yet initialized" fast path) but with a live
// cancellable context wired into asyncReplicationCancelFunc, mirroring the
// state a real shard has after initAsyncReplication but before mayStopAsyncReplication.
func TestSchedulerClose_BoundedAndCancelsContextsWhenShardsStillRegistered(t *testing.T) {
	logger, hook := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(3),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)

	const n = 5
	shardCtxs := make([]context.Context, n)
	shards := make([]*Shard, n)
	for i := range n {
		ctx, cancel := context.WithCancel(context.Background())
		shardCtxs[i] = ctx
		// asyncRepCtx is nil: runEntry exits immediately via "not yet initialized".
		// asyncReplicationCancelFunc is non-nil: Close() must call it to bound RPCs.
		shards[i] = &Shard{asyncReplicationCancelFunc: cancel}
		require.NoError(t, sched.Register(shards[i]))
	}

	// No synchronization needed before Close(): Close() iterates sched.entries
	// to force-cancel asyncReplicationCancelFunc for every registered shard,
	// regardless of whether the entry is currently in-flight or queued in the
	// heap. The assertion below validates this property.

	// Close without deregistering — the invariant-violation path.
	done := make(chan struct{})
	go func() { sched.Close(); close(done) }()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("Close() blocked — scheduler goroutines did not exit within deadline")
	}

	// Close() must have cancelled each shard's context via asyncReplicationCancelFunc.
	for i, ctx := range shardCtxs {
		assert.Error(t, ctx.Err(),
			"shard %d: asyncReplicationCancelFunc must be called by Close() to abort in-flight RPCs", i)
	}

	// Verify the invariant-violation error was logged.
	var errorLogged bool
	for _, entry := range hook.Entries {
		if entry.Level == logrus.ErrorLevel {
			errorLogged = true
			break
		}
	}
	assert.True(t, errorLogged, "Close() must log an error when shards are still registered")
}

// zeroCoalesceWindow disables dispatch coalescing for tests that expect immediate batches.
func zeroCoalesceWindow(t *testing.T) {
	t.Helper()
	prev := prefilterCoalesceWindow
	prefilterCoalesceWindow = 0
	t.Cleanup(func() { prefilterCoalesceWindow = prev })
}

// durationPtr is a helper that returns a pointer to a time.Duration value.
func durationPtr(d time.Duration) *time.Duration { return &d }

// newBareScheduler builds a scheduler struct without starting any goroutines.
func newBareScheduler(batchSize, workChCap int) *AsyncReplicationScheduler {
	s := &AsyncReplicationScheduler{
		entries:                  make(map[*Shard]*asyncSchedulerEntry),
		workCh:                   make(chan *[]*asyncSchedulerEntry, workChCap),
		asyncReplicationDisabled: configRuntime.NewDynamicValue(false),
		rootPrefilterBatchSize:   configRuntime.NewDynamicValue(batchSize),
		logger:                   newNullLogger(),
	}
	s.batchPool.New = func() any {
		b := make([]*asyncSchedulerEntry, 0, 64)
		return &b
	}
	heap.Init(&s.h)
	return s
}

func drainBatchSizes(ch chan *[]*asyncSchedulerEntry) []int {
	var sizes []int
	for {
		select {
		case bp := <-ch:
			sizes = append(sizes, len(*bp))
		default:
			return sizes
		}
	}
}

func drainBatches(ch chan *[]*asyncSchedulerEntry) []*[]*asyncSchedulerEntry {
	var batches []*[]*asyncSchedulerEntry
	for {
		select {
		case bp := <-ch:
			batches = append(batches, bp)
		default:
			return batches
		}
	}
}

func drainResults(ch chan asyncSchedulerResult) []asyncSchedulerResult {
	var results []asyncSchedulerResult
	for {
		select {
		case r := <-ch:
			results = append(results, r)
		default:
			return results
		}
	}
}

// TestRunBatchEmitsOneResultPerEntry: every entry in a batch yields exactly one result.
func TestRunBatchEmitsOneResultPerEntry(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx = context.Background()
	sched.resultCh = make(chan asyncSchedulerResult, 8)

	entries := make([]*asyncSchedulerEntry, 3)
	for i := range entries {
		s := &Shard{class: &models.Class{Class: "C"}}
		s.asyncRepWg.Add(1)
		entries[i] = &asyncSchedulerEntry{shard: s}
		entries[i].pendingDone.Store(true)
	}

	sched.runBatch(&entries, newBatchScratch())

	got := map[*asyncSchedulerEntry]int{}
	for range entries {
		select {
		case r := <-sched.resultCh:
			got[r.entry]++
		case <-time.After(time.Second):
			t.Fatal("missing result for a batch entry")
		}
	}
	for _, e := range entries {
		assert.Equal(t, 1, got[e], "each entry must yield exactly one result")
		e.shard.asyncRepWg.Wait()
	}
}

// TestAsyncSchedulerConcurrentBatchedDispatch races Register/Deregister against
// Close over the batched path under -race: no race, no deadlock, balanced asyncRepWg.
func TestAsyncSchedulerConcurrentBatchedDispatch(t *testing.T) {
	logger, _ := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers:       configRuntime.NewDynamicValue(4),
		AsyncReplicationDisabled:               configRuntime.NewDynamicValue(false),
		AsyncReplicationRootPrefilterBatchSize: configRuntime.NewDynamicValue(3),
	}, nil, logger)
	require.NoError(t, err)

	idx := &Index{Config: IndexConfig{ClassName: "MT"}, partitioningEnabled: true}
	shards := make([]*Shard, 30)
	for i := range shards {
		shards[i] = &Shard{index: idx, class: &models.Class{Class: "MT"}, name: fmt.Sprintf("t%02d", i)}
	}

	var wg sync.WaitGroup
	for _, s := range shards {
		s := s
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = sched.Register(s)
			time.Sleep(5 * time.Millisecond)
			_ = sched.Deregister(s)
		}()
	}

	time.Sleep(8 * time.Millisecond)

	done := make(chan struct{})
	go func() {
		sched.Close()
		wg.Wait()
		close(done)
	}()

	select {
	case <-done:
	case <-time.After(30 * time.Second):
		t.Fatal("scheduler did not terminate — possible deadlock in batched dispatch")
	}

	for _, s := range shards {
		s.asyncRepWg.Wait()
	}
}

// TestOnResultDiscardsZombieEntryAfterReRegister: a stale entry re-registered
// mid-flight must be discarded, not re-pushed alongside the fresh one.
func TestOnResultDiscardsZombieEntryAfterReRegister(t *testing.T) {
	for _, tc := range []struct {
		name         string
		deferDescent bool
	}{
		{name: "normal re-push"},
		{name: "deferDescent re-push", deferDescent: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			sched := newBareScheduler(512, 1)

			s := &Shard{index: &Index{Config: IndexConfig{ClassName: "C"}}, class: &models.Class{Class: "C"}}
			sched.onAddLocked(s)
			e1 := sched.entries[s]

			s.asyncRepWg.Add(1)
			e1.inFlight = true
			heap.Pop(&sched.h)
			s.asyncRepWg.Done()

			sched.onRemoveLocked(s)
			sched.onAddLocked(s)
			e2 := sched.entries[s]
			require.NotSame(t, e1, e2)

			sched.onResultLocked(asyncSchedulerResult{entry: e1, deferDescent: tc.deferDescent})

			require.Len(t, sched.h, 1, "stale entry must not be re-pushed")
			assert.Same(t, e2, sched.h[0])
			assert.Equal(t, -1, e1.heapIdx, "stale entry stays out of the heap")
			s.asyncRepWg.Wait()
		})
	}
}

// TestAsyncSchedulerMassDivergenceDeferDescent stresses a batch larger than the
// resultCh buffer, all diverging, while Deregister/Register race the same shards.
func TestAsyncSchedulerMassDivergenceDeferDescent(t *testing.T) {
	logger, _ := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers:       configRuntime.NewDynamicValue(4),
		AsyncReplicationDisabled:               configRuntime.NewDynamicValue(false),
		AsyncReplicationRootPrefilterBatchSize: configRuntime.NewDynamicValue(512),
	}, nil, logger)
	require.NoError(t, err)

	idx := &Index{Config: IndexConfig{ClassName: "MT"}, partitioningEnabled: true}
	const n = 256
	shards := make([]*Shard, n)
	for i := range shards {
		shards[i] = &Shard{index: idx, class: &models.Class{Class: "MT"}, name: fmt.Sprintf("t%03d", i)}
		_ = sched.Register(shards[i])
	}

	var wg sync.WaitGroup
	for _, s := range shards {
		s := s
		wg.Add(1)
		go func() {
			defer wg.Done()
			for range 3 {
				_ = sched.Deregister(s)
				_ = sched.Register(s)
			}
		}()
	}

	done := make(chan struct{})
	go func() {
		wg.Wait()
		sched.Close()
		close(done)
	}()

	select {
	case <-done:
	case <-time.After(30 * time.Second):
		t.Fatal("scheduler did not terminate — possible deadlock in mass-divergence defer path")
	}

	for _, s := range shards {
		s.asyncRepWg.Wait()
	}
}

// TestClassifyBatchExcludesIneligible: override / uninitialised-hashtree shards are
// excluded from the pre-filter and default to a full descent.
func TestClassifyBatchExcludesIneligible(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx = context.Background()

	override := &Shard{class: &models.Class{Class: "C"}}
	override.targetNodeOverrides = additional.AsyncReplicationTargetNodeOverrides{{TargetNode: "n2"}}
	uninit := &Shard{class: &models.Class{Class: "C"}}

	batch := []*asyncSchedulerEntry{{shard: override}, {shard: uninit}}
	scratch := newBatchScratch()

	sched.classifyBatch(batch, scratch)

	assert.Empty(t, scratch.classes, "no eligible shard ⇒ no roots collected")
	for _, e := range batch {
		assert.False(t, scratch.skip[e], "ineligible shards must take the full descent")
	}
}

// TestPrefilterCtxCancelledByIndexClose pins the deadlock regression: a pre-filter
// rooted only at sched.ctx outlives index.drop() and blocks every replica.
func TestPrefilterCtxCancelledByIndexClose(t *testing.T) {
	newIndex := func() (*Index, context.CancelFunc) {
		idx := &Index{Config: IndexConfig{ClassName: "C"}}
		idx.closingCtx, idx.closingCancel = context.WithCancel(context.Background())
		return idx, idx.closingCancel
	}

	tests := []struct {
		name     string
		stop     func(sched *AsyncReplicationScheduler, closeIndex context.CancelFunc)
		wantDone bool
	}{
		{
			name:     "index closes",
			stop:     func(_ *AsyncReplicationScheduler, closeIndex context.CancelFunc) { closeIndex() },
			wantDone: true,
		},
		{
			name:     "scheduler shuts down",
			stop:     func(sched *AsyncReplicationScheduler, _ context.CancelFunc) { sched.cancel() },
			wantDone: true,
		},
		{
			name:     "nothing stops",
			stop:     func(*AsyncReplicationScheduler, context.CancelFunc) {},
			wantDone: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			sched := newBareScheduler(512, 1)
			sched.ctx, sched.cancel = context.WithCancel(context.Background())
			defer sched.cancel()

			idx, closeIndex := newIndex()
			defer closeIndex()
			// time.Hour: a done ctx can only mean a stop signal propagated.
			ctx, cancel := sched.prefilterCtx(time.Hour, idx)
			defer cancel()
			require.NoError(t, ctx.Err())

			tc.stop(sched, closeIndex)

			if !tc.wantDone {
				time.Sleep(50 * time.Millisecond)
				assert.NoError(t, ctx.Err(), "ctx must stay live while the index is open")
				return
			}

			select {
			case <-ctx.Done():
				assert.ErrorIs(t, ctx.Err(), context.Canceled)
			case <-time.After(5 * time.Second):
				t.Fatal("pre-filter ctx was not cancelled; index.drop() would deadlock the replicas")
			}
		})
	}
}

func TestPrefilterCtxHonoursTimeout(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx, sched.cancel = context.WithCancel(context.Background())
	defer sched.cancel()

	idx := &Index{Config: IndexConfig{ClassName: "C"}}
	idx.closingCtx, idx.closingCancel = context.WithCancel(context.Background())
	defer idx.closingCancel()

	ctx, cancel := sched.prefilterCtx(50*time.Millisecond, idx)
	defer cancel()

	select {
	case <-ctx.Done():
		assert.ErrorIs(t, ctx.Err(), context.DeadlineExceeded)
	case <-time.After(5 * time.Second):
		t.Fatal("pre-filter ctx ignored its timeout")
	}
}

// TestPrefilterCtxNilIndex: unit-test shards carry no index.
func TestPrefilterCtxNilIndex(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx, sched.cancel = context.WithCancel(context.Background())
	defer sched.cancel()

	idx := &Index{Config: IndexConfig{ClassName: "C"}}

	ctx, cancel := sched.prefilterCtx(time.Hour, idx)
	defer cancel()
	require.NoError(t, ctx.Err())

	sched.cancel()
	select {
	case <-ctx.Done():
	case <-time.After(5 * time.Second):
		t.Fatal("a nil index must fall back to the scheduler context")
	}
}

func TestEffectiveBatchSize(t *testing.T) {
	t.Run("configured value is used", func(t *testing.T) {
		sched := newBareScheduler(256, 1)
		assert.Equal(t, 256, sched.effectiveBatchSize())
	})

	t.Run("invalid falls back to default", func(t *testing.T) {
		sched := newBareScheduler(0, 1)
		assert.Equal(t, fallbackRootPrefilterBatchSize, sched.effectiveBatchSize())
		sched = newBareScheduler(-5, 1)
		assert.Equal(t, fallbackRootPrefilterBatchSize, sched.effectiveBatchSize())
	})

	t.Run("over cap is clamped", func(t *testing.T) {
		sched := newBareScheduler(maxRootPrefilterBatchSize+1000, 1)
		assert.Equal(t, maxRootPrefilterBatchSize, sched.effectiveBatchSize())
	})
}

func TestDispatchDueCoalescing(t *testing.T) {
	t.Run("coalesces up to batch size with a smaller final batch", func(t *testing.T) {
		sched := newBareScheduler(3, 16)
		idx := &Index{Config: IndexConfig{ClassName: "C"}}
		for range 7 {
			sched.onAddLocked(&Shard{index: idx, class: &models.Class{Class: "C"}})
		}

		sched.dispatchDueLocked()

		assert.ElementsMatch(t, []int{3, 3, 1}, drainBatchSizes(sched.workCh))
		assert.Empty(t, sched.h, "all due entries dispatched")
	})

	t.Run("batch size 1 dispatches singletons", func(t *testing.T) {
		sched := newBareScheduler(1, 16)
		idx := &Index{Config: IndexConfig{ClassName: "C"}}
		for range 4 {
			sched.onAddLocked(&Shard{index: idx, class: &models.Class{Class: "C"}})
		}

		sched.dispatchDueLocked()

		assert.ElementsMatch(t, []int{1, 1, 1, 1}, drainBatchSizes(sched.workCh))
	})

	t.Run("distinct indexes merge into one cross-class batch", func(t *testing.T) {
		zeroCoalesceWindow(t)
		sched := newBareScheduler(512, 16)
		a := &Index{Config: IndexConfig{ClassName: "A"}}
		b := &Index{Config: IndexConfig{ClassName: "B"}}
		for range 3 {
			sched.onAddLocked(&Shard{index: a, class: &models.Class{Class: "A"}})
		}
		for range 2 {
			sched.onAddLocked(&Shard{index: b, class: &models.Class{Class: "B"}})
		}

		sched.dispatchDueLocked()

		assert.ElementsMatch(t, []int{5}, drainBatchSizes(sched.workCh))
	})

	t.Run("full channel rolls unsent entries back into the heap", func(t *testing.T) {
		sched := newBareScheduler(1, 2)
		idx := &Index{Config: IndexConfig{ClassName: "C"}}
		for range 5 {
			sched.onAddLocked(&Shard{index: idx, class: &models.Class{Class: "C"}})
		}

		sched.dispatchDueLocked()

		assert.Len(t, drainBatchSizes(sched.workCh), 2, "channel capacity bounds dispatched batches")
		assert.Len(t, sched.h, 3, "unsent entries rolled back into the heap")
		for _, e := range sched.h {
			assert.False(t, e.inFlight, "rolled-back entries must not be in-flight")
		}
	})
}

// TestDeferDescentReDispatchesSingletons: a coalesced batch of diverging shards is
// deferred and re-dispatched as singletons so descent spreads across the pool.
func TestDeferDescentReDispatchesSingletons(t *testing.T) {
	zeroCoalesceWindow(t)
	sched := newBareScheduler(512, 16)
	sched.ctx = context.Background()
	sched.resultCh = make(chan asyncSchedulerResult, 32)

	idx := &Index{Config: IndexConfig{ClassName: "MT"}, partitioningEnabled: true}
	const n = 5
	for i := range n {
		sched.onAddLocked(&Shard{index: idx, class: &models.Class{Class: "MT"}, name: fmt.Sprintf("t%d", i)})
	}

	sched.dispatchDueLocked()
	batches := drainBatches(sched.workCh)
	require.Len(t, batches, 1, "the due shards coalesce into a single pre-filter batch")
	require.Len(t, *batches[0], n)

	sched.runBatch(batches[0], newBatchScratch())

	results := drainResults(sched.resultCh)
	require.Len(t, results, n, "one result per entry")
	for _, r := range results {
		assert.True(t, r.deferDescent, "diverging entries are deferred, not descended inline")
		assert.NoError(t, r.err)
		sched.onResultLocked(r)
	}

	require.Len(t, sched.entries, n)
	for _, e := range sched.entries {
		assert.True(t, e.descendDirect, "deferred entries are marked for direct descent")
	}

	sched.dispatchDueLocked()
	assert.ElementsMatch(t, []int{1, 1, 1, 1, 1}, drainBatchSizes(sched.workCh),
		"diverging shards re-dispatch as singletons, never re-coalesced into one batch")
	for _, e := range sched.entries {
		assert.False(t, e.descendDirect, "descendDirect cleared once the singleton is sent")
	}
}

// TestDescendDirectSurvivesFullChannel: on a full workCh, unsent descendDirect
// entries roll back retaining the flag and retry as singletons next round.
func TestDescendDirectSurvivesFullChannel(t *testing.T) {
	sched := newBareScheduler(512, 2)
	idx := &Index{Config: IndexConfig{ClassName: "MT"}, partitioningEnabled: true}
	const n = 5
	for i := range n {
		s := &Shard{index: idx, class: &models.Class{Class: "MT"}, name: fmt.Sprintf("t%d", i)}
		sched.onAddLocked(s)
		sched.entries[s].descendDirect = true
	}

	sched.dispatchDueLocked()

	assert.ElementsMatch(t, []int{1, 1}, drainBatchSizes(sched.workCh),
		"channel capacity bounds the singletons dispatched this round")
	assert.Len(t, sched.h, n-2, "unsent divergers rolled back into the heap")
	for _, e := range sched.h {
		assert.True(t, e.descendDirect, "rolled-back divergers retain descendDirect")
		assert.False(t, e.inFlight, "rolled-back divergers must not be in-flight")
	}

	sched.dispatchDueLocked()
	assert.ElementsMatch(t, []int{1, 1}, drainBatchSizes(sched.workCh),
		"remaining divergers keep dispatching as singletons")
}

func awaitAsyncRepWg(t *testing.T, s *Shard, msg string) {
	t.Helper()
	done := make(chan struct{})
	go func() { s.asyncRepWg.Wait(); close(done) }()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal(msg)
	}
}

// TestDeregisterSettlesQueuedDone: deregistration settles a queued batch's pending Done instead of pinning asyncRepWg until Close.
func TestDeregisterSettlesQueuedDone(t *testing.T) {
	for _, tc := range []struct {
		name          string
		descendDirect bool
	}{
		{name: "bucket dispatch"},
		{name: "descendDirect dispatch", descendDirect: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			prev := prefilterCoalesceWindow
			prefilterCoalesceWindow = 0
			t.Cleanup(func() { prefilterCoalesceWindow = prev })
			sched := newBareScheduler(512, 4)
			sched.ctx = context.Background()
			sched.resultCh = make(chan asyncSchedulerResult, 8)

			s := &Shard{index: &Index{Config: IndexConfig{ClassName: "C"}}, class: &models.Class{Class: "C"}}
			sched.onAddLocked(s)
			sched.entries[s].descendDirect = tc.descendDirect

			sched.dispatchDueLocked()
			batches := drainBatches(sched.workCh)
			require.Len(t, batches, 1)

			sched.onRemoveLocked(s)
			awaitAsyncRepWg(t, s, "asyncRepWg must drain once deregistration settles the queued Done")

			sched.runBatch(batches[0], newBatchScratch())
			assert.Empty(t, drainResults(sched.resultCh), "released entry must not produce a result")
			s.asyncRepWg.Wait()
		})
	}
}

// TestDrainSkipsSettledDones: Close's drain must not settle a Done that deregistration already settled.
func TestDrainSkipsSettledDones(t *testing.T) {
	sched := newBareScheduler(512, 4)
	sched.ctx = context.Background()

	s := &Shard{index: &Index{Config: IndexConfig{ClassName: "C"}}, class: &models.Class{Class: "C"}}
	sched.onAddLocked(s)
	sched.dispatchDueLocked()

	sched.onRemoveLocked(s)
	awaitAsyncRepWg(t, s, "asyncRepWg must drain on deregistration")

	sched.drainWorkChOnExit()
	s.asyncRepWg.Wait()
	assert.Empty(t, drainBatches(sched.workCh))
}

// TestStaleBatchDroppedAfterReRegister: a previous registration's stranded batch is dropped; the new one runs once.
func TestStaleBatchDroppedAfterReRegister(t *testing.T) {
	zeroCoalesceWindow(t)
	sched := newBareScheduler(512, 4)
	sched.ctx = context.Background()
	sched.resultCh = make(chan asyncSchedulerResult, 8)

	s := &Shard{index: &Index{Config: IndexConfig{ClassName: "C"}}, class: &models.Class{Class: "C"}}
	sched.onAddLocked(s)
	e1 := sched.entries[s]
	sched.dispatchDueLocked()
	b1 := drainBatches(sched.workCh)
	require.Len(t, b1, 1)

	sched.onRemoveLocked(s)
	awaitAsyncRepWg(t, s, "asyncRepWg must drain on deregistration")

	sched.onAddLocked(s)
	e2 := sched.entries[s]
	require.NotSame(t, e1, e2)
	sched.dispatchDueLocked()
	b2 := drainBatches(sched.workCh)
	require.Len(t, b2, 1)

	sched.runBatch(b1[0], newBatchScratch())
	assert.Empty(t, drainResults(sched.resultCh), "stale batch must be dropped without a result")

	sched.runBatch(b2[0], newBatchScratch())
	results := drainResults(sched.resultCh)
	require.Len(t, results, 1)
	assert.Same(t, e2, results[0].entry)
	s.asyncRepWg.Wait()
}

// TestRollbackSettlesPendingDone: full-workCh rollback re-queues the entry with asyncRepWg balanced and no pending Done.
func TestRollbackSettlesPendingDone(t *testing.T) {
	for _, tc := range []struct {
		name          string
		descendDirect bool
	}{
		{name: "bucket dispatch"},
		{name: "descendDirect dispatch", descendDirect: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			sched := newBareScheduler(512, 0)
			sched.ctx = context.Background()

			s := &Shard{index: &Index{Config: IndexConfig{ClassName: "C"}}, class: &models.Class{Class: "C"}}
			sched.onAddLocked(s)
			e := sched.entries[s]
			e.descendDirect = tc.descendDirect

			sched.dispatchDueLocked()

			assert.False(t, e.inFlight)
			assert.GreaterOrEqual(t, e.heapIdx, 0, "entry must be re-queued")
			assert.False(t, e.pendingDone.Load())
			s.asyncRepWg.Wait()
		})
	}
}

// TestDeregisterDrainsWithSingleWorker: every deregistered shard's asyncRepWg drains before Close despite batches queued behind one worker.
func TestDeregisterDrainsWithSingleWorker(t *testing.T) {
	logger, _ := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers:       configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:               configRuntime.NewDynamicValue(false),
		AsyncReplicationRootPrefilterBatchSize: configRuntime.NewDynamicValue(3),
	}, nil, logger)
	require.NoError(t, err)

	idx := &Index{Config: IndexConfig{ClassName: "MT"}, partitioningEnabled: true}
	shards := make([]*Shard, 30)
	for i := range shards {
		shards[i] = &Shard{index: idx, class: &models.Class{Class: "MT"}, name: fmt.Sprintf("t%02d", i)}
	}

	var wg sync.WaitGroup
	for _, s := range shards {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = sched.Register(s)
			time.Sleep(2 * time.Millisecond)
			_ = sched.Deregister(s)
		}()
	}
	wg.Wait()

	for _, s := range shards {
		awaitAsyncRepWg(t, s, "asyncRepWg must drain after Deregister without Close")
	}
	sched.Close()
}

// TestRunEntryPanicSettlesOwnership: a prologue panic must not leak the owned Done or kill the worker.
func TestRunEntryPanicSettlesOwnership(t *testing.T) {
	for _, tc := range []struct {
		name  string
		class *models.Class
	}{
		{name: "nil class"},
		{name: "with class", class: &models.Class{Class: "C"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			sched := newBareScheduler(512, 1)
			sched.ctx = context.Background()
			sched.resultCh = make(chan asyncSchedulerResult, 8)

			s := &Shard{class: tc.class, name: "t0"}
			s.hashtree = (*hashtree.HashTree)(nil)
			s.asyncRepWg.Add(1)
			entry := &asyncSchedulerEntry{shard: s}
			entry.pendingDone.Store(true)

			entries := []*asyncSchedulerEntry{entry}
			require.NotPanics(t, func() { sched.runBatch(&entries, newBatchScratch()) })

			awaitAsyncRepWg(t, s, "panic in runEntry prologue must still settle the owned Done")
			assert.True(t, s.asyncReplicationRWMux.TryLock(), "panic must not leak the snapshot RLock")
			s.asyncReplicationRWMux.Unlock()
			results := drainResults(sched.resultCh)
			require.Len(t, results, 1)
			assert.ErrorContains(t, results[0].err, "panic")
		})
	}
}

// TestRunBatchPanicSettlesRemainingEntries: a mid-batch panic settles unhanded entries with error results and keeps the worker alive.
func TestRunBatchPanicSettlesRemainingEntries(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx = context.Background()
	sched.resultCh = make(chan asyncSchedulerResult, 8)

	shards := make([]*Shard, 3)
	entries := make([]*asyncSchedulerEntry, 3)
	for i := range entries {
		shards[i] = &Shard{class: &models.Class{Class: "C"}, name: fmt.Sprintf("t%d", i)}
		shards[i].asyncRepWg.Add(1)
		entries[i] = &asyncSchedulerEntry{shard: shards[i]}
		entries[i].pendingDone.Store(true)
	}

	hits := 0
	asyncRepBatchEntrySeam = func(*asyncSchedulerEntry) {
		hits++
		if hits == 2 {
			panic("boom")
		}
	}
	t.Cleanup(func() { asyncRepBatchEntrySeam = nil })

	batch := append([]*asyncSchedulerEntry{}, entries...)
	require.NotPanics(t, func() { sched.runBatch(&batch, newBatchScratch()) })

	for i, s := range shards {
		awaitAsyncRepWg(t, s, fmt.Sprintf("entry %d Done must settle after mid-batch panic", i))
	}
	results := drainResults(sched.resultCh)
	require.Len(t, results, 3)
	panicked := 0
	for _, r := range results {
		if r.err != nil {
			assert.ErrorContains(t, r.err, "panic in async replication batch")
			panicked++
		}
	}
	assert.Equal(t, 2, panicked, "the two unhanded entries must carry the panic error")
}

// TestDispatcherPanicSettlesReservationsAndUnblocks: a dispatcher panic settles bucket reservations and self-cancels so Register and Close return.
func TestDispatcherPanicSettlesReservationsAndUnblocks(t *testing.T) {
	logger, _ := test.NewNullLogger()
	asyncRepDispatchSeam = func(*asyncSchedulerEntry) { panic("boom") }
	t.Cleanup(func() { asyncRepDispatchSeam = nil })

	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)

	idx := &Index{Config: IndexConfig{ClassName: "C"}}
	s := &Shard{index: idx, class: &models.Class{Class: "C"}, name: "t0"}
	require.NoError(t, sched.Register(s))

	select {
	case <-sched.ctx.Done():
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher panic must self-cancel the scheduler")
	}
	awaitAsyncRepWg(t, s, "stranded bucket reservation must settle after dispatcher panic")
	assert.ErrorIs(t, sched.Register(&Shard{}), ErrSchedulerClosed)

	done := make(chan struct{})
	go func() { sched.Close(); close(done) }()
	select {
	case <-done:
	case <-time.After(10 * time.Second):
		t.Fatal("Close must return after a dispatcher panic")
	}
}

// TestSettleDispatchBucketsOnExit: reservations stranded in dispatchPending are settled and cleared.
func TestSettleDispatchBucketsOnExit(t *testing.T) {
	sched := newBareScheduler(512, 1)
	idx := &Index{Config: IndexConfig{ClassName: "C"}}
	s := &Shard{index: idx, class: &models.Class{Class: "C"}}
	s.asyncRepWg.Add(1)
	entry := &asyncSchedulerEntry{shard: s, inFlight: true}
	entry.pendingDone.Store(true)
	sched.dispatchPending = append(sched.dispatchPending, entry)

	sched.settleDispatchBucketsOnExit()

	awaitAsyncRepWg(t, s, "stranded pending reservation must settle")
	assert.False(t, entry.inFlight)
	assert.Empty(t, sched.dispatchPending)
}

// TestDispatchBucketsEmptiedEveryPass: no entry pointer may survive a dispatch pass, or dropped collections stay pinned forever.
func TestDispatchBucketsEmptiedEveryPass(t *testing.T) {
	zeroCoalesceWindow(t)
	tests := []struct {
		name           string
		batchSize      int
		workChCap      int
		shardsByClass  map[string]int
		wantBatchSizes []int
		wantHeapLen    int
	}{
		{"after cross-class merged dispatch", 512, 16, map[string]int{"A": 3, "B": 2}, []int{5}, 0},
		{"after mid-pass full batch", 2, 16, map[string]int{"C": 4}, []int{2, 2}, 0},
		{"after full-channel rollback", 512, 0, map[string]int{"C": 3}, nil, 3},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			sched := newBareScheduler(tc.batchSize, tc.workChCap)
			for class, n := range tc.shardsByClass {
				idx := &Index{Config: IndexConfig{ClassName: entschema.ClassName(class)}}
				for range n {
					sched.onAddLocked(&Shard{index: idx, class: &models.Class{Class: class}})
				}
			}

			sched.dispatchDueLocked()

			assert.ElementsMatch(t, tc.wantBatchSizes, drainBatchSizes(sched.workCh))
			assert.Len(t, sched.h, tc.wantHeapLen)
			assert.Empty(t, sched.dispatchPending)
		})
	}
}

// TestDeregisterSettlesEntriesAwaitingPrefilter: entries parked behind the root pre-filter stay settleable, so teardown drains never wait out an RPC bound to sched.ctx.
func TestDeregisterSettlesEntriesAwaitingPrefilter(t *testing.T) {
	sched := newBareScheduler(512, 1)
	sched.ctx = context.Background()
	sched.resultCh = make(chan asyncSchedulerResult, 8)

	release := make(chan struct{})
	inPrefilter := make(chan struct{})
	asyncRepPrefilterSeam = func(context.Context, map[string]hashtree.Digest) map[string]struct{} {
		close(inPrefilter)
		<-release
		return nil
	}
	t.Cleanup(func() { asyncRepPrefilterSeam = nil })

	idx := &Index{Config: IndexConfig{ClassName: "C"}}
	shards := make([]*Shard, 2)
	entries := make([]*asyncSchedulerEntry, 2)
	for i := range shards {
		ht, err := hashtree.NewHashTree(1)
		require.NoError(t, err)
		shards[i] = &Shard{index: idx, class: &models.Class{Class: "C"}, name: fmt.Sprintf("t%d", i)}
		shards[i].hashtree = ht
		shards[i].hashtreeFullyInitialized = true
		shards[i].asyncRepWg.Add(1)
		entries[i] = &asyncSchedulerEntry{shard: shards[i]}
		entries[i].pendingDone.Store(true)
	}

	batch := append([]*asyncSchedulerEntry{}, entries...)
	batchDone := make(chan struct{})
	go func() { sched.runBatch(&batch, newBatchScratch()); close(batchDone) }()

	<-inPrefilter
	for _, e := range entries {
		e.settleDone()
	}
	for i, s := range shards {
		awaitAsyncRepWg(t, s, fmt.Sprintf("shard %d drain must not wait for the in-flight pre-filter", i))
	}

	close(release)
	<-batchDone
	assert.Empty(t, drainResults(sched.resultCh), "settled entries must not produce results")
}

// TestNextIntervalFloorsZeroFrequency: an error result with an unresolved cfg must not hot-loop the entry.
func TestNextIntervalFloorsZeroFrequency(t *testing.T) {
	sched := newBareScheduler(512, 1)
	got := sched.nextInterval(AsyncReplicationConfig{}, &asyncSchedulerEntry{}, asyncSchedulerResult{err: errors.New("panic in async replication cycle")})
	assert.Equal(t, defaultFrequency, got)
}

// TestRunEntrySkipHashbeatRecordsNoDiffStatus pins that a root-prefilter skip surfaces in asyncReplicationStatus like the ErrNoDiffFound descent it replaces.
func TestRunEntrySkipHashbeatRecordsNoDiffStatus(t *testing.T) {
	sched := newSchedulerForUnitTest(t)
	s := &Shard{asyncRepCtx: context.Background(), class: &models.Class{Class: "C"}, name: "S"}
	s.asyncRepWg.Add(1)

	sched.runEntry(&asyncSchedulerEntry{shard: s}, true)

	stats := s.getAsyncReplicationStats(context.Background())
	require.Len(t, stats, 1, "a prefilter-skipped cycle proves in-sync and must be visible in asyncReplicationStatus")
	require.Empty(t, stats[0].TargetNode)
	require.Positive(t, stats[0].StartDiffTimeUnixMillis)
}

// TestRecordRootPrefilterNoDiffCancelRaceLeavesStatsEmpty pins that the cancellation check runs under the stats lock: a disable's cancel+clear landing while the recorder awaits the lock must not leave a phantom entry, in every interleaving.
func TestRecordRootPrefilterNoDiffCancelRaceLeavesStatsEmpty(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	s := &Shard{}

	s.asyncReplicationStatsMux.Lock()
	done := make(chan struct{})
	go func() {
		defer close(done)
		s.recordRootPrefilterNoDiff(ctx)
	}()
	cancel()
	s.asyncReplicationStatsByTargetNode = nil
	s.asyncReplicationStatsMux.Unlock()
	<-done

	require.Empty(t, s.getAsyncReplicationStats(context.Background()))
}

type fakeCrossClassComparer func(ctx context.Context, host string, classes map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error)

func (f fakeCrossClassComparer) CompareHashTreeRootsMulti(ctx context.Context, host string,
	classes map[string]map[string]hashtree.Digest,
) (*replica.CompareHashTreeRootsMultiResp, error) {
	return f(ctx, host, classes)
}

func newPrefilterShard(t *testing.T, class, name string) *asyncSchedulerEntry {
	ht, err := hashtree.NewHashTree(1)
	require.NoError(t, err)
	s := &Shard{index: &Index{Config: IndexConfig{ClassName: entschema.ClassName(class)}}, class: &models.Class{Class: class}, name: name}
	s.hashtree = ht
	s.hashtreeFullyInitialized = true
	return &asyncSchedulerEntry{shard: s}
}

// TestClassifyCrossClass covers skip/descend outcomes across hosts, classes, and fallback paths.
func TestClassifyCrossClass(t *testing.T) {
	okAll := func(classes map[string]map[string]hashtree.Digest) *replica.CompareHashTreeRootsMultiResp {
		resp := &replica.CompareHashTreeRootsMultiResp{Classes: map[string]replica.CompareHashTreeRootsMultiClassResp{}}
		for cls := range classes {
			resp.Classes[cls] = replica.CompareHashTreeRootsMultiClassResp{}
		}
		return resp
	}
	type shardSpec struct{ class, name string }
	type responder func(map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error)
	refuse := func(map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
		return nil, errors.New("connection refused")
	}
	tests := []struct {
		name        string
		shards      []shardSpec
		hosts       map[string][]string
		hostErrs    map[string]error
		respond     map[string]responder
		fallback    func(map[string]hashtree.Digest) map[string]struct{}
		nilComparer bool
		wantSkip    map[string]bool
	}{
		{
			name:     "all hosts report in sync",
			shards:   []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:    map[string][]string{"s1": {"h1", "h2"}, "s2": {"h1", "h2"}},
			wantSkip: map[string]bool{"s1": true, "s2": true},
		},
		{
			name:   "diverging shard descends",
			shards: []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:  map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond: map[string]responder{
				"h1": func(classes map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					resp := okAll(classes)
					resp.Classes["A"] = replica.CompareHashTreeRootsMultiClassResp{DivergingShards: []string{"s1"}}
					return resp, nil
				},
			},
			wantSkip: map[string]bool{"s1": false, "s2": true},
		},
		{
			name:   "class error descends only that class",
			shards: []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:  map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond: map[string]responder{
				"h1": func(classes map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					resp := okAll(classes)
					resp.Classes["A"] = replica.CompareHashTreeRootsMultiClassResp{Error: "index not loaded"}
					return resp, nil
				},
			},
			wantSkip: map[string]bool{"s1": false, "s2": true},
		},
		{
			name:   "class missing from response descends",
			shards: []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:  map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond: map[string]responder{
				"h1": func(classes map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					resp := okAll(classes)
					delete(resp.Classes, "B")
					return resp, nil
				},
			},
			wantSkip: map[string]bool{"s1": true, "s2": false},
		},
		{
			name:     "transport error descends the host tuples",
			shards:   []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:    map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond:  map[string]responder{"h1": refuse},
			wantSkip: map[string]bool{"s1": false, "s2": false},
		},
		{
			name:     "one healthy and one erroring host descends",
			shards:   []shardSpec{{"A", "s1"}},
			hosts:    map[string][]string{"s1": {"h1", "h2"}},
			respond:  map[string]responder{"h2": refuse},
			wantSkip: map[string]bool{"s1": false},
		},
		{
			name:   "unsupported peer falls back per class",
			shards: []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:  map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond: map[string]responder{
				"h1": func(map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					return nil, replica.ErrCompareHashTreeRootsUnsupported
				},
			},
			fallback: func(roots map[string]hashtree.Digest) map[string]struct{} {
				if _, ok := roots["s1"]; ok {
					return map[string]struct{}{"s1": {}}
				}
				return nil
			},
			wantSkip: map[string]bool{"s1": false, "s2": true},
		},
		{
			name:        "nil comparer falls back per class",
			shards:      []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:       map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			nilComparer: true,
			fallback:    func(map[string]hashtree.Digest) map[string]struct{} { return nil },
			wantSkip:    map[string]bool{"s1": true, "s2": true},
		},
		{
			name:     "no remote targets skips",
			shards:   []shardSpec{{"A", "s1"}},
			hosts:    map[string][]string{"s1": {}},
			wantSkip: map[string]bool{"s1": true},
		},
		{
			name:     "host resolution error descends",
			shards:   []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:    map[string][]string{"s2": {"h1"}},
			hostErrs: map[string]error{"s1": errors.New("no routing plan")},
			wantSkip: map[string]bool{"s1": false, "s2": true},
		},
		{
			name:   "responder panic forces full descent",
			shards: []shardSpec{{"A", "s1"}, {"B", "s2"}},
			hosts:  map[string][]string{"s1": {"h1"}, "s2": {"h1"}},
			respond: map[string]responder{
				"h1": func(map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					panic("boom")
				},
			},
			wantSkip: map[string]bool{"s1": false, "s2": false},
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			asyncRepTargetHostsSeam = func(s *Shard) ([]string, error) {
				if err := tc.hostErrs[s.name]; err != nil {
					return nil, err
				}
				return tc.hosts[s.name], nil
			}
			t.Cleanup(func() { asyncRepTargetHostsSeam = nil })
			if tc.fallback != nil {
				asyncRepPerClassFallbackSeam = func(_ context.Context, roots map[string]hashtree.Digest) (map[string]struct{}, replica.PrefilterStats) {
					return tc.fallback(roots), replica.PrefilterStats{OK: 1}
				}
				t.Cleanup(func() { asyncRepPerClassFallbackSeam = nil })
			}
			sched := newBareScheduler(512, 1)
			sched.ctx = context.Background()
			if !tc.nilComparer {
				sched.crossClassComparer = fakeCrossClassComparer(func(_ context.Context, host string, classes map[string]map[string]hashtree.Digest) (*replica.CompareHashTreeRootsMultiResp, error) {
					if r := tc.respond[host]; r != nil {
						return r(classes)
					}
					return okAll(classes), nil
				})
			}
			batch := make([]*asyncSchedulerEntry, 0, len(tc.shards))
			byName := map[string]*asyncSchedulerEntry{}
			for _, sp := range tc.shards {
				entry := newPrefilterShard(t, sp.class, sp.name)
				batch = append(batch, entry)
				byName[sp.name] = entry
			}
			scratch := newBatchScratch()
			sched.classifyBatch(batch, scratch)
			for name, want := range tc.wantSkip {
				assert.Equal(t, want, scratch.skip[byName[name]], name)
			}
		})
	}
}
