//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package propertyspecific

import (
	"context"

	"github.com/weaviate/weaviate/adapters/repos/db/vector/geo"
	"github.com/weaviate/weaviate/entities/errorcompounder"
	"github.com/weaviate/weaviate/entities/schema"
)

// Index - for now - only supports a Geo index as a property-specific index.
// This could be extended in the future, for example to allow vectorization of
// single properties, as opposed to only allowing vectorization of the entire
// object.
type Index struct {
	Name     string
	Type     schema.DataType
	GeoIndex *geo.Index
}

// Indices is a collection of property-specific Indices by propname
type Indices map[string]Index

// ByProp retrieves a property-specific index by prop name. Second argument is
// false, if the index doesn't exist.
func (i Indices) ByProp(propName string) (Index, bool) {
	index, ok := i[propName]
	return index, ok
}

func (i Indices) ShutdownGeoIndices(ctx context.Context) error {
	// one failing property must not skip the teardown of the remaining ones
	ec := errorcompounder.New()
	for propName, index := range i {
		if index.Type != schema.DataTypeGeoCoordinates {
			continue
		}

		ec.AddWrapf(index.GeoIndex.Flush(), "flush property %s", propName)
		ec.AddWrapf(index.GeoIndex.Shutdown(ctx), "shutdown property %s", propName)
	}
	return ec.ToError()
}

func (i Indices) DropAll(ctx context.Context, keepFiles bool) error {
	// one failing property must not skip the teardown of the remaining ones
	ec := errorcompounder.New()
	for propName, index := range i {
		if index.Type != schema.DataTypeGeoCoordinates {
			ec.Addf("no implementation to delete property %s index of type %v",
				propName, index.Type)
			continue
		}

		if err := index.GeoIndex.Drop(ctx, keepFiles); err != nil {
			ec.AddWrapf(err, "drop property %s", propName)
			continue
		}

		// Drop nils the underlying vector index, so a kept entry would panic
		// the next ShutdownGeoIndices
		delete(i, propName)
	}
	return ec.ToError()
}
