//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

//go:build integrationTest

package db

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/go-openapi/strfmt"
	"github.com/google/uuid"
	"github.com/prometheus/client_golang/prometheus/testutil"
	"github.com/sirupsen/logrus"
	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	replicationTypes "github.com/weaviate/weaviate/cluster/replication/types"
	routerTypes "github.com/weaviate/weaviate/cluster/router/types"
	"github.com/weaviate/weaviate/entities/additional"
	"github.com/weaviate/weaviate/entities/models"
	entreplication "github.com/weaviate/weaviate/entities/replication"
	"github.com/weaviate/weaviate/entities/storobj"
	"github.com/weaviate/weaviate/usecases/cluster"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"
	"github.com/weaviate/weaviate/usecases/monitoring"
	"github.com/weaviate/weaviate/usecases/objects"
	"github.com/weaviate/weaviate/usecases/replica"
	"github.com/weaviate/weaviate/usecases/replica/hashtree"
	schemaUC "github.com/weaviate/weaviate/usecases/schema"
)

// uuidLow and uuidHigh are deterministic UUIDs with clear binary ordering:
// uuidLow starts with 0x00 (lower half of UUID space),
// uuidHigh starts with 0xF0 (upper half of UUID space).
// This guarantees DigestObjectsInRange always returns them in the same order.
const (
	uuidLow  = strfmt.UUID("00000000-0000-0000-0000-000000000001")
	uuidHigh = strfmt.UUID("f0000000-0000-0000-0000-000000000001")
	uuidMid  = strfmt.UUID("70000000-0000-0000-0000-000000000001")
)

// tsFarPast is a timestamp (Unix ms) well in the past (1970-01-01 00:00:01 UTC).
const tsFarPast int64 = 1

// testObj builds a storobj with a known UUID and UpdateTime. The UpdateTime is
// stored as-is by PutObject (not overwritten by the shard layer).
func testObjWithTime(class string, id strfmt.UUID, updateTime int64) *storobj.Object {
	return &storobj.Object{
		MarshallerVersion: 1,
		Object: models.Object{
			ID:                 id,
			Class:              class,
			LastUpdateTimeUnix: updateTime,
		},
	}
}

// fixedDigestsClient is a test double whose DigestObjectsInRange always
// returns a pre-configured slice of digests. It also mirrors that "remote"
// state through CompareDigests by returning every source digest absent from
// `digests` as missing (UpdateTime=0) and every source digest with a strictly
// newer source UpdateTime as stale (UpdateTime=remote's value). This lets
// pre-existing tests retain their "remote-knowledge" semantics under the new
// CompareDigests protocol.
type fixedDigestsClient struct {
	FakeReplicationClient
	digests          []routerTypes.RepairDigest
	compareDigestErr error // if non-nil, CompareDigests returns this error instead of comparing
}

func (c *fixedDigestsClient) DigestObjectsInRange(
	_ context.Context, _, _, _ string, _, _ strfmt.UUID, _ int,
) ([]routerTypes.RepairDigest, error) {
	return c.digests, nil
}

func (c *fixedDigestsClient) CompareDigests(
	_ context.Context, _, _, _ string, source []routerTypes.RepairDigest,
) ([]routerTypes.RepairDigest, error) {
	if c.compareDigestErr != nil {
		return nil, c.compareDigestErr
	}
	remote := make(map[uuid.UUID]int64, len(c.digests))
	for _, d := range c.digests {
		remote[d.ID] = d.UpdateTime
	}
	out := make([]routerTypes.RepairDigest, 0, len(source))
	for _, s := range source {
		rt, ok := remote[s.ID]
		if !ok {
			// Missing on remote.
			out = append(out, routerTypes.RepairDigest{ID: s.ID, UpdateTime: 0})
			continue
		}
		if s.UpdateTime > rt {
			// Source is strictly newer than remote — stale on target.
			out = append(out, routerTypes.RepairDigest{ID: s.ID, UpdateTime: rt})
		}
		// Equal or remote-newer → no action needed.
	}
	return out, nil
}

// countingDigestsClient wraps fixedDigestsClient and counts CompareDigests calls, letting tests assert RPC round-trip counts.
type countingDigestsClient struct {
	*fixedDigestsClient
	compareCalls atomic.Int64
}

func (c *countingDigestsClient) CompareDigests(
	ctx context.Context, index, shard, host string, source []routerTypes.RepairDigest,
) ([]routerTypes.RepairDigest, error) {
	c.compareCalls.Add(1)
	return c.fixedDigestsClient.CompareDigests(ctx, index, shard, host, source)
}

// withReplicationClient returns an indexOpt that replaces the index's
// replicator with a new one backed by the given client. This allows tests to
// control what CompareDigests returns without modifying production code.
func withReplicationClient(t *testing.T, client replica.Client) func(*Index) {
	t.Helper()
	return func(idx *Index) {
		logger, _ := test.NewNullLogger()

		mockRouter := routerTypes.NewMockRouter(t)
		localReplica := routerTypes.Replica{NodeName: "node1", ShardName: "shard1", HostAddr: "127.0.0.1"}
		mockRouter.EXPECT().
			GetWriteReplicasLocation(mock.Anything, mock.Anything, mock.Anything).
			Return(routerTypes.WriteReplicaSet{Replicas: []routerTypes.Replica{localReplica}}, nil).
			Maybe()
		mockRouter.EXPECT().
			GetReadReplicasLocation(mock.Anything, mock.Anything, mock.Anything).
			Return(routerTypes.ReadReplicaSet{Replicas: []routerTypes.Replica{localReplica}}, nil).
			Maybe()

		nodeResolver := cluster.NewMockNodeResolver(t)

		rep, err := replica.NewReplicator(
			idx.Config.ClassName.String(),
			mockRouter,
			nodeResolver,
			"node1",
			func() string { return models.ReplicationConfigDeletionStrategyNoAutomatedResolution },
			client,
			monitoring.GetMetrics(),
			logger,
		)
		require.NoError(t, err)
		idx.replicator = rep
	}
}

// withRemoteReplicaClient wires a replicator whose router resolves one remote replica, so hashbeat descents reach the given client.
func withRemoteReplicaClient(t *testing.T, client replica.Client) func(*Index) {
	t.Helper()
	return func(idx *Index) {
		logger, _ := test.NewNullLogger()

		mockRouter := routerTypes.NewMockRouter(t)
		replicas := []routerTypes.Replica{
			{NodeName: "node1", ShardName: "shard1", HostAddr: "127.0.0.1"},
			{NodeName: "node2", ShardName: "shard1", HostAddr: "127.0.0.2"},
		}
		mockRouter.EXPECT().
			GetWriteReplicasLocation(mock.Anything, mock.Anything, mock.Anything).
			Return(routerTypes.WriteReplicaSet{Replicas: replicas}, nil).
			Maybe()
		mockRouter.EXPECT().
			GetReadReplicasLocation(mock.Anything, mock.Anything, mock.Anything).
			Return(routerTypes.ReadReplicaSet{Replicas: replicas}, nil).
			Maybe()
		mockRouter.EXPECT().
			BuildRoutingPlanOptions(mock.Anything, mock.Anything, mock.Anything, mock.Anything).
			RunAndReturn(func(tenant, shard string, cl routerTypes.ConsistencyLevel, direct string) routerTypes.RoutingPlanBuildOptions {
				return routerTypes.RoutingPlanBuildOptions{Shard: shard, Tenant: tenant, ConsistencyLevel: cl}
			}).
			Maybe()
		mockRouter.EXPECT().
			BuildReadRoutingPlan(mock.Anything).
			Return(routerTypes.ReadRoutingPlan{
				LocalHostname: "127.0.0.1",
				ReplicaSet:    routerTypes.ReadReplicaSet{Replicas: replicas},
			}, nil).
			Maybe()

		nodeResolver := cluster.NewMockNodeResolver(t)
		nodeResolver.EXPECT().NodeHostname("node1").Return("127.0.0.1", true).Maybe()
		nodeResolver.EXPECT().NodeHostname("node2").Return("127.0.0.2", true).Maybe()

		rep, err := replica.NewReplicator(
			idx.Config.ClassName.String(),
			mockRouter,
			nodeResolver,
			"node1",
			func() string { return models.ReplicationConfigDeletionStrategyNoAutomatedResolution },
			client,
			monitoring.GetMetrics(),
			logger,
		)
		require.NoError(t, err)
		idx.replicator = rep
	}
}

// fullRangeConfig returns an AsyncReplicationConfig that scans the entire UUID
// space (hashtreeHeight=1 → 2 leaves) in batches of batchSize objects.
func fullRangeConfig(batchSize int) AsyncReplicationConfig {
	return AsyncReplicationConfig{
		hashtreeHeight: 1,
		diffBatchSize:  batchSize,
	}
}

// withAsyncScheduler returns a testShard index option that installs a started
// AsyncReplicationScheduler on the index. Tests that call enableAsyncReplication
// directly need this because the function guards against a nil scheduler.
func withAsyncScheduler(t *testing.T) func(*Index) {
	t.Helper()
	return func(idx *Index) {
		sched := newStartedTestScheduler(t, 1)
		idx.asyncReplicationScheduler = sched
	}
}

// concreteShard unwraps the *Shard from a ShardLike returned by testShard.
// testShard passes EnableLazyLoadShards=true which causes initShard to create
// a real *Shard directly (not a LazyLoadShard wrapper).
func concreteShard(t testing.TB, sl ShardLike) *Shard {
	t.Helper()
	s, ok := sl.(*Shard)
	require.True(t, ok, "expected *Shard from testShard (EnableLazyLoadShards=true)")
	return s
}

// flushShard forces all pending memtable data to disk.
func flushShard(t *testing.T, ctx context.Context, shard ShardLike) {
	t.Helper()
	s, ok := shard.(*Shard)
	require.True(t, ok, "flushShard: expected *Shard, got %T", shard)
	require.NoError(t, s.store.FlushMemtables(ctx))
}

func (s *Shard) propagateWithinRangeForTest(t *testing.T, ctx context.Context,
	cfg AsyncReplicationConfig, addr, node string, initialLeaf, finalLeaf uint64,
	limit int, overrides additional.AsyncReplicationTargetNodeOverrides,
	asyncCheckpointCutoff int64,
) (int, []objectToPropagate, error) {
	t.Helper()
	cursor := s.store.Bucket(helpers.ObjectsBucketLSM).CursorReplaceReusable()
	defer cursor.Close()
	scratch := newPropagationScratch(cfg.diffBatchSize)
	return s.objectsToPropagateWithinRange(ctx, cfg, cursor, scratch, addr, node, initialLeaf, finalLeaf, limit, overrides, asyncCheckpointCutoff)
}

// ─── objectsToPropagateWithinRange ───────────────────────────────────────────

// TestObjectsToPropagateWithinRange covers the scanning and filtering logic
// inside objectsToPropagateWithinRange. Tests use well-known UUIDs so that
// batch ordering is deterministic. Flushing is not required for visibility:
// ObjectDigestsInRange uses a merged bucket cursor, which includes memtables.
func TestObjectsToPropagateWithinRange(t *testing.T) {
	ctx := context.Background()
	const class = "PropagateRangeTest"

	t.Run("EmptyShard", func(t *testing.T) {
		sl, idx := testShard(t, ctx, class)
		s := concreteShard(t, sl)
		cfg := fullRangeConfig(100)

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 0, local)
		assert.Empty(t, objs)
		_ = idx
	})

	// MemtableObjectsArePropagated verifies that objects still in the memtable
	// (not yet flushed to disk) are visible to DigestObjectsInRange because the
	// bucket cursor includes both memtable and on-disk segments.
	t.Run("MemtableObjectsArePropagated", func(t *testing.T) {
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{}))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		cfg := fullRangeConfig(100)

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 2, local, "memtable objects must be visible to the merged bucket cursor")
		assert.Len(t, objs, 2, "both memtable objects must be queued for propagation")
		_ = idx
	})

	// SourceBehindRemote verifies the no-op path: remote already has the same
	// objects with equal or newer timestamps, so nothing should be propagated.
	t.Run("SourceBehindRemote", func(t *testing.T) {
		// Pre-configure the remote to return the same digests as local.
		remoteDigests := []routerTypes.RepairDigest{
			{ID: uuid.MustParse(string(uuidLow)), UpdateTime: tsFarPast},
			{ID: uuid.MustParse(string(uuidHigh)), UpdateTime: tsFarPast},
		}
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{digests: remoteDigests}))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))
		cfg := fullRangeConfig(100)

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 2, local)
		assert.Empty(t, objs, "remote is up-to-date → nothing to propagate")
		_ = idx
	})

	// LimitEnforcement verifies that the propagation limit caps the number of
	// objects queued. The default FakeReplicationClient returns empty digests for
	// DigestObjectsInRange (remote has nothing), so every local object appears
	// missing and is queued for propagation.
	t.Run("LimitEnforcement", func(t *testing.T) {
		const limit = 1
		// fixedDigestsClient with no preconfigured digests → CompareDigests
		// reports every source UUID as missing on remote, so each local
		// object is queued for propagation (subject to the limit).
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{}))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))
		cfg := fullRangeConfig(100)

		_, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, limit, nil, 0,
		)
		require.NoError(t, err)
		assert.LessOrEqual(t, len(objs), limit,
			"number of queued propagations must not exceed the limit")
		_ = idx
	})

	// FetchBatchDecoupledFromBudget guards the perf fix: a small propagation
	// limit must not shrink the scan/compare batch. With three in-sync objects
	// and limit=1, the whole leaf must be scanned in a single CompareDigests RPC
	// (diffBatchSize=100), not one round-trip per object.
	t.Run("FetchBatchDecoupledFromBudget", func(t *testing.T) {
		remoteDigests := []routerTypes.RepairDigest{
			{ID: uuid.MustParse(string(uuidLow)), UpdateTime: tsFarPast},
			{ID: uuid.MustParse(string(uuidMid)), UpdateTime: tsFarPast},
			{ID: uuid.MustParse(string(uuidHigh)), UpdateTime: tsFarPast},
		}
		client := &countingDigestsClient{fixedDigestsClient: &fixedDigestsClient{digests: remoteDigests}}
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, client))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidMid, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))
		cfg := fullRangeConfig(100)

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 1, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 3, local, "all three in-sync objects must be scanned despite limit=1")
		assert.Empty(t, objs, "in-sync objects produce no propagations")
		assert.Equal(t, int64(1), client.compareCalls.Load(),
			"leaf must be scanned in one CompareDigests RPC, not one per object")
		_ = idx
	})

	// PropagationDelayExcludesRecentObjects verifies that objects whose UpdateTime
	// falls within [now - propagationDelay, now] are excluded from the propagation
	// batch. This exercises the getHashBeatMaxUpdateTime filter in
	// objectsToPropagateWithinRange. Without the filter a regression (e.g.
	// reversed comparison) would silently propagate objects before the delay
	// elapses, breaking the propagation-delay contract.
	t.Run("PropagationDelayExcludesRecentObjects", func(t *testing.T) {
		// Remote has no objects, so every local object would normally appear as
		// missing and be queued for propagation.
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{}))

		// Use a timestamp very close to now so that it is definitely within the
		// propagation delay window for any realistic clock skew.
		recentTS := time.Now().UnixMilli()
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, recentTS)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))

		cfg := AsyncReplicationConfig{
			hashtreeHeight:   1,
			diffBatchSize:    100,
			propagationDelay: 30 * time.Second,
		}

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 0, local,
			"recently updated object must be excluded by the propagation delay filter")
		assert.Empty(t, objs,
			"no objects must be queued when all are within the propagation delay window")
		_ = idx
	})

	// PropagationDelayCursorAdvancesFastBatch verifies that when an entire batch
	// is filtered out by the propagation delay, the cursor advances past it and
	// continues scanning the remaining UUID space. batchSize=1 forces each UUID
	// into its own batch, so the cursor-advance branch in the filtered path is
	// exercised and uuidHigh (which is old) must still be found and queued.
	t.Run("PropagationDelayCursorAdvancesPastFilteredBatch", func(t *testing.T) {
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{}))

		recentTS := time.Now().UnixMilli()
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, recentTS)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))

		cfg := AsyncReplicationConfig{
			hashtreeHeight:   1,
			diffBatchSize:    1, // one UUID per batch; forces cursor advance when uuidLow is filtered
			propagationDelay: 30 * time.Second,
		}

		local, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.NoError(t, err)
		assert.Equal(t, 1, local,
			"only uuidHigh (old) must count; uuidLow (recent) must be excluded")
		require.Len(t, objs, 1,
			"cursor must advance past the all-filtered uuidLow batch and find uuidHigh")
		assert.Equal(t, uuidHigh, objs[0].uuid,
			"the queued object must be uuidHigh, not the recent uuidLow")
		_ = idx
	})

	// CompareDigestsTransportError verifies that a wire failure on CompareDigests
	// is wrapped, surfaces no propagated objects, and does not corrupt the local
	// scan counters (local count reflects what was scanned before the wire call).
	t.Run("CompareDigestsTransportError", func(t *testing.T) {
		client := &fixedDigestsClient{compareDigestErr: errors.New("simulated rpc unavailable")}
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, client))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))
		cfg := fullRangeConfig(100)

		_, objs, err := s.propagateWithinRangeForTest(
			t, ctx, cfg, "http://fake", "node2", 0, 1, 100, nil, 0,
		)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "comparing digests with remote",
			"transport error must be wrapped with the scheduler's prefix")
		assert.Contains(t, err.Error(), "simulated rpc unavailable",
			"original error must be preserved via %w wrapping")
		assert.Empty(t, objs, "no objects must be queued when CompareDigests fails")
		_ = idx
	})

	// ScratchReusedAcrossRanges guards the per-beat buffer reuse: a second call on the same scratch must not leak the first's queued objects.
	t.Run("ScratchReusedAcrossRanges", func(t *testing.T) {
		sl, idx := testShard(t, ctx, class, withReplicationClient(t, &fixedDigestsClient{}))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidLow, tsFarPast)))
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))

		s := concreteShard(t, sl)
		require.NoError(t, s.store.FlushMemtables(ctx))
		cfg := fullRangeConfig(100)

		cursor := s.store.Bucket(helpers.ObjectsBucketLSM).CursorReplaceReusable()
		defer cursor.Close()
		scratch := newPropagationScratch(cfg.diffBatchSize)

		local1, objs1, err := s.objectsToPropagateWithinRange(ctx, cfg, cursor, scratch, "http://fake", "node2", 0, 1, 100, nil, 0)
		require.NoError(t, err)
		require.Len(t, objs1, 2)
		want := []strfmt.UUID{objs1[0].uuid, objs1[1].uuid}

		local2, objs2, err := s.objectsToPropagateWithinRange(ctx, cfg, cursor, scratch, "http://fake", "node2", 0, 1, 100, nil, 0)
		require.NoError(t, err)
		require.Len(t, objs2, 2, "reused scratch must not leak the prior range's queued objects")
		assert.Equal(t, local1, local2)
		assert.Equal(t, want, []strfmt.UUID{objs2[0].uuid, objs2[1].uuid})
		_ = idx
	})
}

// ─── Async Replication Lifecycle ─────────────────────────────────────────────

// minAsyncReplicationConfig returns a valid AsyncReplicationConfig suitable
// for unit tests that enable async replication.  All ticker durations are
// non-zero (time.NewTicker panics on zero) but large enough that background
// goroutines don't fire during the test lifetime.
func minAsyncReplicationConfig() AsyncReplicationConfig {
	return AsyncReplicationConfig{
		hashtreeHeight:            1,
		frequency:                 10 * time.Minute,
		frequencyWhilePropagating: 10 * time.Minute,
		diffBatchSize:             100,
		propagationLimit:          100,
		propagationConcurrency:    1,
		propagationBatchSize:      10,
		diffPerNodeTimeout:        5 * time.Second,
		prePropagationTimeout:     5 * time.Second,
		propagationTimeout:        5 * time.Second,
	}
}

// awaitHashtreeInitialized polls hashtreeFullyInitialized until it is true or
// the deadline fires.  Since writes no longer update the hashtree, the init
// goroutine is the only writer; polling under RLock is safe and race-free.
func awaitHashtreeInitialized(t *testing.T, s *Shard) {
	t.Helper()
	require.Eventually(t, func() bool {
		s.asyncReplicationRWMux.RLock()
		defer s.asyncReplicationRWMux.RUnlock()
		return s.hashtreeFullyInitialized
	}, 10*time.Second, 10*time.Millisecond, "hashtree did not become fully initialized within timeout")
}

// newAsyncTestShard builds a scheduler-backed shard with shutdown cleanup.
func newAsyncTestShard(t *testing.T, ctx context.Context, class string) (ShardLike, *Shard) {
	t.Helper()
	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })
	return sl, s
}

// enableAndAwaitAsync enables async replication and waits for full hashtree init.
func enableAndAwaitAsync(t *testing.T, ctx context.Context, s *Shard) {
	t.Helper()
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	awaitHashtreeInitialized(t, s)
}

// stopAsyncAndDump mirrors performShutdown's stop-then-persist sequence.
func stopAsyncAndDump(t *testing.T, s *Shard) {
	t.Helper()
	ht := s.mayStopAsyncReplication(true)
	require.NotNil(t, ht, "capture must return the fully-initialized tree")
	s.dumpHashTreeWithTimeout(ht, hashtreeDumpTimeout)
}

// newSeededAsyncShard builds a shard with three flushed objects and async replication fully initialized.
func newSeededAsyncShard(t *testing.T, ctx context.Context, class string) (ShardLike, *Shard) {
	t.Helper()
	sl, s := newAsyncTestShard(t, ctx, class)
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
	}
	flushShard(t, ctx, sl)
	enableAndAwaitAsync(t, ctx, s)
	return sl, s
}

// TestAsyncReplicationEnableDisableCycle verifies the shard can be cycled
// through enable → disable → re-enable without panicking or deadlocking, and
// that hashtree state is correctly managed across transitions.
func TestAsyncReplicationEnableDisableCycle(t *testing.T) {
	ctx := context.Background()
	const class = "AsyncReplicationLifecycleTest"

	config := minAsyncReplicationConfig()
	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)

	// First enable: spawns init goroutine; hashtree must be allocated.
	require.NoError(t, s.enableAsyncReplication(context.Background(), config))
	s.asyncReplicationRWMux.RLock()
	assert.NotNil(t, s.hashtree, "hashtree must be allocated after first enable")
	s.asyncReplicationRWMux.RUnlock()

	// Disable: cancels the init goroutine and clears all state.
	require.NoError(t, s.disableAsyncReplication(context.Background()))
	s.asyncReplicationRWMux.RLock()
	assert.Nil(t, s.hashtree, "hashtree must be nil after disable")
	assert.False(t, s.hashtreeFullyInitialized)
	s.asyncReplicationRWMux.RUnlock()

	// Re-enable: must work without panic or deadlock.
	require.NoError(t, s.enableAsyncReplication(context.Background(), config))
	s.asyncReplicationRWMux.RLock()
	assert.NotNil(t, s.hashtree, "hashtree must be re-allocated after re-enable")
	s.asyncReplicationRWMux.RUnlock()

	// Wait for the init goroutine on the (empty) shard to finish.
	awaitHashtreeInitialized(t, s)

	// Idempotent enable: no-op when already enabled.
	require.NoError(t, s.enableAsyncReplication(context.Background(), config))
	require.NoError(t, s.enableAsyncReplication(context.Background(), config))

	// Config update while running: enableAsyncReplication with a different
	// config must update s.asyncReplicationConfig even though the shard is
	// already running. This covers the case where per-class overrides are
	// cleared (cfg.AsyncConfig transitions from non-nil to nil): the caller
	// does not call disableAsyncReplication first, so enableAsyncReplication
	// must update the stored config itself.
	updatedConfig := config
	newFreq := 99 * time.Minute
	updatedConfig.frequency = newFreq
	require.NoError(t, s.enableAsyncReplication(context.Background(), updatedConfig))
	s.asyncReplicationRWMux.RLock()
	assert.NotNil(t, s.hashtree, "hashtree must still be running after config update")
	assert.Equal(t, newFreq, s.asyncReplicationConfig.frequency,
		"asyncReplicationConfig must be updated even when shard is already running")
	s.asyncReplicationRWMux.RUnlock()

	// Final cleanup.
	require.NoError(t, s.disableAsyncReplication(context.Background()))
}

// TestReconcileAsyncReplicationOnFlagToggle verifies that
// Index.reconcileAsyncReplication starts async replication on a shard that
// skipped initialisation because the global AsyncReplicationDisabled flag was
// set at load time, and stops it again when the flag is re-disabled.
func TestReconcileAsyncReplicationOnFlagToggle(t *testing.T) {
	ctx := context.Background()
	const class = "ReconcileAsyncReplicationTest"

	logger, _ := test.NewNullLogger()

	// Index-level flag the test toggles.
	disabled := configRuntime.NewDynamicValue(true)
	globalConfig := &entreplication.GlobalConfig{AsyncReplicationDisabled: disabled}

	sl, idx := testShard(t, ctx, class, func(i *Index) {
		i.Config.ReplicationFactor = 3
		i.globalreplicationConfig = globalConfig

		// A scheduler whose own disabled flag is permanently set: it accepts
		// Register/Deregister but never dispatches a hashbeat cycle. This keeps
		// the test focused on reconcile's effect on shard state (hashtree +
		// registration) without needing to mock the per-cycle router calls.
		sched, err := NewAsyncReplicationScheduler(ctx,
			entreplication.GlobalConfig{
				AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
				AsyncReplicationDisabled:         configRuntime.NewDynamicValue(true),
			}, nil, logger)
		require.NoError(t, err)
		t.Cleanup(sched.Close)
		i.asyncReplicationScheduler = sched
	})
	s := concreteShard(t, sl)

	// The shard loaded while async replication was globally disabled, so
	// shard_init_lsm skipped init: no hashtree, not registered with the scheduler.
	s.asyncReplicationRWMux.RLock()
	require.Nil(t, s.hashtree, "async replication must be off when loaded while globally disabled")
	s.asyncReplicationRWMux.RUnlock()

	// Re-enable the flag at runtime and reconcile: the already-loaded shard must
	// now start async replication.
	disabled.SetValue(false)
	require.NoError(t, idx.reconcileAsyncReplication(ctx))
	s.asyncReplicationRWMux.RLock()
	require.NotNil(t, s.hashtree, "reconcile must start async replication after the flag is re-enabled")
	s.asyncReplicationRWMux.RUnlock()
	awaitHashtreeInitialized(t, s)

	// Reconcile again with the flag still enabled: idempotent no-op.
	require.NoError(t, idx.reconcileAsyncReplication(ctx))
	s.asyncReplicationRWMux.RLock()
	require.NotNil(t, s.hashtree, "reconcile must be idempotent while the flag stays enabled")
	s.asyncReplicationRWMux.RUnlock()

	// Disable the flag again and reconcile: async replication must stop.
	disabled.SetValue(true)
	require.NoError(t, idx.reconcileAsyncReplication(ctx))
	s.asyncReplicationRWMux.RLock()
	require.Nil(t, s.hashtree, "reconcile must stop async replication after the flag is disabled")
	s.asyncReplicationRWMux.RUnlock()
}

// asyncSchedulerOption returns a testShard index option installing a started
// scheduler whose own disabled flag is permanently set — it accepts
// Register/Deregister but never dispatches a hashbeat cycle.
func asyncSchedulerOption(t *testing.T, ctx context.Context) func(*Index) {
	t.Helper()
	return func(i *Index) {
		logger, _ := test.NewNullLogger()
		sched, err := NewAsyncReplicationScheduler(ctx,
			entreplication.GlobalConfig{
				AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
				AsyncReplicationDisabled:         configRuntime.NewDynamicValue(true),
			}, nil, logger)
		require.NoError(t, err)
		t.Cleanup(sched.Close)
		i.asyncReplicationScheduler = sched
	}
}

func setShardReplicas(t *testing.T, idx *Index, nodes ...string) {
	t.Helper()
	m, ok := idx.schemaReader.(*schemaUC.MockSchemaReader)
	require.True(t, ok, "schemaReader is not a *MockSchemaReader")
	for _, c := range m.ExpectedCalls {
		if c.Method == "ShardReplicas" {
			c.ReturnArguments = mock.Arguments{nodes, error(nil)}
			return
		}
	}
	m.EXPECT().ShardReplicas(mock.Anything, mock.Anything).Return(nodes, nil).Maybe()
}

// TestRunHashbeatCycle_SkipsWhileNonTerminalOpForShard pins the cycle's
// in-flight short-circuit: while a non-terminal op targets the local node for
// this shard, the cycle must return without invoking the replicator so the
// CCL stays the exclusive catch-up channel. A nil FSM reader is treated as
// "no in-flight ops" — the fall-through path for tests that don't plumb one.
func TestRunHashbeatCycle_SkipsWhileNonTerminalOpForShard(t *testing.T) {
	ctx := context.Background()
	const class = "HashbeatInflightCheck"

	sh, idx := testShard(t, ctx, class, asyncSchedulerOption(t, ctx))
	shardName := sh.Name()
	setShardReplicas(t, idx, "node1", "node2")
	localNode := idx.db.localNodeName

	// Swap in a fresh FSM reader so we control the predicate this cycle reads.
	fsmMock := replicationTypes.NewMockReplicationFSMReader(t)
	fsmMock.EXPECT().HasActiveReplicationForShard(mock.Anything, mock.Anything).Return(false).Maybe()
	saved := idx.getReplicationFSMReader()
	idx.SetReplicationFSMReader(fsmMock)
	defer func() { idx.SetReplicationFSMReader(saved) }()

	// Resolve the concrete *Shard to invoke runHashbeatCycle directly.
	concrete, ok := sh.(*Shard)
	require.True(t, ok, "expected a concrete *Shard from testShard")

	cfg := idx.AsyncReplicationConfig()

	t.Run("non-terminal op short-circuits the cycle", func(t *testing.T) {
		// Cycle must consult the FSM, see the in-flight op, and return without
		// calling the replicator (asserted implicitly via NewMockReplicationFSMReader's
		// Cleanup: any unexpected call would fail the mock).
		call := fsmMock.EXPECT().HasActiveTargetReplicationForShard(class, shardName, localNode).Return(true).Once()
		defer call.Unset()
		propagated, err := concrete.runHashbeatCycle(ctx, cfg)
		require.NoError(t, err)
		require.False(t, propagated, "no objects must be propagated while an op is in flight")
	})

	t.Run("nil FSM reader is treated as no in-flight ops", func(t *testing.T) {
		// Tests that never plumb the reader should not have their hashbeat
		// gated by an absent FSM — they fall through to the normal gate.
		idx.SetReplicationFSMReader(nil)
		defer func() { idx.SetReplicationFSMReader(fsmMock) }()

		// We don't need to drive a full diff; we just want to confirm we got
		// past the FSM short-circuit. With no peers configured, the cycle
		// exits cleanly via the existing "no diff found" path. The mock would
		// catch any FSM call here (none allowed; we restored the nil reader).
		_, _ = concrete.runHashbeatCycle(ctx, cfg)
	})
}

// notReadyHashTreeClient returns the not-ready sentinel from HashTreeLevel, as the mapped transport clients do.
type notReadyHashTreeClient struct {
	FakeReplicationClient
}

func (*notReadyHashTreeClient) HashTreeLevel(
	context.Context, string, string, string, int, *hashtree.Bitset,
) ([]hashtree.Digest, error) {
	return nil, fmt.Errorf("%w: hashtree not initialized on shard", replica.ErrAsyncReplicationNotActive)
}

// TestRunHashbeatCycleNotReadyIsQuiet: a not-ready peer must neither count as an iteration failure nor log a warning.
func TestRunHashbeatCycleNotReadyIsQuiet(t *testing.T) {
	ctx := context.Background()
	const class = "HashbeatNotReadyQuietTest"

	logger, hook := test.NewNullLogger()
	sl, idx := testShard(t, ctx, class, asyncSchedulerOption(t, ctx),
		withRemoteReplicaClient(t, &notReadyHashTreeClient{}),
		func(i *Index) { i.logger = logger },
	)
	s := concreteShard(t, sl)
	idx.SetReplicationFSMReader(nil)
	setShardReplicas(t, idx, "node1", "node2")

	metrics, err := NewMetrics(logger, monitoring.GetMetrics(), class, s.name)
	require.NoError(t, err)
	s.metrics = metrics
	enableAndAwaitAsync(t, ctx, s)

	require.NotNil(t, s.metrics.asyncReplicationIterationFailureCount)
	failuresBefore := testutil.ToFloat64(s.metrics.asyncReplicationIterationFailureCount)

	_, err = s.runHashbeatCycle(ctx, minAsyncReplicationConfig())
	require.ErrorIs(t, err, errAsyncReplicationNotActive)

	require.Equal(t, failuresBefore, testutil.ToFloat64(s.metrics.asyncReplicationIterationFailureCount),
		"a not-ready peer must not count as an iteration failure")
	for _, e := range hook.AllEntries() {
		if e.Level == logrus.WarnLevel {
			require.NotContains(t, e.Message, "hashbeat", "not-ready must log at Debug, not Warn: %s", e.Message)
		}
	}
}

func TestReconcileDoesNotForceLoadUnloadedShard(t *testing.T) {
	ctx := context.Background()
	const class = "ReconcileNoForceLoad"

	_, idx := testShard(t, ctx, class, asyncSchedulerOption(t, ctx))
	setShardReplicas(t, idx, "node1", "node2")

	// Register an unloaded lazy shard under a fresh name (disableLazyLoad=false).
	const lazyName = "lazy-cold-shard"
	sl, err := idx.initShard(ctx, lazyName, &models.Class{Class: class}, nil, false, false)
	require.NoError(t, err)
	lazy, ok := sl.(*LazyLoadShard)
	require.True(t, ok, "expected a *LazyLoadShard")
	require.False(t, lazy.isLoaded(), "precondition: shard must start unloaded")
	idx.shards.Store(lazyName, sl)

	require.NoError(t, idx.ReconcileAsyncReplicationForShard(ctx, lazyName))
	require.False(t, lazy.isLoaded(), "reconcile must not force-load an unloaded shard")
}

// TestRepairEndpointsDoNotForceLoadUnloadedShard: the async-replication data
// endpoints must return the typed not-ready error for a cold shard, never load it.
func TestRepairEndpointsDoNotForceLoadUnloadedShard(t *testing.T) {
	ctx := context.Background()
	const class = "RepairEndpointsNoForceLoad"

	_, idx := testShard(t, ctx, class, asyncSchedulerOption(t, ctx))
	setShardReplicas(t, idx, "node1", "node2")

	const lazyName = "lazy-cold-shard-repair"
	sl, err := idx.initShard(ctx, lazyName, &models.Class{Class: class}, nil, false, false)
	require.NoError(t, err)
	lazy, ok := sl.(*LazyLoadShard)
	require.True(t, ok, "expected a *LazyLoadShard")
	require.False(t, lazy.isLoaded(), "precondition: shard must start unloaded")
	idx.shards.Store(lazyName, sl)

	t.Run("OverwriteObjects", func(t *testing.T) {
		_, err := idx.OverwriteObjects(ctx, lazyName, []*objects.VObject{{}})
		require.ErrorIs(t, err, errAsyncReplicationNotActive)
		require.False(t, lazy.isLoaded(), "OverwriteObjects must not force-load an unloaded shard")
	})

	t.Run("CompareDigests", func(t *testing.T) {
		_, err := idx.CompareDigests(ctx, lazyName, []routerTypes.RepairDigest{{ID: uuid.MustParse(string(uuidLow))}})
		require.ErrorIs(t, err, errAsyncReplicationNotActive)
		require.False(t, lazy.isLoaded(), "CompareDigests must not force-load an unloaded shard")
	})

	t.Run("DigestObjectsInRange", func(t *testing.T) {
		_, err := idx.DigestObjectsInRange(ctx, lazyName, uuidLow, uuidHigh, 10)
		require.ErrorIs(t, err, errAsyncReplicationNotActive)
		require.False(t, lazy.isLoaded(), "DigestObjectsInRange must not force-load an unloaded shard")
	})
}

// TestDBReconcileAsyncReplicationWalksEveryIndex verifies that
// DB.ReconcileAsyncReplication visits every index (not just the first) and
// applies the per-shard decision to each one's loaded shards after a runtime
// flip of the global ASYNC_REPLICATION_DISABLED flag.
func TestDBReconcileAsyncReplicationWalksEveryIndex(t *testing.T) {
	ctx := context.Background()
	logger, _ := test.NewNullLogger()

	disabled := configRuntime.NewDynamicValue(true)
	globalConfig := &entreplication.GlobalConfig{AsyncReplicationDisabled: disabled}

	idxASL, idxA := testShard(t, ctx, "ReconcileWalkA", func(i *Index) {
		i.Config.ReplicationFactor = 3
		i.globalreplicationConfig = globalConfig
		asyncSchedulerOption(t, ctx)(i)
	})
	idxBSL, idxB := testShard(t, ctx, "ReconcileWalkB", func(i *Index) {
		i.Config.ReplicationFactor = 3
		i.globalreplicationConfig = globalConfig
		asyncSchedulerOption(t, ctx)(i)
	})

	db := &DB{
		logger:  logger,
		indices: map[string]*Index{idxA.ID(): idxA, idxB.ID(): idxB},
	}

	disabled.SetValue(false)
	require.NoError(t, db.ReconcileAsyncReplication(ctx))

	for _, sl := range []ShardLike{idxASL, idxBSL} {
		s := concreteShard(t, sl)
		s.asyncReplicationRWMux.RLock()
		require.NotNil(t, s.hashtree, "every index must have its shards reconciled")
		s.asyncReplicationRWMux.RUnlock()
	}
}

// TestInitScanPopulatesHashtree validates that objects on disk when async
// replication is enabled are correctly registered in the hashtree by the init
// scan (ApplyToOnDiskObjectDigests), producing a non-zero root digest.
func TestInitScanPopulatesHashtree(t *testing.T) {
	ctx := context.Background()
	const class = "InitScanHashtreeTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)

	// Flush to disk so this exercises the on-disk pass of the init scan.
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
	}
	require.NoError(t, s.store.FlushMemtables(ctx))

	cfg := minAsyncReplicationConfig()
	require.NoError(t, s.enableAsyncReplication(context.Background(), cfg))
	awaitHashtreeInitialized(t, s)

	s.asyncReplicationRWMux.RLock()
	require.NotNil(t, s.hashtree)
	root := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()

	require.NotEqual(t, hashtree.Digest{}, root,
		"hashtree root must be non-zero: on-disk objects must have been registered by init scan")

	require.NoError(t, s.disableAsyncReplication(context.Background()))
}

// buildInitScanRoot applies layout to a fresh shard, enables async replication, and returns the init-scan root.
func buildInitScanRoot(t *testing.T, ctx context.Context, class string, layout func(sl ShardLike, s *Shard)) hashtree.Digest {
	t.Helper()
	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	layout(sl, s)
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	awaitHashtreeInitialized(t, s)
	s.asyncReplicationRWMux.RLock()
	root := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NoError(t, s.disableAsyncReplication(ctx))
	return root
}

// TestInitScanHashtreeConsistency asserts the init scan folds each live UUID once regardless of physical layout (identical logical state ⇒ identical root).
func TestInitScanHashtreeConsistency(t *testing.T) {
	ctx := context.Background()

	// empty tree has a non-zero Merkle root, so this is the "no live objects" oracle, not Digest{}
	emptyRoot := buildInitScanRoot(t, ctx, "InitScanEmpty", func(sl ShardLike, s *Shard) {})

	// testObjWithTime has nil Properties, so every re-put allocates a new docID (docID-changed straddle)
	t.Run("docIDChangedUpdateStraddlingMemtableAndDisk", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanDocIDChange", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDocIDChange", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDocIDChange", uuidMid, tsFarPast+1)))
		})
		want := buildInitScanRoot(t, ctx, "InitScanDocIDChangeRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDocIDChangeRef", uuidMid, tsFarPast+1)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got)
	})

	t.Run("memtableOnlyTombstoneOverDiskValue", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanTombstone", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanTombstone", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.DeleteObject(ctx, uuidMid, time.Now()))
		})
		require.Equal(t, emptyRoot, got, "deleted object must not be resurrected by the init scan")
	})

	t.Run("diskOnlyTombstoneWithLiveSibling", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanDiskTombstone", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDiskTombstone", uuidMid, tsFarPast)))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDiskTombstone", uuidHigh, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.DeleteObject(ctx, uuidMid, time.Now()))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		want := buildInitScanRoot(t, ctx, "InitScanDiskTombstoneRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDiskTombstoneRef", uuidHigh, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got, "flushed tombstone must not resurrect the deleted object")
		require.NotEqual(t, emptyRoot, got, "the live sibling must still be folded")
	})

	t.Run("multiUpdateChainAcrossLayers", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanChain", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanChain", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanChain", uuidMid, tsFarPast+1)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanChain", uuidMid, tsFarPast+2)))
		})
		want := buildInitScanRoot(t, ctx, "InitScanChainRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanChainRef", uuidMid, tsFarPast+2)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got)
	})

	t.Run("updateThenDeleteStraddling", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanUpdDel", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanUpdDel", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanUpdDel", uuidMid, tsFarPast+1)))
			require.NoError(t, sl.DeleteObject(ctx, uuidMid, time.Now()))
		})
		require.Equal(t, emptyRoot, got)
	})

	t.Run("deleteThenReinsertStraddling", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanDelReins", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDelReins", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.DeleteObject(ctx, uuidMid, time.Now()))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDelReins", uuidMid, tsFarPast+2)))
		})
		want := buildInitScanRoot(t, ctx, "InitScanDelReinsRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanDelReinsRef", uuidMid, tsFarPast+2)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got)
	})

	t.Run("memtableOnlyObjectNeverFlushed", func(t *testing.T) {
		got := buildInitScanRoot(t, ctx, "InitScanMemOnly", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanMemOnly", uuidMid, tsFarPast)))
		})
		want := buildInitScanRoot(t, ctx, "InitScanMemOnlyRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanMemOnlyRef", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got)
		require.NotEqual(t, emptyRoot, got, "memtable object must be folded")
	})

	t.Run("multipleUUIDsCollidingToOneLeaf", func(t *testing.T) {
		// uuidLow and uuidMid share leaf 0 at height 1 (top bit 0); mix layouts.
		got := buildInitScanRoot(t, ctx, "InitScanCollide", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanCollide", uuidLow, tsFarPast)))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanCollide", uuidMid, tsFarPast)))
			require.NoError(t, s.store.FlushMemtables(ctx))
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanCollide", uuidLow, tsFarPast+1)))
			require.NoError(t, sl.DeleteObject(ctx, uuidMid, time.Now()))
		})
		want := buildInitScanRoot(t, ctx, "InitScanCollideRef", func(sl ShardLike, s *Shard) {
			require.NoError(t, sl.PutObject(ctx, testObjWithTime("InitScanCollideRef", uuidLow, tsFarPast+1)))
			require.NoError(t, s.store.FlushMemtables(ctx))
		})
		require.Equal(t, want, got)
	})
}

// TestInitScanHashtreeConcurrentWrites (-race) checks a concurrently-built root matches a serial rebuild; writers start after enable() to avoid the out-of-scope enable-transition race.
func TestInitScanHashtreeConcurrentWrites(t *testing.T) {
	ctx := context.Background()
	const class = "InitScanConcurrent"
	const n = 240
	const writers = 4

	uuids := make([]strfmt.UUID, n)
	for i := range uuids {
		prefix := "0"
		if i%2 == 1 {
			prefix = "f" // spread across both leaves at height 1
		}
		uuids[i] = strfmt.UUID(fmt.Sprintf("%s0000000-0000-0000-0000-%012d", prefix, i+1))
	}

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)

	// seed: half on disk, half in memtable so the scan straddles layers
	for i := 0; i < n; i++ {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuids[i], tsFarPast)))
		if i == n/2 {
			require.NoError(t, s.store.FlushMemtables(ctx))
		}
	}

	// enable before writers so none observes hashtree==nil at the barrier
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))

	var wg sync.WaitGroup
	for w := 0; w < writers; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			for i := w; i < n; i += writers {
				switch i % 4 {
				case 0:
					assert.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuids[i], tsFarPast+5)))
				case 1:
					assert.NoError(t, sl.DeleteObject(ctx, uuids[i], time.Now()))
				case 2:
					assert.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuids[i], tsFarPast+5)))
					assert.NoError(t, s.store.FlushMemtables(ctx)) // force flushes concurrent with the scan
				}
			}
		}(w)
	}
	wg.Wait()
	awaitHashtreeInitialized(t, s)

	s.asyncReplicationRWMux.RLock()
	concurrentRoot := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()

	// clean serial rebuild over the frozen final state
	require.NoError(t, s.disableAsyncReplication(ctx))
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	awaitHashtreeInitialized(t, s)
	s.asyncReplicationRWMux.RLock()
	rebuiltRoot := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NoError(t, s.disableAsyncReplication(ctx))

	require.Equal(t, rebuiltRoot, concurrentRoot,
		"root built concurrently with writes must match a clean serial rebuild of the final state")
}

// ─── propagateObjects ─────────────────────────────────────────────────────────

// overwriteRecordingClient records every VObject batch sent via OverwriteObjects.
// All other methods delegate to FakeReplicationClient (no-ops / zero values).
type overwriteRecordingClient struct {
	FakeReplicationClient
	mu      sync.Mutex
	batches [][]*objects.VObject
}

func (c *overwriteRecordingClient) OverwriteObjects(_ context.Context, _, _, _ string, objs []*objects.VObject) ([]routerTypes.RepairResponse, error) {
	batch := make([]*objects.VObject, len(objs))
	copy(batch, objs)
	c.mu.Lock()
	c.batches = append(c.batches, batch)
	c.mu.Unlock()
	return nil, nil
}

// panicOverwriteClient panics on every OverwriteObjects call to simulate a
// worker-level panic inside propagateObjects.
type panicOverwriteClient struct{ FakeReplicationClient }

func (*panicOverwriteClient) OverwriteObjects(_ context.Context, _, _, _ string, _ []*objects.VObject) ([]routerTypes.RepairResponse, error) {
	panic("injected test panic")
}

// blockingOverwriteClient blocks until the context is cancelled, letting tests
// verify that propagateObjects terminates promptly on context cancellation.
type blockingOverwriteClient struct{ FakeReplicationClient }

func (*blockingOverwriteClient) OverwriteObjects(ctx context.Context, _, _, _ string, _ []*objects.VObject) ([]routerTypes.RepairResponse, error) {
	<-ctx.Done()
	return nil, ctx.Err()
}

// propagationTestConfig returns an AsyncReplicationConfig configured for
// propagateObjects unit tests with the given worker count and batch size.
func propagationTestConfig(concurrency, batchSize int) AsyncReplicationConfig {
	return AsyncReplicationConfig{
		propagationConcurrency: concurrency,
		propagationBatchSize:   batchSize,
	}
}

// TestPropagateObjects verifies three important properties of propagateObjects:
//
//  1. HappyPath – all objects are collected and forwarded to the replication
//     client without error.
//
//  2. WorkerPanicSurfacedAsError – a panic inside a worker goroutine is
//     surfaced as a non-nil error and the function returns without deadlocking.
//     Before the fix, the drain-loop defer would steal batches from healthy
//     workers, GoWrapper would silently swallow the panic, and propagateObjects
//     could return nil while objects were never propagated.
//
//  3. ContextCancellationNoDeadlock – when the parent context is cancelled
//     mid-flight, propagateObjects returns promptly; wg accounting via the
//     workerCtx drain path keeps channels and the WaitGroup consistent.
func TestPropagateObjects(t *testing.T) {
	ctx := context.Background()
	const class = "PropagateObjectsTest"
	const deadline = 5 * time.Second

	// awaitDone runs f in a goroutine and fails the test if it does not return
	// within deadline.  It is the deadlock detector for all sub-tests.
	awaitDone := func(t *testing.T, f func()) {
		t.Helper()
		done := make(chan struct{})
		go func() { f(); close(done) }()
		select {
		case <-done:
		case <-time.After(deadline):
			t.Fatal("propagateObjects did not return within the deadline (possible deadlock)")
		}
	}

	// insertObjects inserts n objects into the shard and returns their UUIDs.
	insertObjects := func(t *testing.T, sl ShardLike, n int) []strfmt.UUID {
		t.Helper()
		uuids := make([]strfmt.UUID, n)
		for i := range n {
			id := strfmt.UUID(fmt.Sprintf("00000000-0000-0000-0000-%012x", i+1))
			uuids[i] = id
			require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
		}
		return uuids
	}

	t.Run("HappyPath", func(t *testing.T) {
		client := &overwriteRecordingClient{}
		sl, _ := testShard(t, ctx, class, withReplicationClient(t, client))
		s := concreteShard(t, sl)

		const n = 6
		uuids := insertObjects(t, sl, n)
		cfg := propagationTestConfig(2, 2) // 2 workers, batches of 2 → 3 batches

		var err error
		awaitDone(t, func() {
			_, err = s.propagateObjects(ctx, cfg, "http://fake-host", uuids, nil)
		})

		require.NoError(t, err)
		client.mu.Lock()
		totalSent := 0
		for _, batch := range client.batches {
			totalSent += len(batch)
		}
		client.mu.Unlock()
		assert.Equal(t, n, totalSent, "all objects must have been forwarded to the replication client")
	})

	t.Run("WorkerPanicSurfacedAsError", func(t *testing.T) {
		sl, _ := testShard(t, ctx, class, withReplicationClient(t, &panicOverwriteClient{}))
		s := concreteShard(t, sl)

		uuids := insertObjects(t, sl, 6)
		cfg := propagationTestConfig(2, 2)

		var err error
		awaitDone(t, func() {
			_, err = s.propagateObjects(ctx, cfg, "http://fake-host", uuids, nil)
		})

		require.Error(t, err, "a worker panic must be surfaced as a non-nil error")
		assert.Contains(t, err.Error(), "panic")
	})

	t.Run("ContextCancellationNoDeadlock", func(t *testing.T) {
		sl, _ := testShard(t, ctx, class, withReplicationClient(t, &blockingOverwriteClient{}))
		s := concreteShard(t, sl)

		uuids := insertObjects(t, sl, 4)
		cfg := propagationTestConfig(2, 2)

		cancelCtx, cancel := context.WithCancel(ctx)
		go func() {
			time.Sleep(50 * time.Millisecond)
			cancel()
		}()

		awaitDone(t, func() {
			_, _ = s.propagateObjects(cancelCtx, cfg, "http://fake-host", uuids, nil)
		})
	})
}

// ─── Shutdown hashtree persistence ───────────────────────────────────────────

// htFilesInDir returns all .ht files found directly inside dir; a missing dir counts as empty.
func htFilesInDir(t *testing.T, dir string) []os.DirEntry {
	t.Helper()
	entries, err := os.ReadDir(dir)
	if os.IsNotExist(err) {
		return nil
	}
	require.NoError(t, err)
	var ht []os.DirEntry
	for _, e := range entries {
		if !e.IsDir() && filepath.Ext(e.Name()) == ".ht" {
			ht = append(ht, e)
		}
	}
	return ht
}

// TestMayStopAsyncReplicationDumpsHashtreeOnSuccess verifies the happy path:
// mayStopAsyncReplication writes a .ht file that can be loaded on the next startup.
func TestMayStopAsyncReplicationDumpsHashtreeOnSuccess(t *testing.T) {
	ctx := context.Background()
	_, s := newSeededAsyncShard(t, ctx, "DumpHashtreeOnSuccessTest")

	htPath := s.pathHashTree()

	stopAsyncAndDump(t, s)

	htFiles := htFilesInDir(t, htPath)
	require.Len(t, htFiles, 1,
		".ht file must be written when hashtreeFullyInitialized is true")

	// The persisted root must be non-zero: on-disk objects were registered by
	// the init scan.
	f, err := os.Open(filepath.Join(htPath, htFiles[0].Name()))
	require.NoError(t, err)
	defer f.Close()
	ht, err := hashtree.DeserializeHashTree(bufio.NewReader(f))
	require.NoError(t, err)
	require.NotEqual(t, hashtree.Digest{}, ht.Root(),
		"persisted hashtree root must be non-zero: on-disk objects must have been registered")
}

// ─── Fix: disk I/O outside the write lock ────────────────────────────────────
//
// The following tests cover the fix that moved tryLoadHashtreeFromDisk outside
// the asyncReplicationRWMux write lock in enableAsyncReplication (and the
// shard startup path in initNonVector). Before the fix, the write lock was
// acquired at the top of enableAsyncReplication and held for the entire
// tryLoadHashtreeFromDisk call — blocking all concurrent RLock callers for the
// full duration of disk I/O (ReadDir, OpenFile, Read, Remove, Fsync).

// TestEnableAsyncReplication_LoadsHashtreeFromDisk verifies the new disk-load
// code path: when a .ht file is present, enableAsyncReplication loads it
// and sets hashtreeFullyInitialized = true without waiting for a background
// init scan. It also verifies the file is consumed (deleted) on load.
func TestEnableAsyncReplication_LoadsHashtreeFromDisk(t *testing.T) {
	ctx := context.Background()
	const class = "LoadHashtreeFromDiskTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	// First enable: builds hashtree from scratch via background init scan.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	// Persist some objects so the hashtree has a non-trivial root that we can
	// compare after re-enable.
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
	}
	require.NoError(t, s.store.FlushMemtables(ctx))

	// Capture root before disable so we can verify it survives the round-trip.
	s.asyncReplicationRWMux.RLock()
	rootBeforeDisable := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()

	htPath := s.pathHashTree()

	// mayStopAsyncReplication is the legitimate .ht producer (shutdown path);
	// disableAsyncReplication is the runtime path and does not dump.
	stopAsyncAndDump(t, s)
	require.Len(t, htFilesInDir(t, htPath), 1,
		"pre-condition: mayStopAsyncReplication must have written a .ht file")

	// Re-enable: tryLoadHashtreeFromDisk should load the .ht file.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))

	// hashtreeFullyInitialized is set synchronously inside initAsyncReplication
	// when a cached tree is found (before enableAsyncReplication returns), so
	// it must be true by the time enableAsyncReplication returns — no polling.
	s.asyncReplicationRWMux.RLock()
	require.True(t, s.hashtreeFullyInitialized,
		"hashtree must be fully initialized from disk cache, not via a background scan")
	s.asyncReplicationRWMux.RUnlock()

	// Root must match what was saved: the persisted tree must have been loaded.
	s.asyncReplicationRWMux.RLock()
	rootAfterReEnable := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.Equal(t, rootBeforeDisable, rootAfterReEnable,
		"hashtree root must survive the disable/re-enable round-trip via disk")

	// tryLoadHashtreeFromDisk must delete the .ht file after loading it.
	require.Empty(t, htFilesInDir(t, htPath),
		".ht file must be consumed by enableAsyncReplication on successful load")

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestEnableAsyncReplicationRescansAfterRuntimeDisable pins the silent
// replica-inconsistency bug from PR #11214: disableAsyncReplication is the
// runtime path (shard stays live and serves writes), so any hashtree it
// persists goes stale immediately. Before the fix it dumped a .ht and
// enableAsyncReplication loaded that snapshot verbatim — CollectShardDifferences
// then returned ErrNoDiffFound forever and async repair silently abandoned
// the disabled-window divergence. (mayStopAsyncReplication remains the only
// safe .ht producer; covered by TestMayStopAsyncReplicationDumpsHashtreeOnSuccess.)
//
// Falsifiable assertion: after enable → disable → write → re-enable, the
// hashtree root must differ from its pre-disable value. With the bug the
// cached .ht restores the pre-write root and the assertion fires; with the
// fix re-enable rebuilds from a full scan and the new object shifts the root.
func TestEnableAsyncReplicationRescansAfterRuntimeDisable(t *testing.T) {
	ctx := context.Background()
	const class = "AsyncRescanAfterRuntimeDisable"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	// Seed: three flushed objects so the first init has non-trivial state.
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
	}
	require.NoError(t, s.store.FlushMemtables(ctx))

	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	s.asyncReplicationRWMux.RLock()
	rootBeforeDisable := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NotEqual(t, hashtree.Digest{}, rootBeforeDisable,
		"sanity: seeded hashtree must have a non-zero root")

	// Runtime kill-switch flipped to disabled. Shard stays live.
	require.NoError(t, s.disableAsyncReplication(ctx))

	// disableAsyncReplication must not leave a .ht behind — the shard will
	// serve writes from here on, so any snapshot is stale.
	require.Empty(t, htFilesInDir(t, s.pathHashTree()),
		"runtime disableAsyncReplication must not persist the hashtree; only "+
			"mayStopAsyncReplication (shutdown) may write a .ht")

	// Write a fourth object while async replication is disabled. With the
	// bug, this write is invisible to any future hashtree comparison.
	const uuidWhileDisabled = strfmt.UUID("44444444-4444-4444-4444-444444444444")
	require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidWhileDisabled, tsFarPast)))
	require.NoError(t, s.store.FlushMemtables(ctx))

	// Flip the kill-switch back to false. The shard must rebuild the hashtree
	// from the current object store (a full scan) — not trust a leftover .ht.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	s.asyncReplicationRWMux.RLock()
	rootAfterReEnable := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()

	require.NotEqual(t, rootBeforeDisable, rootAfterReEnable,
		"hashtree must reflect the disabled-window write; if it does not, a "+
			"stale snapshot was trusted and divergence is invisible to repair")

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestShardLoadDiscardsStaleHashtreeWhenAsyncDisabled pins the second arm of
// the stale-cache bug: a node booted with ASYNC_REPLICATION_DISABLED=true
// after a previous async-enabled shutdown must not let the leftover .ht
// survive into a later runtime re-enable — the shard will serve writes while
// async is off, invalidating the snapshot. shard_init_lsm.go discards the
// .ht in this branch; this test exercises the helper it relies on.
func TestShardLoadDiscardsStaleHashtreeWhenAsyncDisabled(t *testing.T) {
	ctx := context.Background()
	const class = "DiscardStaleHashtreeOnDisabledLoad"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	// Produce a legitimate .ht the way a graceful shutdown would: enable async,
	// let the init scan complete, then mayStopAsyncReplication serialises the
	// in-memory tree to disk.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	stopAsyncAndDump(t, s)
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1,
		"pre-condition: mayStopAsyncReplication must have produced a .ht")

	// Simulate the shard-init path running with async replication disabled,
	// i.e. the else-branch of shard_init_lsm.go. The .ht must be discarded
	// so a later runtime enable cannot load a stale snapshot.
	require.NoError(t, s.removePersistedHashtree())

	require.Empty(t, htFilesInDir(t, s.pathHashTree()),
		"shard-load with async replication disabled must discard the "+
			"persisted .ht; otherwise a later runtime enable would load a "+
			"snapshot that the shard's disabled-window writes have invalidated")
}

// TestEnableAsyncReplication_ConcurrentCallsAreSafe verifies that multiple
// goroutines racing to call enableAsyncReplication simultaneously do not cause
// data races, panics, or double-initialisation. Run with -race.
func TestEnableAsyncReplication_ConcurrentCallsAreSafe(t *testing.T) {
	ctx := context.Background()
	const class = "ConcurrentEnableTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	const numGoroutines = 10
	var wg sync.WaitGroup
	wg.Add(numGoroutines)

	// Release all goroutines as close to simultaneously as possible.
	ready := make(chan struct{})
	for range numGoroutines {
		go func() {
			defer wg.Done()
			<-ready
			_ = s.enableAsyncReplication(ctx, cfg)
		}()
	}
	close(ready)
	wg.Wait()

	// Exactly one initialisation must have taken place; the hashtree must not
	// be nil regardless of which goroutine "won" the write lock.
	s.asyncReplicationRWMux.RLock()
	require.NotNil(t, s.hashtree,
		"hashtree must be initialised after concurrent enableAsyncReplication calls")
	s.asyncReplicationRWMux.RUnlock()

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestEnableAsyncReplication_DiskIONotBlockedByRLock is the regression test for
// the write-lock starvation bug described in the code review.
//
// Before the fix, enableAsyncReplication acquired asyncReplicationRWMux.Lock()
// at the very top, then called tryLoadHashtreeFromDisk inside the critical
// section.  Any concurrent RLock holder (e.g. a hashbeat reader or a commit
// handler) was therefore blocked for the full disk I/O duration — observed as
// 1–3 minute goroutine blocks in production profiles.
//
// After the fix, tryLoadHashtreeFromDisk runs BEFORE the write lock is acquired.
// This test verifies the invariant directly:
//
//  1. A .ht file is planted by running a full enable → disable cycle.
//  2. asyncReplicationRWMux.RLock() is held in a goroutine, preventing any
//     write lock from being acquired.
//  3. enableAsyncReplication is started in a second goroutine.
//  4. While the RLock is still held we assert that the .ht file is consumed.
//     This can only happen if tryLoadHashtreeFromDisk ran without the write
//     lock — proving disk I/O is outside the critical section.
//
// With the old code step 4 would time out because the goroutine in step 3
// would immediately block on Lock() and never reach tryLoadHashtreeFromDisk.
func TestEnableAsyncReplication_DiskIONotBlockedByRLock(t *testing.T) {
	ctx := context.Background()
	const class = "DiskIONotBlockedTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	// Enable and wait for a full init so that mayStopAsyncReplication will
	// produce a .ht file we can later load.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	htPath := s.pathHashTree()

	// mayStopAsyncReplication is the legitimate .ht producer; disable is the
	// runtime path and does not dump.
	stopAsyncAndDump(t, s)
	require.Len(t, htFilesInDir(t, htPath), 1,
		"pre-condition: one .ht file must exist before the RLock test")

	// Hold asyncReplicationRWMux.RLock() — this prevents any write lock from
	// being acquired.  We release it only after the file-consumed check passes.
	rLockHeld := make(chan struct{})
	rLockRelease := make(chan struct{})
	var releaseOnce sync.Once
	release := func() { releaseOnce.Do(func() { close(rLockRelease) }) }
	t.Cleanup(release) // safety: always release on test teardown

	go func() {
		s.asyncReplicationRWMux.RLock()
		close(rLockHeld)
		<-rLockRelease
		s.asyncReplicationRWMux.RUnlock()
	}()
	<-rLockHeld // wait until RLock is held before starting enableAsyncReplication

	// Start enableAsyncReplication; it must be able to run tryLoadHashtreeFromDisk
	// (and consume the .ht file) even while our goroutine holds asyncReplicationRWMux.RLock().
	enableErr := make(chan error, 1)
	go func() {
		enableErr <- s.enableAsyncReplication(ctx, cfg)
	}()

	// Assert the .ht file is consumed while RLock is still held.
	// With old code (Lock() before disk I/O): the enableAsyncReplication goroutine
	// blocks immediately on Lock() → tryLoadHashtreeFromDisk never runs → file not
	// consumed → this assertion times out.
	// With new code (disk I/O before Lock()): tryLoadHashtreeFromDisk runs freely →
	// file consumed → assertion passes.
	require.Eventually(t, func() bool {
		return len(htFilesInDir(t, htPath)) == 0
	}, 5*time.Second, 5*time.Millisecond,
		"tryLoadHashtreeFromDisk must run while RLock is held: disk I/O must be outside the write lock")

	// Release the RLock so the write lock can be acquired and init can complete.
	release()

	require.NoError(t, <-enableErr)

	// Hashtree must be loaded from the cached file (fully initialized immediately).
	s.asyncReplicationRWMux.RLock()
	require.True(t, s.hashtreeFullyInitialized,
		"hashtree must be fully initialized from the cached .ht file")
	s.asyncReplicationRWMux.RUnlock()

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestConcurrentEnableDisable verifies that rapid concurrent enable calls do
// not deadlock or panic. Each goroutine may win or lose the write-lock race;
// the important invariant is that the shard settles to a consistent state
// (hashtree allocated or nil) without any goroutine leaking.
func TestConcurrentEnableDisable(t *testing.T) {
	ctx := context.Background()
	const class = "ConcEnableDisable"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	cfg := minAsyncReplicationConfig()

	var wg sync.WaitGroup
	for range 3 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = s.enableAsyncReplication(ctx, cfg)
		}()
	}
	wg.Wait()

	_ = s.disableAsyncReplication(ctx)
}

// TestMergeWritesNoDeadlockUnderAsyncReplicationFlapping guards against the recursive-RLock deadlock where the merge paths called waitForMinimalHashTreeInitialization while holding asyncReplicationRWMux.RLock(); pre-fix it hangs (watchdog fires), post-fix it completes. Run with -race.
func TestMergeWritesNoDeadlockUnderAsyncReplicationFlapping(t *testing.T) {
	const (
		writers    = 8
		iterations = 150
		watchdog   = 30 * time.Second
	)

	ids := []strfmt.UUID{uuidLow, uuidMid, uuidHigh}

	tests := []struct {
		name  string
		write func(s *Shard, id strfmt.UUID, updateTime int64) error
	}{
		{
			// Exercises mergeObjectInStorage via the public MergeObject entry point.
			name: "MergeObject",
			write: func(s *Shard, id strfmt.UUID, updateTime int64) error {
				return s.MergeObject(context.Background(), objects.MergeDocument{
					Class:      s.class.Class,
					ID:         id,
					UpdateTime: updateTime,
				})
			},
		},
		{
			// Exercises mutableMergeObjectLSM directly (the AddReferencesBatch path).
			name: "mutableMergeObjectLSM",
			write: func(s *Shard, id strfmt.UUID, updateTime int64) error {
				idBytes, err := bytesFromUUID(id)
				if err != nil {
					return err
				}
				_, err = s.mutableMergeObjectLSM(context.Background(), objects.MergeDocument{
					Class:      s.class.Class,
					ID:         id,
					UpdateTime: updateTime,
				}, idBytes)
				return err
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx := context.Background()
			sl, _ := testShard(t, ctx, "MergeDeadlock"+tc.name, withAsyncScheduler(t))
			s := concreteShard(t, sl)
			t.Cleanup(func() { _ = sl.Shutdown(ctx) })

			for _, id := range ids {
				require.NoError(t, sl.PutObject(ctx, testObjWithTime(s.class.Class, id, tsFarPast)))
			}
			require.NoError(t, s.store.FlushMemtables(ctx))

			cfg := minAsyncReplicationConfig()
			require.NoError(t, s.enableAsyncReplication(ctx, cfg))
			awaitHashtreeInitialized(t, s)

			var (
				clock      atomic.Int64
				writeErrs  atomic.Int64
				toggleErrs atomic.Int64
				wg         sync.WaitGroup
			)
			clock.Store(tsFarPast)

			// Writers: hammer the merge path.
			for w := range writers {
				wg.Add(1)
				go func(w int) {
					defer wg.Done()
					for range iterations {
						id := ids[w%len(ids)]
						if err := tc.write(s, id, clock.Add(1)); err != nil {
							writeErrs.Add(1)
						}
					}
				}(w)
			}

			// Toggler: flap async replication so a write-lock acquisition is frequently pending — the precondition for the deadlock.
			wg.Add(1)
			go func() {
				defer wg.Done()
				for range iterations {
					if err := s.disableAsyncReplication(ctx); err != nil {
						toggleErrs.Add(1)
					}
					if err := s.enableAsyncReplication(ctx, cfg); err != nil {
						toggleErrs.Add(1)
					}
				}
			}()

			done := make(chan struct{})
			go func() { wg.Wait(); close(done) }()

			select {
			case <-done:
			case <-time.After(watchdog):
				t.Fatalf("merge writes deadlocked under async-replication flapping "+
					"(recursive RLock in %s path): workload did not finish within %s", tc.name, watchdog)
			}

			// Write/toggle errors during flapping are benign (write lands while momentarily disabled); log, do not fail.
			if n := writeErrs.Load(); n > 0 {
				t.Logf("%d/%d merge writes returned a non-fatal error during flapping", n, writers*iterations)
			}
			if n := toggleErrs.Load(); n > 0 {
				t.Logf("%d enable/disable toggles returned a non-fatal error during flapping", n)
			}

			require.NoError(t, s.disableAsyncReplication(ctx))
		})
	}
}

// TestMergeUnblocksWhenInitBailsBeforeHashtreeScan deterministically drives the
// deadlock that TestMergeWritesNoDeadlockUnderAsyncReplicationFlapping only hits
// under load: holding the single init slot parks the init goroutine before
// initHashtree, then disableAsyncReplication cancels its context so it exits
// without ever running the scan that closes minimalHashtreeInitializationCh.
// Without the fix the channel leaks and the in-flight merge blocks forever.
func TestMergeUnblocksWhenInitBailsBeforeHashtreeScan(t *testing.T) {
	ctx := context.Background()

	// Scheduler with a single hashtree-init slot so the test can starve the scan.
	logger, _ := test.NewNullLogger()
	sched, err := NewAsyncReplicationScheduler(context.Background(), entreplication.GlobalConfig{
		AsyncReplicationSchedulerWorkers:        configRuntime.NewDynamicValue(1),
		AsyncReplicationHashtreeInitConcurrency: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:                configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)
	t.Cleanup(sched.Close)

	sl, _ := testShard(t, ctx, "MergeUnblocksInitBail", func(idx *Index) {
		idx.asyncReplicationScheduler = sched
	})
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(s.class.Class, id, tsFarPast)))
	}
	require.NoError(t, s.store.FlushMemtables(ctx))

	// Occupy the only init slot so the shard's init goroutine blocks in
	// acquireHashtreeInitSlot before it reaches initHashtree.
	require.NoError(t, sched.hashtreeInitSem.Acquire(context.Background(), 1))
	defer sched.hashtreeInitSem.Release(1)

	// Spawns the init goroutine, which parks on the held slot with the hashtree
	// set but not yet initialized.
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))

	// The merge captures the open init channel and blocks in
	// waitForMinimalHashTreeInitialization.
	mergeDone := make(chan error, 1)
	go func() {
		mergeDone <- s.MergeObject(ctx, objects.MergeDocument{
			Class:      s.class.Class,
			ID:         uuidLow,
			UpdateTime: tsFarPast + 1,
		})
	}()

	// Precondition: the merge must actually be parked while init is stalled.
	select {
	case <-mergeDone:
		t.Fatal("merge completed while hashtree init was stalled — precondition not met")
	case <-time.After(200 * time.Millisecond):
	}

	// Disable cancels the shard's async context; the init goroutine returns from
	// acquireHashtreeInitSlot and exits without running initHashtree.
	require.NoError(t, s.disableAsyncReplication(ctx))

	select {
	case <-mergeDone:
	case <-time.After(10 * time.Second):
		t.Fatal("merge did not unblock after async replication was disabled — init channel leaked")
	}
}

// TestDisableRacingInitLeavesNoRegistration is a targeted test for the TOCTOU
// window between the init goroutine's WLock release and Register() returning.
//
// Without the guard the dangerous sequence is:
//  1. Init goroutine: WLock → hashtree≠nil → WUnlock
//  2. disableAsyncReplication: WLock → hashtree=nil → WUnlock →
//     Deregister (no-op: shard not yet in the scheduler's registry)
//  3. Init goroutine: Register(s) → shard added to scheduler registry
//  4. BUG: hashtree is nil but shard is permanently registered
//
// The TOCTOU guard closes this by RLocking after Register returns and calling
// Deregister if hashtree is nil. After asyncRepWg.Wait() serialises the
// goroutine's completion, no shard must remain in the registry.
//
// The test uses the cached-tree path (pre-written .ht file loaded on each
// enable) so the init goroutine is as short as possible (no disk scan),
// maximising the probability of the race window being exercised. Run with
// -race to catch any synchronisation gap the guard does not cover.
func TestDisableRacingInitLeavesNoRegistration(t *testing.T) {
	ctx := context.Background()
	const class = "DisableRacesInit"
	const iterations = 50

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	sched := s.index.asyncReplicationScheduler

	cfg := minAsyncReplicationConfig()

	// Bootstrap: enable → full init scan → mayStop persists a .ht. The first
	// loop iteration's enable hits the cached-tree path (short goroutine =
	// lock-check + Register + TOCTOU guard); iterations 2..N go through
	// disableAsyncReplication, which does not dump, so they exercise the same
	// TOCTOU race against the longer full-scan path. Both are worth covering.
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	stopAsyncAndDump(t, s)
	s.asyncRepWg.Wait()

	// awaitWg blocks until asyncRepWg reaches zero or the deadline fires. It
	// covers both the init goroutine and any hashbeat cycle dispatched between
	// Register and Deregister.
	awaitWg := func() {
		t.Helper()
		done := make(chan struct{})
		go func() { s.asyncRepWg.Wait(); close(done) }()
		select {
		case <-done:
		case <-time.After(10 * time.Second):
			t.Fatal("asyncRepWg did not drain within timeout — goroutine leak or deadlock")
		}
	}

	for range iterations {
		// Call enable then immediately disable. Depending on goroutine scheduling,
		// one of three outcomes is possible:
		//   (A) Init goroutine's first WLock check sees nil → returns early (no register).
		//   (B) Goroutine registers; TOCTOU guard fires → self-deregisters.
		//   (C) Goroutine registers; disableAsyncReplication's Deregister removes it.
		// In every case the invariant must hold: shard absent from registry after Wait().
		require.NoError(t, s.enableAsyncReplication(ctx, cfg))
		require.NoError(t, s.disableAsyncReplication(ctx))

		// Serialise: wait until the init goroutine (and any dispatched cycle) has
		// fully exited, including the TOCTOU guard's Deregister call if it fired.
		awaitWg()

		sched.mu.Lock()
		_, inRegistry := sched.entries[s]
		sched.mu.Unlock()
		require.False(t, inRegistry,
			"shard must not remain registered after disableAsyncReplication raced the init goroutine")
	}
}

// TestEffectiveClampsZeroFields verifies that Effective() clamps integer fields
// that have a minimum of 1 to that minimum when a zero-value config is passed.
// This prevents zero-value AsyncReplicationConfig (e.g. from direct struct
// construction) from reaching propagateObjects with invalid concurrency.
func TestEffectiveClampsZeroFields(t *testing.T) {
	// Zero-value config: all numeric fields are 0.
	cfg := AsyncReplicationConfig{}
	result := cfg.Effective(entreplication.GlobalConfig{})

	assert.Equal(t, minDiffBatchSize, result.diffBatchSize,
		"diffBatchSize must be clamped to minDiffBatchSize")
	assert.Equal(t, minPropagationLimit, result.propagationLimit,
		"propagationLimit must be clamped to minPropagationLimit")
	assert.Equal(t, minPropagationConcurrency, result.propagationConcurrency,
		"propagationConcurrency must be clamped to minPropagationConcurrency")
	assert.Equal(t, minPropagationBatchSize, result.propagationBatchSize,
		"propagationBatchSize must be clamped to minPropagationBatchSize")
}

// TestMayStopAsyncReplicationWaitsForInflightCycle verifies that
// mayStopAsyncReplication does not return while a hashbeat cycle is in-flight.
//
// This is the regression test for the asyncRepWg.Wait() fix: without it,
// mayStopAsyncReplication returns as soon as the scheduler confirms deregistration
// (Deregister ack), leaving an in-flight cycle still running against shard
// resources (store cursors, hashtree) that are about to be torn down.
//
// The test simulates a running cycle by calling asyncRepWg.Add(1) directly.
// With the fix, mayStopAsyncReplication blocks on asyncRepWg.Wait() until Done()
// is called. Without the fix, it returns immediately after Deregister, and the
// timed assertion at the "still held" check fails.
func TestMayStopAsyncReplicationWaitsForInflightCycle(t *testing.T) {
	ctx := context.Background()
	const class = "MayStopWaitsForInflightTest"
	// blockDuration gives the goroutine time to cancel asyncRepCtx, call
	// Deregister, and reach asyncRepWg.Wait(). 100 ms is generous for a few
	// lock operations; if the machine is pathologically slow, the test may
	// produce a false negative (not a false positive).
	const blockDuration = 100 * time.Millisecond

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))

	// Hold asyncRepWg to simulate an in-flight hashbeat cycle.
	s.asyncRepWg.Add(1)

	stopDone := make(chan struct{})
	go func() {
		s.mayStopAsyncReplication(true)
		close(stopDone)
	}()

	// After blockDuration, mayStopAsyncReplication must still be blocked.
	time.Sleep(blockDuration)
	select {
	case <-stopDone:
		t.Fatal("mayStopAsyncReplication returned while asyncRepWg was still held: " +
			"asyncRepWg.Wait() is missing or ineffective")
	default:
		// Correctly blocked — release the simulated cycle below.
	}

	// Releasing the WG must unblock mayStopAsyncReplication promptly.
	s.asyncRepWg.Done()
	select {
	case <-stopDone:
		// Correctly unblocked after the in-flight cycle finished.
	case <-time.After(5 * time.Second):
		t.Fatal("mayStopAsyncReplication did not complete within 5 s after asyncRepWg.Done()")
	}
}

// TestLoadHashtreeReclaimsTmpFile: a .ht.tmp is never loaded and is swept, not accumulated.
func TestLoadHashtreeReclaimsTmpFile(t *testing.T) {
	ctx := context.Background()
	const class = "LoadHashtreeReclaimsTmpTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()

	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	stopAsyncAndDump(t, s)

	htPath := s.pathHashTree()

	htFiles := htFilesInDir(t, htPath)
	require.Len(t, htFiles, 1, "pre-condition: exactly one .ht file must exist after mayStop")

	htFile := filepath.Join(htPath, htFiles[0].Name())
	tmpPath := htFile + ".tmp"
	require.NoError(t, os.Rename(htFile, tmpPath))

	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	_, statErr := os.Stat(tmpPath)
	assert.True(t, os.IsNotExist(statErr), ".ht.tmp must be reclaimed")
	assert.Empty(t, htFilesInDir(t, htPath), "tmp-only dir must rescan, loading no .ht")

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestMayStopAsyncReplicationSkipsDumpWhenNotPersisting: persistHashtree=false writes no .ht.
func TestMayStopAsyncReplicationSkipsDumpWhenNotPersisting(t *testing.T) {
	ctx := context.Background()
	_, s := newSeededAsyncShard(t, ctx, "MayStopSkipsDumpTest")

	s.mayStopAsyncReplication(false)
	require.Empty(t, htFilesInDir(t, s.pathHashTree()),
		"persistHashtree=false must not write a .ht")
}

// TestHaltForTransferOffloadDoesNotPersistHashtree: offload halt of a live shard writes no .ht.
func TestHaltForTransferOffloadDoesNotPersistHashtree(t *testing.T) {
	ctx := context.Background()
	_, s := newSeededAsyncShard(t, ctx, "HaltOffloadNoHashtreeTest")

	require.NoError(t, s.HaltForTransfer(ctx, true, 0))
	require.Empty(t, htFilesInDir(t, s.pathHashTree()),
		"offload halt must not persist a hashtree for a live shard")

	require.NoError(t, s.resumeMaintenanceCycles(ctx))

	enableAndAwaitAsync(t, ctx, s)
	s.asyncReplicationRWMux.RLock()
	root := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NotEqual(t, hashtree.Digest{}, root,
		"re-enable after offload must rescan, producing a non-zero root")

	require.NoError(t, s.disableAsyncReplication(ctx))
}

// TestLoadHashtreeRejectsCorruptNewestFile: a corrupt newest .ht rescans, never loading an older one.
// plantableSnapshot enables async replication, serializes the live tree, disables again, and returns the payload, its height, and the recreated snapshot dir.
func plantableSnapshot(t *testing.T, ctx context.Context, s *Shard) (payload []byte, height int, dir string) {
	t.Helper()
	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	awaitHashtreeInitialized(t, s)

	s.asyncReplicationRWMux.RLock()
	var buf bytes.Buffer
	_, serErr := s.hashtree.Serialize(&buf)
	height = s.hashtree.Height()
	s.asyncReplicationRWMux.RUnlock()
	require.NoError(t, serErr)

	require.NoError(t, s.disableAsyncReplication(ctx))

	dir = s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	return buf.Bytes(), height, dir
}

func TestLoadHashtreeRejectsCorruptNewestFile(t *testing.T) {
	ctx := context.Background()
	const class = "LoadHashtreeRejectsCorruptTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	validPayload, height, dir := plantableSnapshot(t, ctx, s)
	// Larger hex suffix (nanosecond timestamp) is the newest load candidate.
	olderValid := filepath.Join(dir, "hashtree-0000000000000001.ht")
	newerCorrupt := filepath.Join(dir, "hashtree-00000000000000ff.ht")
	require.NoError(t, os.WriteFile(olderValid, validPayload, 0o600))
	require.NoError(t, os.WriteFile(newerCorrupt, []byte("not a valid hashtree payload"), 0o600))

	loaded, err := s.tryLoadHashtreeFromDisk(height)
	require.NoError(t, err)
	require.Nil(t, loaded, "corrupt newest .ht must rescan, not fall back to older")
	require.Empty(t, htFilesInDir(t, dir), "both files must be consumed")
}

// TestLoadHashtreeRemoveFailure: an unremovable .ht fails the load (it would be trusted later); an unremovable .tmp only degrades to a rescan.
func TestLoadHashtreeRemoveFailure(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("requires non-root to make the hashtree directory read-only")
	}

	tests := []struct {
		name    string
		class   string
		plant   string
		wantErr bool
	}{
		{name: "stray tmp degrades to rescan", class: "LoadHashtreeRemoveFatalTmpTest", plant: "hashtree-0000000000000001.ht.tmp", wantErr: false},
		{name: "corrupt newest ht is fatal", class: "LoadHashtreeRemoveFatalCorruptTest", plant: "hashtree-0000000000000001.ht", wantErr: true},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ctx := context.Background()
			_, s := newAsyncTestShard(t, ctx, tc.class)

			dir := s.pathHashTree()
			require.NoError(t, os.MkdirAll(dir, os.ModePerm))
			require.NoError(t, os.WriteFile(filepath.Join(dir, tc.plant), []byte("not a valid hashtree payload"), 0o600))

			require.NoError(t, os.Chmod(dir, 0o555))
			t.Cleanup(func() { _ = os.Chmod(dir, 0o755) })

			loaded, err := s.tryLoadHashtreeFromDisk(16)
			if tc.wantErr {
				require.Error(t, err, "an unremovable %s must fail the load", tc.plant)
				return
			}
			require.NoError(t, err, "an unremovable %s must degrade to a rescan", tc.plant)
			require.Nil(t, loaded)
		})
	}
}

// TestLoadHashtreeDemotesUndeletableStaleSnapshot: an undeletable stale .ht is demoted to a stray .tmp instead of failing the load.
func TestLoadHashtreeDemotesUndeletableStaleSnapshot(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "LoadHashtreeQuarantineTest")

	validPayload, height, dir := plantableSnapshot(t, ctx, s)
	stale := filepath.Join(dir, "hashtree-0000000000000001.ht")
	newest := filepath.Join(dir, "hashtree-00000000000000ff.ht")
	require.NoError(t, os.WriteFile(stale, []byte("junk"), 0o600))
	require.NoError(t, os.WriteFile(newest, validPayload, 0o600))

	prev := removeHashtreeFile
	removeHashtreeFile = func(name string) error {
		if name == stale {
			return os.ErrPermission
		}
		return os.Remove(name)
	}
	t.Cleanup(func() { removeHashtreeFile = prev })

	loaded, err := s.tryLoadHashtreeFromDisk(height)
	require.NoError(t, err)
	require.NotNil(t, loaded, "the trusted newest snapshot must still load")
	require.Empty(t, htFilesInDir(t, dir), "no trust-loadable .ht may remain")
	_, statErr := os.Stat(stale + ".tmp")
	require.NoError(t, statErr, "the undeletable stale file must be demoted to a stray .tmp")

	// The demoted .tmp is re-swept on the next load: reclaimed once removable.
	prevSeam := removeHashtreeFile
	removeHashtreeFile = os.Remove
	t.Cleanup(func() { removeHashtreeFile = prevSeam })
	_, err = s.tryLoadHashtreeFromDisk(height)
	require.NoError(t, err)
	_, statErr = os.Stat(stale + ".tmp")
	require.True(t, os.IsNotExist(statErr), "the demoted file must be reclaimed once removable")
}

// TestLoadHashtreeDemotesUndeletableCorruptNewest: a corrupt newest .ht that cannot be removed demotes to .tmp instead of failing shard init forever.
func TestLoadHashtreeDemotesUndeletableCorruptNewest(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "LoadHashtreeCorruptDemoteTest")

	_, height, dir := plantableSnapshot(t, ctx, s)
	corrupt := filepath.Join(dir, "hashtree-00000000000000ff.ht")
	require.NoError(t, os.WriteFile(corrupt, []byte("junk"), 0o600))

	prev := removeHashtreeFile
	removeHashtreeFile = func(string) error { return os.ErrPermission }
	t.Cleanup(func() { removeHashtreeFile = prev })

	loaded, err := s.tryLoadHashtreeFromDisk(height)
	require.NoError(t, err, "an un-removable corrupt newest .ht must demote, not fail the load")
	require.Nil(t, loaded)
	require.Empty(t, htFilesInDir(t, dir))
	_, statErr := os.Stat(corrupt + ".tmp")
	require.NoError(t, statErr, "the corrupt newest must be demoted to a stray .tmp")
}

// TestLoadHashtreeDemotesUndeletableConsumedSnapshot: an undeletable consumed newest .ht demotes to .tmp and the loaded tree stays trusted.
func TestLoadHashtreeDemotesUndeletableConsumedSnapshot(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "LoadHashtreeConsumedDemoteTest")

	validPayload, height, dir := plantableSnapshot(t, ctx, s)
	newest := filepath.Join(dir, "hashtree-00000000000000ff.ht")
	require.NoError(t, os.WriteFile(newest, validPayload, 0o600))

	prev := removeHashtreeFile
	removeHashtreeFile = func(string) error { return os.ErrPermission }
	t.Cleanup(func() { removeHashtreeFile = prev })

	loaded, err := s.tryLoadHashtreeFromDisk(height)
	require.NoError(t, err, "an undeletable consumed snapshot must demote, not fail the load")
	require.NotNil(t, loaded, "the consumed tree is still trustworthy")
	require.Empty(t, htFilesInDir(t, dir))
	_, statErr := os.Stat(newest + ".tmp")
	require.NoError(t, statErr, "the consumed file must be demoted so it cannot be re-trusted")
}

// TestLoadHashtreeDemoteRenameFailureIsFatal: when neither delete nor demote can neutralize a stale .ht, the load must keep failing.
func TestLoadHashtreeDemoteRenameFailureIsFatal(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "LoadHashtreeQuarantineFatalTest")

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	stale := filepath.Join(dir, "hashtree-0000000000000001.ht")
	newest := filepath.Join(dir, "hashtree-00000000000000ff.ht")
	require.NoError(t, os.WriteFile(stale, []byte("junk"), 0o600))
	require.NoError(t, os.WriteFile(newest, []byte("junk"), 0o600))
	require.NoError(t, os.Mkdir(stale+".tmp", 0o755))

	prev := removeHashtreeFile
	removeHashtreeFile = func(name string) error {
		if name == stale {
			return os.ErrPermission
		}
		return os.Remove(name)
	}
	t.Cleanup(func() { removeHashtreeFile = prev })

	_, err := s.tryLoadHashtreeFromDisk(16)
	require.ErrorContains(t, err, "demoting rename failed")
}

// TestMayStopAsyncReplicationDumpReflectsDrainWindowDeletes pins: a drain-window conflict-delete reaches the store but not the dumped tree.
func TestMayStopAsyncReplicationDumpReflectsDrainWindowDeletes(t *testing.T) {
	t.Skip("pinned: drain-window conflict-delete stales the shutdown .ht — fix (drain-before-capture) tracked as follow-up")

	ctx := context.Background()
	_, s := newSeededAsyncShard(t, ctx, "DrainWindowDeleteDumpTest")

	gate := make(chan struct{})
	workerDone := make(chan struct{})
	var delErr error
	s.asyncRepWg.Add(1)
	go func() {
		defer close(workerDone)
		defer s.asyncRepWg.Done()
		<-gate
		_, delErr = s.deleteObject(ctx, uuidMid, time.Now(), true)
	}()

	stopDone := make(chan struct{})
	go func() {
		if ht := s.mayStopAsyncReplication(true); ht != nil {
			s.dumpHashTreeWithTimeout(ht, hashtreeDumpTimeout)
		}
		close(stopDone)
	}()

	require.Eventually(t, func() bool {
		s.asyncReplicationRWMux.RLock()
		defer s.asyncReplicationRWMux.RUnlock()
		return s.hashtree == nil
	}, 5*time.Second, 5*time.Millisecond)
	close(gate)
	<-workerDone
	<-stopDone
	require.NoError(t, delErr)

	htPath := s.pathHashTree()
	htFiles := htFilesInDir(t, htPath)
	require.Len(t, htFiles, 1, "shutdown must have dumped a .ht")
	f, err := os.Open(filepath.Join(htPath, htFiles[0].Name()))
	require.NoError(t, err)
	dumped, deserErr := hashtree.DeserializeHashTree(bufio.NewReader(f))
	require.NoError(t, f.Close())
	require.NoError(t, deserErr)

	require.NoError(t, s.removePersistedHashtree())
	enableAndAwaitAsync(t, ctx, s)
	s.asyncReplicationRWMux.RLock()
	storeRoot := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NoError(t, s.disableAsyncReplication(ctx))

	require.Equal(t, storeRoot, dumped.Root(),
		"shutdown .ht must reflect deletes applied during the worker drain window")
}

// TestUnfreezeMustNotTrustDownloadedHashtree pins: activation trust-loads a possibly-stale .ht from a pre-fix offload artifact.
func TestUnfreezeMustNotTrustDownloadedHashtree(t *testing.T) {
	t.Skip("pinned: activation over downloaded artifact files trust-loads a possibly-stale .ht — scrub belongs in the offload download path, tracked as follow-up")

	ctx := context.Background()
	const class = "UnfreezeDownloadedHashtreeTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	for _, id := range []strfmt.UUID{uuidLow, uuidMid} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tsFarPast)))
	}
	flushShard(t, ctx, sl)

	cfg := minAsyncReplicationConfig()
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	stopAsyncAndDump(t, s)
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1,
		"pre-condition: a .ht snapshot of {low,mid} exists, as in a pre-fix offload artifact")

	require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, uuidHigh, tsFarPast)))
	flushShard(t, ctx, sl)

	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	s.asyncReplicationRWMux.RLock()
	activationRoot := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()

	require.NoError(t, s.disableAsyncReplication(ctx))
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)
	s.asyncReplicationRWMux.RLock()
	rescanRoot := s.hashtree.Root()
	s.asyncReplicationRWMux.RUnlock()
	require.NoError(t, s.disableAsyncReplication(ctx))

	require.Equal(t, rescanRoot, activationRoot,
		"activation over artifact files must rescan the store, not trust the artifact's .ht")
}

// TestDisableAsyncReplicationScrubsPersistedHashtree: runtime disable removes any stray .ht.
func TestDisableAsyncReplicationScrubsPersistedHashtree(t *testing.T) {
	ctx := context.Background()
	const class = "DisableScrubsHashtreeTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	cfg := minAsyncReplicationConfig()
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	awaitHashtreeInitialized(t, s)

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	stray := filepath.Join(dir, "hashtree-00000000000000aa.ht")
	require.NoError(t, os.WriteFile(stray, []byte("stale snapshot"), 0o600))
	require.NotEmpty(t, htFilesInDir(t, dir), "pre-condition: a stray .ht is present")

	require.NoError(t, s.disableAsyncReplication(ctx))
	require.Empty(t, htFilesInDir(t, dir), "disable must scrub any persisted .ht")
}

// TestRemovePersistedHashtreeSweepsTmp: removePersistedHashtree reclaims .ht and .ht.tmp.
func TestRemovePersistedHashtreeSweepsTmp(t *testing.T) {
	ctx := context.Background()
	const class = "RemovePersistedSweepsTmpTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	require.NoError(t, os.WriteFile(filepath.Join(dir, "hashtree-01.ht"), []byte("x"), 0o600))
	require.NoError(t, os.WriteFile(filepath.Join(dir, "hashtree-02.ht.tmp"), []byte("y"), 0o600))

	require.NoError(t, s.removePersistedHashtree())

	entries, err := os.ReadDir(dir)
	require.NoError(t, err)
	require.Empty(t, entries, "removePersistedHashtree must sweep both .ht and .ht.tmp")
}

// failingSerializeHashTree overrides only Serialize; dumpHashTreeOf calls no other method.
type failingSerializeHashTree struct {
	hashtree.AggregatedHashTree
}

func (failingSerializeHashTree) Serialize(io.Writer) (int64, error) {
	return 0, errors.New("serialize boom")
}

// TestDumpHashTreeOfRemovesTmpOnError: a failed dump leaves no .tmp behind.
func TestDumpHashTreeOfRemovesTmpOnError(t *testing.T) {
	ctx := context.Background()
	const class = "DumpRemovesTmpOnErrorTest"

	sl, _ := testShard(t, ctx, class, withAsyncScheduler(t))
	s := concreteShard(t, sl)
	t.Cleanup(func() { _ = sl.Shutdown(ctx) })

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))

	err := s.dumpHashTreeOf(failingSerializeHashTree{})
	require.Error(t, err)

	entries, readErr := os.ReadDir(dir)
	require.NoError(t, readErr)
	require.Empty(t, entries, "a failed dump must not leave a .tmp behind")
}

// blockingSerializeHashTree blocks Serialize until release is closed.
type blockingSerializeHashTree struct {
	hashtree.AggregatedHashTree
	release chan struct{}
}

func (b blockingSerializeHashTree) Serialize(io.Writer) (int64, error) {
	<-b.release
	return 0, nil
}

// TestDumpPublishGateCancelNeverBlocksOnInFlightRename: a hung rename must not defeat the dump timeout through a blocking cancel — that pins performShutdown under shutdownLock.
func TestDumpPublishGateCancelNeverBlocksOnInFlightRename(t *testing.T) {
	gate := &dumpPublishGate{}
	renameStarted := make(chan struct{})
	renameRelease := make(chan struct{})
	publishDone := make(chan struct{})
	cleanupCh := make(chan bool, 1)
	publishErrCh := make(chan error, 1)
	go func() {
		defer close(publishDone)
		cleanup, err := gate.publish(func() error {
			close(renameStarted)
			<-renameRelease
			return nil
		})
		publishErrCh <- err
		cleanupCh <- cleanup
	}()
	<-renameStarted

	cancelWon := make(chan bool, 1)
	go func() { cancelWon <- gate.cancel() }()
	select {
	case won := <-cancelWon:
		require.True(t, won, "cancel must win over an in-flight rename")
	case <-time.After(2 * time.Second):
		t.Fatal("cancel blocked behind the in-flight rename — the dump timeout is defeated")
	}

	close(renameRelease)
	select {
	case <-publishDone:
	case <-time.After(5 * time.Second):
		t.Fatal("publish never returned after release")
	}
	require.ErrorIs(t, <-publishErrCh, errHashtreeDumpCancelled)
	require.True(t, <-cleanupCh, "a rename finishing after a won cancel must demand cleanup")
}

// TestDumpPublishGateOutcomes: published-before-cancel keeps the file; cancel-before-publish blocks it; a failed publish leaves cancel the winner.
func TestDumpPublishGateOutcomes(t *testing.T) {
	g := &dumpPublishGate{}
	cleanup, err := g.publish(func() error { return nil })
	require.NoError(t, err)
	require.False(t, cleanup)
	require.False(t, g.cancel(), "cancel must lose against a completed publish")

	g = &dumpPublishGate{}
	require.True(t, g.cancel())
	cleanup, err = g.publish(func() error { t.Fatal("must not run after cancel"); return nil })
	require.ErrorIs(t, err, errHashtreeDumpCancelled)
	require.False(t, cleanup)

	g = &dumpPublishGate{}
	cleanup, err = g.publish(func() error { return errors.New("rename failed") })
	require.Error(t, err)
	require.False(t, cleanup)
	require.True(t, g.cancel(), "a failed publish leaves nothing published, so cancel wins")
}

// TestRemoveLatePublishedHashTree: the publisher's self-delete removes a late-published .ht.
func TestRemoveLatePublishedHashTree(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "RemoveLatePublishedTest")
	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	late := filepath.Join(dir, "hashtree-00000000000000bb.ht")
	require.NoError(t, os.WriteFile(late, []byte("late"), 0o600))

	s.removeLatePublishedHashTree(late)
	require.Empty(t, htFilesInDir(t, dir))
}

// TestDumpHashTreeWithTimeoutSkipsLatePublication: a timed-out dump returns promptly and the late writer can never publish.
func TestDumpHashTreeWithTimeoutSkipsLatePublication(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "DumpTimeoutNoLatePublishTest")
	require.NoError(t, os.MkdirAll(s.pathHashTree(), os.ModePerm))

	release := make(chan struct{})
	start := time.Now()
	s.dumpHashTreeWithTimeout(blockingSerializeHashTree{release: release}, 25*time.Millisecond)
	require.Less(t, time.Since(start), 5*time.Second, "timed-out dump must not wait for the writer")
	require.Empty(t, htFilesInDir(t, s.pathHashTree()))

	close(release)
	assert.Eventually(t, func() bool {
		entries, err := os.ReadDir(s.pathHashTree())
		return err == nil && len(entries) == 0
	}, 5*time.Second, 10*time.Millisecond, "the late writer must publish nothing and clean up its .tmp")
}

// TestResumeMaintenanceCyclesReappliesSkippedEnable: an enable skipped during a plain halt must be re-derived when the halt lifts.
func TestResumeMaintenanceCyclesReappliesSkippedEnable(t *testing.T) {
	ctx := context.Background()
	const class = "ResumeReappliesEnableTest"
	_, s := newAsyncTestShard(t, ctx, class)

	s.index.replicationConfigLock.Lock()
	s.index.Config.AsyncReplicationConfig = minAsyncReplicationConfig()
	s.index.replicationConfigLock.Unlock()

	require.NoError(t, s.HaltForTransfer(ctx, false, 0))

	override := additional.AsyncReplicationTargetNodeOverride{
		CollectionID:   class,
		ShardID:        s.name,
		SourceNode:     "nodeA",
		TargetNode:     "nodeB",
		UpperTimeBound: time.Now().Add(time.Hour).UnixMilli(),
	}
	require.NoError(t, s.addTargetNodeOverride(ctx, override))

	s.asyncReplicationRWMux.RLock()
	installed := s.hashtree != nil
	s.asyncReplicationRWMux.RUnlock()
	require.False(t, installed, "the enable must be skipped while halted")

	require.NoError(t, s.resumeMaintenanceCycles(ctx))

	s.asyncReplicationRWMux.RLock()
	installed = s.hashtree != nil
	s.asyncReplicationRWMux.RUnlock()
	require.True(t, installed, "the halt-skipped enable must be re-derived on resume")
}

// TestHaltedForTransferDoesNotBlockOnHeldMux: haltedForTransfer must report the true count promptly while the mux is held — neither parking on the backup prep nor misreading a concurrent holder as halted.
func TestHaltedForTransferDoesNotBlockOnHeldMux(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "HaltedNonBlockingTest")

	s.haltForTransferMux.Lock()
	defer s.haltForTransferMux.Unlock()

	got := make(chan bool, 2)
	go func() {
		got <- s.haltedForTransfer()
		s.haltForTransferCount.Store(1)
		got <- s.haltedForTransfer()
	}()
	select {
	case halted := <-got:
		require.False(t, halted, "a held mux without a halt must not read as halted")
	case <-time.After(2 * time.Second):
		t.Fatal("haltedForTransfer parked on the held mux")
	}
	require.True(t, <-got, "an actual halt must read as halted")
	s.haltForTransferCount.Store(0)
}

// TestEnableAsyncReplicationSkipsFreshInitDuringHalt: a fresh enable during a transfer halt must not resurrect async replication mid-offload.
func TestEnableAsyncReplicationSkipsFreshInitDuringHalt(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableSkipsDuringHaltTest")

	s.haltForTransferMux.Lock()
	s.haltForTransferCount.Store(1)
	s.haltForTransferMux.Unlock()

	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	s.asyncReplicationRWMux.RLock()
	installed := s.hashtree != nil
	s.asyncReplicationRWMux.RUnlock()
	require.False(t, installed, "enable during a halt must not install a tree")

	s.haltForTransferMux.Lock()
	s.haltForTransferCount.Store(0)
	s.haltForTransferMux.Unlock()
	enableAndAwaitAsync(t, ctx, s)
}

// TestEnableAsyncReplicationConfigUpdateSurvivesHalt: an already-running shard still takes config updates during a plain-backup halt via the fast path.
func TestEnableAsyncReplicationConfigUpdateSurvivesHalt(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableFastPathDuringHaltTest")
	enableAndAwaitAsync(t, ctx, s)

	s.haltForTransferMux.Lock()
	s.haltForTransferCount.Store(1)
	s.haltForTransferMux.Unlock()
	t.Cleanup(func() {
		s.haltForTransferMux.Lock()
		s.haltForTransferCount.Store(0)
		s.haltForTransferMux.Unlock()
	})

	cfg := minAsyncReplicationConfig()
	cfg.frequency = 123 * time.Second
	require.NoError(t, s.enableAsyncReplication(ctx, cfg))
	s.asyncReplicationRWMux.RLock()
	gotFrequency := s.asyncReplicationConfig.frequency
	treeAlive := s.hashtree != nil
	s.asyncReplicationRWMux.RUnlock()
	require.Equal(t, 123*time.Second, gotFrequency)
	require.True(t, treeAlive, "the running tree must survive a fast-path config update during a halt")
}

// TestDisableAsyncReplicationSkipsScrubDuringShutdownRequest: a config disable racing a requested shutdown must not delete the snapshot the shutdown is about to publish.
func TestDisableAsyncReplicationSkipsScrubDuringShutdownRequest(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "DisableScrubShutdownRaceTest")

	require.NoError(t, os.MkdirAll(s.pathHashTree(), os.ModePerm))
	published := filepath.Join(s.pathHashTree(), "hashtree-00000000000000aa.ht")
	require.NoError(t, os.WriteFile(published, []byte("snapshot"), 0o600))

	s.shutdownRequested.Store(true)
	t.Cleanup(func() { s.shutdownRequested.Store(false) })

	require.NoError(t, s.disableAsyncReplication(ctx))
	_, statErr := os.Stat(published)
	require.NoError(t, statErr, "the scrub must stand down while a shutdown is in flight")
}

// TestDisableAsyncReplicationScrubsWhenAlreadyStopped: disable scrubs even when the tree is already nil (the offload-halt shape).
func TestDisableAsyncReplicationScrubsWhenAlreadyStopped(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "DisableScrubsWhenStoppedTest")
	enableAndAwaitAsync(t, ctx, s)

	s.mayStopAsyncReplication(false)

	require.NoError(t, os.MkdirAll(s.pathHashTree(), os.ModePerm))
	stray := filepath.Join(s.pathHashTree(), "hashtree-00000000000000aa.ht")
	require.NoError(t, os.WriteFile(stray, []byte("stale snapshot"), 0o600))

	require.NoError(t, s.disableAsyncReplication(ctx))
	require.Empty(t, htFilesInDir(t, s.pathHashTree()), "already-stopped disable must still scrub")
}

// TestDisableAsyncReplicationPropagatesScrubError: a surviving .ht is a divergence risk, so the failure must surface.
func TestDisableAsyncReplicationPropagatesScrubError(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("requires non-root to make the hashtree directory read-only")
	}

	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "DisableScrubErrorTest")
	enableAndAwaitAsync(t, ctx, s)

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	require.NoError(t, os.WriteFile(filepath.Join(dir, "hashtree-00000000000000aa.ht"), []byte("stale snapshot"), 0o600))
	require.NoError(t, os.Chmod(dir, 0o555))
	t.Cleanup(func() { _ = os.Chmod(dir, 0o755) })

	require.ErrorContains(t, s.disableAsyncReplication(ctx), "removing persisted hashtree")
}

// TestEnableAsyncReplicationSkipsShutShard: enable on a shut shard is a no-op and must not consume a snapshot.
func TestEnableAsyncReplicationSkipsShutShard(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableSkipsShutShardTest")

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	stray := filepath.Join(dir, "hashtree-00000000000000aa.ht")
	require.NoError(t, os.WriteFile(stray, []byte("snapshot"), 0o600))

	s.shut.Store(true)
	t.Cleanup(func() { s.shut.Store(false) })

	require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
	s.asyncReplicationRWMux.RLock()
	require.Nil(t, s.hashtree)
	s.asyncReplicationRWMux.RUnlock()
	require.Len(t, htFilesInDir(t, dir), 1, "skip must not consume the snapshot")
}

// TestDumpHashTreeOfCreatesDir: a dump must not silently fail when the hashtree dir was never created.
func TestDumpHashTreeOfCreatesDir(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "DumpCreatesDirTest")

	require.NoError(t, os.RemoveAll(s.pathHashTree()))

	ht, err := hashtree.NewHashTree(2)
	require.NoError(t, err)
	require.NoError(t, s.dumpHashTreeOf(ht))
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1)
}

// TestRebuildHashtreeRetriesAfterFailure: a failed rebuild leaves the shard deregistered, so it must retry until it recovers.
func TestRebuildHashtreeRetriesAfterFailure(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("requires non-root to make the hashtree directory read-only")
	}

	prevBackoff := asyncRepRebuildBaseBackoff.Load()
	asyncRepRebuildBaseBackoff.Store(int64(5 * time.Millisecond))
	t.Cleanup(func() { asyncRepRebuildBaseBackoff.Store(prevBackoff) })

	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "RebuildRetriesTest")
	enableAndAwaitAsync(t, ctx, s)

	s.index.replicationConfigLock.Lock()
	s.index.Config.ReplicationFactor = 3
	s.index.Config.AsyncReplicationConfig = minAsyncReplicationConfig()
	s.index.replicationConfigLock.Unlock()

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	require.NoError(t, os.WriteFile(filepath.Join(dir, "hashtree-00000000000000aa.ht"), []byte("stale snapshot"), 0o600))
	require.NoError(t, os.Chmod(dir, 0o555))
	t.Cleanup(func() { _ = os.Chmod(dir, 0o755) })

	rebuildDone := make(chan struct{})
	go func() {
		defer close(rebuildDone)
		s.index.asyncReplicationScheduler.rebuildHashtree(s)
	}()

	require.Eventually(t, func() bool {
		return s.asyncRepRebuildFailures.Load() >= 2
	}, 10*time.Second, 10*time.Millisecond, "rebuild must keep retrying while the scrub fails")

	require.NoError(t, os.Chmod(dir, 0o755))
	select {
	case <-rebuildDone:
	case <-time.After(30 * time.Second):
		t.Fatal("rebuild did not recover after the failure cleared")
	}
	awaitHashtreeInitialized(t, s)
	require.Empty(t, htFilesInDir(t, dir), "the recovered rebuild must have scrubbed the stale snapshot")
}

// TestPerformShutdownPersistsHashtreeAfterStoreFlush: the full shutdown path still produces a snapshot.
func TestPerformShutdownPersistsHashtreeAfterStoreFlush(t *testing.T) {
	ctx := context.Background()
	sl, s := newAsyncTestShard(t, ctx, "ShutdownPersistsAfterFlushTest")
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime("ShutdownPersistsAfterFlushTest", id, tsFarPast)))
	}
	enableAndAwaitAsync(t, ctx, s)

	require.NoError(t, sl.Shutdown(ctx))
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1,
		"a clean shutdown must publish the snapshot after the store flush")
}

// TestPerformShutdownSkipsDumpWhenStoreShutdownFails: a snapshot must never outlive writes the store failed to flush.
func TestPerformShutdownSkipsDumpWhenStoreShutdownFails(t *testing.T) {
	ctx := context.Background()
	sl, s := newAsyncTestShard(t, ctx, "ShutdownSkipsDumpOnStoreFailTest")
	for _, id := range []strfmt.UUID{uuidLow, uuidMid, uuidHigh} {
		require.NoError(t, sl.PutObject(ctx, testObjWithTime("ShutdownSkipsDumpOnStoreFailTest", id, tsFarPast)))
	}
	enableAndAwaitAsync(t, ctx, s)

	// the store is closed first to make its shutdown fail. The teardown itself
	// runs to completion whatever the caller's context does
	require.NoError(t, s.store.Shutdown(ctx))
	require.ErrorContains(t, s.performShutdown(ctx), "stop lsmkv store",
		"the store flush itself must have failed for this test to be meaningful")
	require.Empty(t, htFilesInDir(t, s.pathHashTree()),
		"no snapshot may be published when the store flush did not complete")
}

// TestRebuildFromScratchSkipsShutShard: a shut shard's snapshot survives and no tree is installed.
func TestRebuildFromScratchSkipsShutShard(t *testing.T) {
	ctx := context.Background()
	sl, s := newSeededAsyncShard(t, ctx, "RebuildFromScratchShutShardTest")

	require.NoError(t, sl.Shutdown(ctx))
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1, "pre-condition: shutdown published a snapshot")

	require.NoError(t, s.rebuildAsyncReplicationFromScratch(ctx, true, minAsyncReplicationConfig()))
	s.asyncReplicationRWMux.RLock()
	require.Nil(t, s.hashtree, "no tree may be installed on a shut shard")
	s.asyncReplicationRWMux.RUnlock()
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1, "the shutdown snapshot must survive")
}

// TestDisableAsyncReplicationSkipsShutShard: a config apply racing shutdown must not scrub the fresh snapshot.
func TestDisableAsyncReplicationSkipsShutShard(t *testing.T) {
	ctx := context.Background()
	sl, s := newSeededAsyncShard(t, ctx, "DisableSkipsShutShardTest")

	require.NoError(t, sl.Shutdown(ctx))
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1, "pre-condition: shutdown published a snapshot")

	require.NoError(t, s.disableAsyncReplication(ctx))
	require.Len(t, htFilesInDir(t, s.pathHashTree()), 1, "the shutdown snapshot must survive a late disable")
}

// TestEnableAsyncReplicationShutObservedUnderLock: shut set while enable is parked on the mux must still be observed.
func TestEnableAsyncReplicationShutObservedUnderLock(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableShutUnderLockTest")
	t.Cleanup(func() { s.shut.Store(false) })

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	stale := filepath.Join(dir, "hashtree-00000000000000aa.ht")

	for attempt := 0; attempt < 50; attempt++ {
		require.NoError(t, os.WriteFile(stale, []byte("junk"), 0o600))
		s.shut.Store(false)

		s.asyncReplicationRWMux.Lock()
		enableDone := make(chan error, 1)
		go func() { enableDone <- s.enableAsyncReplication(ctx, minAsyncReplicationConfig()) }()
		time.Sleep(time.Millisecond)
		s.shut.Store(true)
		s.asyncReplicationRWMux.Unlock()
		require.NoError(t, <-enableDone)

		s.asyncReplicationRWMux.RLock()
		tree := s.hashtree
		s.asyncReplicationRWMux.RUnlock()
		require.Nil(t, tree, "no tree may be installed once shut is set")

		// Consumed ⇒ the entry guard passed ⇒ the in-lock check did the skip.
		if len(htFilesInDir(t, dir)) == 0 {
			return
		}
	}
	t.Fatal("enable never reached the in-lock check across attempts")
}

// TestEnableAsyncReplicationSkipsDroppedShard: enable on a dropped shard is a no-op — no snapshot consumed, no tree, no registration, nothing resurrected.
func TestEnableAsyncReplicationSkipsDroppedShard(t *testing.T) {
	ctx := context.Background()

	t.Run("keepFiles drop leaves planted snapshot", func(t *testing.T) {
		sl, _ := testShard(t, ctx, "EnableSkipsDroppedShardKeep", withAsyncScheduler(t))
		s := concreteShard(t, sl)

		dir := s.pathHashTree()
		require.NoError(t, os.MkdirAll(dir, os.ModePerm))
		stray := filepath.Join(dir, "hashtree-00000000000000aa.ht")
		require.NoError(t, os.WriteFile(stray, []byte("snapshot"), 0o600))

		require.NoError(t, s.drop(true))

		require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
		s.asyncReplicationRWMux.RLock()
		require.Nil(t, s.hashtree)
		s.asyncReplicationRWMux.RUnlock()
		require.Len(t, htFilesInDir(t, dir), 1, "skip must not consume the snapshot")

		sched := s.index.asyncReplicationScheduler
		require.Never(t, func() bool {
			sched.mu.Lock()
			defer sched.mu.Unlock()
			_, registered := sched.entries[s]
			return registered
		}, 300*time.Millisecond, 25*time.Millisecond, "a dropped shard must never register with the scheduler")
	})

	t.Run("full drop resurrects nothing", func(t *testing.T) {
		sl, _ := testShard(t, ctx, "EnableSkipsDroppedShardFull", withAsyncScheduler(t))
		s := concreteShard(t, sl)

		require.NoError(t, s.drop(false))

		require.NoError(t, s.enableAsyncReplication(ctx, minAsyncReplicationConfig()))
		s.asyncReplicationRWMux.RLock()
		require.Nil(t, s.hashtree)
		s.asyncReplicationRWMux.RUnlock()
		_, err := os.Stat(s.path())
		require.True(t, os.IsNotExist(err), "enable must not resurrect the dropped shard directory")
	})
}

// TestRebuildFromScratchSkipsDroppedShard: a rebuild racing a tenant delete must install nothing and resurrect nothing.
func TestRebuildFromScratchSkipsDroppedShard(t *testing.T) {
	ctx := context.Background()
	sl, _ := testShard(t, ctx, "RebuildFromScratchDroppedShardTest", withAsyncScheduler(t))
	s := concreteShard(t, sl)
	enableAndAwaitAsync(t, ctx, s)

	require.NoError(t, s.drop(false))

	require.NoError(t, s.rebuildAsyncReplicationFromScratch(ctx, true, minAsyncReplicationConfig()))
	s.asyncReplicationRWMux.RLock()
	require.Nil(t, s.hashtree, "no tree may be installed on a dropped shard")
	s.asyncReplicationRWMux.RUnlock()
	_, err := os.Stat(s.path())
	require.True(t, os.IsNotExist(err), "rebuild must not resurrect the dropped shard directory")
}

// TestDisableAsyncReplicationSkipsDroppedShard: a config apply racing a tenant delete must leave the renamed dir alone.
func TestDisableAsyncReplicationSkipsDroppedShard(t *testing.T) {
	ctx := context.Background()
	sl, _ := testShard(t, ctx, "DisableSkipsDroppedShardTest", withAsyncScheduler(t))
	s := concreteShard(t, sl)
	enableAndAwaitAsync(t, ctx, s)

	require.NoError(t, s.drop(false))

	require.NoError(t, s.disableAsyncReplication(ctx))
	_, err := os.Stat(s.path())
	require.True(t, os.IsNotExist(err), "a late disable must leave the dropped shard directory alone")
}

// TestEnableAsyncReplicationDropObservedUnderLock: a drop signal fired while enable is parked on the mux must still be observed.
func TestEnableAsyncReplicationDropObservedUnderLock(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableDropUnderLockTest")

	dir := s.pathHashTree()
	require.NoError(t, os.MkdirAll(dir, os.ModePerm))
	stale := filepath.Join(dir, "hashtree-00000000000000aa.ht")

	for attempt := 0; attempt < 50; attempt++ {
		require.NoError(t, os.WriteFile(stale, []byte("junk"), 0o600))
		// Fresh teardown signal per attempt (test-only; prod never reassigns shutCtx).
		s.shutCtx, s.shutCtxCancel = context.WithCancelCause(context.Background())

		s.asyncReplicationRWMux.Lock()
		enableDone := make(chan error, 1)
		go func() { enableDone <- s.enableAsyncReplication(ctx, minAsyncReplicationConfig()) }()
		time.Sleep(time.Millisecond)
		s.shutCtxCancel(fmt.Errorf("drop %q", s.ID()))
		s.asyncReplicationRWMux.Unlock()
		require.NoError(t, <-enableDone)

		s.asyncReplicationRWMux.RLock()
		tree := s.hashtree
		s.asyncReplicationRWMux.RUnlock()
		require.Nil(t, tree, "no tree may be installed once the drop signal fired")

		// Consumed ⇒ the entry guard passed ⇒ the in-lock check did the skip.
		if len(htFilesInDir(t, dir)) == 0 {
			return
		}
	}
	t.Fatal("enable never reached the in-lock check across attempts")
}

// TestMayStopSkipsCaptureOnDrainTimeout: a timed-out drain must not capture — a surviving worker can still write.
func TestMayStopSkipsCaptureOnDrainTimeout(t *testing.T) {
	prev := asyncReplicationWorkerDrainTimeout.Load()
	asyncReplicationWorkerDrainTimeout.Store(int64(50 * time.Millisecond))
	t.Cleanup(func() { asyncReplicationWorkerDrainTimeout.Store(prev) })

	ctx := context.Background()
	_, s := newSeededAsyncShard(t, ctx, "MayStopDrainTimeoutTest")

	s.asyncRepWg.Add(1)
	defer s.asyncRepWg.Done()

	require.Nil(t, s.mayStopAsyncReplication(true), "timed-out drain must not capture")
}

// TestLazyWrappersDoNotLoad: async-rep wrappers on an unloaded shard must not trigger a load (a load attempt would nil-deref).
func TestLazyWrappersDoNotLoad(t *testing.T) {
	l := &LazyLoadShard{}
	require.NoError(t, l.enableAsyncReplication(context.Background(), AsyncReplicationConfig{}))
	require.NoError(t, l.rebuildAsyncReplicationFromScratch(context.Background(), true, AsyncReplicationConfig{}))
	require.NoError(t, l.disableAsyncReplication(context.Background()))
	require.NoError(t, l.removePersistedHashtree())
}

// TestResolveObjectConflictTimeBasedNoClobber pins that a TimeBased repair keeps a live local object at least as new as the remote deletion, even when the stale pre-RPC snapshot said it was older.
func TestResolveObjectConflictTimeBasedNoClobber(t *testing.T) {
	ctx := context.Background()
	const (
		class      = "TimeBasedNoClobber"
		targetNode = "node-B"
		snapshot   = int64(100) // stale digest-time snapshot; always < remoteDel so the outer gate passes
		remoteDel  = int64(150)
	)
	id := strfmt.UUID("00000000-0000-0000-0000-000000000abc")

	tests := []struct {
		name        string
		liveTime    int64
		wantDeleted bool
		wantExists  bool
	}{
		{"live newer than remote deletion is kept", 200, false, true},
		{"live older than remote deletion is deleted", 100, true, false},
		{"live equal to remote deletion is kept", 150, false, true},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			sl, _ := testShard(t, ctx, class)
			s := concreteShard(t, sl)
			t.Cleanup(func() { _ = sl.Shutdown(ctx) })

			require.NoError(t, sl.PutObject(ctx, testObjWithTime(class, id, tc.liveTime)))

			deleted, notResolved, err := s.resolveObjectConflict(
				ctx,
				routerTypes.RepairResponse{ID: id.String(), Deleted: true, UpdateTime: remoteDel},
				models.ReplicationConfigDeletionStrategyTimeBasedResolution,
				targetNode, nil,
				map[strfmt.UUID]int64{id: snapshot},
			)
			require.NoError(t, err)
			assert.False(t, notResolved, "notResolved")
			assert.Equal(t, tc.wantDeleted, deleted, "deleted")

			obj, err := s.ObjectByID(ctx, id, nil, additional.Properties{})
			require.NoError(t, err)
			assert.Equal(t, tc.wantExists, obj != nil, "object exists")
		})
	}
}

// TestDisableConcurrentReEnableConsistency is a deadlock + consistency guard for disable Deregistering under the write lock: hammer concurrent enable/disable and assert the enabled<=>registered invariant holds (see PR for why it is not a deterministic reproduction).
func TestDisableConcurrentReEnableConsistency(t *testing.T) {
	ctx := context.Background()
	const class = "DisableRacesReEnable"
	const iterations = 100

	sl, _ := testShard(t, ctx, class, withAsyncSchedulerDispatchDisabled(t))
	s := concreteShard(t, sl)
	sched := s.index.asyncReplicationScheduler

	cfg := minAsyncReplicationConfig()

	awaitWg := func() {
		t.Helper()
		done := make(chan struct{})
		go func() { s.asyncRepWg.Wait(); close(done) }()
		select {
		case <-done:
		case <-time.After(10 * time.Second):
			t.Fatal("asyncRepWg did not drain within timeout — goroutine leak or deadlock")
		}
	}

	for i := range iterations {
		require.NoError(t, s.enableAsyncReplication(ctx, cfg))
		awaitHashtreeInitialized(t, s)
		awaitWg()

		var wg sync.WaitGroup
		wg.Add(2)
		go func() { defer wg.Done(); _ = s.disableAsyncReplication(ctx) }()
		go func() { defer wg.Done(); _ = s.enableAsyncReplication(ctx, cfg) }()
		wg.Wait()

		awaitWg()

		s.asyncReplicationRWMux.RLock()
		enabled := s.hashtree != nil
		s.asyncReplicationRWMux.RUnlock()

		sched.mu.Lock()
		_, registered := sched.entries[s]
		sched.mu.Unlock()

		require.Equalf(t, enabled, registered,
			"enabled<=>registered invariant violated at iteration %d: hashtree!=nil=%v registered=%v "+
				"(enabled-but-unregistered means a disable Deregister orphaned a concurrent re-enable's registration)",
			i, enabled, registered)

		require.NoError(t, s.disableAsyncReplication(ctx))
		awaitWg()
	}
}

// TestUpdateReplicationConfigKeepsAsyncReplicationWhileOverridesActive verifies a config-disable does not tear down async replication while the shard holds an active target-node override.
func TestUpdateReplicationConfigKeepsAsyncReplicationWhileOverridesActive(t *testing.T) {
	ctx := context.Background()
	const class = "UpdateCfgKeepsOverride"

	sl, _ := testShard(t, ctx, class, withAsyncSchedulerDispatchDisabled(t))
	s := concreteShard(t, sl)
	sched := s.index.asyncReplicationScheduler

	s.index.replicationConfigLock.Lock()
	s.index.Config.AsyncReplicationConfig = minAsyncReplicationConfig()
	s.index.replicationConfigLock.Unlock()

	override := additional.AsyncReplicationTargetNodeOverride{
		CollectionID:   class,
		ShardID:        s.name,
		SourceNode:     "nodeA",
		TargetNode:     "nodeB",
		UpperTimeBound: time.Now().Add(time.Hour).UnixMilli(),
	}
	require.NoError(t, s.addTargetNodeOverride(ctx, override))
	awaitHashtreeInitialized(t, s)

	requireRegistered := func(want bool) {
		t.Helper()
		require.Eventually(t, func() bool {
			sched.mu.Lock()
			_, ok := sched.entries[s]
			sched.mu.Unlock()
			return ok == want
		}, 10*time.Second, 10*time.Millisecond, "registered=%v not reached", want)
	}
	hashtreePresent := func() bool {
		s.asyncReplicationRWMux.RLock()
		defer s.asyncReplicationRWMux.RUnlock()
		return s.hashtree != nil
	}

	requireRegistered(true)
	require.True(t, hashtreePresent(), "hashtree must be present while override is active")

	require.NoError(t, s.index.updateReplicationConfig(ctx,
		&models.ReplicationConfig{Factor: 1}))

	require.True(t, hashtreePresent(),
		"hashtree must NOT be torn down by a config-disable while an override is active")
	requireRegistered(true)
	require.True(t, s.hasActiveAsyncReplicationTargetOverrides(),
		"override must still be active after config-disable")

	require.NoError(t, s.removeAllTargetNodeOverrides(ctx))
	require.False(t, hashtreePresent(),
		"hashtree must be torn down once the last override is gone and the class is disabled")
	requireRegistered(false)
}

// TestUpdateReplicationConfigDisablesWhenNoActiveOverrides verifies the override guard does not break normal config-driven teardown when no override is held.
func TestUpdateReplicationConfigDisablesWhenNoActiveOverrides(t *testing.T) {
	ctx := context.Background()
	const class = "UpdateCfgDisablesNoOverride"

	sl, _ := testShard(t, ctx, class, withAsyncSchedulerDispatchDisabled(t))
	s := concreteShard(t, sl)
	sched := s.index.asyncReplicationScheduler

	require.NoError(t, s.index.updateReplicationConfig(ctx,
		&models.ReplicationConfig{Factor: 2}))
	awaitHashtreeInitialized(t, s)
	require.Eventually(t, func() bool {
		sched.mu.Lock()
		_, ok := sched.entries[s]
		sched.mu.Unlock()
		return ok
	}, 10*time.Second, 10*time.Millisecond, "shard must be registered after config-enable")

	require.NoError(t, s.index.updateReplicationConfig(ctx,
		&models.ReplicationConfig{Factor: 1}))

	require.Eventually(t, func() bool {
		s.asyncReplicationRWMux.RLock()
		ht := s.hashtree
		s.asyncReplicationRWMux.RUnlock()
		sched.mu.Lock()
		_, ok := sched.entries[s]
		sched.mu.Unlock()
		return ht == nil && !ok
	}, 10*time.Second, 10*time.Millisecond, "shard must be disabled and deregistered after config-disable with no override")
}

// TestEnableAsyncReplicationInvalidHeightLeavesHashtreeNil: a failed tree allocation must not store a typed-nil interface that reads as "already running" forever.
func TestEnableAsyncReplicationInvalidHeightLeavesHashtreeNil(t *testing.T) {
	ctx := context.Background()
	_, s := newAsyncTestShard(t, ctx, "EnableInvalidHeightTest")

	bad := minAsyncReplicationConfig()
	bad.hashtreeHeight = hashtree.MaxHeight + 1
	require.ErrorIs(t, s.enableAsyncReplication(ctx, bad), hashtree.ErrIllegalArguments)

	s.asyncReplicationRWMux.RLock()
	interfaceNil := s.hashtree == nil
	s.asyncReplicationRWMux.RUnlock()
	require.True(t, interfaceNil, "a failed allocation must leave the hashtree interface nil, not typed-nil")

	enableAndAwaitAsync(t, ctx, s)
	require.NoError(t, s.disableAsyncReplication(ctx))
}
