//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	"fmt"

	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv"
)

// schemaManager field kept for future use but OnMigrationComplete is a no-op
// for searchable — the filterable strategy (which runs second) updates the schema.

// SearchableRetokenizeStrategy implements MigrationStrategy for rebuilding the
// searchable (BM25) index for a text property with a different tokenization
// strategy (e.g. WORD → FIELD).
type SearchableRetokenizeStrategy struct {
	noAnalyzerOverlay
	propName           string
	targetTokenization string
	className          string
	bucketStrategy     string // StrategyMapCollection or StrategyInverted
	generation         int    // see genSuffix godoc for the per-migration generation contract
}

func (s *SearchableRetokenizeStrategy) MigrationDirName() string {
	// Include property name + per-migration generation so back-to-back
	// migrations on the same property don't collide on tracker state.
	return MigrationDirPrefixSearchableRetokenize + "_" + s.propName + genSuffix(s.generation)
}

func (s *SearchableRetokenizeStrategy) SourceBucketName(_ string) string {
	return helpers.BucketSearchableFromPropNameLSM(s.propName)
}

func (s *SearchableRetokenizeStrategy) ReindexSuffix() string {
	return "__retokenize_reindex" + genSuffix(s.generation)
}

func (s *SearchableRetokenizeStrategy) IngestSuffix() string {
	return "__retokenize_ingest" + genSuffix(s.generation)
}

func (s *SearchableRetokenizeStrategy) BackupSuffix() string {
	return "__retokenize_backup" + genSuffix(s.generation)
}

func (s *SearchableRetokenizeStrategy) SourceStrategy() string {
	return s.bucketStrategy
}

func (s *SearchableRetokenizeStrategy) SourceIndexType() PropertyIndexType {
	return IndexTypePropSearchableValue
}

func (s *SearchableRetokenizeStrategy) TargetStrategy() string {
	return s.bucketStrategy
}

func (s *SearchableRetokenizeStrategy) BackupStrategy() string {
	return s.bucketStrategy
}

func (s *SearchableRetokenizeStrategy) WriteToReindexBucket(shard ShardLike, bucket *lsmkv.Bucket,
	docID uint64, prop inverted.Property,
) error {
	if len(prop.RawValues) == 0 {
		return nil
	}

	analyzer := inverted.NewAnalyzer(nil, s.className)
	items := analyzer.TextArray(s.targetTokenization, prop.RawValues, prop.Name, nil)
	propLen := s.calcPropLen(items)

	for _, item := range items {
		pair := shard.pairPropertyWithFrequency(docID, item.TermFrequency, propLen)
		if err := shard.addToPropertyMapBucket(bucket, pair, item.Data); err != nil {
			return fmt.Errorf("retokenize prop '%s': %w", prop.Name, err)
		}
	}
	return nil
}

// MakeAddCallback returns a callback for adding documents to the searchable index.
// forTargetStrategy controls which tokenization is used: true uses the new target
// tokenization (for the reindex bucket), false uses the existing tokenization
// (for the ingest/double-write bucket that must match the currently live index).
func (s *SearchableRetokenizeStrategy) MakeAddCallback(bucketNamer func(string) string,
	propsByName map[string]struct{}, forTargetStrategy bool,
) onAddToPropertyValueIndex {
	// The analyzer is stateless once constructed (it carries only className
	// and a function pointer); hoist it out of the per-callback hot path so
	// we don't allocate a fresh struct on every Add to a reindexed prop.
	// Skip the allocation entirely when forTargetStrategy is false — the
	// closure won't touch the analyzer in that branch.
	var analyzer *inverted.Analyzer
	if forTargetStrategy {
		analyzer = inverted.NewAnalyzer(nil, s.className)
	}
	return func(shard *Shard, docID uint64, property *inverted.Property) error {
		if !property.HasSearchableIndex {
			return nil
		}
		bucket, bucketName, skip := resolveScopedDoubleWriteBucket(shard, property,
			propsByName, bucketNamer, s.SourceBucketName, forTargetStrategy)
		if skip {
			return nil
		}

		var items []inverted.Countable
		if forTargetStrategy && len(property.RawValues) > 0 {
			// Re-tokenize with the target tokenization for the new index.
			items = analyzer.TextArray(s.targetTokenization, property.RawValues, property.Name, nil)
		} else {
			// Use existing items (old tokenization) for the old index.
			items = property.Items
		}

		propLen := s.calcPropLen(items)
		for _, item := range items {
			pair := shard.pairPropertyWithFrequency(docID, item.TermFrequency, propLen)
			if err := shard.addToPropertyMapBucket(bucket, pair, item.Data); err != nil {
				return fmt.Errorf("retokenize add prop '%s' to bucket '%s': %w", item.Data, bucketName, err)
			}
		}
		return nil
	}
}

// MakeDeleteCallback returns a callback for removing documents from the searchable index.
// forTargetStrategy has the same semantics as in MakeAddCallback.
func (s *SearchableRetokenizeStrategy) MakeDeleteCallback(bucketNamer func(string) string,
	propsByName map[string]struct{}, forTargetStrategy bool,
) onDeleteFromPropertyValueIndex {
	// See the MakeAddCallback comment — same rationale: hoist the analyzer
	// out of the per-callback hot path.
	var analyzer *inverted.Analyzer
	if forTargetStrategy {
		analyzer = inverted.NewAnalyzer(nil, s.className)
	}
	return func(shard *Shard, docID uint64, property *inverted.Property) error {
		if !property.HasSearchableIndex {
			return nil
		}
		bucket, bucketName, skip := resolveScopedDoubleWriteBucket(shard, property,
			propsByName, bucketNamer, s.SourceBucketName, forTargetStrategy)
		if skip {
			return nil
		}

		var items []inverted.Countable
		if forTargetStrategy && len(property.RawValues) > 0 {
			items = analyzer.TextArray(s.targetTokenization, property.RawValues, property.Name, nil)
		} else {
			items = property.Items
		}

		for _, item := range items {
			if err := shard.deleteInvertedIndexItemWithFrequencyLSM(bucket, item, docID); err != nil {
				return fmt.Errorf("retokenize delete prop '%s' from bucket '%s': %w", item.Data, bucketName, err)
			}
		}
		return nil
	}
}

func (s *SearchableRetokenizeStrategy) PreReindexHook(_ *Shard, _ []string) {
	// No-op: the searchable bucket already exists.
}

// OnMigrationComplete is a no-op for the searchable strategy. The schema
// update happens in the filterable strategy which runs after this one.
func (s *SearchableRetokenizeStrategy) OnMigrationComplete(_ context.Context, _ ShardLike) error {
	return nil
}

func (s *SearchableRetokenizeStrategy) calcPropLen(items []inverted.Countable) float32 {
	if s.bucketStrategy == lsmkv.StrategyInverted {
		return calcPropLenInverted(items)
	}
	return calcPropLenMap(items)
}
