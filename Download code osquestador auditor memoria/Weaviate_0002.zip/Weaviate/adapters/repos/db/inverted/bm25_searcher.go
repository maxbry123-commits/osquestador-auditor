//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package inverted

import (
	"context"
	"fmt"
	"math"
	"os"
	"runtime/debug"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/weaviate/weaviate/entities/additional"
	"github.com/weaviate/weaviate/entities/concurrency"
	enterrors "github.com/weaviate/weaviate/entities/errors"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	"github.com/weaviate/sroar"
	"github.com/weaviate/weaviate/adapters/handlers/graphql/local/common_filters"
	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted/stopwords"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted/terms"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv"
	"github.com/weaviate/weaviate/adapters/repos/db/priorityqueue"
	"github.com/weaviate/weaviate/entities/inverted"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/entities/searchparams"
	"github.com/weaviate/weaviate/entities/storobj"
	"github.com/weaviate/weaviate/entities/tokenizer"
)

type BM25Searcher struct {
	config           schema.BM25Config
	store            *lsmkv.Store
	getClass         func(string) *models.Class
	classSearcher    ClassSearcher // to allow recursive searches on ref-props
	propLenTracker   propLengthRetriever
	logger           logrus.FieldLogger
	shardVersion     uint16
	stopwordProvider *stopwords.Provider
	// tokResolver, when non-nil, overrides prop.Tokenization on query
	// input analysis. Used by the per-shard tokenization overlay to
	// keep query tokenization aligned with the bucket content during
	// the FINALIZING window of a change-tokenization migration. Nil =
	// use prop.Tokenization directly (tests and callers with no
	// in-flight migration).
	tokResolver TokenizationResolver
	// bucketPinResolver, when non-nil, supersedes tokResolver + GetBucket for
	// searchable text props: one consistent (tokenization, bucket) snapshot,
	// pinned for the whole query. See [SearchableBucketPinningResolver].
	bucketPinResolver SearchableBucketPinningResolver
}

type propLengthRetriever interface {
	PropertyMean(prop string) (float32, error)
}

// pinnedSearchableBuckets carries the buckets one query pinned at prop
// discovery, so lookup reuses the pinned pointer instead of re-fetching by
// name. Per-query, never stored on the shared BM25Searcher.
type pinnedSearchableBuckets struct {
	byProp   map[string]*lsmkv.Bucket
	releases []func()
	released bool
}

func (p *pinnedSearchableBuckets) bucketFor(propName string) (*lsmkv.Bucket, bool) {
	if p == nil || p.byProp == nil {
		return nil, false
	}
	b, ok := p.byProp[propName]
	return b, ok
}

// bucket may be nil; the release is still recorded so it runs at query end.
func (p *pinnedSearchableBuckets) add(propName string, bucket *lsmkv.Bucket, release func()) {
	if p.byProp == nil {
		p.byProp = map[string]*lsmkv.Bucket{}
	}
	p.byProp[propName] = bucket
	if release != nil {
		p.releases = append(p.releases, release)
	}
}

// release is idempotent and nil-safe.
func (p *pinnedSearchableBuckets) release() {
	if p == nil || p.released {
		return
	}
	p.released = true
	for _, r := range p.releases {
		r()
	}
}

type termListRequest struct {
	term               string
	termId             int
	duplicateTextBoost int
	propertyNames      []string
	propertyBoosts     map[string]float32
}

func NewBM25Searcher(config schema.BM25Config, store *lsmkv.Store,
	getClass func(string) *models.Class,
	classSearcher ClassSearcher, stopwordProvider *stopwords.Provider, propLenTracker propLengthRetriever,
	logger logrus.FieldLogger, shardVersion uint16,
) *BM25Searcher {
	return &BM25Searcher{
		config:           config,
		store:            store,
		getClass:         getClass,
		classSearcher:    classSearcher,
		propLenTracker:   propLenTracker,
		logger:           logger.WithField("action", "bm25_search"),
		shardVersion:     shardVersion,
		stopwordProvider: stopwordProvider,
	}
}

// WithTokenizationResolver attaches a [TokenizationResolver] used by query
// input analysis to consult a per-shard tokenization overlay before
// falling back to the schema-stored `prop.Tokenization`. Returns the
// receiver for fluent chaining at construction sites.
//
// Production callers wire `Shard.TokenizationFor` here so a
// change-tokenization migration's FINALIZING-window overlay routes
// query input to the post-swap tokenization. See [TokenizationResolver]
// for the misalignment this closes.
//
// Pass nil (the default) to use the schema-stored value directly.
func (b *BM25Searcher) WithTokenizationResolver(r TokenizationResolver) *BM25Searcher {
	b.tokResolver = r
	return b
}

// WithSearchableBucketPinningResolver: nil (the default) keeps non-pinning behavior.
func (b *BM25Searcher) WithSearchableBucketPinningResolver(
	r SearchableBucketPinningResolver,
) *BM25Searcher {
	b.bucketPinResolver = r
	return b
}

func (b *BM25Searcher) BM25F(ctx context.Context, filterDocIds helpers.AllowList,
	className schema.ClassName, limit int, keywordRanking searchparams.KeywordRanking, additional additional.Properties,
) ([]*storobj.Object, []float32, error) {
	// WEAVIATE-471 - If a property is not searchable, return an error
	for _, property := range keywordRanking.Properties {
		if !PropertyHasSearchableIndex(b.getClass(className.String()), property) {
			return nil, nil, inverted.NewMissingSearchableIndexError(property)
		}
	}

	class := b.getClass(className.String())
	if class == nil {
		return nil, nil, fmt.Errorf("could not find class %s in schema", className)
	}

	var objs []*storobj.Object
	var scores []float32
	var err error

	// TODO: amourao - move this to the global config
	useWand := os.Getenv("USE_BLOCKMAX_WAND") == "false"
	method := "blockmaxwand"
	start := time.Now()
	if useWand {
		objs, scores, err = b.wand(ctx, filterDocIds, class, keywordRanking, limit, additional)
	} else {
		objs, scores, useWand, err = b.wandBlock(ctx, filterDocIds, class, keywordRanking, limit, additional)
	}

	if useWand {
		method = "wand"
	}
	end := time.Since(start)
	if filterDocIds != nil {
		helpers.AnnotateSlowQueryLog(ctx, "kwd_filter_size", filterDocIds.Len())
	}
	helpers.AnnotateSlowQueryLog(ctx, "kwd_method", method)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_time", end)

	if err != nil {
		return nil, nil, errors.Wrap(err, method)
	}

	return objs, scores, nil
}

func (b *BM25Searcher) GetPropertyLengthTracker() *JsonShardMetaData {
	return b.propLenTracker.(*JsonShardMetaData)
}

// queryTerms holds the per-tokenization query terms and per-property boosts
// prepared for a BM25 search. Grouping them lets call sites bind fields by
// name rather than positionally, where the several string-keyed maps are easy
// to transpose.
type queryTerms struct {
	propNamesByTokenization       map[string][]string
	queryTermsByTokenization      map[string][]string
	duplicateBoostsByTokenization map[string][]int
	propertyBoosts                map[string]float32
	// Set only for SearchOperatorAndCross, and only once every searched property
	// is known to tokenize the query the same way. Empty means the operator was
	// not requested or the query has no terms, so the regular path applies.
	crossPropQueryTerms      []string
	crossPropDuplicateBoosts []int
}

// queryStats holds corpus-level BM25 statistics gathered alongside the terms.
type queryStats struct {
	// allBucketsAreInverted is false when any searched bucket is non-inverted,
	// which forces the legacy WAND path instead of BlockMaxWAND.
	allBucketsAreInverted bool
	// n is the total number of documents in the collection (BM25's "N").
	// Approximate (see Bucket.CountApproximate); terms.Idf clamps so an
	// undercount cannot yield a negative idf.
	n                 float64
	averagePropLength float64
}

// Pin lifetime: on SUCCESS the caller owns the pins and MUST defer
// pins.release(); on ERROR they are released here and the caller's
// deferred release no-ops.
func (b *BM25Searcher) generateQueryTermsAndStats(ctx context.Context, class *models.Class, params searchparams.KeywordRanking) (queryTerms, queryStats, *pinnedSearchableBuckets, error) {
	pins := &pinnedSearchableBuckets{}
	failed := true
	defer func() {
		if failed {
			pins.release()
		}
	}()

	// Nil once Store.Shutdown has cleared the bucket map; fail fast.
	objectsBucket := b.store.Bucket(helpers.ObjectsBucketLSM)
	if objectsBucket == nil {
		return queryTerms{}, queryStats{}, pins, fmt.Errorf("objects bucket not available (store shutting down?)")
	}
	count, err := objectsBucket.CountApproximate()
	if err != nil {
		return queryTerms{}, queryStats{}, pins, fmt.Errorf("count objects: %w", err)
	}
	N := float64(count)

	// This flag checks whether all buckets are of the inverted strategy,
	// and thus, compatible with BlockMaxWAND, or if there are other strategies present,
	// which would require the old WAND implementation.
	allBucketsAreInverted := true

	queryTermsByTokenization := map[string][]string{}
	duplicateBoostsByTokenization := map[string][]int{}
	propNamesByTokenization := map[string][]string{}
	propertyBoosts := make(map[string]float32, len(params.Properties))

	// First pass: scan properties to determine which tokenization keys are needed.
	// This avoids eagerly tokenizing the query for all possible tokenizations
	// when only a subset is actually used by the searched properties.
	type propInfo struct {
		name string
		prop *models.Property
		// effectiveTokenization is the active query-time tokenization for
		// this property — either the schema-stored `prop.Tokenization`
		// or the value returned by the per-shard tokenization overlay
		// (see [TokenizationResolver]). Computed once at prop discovery
		// and used everywhere downstream to avoid recomputing the same
		// value across the BM25 pipeline.
		effectiveTokenization string
		tokKey                string
		propMean              float64
		meanValid             bool
	}

	props := make([]propInfo, 0, len(params.Properties))
	seenProps := make(map[string]struct{}, len(params.Properties))
	neededTokenizations := map[string]struct{}{}
	needsASCIIFold := map[string]struct{}{}

	for _, propertyWithBoost := range params.Properties {
		property := propertyWithBoost
		propBoost := float32(1)
		if strings.Contains(propertyWithBoost, "^") {
			property = strings.Split(propertyWithBoost, "^")[0]
			boostStr := strings.Split(propertyWithBoost, "^")[1]
			boost, _ := strconv.ParseFloat(boostStr, 32)
			propBoost = float32(boost)
		}
		propertyBoosts[property] = propBoost

		// Skip duplicates: propertyBoosts already holds the last boost for
		// this property; processing it again would double-count its score.
		if _, dup := seenProps[property]; dup {
			continue
		}
		seenProps[property] = struct{}{}

		propMean, err := b.GetPropertyLengthTracker().PropertyMean(property)
		if err != nil {
			return queryTerms{}, queryStats{}, pins, err
		}

		prop, err := schema.GetPropertyByName(class, property)
		if err != nil {
			return queryTerms{}, queryStats{}, pins, err
		}

		var (
			bucket       *lsmkv.Bucket
			effectiveTok string
		)
		if b.bucketPinResolver != nil {
			var release func()
			// Resolve by the user-supplied name, not prop.Name: a dotted
			// input would otherwise silently search the parent prop's bucket
			// instead of erroring like the non-pinning path.
			effectiveTok, bucket, release = b.bucketPinResolver(property, prop.Tokenization)
			// Record even when bucket==nil so the release still runs.
			pins.add(property, bucket, release)
		} else {
			bucket = b.GetBucket(property)
			effectiveTok = ResolveTokenization(b.tokResolver, prop.Name, prop.Tokenization)
		}
		if bucket == nil {
			return queryTerms{}, queryStats{}, pins, fmt.Errorf("could not find bucket for property %v", property)
		}

		if bucket.Strategy() != lsmkv.StrategyInverted {
			allBucketsAreInverted = false
		}

		switch dt, _ := schema.AsPrimitive(prop.DataType); dt {
		case schema.DataTypeText, schema.DataTypeTextArray:
			tokKey := effectiveTok
			hasCustomStopwords := prop.TextAnalyzer != nil && prop.TextAnalyzer.StopwordPreset != ""
			if prop.TextAnalyzer != nil && prop.TextAnalyzer.ASCIIFold {
				if len(prop.TextAnalyzer.ASCIIFoldIgnore) > 0 || hasCustomStopwords {
					// Per-property key — will be computed after tokenization
					tokKey = asciiTokenizationKey(effectiveTok) + ":" + property
				} else {
					tokKey = asciiTokenizationKey(effectiveTok)
					needsASCIIFold[effectiveTok] = struct{}{}
				}
			} else if hasCustomStopwords {
				// Per-property key for custom stopword preset
				tokKey = effectiveTok + ":" + property
			}
			neededTokenizations[effectiveTok] = struct{}{}

			props = append(props, propInfo{
				name:                  property,
				prop:                  prop,
				effectiveTokenization: effectiveTok,
				tokKey:                tokKey,
				propMean:              float64(propMean),
				meanValid:             !math.IsNaN(float64(propMean)),
			})
		default:
			return queryTerms{}, queryStats{}, pins, fmt.Errorf("cannot handle datatype '%v' of property '%s'", dt, prop.Name)
		}
	}

	// Second pass: tokenize query only for needed tokenizations
	fallbackStopwords := b.stopwordProvider.Fallback()
	for tok := range neededTokenizations {
		var sw tokenizer.StopwordDetector
		if tok == models.PropertyTokenizationWord {
			sw = fallbackStopwords
		}
		tokenTerms, dupBoosts := tokenizer.AnalyzeAndCountDuplicates(params.Query, tok, class.Class, nil, sw)
		queryTermsByTokenization[tok] = tokenTerms
		duplicateBoostsByTokenization[tok] = dupBoosts
		propNamesByTokenization[tok] = make([]string, 0)
	}

	// Prepare ASCII-folded variants only for tokenizations that need them
	foldNoIgnore := tokenizer.NewPreparedAnalyzer(&models.TextAnalyzerConfig{ASCIIFold: true})
	for tok := range needsASCIIFold {
		asciiKey := asciiTokenizationKey(tok)
		var sw tokenizer.StopwordDetector
		if tok == models.PropertyTokenizationWord {
			sw = fallbackStopwords
		}
		asciiTerms, asciiBoosts := tokenizer.AnalyzeAndCountDuplicates(params.Query, tok, class.Class, foldNoIgnore, sw)
		queryTermsByTokenization[asciiKey] = asciiTerms
		duplicateBoostsByTokenization[asciiKey] = asciiBoosts
		propNamesByTokenization[asciiKey] = make([]string, 0)
	}

	// Third pass: assign properties to tokenization keys, compute per-property ignore keys
	averagePropLength := 0.
	averagePropLengthCount := 0
	for _, pi := range props {
		// A NaN here is the result of a corrupted prop length tracker.
		// This is a workaround to try and avoid 0 or NaN scores.
		// There is an extra check below in case all prop lengths are NaN or 0.
		// Related issue https://github.com/weaviate/weaviate/issues/6247
		if pi.meanValid {
			averagePropLength += pi.propMean
			averagePropLengthCount++
		}

		tokKey := pi.tokKey
		hasCustomASCIIFoldIgnore := pi.prop.TextAnalyzer != nil && pi.prop.TextAnalyzer.ASCIIFold && len(pi.prop.TextAnalyzer.ASCIIFoldIgnore) > 0
		hasCustomStopwords := pi.prop.TextAnalyzer != nil && pi.prop.TextAnalyzer.StopwordPreset != ""
		if hasCustomASCIIFoldIgnore || hasCustomStopwords {
			var sw tokenizer.StopwordDetector
			if pi.effectiveTokenization == models.PropertyTokenizationWord {
				d, err := b.stopwordProvider.Get(pi.prop)
				if err != nil {
					return queryTerms{}, queryStats{}, pins, err
				}
				sw = d
			}
			prepared := tokenizer.NewPreparedAnalyzer(pi.prop.TextAnalyzer)
			propTerms, propBoosts := tokenizer.AnalyzeAndCountDuplicates(params.Query, pi.effectiveTokenization, class.Class, prepared, sw)
			queryTermsByTokenization[tokKey] = propTerms
			duplicateBoostsByTokenization[tokKey] = propBoosts
			propNamesByTokenization[tokKey] = make([]string, 0)
		}

		if _, exists := propNamesByTokenization[tokKey]; !exists {
			return queryTerms{}, queryStats{}, pins, fmt.Errorf("cannot handle tokenization '%v' of property '%s'",
				pi.effectiveTokenization, pi.prop.Name)
		}
		propNamesByTokenization[tokKey] = append(propNamesByTokenization[tokKey], pi.name)
	}

	averagePropLength = averagePropLength / float64(averagePropLengthCount)

	// If this value is zero or NaN, the prop length tracker is fully corrupted.
	// This is a workaround to avoid 0 or NaN scores.
	// Related issue https://github.com/weaviate/weaviate/issues/6247
	// sane default, if all prop lengths are NaN or 0
	if math.IsNaN(averagePropLength) || averagePropLength == 0 {
		averagePropLength = 40.0
	}
	// Validated here rather than in either search path so the BlockMax and legacy
	// WAND implementations reject the same queries.
	var crossPropQueryTerms []string
	var crossPropDuplicateBoosts []int
	if params.SearchOperator == common_filters.SearchOperatorAndCross {
		analyzerByTokenization := make(map[string]string, len(props))
		for _, pi := range props {
			analyzerByTokenization[pi.tokKey] = analyzerFingerprint(pi.prop, pi.effectiveTokenization)
		}
		crossPropQueryTerms, crossPropDuplicateBoosts, err = sharedCrossPropQueryTerms(analyzerByTokenization,
			propNamesByTokenization, queryTermsByTokenization, duplicateBoostsByTokenization)
		if err != nil {
			return queryTerms{}, queryStats{}, pins, err
		}
	}

	// Success: the caller now owns the pins; disarm the error-path release.
	failed = false
	return queryTerms{
			propNamesByTokenization:       propNamesByTokenization,
			queryTermsByTokenization:      queryTermsByTokenization,
			duplicateBoostsByTokenization: duplicateBoostsByTokenization,
			propertyBoosts:                propertyBoosts,
			crossPropQueryTerms:           crossPropQueryTerms,
			crossPropDuplicateBoosts:      crossPropDuplicateBoosts,
		}, queryStats{
			allBucketsAreInverted: allBucketsAreInverted,
			n:                     N,
			averagePropLength:     averagePropLength,
		}, pins, nil
}

// analyzerFingerprint identifies the settings that decide how a property tokenizes
// the query. Properties agreeing on it produce the same query terms.
//
// The tokenization must be the effective one, not prop.Tokenization: the per-shard
// overlay can resolve two properties carrying identical schema settings to different
// live analyzers, and those tokenize the same query differently.
func analyzerFingerprint(prop *models.Property, effectiveTokenization string) string {
	asciiFold := false
	stopwordPreset := ""
	var asciiFoldIgnore []string
	if analyzer := prop.TextAnalyzer; analyzer != nil {
		asciiFold, stopwordPreset = analyzer.ASCIIFold, analyzer.StopwordPreset
		asciiFoldIgnore = slices.Clone(analyzer.ASCIIFoldIgnore)
		slices.Sort(asciiFoldIgnore)
	}
	return fmt.Sprintf("%s|asciiFold=%t|asciiFoldIgnore=%s|stopwordPreset=%s",
		effectiveTokenization, asciiFold, strings.Join(asciiFoldIgnore, ","), stopwordPreset)
}

// sharedCrossPropQueryTerms returns the terms every searched property agrees on,
// which cross-property AND needs to merge postings by query-term index.
//
// Compatibility is decided on the analyzer settings rather than on the number of
// tokenization keys, because a property carrying custom stopwords or
// ASCIIFoldIgnore gets a key of its own even when its settings match another's.
// Deciding it on the terms themselves instead would make the operator succeed or
// fail per query, since differently configured properties can still tokenize some
// queries the same way.
//
// The shared list is sorted because terms come out of tokenization in map order
// and a term's index has to mean the same thing in every property.
func sharedCrossPropQueryTerms(analyzerByTokenization map[string]string,
	propNamesByTokenization, queryTermsByTokenization map[string][]string,
	duplicateBoostsByTokenization map[string][]int,
) ([]string, []int, error) {
	var (
		sharedTerms    []string
		sharedAnalyzer string
		boostByTerm    map[string]int
		found          bool
	)
	for tokKey, propNames := range propNamesByTokenization {
		if len(propNames) == 0 {
			continue
		}
		if found {
			if analyzerByTokenization[tokKey] != sharedAnalyzer {
				return nil, nil, fmt.Errorf("%s requires all searched properties to share the same tokenization and analyzer settings",
					common_filters.SearchOperatorAndCross)
			}
			continue
		}

		found, sharedAnalyzer = true, analyzerByTokenization[tokKey]
		sharedTerms = slices.Clone(queryTermsByTokenization[tokKey])
		slices.Sort(sharedTerms)
		boostByTerm = make(map[string]int, len(sharedTerms))
		for i, term := range queryTermsByTokenization[tokKey] {
			boostByTerm[term] = duplicateBoostsByTokenization[tokKey][i]
		}
	}

	sharedBoosts := make([]int, len(sharedTerms))
	for i, term := range sharedTerms {
		sharedBoosts[i] = boostByTerm[term]
	}
	return sharedTerms, sharedBoosts, nil
}

// asciiTokenizationKey returns the composite key used for ascii-insensitive properties.
func asciiTokenizationKey(tokenization string) string {
	return tokenization + ":ascii"
}

func (b *BM25Searcher) wand(
	ctx context.Context, filterDocIds helpers.AllowList, class *models.Class, params searchparams.KeywordRanking, limit int, additional additional.Properties,
) ([]*storobj.Object, []float32, error) {
	start := time.Now()

	qterms, qstats, pins, err := b.generateQueryTermsAndStats(ctx, class, params)
	if err != nil {
		return nil, nil, err
	}
	// A leaked pin would block a future retokenization swap's Shutdown forever.
	defer pins.release()

	return b.wandFromStats(ctx, filterDocIds, params, limit, additional, qterms, qstats, pins, start)
}

// wandFromStats is wand with the query terms/stats precomputed; start feeds
// the slow-query timing annotations. The caller keeps ownership of pins and
// must release them after this returns.
func (b *BM25Searcher) wandFromStats(
	ctx context.Context, filterDocIds helpers.AllowList, params searchparams.KeywordRanking, limit int, additional additional.Properties, qterms queryTerms, qstats queryStats, pins *pinnedSearchableBuckets, start time.Time,
) ([]*storobj.Object, []float32, error) {
	allRequests := make([]termListRequest, 0, 1000)
	allQueryTerms := make([]string, 0, 1000)
	minimumOrTokensMatch := math.MaxInt64

	if len(qterms.crossPropQueryTerms) > 0 {
		// One request per shared term spanning every searched property, so a term is
		// required once globally. Emitting per tokenization group instead would raise
		// the term count without raising the threshold, letting a document satisfy the
		// AND by matching one term in two groups and never matching the others.
		propNames := make([]string, 0, len(params.Properties))
		for _, groupPropNames := range qterms.propNamesByTokenization {
			propNames = append(propNames, groupPropNames...)
		}
		slices.Sort(propNames)

		for queryTermIndex, queryTerm := range qterms.crossPropQueryTerms {
			allRequests = append(allRequests, termListRequest{
				term:               queryTerm,
				termId:             len(allRequests),
				duplicateTextBoost: qterms.crossPropDuplicateBoosts[queryTermIndex],
				propertyNames:      propNames,
				propertyBoosts:     qterms.propertyBoosts,
			})
			allQueryTerms = append(allQueryTerms, queryTerm)
		}
		minimumOrTokensMatch = len(qterms.crossPropQueryTerms)
		helpers.AnnotateSlowQueryLog(ctx, "kwd_2_terms_cross_prop", len(qterms.crossPropQueryTerms))
	} else {
		for tokenization, propNames := range qterms.propNamesByTokenization {
			if len(propNames) > 0 {
				tokenTerms, duplicateBoosts := qterms.queryTermsByTokenization[tokenization], qterms.duplicateBoostsByTokenization[tokenization]
				for queryTermIndex, queryTerm := range tokenTerms {
					allRequests = append(allRequests, termListRequest{
						term:               queryTerm,
						termId:             len(allRequests),
						duplicateTextBoost: duplicateBoosts[queryTermIndex],
						propertyNames:      propNames,
						propertyBoosts:     qterms.propertyBoosts,
					})
					allQueryTerms = append(allQueryTerms, queryTerm)
				}
				minimumOrTokensMatchByTokenization := params.MinimumOrTokensMatch
				if common_filters.IsAndOperator(params.SearchOperator) {
					minimumOrTokensMatchByTokenization = len(tokenTerms)
				}
				if minimumOrTokensMatchByTokenization < minimumOrTokensMatch {
					minimumOrTokensMatch = minimumOrTokensMatchByTokenization
				}
				helpers.AnnotateSlowQueryLog(ctx, "kwd_2_terms_"+tokenization, len(tokenTerms))
			}
		}
	}

	tokenizationTime := time.Since(start)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_1_tok_time", tokenizationTime)
	start = time.Now()
	results := make([]*terms.Term, len(allRequests))

	eg := enterrors.NewErrorGroupWrapper(b.logger)
	eg.SetLimit(_NUMCPU)

	for _, request := range allRequests {
		term := request.term
		termId := request.termId
		propNames := request.propertyNames
		duplicateBoost := request.duplicateTextBoost

		eg.Go(func() (err error) {
			defer func() {
				p := recover()
				if p != nil {
					b.logger.
						WithField("query_term", term).
						WithField("prop_names", propNames).
						WithField("has_filter", filterDocIds != nil).
						WithField("print_stack", string(debug.Stack())).
						Errorf("panic: %v", p)
					err = fmt.Errorf("an internal error occurred during BM25 search")
				}
			}()

			termResult, termErr := b.createTerm(qstats.n, filterDocIds, term, termId, propNames, qterms.propertyBoosts, duplicateBoost, pins, ctx)
			if termErr != nil {
				err = termErr
				return err
			}
			results[termId] = termResult
			return err
		})
	}

	if err := eg.Wait(); err != nil {
		return nil, nil, err
	}

	if ctx.Err() != nil {
		return nil, nil, fmt.Errorf("after createTerm: %w", ctx.Err())
	}

	// all results. Sum up the length of the results from all terms to get an upper bound of how many results there are
	if limit == 0 {
		for _, res := range results {
			if res != nil {
				limit += len(res.Data)
			}
		}
	}

	resultsNonNil := make([]terms.TermInterface, 0, len(results))
	for _, res := range results {
		if res != nil {
			resultsNonNil = append(resultsNonNil, res)
		}
	}

	combinedTerms := &terms.Terms{
		T:     resultsNonNil,
		Count: len(allRequests),
	}

	termSearchTime := time.Since(start)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_3_term_time", termSearchTime)
	start = time.Now()
	topKHeap := lsmkv.DoWand(ctx, limit, combinedTerms, qstats.averagePropLength, params.AdditionalExplanations, minimumOrTokensMatch, b.logger)

	wandTime := time.Since(start)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_4_wand_time", wandTime)

	if ctx.Err() != nil {
		return nil, nil, fmt.Errorf("after DoWand: %w", ctx.Err())
	}

	start = time.Now()
	objects, scores, err := b.getTopKObjects(topKHeap, params.AdditionalExplanations, allQueryTerms, additional)

	fetchTime := time.Since(start)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_5_objects_time", fetchTime)
	helpers.AnnotateSlowQueryLog(ctx, "kwd_6_res_count", len(objects))
	return objects, scores, err
}

func (b *BM25Searcher) getTopKObjects(topKHeap *priorityqueue.Queue[[]*terms.DocPointerWithScore], additionalExplanations bool,
	allRequests []string, additional additional.Properties,
) ([]*storobj.Object, []float32, error) {
	// Nil once Store.Shutdown has cleared the bucket map; fail fast.
	objectsBucket := b.store.Bucket(helpers.ObjectsBucketLSM)
	if objectsBucket == nil {
		return nil, nil, errors.New("objects bucket not available (store shutting down?)")
	}
	scores := make([]float32, 0, topKHeap.Len())
	ids := make([]uint64, 0, topKHeap.Len())
	explanations := make([][]*terms.DocPointerWithScore, 0, topKHeap.Len())
	for topKHeap.Len() > 0 {
		res := topKHeap.Pop()
		ids = append(ids, res.ID)
		scores = append(scores, res.Dist)
		explanations = append(explanations, res.Value)
	}

	objs, err := storobj.ObjectsByDocIDWithEmpty(objectsBucket, ids, additional, nil, b.logger)
	if err != nil {
		return objs, nil, errors.Errorf("objects loading")
	}

	// handle case that an object was removed
	j := 0
	for i := range scores {
		if objs[i] == nil || objs[i].DocID != ids[i] {
			continue
		}
		scores[j] = scores[i]
		objs[j] = objs[i]
		j++
	}
	scores = scores[:j]
	objs = objs[:j]

	if additionalExplanations {
		for k := range objs {
			// add score explanation
			if objs[k].AdditionalProperties() == nil {
				objs[k].Object.Additional = make(map[string]interface{})
			}
			for j, result := range explanations[k] {
				if result == nil {
					continue
				}
				queryTerm := allRequests[j]
				objs[k].Object.Additional["BM25F_"+queryTerm+"_frequency"] = result.Frequency
				objs[k].Object.Additional["BM25F_"+queryTerm+"_propLength"] = result.PropLength
			}
		}
	}

	objs, scores = b.sortResultsByExternalId(objs, scores)

	return objs, scores, nil
}

func (b *BM25Searcher) getTopKIds(topKHeap *priorityqueue.Queue[[]*terms.DocPointerWithScore]) ([]uint64, []float32, [][]*terms.DocPointerWithScore, error) {
	scores := make([]float32, 0, topKHeap.Len())
	ids := make([]uint64, 0, topKHeap.Len())
	explanations := make([][]*terms.DocPointerWithScore, 0, topKHeap.Len())
	for topKHeap.Len() > 0 {
		res := topKHeap.Pop()
		ids = append(ids, res.ID)
		scores = append(scores, res.Dist)
		if res.Value != nil {
			explanations = append(explanations, res.Value)
		}
	}
	return ids, scores, explanations, nil
}

func (b *BM25Searcher) createTerm(N float64, filterDocIds helpers.AllowList, query string, queryTermIndex int, propertyNames []string, propertyBoosts map[string]float32, duplicateTextBoost int, pins *pinnedSearchableBuckets, ctx context.Context) (*terms.Term, error) {
	termResult := terms.NewTerm(query, queryTermIndex, float32(1.0), b.config)

	var filteredDocIDs *sroar.Bitmap
	var filteredDocIDsThread []*sroar.Bitmap
	if filterDocIds != nil {
		filteredDocIDs = sroar.NewBitmap() // to build the global n if there is a filter
		filteredDocIDsThread = make([]*sroar.Bitmap, len(propertyNames))
	}

	eg := enterrors.NewErrorGroupWrapper(b.logger)
	eg.SetLimit(_NUMCPU)

	allMsAndProps := make([][]terms.DocPointerWithScore, len(propertyNames))
	for i, propName := range propertyNames {
		i := i
		propName := propName

		eg.Go(
			func() error {
				// Reuse the bucket pinned at prop discovery — a by-name
				// re-fetch could land on the post-swap bucket or a freed mmap.
				bucket, pinned := pins.bucketFor(propName)
				if !pinned {
					bucket = b.store.Bucket(helpers.BucketSearchableFromPropNameLSM(propName))
				}
				if bucket == nil {
					return fmt.Errorf("could not find bucket for property %v", propName)
				}
				preM, err := bucket.DocPointerWithScoreList(ctx, []byte(query), propertyBoosts[propName])
				if err != nil {
					return err
				}

				var m []terms.DocPointerWithScore
				if filterDocIds != nil {
					if filteredDocIDsThread[i] == nil {
						filteredDocIDsThread[i] = sroar.NewBitmap()
					}
					m = make([]terms.DocPointerWithScore, 0, len(preM))
					for _, val := range preM {
						docID := val.Id
						if filterDocIds.Contains(docID) {
							m = append(m, val)
						} else {
							filteredDocIDsThread[i].Set(docID)
						}
					}
				} else {
					m = preM
				}

				allMsAndProps[i] = m
				return nil
			},
		)
	}
	if err := eg.Wait(); err != nil {
		return termResult, err
	}

	if ctx.Err() != nil {
		return termResult, fmt.Errorf("after DocPointerWithScoreList: %w", ctx.Err())
	}

	if filterDocIds != nil {
		mergeConc := concurrency.BudgetFromCtxCapped(ctx, concurrency.SROAR_MERGE)
		for _, docIDs := range filteredDocIDsThread {
			if docIDs != nil {
				filteredDocIDs.OrConc(docIDs, mergeConc)
			}
		}
	}

	largestN := 0
	// remove empty results from allMsAndProps
	nonEmptyMsAndProps := make([][]terms.DocPointerWithScore, 0, len(allMsAndProps))
	for _, m := range allMsAndProps {
		if len(m) > 0 {
			nonEmptyMsAndProps = append(nonEmptyMsAndProps, m)
		}
		if len(m) > largestN {
			largestN = len(m)
		}
	}
	allMsAndProps = nonEmptyMsAndProps

	if len(nonEmptyMsAndProps) == 0 {
		return nil, nil
	}

	if len(nonEmptyMsAndProps) == 1 {
		termResult.Data = allMsAndProps[0]
		n := float64(len(termResult.Data))
		if filterDocIds != nil {
			n += float64(filteredDocIDs.GetCardinality())
		}
		termResult.SetIdf(terms.Idf(n, N) * float64(duplicateTextBoost))
		termResult.SetPosPointer(0)
		termResult.SetIdPointer(termResult.Data[0].Id)
		return termResult, nil
	}
	indices := make([]int, len(allMsAndProps))
	var docMapPairs []terms.DocPointerWithScore = nil

	// The indices are needed to combining the results of different properties
	// They were previously used to keep track of additional explanations TF and prop len,
	// but this is now done when adding terms to the heap in the getTopKHeap function
	var docMapPairsIndices map[uint64]int = nil
	for {
		i := -1
		minId := uint64(0)
		for ti, mAndProps := range allMsAndProps {
			if indices[ti] >= len(mAndProps) {
				continue
			}
			ki := mAndProps[indices[ti]].Id
			if i == -1 || ki < minId {
				i = ti
				minId = ki
			}
		}

		if i == -1 {
			break
		}

		m := allMsAndProps[i]
		k := indices[i]
		val := m[indices[i]]

		indices[i]++

		// only create maps/slices if we know how many entries there are
		if docMapPairs == nil {
			docMapPairs = make([]terms.DocPointerWithScore, 0, largestN)
			docMapPairsIndices = make(map[uint64]int, largestN)

			docMapPairs = append(docMapPairs, val)
			docMapPairsIndices[val.Id] = k
		} else {
			key := val.Id
			ind, ok := docMapPairsIndices[key]
			if ok {
				if ind >= len(docMapPairs) {
					// the index is not valid anymore, but the key is still in the map
					b.logger.Warnf("Skipping pair in BM25: Index %d is out of range for key %d, length %d.", ind, key, len(docMapPairs))
					continue
				}
				if ind < len(docMapPairs) && docMapPairs[ind].Id != key {
					b.logger.Warnf("Skipping pair in BM25: id at %d in doc map pairs, %d, differs from current key, %d", ind, docMapPairs[ind].Id, key)
					continue
				}

				docMapPairs[ind].PropLength += val.PropLength
				docMapPairs[ind].Frequency += val.Frequency
			} else {
				docMapPairs = append(docMapPairs, val)
				docMapPairsIndices[val.Id] = len(docMapPairs) - 1 // current last entry
			}

		}
	}
	if docMapPairs == nil {
		return nil, nil
	}
	termResult.Data = docMapPairs

	n := float64(len(docMapPairs))
	if filterDocIds != nil {
		n += float64(filteredDocIDs.GetCardinality())
	}
	termResult.SetIdf(terms.Idf(n, N) * float64(duplicateTextBoost))

	// catch special case where there are no results and would panic termResult.data[0].id
	// related to #4125
	if len(termResult.Data) == 0 {
		return nil, nil
	}

	termResult.SetPosPointer(0)
	termResult.SetIdPointer(termResult.Data[0].Id)
	return termResult, nil
}

func PropertyHasSearchableIndex(class *models.Class, tentativePropertyName string) bool {
	if class == nil {
		return false
	}

	propertyName := strings.Split(tentativePropertyName, "^")[0]
	p, err := schema.GetPropertyByName(class, propertyName)
	if err != nil {
		return false
	}
	return HasSearchableIndex(p)
}

func (b *BM25Searcher) GetBucket(propName string) *lsmkv.Bucket {
	return b.store.Bucket(helpers.BucketSearchableFromPropNameLSM(propName))
}
