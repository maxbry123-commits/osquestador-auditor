//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	"fmt"
	"path/filepath"

	"github.com/pkg/errors"
	"go.etcd.io/bbolt"

	"github.com/sirupsen/logrus"
	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv"
	vcommon "github.com/weaviate/weaviate/adapters/repos/db/vector/common"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/dynamic"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/flat"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/hfresh"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/hnsw"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/hnsw/distancer"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/noop"
	entlsmkv "github.com/weaviate/weaviate/entities/lsmkv"
	schemaConfig "github.com/weaviate/weaviate/entities/schema/config"
	"github.com/weaviate/weaviate/entities/vectorindex"
	"github.com/weaviate/weaviate/entities/vectorindex/common"
	dynamicent "github.com/weaviate/weaviate/entities/vectorindex/dynamic"
	flatent "github.com/weaviate/weaviate/entities/vectorindex/flat"
	hfreshent "github.com/weaviate/weaviate/entities/vectorindex/hfresh"
	hnswent "github.com/weaviate/weaviate/entities/vectorindex/hnsw"
)

func (s *Shard) initShardVectors(ctx context.Context) error {
	// Snapshot under the index config lock: updateVectorIndexConfig(s) mutate
	// these concurrently, and ranging the live map is a fatal
	// "concurrent map read and map write", not a recoverable race.
	legacy := s.index.GetVectorIndexConfig("")
	targets := s.index.getTargetVectorIndexConfigs()

	if legacy != nil {
		if err := s.initLegacyVector(ctx, legacy, s.lazySegmentLoadingEnabled); err != nil {
			return err
		}
	}

	if err := s.initTargetVectors(ctx, legacy, targets, s.lazySegmentLoadingEnabled); err != nil {
		return err
	}

	return nil
}

func (s *Shard) initVectorIndex(ctx context.Context,
	targetVector string, vectorIndexUserConfig schemaConfig.VectorIndexConfig, lazyLoadSegments bool,
) (VectorIndex, error) {
	var distProv distancer.Provider

	switch vectorIndexUserConfig.DistanceName() {
	case "", common.DistanceCosine:
		distProv = distancer.NewCosineDistanceProvider()
	case common.DistanceDot:
		distProv = distancer.NewDotProductProvider()
	case common.DistanceL2Squared:
		distProv = distancer.NewL2SquaredProvider()
	case common.DistanceManhattan:
		distProv = distancer.NewManhattanProvider()
	case common.DistanceHamming:
		distProv = distancer.NewHammingProvider()
	default:
		return nil, fmt.Errorf("init vector index: %w",
			errors.Errorf("unrecognized distance metric %q,"+
				"choose one of [\"cosine\", \"dot\", \"l2-squared\", \"manhattan\",\"hamming\"]", vectorIndexUserConfig.DistanceName()))
	}

	var vectorIndex VectorIndex

	makeBucketOptions := s.makeDefaultBucketOptions
	if lazyLoadSegments != s.lazySegmentLoadingEnabled {
		makeBucketOptions = s.overwrittenMakeDefaultBucketOptions(lsmkv.WithLazySegmentLoading(lazyLoadSegments))
	}

	switch vectorIndexUserConfig.IndexType() {
	case vectorindex.VectorIndexTypeHNSW:
		hnswUserConfig, ok := vectorIndexUserConfig.(hnswent.UserConfig)
		if !ok {
			return nil, errors.Errorf("hnsw vector index: config is not hnsw.UserConfig: %T",
				vectorIndexUserConfig)
		}

		if hnswUserConfig.Skip {
			vectorIndex = noop.NewIndex()
		} else {
			// starts vector cycles if vector is configured
			s.index.cycleCallbacks.vectorCommitLoggerCycle.Start()
			s.index.cycleCallbacks.vectorTombstoneCleanupCycle.Start()

			// a shard can actually have multiple vector indexes:
			// - the main index, which is used for all normal object vectors
			// - a geo property index for each geo prop in the schema
			//
			// here we label the main vector index as such.
			vecIdxID := s.vectorIndexID(targetVector)

			vi, err := hnsw.New(hnsw.Config{
				Logger:                            s.index.logger,
				RootPath:                          s.path(),
				ID:                                vecIdxID,
				ShardName:                         s.name,
				ClassName:                         s.index.Config.ClassName.String(),
				PrometheusMetrics:                 s.promMetrics,
				VectorForIDThunk:                  hnsw.NewVectorForIDThunk(targetVector, s.vectorByIndexID),
				MultiVectorForIDThunk:             hnsw.NewVectorForIDThunk(targetVector, s.multiVectorByIndexID),
				TempMultiVectorForIDThunk:         hnsw.NewTempMultiVectorForIDThunk(targetVector, s.readMultiVectorByIndexIDIntoSlice),
				GetViewThunk:                      func() vcommon.BucketView { return s.GetObjectsBucketView() },
				TempVectorForIDWithViewThunk:      hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readVectorByIndexIDIntoSliceWithView),
				TempMultiVectorForIDWithViewThunk: hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readMultiVectorByIndexIDIntoSliceWithView),
				DistanceProvider:                  distProv,
				MakeCommitLoggerThunk: func(opts ...hnsw.CommitlogOption) (hnsw.CommitLogger, error) {
					// Prepend our default options, caller's opts take precedence
					allOpts := append([]hnsw.CommitlogOption{
						// consistent with previous logic where the individual limit is 1/5 of the combined limit
						hnsw.WithCommitlogThreshold(s.index.Config.HNSWMaxLogSize / 5),
					}, opts...)
					return hnsw.NewCommitLogger(s.path(), vecIdxID,
						s.index.logger, s.cycleCallbacks.vectorCommitLoggerCallbacks,
						allOpts...,
					)
				},
				AllocChecker:           s.index.allocChecker,
				WaitForCachePrefill:    s.index.Config.HNSWWaitForCachePrefill,
				FlatSearchConcurrency:  s.index.Config.HNSWFlatSearchConcurrency,
				AcornFilterRatio:       s.index.Config.HNSWAcornFilterRatio,
				VisitedListPoolMaxSize: s.index.Config.VisitedListPoolMaxSize,
				MakeBucketOptions:      makeBucketOptions,
				AsyncIndexingEnabled:   s.index.AsyncIndexingEnabled,
			}, hnswUserConfig, s.cycleCallbacks.vectorTombstoneCleanupCallbacks, s.store)
			if err != nil {
				return nil, errors.Wrapf(err, "init shard %q: hnsw index", s.ID())
			}
			vectorIndex = vi
		}
	case vectorindex.VectorIndexTypeFLAT:
		flatUserConfig, ok := vectorIndexUserConfig.(flatent.UserConfig)
		if !ok {
			return nil, errors.Errorf("flat vector index: config is not flat.UserConfig: %T",
				vectorIndexUserConfig)
		}
		s.index.cycleCallbacks.vectorCommitLoggerCycle.Start()

		// a shard can actually have multiple vector indexes:
		// - the main index, which is used for all normal object vectors
		// - a geo property index for each geo prop in the schema
		//
		// here we label the main vector index as such.
		vecIdxID := s.vectorIndexID(targetVector)

		vi, err := flat.New(flat.Config{
			ID:                vecIdxID,
			TargetVector:      targetVector,
			RootPath:          s.path(),
			Logger:            s.index.logger,
			DistanceProvider:  distProv,
			AllocChecker:      s.index.allocChecker,
			MakeBucketOptions: makeBucketOptions,
		}, flatUserConfig, s.store)
		if err != nil {
			return nil, errors.Wrapf(err, "init shard %q: flat index", s.ID())
		}
		vectorIndex = vi
	case vectorindex.VectorIndexTypeDYNAMIC:
		dynamicUserConfig, ok := vectorIndexUserConfig.(dynamicent.UserConfig)
		if !ok {
			return nil, errors.Errorf("dynamic vector index: config is not dynamic.UserConfig: %T",
				vectorIndexUserConfig)
		}
		s.index.cycleCallbacks.vectorCommitLoggerCycle.Start()
		s.index.cycleCallbacks.vectorTombstoneCleanupCycle.Start()

		// a shard can actually have multiple vector indexes:
		// - the main index, which is used for all normal object vectors
		// - a geo property index for each geo prop in the schema
		//
		// here we label the main vector index as such.
		vecIdxID := s.vectorIndexID(targetVector)

		sharedDB, err := s.getOrInitDynamicVectorIndexDB()
		if err != nil {
			return nil, errors.Wrapf(err, "init shard %q: dynamic index", s.ID())
		}

		vi, err := dynamic.New(dynamic.Config{
			ID:                           vecIdxID,
			TargetVector:                 targetVector,
			Logger:                       s.index.logger,
			DistanceProvider:             distProv,
			RootPath:                     s.path(),
			ShardName:                    s.name,
			ClassName:                    s.index.Config.ClassName.String(),
			PrometheusMetrics:            s.promMetrics,
			VectorForIDThunk:             hnsw.NewVectorForIDThunk(targetVector, s.vectorByIndexID),
			GetViewThunk:                 func() vcommon.BucketView { return s.GetObjectsBucketView() },
			TempVectorForIDWithViewThunk: hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readVectorByIndexIDIntoSliceWithView),
			MakeCommitLoggerThunk: func(opts ...hnsw.CommitlogOption) (hnsw.CommitLogger, error) {
				// Prepend our default options, caller's opts take precedence
				allOpts := append([]hnsw.CommitlogOption{
					// consistent with previous logic where the individual limit is 1/5 of the combined limit
					hnsw.WithCommitlogThreshold(s.index.Config.HNSWMaxLogSize / 5),
				}, opts...)
				return hnsw.NewCommitLogger(s.path(), vecIdxID,
					s.index.logger, s.cycleCallbacks.vectorCommitLoggerCallbacks,
					allOpts...,
				)
			},
			TombstoneCallbacks:   s.cycleCallbacks.vectorTombstoneCleanupCallbacks,
			SharedDB:             sharedDB,
			AllocChecker:         s.index.allocChecker,
			MakeBucketOptions:    makeBucketOptions,
			AsyncIndexingEnabled: s.index.AsyncIndexingEnabled,
		}, dynamicUserConfig, s.store)
		if err != nil {
			return nil, errors.Wrapf(err, "init shard %q: dynamic index", s.ID())
		}
		vectorIndex = vi
	case vectorindex.VectorIndexTypeHFresh:
		if !s.index.HFreshEnabled {
			return nil, errors.New("hfresh index is available only in experimental mode")
		}
		userConfig, ok := vectorIndexUserConfig.(hfreshent.UserConfig)
		if !ok {
			return nil, errors.Errorf("hfresh vector index: config is not hfresh.UserConfig: %T",
				vectorIndexUserConfig)
		}

		s.index.cycleCallbacks.vectorCommitLoggerCycle.Start()
		s.index.cycleCallbacks.vectorTombstoneCleanupCycle.Start()

		hfreshConfigID := s.vectorIndexID(targetVector)
		rootPath := filepath.Join(s.path(), helpers.HFreshDirName(hfreshConfigID))

		hfreshConfig := &hfresh.Config{
			Logger:            s.index.logger,
			Scheduler:         s.index.scheduler,
			DistanceProvider:  distProv,
			RootPath:          rootPath,
			ID:                hfreshConfigID,
			TargetVector:      targetVector,
			ShardName:         s.name,
			ClassName:         s.index.Config.ClassName.String(),
			PrometheusMetrics: s.promMetrics,
			Store: hfresh.StoreConfig{
				MakeBucketOptions: makeBucketOptions,
			},
			VectorForIDThunk:             hnsw.NewVectorForIDThunk(targetVector, s.vectorByIndexID),
			MultiVectorForIDThunk:        hnsw.NewVectorForIDThunk(targetVector, s.multiVectorByIndexID),
			TempVectorForIDWithViewThunk: hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readVectorByIndexIDIntoSliceWithView),
			TombstoneCallbacks:           s.cycleCallbacks.vectorTombstoneCleanupCallbacks,
			Centroids: hfresh.CentroidConfig{
				HNSWConfig: &hnsw.Config{
					Logger:                            s.index.logger,
					RootPath:                          rootPath,
					ID:                                hfreshConfigID + "_centroids",
					ShardName:                         s.name,
					ClassName:                         s.index.Config.ClassName.String(),
					PrometheusMetrics:                 s.promMetrics,
					HFreshMode:                        true,
					TempMultiVectorForIDThunk:         hnsw.NewTempMultiVectorForIDThunk(targetVector, s.readMultiVectorByIndexIDIntoSlice),
					GetViewThunk:                      func() vcommon.BucketView { return s.GetObjectsBucketView() },
					TempVectorForIDWithViewThunk:      hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readVectorByIndexIDIntoSliceWithView),
					TempMultiVectorForIDWithViewThunk: hnsw.NewTempVectorForIDWithViewThunk(targetVector, s.readMultiVectorByIndexIDIntoSliceWithView),
					DistanceProvider:                  distProv,
					MakeCommitLoggerThunk: func(opts ...hnsw.CommitlogOption) (hnsw.CommitLogger, error) {
						// Prepend our default options, caller's opts take precedence
						allOpts := append([]hnsw.CommitlogOption{
							// consistent with previous logic where the individual limit is 1/5 of the combined limit
							hnsw.WithCommitlogThreshold(s.index.Config.HNSWMaxLogSize / 5),
						}, opts...)
						return hnsw.NewCommitLogger(rootPath, hfreshConfigID+"_centroids",
							s.index.logger, s.cycleCallbacks.vectorCommitLoggerCallbacks,
							allOpts...,
						)
					},
					AllocChecker:           s.index.allocChecker,
					WaitForCachePrefill:    s.index.Config.HNSWWaitForCachePrefill,
					FlatSearchConcurrency:  s.index.Config.HNSWFlatSearchConcurrency,
					AcornFilterRatio:       s.index.Config.HNSWAcornFilterRatio,
					VisitedListPoolMaxSize: s.index.Config.VisitedListPoolMaxSize,
					MakeBucketOptions:      makeBucketOptions,
				},
			},
		}

		vi, err := hfresh.New(hfreshConfig, userConfig, s.store)
		if err != nil {
			return nil, errors.Wrapf(err, "init shard %q: hfresh index", s.ID())
		}
		vectorIndex = vi
	default:
		return nil, fmt.Errorf("unknown vector index type: %q. Choose one from [\"%s\", \"%s\", \"%s\", \"%s\"]",
			vectorIndexUserConfig.IndexType(), vectorindex.VectorIndexTypeHNSW, vectorindex.VectorIndexTypeFLAT, vectorindex.VectorIndexTypeDYNAMIC, vectorindex.VectorIndexTypeHFresh)
	}
	defer vectorIndex.PostStartup(s.shutCtx)
	return vectorIndex, nil
}

func (s *Shard) getOrInitDynamicVectorIndexDB() (*bbolt.DB, error) {
	if s.dynamicVectorIndexDB == nil {
		path := filepath.Join(s.path(), dynamicent.StateDBFileName)

		// Timeout: a leaked handle from a failed shard teardown holds the flock;
		// without it this open retries forever and wedges the loading goroutine.
		db, err := bbolt.Open(path, 0o600, &bbolt.Options{Timeout: entlsmkv.BoltFlockTimeout})
		if err != nil {
			return nil, errors.Wrapf(err, "open %q", path)
		}

		s.dynamicVectorIndexDB = db
	}

	return s.dynamicVectorIndexDB, nil
}

// initTargetVectors builds the named target-vector indexes. legacy and configs
// are caller-held snapshots; the migrator needs legacy to tell a
// single-named-vector layout from a legacy-plus-named one.
func (s *Shard) initTargetVectors(ctx context.Context, legacy schemaConfig.VectorIndexConfig,
	configs map[string]schemaConfig.VectorIndexConfig, lazyLoadSegments bool,
) error {
	s.vectorIndexMu.Lock()
	defer s.vectorIndexMu.Unlock()

	if err := newCompressedVectorsMigrator(s.index.logger).do(s, legacy, configs); err != nil {
		s.index.logger.WithFields(logrus.Fields{
			"action":   "init_target_vectors",
			"shard_id": s.ID(),
		}).Errorf("failed to migrate vectors compressed folder: %v", err)
	}

	s.vectorIndexes = make(map[string]VectorIndex, len(configs))
	s.queues = make(map[string]*VectorIndexQueue, len(configs))

	for targetVector, vectorIndexConfig := range configs {
		if err := s.initTargetVectorWithLock(ctx, targetVector, vectorIndexConfig, lazyLoadSegments); err != nil {
			return err
		}
	}
	return nil
}

func (s *Shard) initTargetVector(ctx context.Context, targetVector string, cfg schemaConfig.VectorIndexConfig, lazyLoadSegments bool) error {
	s.vectorIndexMu.Lock()
	defer s.vectorIndexMu.Unlock()
	return s.initTargetVectorWithLock(ctx, targetVector, cfg, lazyLoadSegments)
}

func (s *Shard) initTargetVectorWithLock(ctx context.Context, targetVector string, cfg schemaConfig.VectorIndexConfig, lazyLoadSegments bool) error {
	// Recreating an existing target would orphan the current index+queue (never
	// Dropped). Returning early also makes concurrent UpdateVectorIndexConfigs
	// calls that both saw the target absent safe.
	if _, exists := s.vectorIndexes[targetVector]; exists {
		return nil
	}

	vectorIndex, err := s.initVectorIndex(ctx, targetVector, cfg, lazyLoadSegments)
	if err != nil {
		return fmt.Errorf("cannot create vector index for %q: %w", targetVector, err)
	}
	queue, err := NewVectorIndexQueue(s, targetVector, vectorIndex)
	if err != nil {
		if shutdownErr := vectorIndex.Shutdown(s.shutCtx); shutdownErr != nil {
			return fmt.Errorf("cannot create index queue for %q: %w (shutting down the orphaned vector index also failed: %w)",
				targetVector, err, shutdownErr)
		}
		return fmt.Errorf("cannot create index queue for %q: %w", targetVector, err)
	}

	s.vectorIndexes[targetVector] = vectorIndex
	s.queues[targetVector] = queue
	return nil
}

func (s *Shard) initLegacyVector(ctx context.Context, cfg schemaConfig.VectorIndexConfig, lazyLoadSegments bool) error {
	s.vectorIndexMu.Lock()
	defer s.vectorIndexMu.Unlock()

	vectorIndex, err := s.initVectorIndex(ctx, "", cfg, lazyLoadSegments)
	if err != nil {
		return err
	}

	queue, err := NewVectorIndexQueue(s, "", vectorIndex)
	if err != nil {
		if shutdownErr := vectorIndex.Shutdown(s.shutCtx); shutdownErr != nil {
			return fmt.Errorf("%w (shutting down the orphaned vector index also failed: %w)", err, shutdownErr)
		}
		return err
	}
	s.vectorIndex = vectorIndex
	s.queue = queue
	return nil
}

func (s *Shard) setVectorIndex(targetVector string, index VectorIndex) {
	s.vectorIndexMu.Lock()
	defer s.vectorIndexMu.Unlock()

	if targetVector == "" {
		s.vectorIndex = index
	} else {
		s.vectorIndexes[targetVector] = index
	}
}

// perVectorDropper is implemented by index types whose Drop() would reach
// beyond the one vector being dropped. Only dynamic needs it today: its state
// DB is shared across the shard, so Drop's Close()+Remove would take every
// sibling's state with it.
type perVectorDropper interface {
	DropTargetVector(ctx context.Context) error
}

// dropOneVectorIndex tears down a single named vector's index. Index types that
// own nothing shard-wide fall through to Drop(keepFiles=false), which is the
// same thing for them; the interface exists so a type that DOES own shared
// state has somewhere to say so, rather than the caller having to know which
// types are special.
func dropOneVectorIndex(ctx context.Context, index VectorIndex) error {
	if d, ok := index.(perVectorDropper); ok {
		return d.DropTargetVector(ctx)
	}
	return index.Drop(ctx, false)
}

// DropVectorIndex shuts down and removes the named vector index and its queue
// from this shard, deleting associated files from disk. It also removes the
// LSM buckets that store the raw and compressed vector data.
func (s *Shard) DropVectorIndex(ctx context.Context, targetVector string) error {
	s.vectorIndexMu.Lock()
	defer s.vectorIndexMu.Unlock()

	if queue, ok := s.queues[targetVector]; ok && queue != nil {
		if err := queue.Drop(ctx); err != nil {
			return fmt.Errorf("drop queue for vector %q: %w", targetVector, err)
		}
		delete(s.queues, targetVector)
	}

	if index, ok := s.vectorIndexes[targetVector]; ok && index != nil {
		if err := dropOneVectorIndex(ctx, index); err != nil {
			return fmt.Errorf("drop vector index %q: %w", targetVector, err)
		}
		delete(s.vectorIndexes, targetVector)
	}

	// Remove every on-disk artifact this vector owns — the raw and compressed
	// buckets, the multivector ones (muvera OR mv_mappings), and hfresh's
	// directory and buckets. The set lives in helpers so the live drop, the
	// file sweep and the tests cannot drift apart; passing the collection's
	// other vector names is what stops a sibling being deleted when its own
	// bucket collides with one of this target's artifact names.
	artifacts := helpers.VectorIndexArtifactsFor(targetVector,
		otherTargetVectors(s.class, targetVector))
	for _, bucket := range artifacts.LSMBuckets {
		if err := s.removeBucket(ctx, bucket); err != nil {
			return fmt.Errorf("drop bucket %q for vector %q: %w", bucket, targetVector, err)
		}
	}
	for _, dir := range artifacts.ShardDirs {
		if err := s.removeDirIfExists(s.path(), dir); err != nil {
			return fmt.Errorf("drop directory %q for vector %q: %w", dir, targetVector, err)
		}
	}

	// Remove the index checkpoint entry for this vector.
	if s.indexCheckpoints != nil {
		if err := s.indexCheckpoints.Delete(s.ID(), targetVector); err != nil {
			return fmt.Errorf("delete checkpoint for vector %q: %w", targetVector, err)
		}
	}

	return nil
}
