//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/weaviate/weaviate/adapters/repos/db/indexcheckpoint"
	"github.com/weaviate/weaviate/adapters/repos/db/queue"
	"github.com/weaviate/weaviate/entities/cyclemanager"
	enterrors "github.com/weaviate/weaviate/entities/errors"
	"github.com/weaviate/weaviate/entities/loadlimiter"
	"github.com/weaviate/weaviate/entities/replication"
	esync "github.com/weaviate/weaviate/entities/sync"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"
	"github.com/weaviate/weaviate/usecases/monitoring"
)

// TestIndexStopCycleManagers pins that every cycle manager stops even when another
// one does not, and that Index.drop can still recognize a context error.
func TestIndexStopCycleManagers(t *testing.T) {
	tests := []struct {
		name string
		// stallCompactions keeps both compaction cycles from reporting a stop
		stallCompactions bool
		// refuseFlush makes the flush cycle report that it kept running
		refuseFlush         bool
		cancelCtx           bool
		separateCompactions bool
		wantErrContains     []string
	}{
		{name: "every cycle stops"},
		{
			name:            "a cycle that refuses to stop is reported",
			refuseFlush:     true,
			wantErrContains: []string{"drop: stop flush cycle: cycle kept running"},
		},
		{
			name:             "a cycle that does not finish stopping is reported once ctx expires",
			stallCompactions: true,
			cancelCtx:        true,
			wantErrContains: []string{
				"drop: stop compaction cycle",
				"drop: stop auxiliary compaction cycle",
			},
		},
		{
			name:                "separate compactions are named by the data they cover",
			stallCompactions:    true,
			cancelCtx:           true,
			separateCompactions: true,
			wantErrContains: []string{
				"drop: stop non objects compaction cycle",
				"drop: stop objects compaction cycle",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			idx := newShutdownTestIndex(t, nil)
			idx.Config.SeparateObjectsCompactions = tt.separateCompactions
			if tt.stallCompactions {
				idx.cycleCallbacks.compactionCycle = stallingCycle(idx.cycleCallbacks.compactionCycle)
				idx.cycleCallbacks.compactionAuxCycle = stallingCycle(idx.cycleCallbacks.compactionAuxCycle)
			}
			if tt.refuseFlush {
				idx.cycleCallbacks.flushCycle = refusingCycle(idx.cycleCallbacks.flushCycle)
			}

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if tt.cancelCtx {
				cancel()
			}

			err := idx.stopCycleManagers(ctx, "drop")

			if len(tt.wantErrContains) == 0 {
				require.NoError(t, err)
			} else {
				require.Error(t, err)
				for _, want := range tt.wantErrContains {
					require.Contains(t, err.Error(), want)
				}
			}
			if tt.cancelCtx {
				// Index.drop tolerates context errors, so joining must keep them matchable
				require.ErrorIs(t, err, context.Canceled)
			}

			requireCyclesStopped(t, idx.cycleCallbacks)
		})
	}
}

func TestWaitForCycleStop(t *testing.T) {
	expired := func() context.Context {
		ctx, cancel := context.WithCancel(context.Background())
		cancel()
		return ctx
	}
	stopResult := func(results ...bool) chan bool {
		ch := make(chan bool, 1)
		for _, result := range results {
			ch <- result
		}
		return ch
	}

	tests := []struct {
		name string
		// newCase builds the context and stop result of a single run
		newCase func() (context.Context, chan bool)
		// runs repeats the case, as select picks randomly between ready channels
		runs            int
		wantErrIs       error
		wantErrContains string
	}{
		{
			name: "a cycle that stopped",
			newCase: func() (context.Context, chan bool) {
				return context.Background(), stopResult(true)
			},
		},
		{
			name: "a cycle that kept running",
			newCase: func() (context.Context, chan bool) {
				return context.Background(), stopResult(false)
			},
			wantErrContains: "cycle kept running",
		},
		{
			name: "a cycle that did not stop before ctx expired",
			newCase: func() (context.Context, chan bool) {
				return expired(), stopResult()
			},
			wantErrIs: context.Canceled,
		},
		{
			name: "a stop landing together with the ctx expiry is not a failure",
			newCase: func() (context.Context, chan bool) {
				ch := stopResult()
				return raceCtx{Context: expired(), stopResult: ch}, ch
			},
			runs: 100,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			for range max(tt.runs, 1) {
				ctx, stopResult := tt.newCase()
				err := waitForCycleStop(ctx, stopResult)

				if tt.wantErrIs == nil && tt.wantErrContains == "" {
					require.NoError(t, err)
					continue
				}
				require.Error(t, err)
				if tt.wantErrIs != nil {
					require.ErrorIs(t, err, tt.wantErrIs)
				}
				if tt.wantErrContains != "" {
					require.Contains(t, err.Error(), tt.wantErrContains)
				}
			}
		})
	}
}

// raceCtx reports a stop while Done is evaluated, so the stop and the expiry
// reach the same select.
type raceCtx struct {
	context.Context
	stopResult chan bool
}

func (c raceCtx) Done() <-chan struct{} {
	select {
	case c.stopResult <- true:
	default:
	}
	return c.Context.Done()
}

// stubCycle takes over the stop result of the cycle it wraps. The wrapped cycle
// is never asked to stop, so it keeps running until the test cleanup stops it.
type stubCycle struct {
	cyclemanager.CycleManager
	stopResult chan bool
}

func (c stubCycle) Stop(context.Context) chan bool {
	return c.stopResult
}

// stallingCycle never reports a stop result.
func stallingCycle(cycle cyclemanager.CycleManager) stubCycle {
	return stubCycle{CycleManager: cycle, stopResult: make(chan bool)}
}

// refusingCycle reports that it kept running.
func refusingCycle(cycle cyclemanager.CycleManager) stubCycle {
	stopResult := make(chan bool, 1)
	stopResult <- false
	close(stopResult)
	return stubCycle{CycleManager: cycle, stopResult: stopResult}
}

// requireCyclesStopped asserts that every cycle stopped. Stopping is asynchronous,
// so an expired context can return before the cycles are done. Stubbed cycles are
// skipped, as their stop never reaches the real cycle behind them.
func requireCyclesStopped(t *testing.T, cc *indexCycleCallbacks) {
	t.Helper()
	require.Eventually(t, func() bool {
		for _, cycle := range testCycles(cc) {
			if _, stubbed := cycle.(stubCycle); stubbed {
				continue
			}
			if cycle.Running() {
				return false
			}
		}
		return true
	}, time.Second, 10*time.Millisecond, "cycle managers left running")
}

// failingShards names count shards that all fail to shut down with err.
func failingShards(count int, err error) map[string]error {
	shardErrs := make(map[string]error, count)
	for i := range count {
		shardErrs[fmt.Sprintf("shard%d", i)] = err
	}
	return shardErrs
}

// newShutdownTestIndex builds an index with one mock shard per entry of shardErrs,
// each returning its entry's error from Shutdown, and with all cycle managers running.
func newShutdownTestIndex(t *testing.T, shardErrs map[string]error) *Index {
	t.Helper()
	logger, _ := test.NewNullLogger()

	shards := make(map[string]ShardLike, len(shardErrs))
	for name, err := range shardErrs {
		shard := NewMockShardLike(t)
		shard.EXPECT().Name().Return(name).Maybe()
		shard.EXPECT().Shutdown(mock.Anything).Return(err).Once()
		shards[name] = shard
	}

	idx := newTestIndex(t, logger, "", nil, shards)
	idx.backupLock = esync.NewKeyRWLocker()
	idx.shardCreateLocks = esync.NewKeyRWLocker()
	idx.cycleCallbacks = newTestCycleCallbacks(logger)

	for _, cycle := range testCycles(idx.cycleCallbacks) {
		cycle.Start()
	}
	t.Cleanup(func() {
		// a cycle the index left running would otherwise outlive the test
		for _, cycle := range testCycles(idx.cycleCallbacks) {
			require.NoError(t, cycle.StopAndWait(context.Background()))
		}
	})
	return idx
}

func newTestCycleCallbacks(logger logrus.FieldLogger) *indexCycleCallbacks {
	newCycle := func(name string) cyclemanager.CycleManager {
		return cyclemanager.NewManager(name, cyclemanager.NewNoopTicker(),
			func(cyclemanager.ShouldAbortCallback) bool { return false }, logger)
	}
	return &indexCycleCallbacks{
		compactionCycle:               newCycle("compaction"),
		compactionAuxCycle:            newCycle("compaction-aux"),
		flushCycle:                    newCycle("flush"),
		vectorCommitLoggerCycle:       newCycle("vector-commit-logger"),
		vectorTombstoneCleanupCycle:   newCycle("vector-tombstone-cleanup"),
		geoPropsCommitLoggerCycle:     newCycle("geo-commit-logger"),
		geoPropsTombstoneCleanupCycle: newCycle("geo-tombstone-cleanup"),
	}
}

func testCycles(cc *indexCycleCallbacks) []cyclemanager.CycleManager {
	return []cyclemanager.CycleManager{
		cc.compactionCycle,
		cc.compactionAuxCycle,
		cc.flushCycle,
		cc.vectorCommitLoggerCycle,
		cc.vectorTombstoneCleanupCycle,
		cc.geoPropsCommitLoggerCycle,
		cc.geoPropsTombstoneCleanupCycle,
	}
}

func TestIndexShutdownStopsCycleManagersDespiteShardFailure(t *testing.T) {
	errInUse := errors.New("still in use")
	errDiskGone := errors.New("disk gone")

	tests := []struct {
		name      string
		shardErrs map[string]error
		// a compaction cycle that never reports a stop fails once ctx expires
		stallCompaction bool
		cancelCtx       bool
		wantErrContains []string
		wantErrIs       []error
	}{
		{
			name:      "no shard fails",
			shardErrs: map[string]error{"shard1": nil, "shard2": nil},
		},
		{
			name:      "already shut down shard is not a failure",
			shardErrs: map[string]error{"shard1": errAlreadyShutdown, "shard2": nil},
		},
		{
			name:            "one of two shards fails",
			shardErrs:       map[string]error{"shard1": errInUse, "shard2": nil},
			wantErrContains: []string{`shutdown shard "shard1"`, "still in use"},
			wantErrIs:       []error{errInUse},
		},
		{
			name:            "both shards fail",
			shardErrs:       map[string]error{"shard1": errInUse, "shard2": errDiskGone},
			wantErrContains: []string{`shutdown shard "shard1"`, `shutdown shard "shard2"`, "disk gone"},
			wantErrIs:       []error{errInUse, errDiskGone},
		},
		{
			name:            "shard failures beyond the limit are only counted",
			shardErrs:       failingShards(maxReportedErrors+2, errInUse),
			wantErrContains: []string{"still in use", "(and 2 more)"},
			wantErrIs:       []error{errInUse},
		},
		{
			name:            "shard failure and cycle manager failure are both reported",
			shardErrs:       map[string]error{"shard1": errInUse},
			stallCompaction: true,
			cancelCtx:       true,
			wantErrContains: []string{
				`shutdown shard "shard1"`,
				"shutdown: stop compaction cycle",
				context.Canceled.Error(),
			},
			wantErrIs: []error{errInUse, context.Canceled},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			idx := newShutdownTestIndex(t, tt.shardErrs)
			if tt.stallCompaction {
				idx.cycleCallbacks.compactionCycle = stallingCycle(idx.cycleCallbacks.compactionCycle)
			}

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if tt.cancelCtx {
				cancel()
			}

			err := idx.Shutdown(ctx)

			if len(tt.wantErrContains) == 0 {
				require.NoError(t, err)
			} else {
				require.Error(t, err)
				for _, want := range tt.wantErrContains {
					require.Contains(t, err.Error(), want)
				}
			}
			for _, want := range tt.wantErrIs {
				require.ErrorIs(t, err, want)
			}

			requireCyclesStopped(t, idx.cycleCallbacks)
		})
	}
}

func TestDBShutdownRunsEveryIndexAndCleanup(t *testing.T) {
	type indexSpec struct {
		name          string
		shardErr      error
		alreadyClosed bool
	}

	errInUse := errors.New("still in use")
	errDiskGone := errors.New("disk gone")

	failingIndices := func(count int) []indexSpec {
		specs := make([]indexSpec, count)
		for i := range specs {
			specs[i] = indexSpec{name: fmt.Sprintf("Class%d", i), shardErr: errInUse}
		}
		return specs
	}

	tests := []struct {
		name            string
		indices         []indexSpec
		wantErrContains []string
		wantErrIs       []error
	}{
		{
			name:    "no index fails",
			indices: []indexSpec{{name: "Alpha"}, {name: "Beta"}},
		},
		{
			name:    "already shut down index is not a failure",
			indices: []indexSpec{{name: "Alpha", alreadyClosed: true}, {name: "Beta"}},
		},
		{
			name:            "one of two indices fails",
			indices:         []indexSpec{{name: "Alpha", shardErr: errInUse}, {name: "Beta"}},
			wantErrContains: []string{`shutdown index "Alpha"`, "still in use"},
			wantErrIs:       []error{errInUse},
		},
		{
			name: "every index fails",
			indices: []indexSpec{
				{name: "Alpha", shardErr: errInUse},
				{name: "Beta", shardErr: errDiskGone},
			},
			wantErrContains: []string{`shutdown index "Alpha"`, `shutdown index "Beta"`, "disk gone"},
			wantErrIs:       []error{errInUse, errDiskGone},
		},
		{
			name:            "index failures beyond the limit are only counted",
			indices:         failingIndices(maxReportedErrors + 2),
			wantErrContains: []string{"still in use", "(and 2 more)"},
			wantErrIs:       []error{errInUse},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, _ := test.NewNullLogger()

			checkpoints, err := indexcheckpoint.New(t.TempDir(), logger)
			require.NoError(t, err)

			db := &DB{
				logger:                    logger,
				shutdown:                  make(chan struct{}, 1),
				bitmapBufPoolClose:        func() {},
				AsyncIndexingEnabled:      true,
				asyncReplicationScheduler: newSchedulerForUnitTest(t),
				indexCheckpoints:          checkpoints,
				indices:                   map[string]*Index{},
			}

			for _, spec := range tt.indices {
				// a closed index has no shard to shut down, so it gets no mock shard
				var idx *Index
				if spec.alreadyClosed {
					idx = newShutdownTestIndex(t, nil)
					idx.closed = true
				} else {
					idx = newShutdownTestIndex(t, map[string]error{"shard1": spec.shardErr})
				}
				db.indices[spec.name] = idx
			}

			err = db.Shutdown(context.Background())

			if len(tt.wantErrContains) == 0 {
				require.NoError(t, err)
			} else {
				require.Error(t, err)
				for _, want := range tt.wantErrContains {
					require.Contains(t, err.Error(), want)
				}
			}
			for _, want := range tt.wantErrIs {
				require.ErrorIs(t, err, want)
			}

			// closing the checkpoint store is the last statement after the index
			// loop, so a closed store proves the whole post-loop cleanup ran
			_, _, err = checkpoints.Get("shard1", "")
			require.Error(t, err)
		})
	}
}

// TestIndexShutdownAbortsInFlightReader pins that Shutdown requests the close
// before waiting for closeLock, so a reader holding closeLock.RLock can abort
// rather than hold up DB shutdown, which runs with the DB-wide index lock held.
func TestIndexShutdownAbortsInFlightReader(t *testing.T) {
	idx := newShutdownTestIndex(t, nil)

	reading := make(chan struct{})
	go func() {
		idx.closeLock.RLock()
		defer idx.closeLock.RUnlock()

		close(reading)
		<-idx.closeRequestedCtx.Done()
	}()
	<-reading

	shutdownDone := make(chan error, 1)
	go func() { shutdownDone <- idx.Shutdown(context.Background()) }()

	select {
	case err := <-shutdownDone:
		require.NoError(t, err)
	case <-time.After(5 * time.Second):
		t.Fatal("Shutdown is blocked behind an in-flight reader")
	}
}

// newShutdownTestDB builds the minimal DB the Shutdown path touches, with n batch workers when n > 0.
func newShutdownTestDB(t *testing.T, logger *logrus.Logger, batchWorkers int) *DB {
	t.Helper()
	db := &DB{
		shutdown:            make(chan struct{}),
		logger:              logger,
		bitmapBufPoolClose:  func() {},
		maxNumberGoroutines: batchWorkers,
	}
	db.shutDownWg.Add(1)
	db.scheduler = queue.NewScheduler(queue.SchedulerOptions{Logger: logger, OnClose: db.shutDownWg.Done})
	db.scheduler.Start()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)
	db.asyncReplicationScheduler = sched

	if batchWorkers > 0 {
		db.jobQueueCh = make(chan job, 10)
		db.shutDownWg.Add(batchWorkers)
		for range batchWorkers {
			enterrors.GoWrapper(func() { db.batchWorker(false) }, logger)
		}
	}
	return db
}

func requireShutdownReturns(t *testing.T, db *DB, msg string) {
	t.Helper()
	done := make(chan error, 1)
	go func() { done <- db.Shutdown(context.Background()) }()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal(msg)
	}
}

// TestShutdownSurvivesDeadBatchWorker: DB.Shutdown must return even when a batch worker died from a panic before consuming its poison pill.
func TestShutdownSurvivesDeadBatchWorker(t *testing.T) {
	logger, _ := test.NewNullLogger()
	db := newShutdownTestDB(t, logger, 0)
	db.jobQueueCh = make(chan job, 10)
	db.maxNumberGoroutines = 1

	// Sole consumer, test-owned recover: GoWrapper re-panics under DISABLE_RECOVERY_ON_PANIC and would kill the binary.
	db.shutDownWg.Add(1)
	workerDead := make(chan struct{})
	go func() {
		defer close(workerDead)
		defer func() { _ = recover() }()
		db.batchWorker(false)
	}()

	db.jobQueueCh <- job{index: 0, batcher: nil}
	select {
	case <-workerDead:
	case <-time.After(5 * time.Second):
		t.Fatal("the poisoned job never killed the worker — the fixture no longer exercises the leak")
	}

	requireShutdownReturns(t, db, "DB.Shutdown must not hang when a batch worker died before its poison pill")
}

// TestDBShutdownIdempotent: a second DB.Shutdown must be a safe no-op, not a double close of the metrics observer's channel.
func TestDBShutdownIdempotent(t *testing.T) {
	logger, _ := test.NewNullLogger()
	db := newShutdownTestDB(t, logger, 0)
	db.metricsObserver = &nodeWideMetricsObserver{db: db, shutdown: make(chan struct{})}

	requireShutdownReturns(t, db, "first DB.Shutdown must return")
	require.NotPanics(t, func() {
		requireShutdownReturns(t, db, "second DB.Shutdown must return")
	})
}

// TestShutdownSignalSurvivesDeadResourceScanner: DB.Shutdown must return even when the resource-scan receiver is gone, as after a panic killed its goroutine.
func TestShutdownSignalSurvivesDeadResourceScanner(t *testing.T) {
	logger, _ := test.NewNullLogger()
	db := &DB{
		shutdown:           make(chan struct{}),
		logger:             logger,
		bitmapBufPoolClose: func() {},
	}
	db.shutDownWg.Add(1)
	db.scheduler = queue.NewScheduler(queue.SchedulerOptions{Logger: logger, OnClose: db.shutDownWg.Done})
	db.scheduler.Start()
	sched, err := NewAsyncReplicationScheduler(context.Background(), replication.GlobalConfig{
		AsyncReplicationSchedulerWorkers: configRuntime.NewDynamicValue(1),
		AsyncReplicationDisabled:         configRuntime.NewDynamicValue(false),
	}, nil, logger)
	require.NoError(t, err)
	db.asyncReplicationScheduler = sched

	done := make(chan error, 1)
	go func() { done <- db.Shutdown(context.Background()) }()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(10 * time.Second):
		t.Fatal("DB.Shutdown must not hang without a live resource-scan receiver")
	}
}

// closeRequest is one of the teardowns that asks an index to close before it
// waits for closeLock, paired with the cause it signals.
type closeRequest struct {
	name    string
	request func(*Index) error
	cause   error
}

func closeRequests() []closeRequest {
	return []closeRequest{
		{
			name:    "a shutdown",
			request: func(idx *Index) error { return idx.Shutdown(context.Background()) },
			cause:   errIndexShutdown,
		},
		{
			name: "a drop",
			request: func(idx *Index) error {
				idx.signalCloseRequested(errIndexDropped)
				return nil
			},
			cause: errIndexDropped,
		},
	}
}

// TestCloseRequestAbortsBackgroundShardLoad pins that the background shard load
// gives up its wait once a close is requested. It waits for a node-wide load
// permit while holding the index open, so a load that kept waiting would hold up
// the teardown for as long as the permit is taken.
func TestCloseRequestAbortsBackgroundShardLoad(t *testing.T) {
	for _, tt := range closeRequests() {
		t.Run(tt.name+" releases the load", func(t *testing.T) {
			idx := newShutdownTestIndex(t, nil)

			release, loadDone := startGatedBackgroundLoad(t, idx, "t1")
			// the load must reach the permit wait rather than park at the gate,
			// or it never exercises the wait this test is about
			close(release)

			closeDone := make(chan error, 1)
			go func() { closeDone <- tt.request(idx) }()

			select {
			case err := <-loadDone:
				require.ErrorIs(t, err, context.Canceled)
				require.ErrorIs(t, context.Cause(idx.closeRequestedCtx), tt.cause)
			case <-time.After(5 * time.Second):
				t.Fatal("the shard load kept waiting for a permit through the close request")
			}
			require.NoError(t, <-closeDone)
		})
	}
}

// TestCloseRequestAbortsShardUnload pins that an unload gives up the shard
// shutdown it is waiting on once a close is requested. The shutdown retries for
// seconds while the unload holds the index open, so an unload that kept
// retrying would hold the teardown behind its own in-flight count.
func TestCloseRequestAbortsShardUnload(t *testing.T) {
	for _, tt := range closeRequests() {
		t.Run(tt.name+" releases the unload", func(t *testing.T) {
			idx := newShutdownTestIndex(t, nil)

			var parked sync.Once
			entered := make(chan struct{})
			shard := NewMockShardLike(t)
			shard.EXPECT().Name().Return("t1").Maybe()
			// stands in for Shard.Shutdown's retry loop: a shard in use holds it
			// until the retries run out or the given context is cancelled
			shard.EXPECT().Shutdown(mock.Anything).RunAndReturn(func(ctx context.Context) error {
				parked.Do(func() {
					close(entered)
					<-ctx.Done()
				})
				return ctx.Err()
			})
			idx.shards.Store("t1", shard)

			unloadDone := make(chan error, 1)
			go func() { unloadDone <- idx.UnloadLocalShard(context.Background(), "t1") }()
			<-entered

			closeDone := make(chan error, 1)
			go func() { closeDone <- tt.request(idx) }()

			select {
			case err := <-unloadDone:
				require.ErrorIs(t, err, tt.cause)
			case <-time.After(5 * time.Second):
				t.Fatal("the unload kept waiting on the shard shutdown through the close request")
			}
			require.NoError(t, <-closeDone)
		})
	}
}

// startGatedBackgroundLoad parks a background shard load mid-build and returns
// once it holds the index open: closing the returned channel lets it through to
// the permit wait. The one node-wide permit is taken and never given back, so a
// released load ends at the limiter instead of building a shard.
func startGatedBackgroundLoad(t *testing.T, idx *Index, shardName string) (chan struct{}, chan error) {
	t.Helper()

	limiter := loadlimiter.NewLoadLimiter(monitoring.NoopRegisterer, "test_shard_load", 1)
	require.NoError(t, limiter.Acquire(context.Background()))

	entered, release := make(chan struct{}), make(chan struct{})
	idx.shards.Store(shardName, &LazyLoadShard{
		memMonitor:       gateAllocChecker{entered: entered, release: release},
		shardLoadLimiter: limiter,
	})

	loadDone := make(chan error, 1)
	go func() {
		_, err := idx.loadLocalShardIfActive(shardName)
		loadDone <- err
	}()
	<-entered

	return release, loadDone
}

// TestTeardownProceedsDuringBackgroundShardLoad pins that a shard build in flight
// holds the index open through the refcount rather than closeLock, so a teardown
// closes the index straight away instead of queueing for the write lock behind
// the build.
func TestTeardownProceedsDuringBackgroundShardLoad(t *testing.T) {
	idx := newShutdownTestIndex(t, nil)

	release, loadDone := startGatedBackgroundLoad(t, idx, "t1")

	closeDone := make(chan error, 1)
	go func() { closeDone <- idx.Shutdown(context.Background()) }()

	// beginClose cancels closingCtx under the write lock, so this fires only once
	// the teardown got that lock
	select {
	case <-idx.closingCtx.Done():
	case <-time.After(5 * time.Second):
		t.Fatal("the shard build kept the teardown from closing the index")
	}

	close(release)
	<-loadDone
	require.NoError(t, <-closeDone)
}

// TestCancelOnCloseRequested pins the context a closeLock reader aborts on: live
// while no teardown has asked to close, then cancelled carrying the cause that
// says which teardown asked.
func TestCancelOnCloseRequested(t *testing.T) {
	tests := []struct {
		name string
		// a nil cause means nothing asks to close
		wantCause error
	}{
		{name: "no close requested keeps the context live"},
		{name: "a shutdown cancels it", wantCause: errIndexShutdown},
		{name: "a drop cancels it", wantCause: errIndexDropped},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			idx := newShutdownTestIndex(t, nil)

			derived, done := idx.cancelOnCloseRequested(context.Background())
			defer done()

			if tt.wantCause == nil {
				require.NoError(t, derived.Err())
				return
			}

			idx.signalCloseRequested(tt.wantCause)
			select {
			case <-derived.Done():
			case <-time.After(5 * time.Second):
				t.Fatal("the derived context ignored the close request")
			}
			require.ErrorIs(t, context.Cause(derived), tt.wantCause)
		})
	}
}
