//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package db

import (
	"context"
	stderrors "errors"
	"fmt"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"slices"
	golangSort "sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/go-openapi/strfmt"
	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"

	"github.com/weaviate/weaviate/adapters/repos/db/aggregator"
	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/adapters/repos/db/indexcheckpoint"
	"github.com/weaviate/weaviate/adapters/repos/db/indexcounter"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted/stopwords"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv"
	"github.com/weaviate/weaviate/adapters/repos/db/queue"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringset"
	resolver "github.com/weaviate/weaviate/adapters/repos/db/sharding"
	"github.com/weaviate/weaviate/adapters/repos/db/sorter"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/hnsw"
	"github.com/weaviate/weaviate/adapters/repos/db/vector/hnsw/distancer"
	replicationTypes "github.com/weaviate/weaviate/cluster/replication/types"
	"github.com/weaviate/weaviate/cluster/router/executor"
	routerTypes "github.com/weaviate/weaviate/cluster/router/types"
	"github.com/weaviate/weaviate/entities/additional"
	"github.com/weaviate/weaviate/entities/aggregation"
	"github.com/weaviate/weaviate/entities/autocut"
	"github.com/weaviate/weaviate/entities/backup"
	"github.com/weaviate/weaviate/entities/cyclemanager"
	"github.com/weaviate/weaviate/entities/dto"
	"github.com/weaviate/weaviate/entities/errorcompounder"
	enterrors "github.com/weaviate/weaviate/entities/errors"
	"github.com/weaviate/weaviate/entities/filters"
	"github.com/weaviate/weaviate/entities/loadlimiter"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/modulecapabilities"
	"github.com/weaviate/weaviate/entities/multi"
	"github.com/weaviate/weaviate/entities/replication"
	"github.com/weaviate/weaviate/entities/schema"
	schemaConfig "github.com/weaviate/weaviate/entities/schema/config"
	"github.com/weaviate/weaviate/entities/search"
	"github.com/weaviate/weaviate/entities/searchparams"
	entsentry "github.com/weaviate/weaviate/entities/sentry"
	"github.com/weaviate/weaviate/entities/storagestate"
	"github.com/weaviate/weaviate/entities/storobj"
	esync "github.com/weaviate/weaviate/entities/sync"
	"github.com/weaviate/weaviate/entities/tokenizer"
	vectorIndexCommon "github.com/weaviate/weaviate/entities/vectorindex/common"
	authzerrors "github.com/weaviate/weaviate/usecases/auth/authorization/errors"
	"github.com/weaviate/weaviate/usecases/cluster"
	"github.com/weaviate/weaviate/usecases/config"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"
	"github.com/weaviate/weaviate/usecases/memwatch"
	"github.com/weaviate/weaviate/usecases/modules"
	"github.com/weaviate/weaviate/usecases/monitoring"
	"github.com/weaviate/weaviate/usecases/multitenancy"
	"github.com/weaviate/weaviate/usecases/namespaces"
	"github.com/weaviate/weaviate/usecases/objects"
	"github.com/weaviate/weaviate/usecases/replica"
	schemaUC "github.com/weaviate/weaviate/usecases/schema"
	"github.com/weaviate/weaviate/usecases/schema/namespacing"
	"github.com/weaviate/weaviate/usecases/sharding"
	"github.com/weaviate/weaviate/usecases/usagelimits"
)

// Use runtime.GOMAXPROCS instead of runtime.NumCPU because NumCPU returns
// the physical CPU cores. However, in a containerization context, that might
// not be what we want. The physical node could have 128 cores, but we could
// be cgroup-limited to 2 cores. In that case, we want 2 to be our limit, not
// 128. It isn't guaranteed that MAXPROCS reflects the cgroup limit, but at
// least there is a chance that it was set correctly. If not, it defaults to
// NumCPU anyway, so we're not any worse off.
var _NUMCPU = runtime.GOMAXPROCS(0)

// maxReportedErrors bounds how many failures a shard-wide or index-wide operation
// reports, so a node with many tenants cannot produce a multi-megabyte message.
const maxReportedErrors = 10

// shardMap is a sync.Map which specialized in storing shards
type shardMap sync.Map

// Range calls f sequentially for each key and value present in the map.
// If f returns an error, range stops the iteration
func (m *shardMap) Range(f func(name string, shard ShardLike) error) (err error) {
	(*sync.Map)(m).Range(func(key, value any) bool {
		// Safe type assertion for key
		name, ok := key.(string)
		if !ok {
			// Skip invalid keys
			return true
		}

		// Safe type assertion for value
		shard, ok := value.(ShardLike)
		if !ok || shard == nil {
			// Skip invalid or nil shards
			return true
		}

		err = f(name, shard)
		return err == nil
	})
	return err
}

// RangeConcurrently calls f for each key and value present in the map with at
// most _NUMCPU executors running in parallel. As opposed to [Range] it does
// not guarantee an exit on the first error.
func (m *shardMap) RangeConcurrently(logger logrus.FieldLogger, f func(name string, shard ShardLike) error) (err error) {
	eg := enterrors.NewErrorGroupWrapper(logger)
	eg.SetLimit(_NUMCPU)
	(*sync.Map)(m).Range(func(key, value any) bool {
		name, ok := key.(string)
		if !ok {
			// Skip invalid keys
			return true
		}

		// Safe type assertion for value
		shard, ok := value.(ShardLike)
		if !ok || shard == nil {
			// Skip invalid or nil shards
			return true
		}

		eg.Go(func() error {
			return f(name, shard)
		}, name, shard)
		return true
	})

	return eg.Wait()
}

// Load returns the shard or nil if no shard is present.
// NOTE: this method does not check if the shard is loaded or not and it could
// return a lazy shard that is not loaded which could result in loading it if
// the returned shard is used.
// Use Loaded if you want to check if the shard is loaded without loading it.
func (m *shardMap) Load(name string) ShardLike {
	v, ok := (*sync.Map)(m).Load(name)
	if !ok {
		return nil
	}

	shard, ok := v.(ShardLike)
	if !ok {
		return nil
	}
	return shard
}

// Loaded returns the shard or nil if no shard is present.
// If it's a lazy shard, only return it if it's loaded.
func (m *shardMap) Loaded(name string) ShardLike {
	v, ok := (*sync.Map)(m).Load(name)
	if !ok {
		return nil
	}

	shard, ok := v.(ShardLike)
	if !ok {
		return nil
	}

	// If it's a lazy shard, only return it if it's loaded
	if lazyShard, ok := shard.(*LazyLoadShard); ok {
		if !lazyShard.isLoaded() {
			return nil
		}
	}

	return shard
}

// Store sets a shard giving its name and value
func (m *shardMap) Store(name string, shard ShardLike) {
	(*sync.Map)(m).Store(name, shard)
}

// Swap swaps the shard for a key and returns the previous value if any.
// The loaded result reports whether the key was present.
func (m *shardMap) Swap(name string, shard ShardLike) (previous ShardLike, loaded bool) {
	v, ok := (*sync.Map)(m).Swap(name, shard)
	if v == nil || !ok {
		return nil, ok
	}
	return v.(ShardLike), ok
}

// CompareAndSwap swaps the old and new values for key if the value stored in the map is equal to old.
func (m *shardMap) CompareAndSwap(name string, old, new ShardLike) bool {
	return (*sync.Map)(m).CompareAndSwap(name, old, new)
}

// LoadAndDelete deletes the value for a key, returning the previous value if any.
// The loaded result reports whether the key was present.
func (m *shardMap) LoadAndDelete(name string) (ShardLike, bool) {
	v, ok := (*sync.Map)(m).LoadAndDelete(name)
	if v == nil || !ok {
		return nil, ok
	}
	return v.(ShardLike), ok
}

// causes of Index.closeRequestedCtx
var (
	errIndexDropped  = stderrors.New("collection is being deleted")
	errIndexShutdown = stderrors.New("node is shutting down")
)

// errShardsSkipped signals a walk that didn't reach every shard the index
// held when it started — not a close cause, it describes the walk itself.
var errShardsSkipped = stderrors.New("shard walk did not reach every shard")

// Index is the logical unit which contains all the data for one particular
// class. An index can be further broken up into self-contained units, called
// Shards, to allow for easy distribution across Nodes
type Index struct {
	classSearcher           inverted.ClassSearcher // to allow for nested by-references searches
	shards                  shardMap
	Config                  IndexConfig
	globalreplicationConfig *replication.GlobalConfig

	getSchema    schemaUC.SchemaGetter
	schemaReader schemaUC.SchemaReader

	// replicationFSMReader is wired post-construction (migrator/init) while
	// shards may already run hashbeats — hence atomic, read via getReplicationFSMReader.
	replicationFSMReader atomic.Pointer[replicationTypes.ReplicationFSMReader]
	logger               logrus.FieldLogger
	remote               *sharding.RemoteIndex
	stopwords            *stopwords.Detector
	// stopwordProvider bundles the collection-level stopword detector and the
	// cached user-defined preset detectors. It is replaced atomically when
	// invertedIndexConfig is updated, so reads on hot query paths do not need
	// to take invertedIndexConfigLock. Always access via getStopwordProvider().
	stopwordProvider atomic.Pointer[stopwords.Provider]
	replicator       *replica.Replicator

	vectorIndexUserConfigLock sync.Mutex
	vectorIndexUserConfig     schemaConfig.VectorIndexConfig
	vectorIndexUserConfigs    map[string]schemaConfig.VectorIndexConfig
	HFreshEnabled             bool

	partitioningEnabled  bool
	AsyncIndexingEnabled bool

	invertedIndexConfig     schema.InvertedIndexConfig
	invertedIndexConfigLock sync.Mutex

	// This lock should be used together with the db indexLock.
	//
	// The db indexlock locks the map that contains all indices against changes and should be used while iterating.
	// This lock protects this specific index form being deleted while in use. Use Rlock to signal that it is in use.
	// This way many goroutines can use a specific index in parallel. The delete-routine will try to acquire a RWlock.
	//
	// Usage:
	// Lock the whole db using db.indexLock
	// pick the indices you want and Rlock them
	// unlock db.indexLock
	// Use the indices
	// RUnlock all picked indices
	dropIndex sync.RWMutex

	// closeRequestedCtx is cancelled when a drop or shutdown is requested, before
	// it waits for dropIndex or closeLock, so readers holding either can abort
	// instead of blocking the teardown. Its cause tells the two apart: a reader may
	// leave out a collection being deleted, but not one that is only shutting down.
	// Shutdown signals unconditionally, so an index built without these panics.
	closeRequestedCtx    context.Context
	signalCloseRequested context.CancelCauseFunc

	// The other locks in the index should always be called in the given order to prevent deadlocks:
	// 1. closeLock
	// 2. backupLock (for a specific shard)
	// 3. shardCreateLocks (for a specific shard)
	closeLock  sync.RWMutex       // protects against closing while doing operations
	backupLock *esync.KeyRWLocker // prevents writes while a backup is running
	// prevents concurrent shard status changes. Use .Rlock to secure against status changes and .Lock to change status
	// Minimize holding the RW lock as it will block other operations on the same shard such as searches or writes.
	shardCreateLocks *esync.KeyRWLocker

	// backupProtectedShards tracks shard names protected during non-hardlink backup.
	// Activation and destructive status changes are blocked until ReleaseBackup.
	// non-hardlink backups only occur on niche filesystems so this is not a hot path
	//
	// Deprecated: NO-HARDLINK-BACKUP. Removed in v1.40; bugs here are not fixed.
	backupProtectedShards sync.Map

	// Release uses this to decide whether to resume the shard (halt-for-duration
	// fallback) or skip resume (snapshot already resumed at create time).
	replicaSnapshotsMu sync.Mutex
	replicaSnapshots   map[string]replicaSnapshotState

	// Serializes create/release per opID against target retries. Read RPCs
	// skip it on purpose — locking them would queue downloads behind any
	// concurrent Release and tank throughput.
	replicaSnapshotOpLocks *esync.KeyRWLocker

	metrics          *Metrics
	centralJobQueue  chan job
	scheduler        *queue.Scheduler
	indexCheckpoints *indexcheckpoint.Checkpoints

	cycleCallbacks *indexCycleCallbacks

	lastBackup atomic.Pointer[BackupState]

	// canceled when either Shutdown or Drop called
	closingCtx    context.Context
	closingCancel context.CancelFunc

	// True once the startup sweep is over. Shards it skips or fails to load stay
	// cold, so this does not mean every shard is loaded.
	allShardsReady atomic.Bool
	allocChecker   memwatch.AllocChecker

	replicationConfigLock sync.RWMutex
	// serializes applyAsyncReplicationToLoadedShards fan-outs and the single-shard
	// appliers (resume, scheduler rebuild) so a stale snapshot cannot clobber a
	// fresher one; each holder snapshots the config AFTER acquiring it.
	// The scheduler rebuild only ever TryLocks and yields to pending waiters
	// (asyncReplicationApplyWaiters), so it never delays schema applies or shutdown.
	asyncReplicationApplyLock sync.Mutex
	// blocking apply-lock acquirers pending in Lock(); the scheduler rebuild polls
	// it between steps and aborts so a schema apply never waits on a full rebuild
	asyncReplicationApplyWaiters atomic.Int32
	asyncReplicationScheduler    *AsyncReplicationScheduler

	shardLoadLimiter  *loadlimiter.LoadLimiter
	bucketLoadLimiter *loadlimiter.LoadLimiter

	// namespacesExister is inherited from the owning DB at index creation; a
	// namespaced class refuses every shard decision without it. namespace is
	// empty for an unqualified class name.
	namespacesExister namespaces.Exister
	namespace         string

	closed bool

	// inflight counts operations admitted by enterRead. beginClose drains it
	// instead of holding closeLock across teardown.
	inflight sync.WaitGroup

	shardReindexer ShardReindexerV3

	router         routerTypes.Router
	shardResolver  *resolver.ShardResolver
	bitmapBufPool  roaringset.BitmapBufPool
	tenantsManager schemaUC.TenantsActivityManager

	// usageLimits is inherited from the owning DB at index creation; nil
	// means no enforcement. Read by Shards on the write path. See
	// docs/usage_limits.md.
	usageLimits *usagelimits.Manager

	// db is the owning *DB, set by the caller right after NewIndex
	// returns. Used by [Index.refuseIfReindexInFlight] to consult the
	// DTM-backed backup gate. Nil is treated conservatively by the gate
	// (refuses), matching the pre-wire stance.
	db *DB
}

func (i *Index) ID() string {
	return indexID(i.Config.ClassName)
}

func (i *Index) path() string {
	return path.Join(i.Config.RootPath, i.ID())
}

func (i *Index) snapshotsPath() string {
	return path.Join(i.path(), lsmkv.SnapshotsRootDir)
}

func (i *Index) debugLoggingEnabled() bool {
	switch logger := i.logger.(type) {
	case *logrus.Logger:
		return logger.IsLevelEnabled(logrus.DebugLevel)
	case *logrus.Entry:
		return logger.Logger.IsLevelEnabled(logrus.DebugLevel)
	default:
		return false
	}
}

// NewIndex creates an index with the specified amount of shards, using only
// the shards that are local to a node
// NewIndex builds an index and every shard it owns. db is the owning DB, wired
// in here rather than by the caller because the shards built below read state
// off it while they come up (e.g. the resource-pressure read-only flag, see
// [Shard.inheritResourcePressureReadOnly]) - assigning it after this returns
// would leave those reads racing the assignment.
func NewIndex(
	ctx context.Context,
	db *DB,
	cfg IndexConfig,
	invertedIndexConfig schema.InvertedIndexConfig,
	vectorIndexUserConfig schemaConfig.VectorIndexConfig,
	vectorIndexUserConfigs map[string]schemaConfig.VectorIndexConfig,
	router routerTypes.Router,
	shardResolver *resolver.ShardResolver,
	sg schemaUC.SchemaGetter,
	schemaReader schemaUC.SchemaReader,
	cs inverted.ClassSearcher,
	logger logrus.FieldLogger,
	nodeResolver cluster.NodeResolver,
	remoteClient sharding.RemoteIndexClient,
	replicaClient replica.Client,
	globalReplicationConfig *replication.GlobalConfig,
	promMetrics *monitoring.PrometheusMetrics,
	class *models.Class,
	jobQueueCh chan job,
	scheduler *queue.Scheduler,
	indexCheckpoints *indexcheckpoint.Checkpoints,
	allocChecker memwatch.AllocChecker,
	shardReindexer ShardReindexerV3,
	bitmapBufPool roaringset.BitmapBufPool,
	asyncIndexingEnabled bool,
	tenantsManager schemaUC.TenantsActivityManager,
) (*Index, error) {
	err := tokenizer.AddCustomDict(class.Class, invertedIndexConfig.TokenizerUserDict)
	if err != nil {
		return nil, errors.Wrap(err, "failed to create new index")
	}

	sd, err := stopwords.NewDetectorFromConfig(invertedIndexConfig.Stopwords)
	if err != nil {
		return nil, errors.Wrap(err, "failed to create new index")
	}

	presetDetectors, err := stopwords.BuildPresetDetectors(invertedIndexConfig.StopwordPresets)
	if err != nil {
		return nil, errors.Wrap(err, "failed to create new index")
	}

	if cfg.QueryNestedRefLimit == 0 {
		cfg.QueryNestedRefLimit = config.DefaultQueryNestedCrossReferenceLimit
	}

	if vectorIndexUserConfigs == nil {
		vectorIndexUserConfigs = map[string]schemaConfig.VectorIndexConfig{}
	}

	metrics, err := NewMetrics(logger, promMetrics, cfg.ClassName.String(), "n/a")
	if err != nil {
		return nil, fmt.Errorf("create metrics for index %q: %w", cfg.ClassName.String(), err)
	}

	index := &Index{
		db:                      db,
		Config:                  cfg,
		globalreplicationConfig: globalReplicationConfig,
		getSchema:               sg,
		schemaReader:            schemaReader,
		logger:                  logger,
		classSearcher:           cs,
		vectorIndexUserConfig:   vectorIndexUserConfig,
		invertedIndexConfig:     invertedIndexConfig,
		vectorIndexUserConfigs:  vectorIndexUserConfigs,
		stopwords:               sd,
		partitioningEnabled:     multitenancy.IsMultiTenant(class.MultiTenancyConfig),
		AsyncIndexingEnabled:    asyncIndexingEnabled,
		remote:                  sharding.NewRemoteIndex(cfg.ClassName.String(), sg, nodeResolver, remoteClient),
		metrics:                 metrics,
		centralJobQueue:         jobQueueCh,
		backupLock:              esync.NewKeyRWLocker(),
		scheduler:               scheduler,
		indexCheckpoints:        indexCheckpoints,
		allocChecker:            allocChecker,
		shardCreateLocks:        esync.NewKeyRWLocker(),
		replicaSnapshotOpLocks:  esync.NewKeyRWLocker(),
		shardLoadLimiter:        cfg.ShardLoadLimiter,
		bucketLoadLimiter:       cfg.BucketLoadLimiter,
		namespacesExister:       cfg.NamespacesExister,
		namespace:               namespacing.NamespaceFromQualified(string(cfg.ClassName)),
		shardReindexer:          shardReindexer,
		router:                  router,
		shardResolver:           shardResolver,
		bitmapBufPool:           bitmapBufPool,
		HFreshEnabled:           cfg.HFreshEnabled,
		tenantsManager:          tenantsManager,
	}
	index.closeRequestedCtx, index.signalCloseRequested = context.WithCancelCause(context.Background())
	index.stopwordProvider.Store(stopwords.NewProvider(sd, presetDetectors))

	getDeletionStrategy := func() string {
		return index.DeletionStrategy()
	}

	// TODO: Fix replica router instantiation to be at the top level
	index.replicator, err = replica.NewReplicator(cfg.ClassName.String(), router, nodeResolver, sg.NodeName(), getDeletionStrategy, replicaClient, promMetrics, logger)
	if err != nil {
		return nil, fmt.Errorf("create replicator for index %q: %w", index.ID(), err)
	}

	if cfg.AsyncReplicationScheduler == nil && cfg.ReplicationFactor > 1 {
		return nil, fmt.Errorf("init index %q: async replication scheduler is required when ReplicationFactor > 1", cfg.ClassName.String())
	}
	if globalReplicationConfig == nil && cfg.ReplicationFactor > 1 {
		return nil, fmt.Errorf("init index %q: global replication config is required when ReplicationFactor > 1", cfg.ClassName.String())
	}
	index.asyncReplicationScheduler = cfg.AsyncReplicationScheduler

	index.closingCtx, index.closingCancel = context.WithCancel(context.Background())

	index.initCycleCallbacks()

	if err := index.checkSingleShardMigration(); err != nil {
		return nil, errors.Wrap(err, "migrating sharding state from previous version")
	}

	if err := os.MkdirAll(index.path(), os.ModePerm); err != nil {
		return nil, fmt.Errorf("init index %q: %w", index.ID(), err)
	}

	// Remove the snapshots root to clean up any bucket snapshots left behind
	// by operations that were interrupted (e.g. server crash). This runs once
	// at index creation time — not on every shard load — so it won't interfere
	// with a snapshot that may be in use after a tenant re-activation.
	if err := os.RemoveAll(index.snapshotsPath()); err != nil {
		logger.WithField("action", "remove_orphaned_snapshots").
			WithField("path", index.snapshotsPath()).
			Error(err)
	}

	if err := index.initAndStoreShards(ctx, class, promMetrics); err != nil {
		return nil, err
	}

	index.cycleCallbacks.compactionCycle.Start()
	index.cycleCallbacks.compactionAuxCycle.Start()
	index.cycleCallbacks.flushCycle.Start()

	return index, nil
}

// since called in Index's constructor there is no risk same shard will be inited/created in parallel,
// therefore shardCreateLocks are not used here
func (i *Index) initAndStoreShards(ctx context.Context, class *models.Class,
	promMetrics *monitoring.PrometheusMetrics,
) error {
	type shardInfo struct {
		name           string
		activityStatus string
	}

	var localShards []shardInfo
	className := i.Config.ClassName.String()

	state, err := i.namespaceState()
	if err != nil {
		// Treating the error as a namespace that keeps no shards open would
		// register no shards and report the class ready.
		return err
	}
	if !namespaces.ShardsShouldBeOpen(state) {
		// Nothing loads, and leaving the flag false suppresses the node-wide
		// object count for every index on this node.
		i.allShardsReady.Store(true)
		return nil
	}

	err = i.schemaReader.Read(className, true, func(_ *models.Class, shardingState *sharding.State) error {
		if shardingState == nil {
			return fmt.Errorf("unable to retrieve sharding state for class %s", className)
		}

		for shardName, physical := range shardingState.Physical {
			if shardingState.IsLocalShard(shardName) {
				localShards = append(localShards, shardInfo{
					name:           shardName,
					activityStatus: physical.ActivityStatus(),
				})
			}
		}

		return nil
	})
	if err != nil {
		return fmt.Errorf("failed to read sharding state: %w", err)
	}

	// db.indices does not receive this Index until every one of its shards has
	// loaded, so shards are tallied onto the DB here, as each is stored.
	startupShards := i.Config.StartupShards
	if startupShards == nil {
		startupShards = &startupShardCounters{}
	}

	hotShardNames := make([]string, 0, len(localShards))

	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU)

	for _, shard := range localShards {
		if shard.activityStatus != models.TenantActivityStatusHOT {
			continue
		}
		hotShardNames = append(hotShardNames, shard.name)
		shardName := shard.name
		eg.Go(func() error {
			switch {
			case i.Config.EnableLazyLoadShards:
				lazyShard := NewLazyLoadShard(ctx, promMetrics, shardName, i, class, i.centralJobQueue, i.indexCheckpoints,
					i.allocChecker, i.shardLoadLimiter, i.shardReindexer, true, i.bitmapBufPool)
				i.shards.Store(shardName, lazyShard)
				startupShards.lazy.Add(1)
				return nil
			default:
				// avoid footprint of empty shards
				if i.partitioningEnabled && i.unloadedShardIsEmpty(shardName) {
					i.shards.Store(shardName, NewLazyLoadShard(ctx, promMetrics, shardName, i, class,
						i.centralJobQueue, i.indexCheckpoints, i.allocChecker, i.shardLoadLimiter,
						i.shardReindexer, false, i.bitmapBufPool))
					startupShards.lazy.Add(1)
					return nil
				}
				// default behavior is to load all shards immediately
				if err := i.shardLoadLimiter.Acquire(ctx); err != nil {
					return fmt.Errorf("acquiring permit to load shard: %w", err)
				}
				defer i.shardLoadLimiter.Release()

				newShard, err := NewShard(ctx, promMetrics, shardName, i, class, i.centralJobQueue, i.scheduler,
					i.indexCheckpoints, i.shardReindexer, false, i.bitmapBufPool,
					monitoring.ShardRegistrationEager)
				if err != nil {
					return fmt.Errorf("init shard %s of index %s: %w", shardName, i.ID(), err)
				}

				promMetrics.NewLoadedShard()
				newShard.metricsRegistered.Store(true)
				i.shards.Store(shardName, newShard)
				startupShards.eager.Add(1)
				return nil
			}
		}, shardName)
	}

	if err := eg.Wait(); err != nil {
		return err
	}

	if !i.Config.EnableLazyLoadShards {
		i.allShardsReady.Store(true)
		return nil
	}

	if !i.Config.backgroundWarmupEnabled() {
		// Nothing else sets allShardsReady once the sweep is skipped, and
		// observeObjectCount publishes no node-wide object count while any index
		// reports false. Cold shards answer it from disk via ObjectCountAsync.
		i.allShardsReady.Store(true)
		i.logger.WithFields(logrus.Fields{
			"action":     "skip_load_all_shards",
			"class":      i.Config.ClassName.String(),
			"hot_shards": len(hotShardNames),
		}).Debug("background warmup disabled; lazy shards will load on first access")
		return nil
	}

	// Lazy loading is only half lazy: this loads every hot shard above
	// LazyLoadShardWarmupMinObjects, one per second.
	initLazyShardsInBackground := func() {
		// Fires on every exit, a closing index and a failed load included: the
		// node-wide object count reads a cold shard from disk, and staying false
		// would suppress it for every index on the node.
		defer i.allShardsReady.Store(true)

		ticker := time.NewTicker(time.Second)
		defer ticker.Stop()

		// This only reports and logs. The caller is the one that returns.
		abortIfClosing := func() bool {
			err := i.closingCtx.Err()
			if err == nil {
				return false
			}
			i.logger.
				WithField("action", "load_all_shards").
				Errorf("failed to load all shards: %v", err)
			return true
		}

		now := time.Now()
		tally := map[monitoring.WarmupOutcome]int{}
		recordOutcome := func(outcome monitoring.WarmupOutcome) {
			tally[outcome]++
			promMetrics.RecordWarmupOutcome(outcome)
		}

		for _, shardName := range hotShardNames {
			if abortIfClosing() {
				return
			}

			// Checked before the tick so only shards that will load wait a second.
			// Each skip still costs one unpaced directory listing.
			if shouldWarm, outcome := i.warmupCandidate(shardName); !shouldWarm {
				recordOutcome(outcome)
				continue
			}

			select {
			case <-i.closingCtx.Done():
			case <-ticker.C:
			}
			if abortIfClosing() {
				return
			}

			outcome, err := i.loadLocalShardIfActive(shardName)
			if err != nil {
				recordOutcome(monitoring.WarmupFailed)
				i.logger.
					WithField("action", "load_shard").
					WithField("shard_name", shardName).
					Errorf("failed to load shard, loading the rest anyway: %v", err)
				// A failure says nothing about the shards behind this one: memory
				// pressure is node-wide and transient, anything else is specific
				// to this shard. Stopping here would leave the rest cold.
				continue
			}
			if outcome != "" {
				recordOutcome(outcome)
			}
		}

		i.logger.
			WithFields(logrus.Fields{
				"action":                  "load_all_shards",
				"class":                   i.Config.ClassName.String(),
				"took":                    time.Since(now).String(),
				"loaded":                  tally[monitoring.WarmupLoaded],
				"failed":                  tally[monitoring.WarmupFailed],
				"skipped_shard_gone":      tally[monitoring.WarmupSkippedShardGone],
				"skipped_already_loaded":  tally[monitoring.WarmupSkippedAlreadyLoaded],
				"skipped_empty":           tally[monitoring.WarmupSkippedEmpty],
				"skipped_below_threshold": tally[monitoring.WarmupSkippedBelowThreshold],
			}).
			Debug("finished loading all shards")
	}

	enterrors.GoWrapper(initLazyShardsInBackground, i.logger)

	return nil
}

// unloadedShardIsEmpty reports whether a not-yet-loaded tenant shard has never
// held any objects, read from the persisted index counter without materializing
// the shard. The counter is incremented on every write, so it also accounts for
// data still in an unflushed/reused WAL (unlike segment metadata). On any error it
// returns false so the shard is loaded normally.
func (i *Index) unloadedShardIsEmpty(shardName string) bool {
	count, err := indexcounter.Read(shardPath(i.path(), shardName))
	return err == nil && count == 0
}

// warmupCandidate reports whether the startup sweep should load this shard, and
// where it should not, the outcome naming why. An object count it cannot read
// answers true, so no shard is left cold on a number nobody could take.
func (i *Index) warmupCandidate(shardName string) (bool, monitoring.WarmupOutcome) {
	i.shardCreateLocks.Lock(shardName)
	defer i.shardCreateLocks.Unlock(shardName)

	shard := i.shards.Load(shardName)
	if shard == nil {
		return false, monitoring.WarmupSkippedShardGone
	}
	lazyShard, ok := shard.(*LazyLoadShard)
	if !ok || lazyShard.isLoaded() {
		return false, monitoring.WarmupSkippedAlreadyLoaded
	}

	// avoid footprint of empty shards
	if i.partitioningEnabled && i.unloadedShardIsEmpty(shardName) {
		return false, monitoring.WarmupSkippedEmpty
	}

	minObjects := i.Config.LazyLoadShardWarmupMinObjects
	if minObjects == 0 {
		return true, ""
	}

	count, err := lazyShard.ObjectCountAsync(i.closingCtx)
	if err != nil {
		entry := i.logger.
			WithField("action", "load_shard").
			WithField("shard_name", shardName)
		if stderrors.Is(err, fs.ErrNotExist) {
			entry.Debugf("unloaded shard has no objects bucket yet, warming it up: %v", err)
		} else {
			entry.Warnf("failed to count objects of unloaded shard, warming it up anyway: %v", err)
		}
		return true, ""
	}
	if count > minObjects {
		return true, ""
	}

	// The persisted doc-id counter would see the writes the sidecars miss, but it
	// counts allocations rather than objects: deletes never lower it. A shard that
	// churned its way down to nothing would read large forever.

	i.logger.WithFields(logrus.Fields{
		"action":             "skip_shard_warmup",
		"class":              i.Config.ClassName.String(),
		"shard_name":         shardName,
		"object_count":       count,
		"warmup_min_objects": minObjects,
	}).Debug("shard holds too few objects to warm up; it loads on first access")
	return false, monitoring.WarmupSkippedBelowThreshold
}

// loadLocalShardIfActive loads a shard the startup sweep picked and reports the
// outcome to record. An empty outcome means the index refused the load for a
// reason that says nothing about this shard.
func (i *Index) loadLocalShardIfActive(shardName string) (monitoring.WarmupOutcome, error) {
	// Index.Shutdown skips a lazy shard that is not loaded yet, so a build racing
	// its sweep leaves an open store nothing will ever close. The refcount holds
	// the index open instead of closeLock, because a teardown queued for the write
	// lock would park every other reader for the whole build.
	if err := i.enterRead(); err != nil {
		return "", nil // a closed index is not a load failure
	}
	defer i.exitRead()

	// The namespace state read at boot goes stale as initLazyShardsInBackground
	// walks its shard list, so re-read it here. A refusal returns nil because an
	// error would end that loop for every shard behind this one.
	state, err := i.namespaceState()
	if err != nil || !namespaces.ShardsShouldBeOpen(state) {
		return "", nil
	}

	i.shardCreateLocks.Lock(shardName)
	defer i.shardCreateLocks.Unlock(shardName)

	// check if set to inactive in the meantime by concurrent call
	shard := i.shards.Load(shardName)
	if shard == nil {
		return monitoring.WarmupSkippedShardGone, nil
	}

	lazyShard, ok := shard.(*LazyLoadShard)
	if !ok {
		return monitoring.WarmupSkippedAlreadyLoaded, nil
	}

	// avoid footprint of empty shards
	if i.partitioningEnabled && i.unloadedShardIsEmpty(shardName) {
		return monitoring.WarmupSkippedEmpty, nil
	}

	// The load waits for a permit from the node-wide limiter while the index
	// is held open, so it has to give that wait up on a close request rather
	// than leave a teardown waiting for it to finish.
	ctx, done := i.cancelOnCloseRequested(context.Background())
	defer done()

	loaded, err := lazyShard.loadIfCold(ctx)
	if err != nil {
		return "", err
	}
	if !loaded {
		return monitoring.WarmupSkippedAlreadyLoaded, nil
	}

	return monitoring.WarmupLoaded, nil
}

// used to init/create shard in different moments of index's lifecycle, therefore it needs to be called
// within shardCreateLocks to prevent parallel create/init of the same shard
func (i *Index) initShard(ctx context.Context, shardName string, class *models.Class,
	promMetrics *monitoring.PrometheusMetrics, disableLazyLoad bool, implicitShardLoading bool,
) (ShardLike, error) {
	if disableLazyLoad {
		if err := i.allocChecker.CheckMappingAndReserve(3, int(lsmkv.FlushAfterDirtyDefault.Seconds())); err != nil {
			return nil, errors.Wrap(err, "memory pressure: cannot init shard")
		}

		if err := i.shardLoadLimiter.Acquire(ctx); err != nil {
			return nil, fmt.Errorf("acquiring permit to load shard: %w", err)
		}
		defer i.shardLoadLimiter.Release()

		shard, err := NewShard(ctx, promMetrics, shardName, i, class, i.centralJobQueue, i.scheduler,
			i.indexCheckpoints, i.shardReindexer, false, i.bitmapBufPool,
			monitoring.ShardRegistrationEager)
		if err != nil {
			return nil, fmt.Errorf("init shard %s of index %s: %w", shardName, i.ID(), err)
		}

		promMetrics.NewLoadedShard()
		shard.metricsRegistered.Store(true)
		return shard, nil
	}

	shard := NewLazyLoadShard(ctx, promMetrics, shardName, i, class, i.centralJobQueue, i.indexCheckpoints,
		i.allocChecker, i.shardLoadLimiter, i.shardReindexer, implicitShardLoading, i.bitmapBufPool)
	return shard, nil
}

func (i *Index) maintenanceModeEnabled() bool {
	return i.Config.MaintenanceModeEnabled != nil && i.Config.MaintenanceModeEnabled()
}

// Iterate over all objects in the index, applying the callback function to each one.  Adding or removing objects during iteration is not supported.
func (i *Index) IterateObjects(ctx context.Context, cb func(index *Index, shard ShardLike, object *storobj.Object) error) (err error) {
	return i.ForEachShard(func(_ string, shard ShardLike) error {
		wrapper := func(object *storobj.Object) error {
			return cb(i, shard, object)
		}
		bucket := shard.Store().Bucket(helpers.ObjectsBucketLSM)
		return bucket.IterateObjects(ctx, wrapper)
	})
}

// cancelOnCloseRequested derives a context cancelled on close request, so a teardown
// does not wait behind a lock the caller holds. Call the returned func when done.
// The derived context is cancelled with the same cause, so a caller can tell a
// drop from a shutdown.
func (i *Index) cancelOnCloseRequested(ctx context.Context) (context.Context, func()) {
	derived, cancel := context.WithCancelCause(ctx)
	stop := context.AfterFunc(i.closeRequestedCtx, func() {
		cancel(context.Cause(i.closeRequestedCtx))
	})
	return derived, func() {
		stop()
		cancel(nil)
	}
}

// closeCause reports why the index is closing, or nil if still open. It is
// nil-safe (unlike calling Err on closingCtx directly) and distinguishes a
// delete from a shutdown; an unsignalled close reads as [errIndexClosed].
//
// An Index whose contexts were never wired also reads as open, so
// [Index.ForEachShard] walks it rather than panicking.
func (i *Index) closeCause() error {
	if i.closingCtx == nil || i.closingCtx.Err() == nil {
		return nil
	}
	if i.closeRequestedCtx == nil {
		return errIndexClosed
	}
	if cause := context.Cause(i.closeRequestedCtx); cause != nil {
		return cause
	}
	return errIndexClosed
}

// closeRequestedCause reports why this index is closing or is about to, or nil
// if neither. [Index.closeCause] only answers once teardown reaches the index,
// but a delete first waits on db.indexLock and dropIndex; a walk starting in
// that window works on a collection already committed for deletion.
func (i *Index) closeRequestedCause() error {
	if i.closeRequestedCtx != nil {
		if cause := context.Cause(i.closeRequestedCtx); cause != nil {
			return cause
		}
	}
	return i.closeCause()
}

// forEachShardStrict is [Index.ForEachShard] for callers that must not
// mistake a walk that skipped shards for one that reached them all.
//
// A close is checked both before and after the walk ([Index.closeCause]),
// since sync.Map.Range can skip an entry removed mid-walk before the close
// became visible. A removal with no close cause (e.g. one tenant deleted)
// is instead caught by diffing unvisited names against the shard set
// captured before the walk, reported as [errShardsSkipped]. A shard added
// mid-walk is out of scope either way: Range makes no consistent-snapshot
// guarantee.
func (i *Index) forEachShardStrict(f func(name string, shard ShardLike) error) error {
	if cause := i.closeRequestedCause(); cause != nil {
		return cause
	}
	unvisited := i.shardNameSet()
	err := i.shards.Range(func(name string, shard ShardLike) error {
		delete(unvisited, name)
		return f(name, shard)
	})
	if err != nil {
		return err
	}
	if cause := i.closeCause(); cause != nil {
		return cause
	}
	if len(unvisited) > 0 {
		return fmt.Errorf("%w: %s", errShardsSkipped, strings.Join(reportedShardNames(unvisited), ", "))
	}
	return nil
}

// shardNameSet snapshots the shards currently in the map, used to detect
// shards skipped mid-walk. Paid once per walk rather than shared across
// walks: sharing would be cheaper, but a tenant dropped between two walks
// would then read as skipped in the later one, falsely reporting it truncated.
func (i *Index) shardNameSet() map[string]struct{} {
	names := map[string]struct{}{}
	i.shards.Range(func(name string, _ ShardLike) error {
		names[name] = struct{}{}
		return nil
	})
	return names
}

// reportedShardNames orders and caps names at [maxReportedErrors] for an
// operator-facing message; the cap itself is reported as an entry so the
// count of unaccounted shards isn't lost.
func reportedShardNames(names map[string]struct{}) []string {
	sorted := make([]string, 0, len(names))
	for name := range names {
		sorted = append(sorted, name)
	}
	slices.Sort(sorted)
	if len(sorted) <= maxReportedErrors {
		return sorted
	}
	return append(sorted[:maxReportedErrors:maxReportedErrors],
		fmt.Sprintf("(and %d more)", len(sorted)-maxReportedErrors))
}

// ForEachShard applies func f on each shard in the index.
//
// WARNING: only use this if you expect all LazyLoadShards to be loaded!
// Calling this method may lead to shards being force-loaded, causing
// unexpected CPU spikes. If you only want to apply f on loaded shards,
// call ForEachLoadedShard instead.
// Note: except Dropping and Shutting Down
func (i *Index) ForEachShard(f func(name string, shard ShardLike) error) error {
	// Check if the index is being dropped or shut down to avoid panics when the index is being deleted
	if i.closeCause() != nil {
		i.logger.WithField("action", "for_each_shard").Debug("index is being dropped or shut down")
		return nil
	}

	return i.shards.Range(f)
}

// shardIsLoaded reports whether the shard is materialized, i.e. whether
// touching it would force a cold shard to load.
func shardIsLoaded(shard ShardLike) bool {
	asLazyLoadShard, ok := shard.(*LazyLoadShard)
	return !ok || asLazyLoadShard.isLoaded()
}

func (i *Index) ForEachLoadedShard(f func(name string, shard ShardLike) error) error {
	return i.shards.Range(func(name string, shard ShardLike) error {
		if !shardIsLoaded(shard) {
			return nil
		}
		return f(name, shard)
	})
}

// publishShard makes the shard visible under shardName, reconciling it against
// the resource-pressure flag it may have read before becoming visible.
func (i *Index) publishShard(shardName string, shard ShardLike) {
	i.shards.Store(shardName, shard)
	i.db.reconcileShardResourcePressure(shardName, shard)
}

func (i *Index) ForEachShardConcurrently(f func(name string, shard ShardLike) error) error {
	// Check if the index is being dropped or shut down to avoid panics when the index is being deleted
	if i.closeCause() != nil {
		i.logger.WithField("action", "for_each_shard_concurrently").Debug("index is being dropped or shut down")
		return nil
	}
	return i.shards.RangeConcurrently(i.logger, f)
}

func (i *Index) ForEachLoadedShardConcurrently(f func(name string, shard ShardLike) error) error {
	return i.shards.RangeConcurrently(i.logger, func(name string, shard ShardLike) error {
		if !shardIsLoaded(shard) {
			return nil
		}
		return f(name, shard)
	})
}

// Iterate over all objects in the shard, applying the callback function to each one.  Adding or removing objects during iteration is not supported.
func (i *Index) IterateShards(ctx context.Context, cb func(index *Index, shard ShardLike) error) (err error) {
	return i.ForEachShard(func(key string, shard ShardLike) error {
		return cb(i, shard)
	})
}

// pinLoadedShard takes a shutdown refcount so bucket work scheduled onto an
// error group outlives the shard walk. A cold lazy shard has no store to
// refcount; its file surgery holds shardCreateLocks in shard_lazyloader.go.
func pinLoadedShard(shard ShardLike) (release func(), ok bool) {
	if lazy, isLazy := shard.(*LazyLoadShard); isLazy && !lazy.isLoaded() {
		return func() {}, true
	}

	release, err := shard.preventShutdown()
	if err != nil {
		return func() {}, false
	}
	return release, true
}

func (i *Index) addProperty(ctx context.Context, props ...*models.Property) error {
	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU)

	var releases []func()
	defer func() {
		for _, release := range releases {
			release()
		}
	}()

	// Skip cold shards: they'd only be force-loaded to create empty buckets,
	// which they build from the refreshed class at their next load anyway.
	i.ForEachLoadedShard(func(key string, shard ShardLike) error {
		release, ok := pinLoadedShard(shard)
		if !ok {
			return nil
		}
		releases = append(releases, release)
		shard.initPropertyBuckets(ctx, eg, false, props...)
		return nil
	})

	if err := eg.Wait(); err != nil {
		return errors.Wrapf(err, "extend idx '%s' with properties '%v'", i.ID(), props)
	}
	return nil
}

func (i *Index) updateProperty(ctx context.Context, property *models.Property) error {
	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU)

	var releases []func()
	defer func() {
		for _, release := range releases {
			release()
		}
	}()

	var payloadReads atomic.Int64
	i.ForEachShard(func(key string, shard ShardLike) error {
		release, ok := pinLoadedShard(shard)
		if !ok {
			return nil
		}
		releases = append(releases, release)
		shard.updatePropertyBuckets(ctx, eg, property, &payloadReads)
		return nil
	})

	err := eg.Wait()
	// Gated on work done, not property shape: every property has some index
	// type disabled, so gating on shape alone would log a sweep on every
	// update. This under-reports on purpose: a tracker removed by name match
	// alone costs no payload read, so an absent line doesn't mean nothing swept.
	if reads := payloadReads.Load(); reads > 0 {
		i.logger.WithFields(map[string]any{
			"property":      property.Name,
			"index_types":   disabledIndexTypes(property),
			"payload_reads": reads,
		}).Info("partial-reindex cleanup: migration dirs swept for disabled index types")
	}
	if err != nil {
		return errors.Wrapf(err, "update property '%v' idx '%s'", property.Name, i.ID())
	}

	return nil
}

func (i *Index) updateVectorIndexConfig(ctx context.Context,
	updated schemaConfig.VectorIndexConfig,
) error {
	// an updated is not specific to one shard, but rather all
	err := i.ForEachLoadedShard(func(name string, shard ShardLike) error {
		release, ok := pinLoadedShard(shard)
		if !ok {
			return nil
		}
		defer release()

		// At the moment, we don't do anything in an update that could fail, but
		// technically this should be part of some sort of a two-phase commit  or
		// have another way to rollback if we have updates that could potentially
		// fail in the future. For now that's not a realistic risk.
		if err := shard.UpdateVectorIndexConfig(ctx, updated); err != nil {
			return errors.Wrapf(err, "shard %s", name)
		}
		return nil
	})
	if err != nil {
		return err
	}
	i.vectorIndexUserConfigLock.Lock()
	defer i.vectorIndexUserConfigLock.Unlock()

	i.vectorIndexUserConfig = updated

	return nil
}

func (i *Index) updateVectorIndexConfigs(ctx context.Context,
	updated map[string]schemaConfig.VectorIndexConfig,
) error {
	err := i.ForEachLoadedShard(func(name string, shard ShardLike) error {
		release, ok := pinLoadedShard(shard)
		if !ok {
			return nil
		}
		defer release()

		if err := shard.UpdateVectorIndexConfigs(ctx, updated); err != nil {
			return fmt.Errorf("shard %q: %w", name, err)
		}
		return nil
	})
	if err != nil {
		return err
	}

	i.vectorIndexUserConfigLock.Lock()
	defer i.vectorIndexUserConfigLock.Unlock()

	for targetName, targetCfg := range updated {
		i.vectorIndexUserConfigs[targetName] = targetCfg
	}

	return nil
}

func (i *Index) dropVectorIndex(ctx context.Context, targetVector string) error {
	// Delete the config entry first so that a concurrent shard load
	// (initTargetVectors) won't try to re-initialize the vector being dropped.
	func() {
		i.vectorIndexUserConfigLock.Lock()
		defer i.vectorIndexUserConfigLock.Unlock()
		delete(i.vectorIndexUserConfigs, targetVector)
	}()

	if err := i.ForEachShardConcurrently(func(name string, shard ShardLike) error {
		release, ok := pinLoadedShard(shard)
		if !ok {
			return nil
		}
		defer release()

		if err := shard.DropVectorIndex(ctx, targetVector); err != nil {
			return fmt.Errorf("shard %q: %w", name, err)
		}
		return nil
	}); err != nil {
		// Log the error but still return it so the caller knows the drop was
		// not fully successful. The shard-init helper will clean up any
		// leftover files on next shard initialization.
		i.logger.WithError(err).WithField("vector", targetVector).
			Warn("some shards failed to drop vector index; leftover files will be cleaned up on next shard init")
		return err
	}

	return nil
}

func (i *Index) GetInvertedIndexConfig() schema.InvertedIndexConfig {
	i.invertedIndexConfigLock.Lock()
	defer i.invertedIndexConfigLock.Unlock()

	return i.invertedIndexConfig
}

func (i *Index) updateInvertedIndexConfig(ctx context.Context,
	updated schema.InvertedIndexConfig,
) error {
	i.invertedIndexConfigLock.Lock()
	defer i.invertedIndexConfigLock.Unlock()

	i.invertedIndexConfig = updated

	err := i.stopwords.ReplaceDetectorFromConfig(updated.Stopwords)
	if err != nil {
		return fmt.Errorf("update inverted index config: %w", err)
	}

	presetDetectors, err := stopwords.BuildPresetDetectors(updated.StopwordPresets)
	if err != nil {
		return fmt.Errorf("update inverted index config: %w", err)
	}
	i.stopwordProvider.Store(stopwords.NewProvider(i.stopwords, presetDetectors))

	err = tokenizer.AddCustomDict(i.Config.ClassName.String(), updated.TokenizerUserDict)
	if err != nil {
		return errors.Wrap(err, "updating inverted index config")
	}

	return nil
}

// getStopwordProvider returns the current stopword provider, which bundles
// the collection-level fallback detector and the cached user-defined preset
// detectors. Safe for concurrent use without invertedIndexConfigLock.
func (i *Index) getStopwordProvider() *stopwords.Provider {
	return i.stopwordProvider.Load()
}

func (i *Index) asyncReplicationGloballyDisabled() bool {
	if i.globalreplicationConfig == nil {
		return false
	}
	return i.globalreplicationConfig.AsyncReplicationDisabled.Get()
}

func (i *Index) updateReplicationConfig(ctx context.Context, cfg *models.ReplicationConfig) error {
	class := i.getClass()
	if class == nil {
		return fmt.Errorf("update replication config: class %q not found in schema", i.Config.ClassName)
	}

	// Convert before mutating so an error can't leave a torn Config behind.
	config, err := asyncReplicationConfigFromModel(multitenancy.IsMultiTenant(class.MultiTenancyConfig), cfg.AsyncConfig, i.logger.WithField("class", i.Config.ClassName))
	if err != nil {
		return err
	}

	// The lock must not span the fan-out (ABBA deadlock, see applyAsyncReplicationToLoadedShards); post-unlock loads read the new config.
	func() {
		i.replicationConfigLock.Lock()
		defer i.replicationConfigLock.Unlock()

		i.Config.ReplicationFactor = cfg.Factor
		i.Config.DeletionStrategy = cfg.DeletionStrategy
		i.Config.AsyncReplicationConfig = config
	}()

	// unloaded shards will fetch the latest config when they are loaded
	return i.applyAsyncReplicationToLoadedShards(ctx)
}

// withAsyncReplicationApply serializes fn with all config applies; never enter it holding replicationConfigLock (lazy-load ABBA).
func (i *Index) withAsyncReplicationApply(fn func() error) error {
	i.asyncReplicationApplyWaiters.Add(1)
	i.asyncReplicationApplyLock.Lock()
	i.asyncReplicationApplyWaiters.Add(-1)
	defer i.asyncReplicationApplyLock.Unlock()
	return fn()
}

// applyAsyncReplicationToLoadedShards (re-)applies the per-shard enable/disable decision to every loaded shard (an over-replicated shard at factor 1 keeps async on).
// Callers must NOT hold i.replicationConfigLock — the fan-out takes shard mutexes a mid-load shard holds while RLocking the config (ABBA deadlock).
// Fan-outs are serialized by asyncReplicationApplyLock and snapshot the config at start, so the last one applies the freshest and a stale caller can never clobber a fresher apply.
func (i *Index) applyAsyncReplicationToLoadedShards(ctx context.Context) error {
	return i.withAsyncReplicationApply(func() error {
		return i.applyAsyncReplicationToLoadedShardsLocked(ctx)
	})
}

// applyAsyncReplicationToLoadedShardsLocked is the fan-out body; the apply lock must be held.
func (i *Index) applyAsyncReplicationToLoadedShardsLocked(ctx context.Context) error {
	i.replicationConfigLock.RLock()
	config := i.Config.AsyncReplicationConfig
	rf := i.Config.ReplicationFactor
	i.replicationConfigLock.RUnlock()
	// Snapshot the runtime flag too: one pass must not mix enable and disable decisions.
	globallyDisabled := i.asyncReplicationGloballyDisabled()

	// iterate concurrently so one shard's fault can't skip the rest (errors are
	// accumulated, not first-error abort).
	return i.ForEachLoadedShardConcurrently(func(name string, shard ShardLike) error {
		// Stop the per-shard walk if the caller's context (e.g. server
		// shutdown) was cancelled — the apply below does synchronous disk I/O.
		if err := ctx.Err(); err != nil {
			return err
		}

		ctrl, ok := shard.(asyncReplicationController)
		if !ok {
			return fmt.Errorf("shard %q does not implement asyncReplicationController", name)
		}

		if i.asyncReplicationEnabledForShardWith(name, rf, globallyDisabled) {
			// enableAsyncReplication handles the already-running case by updating
			// the stored config in-place. The scheduler's runEntry detects height
			// changes and triggers a rebuild via asyncRepNeedsRebuild, so a
			// stop/start cycle is only needed for height changes (handled there).
			if err := ctrl.enableAsyncReplication(ctx, config); err != nil {
				return fmt.Errorf("updating async replication on shard %q: %w", name, err)
			}
		} else {
			// An active target-node override (e.g. in-progress movement) forces async
			// replication on; don't tear it down (removeTargetNodeOverride handles it).
			if ctrl.hasActiveAsyncReplicationTargetOverrides() {
				return nil
			}
			if err := ctrl.disableAsyncReplication(ctx); err != nil {
				return fmt.Errorf("updating async replication on shard %q: %w", name, err)
			}
		}
		return nil
	})
}

// reconcileAsyncReplication re-applies the enable/disable decision to this
// index's loaded shards after a runtime change of the global
// AsyncReplicationDisabled flag. Must not short-circuit on
// ReplicationFactor <= 1 — over-replicated shards still need async.
func (i *Index) reconcileAsyncReplication(ctx context.Context) error {
	return i.applyAsyncReplicationToLoadedShards(ctx)
}

// ReconcileAsyncReplication re-applies async replication to every loaded shard
// of every index. The runtime-config hook calls it when the global
// AsyncReplicationDisabled flag changes, so shards loaded while it was disabled
// get (un)registered to match instead of staying stale until a reload.
func (db *DB) ReconcileAsyncReplication(ctx context.Context) error {
	// Snapshot only the index pointers under indexLock; the dropIndex read lock
	// is taken per index just-in-time below, not up front. The pointers stay
	// valid even if a concurrent DeleteIndex removes one from db.indices.
	var indices []*Index
	func() {
		db.indexLock.RLock()
		defer db.indexLock.RUnlock()
		for _, idx := range db.indices {
			indices = append(indices, idx)
		}
	}()

	// Reconcile outside indexLock so the per-shard apply (which can do hashtree
	// I/O) does not block index creation/deletion. Each index takes its own
	// dropIndex.RLock only while it is being reconciled — the established
	// discipline for using an index outside indexLock (see SnapshotShards) —
	// so a concurrent DeleteIndex is blocked only on the current index, not on
	// every index still queued. If a DeleteIndex completed between the snapshot
	// and acquiring dropIndex.RLock, drop() has set idx.closed, so the closed
	// check below skips the index.
	var failed int
	for processed, idx := range indices {
		// Stop the walk if the caller's context (e.g. server shutdown) was
		// cancelled; the per-index apply does synchronous hashtree disk I/O.
		if err := ctx.Err(); err != nil {
			return fmt.Errorf("reconcile async replication interrupted after %d of %d indices: %w",
				processed, len(indices), err)
		}

		err := func() error {
			idx.dropIndex.RLock()
			defer idx.dropIndex.RUnlock()
			if err := idx.enterRead(); err != nil {
				return nil // index is shutting down; nothing to reconcile
			}
			defer idx.exitRead()
			return idx.reconcileAsyncReplication(ctx)
		}()
		if err != nil {
			failed++
			db.logger.WithField("action", "reconcile_async_replication").
				WithField("class", idx.Config.ClassName).Error(err)
		}
	}
	if failed > 0 {
		// Surface a metric: the only self-healing trigger is another flag toggle
		// or schema update, so operators need to detect a partial reconcile.
		if db.asyncReplicationScheduler != nil {
			db.asyncReplicationScheduler.metrics.addReconcileFailures(failed)
		}
		return fmt.Errorf("reconcile async replication failed for %d of %d indices", failed, len(indices))
	}
	return nil
}

func (i *Index) ReplicationFactor() int64 {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.Config.ReplicationFactor
}

func (i *Index) DeletionStrategy() string {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.Config.DeletionStrategy
}

type IndexConfig struct {
	RootPath                            string
	ClassName                           schema.ClassName
	QueryMaximumResults                 int64
	QueryHybridMaximumResults           int64
	QueryNestedRefLimit                 int64
	ResourceUsage                       config.ResourceUsage
	LazySegmentsDisabled                bool
	SegmentInfoIntoFileNameEnabled      bool
	WriteMetadataFilesEnabled           bool
	MemtablesFlushDirtyAfter            int
	MemtablesInitialSizeMB              int
	MemtablesMaxSizeMB                  int
	MemtablesMinActiveSeconds           int
	MemtablesMaxActiveSeconds           int
	MinMMapSize                         int64
	MaxReuseWalSize                     int64
	SegmentsCleanupIntervalSeconds      int
	SeparateObjectsCompactions          bool
	CycleManagerRoutinesFactor          int
	IndexRangeableInMemory              bool
	MaxSegmentSize                      int64
	ReplicationFactor                   int64
	DeletionStrategy                    string
	AsyncReplicationConfig              AsyncReplicationConfig
	AsyncReplicationScheduler           *AsyncReplicationScheduler
	AvoidMMap                           bool
	EnableLazyLoadShards                bool
	LazyLoadShardWarmupMinObjects       int64 // read only when EnableLazyLoadShards is true
	ForceFullReplicasSearch             bool
	TransferInactivityTimeout           time.Duration
	HaltForTransferTimeout              time.Duration
	LSMEnableSegmentsChecksumValidation bool
	SkipWriteClassNameOnDisk            bool
	TrackVectorDimensions               bool
	TrackVectorDimensionsInterval       time.Duration
	UsageEnabled                        bool
	ShardLoadLimiter                    *loadlimiter.LoadLimiter
	StartupShards                       *startupShardCounters
	BucketLoadLimiter                   *loadlimiter.LoadLimiter
	NamespacesExister                   namespaces.Exister
	ObjectsTTLBatchSize                 *configRuntime.DynamicValue[int]
	ObjectsTTLPauseEveryNoBatches       *configRuntime.DynamicValue[int]
	ObjectsTTLPauseDuration             *configRuntime.DynamicValue[time.Duration]

	HNSWMaxLogSize               int64
	HNSWWaitForCachePrefill      bool
	HNSWFlatSearchConcurrency    int
	HNSWAcornFilterRatio         float64
	HNSWGeoIndexEF               int
	VisitedListPoolMaxSize       int
	BM25FilterTombMergeGateRatio *configRuntime.DynamicValue[float64]

	QuerySlowLogEnabled         *configRuntime.DynamicValue[bool]
	QuerySlowLogThreshold       *configRuntime.DynamicValue[time.Duration]
	InvertedSorterDisabled      *configRuntime.DynamicValue[bool]
	QueryBatchedContainsEnabled *configRuntime.DynamicValue[bool]
	LazyPropertyLengthsEnabled  *configRuntime.DynamicValue[bool]
	MaintenanceModeEnabled      func() bool

	HFreshEnabled bool

	AutoTenantActivation bool

	DisableDimensionMetrics *configRuntime.DynamicValue[bool]
}

// backgroundWarmupEnabled reports whether the startup sweep runs at all. Only the
// lazy-loading path has one, and a negative LazyLoadShardWarmupMinObjects turns it
// off. Which shards a non-negative value loads is warmupCandidate's call.
func (c IndexConfig) backgroundWarmupEnabled() bool {
	return c.EnableLazyLoadShards && c.LazyLoadShardWarmupMinObjects >= 0
}

func indexID(class schema.ClassName) string {
	return strings.ToLower(string(class))
}

func (i *Index) putObject(ctx context.Context, object *storobj.Object,
	replProps *additional.ReplicationProperties, tenantName string, schemaVersion uint64,
) error {
	if i.Config.ClassName != object.Class() {
		return fmt.Errorf("cannot import object of class %s into index of class %s",
			object.Class(), i.Config.ClassName)
	}
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return fmt.Errorf("wait for schema version %d: %w", schemaVersion, err)
		}
	}
	targetShard, err := i.shardResolver.ResolveShard(ctx, object)
	if err != nil {
		switch {
		case errors.As(err, &objects.ErrMultiTenancy{}):
			return objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
		case errors.As(err, &authzerrors.Forbidden{}):
			return fmt.Errorf("determine shard: %w", err)
		default:
			return objects.NewErrInvalidUserInput("determine shard: %v", err)
		}
	}
	if replProps == nil {
		replProps = defaultConsistency()
	}
	if i.shardHasMultipleReplicasWrite(tenantName, targetShard.Shard) {
		cl := routerTypes.ConsistencyLevel(replProps.ConsistencyLevel)
		if err := i.replicator.PutObject(ctx, targetShard.Shard, object, cl, schemaVersion); err != nil {
			return fmt.Errorf("replicate insertion: shard=%q: %w", targetShard.Shard, err)
		}
		return nil
	}

	return i.withShardOrRemote(ctx, object.Object.Tenant, targetShard.Shard, localShardOperationWrite, schemaVersion,
		func(shard ShardLike) error {
			i.backupLock.RLock(targetShard.Shard)
			defer i.backupLock.RUnlock(targetShard.Shard)

			if err := shard.PutObject(ctx, object); err != nil {
				return fmt.Errorf("put local object: shard=%q: %w", targetShard.Shard, err)
			}

			return nil
		},
		func() error {
			if err := i.remote.PutObject(ctx, targetShard.Shard, object, schemaVersion); err != nil {
				return fmt.Errorf("put remote object: shard=%q: %w", targetShard.Shard, err)
			}
			return nil
		})
}

func (i *Index) IncomingPutObject(ctx context.Context, shardName string,
	object *storobj.Object, schemaVersion uint64,
) error {
	// This is a bit hacky, the problem here is that storobj.Parse() currently
	// misses date fields as it has no way of knowing that a date-formatted
	// string was actually a date type. However, adding this functionality to
	// Parse() would break a lot of code, because it currently
	// schema-independent. To find out if a field is a date or date[], we need to
	// involve the schema, thus why we are doing it here. This was discovered as
	// part of https://github.com/weaviate/weaviate/issues/1775
	if err := i.parseDateFieldsInProps(object.Object.Properties); err != nil {
		return err
	}

	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	return i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		return shard.PutObject(ctx, object)
	})
}

func (i *Index) replicationEnabled() bool {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.Config.ReplicationFactor > 1
}

// ensureShardLocallyReady rejects reads of a loading shard so the caller retries
// on a replica. With replication off there is none, so the shard is used as it is
// rather than failing a read that would otherwise only be slow.
func (i *Index) ensureShardLocallyReady(shard ShardLike) error {
	if shard.GetStatus() == storagestate.StatusLoading && i.replicationEnabled() {
		return enterrors.NewErrUnprocessable(
			fmt.Errorf("local %s shard is not ready", shard.Name()))
	}
	return nil
}

func (i *Index) shardHasMultipleReplicasWrite(tenantName, shardName string) bool {
	// if replication is enabled, we always have multiple replicas
	if i.replicationEnabled() {
		return true
	}
	if r := i.getReplicationFSMReader(); r != nil &&
		r.HasActiveReplicationForShard(i.Config.ClassName.String(), shardName) {
		return true
	}
	// if the router is nil, preserve previous behavior by returning false
	if i.router == nil {
		return false
	}
	ws, err := i.router.GetWriteReplicasLocation(i.Config.ClassName.String(), tenantName, shardName)
	if err != nil {
		return false
	}
	return len(ws.NodeNames()) > 1
}

func (i *Index) shardHasMultipleReplicasRead(tenantName, shardName string) bool {
	// if replication is enabled, we always have multiple replicas
	if i.replicationEnabled() {
		return true
	}
	// if the router is nil, preserve previous behavior by returning false
	if i.router == nil {
		return false
	}
	replicas, err := i.router.GetReadReplicasLocation(i.Config.ClassName.String(), tenantName, shardName)
	if err != nil {
		return false
	}
	return len(replicas.NodeNames()) > 1
}

// anyShardHasMultipleReplicasRead returns true if any of the shards has multiple replicas
func (i *Index) anyShardHasMultipleReplicasRead(tenantName string, shardNames []string) bool {
	if i.replicationEnabled() {
		return true
	}
	for _, shardName := range shardNames {
		if i.shardHasMultipleReplicasRead(tenantName, shardName) {
			return true
		}
	}
	return false
}

type localShardOperation string

const (
	localShardOperationWrite localShardOperation = "write"
	localShardOperationRead  localShardOperation = "read"
)

// getShardForDirectLocalOperation is used to try to get a shard for a local read/write operation.
// It will return the shard if it is found, and a release function to release the shard.
// The shard will be nil if the shard is not found, or if the local shard should not be used.
// The release function is never nil, including on error, so defer it immediately
// after the call: an error can be returned after a reference was already taken.
func (i *Index) getShardForDirectLocalOperation(
	ctx context.Context,
	tenantName, shardName string,
	operation localShardOperation,
	schemaVersion uint64,
) (ShardLike, func(), error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, release, err
	}

	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return nil, release, fmt.Errorf("shard %q: wait for schema version %d: %w", shardName, schemaVersion, err)
		}
	}

	className := i.Config.ClassName.String()

	switch operation {
	case localShardOperationWrite:
		return i.getShardForWrite(ctx, className, tenantName, shardName, shard, release)
	case localShardOperationRead:
		return i.getShardForRead(ctx, className, tenantName, shardName, shard, release)
	default:
		return nil, release, fmt.Errorf("shard %q: invalid local shard operation: %s", shardName, operation)
	}
}

func (i *Index) getShardForWrite(
	ctx context.Context,
	className, tenantName, shardName string,
	shard ShardLike,
	release func(),
) (ShardLike, func(), error) {
	ws, err := i.router.GetWriteReplicasLocation(className, tenantName, shardName)
	tenantInactiveWithAutoActivation := errors.Is(err, enterrors.ErrTenantNotActive) && i.Config.AutoTenantActivation
	if err != nil && !tenantInactiveWithAutoActivation {
		i.logger.WithFields(logrus.Fields{
			"error":      err,
			"tenantName": tenantName,
			"shardName":  shardName,
		}).Error("get write replicas location")
		// we don't return error here because we want to continue the operation
		// and let the caller handle nil shard and request from remote
		// TODO: we should fix the underlying validator
		return shard, release, nil
	}

	if !slices.Contains(ws.NodeNames(), i.replicator.LocalNodeName()) {
		// This node is not a write replica for this shard.
		return nil, release, nil
	}

	// if the shard is not found, initialize it based on AutoTenantActivation
	if shard == nil {
		// this to handle MT auto enable and RF=1 case
		ensureInit := i.Config.AutoTenantActivation || !i.replicationEnabled()
		initShard, initRelease, err := i.getOptInitLocalShard(ctx, shardName, ensureInit, callerUserRequest)
		// the reference we were handed is not returned to the caller, release it
		release()
		if err != nil {
			return nil, initRelease, err
		}
		return initShard, initRelease, nil
	}

	return shard, release, nil
}

func (i *Index) getShardForRead(
	ctx context.Context,
	className, tenantName, shardName string,
	shard ShardLike,
	release func(),
) (ShardLike, func(), error) {
	rs, err := i.router.GetReadReplicasLocation(className, tenantName, shardName)
	tenantInactiveWithAutoActivation := errors.Is(err, enterrors.ErrTenantNotActive) && i.Config.AutoTenantActivation
	if err != nil && !tenantInactiveWithAutoActivation {
		i.logger.WithFields(logrus.Fields{
			"error":      err,
			"tenantName": tenantName,
			"shardName":  shardName,
		}).Error("get read replicas location")
		// we don't return error here because we want to continue the operation
		// and let the caller handle nil shard and request from remote
		// TODO: we should fix the underlying validator
		return shard, release, nil
	}

	if !slices.Contains(rs.NodeNames(), i.replicator.LocalNodeName()) {
		// This node is not a read replica for this shard.
		return nil, release, nil
	}

	if shard == nil {
		// this to handle MT auto enable and RF=1 case
		ensureInit := i.Config.AutoTenantActivation || !i.replicationEnabled()
		initShard, initRelease, err := i.getOptInitLocalShard(ctx, shardName, ensureInit, callerUserRequest)
		// the reference we were handed is not returned to the caller, release it
		release()
		if err != nil {
			return nil, initRelease, err
		}
		return initShard, initRelease, nil
	}

	return shard, release, nil
}

func (i *Index) asyncReplicationEnabled() bool {
	return i.Config.ReplicationFactor > 1 && !i.asyncReplicationGloballyDisabled()
}

// asyncReplicationEnabledForShard is the per-shard async-replication gate.
// Caller MUST hold replicationConfigLock.
func (i *Index) asyncReplicationEnabledForShard(shardName string) bool {
	return i.asyncReplicationEnabledForShardWith(shardName, i.Config.ReplicationFactor, i.asyncReplicationGloballyDisabled())
}

// asyncReplicationEnabledForShardWith takes the factor and global-disable flag as
// snapshots so lock-free fan-outs get one consistent decision per pass; the
// per-shard replicas lookup stays live (FSM read with its own locking).
func (i *Index) asyncReplicationEnabledForShardWith(shardName string, rf int64, globallyDisabled bool) bool {
	if i.asyncReplicationScheduler == nil {
		return false
	}

	if globallyDisabled {
		return false
	}

	if rf > 1 {
		return true
	}

	replicas, err := i.schemaReader.ShardReplicas(i.Config.ClassName.String(), shardName)
	if err != nil {
		i.logger.
			WithField("action", "async_replication").
			WithField("class_name", i.Config.ClassName.String()).
			WithField("shard_name", shardName).
			Warnf("async replication gate: could not read shard replicas: %v", err)
		return false
	}

	// Over-replication at RF=1: mid scale-out, or RF lowered before extras drained.
	return len(replicas) > 1
}

// withShardOrRemote runs local when this node has a usable shard for shardName,
// otherwise remote. A failed lookup runs neither and returns its error. The shard
// reference is held for the whole local call and released on every path.
func (i *Index) withShardOrRemote(ctx context.Context, tenantName, shardName string,
	operation localShardOperation, schemaVersion uint64,
	local func(shard ShardLike) error, remote func() error,
) error {
	shard, release, err := i.getShardForDirectLocalOperation(ctx, tenantName, shardName, operation, schemaVersion)
	defer release()
	if err != nil {
		return err
	}
	if shard == nil {
		return remote()
	}
	return local(shard)
}

func (i *Index) AsyncReplicationEnabledForShard(shardName string) bool {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.asyncReplicationEnabledForShard(shardName)
}

// asyncReplicationStateForShard reads the per-shard decision and the config under
// one lock acquisition, so shard load cannot mix two config generations.
func (i *Index) asyncReplicationStateForShard(shardName string) (enabled bool, config AsyncReplicationConfig) {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.asyncReplicationEnabledForShard(shardName), i.Config.AsyncReplicationConfig
}

func (i *Index) SetReplicationFSMReader(r replicationTypes.ReplicationFSMReader) {
	i.replicationFSMReader.Store(&r)
}

// getReplicationFSMReader returns the wired reader, or nil when none is set.
func (i *Index) getReplicationFSMReader() replicationTypes.ReplicationFSMReader {
	if p := i.replicationFSMReader.Load(); p != nil {
		return *p
	}
	return nil
}

// IsAsyncReplicationEnabledOrIrrelevant is the export gate: true if async
// replication is irrelevant (RF ≤ 1 and no shard has a non-terminal movement
// op) or enabled (RF > 1 and not globally disabled).
//
// The non-terminal-op clause covers the replica-movement window: BelongsToNodes
// transiently holds source and target, so the export selector could otherwise
// route the snapshot to either replica via least-loaded scheduling. Per-shard
// readiness inspection isn't viable here (multi-tenant shards constantly
// transition and would reject create-then-export during warm-up); the FSM read
// is safe because it reads RAFT-replicated state that only flips on FSM apply.
func (i *Index) IsAsyncReplicationEnabledOrIrrelevant() bool {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	if i.Config.ReplicationFactor > 1 {
		return i.asyncReplicationEnabled()
	}

	// Conservative on read failure: silently allowing export defeats the gate.
	midMovement, err := i.anyShardMidMovement()
	if err != nil {
		i.logger.
			WithField("action", "async_replication").
			WithField("class_name", i.Config.ClassName.String()).
			Warnf("IsAsyncReplicationEnabledOrIrrelevant: could not read sharding state, refusing export: %v", err)
		return false
	}
	return !midMovement
}

func (i *Index) anyShardMidMovement() (bool, error) {
	// Nil reader: treat as "no in-flight ops". Mirrors the runHashbeatCycle
	// guard so tests without an FSM wired (and any future Index-construction
	// path that doesn't call SetReplicationFSMReader) don't nil-panic.
	fsmReader := i.getReplicationFSMReader()
	if fsmReader == nil {
		return false, nil
	}
	var midMovement bool
	className := i.Config.ClassName.String()
	err := i.schemaReader.Read(className, true, func(_ *models.Class, state *sharding.State) error {
		if state == nil {
			return fmt.Errorf("unable to retrieve sharding state for class %s", className)
		}
		for shardName := range state.Physical {
			// Short-circuit on first match: map iteration is randomized, so
			// without this we'd non-deterministically miss other in-flight shards.
			if fsmReader.HasActiveReplicationForShard(className, shardName) {
				midMovement = true
				return nil
			}
		}
		return nil
	})
	if err != nil {
		return false, err
	}
	return midMovement, nil
}

func (i *Index) AsyncReplicationConfig() AsyncReplicationConfig {
	i.replicationConfigLock.RLock()
	defer i.replicationConfigLock.RUnlock()

	return i.Config.AsyncReplicationConfig
}

// InitAsyncReplicationOnShard force-starts async replication on a single named
// shard. Called by the copier after a shard copy completes, before the index's
// ReplicationFactor has been updated cluster-wide.
func (i *Index) InitAsyncReplicationOnShard(ctx context.Context, shardName string) error {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return fmt.Errorf("get shard %s: %w", shardName, err)
	}
	if shard == nil {
		return fmt.Errorf("get shard %s: not found", shardName)
	}
	defer release()

	ctrl, ok := shard.(asyncReplicationController)
	if !ok {
		return fmt.Errorf("shard %q does not implement asyncReplicationController", shardName)
	}

	return i.withAsyncReplicationApply(func() error {
		return ctrl.enableAsyncReplication(ctx, i.AsyncReplicationConfig())
	})
}

// RevertAsyncReplicationOnShard reverts a shard to the async replication state
// dictated by the index's current ReplicationFactor. Called by the copier when
// rolling back a copy operation.
func (i *Index) RevertAsyncReplicationOnShard(ctx context.Context, shardName string) error {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return fmt.Errorf("get shard %s: %w", shardName, err)
	}
	if shard == nil {
		return fmt.Errorf("get shard %s: not found", shardName)
	}
	defer release()

	ctrl, ok := shard.(asyncReplicationController)
	if !ok {
		return fmt.Errorf("shard %q does not implement asyncReplicationController", shardName)
	}

	// Apply-lock serialized; a concurrent update's fan-out re-snapshots behind it.
	return i.withAsyncReplicationApply(func() error {
		enabled, config := i.asyncReplicationStateForShard(shardName)
		if enabled {
			return ctrl.enableAsyncReplication(ctx, config)
		}
		return ctrl.disableAsyncReplication(ctx)
	})
}

// ReconcileAsyncReplicationForShard re-applies the per-shard async-replication
// decision after a replica was added or removed. No-op when the shard is not
// loaded locally — it must not be force-loaded just to toggle async; the init
// gate re-derives on next load.
func (i *Index) ReconcileAsyncReplicationForShard(ctx context.Context, shardName string) error {
	shard := i.shards.Loaded(shardName)
	if shard == nil {
		return nil
	}

	ctrl, ok := shard.(asyncReplicationController)
	if !ok {
		return fmt.Errorf("shard %q does not implement asyncReplicationController", shardName)
	}

	// Config lock must not span the ctrl call (3-way lazy-load ABBA); blocking on the apply lock is deliberate — skipping would lose the apply behind a fan-out that snapshotted earlier.
	return i.withAsyncReplicationApply(func() error {
		enabled, config := i.asyncReplicationStateForShard(shardName)
		if enabled {
			return ctrl.enableAsyncReplication(ctx, config)
		}
		if ctrl.hasActiveAsyncReplicationTargetOverrides() {
			return nil
		}
		return ctrl.disableAsyncReplication(ctx)
	})
}

// resumeAfterAbortedOffload reverses an aborted offloading HaltForTransfer: resume maintenance and rebuild async replication from a full scan so the shard cannot silently diverge. No-op when not loaded.
func (i *Index) resumeAfterAbortedOffload(ctx context.Context, shardName string) error {
	shard := i.shards.Loaded(shardName)
	if shard == nil {
		return nil
	}

	ctrl, ok := shard.(asyncReplicationController)
	if !ok {
		return fmt.Errorf("shard %q does not implement asyncReplicationController", shardName)
	}

	// Idempotent when not halted (e.g. HaltForTransfer failed and self-resumed).
	if err := shard.resumeMaintenanceCycles(ctx); err != nil {
		return fmt.Errorf("resume maintenance cycles on shard %q: %w", shardName, err)
	}

	// Apply-lock serialized so a stale rebuild cannot install an old-config tree after a fresher apply.
	return i.withAsyncReplicationApply(func() error {
		enabled, config := i.asyncReplicationStateForShard(shardName)
		return ctrl.rebuildAsyncReplicationFromScratch(ctx, enabled, config)
	})
}

// parseDateFieldsInProps checks the schema for the current class for which
// fields are date fields, then - if they are set - parses them accordingly.
// Works for both date and date[].
func (i *Index) parseDateFieldsInProps(props interface{}) error {
	if props == nil {
		return nil
	}

	propMap, ok := props.(map[string]interface{})
	if !ok {
		// don't know what to do with this
		return nil
	}

	c := i.getSchema.ReadOnlyClass(i.Config.ClassName.String())
	if c == nil {
		return fmt.Errorf("class %s not found in schema", i.Config.ClassName)
	}

	for _, prop := range c.Properties {
		if prop.DataType[0] == string(schema.DataTypeDate) {
			raw, ok := propMap[prop.Name]
			if !ok {
				// prop is not set, nothing to do
				continue
			}

			parsed, err := parseAsStringToTime(raw)
			if err != nil {
				return errors.Wrapf(err, "time prop %q", prop.Name)
			}

			propMap[prop.Name] = parsed
		}

		if prop.DataType[0] == string(schema.DataTypeDateArray) {
			raw, ok := propMap[prop.Name]
			if !ok {
				// prop is not set, nothing to do
				continue
			}

			asSlice, ok := raw.([]string)
			if !ok {
				return errors.Errorf("parse as time array, expected []interface{} got %T",
					raw)
			}
			parsedSlice := make([]interface{}, len(asSlice))
			for j := range asSlice {
				parsed, err := parseAsStringToTime(interface{}(asSlice[j]))
				if err != nil {
					return errors.Wrapf(err, "time array prop %q at pos %d", prop.Name, j)
				}

				parsedSlice[j] = parsed
			}
			propMap[prop.Name] = parsedSlice

		}
	}

	return nil
}

func parseAsStringToTime(in interface{}) (time.Time, error) {
	var parsed time.Time
	var err error

	asString, ok := in.(string)
	if !ok {
		return parsed, errors.Errorf("parse as time, expected string got %T", in)
	}

	parsed, err = time.Parse(time.RFC3339, asString)
	if err != nil {
		return parsed, err
	}

	return parsed, nil
}

// return value []error gives the error for the index with the positions
// matching the inputs and nil on positions where the write succeeded
func (i *Index) putObjectBatch(ctx context.Context, objects []*storobj.Object,
	replProps *additional.ReplicationProperties, schemaVersion uint64,
) []error {
	type objsAndPos struct {
		objects []*storobj.Object
		pos     []int
	}
	out := make([]error, len(objects))
	if replProps == nil {
		replProps = defaultConsistency()
	}
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return duplicateErr(fmt.Errorf("wait for schema version %d: %w", schemaVersion, err), len(objects))
		}
	}
	byShard := map[string]objsAndPos{}
	for pos, obj := range objects {
		target, err := i.shardResolver.ResolveShard(ctx, obj)
		if err != nil {
			out[pos] = err
			continue
		}
		group := byShard[target.Shard]
		group.objects = append(group.objects, obj)
		group.pos = append(group.pos, pos)
		byShard[target.Shard] = group
	}

	wg := &sync.WaitGroup{}
	for shardName, group := range byShard {
		shardName := shardName
		group := group
		wg.Add(1)
		f := func() {
			defer wg.Done()

			defer func() {
				err := recover()
				if err != nil {
					for _, pos := range group.pos {
						out[pos] = fmt.Errorf("an unexpected error occurred: %s", err)
					}
					fmt.Fprintf(os.Stderr, "panic: %s\n", err)
					entsentry.Recover(err)
					enterrors.PrintStack(i.logger)
				}
			}()
			// All objects in the same shard group have the same tenant since in multi-tenant
			// systems all objects belonging to a tenant end up in the same shard.
			// For non-multi-tenant collections, Object.Tenant is empty for all objects.
			// Therefore, we can safely use the tenant from any object in the group.
			tenantName := group.objects[0].Object.Tenant
			var errs []error
			if i.shardHasMultipleReplicasWrite(tenantName, shardName) {
				errs = i.replicator.PutObjects(ctx, shardName, group.objects,
					routerTypes.ConsistencyLevel(replProps.ConsistencyLevel), schemaVersion)
			} else {
				err := i.withShardOrRemote(ctx, tenantName, shardName, localShardOperationWrite, schemaVersion,
					func(shard ShardLike) error {
						i.backupLock.RLock(shardName)
						defer i.backupLock.RUnlock(shardName)
						errs = shard.PutObjectBatch(ctx, group.objects)
						return nil
					},
					func() error {
						errs = i.remote.BatchPutObjects(ctx, shardName, group.objects, schemaVersion)
						return nil
					})
				if err != nil {
					errs = duplicateErr(err, len(group.objects))
				}
			}

			for i, err := range errs {
				desiredPos := group.pos[i]
				out[desiredPos] = err
			}
		}
		enterrors.GoWrapper(f, i.logger)
	}

	wg.Wait()

	return out
}

func duplicateErr(in error, count int) []error {
	out := make([]error, count)
	for i := range out {
		out[i] = in
	}

	return out
}

func (i *Index) IncomingBatchPutObjects(ctx context.Context, shardName string,
	objects []*storobj.Object, schemaVersion uint64,
) []error {
	// This is a bit hacky, the problem here is that storobj.Parse() currently
	// misses date fields as it has no way of knowing that a date-formatted
	// string was actually a date type. However, adding this functionality to
	// Parse() would break a lot of code, because it currently
	// schema-independent. To find out if a field is a date or date[], we need to
	// involve the schema, thus why we are doing it here. This was discovered as
	// part of https://github.com/weaviate/weaviate/issues/1775
	for j := range objects {
		if err := i.parseDateFieldsInProps(objects[j].Object.Properties); err != nil {
			return duplicateErr(err, len(objects))
		}
	}

	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	var res []error
	if err := i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		res = shard.PutObjectBatch(ctx, objects)
		return nil
	}); err != nil {
		return duplicateErr(err, len(objects))
	}
	return res
}

// return value []error gives the error for the index with the positions
// matching the inputs and nil on positions where the write succeeded
func (i *Index) AddReferencesBatch(ctx context.Context, refs objects.BatchReferences,
	replProps *additional.ReplicationProperties, schemaVersion uint64,
) []error {
	type refsAndPos struct {
		refs objects.BatchReferences
		pos  []int
	}
	if replProps == nil {
		replProps = defaultConsistency()
	}
	// Stamp once so all replicas write the same LastUpdateTime; otherwise
	// per-replica time.Now() diverges and triggers spurious async-replication
	// repairs. Pre-set values (forwarded batches) are kept.
	nowMs := time.Now().UnixMilli()
	for idx := range refs {
		if refs[idx].UpdateTime == 0 {
			refs[idx].UpdateTime = nowMs
		}
	}
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return duplicateErr(fmt.Errorf("wait for schema version %d: %w", schemaVersion, err), len(refs))
		}
	}
	byShard := map[string]refsAndPos{}
	out := make([]error, len(refs))

	for pos, ref := range refs {
		shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, ref.From.TargetID, ref.Tenant)
		if err != nil {
			out[pos] = err
			continue
		}

		group := byShard[shardName]
		group.refs = append(group.refs, ref)
		group.pos = append(group.pos, pos)
		byShard[shardName] = group
	}

	for shardName, group := range byShard {
		// All references in the same shard group have the same tenant since in multi-tenant
		// systems all objects belonging to a tenant end up in the same shard.
		// For non-multi-tenant collections, ref.Tenant is empty for all references.
		// Therefore, we can safely use the tenant from any reference in the group.
		tenantName := group.refs[0].Tenant
		var errs []error
		if i.shardHasMultipleReplicasWrite(tenantName, shardName) {
			errs = i.replicator.AddReferences(ctx, shardName, group.refs, routerTypes.ConsistencyLevel(replProps.ConsistencyLevel), schemaVersion)
		} else {
			err := i.withShardOrRemote(ctx, tenantName, shardName, localShardOperationWrite, schemaVersion,
				func(shard ShardLike) error {
					i.backupLock.RLock(shardName)
					defer i.backupLock.RUnlock(shardName)
					errs = shard.AddReferencesBatch(ctx, group.refs)
					return nil
				},
				func() error {
					errs = i.remote.BatchAddReferences(ctx, shardName, group.refs, schemaVersion)
					return nil
				})
			if err != nil {
				errs = duplicateErr(err, len(group.refs))
			}
		}

		for i, err := range errs {
			desiredPos := group.pos[i]
			out[desiredPos] = err
		}
	}

	return out
}

func (i *Index) IncomingBatchAddReferences(ctx context.Context, shardName string,
	refs objects.BatchReferences, schemaVersion uint64,
) []error {
	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	var res []error
	if err := i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		res = shard.AddReferencesBatch(ctx, refs)
		return nil
	}); err != nil {
		return duplicateErr(err, len(refs))
	}
	return res
}

func (i *Index) objectByID(ctx context.Context, id strfmt.UUID,
	props search.SelectProperties, addl additional.Properties,
	replProps *additional.ReplicationProperties, tenant string,
) (*storobj.Object, error) {
	shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, id, tenant)
	if err != nil {
		switch {
		case errors.As(err, &objects.ErrMultiTenancy{}):
			return nil, objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
		case errors.As(err, &authzerrors.Forbidden{}):
			return nil, fmt.Errorf("determine shard: %w", err)
		default:
			return nil, objects.NewErrInvalidUserInput("determine shard: %v", err)
		}
	}

	var obj *storobj.Object

	if i.shardHasMultipleReplicasRead(tenant, shardName) {
		if replProps == nil {
			replProps = defaultConsistency()
		}
		if replProps.NodeName != "" {
			obj, err = i.replicator.NodeObject(ctx, replProps.NodeName, shardName, id, props, addl)
		} else {
			obj, err = i.replicator.GetOne(ctx, routerTypes.ConsistencyLevel(replProps.ConsistencyLevel), shardName, id, props, addl)
		}
		return obj, err
	}

	err = i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
		func(shard ShardLike) error {
			var err error
			if obj, err = shard.ObjectByID(ctx, id, props, addl); err != nil {
				return fmt.Errorf("get local object: shard=%s: %w", shardName, err)
			}
			return nil
		},
		func() error {
			var err error
			if obj, err = i.remote.GetObject(ctx, shardName, id, props, addl); err != nil {
				return fmt.Errorf("get remote object: shard=%s: %w", shardName, err)
			}
			return nil
		})
	return obj, err
}

func (i *Index) IncomingGetObject(ctx context.Context, shardName string,
	id strfmt.UUID, props search.SelectProperties,
	additional additional.Properties,
) (*storobj.Object, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, err
	}
	defer release()

	if shard == nil {
		return nil, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, err
	}

	return shard.ObjectByID(ctx, id, props, additional)
}

func (i *Index) IncomingMultiGetObjects(ctx context.Context, shardName string,
	ids []strfmt.UUID,
) ([]*storobj.Object, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, err
	}
	defer release()

	if shard == nil {
		return nil, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, err
	}

	return shard.MultiObjectByID(ctx, wrapIDsInMulti(ids))
}

func (i *Index) multiObjectByID(ctx context.Context,
	query []multi.Identifier, tenant string,
) ([]*storobj.Object, error) {
	type idsAndPos struct {
		ids []multi.Identifier
		pos []int
	}

	byShard := map[string]idsAndPos{}
	for pos, id := range query {
		shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, strfmt.UUID(id.ID), tenant)
		if err != nil {
			switch {
			case errors.As(err, &objects.ErrMultiTenancy{}):
				return nil, objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
			case errors.As(err, &authzerrors.Forbidden{}):
				return nil, fmt.Errorf("determine shard: %w", err)
			default:
				return nil, objects.NewErrInvalidUserInput("determine shard: %v", err)
			}
		}

		group := byShard[shardName]
		group.ids = append(group.ids, id)
		group.pos = append(group.pos, pos)
		byShard[shardName] = group
	}

	out := make([]*storobj.Object, len(query))

	for shardName, group := range byShard {
		var objects []*storobj.Object

		err := i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
			func(shard ShardLike) error {
				var err error
				objects, err = shard.MultiObjectByID(ctx, group.ids)
				return errors.Wrapf(err, "local shard %s", shardId(i.ID(), shardName))
			},
			func() error {
				var err error
				objects, err = i.remote.MultiGetObjects(ctx, shardName, extractIDsFromMulti(group.ids))
				return errors.Wrapf(err, "remote shard %s", shardName)
			})
		if err != nil {
			return nil, err
		}

		for i, obj := range objects {
			desiredPos := group.pos[i]
			out[desiredPos] = obj
		}
	}

	return out, nil
}

func extractIDsFromMulti(in []multi.Identifier) []strfmt.UUID {
	out := make([]strfmt.UUID, len(in))

	for i, id := range in {
		out[i] = strfmt.UUID(id.ID)
	}

	return out
}

func wrapIDsInMulti(in []strfmt.UUID) []multi.Identifier {
	out := make([]multi.Identifier, len(in))

	for i, id := range in {
		out[i] = multi.Identifier{ID: string(id)}
	}

	return out
}

func (i *Index) exists(ctx context.Context, id strfmt.UUID,
	replProps *additional.ReplicationProperties, tenant string,
) (bool, error) {
	shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, id, tenant)
	if err != nil {
		switch {
		case errors.As(err, &objects.ErrMultiTenancy{}):
			return false, objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
		case errors.As(err, &authzerrors.Forbidden{}):
			return false, fmt.Errorf("determine shard: %w", err)
		default:
			return false, objects.NewErrInvalidUserInput("determine shard: %v", err)
		}
	}

	var exists bool
	if i.shardHasMultipleReplicasRead(tenant, shardName) {
		if replProps == nil {
			replProps = defaultConsistency()
		}
		cl := routerTypes.ConsistencyLevel(replProps.ConsistencyLevel)
		return i.replicator.Exists(ctx, cl, shardName, id)
	}

	err = i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
		func(shard ShardLike) error {
			var err error
			if exists, err = shard.Exists(ctx, id); err != nil {
				return fmt.Errorf("exists locally: shard=%q: %w", shardName, err)
			}
			return nil
		},
		func() error {
			var err error
			if exists, err = i.remote.Exists(ctx, shardName, id); err != nil {
				owner, _ := i.getSchema.ShardOwner(i.Config.ClassName.String(), shardName)
				return fmt.Errorf("exists remotely: shard=%q owner=%q: %w", shardName, owner, err)
			}
			return nil
		})

	return exists, err
}

func (i *Index) IncomingExists(ctx context.Context, shardName string,
	id strfmt.UUID,
) (bool, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return false, err
	}
	defer release()

	if shard == nil {
		return false, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return false, err
	}

	return shard.Exists(ctx, id)
}

func (i *Index) objectSearch(ctx context.Context, limit int, filters *filters.LocalFilter,
	keywordRanking *searchparams.KeywordRanking, sort []filters.Sort, cursor *filters.Cursor,
	addlProps additional.Properties, replProps *additional.ReplicationProperties, tenant string, autoCut int,
	properties []string,
) ([]*storobj.Object, []float32, error) {
	cl := i.consistencyLevel(replProps, routerTypes.ConsistencyLevelOne)
	readPlan, err := i.buildReadRoutingPlan(cl, tenant)
	if err != nil {
		return nil, nil, err
	}

	// If the request is a BM25F with no properties selected, use all possible properties
	if keywordRanking != nil && keywordRanking.Type == "bm25" && len(keywordRanking.Properties) == 0 {

		cl := i.getSchema.ReadOnlyClass(i.Config.ClassName.String())
		if cl == nil {
			return nil, nil, fmt.Errorf("class %s not found in schema", i.Config.ClassName)
		}

		propHash := cl.Properties
		// Get keys of hash
		for _, v := range propHash {
			if inverted.PropertyHasSearchableIndex(i.getSchema.ReadOnlyClass(i.Config.ClassName.String()), v.Name) {
				keywordRanking.Properties = append(keywordRanking.Properties, v.Name)
			}
		}

		// WEAVIATE-471 - error if we can't find a property to search
		if len(keywordRanking.Properties) == 0 {
			return nil, []float32{}, errors.New(
				"No properties provided, and no indexed properties found in class")
		}
	}

	outObjects, outScores, err := i.objectSearchByShard(ctx, limit, filters, keywordRanking, sort, cursor, addlProps, tenant, readPlan, properties)
	if err != nil {
		return nil, nil, err
	}

	if len(outObjects) == len(outScores) {
		if keywordRanking != nil && keywordRanking.Type == "bm25" {
			for ii := range outObjects {
				oo := outObjects[ii]

				if oo.AdditionalProperties() == nil {
					oo.Object.Additional = make(map[string]interface{})
				}

				// Additional score is filled in by the top level function

				// Collect all keys starting with "BM25F" and add them to the Additional
				if keywordRanking.AdditionalExplanations {
					explainScore := ""
					for k, v := range oo.Object.Additional {
						if strings.HasPrefix(k, "BM25F") {

							explainScore = fmt.Sprintf("%v, %v:%v", explainScore, k, v)
							delete(oo.Object.Additional, k)
						}
					}
					oo.Object.Additional["explainScore"] = explainScore
				}
			}
		}
	}

	if len(sort) > 0 {
		if len(readPlan.Shards()) > 1 {
			var err error
			outObjects, outScores, err = i.sort(outObjects, outScores, sort, limit)
			if err != nil {
				return nil, nil, errors.Wrap(err, "sort")
			}
		}
	} else if keywordRanking != nil {
		outObjects, outScores = i.sortKeywordRanking(outObjects, outScores)
	} else if len(readPlan.Shards()) > 1 && !addlProps.ReferenceQuery {
		// sort only for multiple shards (already sorted for single)
		// and for not reference nested query (sort is applied for root query)
		outObjects, outScores = i.sortByID(outObjects, outScores)
	}

	if autoCut > 0 {
		cutOff := autocut.Autocut(outScores, autoCut)
		outObjects = outObjects[:cutOff]
		outScores = outScores[:cutOff]
	}

	// if this search was caused by a reference property
	// search, we should not limit the number of results.
	// for example, if the query contains a where filter
	// whose operator is `And`, and one of the operands
	// contains a path to a reference prop, the Search
	// caused by such a ref prop being limited can cause
	// the `And` to return no results where results would
	// be expected. we won't know that unless we search
	// and return all referenced object properties.
	if !addlProps.ReferenceQuery && len(outObjects) > limit {
		if len(outObjects) == len(outScores) {
			outScores = outScores[:limit]
		}
		outObjects = outObjects[:limit]
	}

	if i.anyShardHasMultipleReplicasRead(tenant, readPlan.Shards()) {
		err = i.replicator.CheckConsistency(ctx, cl, outObjects)
		if err != nil {
			i.logger.WithField("action", "object_search").
				Errorf("failed to check consistency of search results: %v", err)
		}
	}

	return outObjects, outScores, nil
}

func (i *Index) objectSearchByShard(ctx context.Context, limit int, filters *filters.LocalFilter,
	keywordRanking *searchparams.KeywordRanking, sort []filters.Sort, cursor *filters.Cursor,
	addlProps additional.Properties, tenant string, readPlan routerTypes.ReadRoutingPlan, properties []string,
) ([]*storobj.Object, []float32, error) {
	resultObjects, resultScores := objectSearchPreallocate(limit, readPlan.Shards())

	eg := enterrors.NewErrorGroupWrapper(i.logger, "filters:", filters)
	// When running in fractional CPU environments, _NUMCPU will be 1
	// Most cloud deployments of Weaviate are in HA clusters with rf=3
	// Therefore, we should set the maximum amount of concurrency to at least 3
	// so that single-tenant rf=3 queries are not serialized. For any higher value of
	// _NUMCPU, e.g. 8, the extra goroutine will not be a significant overhead (16 -> 17)
	eg.SetLimit(_NUMCPU*2 + 1)
	shardResultLock := sync.Mutex{}

	remoteSearch := func(shardName string) error {
		objs, scores, queryProfiles, nodeName, err := i.remote.SearchShard(ctx, shardName, nil, nil, 0, limit, filters, keywordRanking, sort, cursor, nil, addlProps, nil, properties)
		if err != nil {
			return fmt.Errorf(
				"remote shard object search %s: %w", shardName, err)
		}

		if i.shardHasMultipleReplicasRead(tenant, shardName) {
			storobj.AddOwnership(objs, nodeName, shardName)
		}

		shardResultLock.Lock()
		resultObjects = append(resultObjects, objs...)
		resultScores = append(resultScores, scores...)
		shardResultLock.Unlock()

		helpers.AddRemoteQueryProfiles(ctx, queryProfiles)

		return nil
	}
	localSeach := func(shardName string) error {
		// The read lookup initializes the shard after a tenant reactivation; a plain
		// GetShard would not.
		return i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
			func(shard ShardLike) error {
				localCtx := helpers.InitSlowQueryDetails(ctx)
				helpers.AnnotateSlowQueryLog(localCtx, "is_coordinator", true)
				var shardStart time.Time
				if addlProps.QueryProfile {
					shardStart = time.Now()
				}
				objs, scores, err := shard.ObjectSearch(localCtx, limit, filters, keywordRanking, sort, cursor, addlProps, properties)
				if err != nil {
					return fmt.Errorf(
						"local shard object search %s: %w", shard.ID(), err)
				}
				nodeName := i.getSchema.NodeName()
				if addlProps.QueryProfile {
					searchType := "keyword"
					if keywordRanking == nil {
						searchType = "object"
					}
					helpers.AddShardQueryProfile(ctx, shard.ID(), nodeName, searchType, time.Since(shardStart), helpers.ExtractSlowQueryDetails(localCtx))
				}

				if i.shardHasMultipleReplicasRead(tenant, shardName) {
					storobj.AddOwnership(objs, nodeName, shardName)
				}

				shardResultLock.Lock()
				resultObjects = append(resultObjects, objs...)
				resultScores = append(resultScores, scores...)
				shardResultLock.Unlock()

				return nil
			},
			func() error {
				// Hitting the other remote replicas usually resolves any kind of
				// eventual consistency issue just thanks to delaying the search to the
				// other replica. This is not ideal, but it works for now.
				return remoteSearch(shardName)
			})
	}
	err := executor.ExecuteForEachShard(readPlan,
		// Local Shard Search
		func(replica routerTypes.Replica) error {
			shardName := replica.ShardName
			eg.Go(func() error {
				return localSeach(shardName)
			}, shardName)
			return nil
		},
		func(replica routerTypes.Replica) error {
			shardName := replica.ShardName
			eg.Go(func() error {
				return remoteSearch(shardName)
			}, shardName)
			return nil
		},
	)
	if err != nil {
		return nil, nil, fmt.Errorf("error executing search for each shard: %w", err)
	}
	if err := eg.Wait(); err != nil {
		return nil, nil, err
	}

	if len(resultObjects) == len(resultScores) {
		// Force a stable sort order by UUID
		type resultSortable struct {
			object *storobj.Object
			score  float32
		}
		objs := resultObjects
		scores := resultScores
		results := make([]resultSortable, len(objs))
		for i := range objs {
			results[i] = resultSortable{
				object: objs[i],
				score:  scores[i],
			}
		}

		golangSort.Slice(results, func(i, j int) bool {
			if results[i].score == results[j].score {
				return results[i].object.Object.ID < results[j].object.Object.ID
			}

			return results[i].score > results[j].score
		})

		finalObjs := make([]*storobj.Object, len(results))
		finalScores := make([]float32, len(results))
		for i, result := range results {
			finalObjs[i] = result.object
			finalScores[i] = result.score
		}

		return finalObjs, finalScores, nil
	}

	return resultObjects, resultScores, nil
}

func (i *Index) sortByID(objects []*storobj.Object, scores []float32,
) ([]*storobj.Object, []float32) {
	return newIDSorter().sort(objects, scores)
}

func (i *Index) sortKeywordRanking(objects []*storobj.Object,
	scores []float32,
) ([]*storobj.Object, []float32) {
	return newScoresSorter().sort(objects, scores)
}

func (i *Index) sort(objects []*storobj.Object, scores []float32,
	sort []filters.Sort, limit int,
) ([]*storobj.Object, []float32, error) {
	return sorter.NewObjectsSorter(i.getSchema.ReadOnlyClass).
		Sort(objects, scores, limit, sort)
}

func (i *Index) mergeGroups(objects []*storobj.Object, dists []float32,
	groupBy *searchparams.GroupBy, limit, shardCount int,
) ([]*storobj.Object, []float32, error) {
	return newGroupMerger(objects, dists, groupBy).Do()
}

func (i *Index) singleLocalShardObjectVectorSearch(ctx context.Context, searchVectors []models.Vector,
	targetVectors []string, dist float32, limit int, filters *filters.LocalFilter,
	sort []filters.Sort, groupBy *searchparams.GroupBy, additional additional.Properties,
	shard ShardLike, targetCombination *dto.TargetCombination, properties []string,
) ([]*storobj.Object, []float32, error) {
	ctx = helpers.InitSlowQueryDetails(ctx)
	helpers.AnnotateSlowQueryLog(ctx, "is_coordinator", true)
	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, nil, err
	}
	var shardStart time.Time
	if additional.QueryProfile {
		shardStart = time.Now()
	}
	res, resDists, err := shard.ObjectVectorSearch(
		ctx, searchVectors, targetVectors, dist, limit, filters, sort, groupBy, additional, targetCombination, properties)
	if err != nil {
		return nil, nil, errors.Wrapf(err, "shard %s", shard.ID())
	}
	if additional.QueryProfile {
		helpers.AddShardQueryProfile(ctx, shard.ID(), i.getSchema.NodeName(), "vector", time.Since(shardStart), helpers.ExtractSlowQueryDetails(ctx))
	}
	return res, resDists, nil
}

func (i *Index) localShardSearch(ctx context.Context, searchVectors []models.Vector,
	targetVectors []string, dist float32, limit int, localFilters *filters.LocalFilter,
	sort []filters.Sort, groupBy *searchparams.GroupBy, additionalProps additional.Properties,
	targetCombination *dto.TargetCombination, properties []string, tenantName string, shardName string,
) ([]*storobj.Object, []float32, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, nil, err
	}
	defer release()
	if shard == nil {
		return nil, nil, enterrors.NewErrUnprocessable(fmt.Errorf("local %s shard does not exist", shardName))
	}

	localCtx := helpers.InitSlowQueryDetails(ctx)
	helpers.AnnotateSlowQueryLog(localCtx, "is_coordinator", true)
	var shardStart time.Time
	if additionalProps.QueryProfile {
		shardStart = time.Now()
	}
	localShardResult, localShardScores, err := shard.ObjectVectorSearch(
		localCtx, searchVectors, targetVectors, dist, limit, localFilters, sort, groupBy, additionalProps, targetCombination, properties)
	if err != nil {
		return nil, nil, errors.Wrapf(err, "shard %s", shard.ID())
	}
	if additionalProps.QueryProfile {
		helpers.AddShardQueryProfile(ctx, shard.ID(), i.getSchema.NodeName(), "vector", time.Since(shardStart), helpers.ExtractSlowQueryDetails(localCtx))
	}
	// Append result to out
	if i.shardHasMultipleReplicasRead(tenantName, shardName) {
		storobj.AddOwnership(localShardResult, i.getSchema.NodeName(), shardName)
	}
	return localShardResult, localShardScores, nil
}

func (i *Index) remoteShardSearch(ctx context.Context, searchVectors []models.Vector,
	targetVectors []string, distance float32, limit int, localFilters *filters.LocalFilter,
	sort []filters.Sort, groupBy *searchparams.GroupBy, additional additional.Properties,
	targetCombination *dto.TargetCombination, properties []string, tenantName string, shardName string,
) ([]*storobj.Object, []float32, error) {
	var outObjects []*storobj.Object
	var outScores []float32

	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, nil, err
	}
	defer release()

	if i.Config.ForceFullReplicasSearch {
		// Force a search on all the replicas for the shard
		remoteSearchResults, err := i.remote.SearchAllReplicas(ctx,
			i.logger, shardName, searchVectors, targetVectors, distance, limit, localFilters,
			nil, sort, nil, groupBy, additional, i.getSchema.NodeName(), targetCombination, properties)
		// Only return an error if we failed to query remote shards AND we had no local shard to query
		if err != nil && shard == nil {
			return nil, nil, errors.Wrapf(err, "remote shard %s", shardName)
		}
		// Append the result of the search to the outgoing result
		for _, remoteShardResult := range remoteSearchResults {
			if i.shardHasMultipleReplicasRead(tenantName, shardName) {
				storobj.AddOwnership(remoteShardResult.Objects, remoteShardResult.Node, shardName)
			}
			outObjects = append(outObjects, remoteShardResult.Objects...)
			outScores = append(outScores, remoteShardResult.Scores...)
			helpers.AddRemoteQueryProfiles(ctx, remoteShardResult.QueryProfiles)
		}
	} else {
		// Search only what is necessary
		remoteResult, remoteDists, queryProfiles, nodeName, err := i.remote.SearchShard(ctx,
			shardName, searchVectors, targetVectors, distance, limit, localFilters,
			nil, sort, nil, groupBy, additional, targetCombination, properties)
		if err != nil {
			return nil, nil, errors.Wrapf(err, "remote shard %s", shardName)
		}

		if i.shardHasMultipleReplicasRead(tenantName, shardName) {
			storobj.AddOwnership(remoteResult, nodeName, shardName)
		}
		outObjects = remoteResult
		outScores = remoteDists
		helpers.AddRemoteQueryProfiles(ctx, queryProfiles)
	}
	return outObjects, outScores, nil
}

func (i *Index) objectVectorSearch(ctx context.Context, searchVectors []models.Vector,
	targetVectors []string, dist float32, limit int, localFilters *filters.LocalFilter, sort []filters.Sort,
	groupBy *searchparams.GroupBy, additionalProps additional.Properties,
	replProps *additional.ReplicationProperties, tenant string, targetCombination *dto.TargetCombination, properties []string,
) ([]*storobj.Object, []float32, error) {
	cl := i.consistencyLevel(replProps, routerTypes.ConsistencyLevelOne)
	readPlan, err := i.buildReadRoutingPlan(cl, tenant)
	if err != nil {
		return nil, nil, err
	}

	if len(readPlan.Shards()) == 1 && !i.Config.ForceFullReplicasSearch {
		shard, release, err := i.getShardForDirectLocalOperation(ctx, tenant, readPlan.Shards()[0], localShardOperationRead, 0)
		defer release()
		if err != nil {
			return nil, nil, err
		}
		if shard != nil {
			return i.singleLocalShardObjectVectorSearch(ctx, searchVectors, targetVectors, dist, limit, localFilters,
				sort, groupBy, additionalProps, shard, targetCombination, properties)
		}
	}

	// a limit of -1 is used to signal a search by distance. if that is
	// the case we have to adjust how we calculate the output capacity
	var shardCap int
	if limit < 0 {
		shardCap = len(readPlan.Shards()) * hnsw.DefaultSearchByDistInitialLimit
	} else {
		shardCap = len(readPlan.Shards()) * limit
	}

	eg := enterrors.NewErrorGroupWrapper(i.logger, "tenant:", tenant)
	// When running in fractional CPU environments, _NUMCPU will be 1
	// Most cloud deployments of Weaviate are in HA clusters with rf=3
	// Therefore, we should set the maximum amount of concurrency to at least 3
	// so that single-tenant rf=3 queries are not serialized. For any higher value of
	// _NUMCPU, e.g. 8, the extra goroutine will not be a significant overhead (16 -> 17)
	eg.SetLimit(_NUMCPU*2 + 1)
	m := &sync.Mutex{}

	out := make([]*storobj.Object, 0, shardCap)
	dists := make([]float32, 0, shardCap)
	var localSearches atomic.Int64
	var localResponses atomic.Int64
	var remoteSearches atomic.Int64
	var remoteResponses atomic.Int64

	remoteSearch := func(shardName string) error {
		// If we have no local shard or if we force the query to reach all replicas
		remoteShardObject, remoteShardScores, err2 := i.remoteShardSearch(ctx, searchVectors, targetVectors, dist, limit, localFilters, sort, groupBy, additionalProps, targetCombination, properties, tenant, shardName)
		if err2 != nil {
			return fmt.Errorf(
				"remote shard object search %s: %w", shardName, err2)
		}
		m.Lock()
		remoteResponses.Add(1)
		out = append(out, remoteShardObject...)
		dists = append(dists, remoteShardScores...)
		m.Unlock()
		return nil
	}
	localSearch := func(shardName string) error {
		shard, release, err := i.GetShard(ctx, shardName)
		if err != nil {
			return err
		}
		defer release()

		if shard != nil {
			localShardResult, localShardScores, err1 := i.localShardSearch(ctx, searchVectors, targetVectors, dist, limit, localFilters, sort, groupBy, additionalProps, targetCombination, properties, tenant, shardName)
			if err1 != nil {
				return fmt.Errorf(
					"local shard object search %s: %w", shard.ID(), err1)
			}

			m.Lock()
			localResponses.Add(1)
			out = append(out, localShardResult...)
			dists = append(dists, localShardScores...)
			m.Unlock()
		} else {
			return remoteSearch(shardName)
		}

		return nil
	}

	err = executor.ExecuteForEachShard(readPlan,
		// Local Shard Search
		func(replica routerTypes.Replica) error {
			shardName := replica.ShardName
			eg.Go(func() error {
				localSearches.Add(1)
				return localSearch(shardName)
			}, shardName)
			return nil
		},
		func(replica routerTypes.Replica) error {
			shardName := replica.ShardName
			eg.Go(func() error {
				remoteSearches.Add(1)
				return remoteSearch(shardName)
			}, shardName)
			return nil
		},
	)
	if err != nil {
		return nil, nil, fmt.Errorf("error executing search for each shard: %w", err)
	}
	if err := eg.Wait(); err != nil {
		return nil, nil, err
	}

	// If we are force querying all replicas, we need to run deduplication on the result.
	if i.Config.ForceFullReplicasSearch {
		if localSearches.Load() != localResponses.Load() {
			i.logger.Warnf("(in full replica search) local search count does not match local response count: searches=%d responses=%d", localSearches.Load(), localResponses.Load())
		}
		if remoteSearches.Load() != remoteResponses.Load() {
			i.logger.Warnf("(in full replica search) remote search count does not match remote response count: searches=%d responses=%d", remoteSearches.Load(), remoteResponses.Load())
		}
		out, dists, err = searchResultDedup(out, dists)
		if err != nil {
			return nil, nil, fmt.Errorf("could not deduplicate result after full replicas search: %w", err)
		}
	}

	if len(readPlan.Shards()) == 1 {
		return out, dists, nil
	}

	if len(readPlan.Shards()) > 1 && groupBy != nil {
		return i.mergeGroups(out, dists, groupBy, limit, len(readPlan.Shards()))
	}

	if len(readPlan.Shards()) > 1 && len(sort) > 0 {
		return i.sort(out, dists, sort, limit)
	}

	out, dists = newDistancesSorter().sort(out, dists)
	if limit > 0 && len(out) > limit {
		out = out[:limit]
		dists = dists[:limit]
	}

	if i.anyShardHasMultipleReplicasRead(tenant, readPlan.Shards()) {
		err = i.replicator.CheckConsistency(ctx, cl, out)
		if err != nil {
			i.logger.WithField("action", "object_vector_search").
				Errorf("failed to check consistency of search results: %v", err)
		}
	}

	return out, dists, nil
}

// distancerForConfig returns the distancer.Provider matching the given vector
// index configuration. Used by both shard-level and coordinator-level MMR.
func distancerForConfig(cfg schemaConfig.VectorIndexConfig) distancer.Provider {
	if cfg != nil {
		switch cfg.DistanceName() {
		case vectorIndexCommon.DistanceDot:
			return distancer.NewDotProductProvider()
		case vectorIndexCommon.DistanceL2Squared:
			return distancer.NewL2SquaredProvider()
		case vectorIndexCommon.DistanceManhattan:
			return distancer.NewManhattanProvider()
		case vectorIndexCommon.DistanceHamming:
			return distancer.NewHammingProvider()
		}
	}
	return distancer.NewCosineDistanceProvider()
}

func (i *Index) IncomingSearch(ctx context.Context, shardName string,
	searchVectors []models.Vector, targetVectors []string, distance float32, limit int,
	filters *filters.LocalFilter, keywordRanking *searchparams.KeywordRanking,
	sort []filters.Sort, cursor *filters.Cursor, groupBy *searchparams.GroupBy,
	additional additional.Properties, targetCombination *dto.TargetCombination, properties []string,
) ([]*storobj.Object, []float32, []helpers.ShardQueryProfile, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, nil, nil, err
	}
	defer release()

	if shard == nil {
		return nil, nil, nil, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, nil, nil, err
	}

	ctx = helpers.InitSlowQueryDetails(ctx)
	helpers.AnnotateSlowQueryLog(ctx, "is_coordinator", false)

	if additional.QueryProfile {
		ctx = helpers.InitQueryProfileCollector(ctx)
	}

	if len(searchVectors) == 0 {
		var shardStart time.Time
		if additional.QueryProfile {
			shardStart = time.Now()
		}
		res, scores, err := shard.ObjectSearch(ctx, limit, filters, keywordRanking, sort, cursor, additional, properties)
		if err != nil {
			return nil, nil, nil, err
		}
		if additional.QueryProfile {
			searchType := "keyword"
			if keywordRanking == nil {
				searchType = "object"
			}
			helpers.AddShardQueryProfile(ctx, shard.ID(), i.getSchema.NodeName(), searchType, time.Since(shardStart), helpers.ExtractSlowQueryDetails(ctx))
		}

		return res, scores, helpers.ExtractQueryProfiles(ctx), nil
	}

	var shardStart time.Time
	if additional.QueryProfile {
		shardStart = time.Now()
	}
	res, resDists, err := shard.ObjectVectorSearch(
		ctx, searchVectors, targetVectors, distance, limit, filters, sort, groupBy, additional, targetCombination, properties)
	if err != nil {
		return nil, nil, nil, errors.Wrapf(err, "shard %s", shard.ID())
	}
	if additional.QueryProfile {
		helpers.AddShardQueryProfile(ctx, shard.ID(), i.getSchema.NodeName(), "vector", time.Since(shardStart), helpers.ExtractSlowQueryDetails(ctx))
	}

	return res, resDists, helpers.ExtractQueryProfiles(ctx), nil
}

func (i *Index) deleteObject(ctx context.Context, id strfmt.UUID,
	deletionTime time.Time, replProps *additional.ReplicationProperties, tenant string, schemaVersion uint64,
) error {
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return fmt.Errorf("wait for schema version %d: %w", schemaVersion, err)
		}
	}
	shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, id, tenant)
	if err != nil {
		switch {
		case errors.As(err, &objects.ErrMultiTenancy{}):
			return objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
		case errors.As(err, &authzerrors.Forbidden{}):
			return fmt.Errorf("determine shard: %w", err)
		default:
			return objects.NewErrInvalidUserInput("determine shard: %v", err)
		}
	}

	if i.shardHasMultipleReplicasWrite(tenant, shardName) {
		if replProps == nil {
			replProps = defaultConsistency()
		}
		cl := routerTypes.ConsistencyLevel(replProps.ConsistencyLevel)
		if err := i.replicator.DeleteObject(ctx, shardName, id, deletionTime, cl, schemaVersion); err != nil {
			return fmt.Errorf("replicate deletion: shard=%q %w", shardName, err)
		}
		return nil
	}

	return i.withShardOrRemote(ctx, tenant, shardName, localShardOperationWrite, schemaVersion,
		func(shard ShardLike) error {
			i.backupLock.RLock(shardName)
			defer i.backupLock.RUnlock(shardName)
			if err := shard.DeleteObject(ctx, id, deletionTime); err != nil {
				return fmt.Errorf("delete local object: shard=%q: %w", shardName, err)
			}
			return nil
		},
		func() error {
			if err := i.remote.DeleteObject(ctx, shardName, id, deletionTime, schemaVersion); err != nil {
				return fmt.Errorf("delete remote object: shard=%q: %w", shardName, err)
			}
			return nil
		})
}

func (i *Index) IncomingDeleteObject(ctx context.Context, shardName string,
	id strfmt.UUID, deletionTime time.Time, schemaVersion uint64,
) error {
	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	return i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		return shard.DeleteObject(ctx, id, deletionTime)
	})
}

func (i *Index) getClass() *models.Class {
	className := i.Config.ClassName.String()
	return i.getSchema.ReadOnlyClass(className)
}

// Intended to run on "receiver" nodes, where local shard
// is expected to exist and be active
// Method first tries to get shard from Index::shards map,
// or inits shard and adds it to the map if shard was not found
func (i *Index) initLocalShard(ctx context.Context, shardName string) error {
	return i.initLocalShardWithForcedLoading(ctx, i.getClass(), shardName, false, false, callerUserRequest)
}

// LoadLocalShardForMovement loads a shard on behalf of a replica movement.
// Suspending or resuming the namespace mid-movement must not fail that load, so
// it is exempt from the request-path namespace check. The exemption covers this
// node's target shard, not the movement: a movement still reading its source is
// refused at IncomingStartChangeCapture and waits for the namespace, while one
// past that drains its source through getLoadedShard and finishes.
func (i *Index) LoadLocalShardForMovement(ctx context.Context, shardName string) error {
	return i.initLocalShardWithForcedLoading(ctx, i.getClass(), shardName, true, false, callerMovement)
}

// LoadLocalShardForNewReplica loads a shard for the apply that records this node
// as a replica of it, with no replica movement to keep going. Only a namespace
// being deleted skips it, and that skip returns nil: the apply lands once and is
// never re-sent, so erroring reports a failure nothing acts on.
func (i *Index) LoadLocalShardForNewReplica(ctx context.Context, shardName string) error {
	return i.loadLocalShardUnlessNamespaceClosed(ctx, shardName, true, false, callerNewReplica, "replica added")
}

// LoadLocalShardForTenantAdd loads a shard for the apply that records a new HOT
// tenant. Only a namespace being deleted skips it, and that skip returns nil: the
// schema half has already committed, so erroring would fail an apply the schema
// stands behind either way. mustLoad stays false to keep the lazy registration a
// tenant create did before.
func (i *Index) LoadLocalShardForTenantAdd(ctx context.Context, shardName string) error {
	return i.loadLocalShardUnlessNamespaceClosed(ctx, shardName, false, false, callerTenantAdd, "tenant added")
}

// LoadLocalShardForTenantActivation loads a shard for the apply that records a
// tenant turning HOT. It skips and returns nil for the same reason
// [Index.LoadLocalShardForTenantAdd] does.
func (i *Index) LoadLocalShardForTenantActivation(ctx context.Context, shardName string,
	implicitShardLoading bool,
) error {
	return i.loadLocalShardUnlessNamespaceClosed(ctx, shardName, true, implicitShardLoading,
		callerTenantActivation, "tenant activated")
}

// LoadLocalShardForTenantProcess loads a shard for the apply that records a
// finished offload or onload. Only a namespace being deleted skips it, and that
// skip returns nil: the report arrives once and is never re-sent, so erroring
// reports a failure nothing acts on.
func (i *Index) LoadLocalShardForTenantProcess(ctx context.Context, shardName string) error {
	return i.loadLocalShardUnlessNamespaceClosed(ctx, shardName, true, false, callerTenantProcess, "tenant status applied")
}

// loadLocalShardForReload opens a shard for the reload replaying committed
// schema. A namespace that keeps no shards open opens none and returns nil: an
// error here would skip the tenant drops and property adds the same reload
// owes, and nothing re-runs a reload. The skip is silent, like
// initAndStoreShards', since a suspended namespace reaches this once per
// tenant. mustLoad preserves the eager load each call site did before.
func (i *Index) loadLocalShardForReload(ctx context.Context, shardName string, mustLoad bool) error {
	err := i.initLocalShardWithForcedLoading(ctx, i.getClass(), shardName, mustLoad, false, callerReload)
	if stderrors.Is(err, errShardNamespaceClosed) {
		return nil
	}
	return err
}

// loadLocalShardUnlessNamespaceClosed loads a shard for an apply whose schema half
// has already committed. A namespace whose state refuses this caller loads none
// and returns nil rather than erroring. The schema change stands either way, and
// the shard is materialized by whatever next loads it. A state that cannot be read
// still errors.
func (i *Index) loadLocalShardUnlessNamespaceClosed(ctx context.Context, shardName string,
	mustLoad, implicitShardLoading bool, caller shardLoadCaller, change string,
) error {
	err := i.initLocalShardWithForcedLoading(ctx, i.getClass(), shardName, mustLoad, implicitShardLoading, caller)
	if stderrors.Is(err, errShardNamespaceClosed) {
		i.logger.WithFields(logrus.Fields{
			"class": i.Config.ClassName.String(), "namespace": i.namespace, "shard": shardName,
		}).Infof("%s without loading the shard: %v", change, err)
		return nil
	}
	return err
}

// DropLocalShard removes a single local shard and its on-disk files. It is the
// local counterpart to LoadLocalShard. Idempotent: dropping an absent or
// unloaded shard returns nil (dropShards falls back to os.RemoveAll).
func (i *Index) DropLocalShard(name string) error {
	return i.dropShards([]string{name})
}

func (i *Index) initLocalShardWithForcedLoading(ctx context.Context, class *models.Class, shardName string, mustLoad bool, implicitShardLoading bool, caller shardLoadCaller) error {
	if err := i.enterRead(); err != nil {
		return err
	}
	defer i.exitRead()

	// Checked before the already-in-map return below, because with mustLoad that
	// return still loads a lazy shard.
	if err := i.requireNamespaceAllowsShardLoad(caller); err != nil {
		return err
	}

	// make sure same shard is not inited in parallel
	i.shardCreateLocks.Lock(shardName)
	defer i.shardCreateLocks.Unlock(shardName)

	// check if created in the meantime by concurrent call
	if shard := i.shards.Load(shardName); shard != nil {
		// Never trust a map hit on a shard that already COMPLETED a shutdown
		// (e.g. the deferred ref-drain one) — re-initialize fresh instead of
		// leaving the tenant serving errAlreadyShutdown forever. Only
		// CLEANLY-shut entries qualify: an unloaded LazyLoadShard is normal
		// steady state (evicting it would race a concurrent Load() into a
		// duplicate instance over the same directory), and a TORN shard must
		// stay as the last reference to its leaked handles — re-initializing
		// over them would only collide with the bucket registry.
		if terr := shardTeardownError(shard); terr != nil {
			return fmt.Errorf("reactivate shard %q: %w", shardName, terr)
		}
		if shardKnownShut(shard) {
			i.evictShutShard(shardName)
		} else {
			if mustLoad {
				lazyShard, ok := shard.(*LazyLoadShard)
				if ok {
					return lazyShard.Load(ctx)
				}
			}
			return nil
		}
	}

	// NO-HARDLINK-BACKUP: removed in v1.40; bugs here are not fixed.
	if _, protected := i.backupProtectedShards.Load(shardName); protected {
		return fmt.Errorf("shard %q is protected for backup, activation blocked", shardName)
	}

	disableLazyLoad := mustLoad || !i.Config.EnableLazyLoadShards

	shard, err := i.initShard(ctx, shardName, class, i.metrics.baseMetrics, disableLazyLoad, implicitShardLoading)
	if err != nil {
		return err
	}

	i.publishShard(shardName, shard)

	return nil
}

// UnloadLocalShard closes a shard and takes it out of the shard map. A shard
// that is already gone or already shut is success — the caller wanted it not
// loaded, and it is not. Every returned error means the shard is still loaded:
// errAlreadyShutdown once the index is closed, and errIndexShutdown or
// errIndexDropped while its close is only requested.
func (i *Index) UnloadLocalShard(ctx context.Context, shardName string) error {
	if err := i.enterRead(); err != nil {
		return err
	}
	defer i.exitRead()

	i.shardCreateLocks.Lock(shardName)
	defer i.shardCreateLocks.Unlock(shardName)

	shardLike, ok := i.shards.LoadAndDelete(shardName)
	if !ok {
		return nil // shard was not found, nothing to unload
	}

	// The shutdown retries for seconds while enterRead holds the index open. A
	// close request has to end that wait, or the teardown blocks behind it.
	shutdownCtx, done := i.cancelOnCloseRequested(ctx)
	defer done()

	if err := shutdownOrRestoreShard(shutdownCtx, i, shardName, shardLike); err != nil {
		if errors.Is(err, errAlreadyShutdown) {
			// The shard is shut, which is the outcome this call asked for. It
			// is worth a line: reaching it means the shutdown burned its retry
			// backoff holding shardCreateLocks.
			i.logger.WithField("shard", shardName).
				Debugf("shard was already shut or dropped: %v", err)
			return nil
		}
		// backoff reports the aborted wait as a plain cancellation, so only
		// context.Cause names the teardown. The two are joined because a shutdown
		// that failed on its own also cancels, and that is what to act on.
		if shutdownCtx.Err() != nil && ctx.Err() == nil && errors.Is(err, context.Canceled) {
			err = fmt.Errorf("%w: %w", context.Cause(shutdownCtx), err)
		}
		return errors.Wrapf(err, "shutdown shard %q", shardName)
	}

	return nil
}

func (i *Index) GetShard(ctx context.Context, shardName string) (
	shard ShardLike, release func(), err error,
) {
	return i.getOptInitLocalShard(ctx, shardName, false, callerUserRequest)
}

// getOrInitShard initiates the shard locally if it doesn't exist.
//
// NOTE: Don't use this function on read requests. Instead, use GetShard()
// to avoid creating an empty shard. On write requests it makes sense because
// we wait for the latest version from the schema, but on read requests it could
// be affected by eventual consistency.
func (i *Index) getOrInitShard(ctx context.Context, shardName string) (
	shard ShardLike, release func(), err error,
) {
	return i.getOptInitLocalShard(ctx, shardName, true, callerUserRequest)
}

// getOrInitShardForReplication exempts a replica movement's write to its target
// shard from the request-path namespace check, as LoadLocalShardForMovement
// does for the load.
func (i *Index) getOrInitShardForReplication(ctx context.Context, shardName string) (
	shard ShardLike, release func(), err error,
) {
	return i.getOptInitLocalShard(ctx, shardName, true, callerMovement)
}

// getLoadedShard returns the shard only if it is already loaded, never
// materializing one, plus a release that drops the shutdown refcount. A nil
// shard and a nil error mean the shard is not loaded here.
//
// The refcount rather than shardCreateLocks keeps the shard alive, because
// shardCreateLocks is on the shard's own read and write path and callers can
// run long. Same reasoning as backupShardWithHardlinks.
func (i *Index) getLoadedShard(shardName string) (shard ShardLike, release func(), err error) {
	// Every shard teardown holds one of these two: Index.Shutdown takes closeLock
	// for write, the unload paths take shardCreateLocks for write.
	i.closeLock.RLock()
	defer i.closeLock.RUnlock()

	if i.closed {
		return nil, func() {}, fmt.Errorf("local shard %q: %w", shardName, errAlreadyShutdown)
	}

	i.shardCreateLocks.RLock(shardName)
	defer i.shardCreateLocks.RUnlock(shardName)

	shard = i.shards.Loaded(shardName)
	if shard == nil {
		return nil, func() {}, nil
	}
	// Both locks span the map read and the refcount: a lazy shard's
	// preventShutdown loads, so a teardown landing in between would have it
	// rebuild the shard outside i.shards, where nothing can ever shut it down.
	release, err = shard.preventShutdown()
	if err != nil {
		return nil, func() {}, fmt.Errorf("shard %q, no shutdown: %w", shardName, err)
	}
	return shard, release, nil
}

// withShardForWrite runs f against the named local shard's write surface. It
// owns the pin lifetime, so a caller cannot leak one and leave inUseCounter
// non-zero, blocking the shard from unloading.
func (i *Index) withShardForWrite(ctx context.Context, shardName string, f func(shard shardWriter) error) error {
	shard, release, err := i.getOrInitShard(ctx, shardName)
	defer release()
	if err != nil {
		return fmt.Errorf("get shard %q: %w", shardName, err)
	}
	return f(shard)
}

// getOptInitLocalShard returns the local shard with the given name.
// It is ensured that the returned instance is a fully loaded shard if ensureInit is set to true.
// The returned shard may be a lazy shard instance or nil if the shard hasn't yet been initialized.
// The returned shard cannot be closed until release is called.
// release is never nil, including on error, so defer it immediately after the call.
func (i *Index) getOptInitLocalShard(ctx context.Context, shardName string, ensureInit bool, caller shardLoadCaller) (
	shard ShardLike, release func(), err error,
) {
	if err := i.enterRead(); err != nil {
		return nil, func() {}, fmt.Errorf("local shard %q: %w", shardName, err)
	}
	defer i.exitRead()

	// Above the shard-map read, not merely above the load points. preventShutdown
	// below loads a resident lazy shard even with ensureInit false, so a check
	// further down would miss those reads — and sitting above the lookup also
	// refuses a shard that is already resident and loaded, which is what makes a
	// suspend cut reads and writes rather than only materialization. Moving it
	// below the map read, or gating it on a shard being lazy, quietly restores
	// both.
	if err := i.requireNamespaceAllowsShardLoad(caller); err != nil {
		return nil, func() {}, err
	}

	// make sure same shard is not inited in parallel. In case it is not loaded yet, switch to a RW lock and initialize
	// the shard
	func() {
		i.shardCreateLocks.RLock(shardName)
		defer i.shardCreateLocks.RUnlock(shardName)
		shard = i.shards.Load(shardName)
	}()

	// A torn shard (deep teardown failure) is held in the map as the last
	// reference to its leaked handles; surface the cause instead of a bare
	// errAlreadyShutdown. Unavailable until restart.
	if shard != nil && ensureInit {
		if terr := shardTeardownError(shard); terr != nil {
			return nil, func() {}, fmt.Errorf("shard %q: %w", shardName, terr)
		}
	}

	// A map hit on a shard that CLEANLY completed a shutdown (the deferred
	// ref-drain one after a failed-but-restored close) must not pin the tenant
	// on errAlreadyShutdown forever: the init path below re-creates it, same
	// as the reactivation belt in initLocalShardWithForcedLoading. Read-only
	// callers (ensureInit=false) keep surfacing the terminal error — the
	// eventual-shutdown contract pins GetShard to errAlreadyShutdown.
	if shard == nil || (ensureInit && shardKnownShut(shard)) {
		if !ensureInit {
			return nil, func() {}, nil
		}

		className := i.Config.ClassName.String()
		class := i.getSchema.ReadOnlyClass(className)
		if class == nil {
			return nil, func() {}, fmt.Errorf("init local shard %q: class %s not found in schema", shardName, className)
		}

		i.shardCreateLocks.Lock(shardName)
		defer i.shardCreateLocks.Unlock(shardName)

		// double check if loaded in the meantime by concurrent call, if not load it
		shard = i.shards.Load(shardName)
		if shard != nil && shardKnownShut(shard) {
			i.evictShutShard(shardName)
			shard = nil
		}
		if shard == nil {
			// NO-HARDLINK-BACKUP: removed in v1.40; bugs here are not fixed.
			if _, protected := i.backupProtectedShards.Load(shardName); protected {
				return nil, func() {}, fmt.Errorf("shard %q is protected for backup, activation blocked", shardName)
			}
			shard, err = i.initShard(ctx, shardName, class, i.metrics.baseMetrics, true, false)
			if err != nil {
				return nil, func() {}, fmt.Errorf("init local shard %q of index %s: %w", shardName, i.ID(), err)
			}
			i.publishShard(shardName, shard)
		}
	}

	// If ensureInit is true, ensure the shard is loaded. For lazy shards, preventShutdown()
	// will call Load() internally
	release, err = shard.preventShutdown()
	if err != nil {
		return nil, func() {}, fmt.Errorf("get/init local shard %q, no shutdown: %w", shardName, err)
	}

	return shard, release, nil
}

func (i *Index) mergeObject(ctx context.Context, merge objects.MergeDocument,
	replProps *additional.ReplicationProperties, tenant string, schemaVersion uint64,
) error {
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return fmt.Errorf("wait for schema version %d: %w", schemaVersion, err)
		}
	}
	shardName, err := i.shardResolver.ResolveShardByObjectID(ctx, merge.ID, tenant)
	if err != nil {
		switch {
		case errors.As(err, &objects.ErrMultiTenancy{}):
			return objects.NewErrMultiTenancy(fmt.Errorf("determine shard: %w", err))
		case errors.As(err, &authzerrors.Forbidden{}):
			return fmt.Errorf("determine shard: %w", err)
		default:
			return objects.NewErrInvalidUserInput("determine shard: %v", err)
		}
	}

	if i.shardHasMultipleReplicasWrite(tenant, shardName) {
		if replProps == nil {
			replProps = defaultConsistency()
		}
		cl := routerTypes.ConsistencyLevel(replProps.ConsistencyLevel)
		if err := i.replicator.MergeObject(ctx, shardName, &merge, cl, schemaVersion); err != nil {
			return fmt.Errorf("replicate single update: %w", err)
		}
		return nil
	}

	return i.withShardOrRemote(ctx, tenant, shardName, localShardOperationWrite, schemaVersion,
		func(shard ShardLike) error {
			i.backupLock.RLock(shardName)
			defer i.backupLock.RUnlock(shardName)
			if err := shard.MergeObject(ctx, merge); err != nil {
				return fmt.Errorf("update local object: shard=%q: %w", shardName, err)
			}

			return nil
		},
		func() error {
			if err := i.remote.MergeObject(ctx, shardName, merge, schemaVersion); err != nil {
				return fmt.Errorf("update remote object: shard=%q: %w", shardName, err)
			}
			return nil
		})
}

func (i *Index) IncomingMergeObject(ctx context.Context, shardName string,
	mergeDoc objects.MergeDocument, schemaVersion uint64,
) error {
	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	return i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		return shard.MergeObject(ctx, mergeDoc)
	})
}

func (i *Index) aggregate(ctx context.Context, replProps *additional.ReplicationProperties,
	params aggregation.Params, modules *modules.Provider,
) (*aggregation.Result, error) {
	// ValidateConsistencyLevel requires every shard to resolve to the same number,
	// and ONE is the only level that does so whatever the shards' replica counts.
	readPlan, err := i.buildReadRoutingPlan(routerTypes.ConsistencyLevelOne, params.Tenant)
	if err != nil {
		return nil, err
	}

	if aggregation.IsCountStar(&params) {
		return i.aggregateCount(ctx, readPlan)
	}

	shards := readPlan.Shards()
	results := make([]*aggregation.Result, len(shards))
	for j, shardName := range shards {
		var res *aggregation.Result

		err := i.withShardOrRemote(ctx, params.Tenant, shardName, localShardOperationRead, 0,
			func(shard ShardLike) error {
				var err error
				res, err = shard.Aggregate(ctx, params, modules)
				return err
			},
			func() error {
				var err error
				res, err = i.remote.Aggregate(ctx, shardName, params)
				if err != nil || res == nil {
					return err
				}
				// restore wire state here so a malformed payload error still names the shard
				return aggregator.NewShardCombiner().RestoreSerializedAggregators(res)
			})
		if err != nil {
			return nil, errors.Wrapf(err, "shard %s", shardName)
		}

		results[j] = res
	}

	return aggregator.NewShardCombiner().Do(results)
}

// aggregateCount counts every shard in readPlan against that plan's replicas,
// resolved once for the whole aggregation rather than per shard. It counts at
// ALL, so a shard's count is reconciled over every replica that answers.
func (i *Index) aggregateCount(ctx context.Context, readPlan routerTypes.ReadRoutingPlan) (*aggregation.Result, error) {
	var total atomic.Int64

	shardPlans := readPlan.ShardPlans(routerTypes.ConsistencyLevelAll)

	eg, ctx := enterrors.NewErrorGroupWithContextWrapper(i.logger, ctx)
	eg.SetLimit(min(len(shardPlans), runtime.GOMAXPROCS(0)*4))

	for _, shardPlan := range shardPlans {
		eg.Go(func() error {
			count, err := i.replicator.CountObjects(ctx, shardPlan)
			if err != nil {
				return err
			}
			total.Add(int64(count))
			return nil
		})
	}

	if err := eg.Wait(); err != nil {
		return nil, err
	}

	return &aggregation.Result{Groups: []aggregation.Group{{Count: int(total.Load())}}}, nil
}

func (i *Index) IncomingAggregate(ctx context.Context, shardName string,
	params aggregation.Params, mods interface{},
) (*aggregation.Result, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, err
	}
	defer release()

	if shard == nil {
		return nil, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, err
	}

	return shard.Aggregate(ctx, params, mods.(*modules.Provider))
}

func (i *Index) drop() error {
	if err := i.beginClose(); err != nil {
		return err
	}

	// Check if a backup is in progress. Dont delete files in this case so the backup process can complete successfully
	// The files will be deleted after the backup is completed and in case of a crash on next startup.
	lastBackup := i.lastBackup.Load()
	keepFiles := lastBackup != nil

	ec := errorcompounder.NewSafe()
	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU * 2)
	dropShard := func(shardName string, _ ShardLike) error {
		eg.Go(func() error {
			i.backupLock.RLock(shardName)
			defer i.backupLock.RUnlock(shardName)

			i.shardCreateLocks.Lock(shardName)
			defer i.shardCreateLocks.Unlock(shardName)

			shard, ok := i.shards.LoadAndDelete(shardName)
			if !ok {
				return nil // shard already does not exist
			}
			if err := shard.drop(keepFiles); err != nil {
				ec.Add(err)
				i.logger.WithField("action", "drop_shard").
					WithField("shard", shard.ID()).Error(err)
			}

			return nil
		})
		return nil
	}

	i.shards.Range(dropShard)

	// the error group only carries a recovered worker panic, which would
	// otherwise leave the shard un-dropped without failing the call
	ec.Add(eg.Wait())

	// 1s target contract per weaviate/0-weaviate-issues#250; ctx errors
	// are best-effort (flush doesn't honor ctx yet — separable follow-up).
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	// the index is torn down regardless, so the cycles must stop and the
	// directory must be renamed even when a shard or a cycle failed; a cycle that
	// ran out of time must not hide one that failed for another reason
	for _, cause := range causesOf(i.stopCycleManagers(ctx, "drop")) {
		if !stderrors.Is(cause, context.Canceled) && !stderrors.Is(cause, context.DeadlineExceeded) {
			ec.Add(cause)
		}
	}

	if keepFiles {
		// backup framework expects the DeleteMarkerAdd-prefixed rename
		marker := filepath.Join(i.Config.RootPath, backup.DeleteMarkerAdd(i.ID()))
		if err := os.Rename(i.path(), marker); err != nil {
			ec.Add(fmt.Errorf("rename index for delete marker: %w", err))
		} else if i.lastBackup.Load() == nil {
			// drop blocks on backupLock until ReleaseBackup runs, so if that already
			// finished it looked for the marker before this rename created it.
			ec.Add(os.RemoveAll(marker))
		}
	} else {
		// rename sync (must complete even if ctx is expired); RemoveAll async
		deleted, err := renameForAsyncDelete(i.path(), i.logger)
		if err != nil {
			ec.Add(fmt.Errorf("rename index for async delete: %w", err))
		} else if deleted != "" {
			spawnAsyncDelete(deleted, i.logger)
		}
	}
	return ec.ToErrorLimited(maxReportedErrors)
}

// causesOf splits a joined error into the errors it was built from, so a caller
// can judge each one on its own. A nil error has no causes.
func causesOf(err error) []error {
	if err == nil {
		return nil
	}
	if joined, ok := err.(interface{ Unwrap() []error }); ok {
		return joined.Unwrap()
	}
	return []error{err}
}

// withCloseRLockGuard runs fn only if the index is not closing/closed,
// returning context.Canceled without running it otherwise. fn must not acquire
// i.closeLock for writing or any lock drop() holds in an inverting order.
//
// Covers whole-index drops only: dropShards never sets i.closed, so tenant
// deletes are invisible to the guard. Tracked in
// https://github.com/weaviate/0-weaviate-issues/issues/288.
func (i *Index) withCloseRLockGuard(fn func() error) error {
	if err := i.enterRead(); err != nil {
		return context.Canceled
	}
	defer i.exitRead()

	return fn()
}

func (i *Index) dropShards(names []string) error {
	if err := i.enterRead(); err != nil {
		return err
	}
	defer i.exitRead()

	ec := errorcompounder.NewSafe()
	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU * 2)

	var (
		unloadedMu    sync.Mutex
		unloadedNames []string
	)

	for _, name := range names {
		name := name
		eg.Go(func() error {
			i.backupLock.RLock(name)
			defer i.backupLock.RUnlock(name)
			i.shardCreateLocks.Lock(name)
			defer i.shardCreateLocks.Unlock(name)

			shard, ok := i.shards.LoadAndDelete(name)
			if !ok {
				// Ensure that if the shard is not loaded we delete any reference on disk for any data.
				// This ensures that we also delete inactive shards/tenants
				if err := os.RemoveAll(shardPath(i.path(), name)); err != nil {
					ec.Add(err)
					i.logger.WithField("action", "drop_shard").WithField("shard", name).Error(err)
				}
				unloadedMu.Lock()
				unloadedNames = append(unloadedNames, name)
				unloadedMu.Unlock()
			} else {
				// If shard is loaded use the native primitive to drop it
				if err := shard.drop(false); err != nil {
					ec.Add(err)
					i.logger.WithField("action", "drop_shard").WithField("shard", shard.ID()).Error(err)
				}
			}

			return nil
		})
	}

	// the error group only carries a recovered worker panic, which would
	// otherwise leave the shard un-dropped without failing the call
	ec.Add(eg.Wait())

	i.purgeUnloadedShardRegistry(unloadedNames)

	return ec.ToErrorLimited(maxReportedErrors)
}

// purgeUnloadedShardRegistry removes, in a single locked registry scan, the
// GlobalBucketRegistry entries under the lsm subtree of each unloaded shard that
// dropShards deleted from disk.
//
// Correctness rests on holding each name's shardCreateLocks write lock across
// BOTH the gate (i.shards.Load(name)==nil) AND the RemoveByPrefixes scan.
func (i *Index) purgeUnloadedShardRegistry(names []string) {
	if len(names) == 0 {
		return
	}

	names = slices.Clone(names)
	slices.Sort(names)
	names = slices.Compact(names)

	for _, name := range names {
		i.shardCreateLocks.Lock(name)
	}
	defer func() {
		for _, name := range names {
			i.shardCreateLocks.Unlock(name)
		}
	}()

	dirs := make([]string, 0, len(names))
	for _, name := range names {
		if i.shards.Load(name) == nil {
			dirs = append(dirs, shardPathLSM(i.path(), name))
		}
	}
	lsmkv.GlobalBucketRegistry.RemoveByPrefixes(dirs...)
}

func (i *Index) dropCloudShards(ctx context.Context, cloud modulecapabilities.OffloadCloud, names []string, nodeId string) error {
	if err := i.enterRead(); err != nil {
		return err
	}
	defer i.exitRead()

	ec := errorcompounder.NewSafe()
	eg := enterrors.NewErrorGroupWrapper(i.logger)
	eg.SetLimit(_NUMCPU * 2)

	for _, name := range names {
		eg.Go(func() error {
			i.backupLock.RLock(name)
			defer i.backupLock.RUnlock(name)
			i.shardCreateLocks.Lock(name)
			defer i.shardCreateLocks.Unlock(name)

			if err := cloud.Delete(ctx, i.ID(), name, nodeId); err != nil {
				ec.Add(err)
				i.logger.WithField("action", "cloud_drop_shard").
					WithField("shard", name).Error(err)
			}
			return nil
		})
	}

	// the error group only carries a recovered worker panic, which would
	// otherwise leave the shard un-dropped without failing the call
	ec.Add(eg.Wait())
	return ec.ToErrorLimited(maxReportedErrors)
}

func (i *Index) Shutdown(ctx context.Context) error {
	// a reader holding closeLock would hold up the whole DB shutdown
	i.signalCloseRequested(errIndexShutdown)
	if err := i.beginClose(); err != nil {
		return err
	}

	ec := errorcompounder.NewSafe()

	ec.Add(i.shards.RangeConcurrently(i.logger, func(name string, shard ShardLike) error {
		i.backupLock.RLock(name)
		defer i.backupLock.RUnlock(name)

		if err := shard.Shutdown(ctx); err != nil {
			if !errors.Is(err, errAlreadyShutdown) {
				ec.AddWrapf(err, "shutdown shard %q", name)
				return nil
			}
			i.logger.WithField("shard", shard.Name()).Debug("was already shut or dropped")
		}
		return nil
	}))

	// the cycle managers must stop even when a shard failed to shut down
	ec.Add(i.stopCycleManagers(ctx, "shutdown"))

	return ec.ToErrorLimited(maxReportedErrors)
}

// stopCycleManagers asks every cycle to stop before waiting for any of them, so
// one slow cycle cannot use up ctx before the others were asked. The index is
// being closed or deleted, so the cycles are stopped even when ctx already
// expired; ctx only bounds how long we wait. Joining keeps each failure matchable.
func (i *Index) stopCycleManagers(ctx context.Context, usecase string) error {
	// which data each compaction cycle covers depends on SeparateObjectsCompactions
	compaction, compactionAux := "compaction", "auxiliary compaction"
	if i.Config.SeparateObjectsCompactions {
		compaction, compactionAux = "non objects compaction", "objects compaction"
	}

	cycles := []struct {
		name  string
		cycle cyclemanager.CycleManager
	}{
		{compaction, i.cycleCallbacks.compactionCycle},
		{compactionAux, i.cycleCallbacks.compactionAuxCycle},
		{"flush", i.cycleCallbacks.flushCycle},
		{"vector commit logger", i.cycleCallbacks.vectorCommitLoggerCycle},
		{"vector tombstone cleanup", i.cycleCallbacks.vectorTombstoneCleanupCycle},
		{"geo props commit logger", i.cycleCallbacks.geoPropsCommitLoggerCycle},
		{"geo props tombstone cleanup", i.cycleCallbacks.geoPropsTombstoneCleanupCycle},
	}

	stopResults := make([]chan bool, len(cycles))
	for j, c := range cycles {
		stopResults[j] = c.cycle.Stop(context.Background())
	}

	var errs []error
	for j, c := range cycles {
		if err := waitForCycleStop(ctx, stopResults[j]); err != nil {
			errs = append(errs, fmt.Errorf("%s: stop %s cycle: %w", usecase, c.name, err))
		}
	}
	return stderrors.Join(errs...)
}

// waitForCycleStop waits for a stop result, preferring it over an expired ctx when
// both are ready, so a cycle that did stop is not reported as a failure.
func waitForCycleStop(ctx context.Context, stopResult chan bool) error {
	var stopped bool
	select {
	case stopped = <-stopResult:
	case <-ctx.Done():
		// select picks randomly when both are ready, so the result is checked again
		select {
		case stopped = <-stopResult:
		default:
			return ctx.Err()
		}
	}
	if !stopped {
		return stderrors.New("cycle kept running")
	}
	return nil
}

func (i *Index) getShardsQueueSize(ctx context.Context, tenant string) (map[string]int64, error) {
	className := i.Config.ClassName.String()
	shardNames, err := i.schemaReader.Shards(className)
	if err != nil {
		return nil, err
	}

	shardsQueueSize := make(map[string]int64)
	for _, shardName := range shardNames {
		if tenant != "" && shardName != tenant {
			continue
		}
		var size int64
		err := i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
			func(shard ShardLike) error {
				return shard.ForEachVectorQueue(func(_ string, queue *VectorIndexQueue) error {
					size += queue.Size()
					return nil
				})
			},
			func() error {
				var err error
				size, err = i.remote.GetShardQueueSize(ctx, shardName)
				return err
			})
		if err != nil {
			return nil, errors.Wrapf(err, "shard %s", shardName)
		}

		shardsQueueSize[shardName] = size
	}

	return shardsQueueSize, nil
}

func (i *Index) IncomingGetShardQueueSize(ctx context.Context, shardName string) (int64, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return 0, err
	}
	defer release()

	if shard == nil {
		return 0, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return 0, err
	}
	var size int64
	_ = shard.ForEachVectorQueue(func(_ string, queue *VectorIndexQueue) error {
		size += queue.Size()
		return nil
	})
	return size, nil
}

// getShardsStatus returns the status of the collection's shards on each of its
// replica nodes. Example:
//
//	map[string]map[string]string{
//		"shard-0": { "node-0": "READY", "node-1": "READONLY" },
//		"shard-1": { "node-1": "READY", "node-1": "READONLY" },
//	}
//
// The second return value are shard statuses mirroring the legacy implementation,
// where the status is returned based on the first replica to contain the shard,
// preferably local.
func (i *Index) getShardsStatus(ctx context.Context, tenant string) (map[string]map[string]string, map[string]string, error) {
	thisNode := i.getSchema.NodeName()
	className := i.Config.ClassName.String()
	shardNames, err := i.schemaReader.Shards(className)
	if err != nil {
		return nil, nil, err
	}

	var mu sync.Mutex // guards shardsStatus and legacyStatus
	shardsStatus := make(map[string]map[string]string, len(shardNames))
	legacyStatus := make(map[string]string, len(shardNames))

	eg, ctx := enterrors.NewErrorGroupWithContextWrapper(i.logger, ctx)
	eg.SetLimit(min(len(shardNames), runtime.GOMAXPROCS(0)*4))

	for _, shardName := range shardNames {
		if tenant != "" && shardName != tenant {
			continue
		}

		eg.Go(func() error {
			replicas, err := i.schemaReader.ShardReplicas(className, shardName)
			if err != nil {
				return err
			}

			var (
				oneNodeStatus atomic.Value
				perNodeStatus = make(map[string]string, len(replicas))
			)
			for _, nodeName := range replicas {
				var err error
				if nodeName == thisNode {
					var (
						shard   ShardLike
						release func()
					)
					shard, release, err = i.getShardForDirectLocalOperation(
						ctx,
						shardName,
						shardName,
						localShardOperationRead,
						0,
					)
					if err == nil && shard != nil {
						status := shard.GetStatus().String()
						oneNodeStatus.Store(status)
						perNodeStatus[nodeName] = status
					}
					release()
				} else {
					var status string
					if status, err = i.remote.GetShardStatus(ctx, shardName, nodeName); err == nil {
						oneNodeStatus.CompareAndSwap(nil, status)
						perNodeStatus[nodeName] = status
					}
				}

				if errors.Is(err, errAlreadyShutdown) {
					return err
				}
			}

			mu.Lock()
			shardsStatus[shardName] = perNodeStatus
			if s, ok := oneNodeStatus.Load().(string); ok {
				legacyStatus[shardName] = s
			}
			mu.Unlock()
			return nil
		}, shardName)
	}

	if err := eg.Wait(); err != nil {
		return nil, nil, err
	}
	return shardsStatus, legacyStatus, nil
}

func (i *Index) IncomingGetShardStatus(ctx context.Context, shardName string) (string, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return "", err
	}
	defer release()

	if shard == nil {
		return "", fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return "", err
	}
	return shard.GetStatus().String(), nil
}

func (i *Index) updateShardStatus(ctx context.Context, shardName, targetStatus string) error {
	isOwner := false
	if err := i.schemaReader.Read(i.Config.ClassName.String(), true, func(_ *models.Class, state *sharding.State) error {
		if state != nil {
			isOwner = state.IsLocalShard(shardName)
		}
		return nil
	}); err != nil {
		return err
	}
	if !isOwner {
		return nil
	}

	return i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		return shard.UpdateStatus(targetStatus, statusReasonManualUpdate)
	})
}

func (i *Index) IncomingUpdateShardStatus(ctx context.Context, shardName, targetStatus string, schemaVersion uint64) error {
	return i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		return shard.UpdateStatus(targetStatus, statusReasonManualUpdate)
	})
}

func (i *Index) findUUIDs(ctx context.Context,
	filters *filters.LocalFilter, tenant string, repl *additional.ReplicationProperties,
	perShardLimit int,
) (map[string][]strfmt.UUID, error) {
	before := time.Now()
	defer i.metrics.BatchDelete(before, "filter_total")
	cl := i.consistencyLevel(repl)
	readPlan, err := i.buildReadRoutingPlan(cl, tenant)
	if err != nil {
		return nil, err
	}
	className := i.Config.ClassName.String()

	results := make(map[string][]strfmt.UUID)
	for _, shardName := range readPlan.Shards() {
		var err error

		if i.shardHasMultipleReplicasRead(tenant, shardName) {
			results[shardName], err = i.replicator.FindUUIDs(ctx, className, shardName, filters, cl, perShardLimit)
		} else {
			err = i.withShardOrRemote(ctx, tenant, shardName, localShardOperationRead, 0,
				func(shard ShardLike) error {
					var err error
					results[shardName], err = shard.FindUUIDs(ctx, filters, perShardLimit)
					return err
				},
				func() error {
					var err error
					results[shardName], err = i.remote.FindUUIDs(ctx, shardName, filters, perShardLimit)
					return err
				})
		}

		if err != nil {
			return nil, fmt.Errorf("find matching doc ids in shard %q: %w", shardName, err)
		}
	}

	return results, nil
}

// consistencyLevel returns the consistency level for the given replication properties.
// If repl is not nil, the consistency level is returned from repl.
// If repl is nil and a default override is provided, the default override is returned.
// If repl is nil and no default override is provided, the default consistency level
// is returned (QUORUM).
func (i *Index) consistencyLevel(
	repl *additional.ReplicationProperties,
	defaultOverride ...routerTypes.ConsistencyLevel,
) routerTypes.ConsistencyLevel {
	if repl == nil {
		repl = defaultConsistency(defaultOverride...)
	}
	return routerTypes.ConsistencyLevel(repl.ConsistencyLevel)
}

func (i *Index) IncomingFindUUIDs(ctx context.Context, shardName string,
	filters *filters.LocalFilter, limit int,
) ([]strfmt.UUID, error) {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return nil, err
	}
	defer release()

	if shard == nil {
		return nil, fmt.Errorf("local %s shard not found", shardName)
	}

	if err := i.ensureShardLocallyReady(shard); err != nil {
		return nil, err
	}

	return shard.FindUUIDs(ctx, filters, limit)
}

func (i *Index) batchDeleteObjects(ctx context.Context, shardUUIDs map[string][]strfmt.UUID,
	deletionTime time.Time, dryRun bool, replProps *additional.ReplicationProperties, schemaVersion uint64,
	tenant string,
) (objects.BatchSimpleObjects, error) {
	before := time.Now()
	defer i.metrics.BatchDelete(before, "delete_from_shards_total")
	if schemaVersion > 0 {
		if err := i.schemaReader.WaitForUpdate(ctx, schemaVersion); err != nil {
			return nil, fmt.Errorf("wait for schema version %d: %w", schemaVersion, err)
		}
	}
	type result struct {
		objs objects.BatchSimpleObjects
	}

	if replProps == nil {
		replProps = defaultConsistency()
	}

	wg := &sync.WaitGroup{}
	ch := make(chan result, len(shardUUIDs))
	for shardName, uuids := range shardUUIDs {
		uuids := uuids
		shardName := shardName
		wg.Add(1)
		f := func() {
			defer wg.Done()

			var objs objects.BatchSimpleObjects
			if i.shardHasMultipleReplicasWrite(tenant, shardName) {
				objs = i.replicator.DeleteObjects(ctx, shardName, uuids, deletionTime,
					dryRun, routerTypes.ConsistencyLevel(replProps.ConsistencyLevel), schemaVersion)
			} else {
				err := i.withShardOrRemote(ctx, tenant, shardName, localShardOperationWrite, schemaVersion,
					func(shard ShardLike) error {
						i.backupLock.RLock(shardName)
						defer i.backupLock.RUnlock(shardName)
						objs = shard.DeleteObjectBatch(ctx, uuids, deletionTime, dryRun)
						return nil
					},
					func() error {
						objs = i.remote.DeleteObjectBatch(ctx, shardName, uuids, deletionTime, dryRun, schemaVersion)
						return nil
					})
				if err != nil {
					objs = objects.BatchSimpleObjects{
						objects.BatchSimpleObject{Err: err},
					}
				}
			}

			ch <- result{objs}
		}
		enterrors.GoWrapper(f, i.logger)
	}

	wg.Wait()
	close(ch)

	var out objects.BatchSimpleObjects
	for res := range ch {
		out = append(out, res.objs...)
	}

	return out, nil
}

func (i *Index) IncomingDeleteObjectBatch(ctx context.Context, shardName string,
	uuids []strfmt.UUID, deletionTime time.Time, dryRun bool, schemaVersion uint64,
) objects.BatchSimpleObjects {
	i.backupLock.RLock(shardName)
	defer i.backupLock.RUnlock(shardName)

	var res objects.BatchSimpleObjects
	if err := i.withShardForWrite(ctx, shardName, func(shard shardWriter) error {
		res = shard.DeleteObjectBatch(ctx, uuids, deletionTime, dryRun)
		return nil
	}); err != nil {
		return objects.BatchSimpleObjects{
			objects.BatchSimpleObject{Err: err},
		}
	}
	return res
}

func defaultConsistency(defaultOverride ...routerTypes.ConsistencyLevel) *additional.ReplicationProperties {
	rp := &additional.ReplicationProperties{}
	if len(defaultOverride) != 0 {
		rp.ConsistencyLevel = string(defaultOverride[0])
	} else {
		rp.ConsistencyLevel = string(routerTypes.ConsistencyLevelQuorum)
	}
	return rp
}

func objectSearchPreallocate(limit int, shards []string) ([]*storobj.Object, []float32) {
	perShardLimit := config.DefaultQueryMaximumResults
	if perShardLimit > int64(limit) {
		perShardLimit = int64(limit)
	}
	capacity := perShardLimit * int64(len(shards))
	objects := make([]*storobj.Object, 0, capacity)
	scores := make([]float32, 0, capacity)

	return objects, scores
}

// GetVectorIndexConfig returns a vector index configuration associated with targetVector.
// In case targetVector is empty string, legacy vector configuration is returned.
// Method expects that configuration associated with targetVector is present.
func (i *Index) GetVectorIndexConfig(targetVector string) schemaConfig.VectorIndexConfig {
	i.vectorIndexUserConfigLock.Lock()
	defer i.vectorIndexUserConfigLock.Unlock()

	if targetVector == "" {
		return i.vectorIndexUserConfig
	}

	return i.vectorIndexUserConfigs[targetVector]
}

// GetVectorIndexConfigs returns a map of vector index configurations.
// If present, legacy vector is return under the key of empty string.
func (i *Index) GetVectorIndexConfigs() map[string]schemaConfig.VectorIndexConfig {
	i.vectorIndexUserConfigLock.Lock()
	defer i.vectorIndexUserConfigLock.Unlock()

	configs := make(map[string]schemaConfig.VectorIndexConfig, len(i.vectorIndexUserConfigs)+1)
	for k, v := range i.vectorIndexUserConfigs {
		configs[k] = v
	}

	if i.vectorIndexUserConfig != nil {
		configs[""] = i.vectorIndexUserConfig
	}

	return configs
}

// getTargetVectorIndexConfigs snapshots the named target-vector configs, without
// the legacy one GetVectorIndexConfigs folds in under "".
func (i *Index) getTargetVectorIndexConfigs() map[string]schemaConfig.VectorIndexConfig {
	i.vectorIndexUserConfigLock.Lock()
	defer i.vectorIndexUserConfigLock.Unlock()

	configs := make(map[string]schemaConfig.VectorIndexConfig, len(i.vectorIndexUserConfigs))
	for k, v := range i.vectorIndexUserConfigs {
		configs[k] = v
	}

	return configs
}

func convertToVectorIndexConfig(config interface{}) schemaConfig.VectorIndexConfig {
	if config == nil {
		return nil
	}
	// in case legacy vector config was set as an empty map/object instead of nil
	if empty, ok := config.(map[string]interface{}); ok && len(empty) == 0 {
		return nil
	}
	// Safe type assertion
	if vectorIndexConfig, ok := config.(schemaConfig.VectorIndexConfig); ok {
		return vectorIndexConfig
	}
	return nil
}

func convertToVectorIndexConfigs(configs map[string]models.VectorConfig) map[string]schemaConfig.VectorIndexConfig {
	if len(configs) > 0 {
		vectorIndexConfigs := make(map[string]schemaConfig.VectorIndexConfig)
		for targetVector, vectorConfig := range configs {
			if vectorIndexConfig, ok := vectorConfig.VectorIndexConfig.(schemaConfig.VectorIndexConfig); ok {
				vectorIndexConfigs[targetVector] = vectorIndexConfig
			}
		}
		return vectorIndexConfigs
	}
	return nil
}

// IMPORTANT:
// DebugResetVectorIndex is intended to be used for debugging purposes only.
// It drops the selected vector index, creates a new one, then reindexes it in the background.
// This function assumes the node is not receiving any traffic besides the
// debug endpoints and that async indexing is enabled.
func (i *Index) DebugResetVectorIndex(ctx context.Context, shardName, targetVector string) error {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return err
	}
	defer release()
	if shard == nil {
		return errors.New("shard not found")
	}

	// Get the vector index
	vidx, ok := shard.GetVectorIndex(targetVector)
	if !ok {
		return errors.New("vector index not found")
	}

	if !hnsw.IsHNSWIndex(vidx) {
		return errors.New("vector index is not hnsw")
	}

	// Reset the vector index
	err = shard.DebugResetVectorIndex(ctx, targetVector)
	if err != nil {
		return errors.Wrap(err, "failed to reset vector index")
	}

	// Reindex in the background
	enterrors.GoWrapper(func() {
		err = shard.FillQueue(targetVector, 0)
		if err != nil {
			i.logger.WithField("shard", shardName).WithError(err).Error("failed to reindex vector index")
			return
		}
	}, i.logger)

	return nil
}

func (i *Index) DebugRepairIndex(ctx context.Context, shardName, targetVector string) error {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return err
	}
	defer release()
	if shard == nil {
		return errors.New("shard not found")
	}

	// Repair in the background
	enterrors.GoWrapper(func() {
		err := shard.RepairIndex(context.Background(), targetVector)
		if err != nil {
			i.logger.WithField("shard", shardName).WithError(err).Error("failed to repair vector index")
			return
		}
	}, i.logger)

	return nil
}

func (i *Index) tenantDirExists(tenantName string) (bool, error) {
	tenantPath := shardPath(i.path(), tenantName)
	if _, err := os.Stat(tenantPath); err != nil {
		// when inactive tenant is not populated, its directory does not exist yet
		if !errors.Is(err, os.ErrNotExist) {
			return false, err
		}
		return false, nil
	}
	return true, nil
}

func (i *Index) buildReadRoutingPlan(cl routerTypes.ConsistencyLevel, tenantName string) (routerTypes.ReadRoutingPlan, error) {
	planOptions := routerTypes.RoutingPlanBuildOptions{
		Tenant:                tenantName,
		ConsistencyLevel:      cl,
		AllowTenantActivation: true,
	}
	readPlan, err := i.router.BuildReadRoutingPlan(planOptions)
	if err != nil {
		return routerTypes.ReadRoutingPlan{}, err
	}

	return readPlan, nil
}

func (i *Index) DebugRequantizeIndex(ctx context.Context, shardName, targetVector string) error {
	shard, release, err := i.GetShard(ctx, shardName)
	if err != nil {
		return err
	}
	defer release()
	if shard == nil {
		return errors.New("shard not found")
	}

	// Repair in the background
	enterrors.GoWrapper(func() {
		err := shard.RequantizeIndex(context.Background(), targetVector)
		if err != nil {
			i.logger.WithField("shard", shardName).WithError(err).Error("failed to requantize vector index")
			return
		}
	}, i.logger)

	return nil
}

// enterRead admits an operation onto a live index; pair it with exitRead. The
// Add runs under closeLock.RLock, so it cannot land after beginClose's Wait.
func (i *Index) enterRead() error {
	i.closeLock.RLock()
	defer i.closeLock.RUnlock()

	if i.closed {
		return errAlreadyShutdown
	}
	i.inflight.Add(1)
	return nil
}

func (i *Index) exitRead() { i.inflight.Done() }

// beginClose closes the index and drains in-flight readers. It returns holding
// no lock: teardown must not exclude readers, or a peer's RPC handler blocks
// behind it while this node waits on that peer.
func (i *Index) beginClose() error {
	i.closeLock.Lock()
	if i.closed {
		i.closeLock.Unlock()
		return errAlreadyShutdown
	}
	i.closed = true
	// Terminal registry sweep. Safe because i.closed is set under closeLock.Lock and every
	// bucket-registering init path re-checks it under closeLock.RLock, so no live
	// bucket for this index can register once the drop begins.
	defer lsmkv.GlobalBucketRegistry.RemoveByPrefixes(i.path())
	i.closingCancel()
	i.closeLock.Unlock()

	i.inflight.Wait()
	return nil
}
