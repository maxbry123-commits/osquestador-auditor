//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/sirupsen/logrus"
	bolterrors "go.etcd.io/bbolt/errors"

	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv/editops"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv/segmentindex"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringset"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringsetrange"
	"github.com/weaviate/weaviate/entities/cyclemanager"
	"github.com/weaviate/weaviate/entities/diskio"
	"github.com/weaviate/weaviate/entities/lsmkv"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/entities/storagestate"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"
	"github.com/weaviate/weaviate/usecases/memwatch"
)

// baseLayerHeadroomFactor sizes the base layer's pooled buffer with 25%
// headroom so the in-place merges of later layers usually fit without
// reallocating off-pool.
const baseLayerHeadroomFactor = 1.25

type SegmentGroup struct {
	segments []Segment

	// Holds compacted / cleaned up segments meant to be closed and removed from disk
	// after their's refs counter drops to 0.
	segmentsAwaitingDrop []struct {
		seg  Segment
		time time.Time
	}
	segmentsAwaitingLastWarn time.Time
	// Counter for generating unique names of segments marked for deletions.
	// Segments for deletions are marked with unique stamp and extension eg:
	// segment-1771258130098421000.db.1771333257123.deleteme
	deleteMarkerCounter *atomic.Int64

	// Lock() for changing the currently active segments, RLock() for normal
	// operation
	maintenanceLock sync.RWMutex
	dir             string

	strategy string

	compactionCallbackCtrl cyclemanager.CycleCallbackCtrl

	logger logrus.FieldLogger

	// for backward-compatibility with states where the disk state for maps was
	// not guaranteed to be sorted yet
	mapRequiresSorting bool

	status     storagestate.Status
	statusLock sync.Mutex
	metrics    *Metrics

	// all "replace" buckets support counting through net additions, but not all
	// produce a meaningful count. Typically, the only count we're interested in
	// is that of the bucket that holds objects
	monitorCount bool

	mmapContents             bool
	keepTombstones           bool // see bucket for more details
	useBloomFilter           bool // see bucket for more details
	calcCountNetAdditions    bool // see bucket for more details
	compactLeftOverSegments  bool // see bucket for more details
	enableChecksumValidation bool
	MinMMapSize              int64
	keepLevelCompaction      bool // see bucket for more details

	allocChecker   memwatch.AllocChecker
	maxSegmentSize int64

	segmentCleaner     segmentCleaner
	cleanupInterval    time.Duration
	lastCleanupCall    time.Time
	lastCompactionCall time.Time

	// editOps tracks in-place segment edit operations and the segments still
	// pending rewrite. It also builds the per-pass value transformer (see
	// BuildCurrentTransformer). nil unless edit ops are enabled for this segment
	// group.
	editOps *SegmentEditOps

	roaringSetRangeSegmentInMemory *roaringsetrange.SegmentInMemory
	bitmapBufPool                  roaringset.BitmapBufPool
	// bitmapBufPool wrapped with baseLayerHeadroomFactor for roaringSetGet's
	// base layer; built once at construction
	bitmapBufPoolWithHeadroom    roaringset.BitmapBufPool
	bm25config                   *schema.BM25Config
	lazyPropertyLengths          *configRuntime.DynamicValue[bool]
	writeSegmentInfoIntoFileName bool
	writeMetadata                bool
	sequentialAccess             bool // hint kernel for sequential read-ahead (export snapshots)

	shouldSkipKey func(key []byte, ctx context.Context) (bool, error)
	// averagePropLength caches the live-set property-length sum and count for BM25
	// scoring, avoiding a per-segment recalculation on every query. Published as a
	// single pointer so a reader never observes a torn sum/count pair while a flush
	// or compaction updates the accounting.
	averagePropLength atomic.Pointer[avgPropLengthStats]
}

// avgPropLengthStats is an immutable (sum, count) snapshot; updates swap in a new
// value rather than mutating the fields.
type avgPropLengthStats struct {
	sum   uint64
	count uint64
}

type sgConfig struct {
	dir                          string
	strategy                     string
	mapRequiresSorting           bool
	monitorCount                 bool
	mmapContents                 bool
	keepTombstones               bool
	useBloomFilter               bool
	calcCountNetAdditions        bool
	forceCompaction              bool
	keepLevelCompaction          bool
	maxSegmentSize               int64
	cleanupInterval              time.Duration
	enableChecksumValidation     bool
	keepSegmentsInMemory         bool
	MinMMapSize                  int64
	bm25config                   *models.BM25Config
	lazyPropertyLengths          *configRuntime.DynamicValue[bool]
	writeSegmentInfoIntoFileName bool
	writeMetadata                bool
	sequentialAccess             bool
	shouldSkipKey                func(key []byte, ctx context.Context) (bool, error)
	className                    string
}

func newSegmentGroup(ctx context.Context, logger logrus.FieldLogger, metrics *Metrics, cfg sgConfig,
	compactionCallbacks cyclemanager.CycleCallbackGroup, b *Bucket, files map[string]int64,
) (_ *SegmentGroup, err error) {
	now := time.Now()
	deleteMarkerCounter := new(atomic.Int64)
	deleteMarkerCounter.Store(now.UnixMilli())

	sg := &SegmentGroup{
		segments:                     make([]Segment, len(files)),
		dir:                          cfg.dir,
		logger:                       logger,
		metrics:                      metrics,
		monitorCount:                 cfg.monitorCount,
		mapRequiresSorting:           cfg.mapRequiresSorting,
		strategy:                     cfg.strategy,
		mmapContents:                 cfg.mmapContents,
		keepTombstones:               cfg.keepTombstones,
		useBloomFilter:               cfg.useBloomFilter,
		calcCountNetAdditions:        cfg.calcCountNetAdditions,
		compactLeftOverSegments:      cfg.forceCompaction,
		maxSegmentSize:               cfg.maxSegmentSize,
		cleanupInterval:              cfg.cleanupInterval,
		enableChecksumValidation:     cfg.enableChecksumValidation,
		allocChecker:                 b.allocChecker,
		lastCompactionCall:           now,
		lastCleanupCall:              now,
		MinMMapSize:                  cfg.MinMMapSize,
		writeSegmentInfoIntoFileName: cfg.writeSegmentInfoIntoFileName,
		writeMetadata:                cfg.writeMetadata,
		sequentialAccess:             cfg.sequentialAccess,
		lazyPropertyLengths:          cfg.lazyPropertyLengths,
		bitmapBufPool:                b.bitmapBufPool,
		bitmapBufPoolWithHeadroom:    roaringset.NewBitmapBufPoolFactorWrapper(b.bitmapBufPool, baseLayerHeadroomFactor),
		keepLevelCompaction:          cfg.keepLevelCompaction,
		shouldSkipKey:                cfg.shouldSkipKey,
		deleteMarkerCounter:          deleteMarkerCounter,
	}

	// Clean up stale scratch directories left behind by a prior version that
	// used scratch files during compaction/flushing. These are no longer
	// created, but may linger after an upgrade if the process crashed mid-
	// compaction before the old code could remove them.
	if entries, err := os.ReadDir(cfg.dir); err == nil {
		for _, e := range entries {
			if e.IsDir() && strings.HasSuffix(e.Name(), ".scratch.d") {
				p := filepath.Join(cfg.dir, e.Name())
				if err := os.RemoveAll(p); err != nil {
					logger.WithError(err).WithField("path", p).
						Warn("failed to remove stale scratch directory")
				}
			}
		}
	}

	segmentIndex := 0

	// Note: it's important to process first the compacted segments
	// TODO: a single iteration may be possible

	// Sorted: adopting one .tmp adds and removes segments that decide how the next
	// one is resolved, so a map range would recover the same directory
	// differently on every start.
	tmpEntries := make([]string, 0, len(files))
	for entry := range files {
		if filepath.Ext(entry) == ".tmp" {
			tmpEntries = append(tmpEntries, entry)
		}
	}
	slices.Sort(tmpEntries)

	for _, entry := range tmpEntries {
		potentialCompactedSegmentFileName := strings.TrimSuffix(entry, ".tmp")

		if filepath.Ext(potentialCompactedSegmentFileName) != ".db" {
			// A non-.db segment .tmp (e.g. a precomputed segment-X.bloom.tmp) is a
			// leftover from a crash during a compaction/cleanup switch — no such
			// work runs during init — so remove it. The derived files are
			// recomputed on load.
			if strings.HasPrefix(entry, "segment-") {
				if err := os.Remove(filepath.Join(sg.dir, entry)); err != nil {
					return nil, fmt.Errorf("delete leftover segment temp file %q: %w", entry, err)
				}
			}
			continue
		}

		jointSegments := segmentID(potentialCompactedSegmentFileName)
		jointSegmentsIDs := strings.Split(jointSegments, "_")

		if len(jointSegmentsIDs) == 1 {
			// cleanup leftover, to be removed
			if err := os.Remove(filepath.Join(sg.dir, entry)); err != nil {
				return nil, fmt.Errorf("delete partially cleaned segment %q: %w", entry, err)
			}
			continue
		}

		if len(jointSegmentsIDs) != 2 {
			logger.WithField("action", "lsm_segment_init").
				WithField("path", filepath.Join(sg.dir, entry)).
				Warn("ignored (partially written) LSM compacted segment generated with a version older than v1.24.0")

			continue
		}

		// jointSegmentsIDs[0] is the left segment, jointSegmentsIDs[1] is the right segment
		leftSegmentFound, _ := segmentExistsWithID(jointSegmentsIDs[0], files)
		rightSegmentFound, rightSegmentFilename := segmentExistsWithID(jointSegmentsIDs[1], files)

		rightSegmentPath := filepath.Join(sg.dir, rightSegmentFilename)

		if leftSegmentFound && rightSegmentFound {
			delete(files, entry)
			if err := os.Remove(filepath.Join(sg.dir, entry)); err != nil {
				return nil, fmt.Errorf("delete partially compacted segment %q: %w", entry, err)
			}
			continue
		}

		if leftSegmentFound && !rightSegmentFound {
			// a switch marks the left segment before the right one, so this state
			// cannot come from an interrupted switch: the file is a leftover of a
			// compaction that never switched, and the operator can delete it
			return nil, fmt.Errorf("compacted segment %q has no right segment with id %s "+
				"left to replace, delete the compacted segment to recover", entry, jointSegmentsIDs[1])
		}

		if !leftSegmentFound && rightSegmentFound {
			// segment is initialized just to be erased
			// there is no need of bloom filters nor net addition counter re-calculation
			rightSegment, err := newSegment(rightSegmentPath, logger,
				metrics, sg.makeExistsOn(nil),
				segmentConfig{
					mmapContents:             sg.mmapContents,
					useBloomFilter:           sg.useBloomFilter,
					calcCountNetAdditions:    sg.calcCountNetAdditions,
					overwriteDerived:         false,
					enableChecksumValidation: sg.enableChecksumValidation,
					sequentialAccess:         sg.sequentialAccess,
					MinMMapSize:              sg.MinMMapSize,
					allocChecker:             sg.allocChecker,
					fileList:                 make(map[string]int64), // empty to not check if bloom/cna files already exist
					writeMetadata:            sg.writeMetadata,
					deleteMarkerCounter:      sg.deleteMarkerCounter.Add(1),
					lazyPropertyLengths:      sg.lazyPropertyLengths,
				})
			if err != nil {
				return nil, fmt.Errorf("init already compacted right segment %s: %w", rightSegmentFilename, err)
			}

			err = rightSegment.close()
			if err != nil {
				return nil, fmt.Errorf("close already compacted right segment %s: %w", rightSegmentFilename, err)
			}

			// https://github.com/weaviate/weaviate/pull/6128 introduces the ability
			// to drop segments delayed by renaming them first and then dropping them
			// later.
			//
			// The existing functionality (previously .drop) was renamed to
			// .dropImmediately. We are keeping the old behavior in this mainly for
			// backward compatbility, but also because the motivation behind the
			// delayed deletion does not apply here:
			//
			// The new behavior is meant to split the deletion into two steps, to
			// reduce the time that an expensive lock – which could block readers -
			// is held. In this scenario, the segment has not been initialized yet,
			// so there is no one we could be blocking.
			//
			// The total time is the same, so we can also just drop it immediately.
			err = rightSegment.dropImmediately()
			if err != nil {
				return nil, fmt.Errorf("delete already compacted right segment %s: %w", rightSegmentFilename, err)
			}
			delete(files, rightSegmentFilename)
			// the compacted segment can take over the same name below and would
			// otherwise try to load the derived files that were just deleted
			for _, path := range rightSegment.sidecarPaths() {
				delete(files, filepath.Base(path))
			}

			err = diskio.Fsync(sg.dir)
			if err != nil {
				return nil, fmt.Errorf("fsync segment directory %s: %w", sg.dir, err)
			}
		}

		// the same rename a completed switch would have done, which keeps whatever
		// level and strategy the compaction wrote into the name
		newRightSegmentPath, err := stripTmpExtension(filepath.Join(sg.dir, entry),
			jointSegmentsIDs[0], jointSegmentsIDs[1])
		if err != nil {
			return nil, fmt.Errorf("adopt compacted segment %q: %w", entry, err)
		}

		logger.WithField("action", "lsm_segment_init").
			WithField("path", newRightSegmentPath).
			Info("took over the segment of a compaction that was interrupted mid-switch")

		// initialize in correct order in the next iteration
		files[filepath.Base(newRightSegmentPath)] = files[entry]
		delete(files, entry)
	}

	// segments need to be initialised in order of their timestamp to ensure that various computations are correct (CNA etc)
	// Any init failure from here on discards sg without a shutdown — mid-loop
	// load errors, WAL recovery, the sidecar-recovery hard-fail, cleaner init.
	// Close whatever segments were already opened or every reload retry leaks
	// their mmaps. Nil entries: the slice is pre-sized and truncated after the
	// loop.
	defer func() {
		if err == nil {
			return
		}
		for _, seg := range sg.segments {
			if seg == nil {
				continue
			}
			if closeErr := seg.close(); closeErr != nil {
				sg.logger.WithField("path", cfg.dir).
					Warnf("close segment after failed segment-group init: %v", closeErr)
			}
			sg.metrics.DecSegmentTotalByStrategy(sg.strategy)
		}
	}()

	fileList := make([]string, 0, len(files))
	for entry := range files {
		fileList = append(fileList, entry)
	}
	slices.Sort(fileList)

	for _, entry := range fileList {
		if filepath.Ext(entry) == DeleteMarkerSuffix {
			// marked for deletion, but never actually deleted. Delete now.
			if err := os.Remove(filepath.Join(sg.dir, entry)); err != nil {
				// don't abort if the delete fails, we can still continue (albeit
				// without freeing disk space that should have been freed)
				sg.logger.WithError(err).WithFields(logrus.Fields{
					"action": "lsm_segment_init_deleted_previously_marked_files",
					"file":   entry,
				}).Error("failed to delete file already marked for deletion")
			}
			continue

		}

		if filepath.Ext(entry) != ".db" {
			// skip, this could be commit log, etc.
			continue
		}

		// before we can mount this file, we need to check if a WAL exists for it.
		// If yes, we must assume that the flush never finished, as otherwise the
		// WAL would have been deleted. Thus we must remove it.
		walFileName, _, _ := strings.Cut(entry, ".")
		walFileName += ".wal"
		_, ok := files[walFileName]
		if ok {
			// the segment will be recovered from the WAL
			err := os.Remove(filepath.Join(sg.dir, entry))
			if err != nil {
				return nil, fmt.Errorf("delete partially written segment %s: %w", entry, err)
			}

			logger.WithField("action", "lsm_segment_init").
				WithField("path", filepath.Join(sg.dir, entry)).
				WithField("wal_path", walFileName).
				Info("discarded (partially written) LSM segment, because an active WAL for " +
					"the same segment was found. A recovery from the WAL will follow.")

			continue
		}

		var segment Segment
		segConf := segmentConfig{
			mmapContents:             sg.mmapContents,
			useBloomFilter:           sg.useBloomFilter,
			calcCountNetAdditions:    sg.calcCountNetAdditions,
			overwriteDerived:         false,
			enableChecksumValidation: sg.enableChecksumValidation,
			sequentialAccess:         sg.sequentialAccess,
			MinMMapSize:              sg.MinMMapSize,
			allocChecker:             sg.allocChecker,
			fileList:                 files,
			writeMetadata:            sg.writeMetadata,
			deleteMarkerCounter:      sg.deleteMarkerCounter.Add(1),
			lazyPropertyLengths:      sg.lazyPropertyLengths,
		}
		var err error
		if b.lazySegmentLoading {
			segment, err = newLazySegment(filepath.Join(sg.dir, entry), logger,
				metrics, sg.makeExistsOn(sg.segments[:segmentIndex]), segConf,
			)
			if err != nil {
				return nil, fmt.Errorf("init lazy segment %s: %w", filepath.Join(sg.dir, entry), err)
			}
		} else {
			segment, err = newSegment(filepath.Join(sg.dir, entry), logger,
				metrics, sg.makeExistsOn(sg.segments[:segmentIndex]), segConf,
			)
			if err != nil {
				return nil, fmt.Errorf("init segment %s: %w", filepath.Join(sg.dir, entry), err)
			}
		}
		sg.segments[segmentIndex] = segment
		segmentIndex++

		sg.metrics.IncSegmentTotalByStrategy(sg.strategy)
		sg.metrics.ObserveSegmentSize(sg.strategy, segment.Size())
	}

	sg.segments = sg.segments[:segmentIndex]

	// Actual strategy is stored in segment files. In case it is SetCollection,
	// while new implementation uses bitmaps and supposed to be RoaringSet,
	// bucket and segmentgroup strategy is changed back to SetCollection
	// (memtables will be created later on, with already modified strategy)
	// TODO what if only WAL files exists, and there is no segment to get actual strategy?
	if b.strategy == StrategyRoaringSet && len(sg.segments) > 0 &&
		sg.segments[0].getStrategy() == segmentindex.StrategySetCollection {
		b.strategy = StrategySetCollection
		b.desiredStrategy = StrategyRoaringSet
		sg.strategy = StrategySetCollection
	}
	// As of v1.19 property's IndexInterval setting is replaced with
	// IndexFilterable (roaring set) + IndexSearchable (map) and enabled by default.
	// Buckets for text/text[] inverted indexes created before 1.19 have strategy
	// map and name that since 1.19 is used by filterable indeverted index.
	// Those buckets (roaring set by configuration, but in fact map) have to be
	// renamed on startup by migrator. Here actual strategy is set based on
	// data found in segment files
	if b.strategy == StrategyRoaringSet && len(sg.segments) > 0 &&
		sg.segments[0].getStrategy() == segmentindex.StrategyMapCollection {
		b.strategy = StrategyMapCollection
		b.desiredStrategy = StrategyRoaringSet
		sg.strategy = StrategyMapCollection
	}

	// Inverted segments share a lot of their logic as the MapCollection,
	// and the main difference is in the way they store their data.
	// Setting the desired strategy to Inverted will make sure that we can
	// distinguish between the two strategies for search.
	// The changes only apply when we have segments on disk,
	// as the memtables will always be created with the MapCollection strategy.
	if b.strategy == StrategyInverted && len(sg.segments) > 0 &&
		sg.segments[0].getStrategy() == segmentindex.StrategyMapCollection {
		b.strategy = StrategyMapCollection
		b.desiredStrategy = StrategyInverted
		sg.strategy = StrategyMapCollection
	} else if b.strategy == StrategyMapCollection && len(sg.segments) > 0 &&
		sg.segments[0].getStrategy() == segmentindex.StrategyInverted {
		// TODO amourao: blockmax "else" to be removed before final release
		// in case bucket was created as inverted and default strategy was reverted to map
		// by unsetting corresponding env variable
		b.strategy = StrategyInverted
		b.desiredStrategy = StrategyMapCollection
		sg.strategy = StrategyInverted
	}

	// Construct the edit-ops sidecar BEFORE WAL recovery: the recovery must
	// know whether ops exist — a last-WAL memtable kept live under a pending
	// drop would hold pre-strip bytes outside the pending-segment bookkeeping
	// (see mayRecoverFromCommitLogs). Recovery of the sidecar itself runs
	// after the WALs, over the final segment set.
	if cfg.className != "" && cfg.strategy == StrategyReplace {
		sg.editOps = newSegmentEditOps(cfg.dir, cfg.className)
		sg.editOps.logger = sg.logger
		// Any later init failure discards sg without a shutdown — the probe
		// or recovery may have opened the sidecar's bolt (flock held), and a
		// leaked handle wedges every reload retry until process restart.
		defer func() {
			if err != nil {
				if closeErr := sg.editOps.Close(); closeErr != nil {
					sg.logger.WithField("path", cfg.dir).
						Warnf("close edit-ops sidecar after failed init: %v", closeErr)
				}
			}
		}()
	}

	if err := b.mayRecoverFromCommitLogs(ctx, sg, files); err != nil {
		return nil, err
	}

	if sg.monitorCount {
		sg.metrics.ObjectCount(sg.count())
	}

	// Recover the sidecar AFTER WAL recovery so it judges the settled segment
	// set — it prunes rows whose segments are gone from disk, and must not run
	// while WAL replay is still creating segments (construction happened above,
	// before recovery — still ahead of the cleaner, which consults sg.editOps,
	// and of the compaction cycle registration: published before any pass reads
	// it). The bolt file opens lazily on the first registered op, so an objects
	// bucket that never sees a drop carries no sidecar. Closed in shutdown.
	if sg.editOps != nil {
		if err := sg.recoverEditOps(ctx); err != nil {
			if errors.Is(err, bolterrors.ErrTimeout) {
				// The sidecar's bolt file is still locked — a previous instance of
				// this shard has not finished closing. Its ops and pending sets are
				// unreadable, so cleanup could neither arm transformers nor tell
				// stripped segments from unstripped ones (running blind here is how
				// a completed drop's data once got resurrected); fail the load so
				// the shard lifecycle retries once the old instance is gone.
				return nil, fmt.Errorf("segment edit ops sidecar still locked by a previous instance: %w", err)
			}
			// Other failures are not fatal: bricking the shard over drop-progress
			// bookkeeping (e.g. a torn sidecar copy) would trade data availability
			// for cleanup state. The drop stalls and every cleanup pass logs until
			// repaired.
			sg.logger.WithField("path", cfg.dir).
				Errorf("recover segment edit ops failed; drop-vector cleanup on this shard is stalled: %v", err)
		}
	}

	sc, err := newSegmentCleaner(sg)
	if err != nil {
		return nil, err
	}
	sg.segmentCleaner = sc

	// if a segment exists of the map collection strategy, we need to
	// convert the inverted strategy to a map collection strategy
	// as it is done on the bucket level
	if sg.strategy == StrategyInverted && len(sg.segments) > 0 &&
		sg.segments[0].getStrategy() == segmentindex.StrategyMapCollection {
		sg.strategy = StrategyMapCollection
	}

	switch sg.strategy {
	case StrategyInverted:
		if len(sg.segments) == 0 {
			break
		}
		var stats avgPropLengthStats
		avg, count := sg.segments[len(sg.segments)-1].getInvertedData().avgPropertyLengthsAvg, sg.segments[len(sg.segments)-1].getInvertedData().avgPropertyLengthsCount

		if count > 0 {
			stats.sum += uint64(avg * float64(count))
			stats.count += count
		}
		// start with last but one segment, as the last one doesn't need tombstones for now
		for i := len(sg.segments) - 2; i >= 0; i-- {
			// avoid crashing if segment has no tombstones
			tombstonesNext, err := sg.segments[i+1].ReadOnlyTombstones()
			if err != nil {
				return nil, fmt.Errorf("init segment %s: load tombstones %w", sg.segments[i+1].getPath(), err)
			}
			if _, err := sg.segments[i].MergeTombstones(tombstonesNext); err != nil {
				return nil, fmt.Errorf("init segment %s: merge tombstones %w", sg.segments[i].getPath(), err)
			}

			avg, count := sg.segments[i].getInvertedData().avgPropertyLengthsAvg, sg.segments[i].getInvertedData().avgPropertyLengthsCount

			if count > 0 {
				stats.sum += uint64(avg * float64(count))
				stats.count += count
			}
		}
		sg.averagePropLength.Store(&stats)

	case StrategyRoaringSetRange:
		if cfg.keepSegmentsInMemory {
			t := time.Now()
			sg.roaringSetRangeSegmentInMemory = roaringsetrange.NewSegmentInMemory(sg.logger)
			for _, seg := range sg.segments {
				cursor := seg.newRoaringSetRangeCursor()
				if err := sg.roaringSetRangeSegmentInMemory.MergeSegmentByCursor(cursor); err != nil {
					return nil, fmt.Errorf("build segment-in-memory of strategy '%s': %w", sg.strategy, err)
				}
			}
			logger.WithFields(logrus.Fields{
				"took":    time.Since(t).String(),
				"bucket":  filepath.Base(cfg.dir),
				"size_mb": fmt.Sprintf("%.3f", float64(sg.roaringSetRangeSegmentInMemory.Size())/1024/1024),
			}).Debug("rangeable segment-in-memory built")
		}
	}

	id := "segmentgroup/compaction/" + sg.dir
	sg.compactionCallbackCtrl = compactionCallbacks.Register(id, sg.compactOrCleanup)

	return sg, nil
}

func (sg *SegmentGroup) pauseCompaction(ctx context.Context) error {
	return sg.compactionCallbackCtrl.Deactivate(ctx)
}

func (sg *SegmentGroup) resumeCompaction(_ context.Context) error {
	return sg.compactionCallbackCtrl.Activate()
}

// buildRoaringSetRangeRep merges the current disk segments (ref-counted,
// oldest to newest) into a fresh unpublished rep. Caller must have paused
// compaction so the merged segments stay a stable prefix for
// installRoaringSetRangeRep's catch-up.
//
// Caller must not call the returned release until installRoaringSetRangeRep
// returns: holding the ref keeps a concurrent shutdown() from closing these
// segments mid-merge. The release is deferred and only suppressed on
// success, so a panic mid-merge still releases it instead of leaking a ref
// that would hang the next shutdown() forever.
func (sg *SegmentGroup) buildRoaringSetRangeRep(ctx context.Context) (*roaringsetrange.SegmentInMemory, []Segment, func(), error) {
	segments, release := sg.getConsistentViewOfSegments()
	ownershipTransferred := false
	defer func() {
		if !ownershipTransferred {
			release()
		}
	}()

	if sg.allocChecker != nil {
		// Unbounded full-property build; refuse on memory pressure so the
		// caller degrades to disk serving instead of risking an OOM kill.
		var totalSize int64
		for _, seg := range segments {
			totalSize += seg.Size()
		}
		if err := sg.allocChecker.CheckAlloc(totalSize); err != nil {
			sg.logger.WithFields(logrus.Fields{
				"action":   "rangeable_inmemory_rebuild",
				"event":    "rebuild_skipped_oom",
				"bucket":   filepath.Base(sg.dir),
				"segments": len(segments),
			}).Warnf("skipping rangeable in-memory rebuild due to memory pressure: %v", err)
			return nil, nil, nil, err
		}
	}

	t := time.Now()
	rep := roaringsetrange.NewSegmentInMemory(sg.logger)
	for _, seg := range segments {
		if err := ctx.Err(); err != nil {
			return nil, nil, nil, err
		}
		if err := rep.MergeSegmentByCursor(seg.newRoaringSetRangeCursor()); err != nil {
			return nil, nil, nil, fmt.Errorf("merge segment into rangeable rep: %w", err)
		}
	}
	sg.logger.WithFields(logrus.Fields{
		"took":     time.Since(t).String(),
		"bucket":   filepath.Base(sg.dir),
		"segments": len(segments),
		"size_mb":  fmt.Sprintf("%.3f", float64(rep.Size())/1024/1024),
	}).Debug("rangeable segment-in-memory rebuilt")
	ownershipTransferred = true
	return rep, segments, release, nil
}

// installRoaringSetRangeRep merges segments appended after the bulk build
// (flush appends only; compaction must stay paused) and publishes the rep.
// Caller must hold the bucket's flushLock so no flush races the catch-up
// with the publish. releaseBuilt always runs via defer, so a group shut
// down mid-rebuild is never blocked past this call.
//
// Compaction staying paused for the whole span means appends only grow the
// tail, so the catch-up view is always a superset of alreadyMerged. The
// publish assignment pairs maintenanceLock.Lock() here with the RLock()
// guard in PrependSegmentsFromBucket.
func (sg *SegmentGroup) installRoaringSetRangeRep(rep *roaringsetrange.SegmentInMemory, alreadyMerged []Segment, releaseBuilt func()) error {
	defer releaseBuilt()

	segments, release := sg.getConsistentViewOfSegments()
	defer release()

	catchUpFrom := len(alreadyMerged)
	if catchUpFrom > len(segments) {
		// Should be unreachable while compaction stays paused (segments
		// only grow); guard defensively against a slice-bounds panic.
		sg.logger.WithFields(logrus.Fields{
			"bucket":         filepath.Base(sg.dir),
			"already_merged": catchUpFrom,
			"current":        len(segments),
		}).Debug("rangeable rep catch-up: segment count shrank since bulk build, skipping catch-up merge")
		catchUpFrom = len(segments)
	}

	for _, seg := range segments[catchUpFrom:] {
		if err := rep.MergeSegmentByCursor(seg.newRoaringSetRangeCursor()); err != nil {
			return fmt.Errorf("catch-up merge segment into rangeable rep: %w", err)
		}
	}

	sg.maintenanceLock.Lock()
	sg.roaringSetRangeSegmentInMemory = rep
	sg.maintenanceLock.Unlock()
	return nil
}

func (sg *SegmentGroup) makeExistsOn(segments []Segment) existsOnLowerSegmentsFn {
	return func(key []byte) (bool, error) {
		if len(segments) == 0 {
			// this is already the lowest possible segment, we can guarantee that
			// any key in this segment is previously unseen.
			return false, nil
		}
		if _, err := sg.getWithSegmentList(key, segments); err != nil {
			if !errors.Is(err, lsmkv.Deleted) && !errors.Is(err, lsmkv.NotFound) {
				return false, fmt.Errorf("check exists on segments: %w", err)
			}
			return false, nil
		}
		return true, nil
	}
}

func (sg *SegmentGroup) add(path string) error {
	sg.maintenanceLock.Lock()
	defer sg.maintenanceLock.Unlock()

	segment, err := newSegment(path, sg.logger,
		sg.metrics, sg.makeExistsOn(sg.segments),
		segmentConfig{
			mmapContents:             sg.mmapContents,
			useBloomFilter:           sg.useBloomFilter,
			calcCountNetAdditions:    sg.calcCountNetAdditions,
			overwriteDerived:         true,
			enableChecksumValidation: sg.enableChecksumValidation,
			sequentialAccess:         sg.sequentialAccess,
			MinMMapSize:              sg.MinMMapSize,
			allocChecker:             sg.allocChecker,
			writeMetadata:            sg.writeMetadata,
			deleteMarkerCounter:      sg.deleteMarkerCounter.Add(1),
			lazyPropertyLengths:      sg.lazyPropertyLengths,
		})
	if err != nil {
		return fmt.Errorf("init segment %s: %w", path, err)
	}

	sg.segments = append(sg.segments, segment)
	sg.metrics.IncSegmentTotalByStrategy(sg.strategy)
	sg.metrics.ObserveSegmentSize(sg.strategy, segment.Size())

	// this path adds a segment post-init (WAL recovery flushing a recovered
	// memtable), so it owns the same accounting a flush does
	sg.countSegmentAveragePropLength(segment)

	return nil
}

// segmentAtPositionHasID reports, under maintenanceLock, whether the in-memory
// segment at pos still has the given id. Used to re-validate a position-based
// swap before it runs, so a wrong-segment swap fails loudly instead of corrupting
// data if the compaction/cleanup serialization invariant is ever broken.
func (sg *SegmentGroup) segmentAtPositionHasID(pos int, id string) bool {
	sg.maintenanceLock.RLock()
	defer sg.maintenanceLock.RUnlock()
	return pos >= 0 && pos < len(sg.segments) && segmentID(sg.segments[pos].getPath()) == id
}

// recoverEditOps runs startup recovery for the edit-ops sidecar: sweep ops whose
// task is gone (load-bearing: re-arming an orphaned op would strip a re-created
// same-name vector), then prune rows for segments gone from disk
// (SegmentEditOps.Recover). Surviving pending sets are kept as recorded — they
// are the resume point of an interrupted strip; see Recover for why absence
// from pending firmly means "clean" across every rewrite and crash window
// (segments born from WAL replay were already durably pended by the recovery
// itself; see mayRecoverFromCommitLogs). Runs before the compaction cycle
// registers, so no pass races the segment-set read.
func (sg *SegmentGroup) recoverEditOps(ctx context.Context) error {
	if sg.editOps == nil {
		return nil
	}
	sg.maintenanceLock.RLock()
	ids := sg.currentSegmentIDsLocked()
	sg.maintenanceLock.RUnlock()
	return sg.editOps.Recover(ids,
		func() map[string]struct{} { return sg.liveEditOpIDs(ctx, false) },
		func() map[string]struct{} { return sg.liveEditOpIDs(ctx, true) })
}

// liveEditOpIDs resolves the live-op set for the orphan sweep via the package
// provider (editops.SetLivenessProvider), or nil to skip it (no provider, or a
// lookup failure — sweeping on a bad read could drop a still-live op, so we
// prefer to re-arm and let a later load reconcile).
func (sg *SegmentGroup) liveEditOpIDs(ctx context.Context, fresh bool) map[string]struct{} {
	if !editops.LivenessProviderInstalled() {
		// Only reached with edit ops present: a missing provider silently disables
		// the orphan sweep, which the startup wiring is supposed to prevent — warn
		// loudly instead of hiding it.
		sg.logger.Warnf("drop-vector: no edit-op liveness provider installed; orphan sweep disabled for this load")
		return nil
	}
	var live map[string]struct{}
	var err error
	if fresh {
		live, err = editops.LiveOpsFresh(ctx)
	} else {
		live, err = editops.LiveOps(ctx)
	}
	if err != nil {
		sg.logger.Warnf("drop-vector: live edit-op lookup failed; skipping orphan sweep this load: %v", err)
		return nil
	}
	return live
}

// registerEditOpAndSnapshot registers opID and snapshots the current on-disk
// segments in one write. Idempotent via the snapshot guard (not the descriptor),
// so a resume completes an interrupted register rather than skipping it, and one
// that already snapshotted does not re-queue completed segments. The segment IDs
// are read and written under maintenanceLock so the snapshot stays coherent with
// the in-memory segment set.
func (sg *SegmentGroup) registerEditOpAndSnapshot(opID string, desc OpDescriptor) error {
	if sg.editOps == nil {
		return fmt.Errorf("edit ops not enabled for this segment group")
	}
	snapshotted, err := sg.editOps.HasPendingSnapshot(opID)
	if err != nil {
		return err
	}
	if snapshotted {
		return nil
	}

	sg.maintenanceLock.RLock()
	defer sg.maintenanceLock.RUnlock()
	return sg.editOps.RegisterOpWithSnapshot(opID, desc, sg.currentSegmentIDsLocked())
}

// requeueQuarantinedEditOps returns opID's quarantined segments to pending with
// a fresh retry budget (see SegmentEditOps.RequeueQuarantined). Called when a
// new round re-arms an already-snapshotted op. The live-segment set is read and
// used under maintenanceLock so a concurrent merge cannot swap segments between
// the read and the write.
func (sg *SegmentGroup) requeueQuarantinedEditOps(opID string) error {
	if sg.editOps == nil {
		return fmt.Errorf("edit ops not enabled for this segment group")
	}
	sg.maintenanceLock.RLock()
	defer sg.maintenanceLock.RUnlock()
	return sg.editOps.RequeueQuarantined(opID, sg.currentSegmentIDsLocked())
}

// currentSegmentIDsLocked snapshots the in-memory segment IDs. Caller must hold
// maintenanceLock (read).
func (sg *SegmentGroup) currentSegmentIDsLocked() []string {
	ids := make([]string, len(sg.segments))
	for i, seg := range sg.segments {
		ids[i] = segmentID(seg.getPath())
	}
	return ids
}

func (sg *SegmentGroup) getConsistentViewOfSegments() (segments []Segment, release func()) {
	sg.maintenanceLock.RLock()
	segments = make([]Segment, len(sg.segments))
	copy(segments, sg.segments)

	// incRef under the RLock so the refs are taken before any compaction (which
	// holds the write lock) can swap these segments out. refCount is atomic, so no
	// separate refcount lock is needed.
	for _, seg := range segments {
		seg.incRef()
	}
	sg.maintenanceLock.RUnlock()

	return segments, func() {
		for _, seg := range segments {
			seg.decRef()
		}
	}
}

func (sg *SegmentGroup) addInitializedSegment(segment Segment) (err error) {
	defer func() {
		if err != nil {
			return
		}
		sg.metrics.IncSegmentTotalByStrategy(sg.strategy)
		sg.metrics.ObserveSegmentSize(sg.strategy, segment.Size())
	}()

	sg.maintenanceLock.Lock()
	defer sg.maintenanceLock.Unlock()

	sg.segments = append(sg.segments, segment)
	return nil
}

// not thread-safe on its own, as the assumption is that this is called from a
// lockholder, e.g. within .get()
func (sg *SegmentGroup) getWithSegmentList(key []byte, segments []Segment) ([]byte, error) {
	if err := CheckExpectedStrategy(sg.strategy, StrategyReplace); err != nil {
		return nil, fmt.Errorf("SegmentGroup::getWithSegmentList(): %w", err)
	}

	// start with latest and exit as soon as something is found, thus making sure
	// the latest takes presence
	for i := len(segments) - 1; i >= 0; i-- {
		beforeSegment := time.Now()
		v, err := segments[i].get(key)
		if duration := time.Since(beforeSegment); duration > 100*time.Millisecond {
			sg.logger.WithError(err).
				WithFields(logrus.Fields{
					"duration":    duration,
					"action":      "lsm_segment_group_get_individual_segment",
					"segment_pos": i,
				}).Debug("waited over 100ms to get result from individual segment")
		}
		if err == nil {
			return v, nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			return nil, err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return nil, fmt.Errorf("SegmentGroup::getWithSegmentList() %q: %w", segments[i].getPath(), err)
		}
	}

	return nil, lsmkv.NotFound
}

// existsWithSegmentList checks if a key exists and is not deleted, without reading the full value.
// This is more efficient than getWithSegmentList() when only existence check is needed.
func (sg *SegmentGroup) existsWithSegmentList(key []byte, segments []Segment) error {
	return sg.existsWithSegmentListUpTo(key, 0, segments)
}

// existsWithSegmentList checks if a key exists and is not deleted, without reading the full value.
// This is more efficient than getWithSegmentList() when only existence check is needed.
func (sg *SegmentGroup) existsWithSegmentListUpTo(key []byte, segIdx int, segments []Segment) error {
	if err := CheckExpectedStrategy(sg.strategy, StrategyReplace); err != nil {
		return fmt.Errorf("SegmentGroup::existsWithSegmentListUpTo(): %w", err)
	}

	// start with latest and exit as soon as something is found, thus making sure
	// the latest takes presence
	for i := len(segments) - 1; i >= segIdx; i-- {
		beforeSegment := time.Now()
		err := segments[i].exists(key)
		if duration := time.Since(beforeSegment); duration > 100*time.Millisecond {
			sg.logger.WithError(err).
				WithFields(logrus.Fields{
					"duration":    duration,
					"action":      "lsm_segment_group_exists_individual_segment",
					"segment_pos": i,
				}).Debug("waited over 100ms to check existence in individual segment")
		}
		if err == nil {
			return nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			return err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return fmt.Errorf("SegmentGroup::existsWithSegmentList() %q: %w", segments[i].getPath(), err)
		}
	}

	return lsmkv.NotFound
}

func (sg *SegmentGroup) getBySecondaryWithSegmentList(pos int, key []byte, buffer []byte,
	segments []Segment,
) ([]byte, []byte, []byte, int, error) {
	if err := CheckExpectedStrategy(sg.strategy, StrategyReplace); err != nil {
		return nil, nil, nil, -1, fmt.Errorf("SegmentGroup::getBySecondaryWithSegmentList(): %w", err)
	}

	// start with latest and exit as soon as something is found, thus making sure
	// the latest takes presence
	for i := len(segments) - 1; i >= 0; i-- {
		beforeSegment := time.Now()
		k, v, allocBuf, err := segments[i].getBySecondary(pos, key, buffer)
		if duration := time.Since(beforeSegment); duration > 100*time.Millisecond {
			sg.logger.WithError(err).
				WithFields(logrus.Fields{
					"duration":    duration,
					"action":      "lsm_segment_group_getbysecondary_individual_segment",
					"segment_pos": i,
				}).Debug("waited over 100ms to get result from individual segment")
		}
		if err == nil {
			return k, v, allocBuf, i, nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			return nil, nil, nil, i, err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return nil, nil, nil, i, fmt.Errorf("SegmentGroup::getBySecondaryWithSegmentList() %q: %w", segments[i].getPath(), err)
		}
	}
	return nil, nil, nil, -1, lsmkv.NotFound
}

func (sg *SegmentGroup) getCollection(key []byte, segments []Segment) ([]value, error) {
	var out []value

	// start with first and do not exit
	for _, segment := range segments {
		v, err := segment.getCollection(key)
		if err != nil {
			if errors.Is(err, lsmkv.NotFound) {
				continue
			}

			return nil, err
		}

		if len(out) == 0 {
			out = v
		} else {
			out = append(out, v...)
		}
	}

	return out, nil
}

func (sg *SegmentGroup) getCollectionBytes(key []byte, segments []Segment) ([][]byte, error) {
	var out [][]byte

	// start with first and do not exit
	for _, segment := range segments {
		v, err := segment.getCollectionBytes(key)
		if err != nil {
			if errors.Is(err, lsmkv.NotFound) {
				continue
			}

			return nil, err
		}

		if len(out) == 0 {
			out = v
		} else {
			out = append(out, v...)
		}
	}

	return out, nil
}

func (sg *SegmentGroup) getCollectionAndSegments(ctx context.Context, key []byte, segments []Segment) ([][]value, []Segment, error) {
	out := make([][]value, len(segments))
	outSegments := make([]Segment, len(segments))

	i := 0
	// start with first and do not exit
	for _, segment := range segments {
		if ctx.Err() != nil {
			return nil, nil, ctx.Err()
		}
		v, err := segment.getCollection(key)
		if err != nil {
			if !errors.Is(err, lsmkv.NotFound) {
				return nil, nil, err
			}
			// inverted segments need to be loaded anyway, even if they don't have
			// the key, as we need to know if they have tombstones
			if segment.getStrategy() != segmentindex.StrategyInverted {
				continue
			}
		}

		out[i] = v
		outSegments[i] = segment
		i++
	}

	return out[:i], outSegments[:i], nil
}

// roaringSetGet folds all disk segments holding key into a single BitmapLayer:
// the first segment with the key becomes the base (additions cloned into a
// pooled buffer with headroom), every later segment merges into it in place.
// If no segment has the key, a zero BitmapLayer and noop release are returned.
// Only Additions is fully folded; Deletions is the first segment's deletions,
// retained solely so its buffer gets released — not the flattened deletions.
func (sg *SegmentGroup) roaringSetGet(key []byte, segments []Segment, maxConc int) (out roaringset.BitmapLayer, release func(), err error) {
	ln := len(segments)
	if ln == 0 {
		return out, noopRelease, nil
	}

	// acquired (not the named return, which error paths overwrite with
	// noopRelease) is what the defer frees, so a mid-merge disk read error
	// can't leak the first layer's pooled buffer.
	acquired := noopRelease

	i := 0
	for ; i < ln; i++ {
		layer, layerRelease, getErr := segments[i].roaringSetGet(key, sg.bitmapBufPoolWithHeadroom)
		if getErr == nil {
			out = layer
			acquired = layerRelease
			i++
			break
		}
		if !errors.Is(getErr, lsmkv.NotFound) {
			return roaringset.BitmapLayer{}, noopRelease, getErr
		}
	}
	defer func() {
		if err != nil {
			acquired()
		}
	}()

	for ; i < ln; i++ {
		if mergeErr := segments[i].roaringSetMergeWith(key, out, sg.bitmapBufPool, maxConc); mergeErr != nil {
			err = mergeErr
			return roaringset.BitmapLayer{}, noopRelease, err
		}
	}

	return out, acquired, nil
}

func (sg *SegmentGroup) count() int {
	segments, release := sg.getConsistentViewOfSegments()
	defer release()

	return sg.countWithSegmentList(segments)
}

// roaringSetRangeDiskSegmentCount returns the on-disk segment count via a
// cheap read lock only. Must not be held while bitmapsLock is held.
func (sg *SegmentGroup) roaringSetRangeDiskSegmentCount() int {
	sg.maintenanceLock.RLock()
	defer sg.maintenanceLock.RUnlock()

	return len(sg.segments)
}

func (sg *SegmentGroup) countWithSegmentList(segments []Segment) int {
	count := 0
	for _, seg := range segments {
		count += seg.getCountNetAdditions()
	}

	return count
}

func (sg *SegmentGroup) shutdown(ctx context.Context) error {
	if err := sg.compactionCallbackCtrl.Unregister(ctx); err != nil {
		return fmt.Errorf("long-running compaction in progress: %w", ctx.Err())
	}
	if err := sg.segmentCleaner.close(); err != nil {
		return err
	}
	if sg.editOps != nil {
		if err := sg.editOps.Close(); err != nil {
			return err
		}
	}

	// TODO aliszka:copy-on-read forbid consistent view to be created from that point
	sg.maintenanceLock.RLock()
	ln1 := len(sg.segmentsAwaitingDrop)
	ln2 := len(sg.segments)
	segmentsWithRefs := make([]Segment, ln1+ln2)
	copy(segmentsWithRefs[ln1:], sg.segments)
	for i := range ln1 {
		segmentsWithRefs[i] = sg.segmentsAwaitingDrop[i].seg
	}
	sg.maintenanceLock.RUnlock()

	sg.waitForReferenceCountToReachZero(segmentsWithRefs...)
	sg.dropSegmentsAwaiting()

	// Lock acquirement placed after compaction cycle stop request, due to occasional deadlock,
	// because compaction logic used in cycle also requires maintenance lock.
	//
	// If lock is grabbed by shutdown method and compaction in cycle loop starts right after,
	// it is blocked waiting for the same lock, eventually blocking entire cycle loop and preventing to read stop signal.
	// If stop signal can not be read, shutdown will not receive stop result and will not proceed with further execution.
	// Maintenance lock will then never be released.
	sg.maintenanceLock.Lock()
	defer sg.maintenanceLock.Unlock()

	for _, seg := range sg.segments {
		// For sequential-access buckets, drop page cache entries before
		// closing to avoid polluting the cache with pages that won't be
		// accessed again. Best-effort: fadvise is purely advisory.
		if sg.sequentialAccess {
			if cs, ok := seg.(*segment); ok && cs.contentFile != nil {
				_ = fadviseDontNeed(cs.contentFile, cs.size)
			}
		}

		if err := seg.close(); err != nil {
			return err
		}
		sg.metrics.DecSegmentTotalByStrategy(sg.strategy)
	}

	// make sure the segment list itself is set to nil. In case a memtable will
	// still flush after closing, it might try to read from a disk segment list
	// otherwise and run into nil-pointer problems.
	sg.segments = nil

	return nil
}

func (sg *SegmentGroup) UpdateStatus(status storagestate.Status) {
	sg.statusLock.Lock()
	defer sg.statusLock.Unlock()

	sg.status = status
}

func (sg *SegmentGroup) isReadyOnly() bool {
	sg.statusLock.Lock()
	defer sg.statusLock.Unlock()

	return sg.status == storagestate.StatusReadOnly
}

// traceEnabled reports whether the logger emits trace entries, so callers can
// skip building WithField chains a normal log level would discard. A logger of
// unknown type is treated as enabled rather than silently losing the line.
func traceEnabled(logger logrus.FieldLogger) bool {
	switch l := logger.(type) {
	case *logrus.Logger:
		return l.IsLevelEnabled(logrus.TraceLevel)
	case *logrus.Entry:
		return l.Logger.IsLevelEnabled(logrus.TraceLevel)
	default:
		return true
	}
}

func fileExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}

	if errors.Is(err, fs.ErrNotExist) {
		return false, nil
	}

	return false, err
}

func segmentExistsWithID(segmentID string, files map[string]int64) (bool, string) {
	// segment file format is "segment-{segmentID}.EXT" where EXT is either
	// - ".db" if extra infos in filename are not used
	// - ".{extra_infos}.db" if extra infos in filename are used
	match := fmt.Sprintf("segment-%s.", segmentID)
	for fileName := range files {
		if strings.HasPrefix(fileName, match) && strings.HasSuffix(fileName, ".db") {
			return true, fileName
		}
	}
	return false, ""
}

func (sg *SegmentGroup) compactOrCleanup(shouldAbort cyclemanager.ShouldAbortCallback) bool {
	sg.monitorSegments()

	compact := func() bool {
		sg.lastCompactionCall = time.Now()
		compacted, err := sg.compactOnceAbortable(context.Background(), shouldAbort)
		if err != nil {
			sg.logger.WithField("action", "lsm_compaction").
				WithField("path", sg.dir).
				WithError(err).
				Errorf("compaction failed")
		} else if !compacted && traceEnabled(sg.logger) {
			sg.logger.WithField("action", "lsm_compaction").
				WithField("path", sg.dir).
				Trace("no segments eligible for compaction")
		}
		return compacted
	}
	cleanup := func() bool {
		sg.lastCleanupCall = time.Now()
		cleaned, err := sg.segmentCleaner.cleanupOnce(shouldAbort)
		if err != nil {
			sg.logger.WithField("action", "lsm_cleanup").
				WithField("path", sg.dir).
				WithError(err).
				Errorf("cleanup failed")
		}
		return cleaned
	}

	defer func() {
		if _, err := sg.dropSegmentsAwaiting(); err != nil {
			sg.logger.WithField("action", "lsm_drop_segments_awaiting").
				WithField("path", sg.dir).
				WithError(err).
				Errorf("periodical drop failed")
		}
	}()

	// alternatively run compaction or cleanup first
	// if 1st one called succeeds, 2nd one is skipped, otherwise 2nd one is called as well
	//
	// compaction has the precedence over cleanup, however if cleanup
	// was not called for over [forceCleanupInterval], force at least one execution
	// in between compactions.
	// (ignore if compaction was not called within that time either)
	forceCleanupInterval := time.Hour * 12

	if time.Since(sg.lastCleanupCall) > forceCleanupInterval && sg.lastCleanupCall.Before(sg.lastCompactionCall) {
		return cleanup() || compact()
	}
	return compact() || cleanup()
}

func (sg *SegmentGroup) Len() int {
	segments, release := sg.getConsistentViewOfSegments()
	defer release()

	return len(segments)
}

func (sg *SegmentGroup) GetAveragePropertyLength() (float64, uint64) {
	stats := sg.averagePropLength.Load()
	if stats == nil || stats.count == 0 {
		return 0, 0
	}
	return float64(stats.sum) / float64(stats.count), stats.count
}

// countSegmentAveragePropLength folds a segment that has just become live in
// the group into the average-property-length accounting. Every path that makes a
// segment live must call it — flush, add (WAL recovery) and prepend — because
// reconcileAveragePropertyLength subtracts a retired segment's contribution at
// compaction: a segment that is live but uncounted would have a contribution
// subtracted that was never added, underflowing the running total.
func (sg *SegmentGroup) countSegmentAveragePropLength(segment Segment) {
	if sg.strategy != StrategyInverted {
		return
	}
	inv := segment.getInvertedData()
	if inv.avgPropertyLengthsCount == 0 {
		return
	}
	sg.addAveragePropLength(uint64(inv.avgPropertyLengthsAvg*float64(inv.avgPropertyLengthsCount)),
		inv.avgPropertyLengthsCount)
}

// addAveragePropLength applies a (sum, count) delta to the published snapshot.
// Deltas may wrap for subtraction; the running total always covers what is being
// removed, so the result never underflows.
func (sg *SegmentGroup) addAveragePropLength(deltaSum, deltaCount uint64) {
	for {
		cur := sg.averagePropLength.Load()
		next := avgPropLengthStats{}
		if cur != nil {
			next = *cur
		}
		next.sum += deltaSum
		next.count += deltaCount
		if sg.averagePropLength.CompareAndSwap(cur, &next) {
			return
		}
	}
}

// reconcileAveragePropertyLength moves the average-property-length accounting
// from the two retired segments to the merged one after an inverted compaction,
// so the group's avgdl denominator tracks the live set. Reusing the flush and
// init paths' uint64(avg*count) accumulation makes the running total cancel
// exactly and match a restart's recompute-from-segments.
func (sg *SegmentGroup) reconcileAveragePropertyLength(retiredLeft, retiredRight, merged Segment) {
	contribution := func(inv *segmentInvertedData) (sum, count uint64) {
		if inv.avgPropertyLengthsCount == 0 {
			return 0, 0
		}
		return uint64(inv.avgPropertyLengthsAvg * float64(inv.avgPropertyLengthsCount)), inv.avgPropertyLengthsCount
	}

	oldSumL, oldCountL := contribution(retiredLeft.getInvertedData())
	oldSumR, oldCountR := contribution(retiredRight.getInvertedData())
	newSum, newCount := contribution(merged.getInvertedData())

	sg.addAveragePropLength(newSum-oldSumL-oldSumR, newCount-oldCountL-oldCountR)
}
