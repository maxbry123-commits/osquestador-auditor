//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"context"
	"fmt"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"strings"
	"sync"

	"github.com/weaviate/weaviate/entities/loadlimiter"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"

	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/entities/cyclemanager"
	"github.com/weaviate/weaviate/entities/errorcompounder"
	enterrors "github.com/weaviate/weaviate/entities/errors"
	entsentry "github.com/weaviate/weaviate/entities/sentry"
	"github.com/weaviate/weaviate/entities/storagestate"
	wsync "github.com/weaviate/weaviate/entities/sync"
)

var ErrAlreadyClosed = errors.New("store already closed")

// Store groups multiple buckets together, it "owns" one folder on the file
// system
type Store struct {
	dir     string
	rootDir string

	// Prevent concurrent manipulations to the bucketsByNameMap, most notably
	// when initializing buckets in parallel
	bucketAccessLock sync.RWMutex
	bucketsByName    map[string]*Bucket

	logger  logrus.FieldLogger
	metrics *Metrics

	cycleCallbacks *storeCycleCallbacks
	bcreator       BucketCreator
	// Prevent concurrent manipulations to the same Bucket, specially if there is
	// action on the bucket in the meantime.
	bucketsLocks *wsync.KeyLocker
	loadLimiter  *loadlimiter.LoadLimiter

	closeLock sync.RWMutex
	closed    bool
}

// New initializes a new [Store] based on the root dir. If state is present on
// disk, it is loaded, if the folder is empty a new store is initialized in
// there.
func New(dir, rootDir string, logger logrus.FieldLogger, metrics *Metrics, loadLimiter *loadlimiter.LoadLimiter,
	shardCompactionCallbacks, shardCompactionAuxCallbacks,
	shardFlushCallbacks cyclemanager.CycleCallbackGroup,
) (*Store, error) {
	s := &Store{
		dir:           dir,
		rootDir:       rootDir,
		bucketsByName: map[string]*Bucket{},
		bucketsLocks:  wsync.NewKeyLocker(),
		bcreator:      NewBucketCreator(),
		logger:        logger,
		metrics:       metrics,
		loadLimiter:   loadLimiter,
	}
	s.initCycleCallbacks(shardCompactionCallbacks, shardCompactionAuxCallbacks, shardFlushCallbacks)

	return s, s.init()
}

func (s *Store) Bucket(name string) *Bucket {
	s.bucketAccessLock.RLock()
	defer s.bucketAccessLock.RUnlock()

	return s.bucketNoLock(name)
}

// bucketNoLock returns a bucket by name; caller must hold bucketAccessLock.
func (s *Store) bucketNoLock(name string) *Bucket {
	return s.bucketsByName[name]
}

// AcquireBucketForRead returns the bucket registered under name, pinned via
// lifetimeLock.RLock so a concurrent swap+Shutdown cannot free it mid-query.
// Unknown name returns (nil, no-op release); caller MUST release exactly once.
//
// TEARDOWN INVARIANT: no teardown path may hold bucketAccessLock across a
// draining bucket.Shutdown — deregister first, then drain outside the lock,
// or the whole store deadlocks.
func (s *Store) AcquireBucketForRead(name string) (*Bucket, func()) {
	s.bucketAccessLock.RLock()
	b := s.bucketsByName[name]
	if b == nil {
		s.bucketAccessLock.RUnlock()
		return nil, func() {}
	}
	b.lifetimeLock.RLock()
	s.bucketAccessLock.RUnlock()
	return b, b.lifetimeLock.RUnlock
}

func (s *Store) UpdateBucketsStatus(targetStatus storagestate.Status) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: updating buckets state in store %q", ErrAlreadyClosed, s.dir)
	}

	// UpdateBucketsStatus is a write operation on the bucket itself, but from
	// the perspective of our bucket access map this is a read-only operation,
	// hence an RLock()
	s.bucketAccessLock.RLock()
	defer s.bucketAccessLock.RUnlock()

	for _, b := range s.bucketsByName {
		if b != nil {
			b.UpdateStatus(targetStatus)
		}
	}

	return nil
}

func (s *Store) init() error {
	if err := os.MkdirAll(s.dir, 0o700); err != nil {
		return err
	}
	return nil
}

func (s *Store) bucketDir(bucketName string) string {
	return path.Join(s.dir, bucketName)
}

func (s *Store) GetDir() string {
	return s.dir
}

// CreateOrLoadBucket registers a bucket with the given name. If state on disk
// exists for this bucket it is loaded, otherwise created. Pass [BucketOptions]
// to configure the strategy of a bucket. The strategy defaults to "replace".
// For example, to load or create a map-type bucket, do:
//
//	ctx := context.Background()
//	err := store.CreateOrLoadBucket(ctx, "my_bucket_name", WithStrategy(StrategyReplace))
//	if err != nil { /* handle error */ }
//
//	// you can now access the bucket using store.Bucket()
//	b := store.Bucket("my_bucket_name")
func (s *Store) CreateOrLoadBucket(ctx context.Context, bucketName string,
	opts ...BucketOption,
) (err error) {
	defer func() {
		p := recover()
		if p == nil {
			// happy path
			return
		}

		entsentry.Recover(p)

		err = fmt.Errorf("unexpected error loading bucket %q at path %q: %v",
			bucketName, s.rootDir, p)
		// logger is already annotated to identify the store (e.g. collection +
		// shard), we only need to annotate it with the exact path of this
		// bucket.
		s.logger.
			WithFields(logrus.Fields{
				"action":   "lsm_create_or_load_bucket",
				"root_dir": s.rootDir,
				"dir":      s.dir,
				"bucket":   bucketName,
			}).
			WithError(err).Errorf("unexpected error loading shard")
		enterrors.PrintStack(s.logger)
	}()

	if s.loadLimiter != nil {
		if err := s.loadLimiter.Acquire(ctx); err != nil {
			return errors.Wrapf(err, "acquire load limiter for bucket %q", bucketName)
		}
		defer s.loadLimiter.Release()
	}

	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: adding a bucket %q to store %q", ErrAlreadyClosed, bucketName, s.dir)
	}

	s.bucketsLocks.Lock(bucketName)
	defer s.bucketsLocks.Unlock(bucketName)

	if b := s.Bucket(bucketName); b != nil {
		return nil
	}

	compactionCallbacks := s.cycleCallbacks.compactionCallbacks
	if bucketName == helpers.ObjectsBucketLSM && s.cycleCallbacks.compactionAuxCallbacks != nil {
		compactionCallbacks = s.cycleCallbacks.compactionAuxCallbacks
	}

	// bucket can be concurrently loaded with another buckets but
	// the same bucket will be loaded only once
	b, err := s.bcreator.NewBucket(ctx, s.bucketDir(bucketName), s.rootDir, s.logger, s.metrics,
		compactionCallbacks, s.cycleCallbacks.flushCallbacks, opts...)
	if err != nil {
		return err
	}

	s.setBucket(bucketName, b)

	return nil
}

func (s *Store) setBucket(name string, b *Bucket) {
	s.bucketAccessLock.Lock()
	defer s.bucketAccessLock.Unlock()

	s.bucketsByName[name] = b
}

func (s *Store) Shutdown(ctx context.Context) error {
	s.closeLock.Lock()
	defer s.closeLock.Unlock()

	if s.closed {
		return fmt.Errorf("%w: closing store %q", ErrAlreadyClosed, s.dir)
	}

	s.closed = true

	// Snapshot + clear the registry, then release bucketAccessLock BEFORE
	// draining (TEARDOWN INVARIANT on AcquireBucketForRead). Consequence:
	// mid-teardown Store.Bucket returns nil where it previously returned a
	// shutting-down bucket — query paths nil-check for this.
	s.bucketAccessLock.Lock()
	buckets := make(map[string]*Bucket, len(s.bucketsByName))
	for name, bucket := range s.bucketsByName {
		buckets[name] = bucket
	}
	s.bucketsByName = map[string]*Bucket{}
	s.bucketAccessLock.Unlock()

	// shutdown must be called on every bucket
	eg := enterrors.NewErrorGroupWrapper(s.logger)
	eg.SetLimit(runtime.GOMAXPROCS(0))

	for name, bucket := range buckets {
		name := name
		bucket := bucket

		eg.Go(func() error {
			if err := bucket.Shutdown(ctx); err != nil {
				return errors.Wrapf(err, "shutdown bucket %q of store %q", name, s.dir)
			}
			return nil
		})
	}

	return eg.Wait()
}

// ErrBucketNotFound is the sentinel returned by [Store.ShutdownBucket]
// when the named bucket is absent at shutdown time. Callers that race
// against another teardown path (cancel-cleanup, restart-bootstrap) can
// match this sentinel with [errors.Is] to treat "already gone" as the
// desired post-state. Callers that genuinely expected the bucket to be
// present (e.g. the reindex task that just created it) propagate the
// error normally.
var ErrBucketNotFound = errors.New("bucket not found")

func (s *Store) ShutdownBucket(ctx context.Context, bucketName string) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	// Remove from the registry FIRST, drain outside bucketAccessLock
	// (TEARDOWN INVARIANT on AcquireBucketForRead). Deregistered even if
	// Shutdown errors: a half-shut-down bucket must not be pinnable.
	s.bucketAccessLock.Lock()
	bucket, ok := s.bucketsByName[bucketName]
	if ok {
		delete(s.bucketsByName, bucketName)
	}
	s.bucketAccessLock.Unlock()

	if !ok {
		return fmt.Errorf("shutdown bucket %q of store %q: %w", bucketName, s.dir, ErrBucketNotFound)
	}
	if err := bucket.Shutdown(ctx); err != nil {
		return errors.Wrapf(err, "shutdown bucket %q of store %q", bucketName, s.dir)
	}
	return nil
}

func (s *Store) WriteWALs() error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: writing wals of store %q", ErrAlreadyClosed, s.dir)
	}

	s.bucketAccessLock.RLock()
	defer s.bucketAccessLock.RUnlock()

	for name, bucket := range s.bucketsByName {
		if err := bucket.WriteWAL(); err != nil {
			return errors.Wrapf(err, "bucket %q", name)
		}
	}

	return nil
}

// bucketJobStatus is used to safely track the status of
// a job applied to each of a store's buckets when run
// in parallel
type bucketJobStatus struct {
	sync.Mutex
	buckets map[*Bucket]error
}

func newBucketJobStatus() *bucketJobStatus {
	return &bucketJobStatus{
		buckets: make(map[*Bucket]error),
	}
}

type jobFunc func(context.Context, *Bucket) (interface{}, error)

type rollbackFunc func(context.Context, *Bucket) error

func (s *Store) ListFiles(ctx context.Context, basePath string) ([]string, error) {
	listFiles := func(ctx context.Context, b *Bucket) (interface{}, error) {
		basePath, err := filepath.Rel(basePath, b.GetDir())
		if err != nil {
			return nil, fmt.Errorf("bucket relative path: %w", err)
		}
		return b.ListFiles(ctx, basePath)
	}

	result, err := s.runJobOnBuckets(ctx, listFiles, nil)
	if err != nil {
		return nil, err
	}

	migrationFiles, err := s.listMigrationFiles(basePath)
	if err != nil {
		return nil, err
	}

	files := migrationFiles
	for _, res := range result {
		files = append(files, res.([]string)...)
	}

	return files, nil
}

func (s *Store) listMigrationFiles(basePath string) ([]string, error) {
	migrationRoot := filepath.Join(s.dir, ".migrations")

	var files []string
	err := filepath.WalkDir(migrationRoot, func(path string, d os.DirEntry, _ error) error {
		if d == nil || d.IsDir() {
			return nil
		}
		// A crash mid-rename leaves the tracker's scratch file behind, and
		// nothing under .migrations ever sweeps it. Copying it would carry it
		// into every later backup and restore.
		if filepath.Ext(d.Name()) == ".tmp" {
			return nil
		}

		relPath, err := filepath.Rel(basePath, path)
		if err != nil {
			return err
		}
		files = append(files, relPath)
		return nil
	})
	if err != nil {
		return nil, errors.Errorf("failed to list files for migrations: %s", err)
	}
	return files, nil
}

// runJobOnBuckets applies a jobFunc to each bucket in the store in parallel.
// The jobFunc allows for the job to return an arbitrary value.
// Additionally, a rollbackFunc may be provided which will be run on the target
// bucket in the event of an unsuccessful job.
func (s *Store) runJobOnBuckets(ctx context.Context,
	jobFunc jobFunc, rollbackFunc rollbackFunc,
) ([]interface{}, error) {
	s.bucketAccessLock.Lock()
	var (
		status      = newBucketJobStatus()
		resultQueue = make(chan interface{}, len(s.bucketsByName))
		wg          = sync.WaitGroup{}
	)

	for _, bucket := range s.bucketsByName {
		wg.Add(1)
		b := bucket
		f := func() {
			defer wg.Done()
			status.Lock()
			defer status.Unlock()
			res, err := jobFunc(ctx, b)
			resultQueue <- res
			status.buckets[b] = err
		}
		enterrors.GoWrapper(f, s.logger)
	}
	s.bucketAccessLock.Unlock()
	wg.Wait()
	close(resultQueue)

	errs := errorcompounder.New()
	for _, err := range status.buckets {
		errs.Add(err)
	}

	if errs.Len() != 0 {
		// if any of the bucket jobs failed, and a
		// rollbackFunc has been provided, attempt
		// to roll back. if this fails, the err is
		// added to the compounder
		for b, jobErr := range status.buckets {
			if jobErr != nil && rollbackFunc != nil {
				if rollbackErr := rollbackFunc(ctx, b); rollbackErr != nil {
					errs.AddWrapf(rollbackErr, "bucket job rollback")
				}
			}
		}

		return nil, errs.ToError()
	}

	var finalResult []interface{}
	for res := range resultQueue {
		finalResult = append(finalResult, res)
	}

	return finalResult, nil
}

func (s *Store) GetBucketsByName() map[string]*Bucket {
	s.bucketAccessLock.RLock()
	defer s.bucketAccessLock.RUnlock()

	newMap := map[string]*Bucket{}
	for name, bucket := range s.bucketsByName {
		newMap[name] = bucket
	}

	return newMap
}

// Creates bucket, first removing any files if already exist
// Bucket can not be registered in bucketsByName before removal
func (s *Store) CreateBucket(ctx context.Context, bucketName string,
	opts ...BucketOption,
) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: adding a bucket %q to store %q", ErrAlreadyClosed, bucketName, s.dir)
	}

	s.bucketsLocks.Lock(bucketName)
	defer s.bucketsLocks.Unlock(bucketName)

	if b := s.Bucket(bucketName); b != nil {
		return fmt.Errorf("bucket %s exists and is already in use", bucketName)
	}

	bucketDir := s.bucketDir(bucketName)
	if err := os.RemoveAll(bucketDir); err != nil {
		return errors.Wrapf(err, "failed removing bucket %s files", bucketName)
	}

	compactionCallbacks := s.cycleCallbacks.compactionCallbacks
	if bucketName == helpers.ObjectsBucketLSM && s.cycleCallbacks.compactionAuxCallbacks != nil {
		compactionCallbacks = s.cycleCallbacks.compactionAuxCallbacks
	}

	b, err := s.bcreator.NewBucket(ctx, bucketDir, s.rootDir, s.logger, s.metrics,
		compactionCallbacks, s.cycleCallbacks.flushCallbacks, opts...)
	if err != nil {
		return err
	}

	s.setBucket(bucketName, b)

	return nil
}

// ReplacedBucketDirSuffix names the dir the displaced bucket sits at between
// [Store.ReplaceBuckets]' two renames. A crash in that window leaves it on
// disk, where only the per-property cleanup sweep in package db picks it up.
const ReplacedBucketDirSuffix = "___del"

// replaceBucket drains the displaced bucket and swaps the two directories on
// disk. Caller must hold replacementBucket.flushLock (flushLock OUTER →
// maintenanceLock INNER, same order as the flush path).
func (s *Store) replaceBucket(ctx context.Context, replacementBucket *Bucket, replacementBucketName string, bucket *Bucket, bucketName string) (string, string, string, string, error) {
	replacementBucket.disk.maintenanceLock.Lock()
	defer replacementBucket.disk.maintenanceLock.Unlock()

	currBucketDir := bucket.dir
	newBucketDir := bucket.dir + ReplacedBucketDirSuffix
	currReplacementBucketDir := replacementBucket.dir
	newReplacementBucketDir := currBucketDir

	if err := bucket.Shutdown(ctx); err != nil {
		return "", "", "", "", errors.Wrapf(err, "failed shutting down bucket old '%s'", bucketName)
	}

	s.logger.WithField("action", "lsm_replace_bucket").
		WithField("bucket", bucketName).
		WithField("replacement_bucket", replacementBucketName).
		WithField("dir", s.dir).
		Info("replacing bucket")

	if err := os.Rename(currBucketDir, newBucketDir); err != nil {
		return "", "", "", "", errors.Wrapf(err, "failed moving orig bucket dir '%s'", currBucketDir)
	}
	if err := os.Rename(currReplacementBucketDir, newReplacementBucketDir); err != nil {
		return "", "", "", "", errors.Wrapf(err, "failed moving replacement bucket dir '%s'", currReplacementBucketDir)
	}

	return currBucketDir, newBucketDir, currReplacementBucketDir, newReplacementBucketDir, nil
}

// freezeAndSwapForReplace makes the replacement name-visible while frozen:
// flushLock is taken before the map swap and held on success, so a by-name
// writer landing before ReplaceBuckets' tail completes blocks instead of
// writing into the memtable the tail discards (lost write).
func (s *Store) freezeAndSwapForReplace(bucketName, replacementBucketName string) (bucket, replacementBucket *Bucket, err error) {
	s.bucketAccessLock.Lock()
	defer s.bucketAccessLock.Unlock()

	bucket = s.bucketsByName[bucketName]
	replacementBucket = s.bucketsByName[replacementBucketName]
	if bucket == nil {
		return nil, nil, fmt.Errorf("bucket '%s' not found", bucketName)
	}
	if replacementBucket == nil {
		return nil, nil, fmt.Errorf("replacement bucket '%s' not found", replacementBucketName)
	}

	replacementBucket.flushLock.Lock()
	if replacementBucket.flushing != nil {
		replacementBucket.flushLock.Unlock() // lock escapes this scope only on success
		return nil, nil, fmt.Errorf("bucket '%s' can not be renamed before flushing", replacementBucketName)
	}

	s.bucketsByName[bucketName] = replacementBucket
	delete(s.bucketsByName, replacementBucketName)
	return bucket, replacementBucket, nil
}

// Replaces 1st bucket with 2nd one. Both buckets have to registered in bucketsByName.
// 2nd bucket swaps the 1st one in bucketsByName using 1st one's name, 2nd one's name is deleted.
// Dir path of 2nd bucket is changed to dir of 1st bucket as well as all other related paths of
// bucket resources (segment group, memtables, commit log).
// Dir path of 1st bucket is temporarily suffixed with "___del", later on bucket is shutdown and
// its files deleted.
// 2nd bucket becomes 1st bucket
func (s *Store) ReplaceBuckets(ctx context.Context, bucketName, replacementBucketName string) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: replacing bucket %q for %q in store %q", ErrAlreadyClosed, bucketName, replacementBucketName, s.dir)
	}

	// Swap the registry entries with the replacement frozen, then drain the
	// displaced bucket (inside replaceBucket) OUTSIDE bucketAccessLock
	// (TEARDOWN INVARIANT on AcquireBucketForRead). By-name access to the
	// replacement blocks on its held flushLock until the move completes.
	bucket, replacementBucket, err := s.freezeAndSwapForReplace(bucketName, replacementBucketName)
	if err != nil {
		return err
	}
	defer replacementBucket.flushLock.Unlock()

	currBucketDir, newBucketDir, currReplacementBucketDir, newReplacementBucketDir, err := s.replaceBucket(ctx, replacementBucket, replacementBucketName, bucket, bucketName)
	if err != nil {
		return errors.Wrapf(err, "failed renaming bucket '%s' to '%s'", bucketName, replacementBucketName)
	}

	replacementBucket.dir = newReplacementBucketDir

	mt, err := replacementBucket.createNewActiveMemtable()
	if err != nil {
		return fmt.Errorf("switch active memtable: %w", err)
	}
	replacementBucket.active = mt

	s.updateBucketDir(bucket, currBucketDir, newBucketDir)
	s.updateBucketDir(replacementBucket, currReplacementBucketDir, newReplacementBucketDir)

	if err := os.RemoveAll(newBucketDir); err != nil {
		return errors.Wrapf(err, "failed removing dir '%s'", newBucketDir)
	}

	return nil
}

func (s *Store) RenameBucket(ctx context.Context, bucketName, newBucketName string) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: renaming bucket %q for %q in store %q", ErrAlreadyClosed, bucketName, newBucketName, s.dir)
	}

	s.bucketAccessLock.Lock()
	defer s.bucketAccessLock.Unlock()

	currBucket := s.bucketsByName[bucketName]
	if currBucket == nil {
		return fmt.Errorf("bucket '%s' not found", bucketName)
	}
	newBucket := s.bucketsByName[newBucketName]
	if newBucket != nil {
		return fmt.Errorf("bucket '%s' already exists", newBucketName)
	}

	if !currBucket.isReadOnly() {
		return fmt.Errorf("bucket '%s' must be in %s mode to be renamed", bucketName, storagestate.StatusReadOnly)
	}

	currBucketDir := currBucket.dir
	newBucketDir := s.bucketDir(newBucketName)

	currBucket.flushLock.Lock()
	defer currBucket.flushLock.Unlock()

	if currBucket.flushing != nil {
		return fmt.Errorf("bucket '%s' can not be renamed before flushing", bucketName)
	}

	currBucket.dir = newBucketDir

	mt, err := currBucket.createNewActiveMemtable()
	if err != nil {
		return fmt.Errorf("switch active memtable: %w", err)
	}
	currBucket.active = mt

	s.bucketsByName[newBucketName] = currBucket
	delete(s.bucketsByName, bucketName)

	if err := os.Rename(currBucketDir, newBucketDir); err != nil {
		return errors.Wrapf(err, "failed renaming bucket dir '%s' to '%s'", currBucketDir, newBucketDir)
	}

	s.updateBucketDir(currBucket, currBucketDir, newBucketDir)

	return nil
}

// SwapBucketPointer atomically redirects all future Store.Bucket(targetName)
// calls to return the bucket currently registered as sourceName. The source
// name is removed from the map. Returns the old bucket (previously at
// targetName) so the caller can shut it down.
//
// This is a pure in-memory operation — no filesystem changes. The caller is
// responsible for:
//   - Shutting down the returned old bucket
//   - Persisting any crash-safety markers (sentinel files) around this call
//   - Finalizing directory renames at a later point (e.g., next restart)
//
// Registry side effect: the source bucket's on-disk path is released from
// [GlobalBucketRegistry] as part of the swap. The source bucket continues to
// serve queries from its original on-disk directory (the rename is deferred
// to next-restart finalization), but in-process callers may now load a fresh
// bucket at that path (typically after wiping the dir via
// cleanStaleSidecarDirs). Without this release a back-to-back migration in
// the same process — e.g. two consecutive filterable retokenizations on the
// same property — aborts at OnAfterLsmInit with
// "bucket already registered" when the second cycle's ingest bucket tries to
// claim the same path. The displaced (old-main) bucket has its own registry
// entry which is cleaned up by the caller's subsequent Shutdown of the
// returned bucket — that path is NOT released here.
func (s *Store) SwapBucketPointer(ctx context.Context, targetName, sourceName string) (*Bucket, error) {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return nil, fmt.Errorf("%w: swapping bucket %q with %q in store %q",
			ErrAlreadyClosed, targetName, sourceName, s.dir)
	}

	s.bucketAccessLock.Lock()
	defer s.bucketAccessLock.Unlock()

	oldBucket, ok := s.bucketsByName[targetName]
	if !ok {
		return nil, fmt.Errorf("target bucket %q not found in store %q", targetName, s.dir)
	}

	sourceBucket, ok := s.bucketsByName[sourceName]
	if !ok {
		return nil, fmt.Errorf("source bucket %q not found in store %q", sourceName, s.dir)
	}

	s.bucketsByName[targetName] = sourceBucket
	delete(s.bucketsByName, sourceName)

	// Release the source bucket's on-disk path from the global registry. See
	// the function doc above for the full rationale. The source bucket is
	// still alive and operates from this dir on disk until FinalizeBucketSwap
	// runs (typically on next restart) — but the registry is purely an
	// in-process de-duplication shield for CreateOrLoadBucket. Releasing it
	// lets a same-process back-to-back migration claim the same path after
	// the on-disk dir has been cleaned by cleanStaleSidecarDirs (called from
	// CleanStalePartialReindexState at submit time).
	//
	// Safety vs the source bucket's eventual Shutdown: Bucket.Shutdown calls
	// GlobalBucketRegistry.Remove(b.registeredPath) which is idempotent —
	// removing a path that is not in the registry is a no-op, and the bucket
	// that did claim the path between the swap and the Shutdown is not affected
	// because every swap in a chain runs this same Remove, so the path is
	// released BEFORE the next bucket claims it. registeredPath equals the
	// source bucket's current dir here (no rename has run yet).
	GlobalBucketRegistry.Remove(sourceBucket.registeredPath)

	return oldBucket, nil
}

// FinalizeBucketSwap completes a deferred bucket swap by renaming directories
// on disk and updating all in-memory paths.
//
// IMPORTANT: This MUST only be called during startup, before the bucket serves
// any queries. It renames the bucket's on-disk directory and rewrites all
// in-memory segment paths. Calling this on a live, query-serving bucket will
// cause data races, stale file handles, and potential data loss.
//
//   - canonicalDir: the directory the bucket should ultimately live at
//   - currentDir:   the directory the bucket was loaded from
//   - backupDir:    the _bak directory to clean up
//
// Steps:
//  1. Flush any active memtable data to a segment (preserves WAL-replayed data)
//  2. Remove backupDir if it exists
//  3. Rename currentDir → canonicalDir
//  4. Update bucket.dir, bucket.disk.dir, and all segment paths in memory
//  5. Create a fresh active memtable at the canonical path
func (s *Store) FinalizeBucketSwap(ctx context.Context, bucketName, canonicalDir, currentDir, backupDir string) error {
	s.closeLock.RLock()
	defer s.closeLock.RUnlock()

	if s.closed {
		return fmt.Errorf("%w: finalizing bucket swap for %q in store %q",
			ErrAlreadyClosed, bucketName, s.dir)
	}

	s.bucketAccessLock.Lock()
	defer s.bucketAccessLock.Unlock()

	bucket, ok := s.bucketsByName[bucketName]
	if !ok {
		return fmt.Errorf("bucket %q not found in store %q", bucketName, s.dir)
	}

	// Flush any in-memory data (e.g. from WAL replay at startup) to a segment
	// before renaming directories. FlushAndSwitch is a no-op for empty
	// memtables.
	if err := bucket.FlushAndSwitch(); err != nil {
		return fmt.Errorf("flush memtable before dir rename: %w", err)
	}

	if err := os.RemoveAll(backupDir); err != nil {
		return fmt.Errorf("remove backup dir %q: %w", backupDir, err)
	}

	if err := os.Rename(currentDir, canonicalDir); err != nil {
		return fmt.Errorf("rename %q to %q: %w", currentDir, canonicalDir, err)
	}

	s.updateBucketDir(bucket, currentDir, canonicalDir)
	bucket.dir = canonicalDir

	bucket.flushLock.Lock()
	defer bucket.flushLock.Unlock()

	mt, err := bucket.createNewActiveMemtable()
	if err != nil {
		return fmt.Errorf("create new active memtable after dir rename: %w", err)
	}
	bucket.active = mt

	return nil
}

func (s *Store) updateBucketDir(bucket *Bucket, bucketDir, newBucketDir string) {
	updatePath := func(src string) string {
		return strings.Replace(src, bucketDir, newBucketDir, 1)
	}

	segments, release := bucket.disk.getConsistentViewOfSegments()
	defer release()

	bucket.disk.dir = newBucketDir
	for _, segment := range segments {
		segment.setPath(updatePath(segment.getPath()))
	}
}
