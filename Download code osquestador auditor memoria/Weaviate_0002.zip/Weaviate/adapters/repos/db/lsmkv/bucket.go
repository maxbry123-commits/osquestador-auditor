//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	"github.com/weaviate/weaviate/entities/diskio"
	"github.com/weaviate/weaviate/entities/errorcompounder"
	"github.com/weaviate/weaviate/usecases/config"
	configRuntime "github.com/weaviate/weaviate/usecases/config/runtime"

	entcfg "github.com/weaviate/weaviate/entities/config"
	enterrors "github.com/weaviate/weaviate/entities/errors"

	"github.com/pkg/errors"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/sirupsen/logrus"

	"github.com/weaviate/sroar"
	"github.com/weaviate/weaviate/adapters/repos/db/helpers"
	"github.com/weaviate/weaviate/adapters/repos/db/inverted/terms"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv/segmentindex"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringset"
	"github.com/weaviate/weaviate/entities/cyclemanager"
	"github.com/weaviate/weaviate/entities/interval"
	"github.com/weaviate/weaviate/entities/lsmkv"
	"github.com/weaviate/weaviate/entities/models"
	"github.com/weaviate/weaviate/entities/schema"
	"github.com/weaviate/weaviate/entities/storagestate"
	"github.com/weaviate/weaviate/entities/storobj"
	"github.com/weaviate/weaviate/usecases/memwatch"
)

// since v1.34 StrategyRoaringSet is default strategy for dimensions bucket,
// StrategyMapCollection is left as backward compatibility for buckets created earlier
var DimensionsBucketPrioritizedStrategies = []string{
	StrategyRoaringSet,
	StrategyMapCollection,
}

const (
	FlushAfterDirtyDefault = 60 * time.Second
	unsetStrategy          = "UNSET"
	contextCheckInterval   = 50 // check context every 50 iterations, every iteration adds too much overhead
)

// ErrImmutable is returned by write operations on a structurally immutable
// bucket (e.g. a snapshot bucket opened via NewSnapshotBucket). This is
// distinct from storagestate.ErrStatusReadOnly which indicates a transient
// operational state set by the parent shard.
var ErrImmutable = errors.New("bucket is immutable")

// memtableNames is used for error messages and metrics when iterating memtables
var memtableNames = [2]string{"active_memtable", "flushing_memtable"}

type BucketCreator interface {
	NewBucket(ctx context.Context, dir, rootDir string, logger logrus.FieldLogger,
		metrics *Metrics, compactionCallbacks, flushCallbacks cyclemanager.CycleCallbackGroup,
		opts ...BucketOption,
	) (*Bucket, error)
}

type Bucket struct {
	dir            string
	registeredPath string
	rootDir        string
	active         memtable
	flushing       memtable
	disk           *SegmentGroup
	logger         logrus.FieldLogger

	// Lock() means a move from active to flushing is happening, RLock() is
	// normal operation
	flushLock sync.RWMutex

	// lifetimeLock pins this bucket for a whole read (RLock via
	// Store.AcquireBucketForRead); Shutdown takes Lock() first, draining all
	// pins before freeing mmap'd segments (no drain timeout — timeout-then-free
	// would SEGFAULT a reader). Order: lifetimeLock OUTER, flushLock INNER.
	lifetimeLock sync.RWMutex
	// flushAndSwitchMu serializes [FlushAndSwitch] calls. The bucket was
	// designed assuming a single triggerer at a time (the periodic flush
	// callback or a control-plane caller — backup, runtime migration,
	// startup finalize); the data hot path never invokes
	// [FlushAndSwitch] directly (writes go through memtable.put without
	// it). When two callers overlap — most visibly seen on the objects
	// bucket with concurrent runtime-reindex migrations — the second
	// caller's atomicallySwitchMemtable observes `active.Size() == 0`
	// and returns early, racing the first caller's still-in-flight
	// flush. Any follow-up `CursorOnDisk` would miss data parked in
	// `b.flushing`. Serializing here gives every caller the invariant
	// "after FlushAndSwitch returns, all data written before the call
	// is durably in segments." See GH https://github.com/weaviate/0-weaviate-issues/issues/212 Issues C+D.
	//
	// Lock ordering: flushAndSwitchMu MUST be acquired BEFORE flushLock.
	// FlushAndSwitch takes flushAndSwitchMu for its full duration and
	// internally takes flushLock during atomicallySwitchMemtable +
	// atomicallyAddDiskSegmentAndRemoveFlushing. Reverse-order callers
	// would deadlock.
	flushAndSwitchMu sync.Mutex
	haltedFlushTimer *interval.BackoffTimer

	minWalThreshold   uint64
	walThreshold      uint64
	flushDirtyAfter   time.Duration
	memtableThreshold uint64
	minMMapSize       int64
	memtableResizer   *memtableSizeAdvisor
	strategy          string
	// Strategy inverted index is supposed to be created with, but existing
	// segment files were created with different one.
	// It can happen when new strategy were introduced to weaviate, but
	// files are already created using old implementation.
	// Example: RoaringSet strategy replaces CollectionSet strategy.
	// Field can be used for migration files of old strategy to newer one.
	desiredStrategy  string
	secondaryIndices uint16

	// Optional to avoid syscalls
	mmapContents  bool
	writeMetadata bool

	// for backward compatibility
	legacyMapSortingBeforeCompaction bool

	flushCallbackCtrl cyclemanager.CycleCallbackCtrl

	status     storagestate.Status
	statusLock sync.RWMutex

	metrics *Metrics

	// all "replace" buckets support counting through net additions, but not all
	// produce a meaningful count. Typically, the only count we're interested in
	// is that of the bucket that holds objects
	monitorCount bool

	// pauseCompactionMu ref-counts reindex pause/resume (weaviate/0-weaviate-issues#251).
	pauseCompactionMu    sync.Mutex
	pauseCompactionCount int

	// pauseTimerMu ref-counts the timer across backup + reindex pause paths.
	pauseTimerMu    sync.Mutex
	pauseTimerCount int
	pauseTimer      *prometheus.Timer

	// Whether tombstones (set/map/replace types) or deletions (roaringset type)
	// should be kept in root segment during compaction process.
	// Since segments are immutable, deletions are added as new entries with
	// tombstones. Tombstones are by default copied to merged segment, as they
	// can refer to keys/values present in previous segments.
	// Those tombstones can be removed entirely when merging with root (1st) segment,
	// due to lack of previous segments, tombstones may relate to.
	// As info about key/value being deleted (based on tombstone presence) may be important
	// for some use cases (e.g. replication needs to know if object(ObjectsBucketLSM) was deleted)
	// keeping tombstones on compaction is optional
	keepTombstones bool

	// Init and use bloom filter for getting key from bucket segments.
	// As some buckets can be accessed only with cursor (see flat index),
	// where bloom filter is not applicable, it can be disabled.
	// ON by default
	useBloomFilter bool

	// Net additions keep track of number of elements stored in bucket (of type replace).
	// As some buckets don't have to provide Count info (see flat index),
	// tracking additions can be disabled.
	// ON by default
	calcCountNetAdditions bool

	forceCompaction     bool
	disableCompaction   bool
	lazySegmentLoading  bool
	lazyPropertyLengths *configRuntime.DynamicValue[bool]

	// Block-max WAND filter/tombstone-fold gate, read in createDiskTermFromCV
	// (see WithBM25FilterTombMergeGateRatio). Runtime-tunable via Get().
	bm25FilterTombMergeGateRatio *configRuntime.DynamicValue[float64]

	// Canonical class name carried by the bucket. Required for any bucket
	// whose readers go through the storobj decoders (the objects bucket); set
	// via WithClassName at creation time so the decoders can stamp the
	// canonical class on every decoded object instead of trusting the (no
	// longer authoritative) on-disk class-name field. ClassName() returns an
	// error when this is empty — buckets that do not hold storobj payloads
	// (inverted, prop-length, etc.) leave it unset because those readers
	// never call ClassName() in the first place.
	className string

	// if true, don't increase the segment level during compaction.
	// useful for migrations, as it allows to merge reindex and ingest buckets
	// without discontinuities in segment levels.
	keepLevelCompaction bool

	// optionally supplied to prevent starting memory-intensive
	// processes when memory pressure is high
	allocChecker memwatch.AllocChecker

	// optional segment size limit. If set, a compaction will skip segments that
	// sum to more than the specified value.
	maxSegmentSize int64

	// optional segments cleanup interval. If set, segments will be cleaned of
	// redundant obsolete data, that was deleted or updated in newer segments
	// (currently supported only in buckets of REPLACE strategy)
	segmentsCleanupInterval time.Duration

	// optional validation of segment file checksums. Enabling this option
	// introduces latency of segment availability, for the tradeoff of
	// ensuring segment files have integrity before reading them.
	enableChecksumValidation bool

	// keep segments in memory for more performant search
	// (currently used by roaringsetrange inverted indexes)
	keepSegmentsInMemory bool

	// rangeableInMemoryDeferred marks a bucket whose rep was intentionally left
	// unbuilt (reindex ingest path). Selects a diagnostic log line only;
	// rangeableServesFromMemory alone governs read-path selection.
	rangeableInMemoryDeferred bool

	// rangeableRepRebuilt flips once RebuildRangeableSegmentInMemory
	// publishes a rep. Atomic and read unlocked; the false->true store
	// happens under flushLock after the rep is fully built, so a reader
	// observing true is guaranteed a populated rep.
	rangeableRepRebuilt atomic.Bool

	// shuttingDown flips at Shutdown entry and never resets: registering a
	// NEW edit op on a closing bucket must hard-fail (see RegisterEditOp) —
	// the snapshot would race the dismantling and could record "nothing to
	// clean" for a bucket full of data.
	shuttingDown atomic.Bool

	// Dedup for the rangeable diagnostic log lines, once per bucket-open.
	rangeableDeferredLogOnce  sync.Once
	rangeableFallbackWarnOnce sync.Once

	// pool of buffers for bitmaps merges
	// (currently used by roaringsetrange inverted indexes)
	bitmapBufPool roaringset.BitmapBufPool

	// add information like the level and the strategy into the filename so these things can be checked without loading
	// the segment
	writeSegmentInfoIntoFileName bool

	bm25Config *models.BM25Config

	// function to decide whether a key should be skipped
	// during compaction for the SetCollection strategy
	shouldSkipKey func(key []byte, ctx context.Context) (bool, error)

	skipSecondaryKeyCheck bool

	// immutable prevents all write operations. Set via WithImmutable, used by
	// snapshot buckets to guarantee they never modify data. This is distinct
	// from the shard-level read-only status (storagestate.StatusReadOnly)
	// checked by isReadOnly().
	immutable bool

	// sequentialAccess hints the kernel (via fadvise) that segment files will
	// be read sequentially. Set via WithSequentialAccess for snapshot buckets.
	sequentialAccess bool
}

// bucketCreator satisfies BucketCreator without being a Bucket itself: a Bucket
// that has not been through NewBucket has no logger, no memtables and no
// segment group, so it must never be handed out as one.
type bucketCreator struct{}

func NewBucketCreator() BucketCreator { return bucketCreator{} }

// NewBucket initializes a new bucket. It either loads the state from disk if
// it exists, or initializes new state.
//
// You do not need to ever call NewBucket() yourself, if you are using a
// [Store]. In this case the [Store] can manage buckets for you, using methods
// such as CreateOrLoadBucket().
// newBucketPostDiskInitHook is a test-only fault-injection point between the
// segment-group init and the rest of NewBucket. Nil in production.
var newBucketPostDiskInitHook func(*Bucket) error

func (bucketCreator) NewBucket(ctx context.Context, dir, rootDir string, logger logrus.FieldLogger,
	metrics *Metrics, compactionCallbacks, flushCallbacks cyclemanager.CycleCallbackGroup,
	opts ...BucketOption,
) (b *Bucket, err error) {
	beforeAll := time.Now()

	// Claim the registry entry BEFORE touching any file: a second open of a
	// still-live bucket (e.g. re-init after a shard teardown failed deep and
	// leaked this bucket open) must be refused up front. Checking last let a
	// doomed re-open run WAL recovery first — deleting the live instance's
	// active WAL, whose buffered writes then flushed into an unlinked inode
	// on shutdown: silent data loss.
	if err := GlobalBucketRegistry.TryAdd(dir); err != nil {
		return nil, err
	}
	var constructed *Bucket // named return b is nil'd by error returns; keep our own handle
	defer func() {
		if err == nil {
			return
		}
		// A failure after newSegmentGroup succeeded leaves mmapped segments
		// and flocked bolt handles behind disk; tear them down before
		// releasing the claim — freeing the slot over live handles re-opens
		// the exact double-open the front claim prevents. If the teardown
		// itself fails, keep the claim: re-open stays refused until restart.
		if constructed != nil && constructed.disk != nil {
			if serr := constructed.disk.shutdown(context.Background()); serr != nil {
				logger.WithField("dir", dir).
					Errorf("close partially initialized bucket: %v — keeping registry claim; re-open refused until restart", serr)
				return
			}
		}
		GlobalBucketRegistry.Remove(dir)
	}()

	defaultMemTableThreshold := uint64(10 * 1024 * 1024)
	defaultWalThreshold := uint64(1024 * 1024 * 1024)
	defaultFlushAfterDirty := FlushAfterDirtyDefault
	// this is not the nicest way of doing this check, but we will make strategy a required parameter in the future on
	// main
	defaultStrategy := unsetStrategy

	b = &Bucket{
		dir:     dir,
		rootDir: rootDir,
		// The actual path of the bucket can change, e.g. on delete, without
		// updating the registry. Keep the registered path (claimed at the top
		// of this function) so shutdown can release the right entry.
		registeredPath:               dir,
		memtableThreshold:            defaultMemTableThreshold,
		walThreshold:                 defaultWalThreshold,
		flushDirtyAfter:              defaultFlushAfterDirty,
		strategy:                     defaultStrategy,
		mmapContents:                 true,
		logger:                       logger,
		metrics:                      metrics,
		useBloomFilter:               true,
		calcCountNetAdditions:        false,
		haltedFlushTimer:             interval.NewBackoffTimer(),
		writeSegmentInfoIntoFileName: false,
		minWalThreshold:              config.DefaultPersistenceMaxReuseWalSize,
	}

	for _, opt := range opts {
		if err := opt(b); err != nil {
			return nil, err
		}
	}

	if b.strategy == unsetStrategy {
		return nil, errors.New("strategy needs to be explicitly set for all buckets")
	}

	if !b.immutable && IsSnapshotDir(dir) {
		return nil, fmt.Errorf("cannot open a snapshot directory (%q) with NewBucket; use NewSnapshotBucket instead", dir)
	}

	if b.memtableResizer != nil {
		b.memtableThreshold = uint64(b.memtableResizer.Initial())
	}

	if b.disableCompaction {
		compactionCallbacks = cyclemanager.NewCallbackGroupNoop()
	}

	constructed = b

	b.desiredStrategy = b.strategy

	metrics.IncBucketInitCountByStrategy(b.strategy)
	metrics.IncBucketInitInProgressByStrategy(b.strategy)

	defer func(strategy string) {
		metrics.DecBucketInitInProgressByStrategy(strategy)

		if err != nil {
			metrics.IncBucketInitFailureCountByStrategy(strategy)
			return
		}

		metrics.ObserveBucketInitDurationByStrategy(strategy, time.Since(beforeAll))
	}(b.strategy)

	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}

	files, _, err := diskio.GetFileWithSizes(dir)
	if err != nil {
		return nil, err
	}

	sg, err := newSegmentGroup(ctx, logger, metrics,
		sgConfig{
			dir:                          dir,
			strategy:                     b.strategy,
			mapRequiresSorting:           b.legacyMapSortingBeforeCompaction,
			monitorCount:                 b.monitorCount,
			mmapContents:                 b.mmapContents,
			keepTombstones:               b.keepTombstones,
			forceCompaction:              b.forceCompaction,
			useBloomFilter:               b.useBloomFilter,
			calcCountNetAdditions:        b.calcCountNetAdditions,
			maxSegmentSize:               b.maxSegmentSize,
			cleanupInterval:              b.segmentsCleanupInterval,
			enableChecksumValidation:     b.enableChecksumValidation,
			keepSegmentsInMemory:         b.keepSegmentsInMemory,
			MinMMapSize:                  b.minMMapSize,
			bm25config:                   b.bm25Config,
			lazyPropertyLengths:          b.lazyPropertyLengths,
			keepLevelCompaction:          b.keepLevelCompaction,
			writeSegmentInfoIntoFileName: b.writeSegmentInfoIntoFileName,
			writeMetadata:                b.writeMetadata,
			sequentialAccess:             b.sequentialAccess,
			shouldSkipKey:                b.shouldSkipKey,
			className:                    b.className,
		}, compactionCallbacks, b, files)
	if err != nil {
		return nil, fmt.Errorf("init disk segments: %w", err)
	}

	b.disk = sg

	if newBucketPostDiskInitHook != nil {
		if err := newBucketPostDiskInitHook(b); err != nil {
			return nil, err
		}
	}

	if b.active == nil {
		b.active, err = b.createNewActiveMemtable()
		if err != nil {
			return nil, err
		}
	}

	id := "bucket/flush/" + b.dir
	b.flushCallbackCtrl = flushCallbacks.Register(id, b.flushAndSwitchIfThresholdsMet)

	b.metrics.TrackStartupBucket(beforeAll)

	return b, nil
}

func (b *Bucket) GetDir() string {
	b.flushLock.RLock()
	defer b.flushLock.RUnlock()
	return b.dir
}

func (b *Bucket) GetRootDir() string {
	return b.rootDir
}

// HasEditOps reports whether this bucket has an edit-ops sidecar (the objects
// bucket).
func (b *Bucket) HasEditOps() bool {
	return b.disk != nil && b.disk.editOps != nil
}

// RegisterEditOp records an in-place edit op (e.g. drop-vector) and snapshots the
// current segments as pending for the compaction/cleanup transformer to rewrite.
// It flushes the active memtable first so in-memory data is captured. Idempotent:
// an op that already has a snapshot (resume) skips the flush and the snapshot,
// keeping the recorded pending set as the progress marker; it only requeues
// segments an earlier round quarantined, granting them a fresh retry budget.
func (b *Bucket) RegisterEditOp(opID string, desc OpDescriptor) error {
	if !b.HasEditOps() {
		return fmt.Errorf("edit ops not enabled for this bucket")
	}
	// Hold flushAndSwitchMu across [flag check -> flush -> snapshot]:
	// Shutdown sets shuttingDown and then passes a barrier on this mutex, so
	// either this registration observed the flag and refused, or it completes
	// its flush AND snapshot before the shutdown proceeds — a shutdown flush
	// can never land between our flush and our snapshot (a segment outside
	// the pending set is exactly the resurrection this guard exists to stop).
	b.flushAndSwitchMu.Lock()
	defer b.flushAndSwitchMu.Unlock()
	// flushAndSwitchLocked skips FlushAndSwitch's read-only guard; re-check
	// here — arming triggers a flush, the exact write StatusReadOnly blocks.
	if err := b.readOnlyErr(); err != nil {
		return err
	}
	if b.shuttingDown.Load() {
		// Arming against a closing bucket is unsound: the flush + segment
		// snapshot race the dismantling, and an empty or partial snapshot
		// would let the drop record completion without stripping. Fail the
		// unit instead; a later round re-arms on a live instance.
		return fmt.Errorf("bucket is shutting down; refusing to register edit op %q", opID)
	}
	snapshotted, err := b.disk.editOps.HasPendingSnapshot(opID)
	if err != nil {
		return err
	}
	if snapshotted {
		// Resume: the recorded pending set IS the progress, so no new snapshot
		// and no flush. A re-arm marks a new round, though, so segments
		// quarantined by an earlier round get a fresh retry budget — otherwise
		// a single exhausted budget would wedge the drop permanently (the op
		// and its quarantine rows outlive FAILED rounds by design).
		return b.disk.requeueQuarantinedEditOps(opID)
	}
	if err := b.flushAndSwitchLocked(); err != nil {
		return fmt.Errorf("flush before edit-op snapshot: %w", err)
	}
	return b.disk.registerEditOpAndSnapshot(opID, desc)
}

// EditOpPending returns the segment IDs still awaiting rewrite for opID. An empty
// result means the operation has been fully applied on this bucket.
func (b *Bucket) EditOpPending(opID string) ([]string, error) {
	if !b.HasEditOps() {
		return nil, fmt.Errorf("edit ops not enabled for this bucket")
	}
	return b.disk.editOps.Pending(opID)
}

// DeleteEditOpIfDrained removes opID and its bookkeeping from the sidecar
// once this bucket's work for it is finished for good: task success
// (delivered as SWAPPING or a replayed FINISHED), or a terminal round whose
// unit here COMPLETED (the shard enters the epoch's inherited coverage, so no
// later round returns). A lingering op would re-decode every object on every
// future compaction and — once the dropped name is freed for re-creation —
// strip the re-created vector (the dropped-target fence is the runtime guard
// against exactly that). The delete is gated, in one transaction, on the op
// having no pending and no quarantined rows — the caller's "this op is
// drained" belief is verified atomically instead of across separate reads,
// because a pending row may be unstripped data's only cover. Reports whether
// the op was deleted and, when kept, the row counts that vetoed it.
// Idempotent; this is the ONLY delete the provider gets — an unguarded
// variant existed and was removed so it cannot be reached for.
func (b *Bucket) DeleteEditOpIfDrained(opID string) (deleted bool, pending, quarantined int, err error) {
	if !b.HasEditOps() {
		return false, 0, 0, fmt.Errorf("edit ops not enabled for this bucket")
	}
	return b.disk.editOps.DeleteOpIfDrained(opID)
}

// EditOpsHaveRows reports whether ANY edit op on this bucket still has
// pending or quarantined segments — i.e. an in-place edit (drop-vector strip)
// is mid-flight on this bucket's data. Replica movement consults this: the
// sidecar is excluded from copied file lists, so moving a bucket with rows
// would land the unstripped bytes at the target with no record they exist.
func (b *Bucket) EditOpsHaveRows() (bool, error) {
	if !b.HasEditOps() {
		return false, nil
	}
	pending, err := b.disk.editOps.AllPending()
	if err != nil {
		return false, err
	}
	if len(pending) > 0 {
		return true, nil
	}
	quarantined, err := b.disk.editOps.Quarantined()
	if err != nil {
		return false, err
	}
	return len(quarantined) > 0, nil
}

// EditOpQuarantined returns the segment IDs the cleanup driver quarantined
// (retry budget exhausted) for opID; they still carry the dropped data, so the
// caller must fail rather than treat empty pending as success.
func (b *Bucket) EditOpQuarantined(opID string) ([]string, error) {
	if !b.HasEditOps() {
		return nil, fmt.Errorf("edit ops not enabled for this bucket")
	}
	return b.disk.editOps.QuarantinedFor(opID)
}

func (b *Bucket) GetStrategy() string {
	return b.strategy
}

func (b *Bucket) GetDesiredStrategy() string {
	return b.desiredStrategy
}

func (b *Bucket) GetSecondaryIndices() uint16 {
	return b.secondaryIndices
}

func (b *Bucket) GetStatus() storagestate.Status {
	b.statusLock.RLock()
	defer b.statusLock.RUnlock()

	return b.status
}

func (b *Bucket) GetMemtableThreshold() uint64 {
	return b.memtableThreshold
}

func (b *Bucket) GetWalThreshold() uint64 {
	return b.walThreshold
}

func (b *Bucket) GetFlushCallbackCtrl() cyclemanager.CycleCallbackCtrl {
	return b.flushCallbackCtrl
}

func (b *Bucket) IterateObjects(ctx context.Context, f func(object *storobj.Object) error) error {
	cursor := b.Cursor()
	defer cursor.Close()

	i := 0

	className, err := b.ClassName()
	if err != nil {
		return fmt.Errorf("getting bucket class name: %w", err)
	}
	for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
		obj, err := storobj.FromBinaryDisk(v, className)
		if err != nil {
			return fmt.Errorf("cannot unmarshal object %d, %w", i, err)
		}
		if err := f(obj); err != nil {
			return fmt.Errorf("callback on object '%d' failed: %w", obj.DocID, err)
		}

		i++
	}

	return nil
}

// pauseCompaction / resumeCompaction are ref-counted at the bucket level so
// snapshot, ApplyToObjectDigests, and runtime-reindex callers share one pause
// (weaviate/0-weaviate-issues#251 + weaviate/weaviate#11486 review).
func (b *Bucket) pauseCompaction(ctx context.Context) error {
	b.pauseCompactionMu.Lock()
	defer b.pauseCompactionMu.Unlock()

	b.pauseCompactionCount++
	if b.pauseCompactionCount > 1 {
		return nil
	}
	if err := b.disk.pauseCompaction(ctx); err != nil {
		b.pauseCompactionCount--
		return err
	}
	b.doStartPauseTimer()
	return nil
}

func (b *Bucket) resumeCompaction(ctx context.Context) error {
	b.pauseCompactionMu.Lock()
	defer b.pauseCompactionMu.Unlock()

	if b.pauseCompactionCount == 0 {
		return nil
	}
	if b.pauseCompactionCount > 1 {
		b.pauseCompactionCount--
		return nil
	}
	if err := b.disk.resumeCompaction(ctx); err != nil {
		return err
	}
	b.doStopPauseTimer()
	b.pauseCompactionCount--
	return nil
}

// ApplyToObjectDigests applies f to every live object (memtable and disk) once per
// UUID, stopping on the first error. Dedup is keyed by UUID, not docID (a
// vector-changed update reuses the UUID under a new docID); memtable-only tombstones
// suppress their stale on-disk value. afterInMemCallback fires once the in-memory
// scan is done.
//
// The on-disk cursor is created while the in-mem cursor holds the flush lock, so both
// snapshots are taken at a single consistent point with no flush in between. Compaction
// is not paused: the on-disk cursor pins its segments via reference counting.
func (b *Bucket) ApplyToObjectDigests(ctx context.Context,
	afterInMemCallback func(), f func(uuidBytes []byte, updateTime int64) error,
) error {
	var onDiskCursor *CursorReplace

	inmemProcessedUUIDs := make(map[[16]byte]struct{})

	// note: read-write access to active and flushing memtable will be blocked only during the scope of this inner function
	err := func() error {
		defer afterInMemCallback()

		inMemCursor := b.CursorInMemWithTombstones()
		defer inMemCursor.Close()

		// created under the in-mem cursor's flush lock, so it is consistent with the
		// memtable view: no flush can run between the two snapshots.
		// Digest mode: only the header is read below, so skip the full value copy.
		onDiskCursor = b.CursorOnDiskDigest(storobj.MarshallerV1HeaderLen)

		for k, v := inMemCursor.First(); k != nil; k, v = inMemCursor.Next() {
			select {
			case <-ctx.Done():
				return ctx.Err()
			default:
			}

			if len(k) != 16 {
				return fmt.Errorf("invalid object uuid '%x': expected 16 bytes, got %d", k, len(k))
			}

			// record every UUID (live or tombstone) so the disk pass skips its stale value
			inmemProcessedUUIDs[[16]byte(k)] = struct{}{}

			if v == nil {
				continue // tombstone: recorded, not folded
			}

			_, updateTime, err := storobj.DocIDAndTimeFromBinary(v)
			if err != nil {
				return fmt.Errorf("cannot unmarshal object '%x': %w", k, err)
			}
			if err := f(k, updateTime); err != nil {
				return fmt.Errorf("callback on object '%x' failed: %w", k, err)
			}
		}

		return nil
	}()
	if onDiskCursor != nil {
		defer onDiskCursor.Close()
	}
	if err != nil {
		return err
	}

	for k, v := onDiskCursor.First(); k != nil; k, v = onDiskCursor.Next() {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		if len(k) != 16 {
			return fmt.Errorf("invalid object uuid '%x': expected 16 bytes, got %d", k, len(k))
		}

		if _, ok := inmemProcessedUUIDs[[16]byte(k)]; ok {
			continue
		}

		_, updateTime, err := storobj.DocIDAndTimeFromBinary(v)
		if err != nil {
			return fmt.Errorf("cannot unmarshal object '%x': %w", k, err)
		}
		if err := f(k, updateTime); err != nil {
			return fmt.Errorf("callback on object '%x' failed: %w", k, err)
		}
	}

	return nil
}

func (b *Bucket) IterateMapObjects(ctx context.Context, f func([]byte, []byte, []byte, bool) error) error {
	cursor, err := b.MapCursor()
	if err != nil {
		return fmt.Errorf("create map cursor: %w", err)
	}
	defer cursor.Close()

	for kList, vList := cursor.First(ctx); kList != nil; kList, vList = cursor.Next(ctx) {
		for _, v := range vList {
			if err := f(kList, v.Key, v.Value, v.Tombstone); err != nil {
				return fmt.Errorf("callback on object '%v' failed: %w", v, err)
			}
		}
	}

	return ctx.Err()
}

func (b *Bucket) SetMemtableThreshold(size uint64) {
	b.memtableThreshold = size
}

type BucketConsistentView struct {
	Active   memtable
	Flushing memtable
	Disk     []Segment
	release  func()
	Bucket   *Bucket
}

func (cv BucketConsistentView) ReleaseView() {
	cv.release()
}

// GetConsistentView returns a consistent view of the bucket that can be used
// for multiple reads without acquiring locks for each read. The caller must
// call ReleaseView() on the returned view when done to avoid blocking compactions.
func (b *Bucket) GetConsistentView() BucketConsistentView {
	beforeFlushLock := time.Now()
	b.flushLock.RLock()
	defer b.flushLock.RUnlock()

	if duration := time.Since(beforeFlushLock); duration > 100*time.Millisecond {
		b.logger.WithFields(logrus.Fields{
			"duration": duration,
			"action":   "lsm_bucket_get_acquire_flush_lock",
		}).Debug("Waited more than 100ms to obtain a flush lock during get")
	}

	diskSegments, releaseDiskSegments := b.disk.getConsistentViewOfSegments()
	return BucketConsistentView{
		Active:   b.active,
		Flushing: b.flushing,
		Disk:     diskSegments,
		release:  releaseDiskSegments,
		Bucket:   b,
	}
}

// viewMemtables returns the memtables from a view and the count of valid memtables.
// This avoids allocating a slice on every call by returning a fixed-size array.
func viewMemtables(view BucketConsistentView) ([2]memtable, int) {
	if view.Flushing != nil {
		return [2]memtable{view.Active, view.Flushing}, 2
	}
	return [2]memtable{view.Active, nil}, 1
}

// Get retrieves the single value for the given key.
//
// Get is specific to ReplaceStrategy and cannot be used with any of the other
// strategies. Use [Bucket.SetList] or [Bucket.MapList] instead.
//
// Get uses the regular or "primary" key for an object. If a bucket has
// secondary indexes, use [Bucket.GetBySecondary] to retrieve an object using
// its secondary key
func (b *Bucket) Get(key []byte) ([]byte, error) {
	v, err := b.get(key)
	if err != nil && lsmkv.IsDeletedOrNotFound(err) {
		return nil, nil
	}
	return v, err
}

func (b *Bucket) GetErrDeleted(key []byte) ([]byte, error) {
	return b.get(key)
}

// Exists checks whether the given key exists and is not deleted without reading
// the full value.
//
// Exists is specific to ReplaceStrategy.
func (b *Bucket) Exists(key []byte) (bool, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	err := b.existsWithConsistentView(key, view)
	if err != nil {
		if lsmkv.IsDeletedOrNotFound(err) {
			return false, nil
		}
		return false, err
	}
	return true, nil
}

func (b *Bucket) get(key []byte) ([]byte, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	return b.getWithConsistentView(key, view)
}

func (b *Bucket) getWithConsistentView(key []byte, view BucketConsistentView) ([]byte, error) {
	memtables, count := viewMemtables(view)

	for i := range count {
		v, err := b.getFromMemtable(key, memtables[i], memtableNames[i])
		if err == nil {
			// item found and no error, return and stop searching, since the strategy
			// is replace
			return v, nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			// deleted in the mem-table (which is always the latest) means we don't
			// have to check the disk segments, return nil now
			return nil, err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return nil, fmt.Errorf("Bucket::get() %q: %w", memtableNames[i], err)
		}
	}

	return b.getFromSegmentGroup(key, view.Disk)
}

// existsWithConsistentView checks if a key exists and is not deleted, without reading the full value.
// Returns nil if the key exists, lsmkv.NotFound if not found, or lsmkv.Deleted if tombstoned.
// This is more efficient than getWithConsistentView() when only existence check is needed.
func (b *Bucket) existsWithConsistentView(key []byte, view BucketConsistentView) error {
	return b.existsWithConsistentViewUpTo(key, 0, view)
}

// existsWithConsistentView checks if a key exists and is not deleted, without reading the full value.
// Returns nil if the key exists, lsmkv.NotFound if not found, or lsmkv.Deleted if tombstoned.
// This is more efficient than getWithConsistentView() when only existence check is needed.
func (b *Bucket) existsWithConsistentViewUpTo(key []byte, segIdx int, view BucketConsistentView) error {
	memtables, count := viewMemtables(view)

	for i := range count {
		err := memtables[i].exists(key)
		if err == nil {
			// item found and no error, return and stop searching, since the strategy
			// is replace
			return nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			// deleted in the mem-table (which is always the latest) means we don't
			// have to check the disk segments, return now
			return err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return fmt.Errorf("Bucket::exists() %q: %w", memtableNames[i], err)
		}
	}

	return b.disk.existsWithSegmentListUpTo(key, segIdx, view.Disk)
}

// GetBySecondary retrieves an object using one of its secondary keys. A bucket
// can have an infinite number of secondary keys. Specify the secondary key
// position as the first argument.
//
// A real-life example of secondary keys is the Weaviate object store. Objects
// are stored with the user-facing ID as their primary key and with the doc-id
// (an ever-increasing uint64) as the secondary key.
//
// Similar to [Bucket.Get], GetBySecondary is limited to ReplaceStrategy. No
// equivalent exists for Set and Map, as those do not support secondary
// indexes.
func (b *Bucket) GetBySecondary(ctx context.Context, pos int, key []byte) ([]byte, error) {
	bytes, _, err := b.GetBySecondaryWithBuffer(ctx, pos, key, nil)
	return bytes, err
}

// GetBySecondaryWithBuffer is like [Bucket.GetBySecondary], but also takes a
// buffer. It's in the response of the caller to pool the buffer, since the
// bucket does not know when the caller is done using it. The return bytes will
// likely point to the same memory that's part of the buffer. However, if the
// buffer is to small, a larger buffer may also be returned (second arg).
//
// Similar to [Bucket.Get], GetBySecondaryWithBuffer is limited to ReplaceStrategy. No
// equivalent exists for Set and Map, as those do not support secondary
// indexes.
func (b *Bucket) GetBySecondaryWithBuffer(ctx context.Context, pos int, seckey []byte, buffer []byte) ([]byte, []byte, error) {
	v, allocBuf, err := b.getBySecondary(ctx, pos, seckey, buffer)
	if err != nil && lsmkv.IsDeletedOrNotFound(err) {
		return nil, buffer, nil
	}
	return v, allocBuf, err
}

// GetBySecondaryWithBufferAndView is like [Bucket.GetBySecondaryWithBuffer], but uses
// an existing consistent view instead of acquiring a new one. This is useful for
// batch operations where the same view can be reused across multiple lookups to
// reduce lock contention.
func (b *Bucket) GetBySecondaryWithBufferAndView(ctx context.Context, pos int, seckey []byte, buffer []byte, view BucketConsistentView) ([]byte, []byte, error) {
	v, allocBuf, err := b.getBySecondaryWithView(ctx, pos, seckey, buffer, view)
	if err != nil && lsmkv.IsDeletedOrNotFound(err) {
		return nil, buffer, nil
	}
	return v, allocBuf, err
}

// SecondaryViewLookup acquires a single consistent view and returns a lookup
// function bound to it, together with a release function. Reusing one view
// across many secondary-key lookups avoids acquiring a fresh view (flush lock,
// segment snapshot, and per-segment refcount churn) for every lookup. The
// returned lookup is safe for concurrent use; call release exactly once, after
// all lookups are done.
func (b *Bucket) SecondaryViewLookup() (
	func(ctx context.Context, pos int, seckey, buffer []byte) ([]byte, []byte, error),
	func(),
) {
	view := b.GetConsistentView()
	lookup := func(ctx context.Context, pos int, seckey, buffer []byte) ([]byte, []byte, error) {
		return b.GetBySecondaryWithBufferAndView(ctx, pos, seckey, buffer, view)
	}
	return lookup, view.ReleaseView
}

func (b *Bucket) getBySecondary(ctx context.Context, pos int, seckey []byte, buffer []byte) ([]byte, []byte, error) {
	beforeAll := time.Now()
	view := b.GetConsistentView()
	defer view.ReleaseView()
	tookView := time.Since(beforeAll)

	return b.getBySecondaryCore(ctx, pos, seckey, buffer, view, tookView, "lsm_get_by_secondary")
}

func (b *Bucket) getBySecondaryWithView(ctx context.Context, pos int, seckey []byte, buffer []byte, view BucketConsistentView) ([]byte, []byte, error) {
	return b.getBySecondaryCore(ctx, pos, seckey, buffer, view, 0, "lsm_get_by_secondary_with_view")
}

func (b *Bucket) getBySecondaryCore(ctx context.Context, pos int, seckey []byte, buffer []byte, view BucketConsistentView, viewTiming time.Duration, logKey string) ([]byte, []byte, error) {
	if pos >= int(b.secondaryIndices) {
		return nil, nil, fmt.Errorf("no secondary index at pos %d", pos)
	}

	beforeAll := time.Now()
	memtables, count := viewMemtables(view)

	var memtablesTook [2]time.Duration
	for i := range count {
		beforeMemtable := time.Now()
		k, v, err := b.getBySecondaryFromMemtable(pos, seckey, memtables[i], memtableNames[i])
		memtablesTook[i] = time.Since(beforeMemtable)
		if err == nil {
			if i == 1 {
				// if the item is found in the flushing memtable,
				// we need to check if it exists in the primary key of the active memtable,
				// to avoid returning an item that was deleted and re-added with the same secondary key
				// - exists(k) == nil: a newer version of the doc exists, return lsmkv.NotFound
				// - exists(k) == lsmkv.Deleted: the doc was deleted and not re-added, return lsmkv.Deleted
				// - exists(k) == any other error != lsmkv.NotFound: return the error, since we can't be sure about the state of the doc
				// - "default" exists(k) == lsmkv.NotFound: the doc was not found, so we can return the item found in the flushing memtable
				err = memtables[0].exists(k)
				if err == nil {
					return nil, nil, lsmkv.NotFound
				} else if errors.Is(err, lsmkv.Deleted) {
					return nil, nil, err
				} else if !errors.Is(err, lsmkv.NotFound) {
					return nil, nil, fmt.Errorf("Bucket::getBySecondary() %q: %w", memtableNames[0], err)
				}
			}
			// item found and no error, return and stop searching, since the strategy
			// is replace
			return v, buffer, nil
		}
		if errors.Is(err, lsmkv.Deleted) {
			// deleted in the mem-table (which is always the latest) means we don't
			// have to check the disk segments, return nil now
			return nil, nil, err
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return nil, nil, fmt.Errorf("Bucket::getBySecondary() %q: %w", memtableNames[i], err)
		}
	}

	beforeSegments := time.Now()
	priKey, v, allocBuf, secSegIndex, err := b.getBySecondaryFromSegmentGroup(pos, seckey, buffer, view.Disk)
	if err != nil {
		return nil, nil, err
	}
	segmentsTook := time.Since(beforeSegments)

	// additional validation to ensure the primary key has not been marked as deleted
	beforeReCheck := time.Now()

	// Check if a later version of the document is accesible by primary key.
	// Only check up to, not including, the segment (secSegIndex+1) where the item was found,
	// to avoid disk access for items that were deleted and re-added with the same secondary key in a later segment
	err = b.existsWithConsistentViewUpTo(priKey, secSegIndex+1, view)

	// if it exists on a later segment for priKey (err == nil), it means it was updated
	// thus, we return lsmkv.NotFound to avoid returning stale data.
	if err == nil {
		return nil, nil, lsmkv.NotFound
	}

	// if there is an error other than not found, we propagate the err
	if !errors.Is(err, lsmkv.NotFound) {
		return nil, nil, err
	}

	recheckTook := time.Since(beforeReCheck)

	helpers.AnnotateSlowQueryLogAppend(ctx, logKey, BucketSlowLogEntry{
		View:             viewTiming,
		ActiveMemtable:   memtablesTook[0],
		FlushingMemtable: memtablesTook[1],
		Segments:         segmentsTook,
		Recheck:          recheckTook,
		Total:            time.Since(beforeAll),
	})

	return v, allocBuf, nil
}

func (b *Bucket) getFromMemtable(key []byte, memtable memtable, component string) (v []byte, err error) {
	op := "get"

	start := time.Now()
	b.metrics.IncBucketReadOpCountByComponent(op, component)
	b.metrics.IncBucketReadOpOngoingByComponent(op, component)

	defer func() {
		if duration := time.Since(start); duration > 100*time.Millisecond {
			b.logger.WithFields(logrus.Fields{
				"duration": duration,
				"action":   fmt.Sprintf("lsm_bucket_get_%s", component),
			}).Debug("Waited more than 100ms to retrieve object from memtable")
		}

		b.metrics.DecBucketReadOpOngoingByComponent(op, component)
		if err != nil && !lsmkv.IsDeletedOrNotFound(err) {
			b.metrics.IncBucketReadOpFailureCountByComponent(op, component)
			return
		}
		b.metrics.ObserveBucketReadOpDurationByComponent(op, component, time.Since(start))
	}()

	return memtable.get(key)
}

func (b *Bucket) getBySecondaryFromMemtable(pos int, seckey []byte, memtable memtable, component string,
) (k []byte, v []byte, err error) {
	op := "getbysecondary"

	start := time.Now()
	b.metrics.IncBucketReadOpCountByComponent(op, component)
	b.metrics.IncBucketReadOpOngoingByComponent(op, component)

	defer func() {
		if duration := time.Since(start); duration > 100*time.Millisecond {
			b.logger.WithFields(logrus.Fields{
				"duration": duration,
				"action":   fmt.Sprintf("lsm_bucket_getbysecondary_%s", component),
			}).Debug("Waited more than 100ms to retrieve object from memtable")
		}

		b.metrics.DecBucketReadOpOngoingByComponent(op, component)
		if err != nil && !lsmkv.IsDeletedOrNotFound(err) {
			b.metrics.IncBucketReadOpFailureCountByComponent(op, component)
			return
		}
		b.metrics.ObserveBucketReadOpDurationByComponent(op, component, time.Since(start))
	}()

	return memtable.getBySecondary(pos, seckey)
}

func (b *Bucket) getFromSegmentGroup(key []byte, segments []Segment) (v []byte, err error) {
	op := "get"
	component := "segment_group"

	start := time.Now()
	b.metrics.IncBucketReadOpCountByComponent(op, component)
	b.metrics.IncBucketReadOpOngoingByComponent(op, component)

	defer func() {
		b.metrics.DecBucketReadOpOngoingByComponent(op, component)
		if err != nil && !lsmkv.IsDeletedOrNotFound(err) {
			b.metrics.IncBucketReadOpFailureCountByComponent(op, component)
			return
		}
		b.metrics.ObserveBucketReadOpDurationByComponent(op, component, time.Since(start))
	}()

	return b.disk.getWithSegmentList(key, segments)
}

func (b *Bucket) getBySecondaryFromSegmentGroup(pos int, seckey []byte, buffer []byte, segments []Segment,
) (k, v []byte, buf []byte, segmentId int, err error) {
	op := "getbysecondary"
	component := "segment_group"

	start := time.Now()
	b.metrics.IncBucketReadOpCountByComponent(op, component)
	b.metrics.IncBucketReadOpOngoingByComponent(op, component)

	defer func() {
		b.metrics.DecBucketReadOpOngoingByComponent(op, component)
		if err != nil && !lsmkv.IsDeletedOrNotFound(err) {
			b.metrics.IncBucketReadOpFailureCountByComponent(op, component)
			return
		}
		b.metrics.ObserveBucketReadOpDurationByComponent(op, component, time.Since(start))
	}()

	return b.disk.getBySecondaryWithSegmentList(pos, seckey, buffer, segments)
}

// SetList returns all Set entries for a given key.
//
// SetList is specific to the Set Strategy, for Map use [Bucket.MapList], and
// for Replace use [Bucket.Get].
func (b *Bucket) SetList(key []byte) ([][]byte, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	return b.setListFromConsistentView(view, key)
}

func (b *Bucket) setListFromConsistentView(view BucketConsistentView, key []byte) ([][]byte, error) {
	var out []value

	v, err := b.disk.getCollection(key, view.Disk)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}
	out = v

	if view.Flushing != nil {
		v, err = view.Flushing.getCollection(key)
		if err != nil && !errors.Is(err, lsmkv.NotFound) {
			return nil, err
		}
		out = append(out, v...)

	}

	v, err = view.Active.getCollection(key)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}
	if len(v) > 0 {
		// skip the expensive append operation if there was no memtable
		out = append(out, v...)
	}

	return newSetDecoder().Do(out), nil
}

// Put creates or replaces a single value for a given key.
//
//	err := bucket.Put([]byte("my_key"), []byte("my_value"))
//	 if err != nil {
//		/* do something */
//	}
//
// If a bucket has a secondary index configured, you can also specify one or
// more secondary keys, like so:
//
//	err := bucket.Put([]byte("my_key"), []byte("my_value"),
//		WithSecondaryKey(0, []byte("my_alternative_key")),
//	)
//	 if err != nil {
//		/* do something */
//	}
//
// Put is limited to ReplaceStrategy, use [Bucket.SetAdd] for Set or
// [Bucket.MapSet] and [Bucket.MapSetMulti].
func (b *Bucket) Put(key, value []byte, opts ...SecondaryKeyOption) (err error) {
	start := time.Now()
	b.metrics.IncBucketWriteOpCount("put")
	b.metrics.IncBucketWriteOpOngoing("put")
	defer func() {
		b.metrics.DecBucketWriteOpOngoing("put")
		if err != nil {
			b.metrics.IncBucketWriteOpFailureCount("put")
			return
		}
		b.metrics.ObserveBucketWriteOpDuration("put", time.Since(start))
	}()

	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.put(key, value, opts...)
}

// getActiveMemtableForWrite returns the active memtable and uses reference
// counting to avoid holding a lock during the entire duration of the write.
//
// It is safe to switch the memtable from active to flushing while a writer
// is ongoing, because the actual flush only happens once the writer count
// has dropped to zero. Essentially the switch just switches pointers, but we
// will always work on the same pointer for the duration of the write.
func (b *Bucket) getActiveMemtableForWrite() (active memtable, release func(), err error) {
	if err := b.readOnlyErr(); err != nil {
		return nil, nil, err
	}

	b.flushLock.RLock()
	defer b.flushLock.RUnlock()

	active = b.active
	active.incWriterCount()

	release = func() {
		active.decWriterCount()
	}

	return active, release, nil
}

// SetAdd adds one or more Set-Entries to a Set for the given key. SetAdd is
// entirely agnostic of existing entries, it acts as append-only. This also
// makes it agnostic of whether the key already exists or not.
//
// Example to add two entries to a set:
//
//	err := bucket.SetAdd([]byte("my_key"), [][]byte{
//		[]byte("one-set-element"), []byte("another-set-element"),
//	})
//	if err != nil {
//		/* do something */
//	}
//
// SetAdd is specific to the Set strategy. For Replace, use [Bucket.Put], for
// Map use either [Bucket.MapSet] or [Bucket.MapSetMulti].
func (b *Bucket) SetAdd(key []byte, values [][]byte) error {
	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.append(key, newSetEncoder().Do(values))
}

// SetDeleteSingle removes one Set element from the given key. Note that LSM
// stores are append only, thus internally this action appends a tombstone. The
// entry will not be removed until a compaction has run, and even then a
// compaction does not guarantee the removal of the data right away. This is
// because an entry could have been created in an older segment than those
// present in the compaction. This can be seen as an implementation detail,
// unless the caller expects to free disk space by calling this method. Such
// freeing is not guaranteed.
//
// SetDeleteSingle is specific to the Set Strategy. For Replace, you can use
// [Bucket.Delete] to delete the entire row, for Maps use [Bucket.MapDeleteKey]
// to delete a single map entry.
func (b *Bucket) SetDeleteSingle(key []byte, valueToDelete []byte) error {
	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.append(key, []value{
		{
			value:     valueToDelete,
			tombstone: true,
		},
	})
}

// WasDeleted determines if an object used to exist in the LSM store
//
// There are 3 different locations that we need to check for the key
// in this order: active memtable, flushing memtable, and disk
// segment
func (b *Bucket) WasDeleted(key []byte) (bool, time.Time, error) {
	if !b.keepTombstones {
		return false, time.Time{}, fmt.Errorf("Bucket requires option `keepTombstones` set to check deleted keys")
	}

	if _, err := b.get(key); err != nil {
		if errors.Is(err, lsmkv.Deleted) {
			var errDeleted lsmkv.ErrDeleted
			if errors.As(err, &errDeleted) {
				return true, errDeleted.DeletionTime(), nil
			}
			return true, time.Time{}, nil
		}
		if !errors.Is(err, lsmkv.NotFound) {
			return false, time.Time{}, fmt.Errorf("unsupported bucket error: %w", err)
		}
	}
	return false, time.Time{}, nil
}

type MapListOptionConfig struct {
	acceptDuplicates           bool
	legacyRequireManualSorting bool
	skipPropertyLengths        bool
}

type MapListOption func(c *MapListOptionConfig)

func MapListAcceptDuplicates() MapListOption {
	return func(c *MapListOptionConfig) {
		c.acceptDuplicates = true
	}
}

func MapListLegacySortingRequired() MapListOption {
	return func(c *MapListOptionConfig) {
		c.legacyRequireManualSorting = true
	}
}

// MapListSkipPropertyLengths skips loading an inverted segment's per-document
// property length map, for callers that read only keys (e.g. filter resolution).
func MapListSkipPropertyLengths() MapListOption {
	return func(c *MapListOptionConfig) {
		c.skipPropertyLengths = true
	}
}

// MapList returns all map entries for a given row key. The order of map pairs
// has no specific meaning. For efficient merge operations, pair entries are
// stored sorted on disk, however that is an implementation detail and not a
// caller-facing guarantee.
//
// MapList is specific to the Map strategy, for Sets use [Bucket.SetList], for
// Replace use [Bucket.Get].
func (b *Bucket) MapList(ctx context.Context, key []byte, cfgs ...MapListOption) ([]MapPair, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	return b.mapListFromConsistentView(ctx, view, key, cfgs...)
}

func (b *Bucket) mapListFromConsistentView(ctx context.Context, view BucketConsistentView,
	key []byte, cfgs ...MapListOption,
) ([]MapPair, error) {
	c := MapListOptionConfig{}
	for _, cfg := range cfgs {
		cfg(&c)
	}

	entriesPerSegment := [][]MapPair{}
	// before := time.Now()
	plists, segmentsDisk, err := b.disk.getCollectionAndSegments(ctx, key, view.Disk)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}
	// segmentsDisk would be the same as view.Segments on StrategyInverted, but
	// differs on StrategyMapCollection where we would only contain segments that
	// have the key.

	allTombstones, err := b.loadAllTombstones(view)
	if err != nil {
		return nil, err
	}

	for i, plist := range plists {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}

		segmentStrategy := segmentsDisk[i].getStrategy()

		var propLengths propLengthsView
		if segmentStrategy == segmentindex.StrategyInverted && !c.skipPropertyLengths {
			propLengths, err = segmentsDisk[i].propLengthsView()
			if err != nil {
				return nil, err
			}
		}

		segmentDecoded := make([]MapPair, len(plist))
		for j, v := range plist {
			// Inverted segments have a slightly different internal format
			// and separate property lengths that need to be read.
			if segmentStrategy == segmentindex.StrategyInverted {
				if err := segmentDecoded[j].FromBytesInverted(v.value, false); err != nil {
					return nil, err
				}
				docId := binary.BigEndian.Uint64(segmentDecoded[j].Key[:8])
				// check if there are any tombstones between the i and len(disk) segments
				for _, tombstones := range allTombstones[i+1:] {
					if tombstones != nil && tombstones.Contains(docId) {
						segmentDecoded[j].Tombstone = true
						break
					}
				}
				// put the property length in the value from the "external" property lengths
				binary.LittleEndian.PutUint32(segmentDecoded[j].Value[4:], math.Float32bits(float32(propLengths.get(docId))))

			} else {
				if err := segmentDecoded[j].FromBytes(v.value, false); err != nil {
					return nil, err
				}
				// Read "broken" tombstones with length 12 but a non-tombstone value
				// Related to Issue #4125
				// TODO: Remove the extra check, as it may interfere future in-disk format changes
				segmentDecoded[j].Tombstone = v.tombstone || len(v.value) == 12
			}
		}
		if len(segmentDecoded) > 0 {
			entriesPerSegment = append(entriesPerSegment, segmentDecoded)
		}
	}

	// fmt.Printf("--map-list: get all disk segments took %s\n", time.Since(before))

	// before = time.Now()
	// fmt.Printf("--map-list: append all disk segments took %s\n", time.Since(before))

	if view.Flushing != nil {
		v, err := view.Flushing.getMap(key)
		if err != nil && !errors.Is(err, lsmkv.NotFound) {
			return nil, err
		}
		if len(v) > 0 {
			entriesPerSegment = append(entriesPerSegment, v)
		}
	}

	// before = time.Now()
	v, err := view.Active.getMap(key)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}
	if len(v) > 0 {
		entriesPerSegment = append(entriesPerSegment, v)
	}
	// fmt.Printf("--map-list: get all active segments took %s\n", time.Since(before))

	// before = time.Now()
	// defer func() {
	// 	fmt.Printf("--map-list: run decoder took %s\n", time.Since(before))
	// }()

	if c.legacyRequireManualSorting {
		// Sort to support segments which were stored in an unsorted fashion
		for i := range entriesPerSegment {
			sort.Slice(entriesPerSegment[i], func(a, b int) bool {
				return bytes.Compare(entriesPerSegment[i][a].Key, entriesPerSegment[i][b].Key) == -1
			})
		}
	}

	return newSortedMapMerger().do(ctx, entriesPerSegment)
}

func (b *Bucket) loadAllTombstones(view BucketConsistentView) ([]*sroar.Bitmap, error) {
	hasTombstones := false
	allTombstones := make([]*sroar.Bitmap, len(view.Disk)+2)
	for i, segment := range view.Disk {
		if segment.getStrategy() == segmentindex.StrategyInverted {
			tombstones, err := segment.ReadOnlyTombstones()
			if err != nil {
				return nil, err
			}
			allTombstones[i] = tombstones
			hasTombstones = true
		}
	}
	if hasTombstones {
		if view.Flushing != nil {
			tombstones, err := view.Flushing.ReadOnlyTombstones()
			if err != nil {
				return nil, err
			}
			allTombstones[len(view.Disk)] = tombstones
		}

		tombstones, err := view.Active.ReadOnlyTombstones()
		if err != nil {
			return nil, err
		}
		allTombstones[len(view.Disk)+1] = tombstones
	}
	return allTombstones, nil
}

// MapSet writes one [MapPair] into the map for the given row key. It is
// agnostic of whether the row key already exists, as well as agnostic of
// whether the map key already exists. In both cases it will create the entry
// if it does not exist or override if it does.
//
// Example to add a new MapPair:
//
//	pair := MapPair{Key: []byte("Jane"), Value: []byte("Backend")}
//	err := bucket.MapSet([]byte("developers"), pair)
//	if err != nil {
//		/* do something */
//	}
//
// MapSet is specific to the Map Strategy, for Replace use [Bucket.Put], and for Set use [Bucket.SetAdd] instead.
func (b *Bucket) MapSet(rowKey []byte, kv MapPair) error {
	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.appendMapSorted(rowKey, kv)
}

// MapSetMulti is the same as [Bucket.MapSet], except that it takes in multiple
// [MapPair] objects at the same time.
func (b *Bucket) MapSetMulti(rowKey []byte, kvs []MapPair) error {
	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	for _, kv := range kvs {
		if err := active.appendMapSorted(rowKey, kv); err != nil {
			return err
		}
	}

	return nil
}

// MapDeleteKey removes one key-value pair from the given map row. Note that
// LSM stores are append only, thus internally this action appends a tombstone.
// The entry will not be removed until a compaction has run, and even then a
// compaction does not guarantee the removal of the data right away. This is
// because an entry could have been created in an older segment than those
// present in the compaction. This can be seen as an implementation detail,
// unless the caller expects to free disk space by calling this method. Such
// freeing is not guaranteed.
//
// MapDeleteKey is specific to the Map Strategy. For Replace, you can use
// [Bucket.Delete] to delete the entire row, for Sets use [Bucket.SetDeleteSingle] to delete a single set element.
func (b *Bucket) MapDeleteKey(rowKey, mapKey []byte) error {
	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	pair := MapPair{
		Key:       mapKey,
		Tombstone: true,
	}

	// The doc-tombstone bitmap must never lead the WAL: replay reconstructs it
	// from the persisted pair (commitlogger_parser_collection.go), so a failed
	// append must leave no bitmap change.
	if err := active.appendMapSorted(rowKey, pair); err != nil {
		return err
	}

	if active.getStrategy() == StrategyInverted {
		docID := binary.BigEndian.Uint64(mapKey)
		if err := active.SetTombstone(docID); err != nil {
			return err
		}
	}

	return nil
}

// Delete removes the given row. Note that LSM stores are append only, thus
// internally this action appends a tombstone.  The entry will not be removed
// until a compaction has run, and even then a compaction does not guarantee
// the removal of the data right away. This is because an entry could have been
// created in an older segment than those present in the compaction. This can
// be seen as an implementation detail, unless the caller expects to free disk
// space by calling this method. Such freeing is not guaranteed.
//
// Delete is specific to the Replace Strategy. For Maps, you can use
// [Bucket.MapDeleteKey] to delete a single key-value pair, for Sets use
// [Bucket.SetDeleteSingle] to delete a single set element.
func (b *Bucket) Delete(key []byte, opts ...SecondaryKeyOption) (err error) {
	start := time.Now()
	b.metrics.IncBucketWriteOpCount("delete")
	b.metrics.IncBucketWriteOpOngoing("delete")
	defer func() {
		b.metrics.DecBucketWriteOpOngoing("delete")
		if err != nil {
			b.metrics.IncBucketWriteOpFailureCount("delete")
			return
		}
		b.metrics.ObserveBucketWriteOpDuration("delete", time.Since(start))
	}()

	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.setTombstone(key, opts...)
}

func (b *Bucket) DeleteWith(key []byte, deletionTime time.Time, opts ...SecondaryKeyOption) (err error) {
	start := time.Now()
	b.metrics.IncBucketWriteOpCount("delete")
	b.metrics.IncBucketWriteOpOngoing("delete")
	defer func() {
		b.metrics.DecBucketWriteOpOngoing("delete")
		if err != nil {
			b.metrics.IncBucketWriteOpFailureCount("delete")
			return
		}
		b.metrics.ObserveBucketWriteOpDuration("delete", time.Since(start))
	}()

	if !b.keepTombstones {
		return fmt.Errorf("bucket requires option `keepTombstones` set to delete keys at a given timestamp")
	}

	active, release, err := b.getActiveMemtableForWrite()
	if err != nil {
		return err
	}
	defer release()

	return active.setTombstoneWith(key, deletionTime, opts...)
}

func (b *Bucket) createNewActiveMemtable() (memtable, error) {
	path := filepath.Join(b.dir, fmt.Sprintf("segment-%d", time.Now().UnixNano()))

	cl, err := newLazyCommitLogger(path, b.strategy)
	if err != nil {
		return nil, errors.Wrap(err, "init commit logger")
	}

	mt, err := newMemtable(cl, b.metrics, b.logger, b.allocChecker, memtableConfig{
		path:                         path,
		strategy:                     b.strategy,
		secondaryIndices:             b.secondaryIndices,
		enableChecksumValidation:     b.enableChecksumValidation,
		writeSegmentInfoIntoFileName: b.writeSegmentInfoIntoFileName,
		shouldSkipKeyFunc:            b.shouldSkipKey,
		skipSecondaryKeyCheck:        b.skipSecondaryKeyCheck,
		bm25config:                   b.bm25Config,
	})
	if err != nil {
		return nil, err
	}

	return mt, nil
}

func (b *Bucket) Count(ctx context.Context) (int, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	return b.countFromCV(ctx, view)
}

func (b *Bucket) countFromCV(ctx context.Context, view BucketConsistentView) (int, error) {
	if err := CheckExpectedStrategy(b.strategy, StrategyReplace); err != nil {
		return 0, fmt.Errorf("Bucket::Count(): %w", err)
	}

	memtableCount := 0
	activeCountStats := view.Active.countStats()
	if view.Flushing == nil {
		count, err := b.memtableNetCount(ctx, activeCountStats, nil, view.Disk)
		if err != nil {
			return 0, err
		}
		memtableCount += count
	} else {
		flushingCountStats := view.Flushing.countStats()
		deltaActive, err := b.memtableNetCount(ctx, activeCountStats, flushingCountStats, view.Disk)
		if err != nil {
			return 0, err
		}
		deltaFlushing, err := b.memtableNetCount(ctx, flushingCountStats, nil, view.Disk)
		if err != nil {
			return 0, err
		}

		memtableCount = deltaActive + deltaFlushing
	}

	diskCount := b.disk.countWithSegmentList(view.Disk)

	if b.monitorCount {
		b.metrics.ObjectCount(memtableCount + diskCount)
	}
	return memtableCount + diskCount, nil
}

// CountAsync ignores the current memtable, that makes it async because it only
// reflects what has been already flushed. This in turn makes it very cheap to
// call, so it can be used for observability purposes where eventual
// consistency on the count is fine, but a large cost is not.
func (b *Bucket) CountAsync() int {
	return b.disk.count()
}

// CountApproximate is a cheap O(#segments) alternative to Count: exact
// per-segment counts plus each memtable's approximate counter (see
// Memtable.netCountAdditions for the drift bounds).
func (b *Bucket) CountApproximate() (int, error) {
	if err := CheckExpectedStrategy(b.strategy, StrategyReplace); err != nil {
		return 0, fmt.Errorf("Bucket::CountApproximate(): %w", err)
	}

	view := b.GetConsistentView()
	defer view.ReleaseView()

	count := b.disk.countWithSegmentList(view.Disk) + view.Active.netCount()
	if view.Flushing != nil {
		count += view.Flushing.netCount()
	}
	if count < 0 {
		count = 0
	}
	return count, nil
}

func (b *Bucket) memtableNetCount(ctx context.Context, stats *countStats, previousMemtable *countStats,
	segments []Segment,
) (int, error) {
	netCount := 0

	// TODO: this uses regular get, given that this may be called quite commonly,
	// we might consider building a pure Exists(), which skips reading the value
	// and only checks for tombstones, etc.
	for i, key := range stats.upsertKeys {
		if i%contextCheckInterval == 0 && ctx.Err() != nil {
			return 0, ctx.Err()
		}
		if !b.existsOnDiskAndPreviousMemtable(previousMemtable, key, segments) {
			netCount++
		}
	}

	for i, key := range stats.tombstonedKeys {
		if i%contextCheckInterval == 0 && ctx.Err() != nil {
			return 0, ctx.Err()
		}
		if b.existsOnDiskAndPreviousMemtable(previousMemtable, key, segments) {
			netCount--
		}
	}

	return netCount, nil
}

func (b *Bucket) existsOnDiskAndPreviousMemtable(previous *countStats, key []byte, segments []Segment) bool {
	// exists in the previous memtable
	if previous.hasUpsert(key) {
		return true
	}
	// deleted in the previous memtable
	if previous.hasTombstone(key) {
		return false
	}
	// check on disk
	if _, err := b.disk.getWithSegmentList(key, segments); err != nil {
		if errors.Is(err, lsmkv.Deleted) || errors.Is(err, lsmkv.NotFound) {
			return false
		}
		// assumes it does not exist in case of error
		return false
	}
	return true
}

func (b *Bucket) Shutdown(ctx context.Context) (err error) {
	b.shuttingDown.Store(true)
	// Barrier: any RegisterEditOp that passed the flag check holds
	// flushAndSwitchMu until its snapshot is durable — wait it out, so no
	// arm is mid-flight once the teardown below starts. Later arms see the
	// flag and refuse.
	b.flushAndSwitchMu.Lock()
	b.flushAndSwitchMu.Unlock() //nolint:staticcheck // empty critical section IS the barrier
	// Drain all in-flight read pins first (see the lifetimeLock doc); the
	// heartbeat makes a wedged drain diagnosable.
	drained := make(chan struct{})
	enterrors.GoWrapper(func() {
		t := time.NewTicker(30 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-drained:
				return
			case <-t.C:
				b.logger.WithField("dir", b.dir).
					Warn("bucket shutdown still draining in-flight read pins")
			}
		}
	}, b.logger)
	b.lifetimeLock.Lock()
	close(drained)
	defer b.lifetimeLock.Unlock()

	defer func() {
		// Release the registry claim only on a COMPLETED teardown: a failed
		// one may leave open handles, and the claim is what makes a re-open
		// over them refuse up front instead of racing a still-live instance
		// (see the claim in NewBucket). A retried or restart shutdown clears
		// it once the teardown actually finishes.
		if err == nil {
			GlobalBucketRegistry.Remove(b.registeredPath)
		}
	}()

	start := time.Now()

	b.metrics.IncBucketShutdownCountByStrategy(b.strategy)
	b.metrics.IncBucketShutdownInProgressByStrategy(b.strategy)

	defer func() {
		b.metrics.DecBucketShutdownInProgressByStrategy(b.strategy)

		if err != nil {
			b.metrics.IncBucketShutdownFailureCountByStrategy(b.strategy)
			return
		}

		b.metrics.ObserveBucketShutdownDurationByStrategy(b.strategy, time.Since(start))
	}()

	if err := b.disk.shutdown(ctx); err != nil {
		return err
	}

	if err := b.flushCallbackCtrl.Unregister(ctx); err != nil {
		return fmt.Errorf("long-running flush in progress: %w", ctx.Err())
	}

	b.flushLock.Lock()
	if b.active.getStrategy() == StrategyInverted {

		// we need to calculate it outside of b.GetAveragePropertyLength()
		// to avoid locking flushLock twice
		propLengthSum, propLengthCount := b.getMemtablePropertyLengths()

		// weighted average of m.averagePropLength and the average of the current flush
		// averaged by propLengthCount and m.propLengthCount
		segmentAveragePropLength, segmentPropCount := b.disk.GetAveragePropertyLength()

		if segmentPropCount != 0 {
			propLengthSum += uint64(segmentAveragePropLength * float64(segmentPropCount))
			propLengthCount += segmentPropCount
		}
		avgPropLength := float64(0)
		if propLengthCount != 0 {
			avgPropLength = float64(propLengthSum) / float64(propLengthCount)
		}
		b.active.setAveragePropertyLength(avgPropLength, propLengthCount)
	}

	if b.shouldReuseWAL() {
		if err := b.active.flushWAL(); err != nil {
			b.flushLock.Unlock()
			return err
		}
	} else {
		if _, err := b.active.flush(); err != nil {
			b.flushLock.Unlock()
			return err
		}
	}
	b.flushLock.Unlock()

	if b.flushing == nil {
		// active has flushing, no one else was currently flushing, it's safe to
		// exit
		return nil
	}

	// it seems we still need to wait for someone to finish flushing
	t := time.NewTicker(50 * time.Millisecond)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			if b.flushing == nil {
				return nil
			}
		}
	}
}

func (b *Bucket) shouldReuseWAL() bool {
	return uint64(b.active.commitlogSize()) <= uint64(b.minWalThreshold)
}

// flushAndSwitchIfThresholdsMet is part of flush callbacks of the bucket.
func (b *Bucket) flushAndSwitchIfThresholdsMet(shouldAbort cyclemanager.ShouldAbortCallback) bool {
	b.flushLock.RLock()
	commitLogSize := b.active.commitlogSize()
	memtableTooLarge := b.active.Size() >= b.memtableThreshold
	walTooLarge := uint64(commitLogSize) >= b.walThreshold
	dirtyTooLong := b.active.DirtyDuration() >= b.flushDirtyAfter
	shouldSwitch := memtableTooLarge || walTooLarge || dirtyTooLong

	// If true, the parent shard has indicated that it has
	// entered an immutable state. During this time, the
	// bucket should refrain from flushing until its shard
	// indicates otherwise
	if shouldSwitch && b.isReadOnly() {
		if b.haltedFlushTimer.IntervalElapsed() {
			b.logger.WithField("action", "lsm_memtable_flush").
				WithField("path", b.dir).
				Warn("flush halted due to shard READONLY status")
			b.haltedFlushTimer.IncreaseInterval()
		}

		b.flushLock.RUnlock()
		return false
	}

	if b.shouldReuseWAL() {
		defer b.flushLock.RUnlock()
		return b.getAndUpdateWritesSinceLastSync()
	}

	b.flushLock.RUnlock()
	if shouldSwitch {
		b.haltedFlushTimer.Reset()
		cycleLength := b.active.ActiveDuration()
		if err := b.FlushAndSwitch(); err != nil {
			b.logger.WithField("action", "lsm_memtable_flush").
				WithField("path", b.GetDir()).
				WithError(err).
				Errorf("flush and switch failed")
			return false
		}

		if b.memtableResizer != nil {
			next, ok := b.memtableResizer.NextTarget(int(b.memtableThreshold), cycleLength)
			if ok {
				b.memtableThreshold = uint64(next)
			}
		}
		return true
	}
	return false
}

func (b *Bucket) getAndUpdateWritesSinceLastSync() bool {
	return b.active.getAndUpdateWritesSinceLastSync(b.logger)
}

// UpdateStatus is used by the parent shard to communicate to the bucket
// when the shard has been set to readonly, or when it is ready for
// writes.
func (b *Bucket) UpdateStatus(status storagestate.Status) {
	b.statusLock.Lock()
	defer b.statusLock.Unlock()

	b.status = status
	b.disk.UpdateStatus(status)
}

func (b *Bucket) isReadOnly() bool {
	if b.immutable {
		return true
	}
	b.statusLock.Lock()
	defer b.statusLock.Unlock()

	return b.status == storagestate.StatusReadOnly
}

// readOnlyErr returns the appropriate error when the bucket is read-only, or
// nil if the bucket is writable. This preserves the distinction between
// structurally immutable buckets (snapshots → ErrImmutable) and operationally
// read-only buckets (shard status → storagestate.ErrStatusReadOnly).
func (b *Bucket) readOnlyErr() error {
	if b.immutable {
		return ErrImmutable
	}
	b.statusLock.Lock()
	defer b.statusLock.Unlock()

	if b.status == storagestate.StatusReadOnly {
		return storagestate.ErrStatusReadOnly
	}
	return nil
}

// FlushAndSwitch is the main way to flush a memtable, replace it with a new
// one, and make sure that the flushed segment gets added to the segment group.
//
// Flushing and adding a segment can take considerable time, which is why the
// whole process is designed to be non-blocking.
//
// To achieve a non-blocking flush, the process is split into four parts:
//
//  1. atomicallySwitchMemtable: A new memtable is created, the previous
//     memtable is moved from "active" to "flushing". This switch is blocking
//     (holds b.flushLock.Lock()), but extremely fast, as we essentially just
//     switch a pointer.
//
//  2. flush: The previous memtable is flushed to disk. This may take
//     considerable time as we are I/O-bound. This is done "in the
//     background"meaning that it does not block any CRUD operations for the
//     user. It only blocks the flush process itself, meaning only one flush per
//     bucket can happen simultaneously. This is by design.
//
//  3. initAndPrecomputeNewSegment: (Newly added in
//     https://github.com/weaviate/weaviate/pull/5943, early October 2024). After
//     the previous flush step the segment can now be initialized. However, to
//     make it usable for real life, we still need to compute metadata, such as
//     bloom filters (all types) and net count additions (only Replace type).
//     Bloom filters can be calculated in isolation and are therefore fairly
//     trivial. Net count additions on the other hand are more complex, as they
//     depend on all previous segments. Calculating net count additions can take
//     a considerable amount of time, especially as the buckets grow larger. As a
//     result, we need to provide two guarantees: (1) the calculation is
//     non-blocking from a user's POV and (2) for the duration of the
//     calculation, the segment group is considered stable, i.e. no other
//     segments are added, removed, or merged. We can achieve this by holding a
//     `b.disk.maintenanceLock.RLock()` which prevents modification of the
//     segments array, but does not block user operation (which are themselves
//     RLock-holders on that same Lock).
//
//  4. atomicallyAddDiskSegmentAndRemoveFlushing: The previous method returned
//     a fully initialized segment that has not yet been added to the segment
//     group. This last step is the counter part to the first step and again
//     blocking, but fast. It adds the segment to the segment group  which at
//     this point is just a simple array append. At the same time it removes the
//     "flushing" memtable. It holds the `b.flushLock.Lock()` making this
//     operation atomic, but blocking.
//
// FlushAndSwitch is typically called periodically and does not require manual
// calling, but there are some situations where this might be intended, such as
// in test scenarios or when a force flush is desired.
func (b *Bucket) FlushAndSwitch() error {
	if err := b.readOnlyErr(); err != nil {
		return err
	}

	// Serialize against any other in-flight FlushAndSwitch on this bucket.
	// See the [flushAndSwitchMu] godoc and GH https://github.com/weaviate/0-weaviate-issues/issues/212
	// Issues C+D for the rationale. This ensures the invariant
	// "after FlushAndSwitch returns, all data written before the call is
	// durably in segments" holds even when two callers race — the second
	// caller waits for the first's flush to land before its own
	// atomicallySwitchMemtable runs.
	b.flushAndSwitchMu.Lock()
	defer b.flushAndSwitchMu.Unlock()

	return b.flushAndSwitchLocked()
}

// flushAndSwitchLocked is FlushAndSwitch's body; the caller must hold
// flushAndSwitchMu (RegisterEditOp holds it across flush + snapshot so a
// concurrent Shutdown cannot interleave between them).
func (b *Bucket) flushAndSwitchLocked() error {
	before := time.Now()
	var err error

	bucketPath := b.GetDir()

	b.logger.WithField("action", "lsm_memtable_flush_start").
		WithField("path", bucketPath).
		Trace("start flush and switch")

	// A non-nil b.flushing here is the aftermath of a FAILED earlier flush
	// (flushAndSwitchLocked returned mid-way and nothing else retries that
	// memtable). Its acknowledged, fsynced writes are readable only through
	// the flushing memtable — switching over it would orphan them until a
	// restart's WAL replay (and, mid-drop, leave pre-arm bytes outside every
	// snapshot). Complete the leftover flush first; if it fails again, this
	// attempt fails too and the data stays readable where it is.
	if b.flushing != nil {
		b.logger.WithField("action", "lsm_memtable_flush_start").
			WithField("path", bucketPath).
			Warn("a previous memtable flush did not complete; retrying it before switching")
		if err := b.flushFlushingLocked(); err != nil {
			return fmt.Errorf("retry incomplete previous flush: %w", err)
		}
	}

	switched, err := b.atomicallySwitchMemtable(b.createNewActiveMemtable)
	if err != nil {
		b.logger.WithField("action", "lsm_memtable_flush_start").
			WithField("path", bucketPath).
			Error(err)
		return fmt.Errorf("flush and switch: %w", err)
	}
	if !switched {
		b.logger.WithField("action", "lsm_memtable_flush_start").
			WithField("path", bucketPath).
			Trace("flush and switch not needed")
		return nil
	}

	if err := b.flushFlushingLocked(); err != nil {
		return err
	}

	took := time.Since(before)
	b.logger.WithField("action", "lsm_memtable_flush_complete").
		WithField("path", bucketPath).
		Trace("finish flush and switch")

	b.logger.WithField("action", "lsm_memtable_flush_complete").
		WithField("path", bucketPath).
		WithField("took", took).
		Debugf("flush and switch took %s\n", took)

	return nil
}

// flushFlushingLocked completes the flush of the memtable currently in
// b.flushing (steps 2-4 of FlushAndSwitch): wait out its writers, flush it to
// a segment, precompute metadata, and atomically add the segment while
// clearing b.flushing. Split out so flushAndSwitchLocked can also drain a
// memtable a FAILED earlier flush left behind before switching. The caller
// must hold flushAndSwitchMu.
func (b *Bucket) flushFlushingLocked() error {
	// Before we can start the actual flush, we need to make sure that all
	// ongoing writers have finished their write, otherwise we could lose the
	// write.
	//
	// The writer count is guaranteed to eventually reach zero, because we
	// switched the active memtable already, new writers will go into the
	// currently active memtable, and existing writers will eventually finish
	// their work
	b.waitForZeroWriters(b.flushing)

	if b.flushing.getStrategy() == StrategyInverted {
		avgPropLength, propLengthCount := b.disk.GetAveragePropertyLength()
		b.flushing.setAveragePropertyLength(avgPropLength, propLengthCount)
	}
	segmentPath, err := b.flushing.flush()
	if err != nil {
		return fmt.Errorf("flush: %w", err)
	}

	var tombstones *sroar.Bitmap
	if b.strategy == StrategyInverted {
		if tombstones, err = b.flushing.ReadOnlyTombstones(); err != nil {
			return fmt.Errorf("get tombstones: %w", err)
		}
	}

	segment, err := b.disk.initAndPrecomputeNewSegment(segmentPath)
	if err != nil {
		return fmt.Errorf("precompute metadata: %w", err)
	}

	if err := b.atomicallyAddDiskSegmentAndRemoveFlushing(segment); err != nil {
		return fmt.Errorf("add segment and remove flushing: %w", err)
	}

	switch b.strategy {
	case StrategyInverted:
		if !tombstones.IsEmpty() {
			if err = func() error {
				// As part of the discussions for
				// https://github.com/weaviate/weaviate/pull/9104 we disocvered that
				// there is a potential, non-critical bug in this logic. There can
				// essentially be a race:
				//
				//   1. Imagine two segments A+B.
				//   2. A compaction is started which merges A+B into AB
				//   3. A flush happens while the compaction is ongoing, we extend A+B
				//      with tombstones
				//   4. The compaction finishes, A+B are replaced with AB, which does
				//      not have the tombstones
				//
				// However, we deem the situation non-critical because any deleted
				// object would be filtered out at the end of the search, so we're
				// "only" wasting some CPU cycles on scoring objects that are already
				// deleted. In addition, on the next restart the tombstones would be
				// applied in a consistent fashion again, so this does not lead to
				// permanent data loss; only a temporary non-critical divergence of
				// in-memory vs on-disk state.
				//
				// As part of #9104, we have accepted this bug (as it is independent of
				// the work done in 9104) and may revisit this logic at a a later
				// point. #9104 simply changes from a maintenance RLock to a segment
				// view which does not alter the behavior, but does help reduce lock
				// contention.
				segments, release := b.disk.getConsistentViewOfSegments()
				defer release()

				// add flushing memtable tombstones to all segments
				for _, seg := range segments {
					if _, err := seg.MergeTombstones(tombstones); err != nil {
						return fmt.Errorf("merge tombstones: %w", err)
					}
				}
				return nil
			}(); err != nil {
				return fmt.Errorf("add tombstones: %w", err)
			}
		}
	}

	return nil
}

// atomicallySwitchMemtable creates a new memtable and switches the active
// memtable to flushing while holding the flush lock. This makes the change atomic.
// This method is agnostic of how a new memtable is constructed, the caller can
// dependency-inject a function to do so.
func (b *Bucket) atomicallySwitchMemtable(createNewActiveMemtable func() (memtable, error)) (bool, error) {
	b.flushLock.Lock()
	defer b.flushLock.Unlock()

	if b.flushing != nil {
		// Overwriting a leftover flushing memtable would orphan its
		// acknowledged writes (unreadable until a restart's WAL replay).
		// Callers must drain it first — flushAndSwitchLocked does.
		return false, fmt.Errorf("previous flushing memtable still present; refusing to overwrite it")
	}

	if b.active.Size() == 0 {
		return false, nil
	}

	flushing := b.active

	mt, err := createNewActiveMemtable()
	if err != nil {
		return false, fmt.Errorf("switch active memtable: %w", err)
	}
	b.active = mt
	b.flushing = flushing

	return true, nil
}

func (b *Bucket) waitForZeroWriters(mt memtable) {
	const (
		tickerInterval = 100 * time.Millisecond
		warnThreshold  = 1 * time.Second
		warnInterval   = 1 * time.Second
	)

	start := time.Now()
	var lastWarn time.Time
	t := time.NewTicker(tickerInterval)
	for {
		writers := mt.getWriterCount()
		if writers == 0 {
			return
		}

		now := time.Now()
		if sinceStart := now.Sub(start); sinceStart >= warnThreshold {
			if lastWarn.IsZero() || now.Sub(lastWarn) >= warnInterval {
				b.logger.WithFields(logrus.Fields{
					"action":     "lsm_flush_wait_writers_refcount",
					"path":       b.dir,
					"refcount":   writers,
					"total_wait": sinceStart,
				}).Warnf("still delaying flush to wait for writers to finish (waited %.2fs so far)", sinceStart.Seconds())
				lastWarn = now
			}
		}

		<-t.C
	}
}

func (b *Bucket) atomicallyAddDiskSegmentAndRemoveFlushing(seg Segment) error {
	b.flushLock.Lock()
	defer b.flushLock.Unlock()

	if b.flushing.Size() == 0 {
		b.flushing = nil
		return nil
	}

	if err := b.disk.addInitializedSegment(seg); err != nil {
		return err
	}
	flushing := b.flushing
	b.flushing = nil

	switch b.strategy {
	case StrategyReplace:
		if b.monitorCount {
			// having just flushed the memtable we now have the most up2date count which
			// is a good place to update the metric
			b.metrics.ObjectCount(b.disk.count())
		}

	case StrategyRoaringSetRange:
		if b.rangeableServesFromMemory() {
			b.disk.roaringSetRangeSegmentInMemory.MergeMemtableEventually(flushing.extractRoaringSetRange())
		}
	case StrategyInverted:
		// A flush only adds the new segment's live docs; deletes are subtracted
		// later at compaction, once the tombstoned docs' lengths drop out of the
		// merged segment (reconcileAveragePropertyLength).
		b.disk.countSegmentAveragePropLength(seg)
	}

	return nil
}

func (b *Bucket) Strategy() string {
	return b.strategy
}

func (b *Bucket) DesiredStrategy() string {
	return b.desiredStrategy
}

// ClassName returns the canonical class name supplied at bucket creation via
// WithClassName. Storobj decoders use this value as the authoritative class
// name and stamp it on every decoded object, ignoring the on-disk class-name
// field. Buckets that do not hold storobj payloads (inverted, prop-length,
// etc.) are not opened with WithClassName; calling ClassName() on them
// returns an error rather than silently producing decoded objects with an
// empty class — readers that need a class name must come from a bucket that
// has one.
func (b *Bucket) ClassName() (string, error) {
	if b.className == "" {
		return "", fmt.Errorf("bucket does not have a class name")
	}
	return b.className, nil
}

// the WAL uses a buffer and isn't written until the buffer size is crossed or
// this function explicitly called. This allows to avoid unnecessary disk
// writes in larger operations, such as batches. It is sufficient to call write
// on the WAL just once. This does not make a batch atomic, but it guarantees
// that the WAL is written before a successful response is returned to the
// user.
func (b *Bucket) WriteWAL() error {
	b.flushLock.RLock()
	defer b.flushLock.RUnlock()

	return b.active.writeWAL()
}

func (b *Bucket) DocPointerWithScoreList(ctx context.Context, key []byte, propBoost float32, cfgs ...MapListOption) ([]terms.DocPointerWithScore, error) {
	view := b.GetConsistentView()
	defer view.ReleaseView()

	return b.docPointerWithScoreListFromConsistentView(ctx, view, key, propBoost, cfgs...)
}

func (b *Bucket) docPointerWithScoreListFromConsistentView(ctx context.Context, view BucketConsistentView,
	key []byte, propBoost float32, cfgs ...MapListOption,
) ([]terms.DocPointerWithScore, error) {
	c := MapListOptionConfig{}
	for _, cfg := range cfgs {
		cfg(&c)
	}

	segments := [][]terms.DocPointerWithScore{}
	plists, segmentsDisk, err := b.disk.getCollectionAndSegments(ctx, key, view.Disk)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}

	allTombstones, err := b.loadAllTombstones(view)
	if err != nil {
		return nil, err
	}

	for i, plist := range plists {
		if ctx.Err() != nil {
			return nil, fmt.Errorf("docPointerWithScoreList: %w", ctx.Err())
		}

		segmentStrategy := segmentsDisk[i].getStrategy()

		var propLengths propLengthsView
		if segmentStrategy == segmentindex.StrategyInverted {
			propLengths, err = segmentsDisk[i].propLengthsView()
			if err != nil {
				return nil, err
			}
		}

		segmentDecoded := make([]terms.DocPointerWithScore, len(plist))
		for j, v := range plist {
			if segmentStrategy == segmentindex.StrategyInverted {
				docId := binary.BigEndian.Uint64(v.value[:8])
				propLen := propLengths.get(docId)
				if err := segmentDecoded[j].FromBytesInverted(v.value, propBoost, float32(propLen)); err != nil {
					return nil, err
				}
				// check if there are any tombstones between the i and len(disk) segments
				for _, tombstones := range allTombstones[i+1:] {
					if tombstones != nil && tombstones.Contains(docId) {
						segmentDecoded[j].Frequency = 0
						break
					}
				}
			} else {
				if err := segmentDecoded[j].FromBytes(v.value, v.tombstone, propBoost); err != nil {
					return nil, err
				}
			}
		}
		segments = append(segments, segmentDecoded)
	}

	if view.Flushing != nil {
		mem, err := view.Flushing.getMap(key)
		if err != nil && !errors.Is(err, lsmkv.NotFound) {
			return nil, err
		}
		docPointers := make([]terms.DocPointerWithScore, len(mem))
		for i, v := range mem {
			if err := docPointers[i].FromKeyVal(v.Key, v.Value, v.Tombstone, propBoost); err != nil {
				return nil, err
			}
		}
		segments = append(segments, docPointers)
	}

	mem, err := view.Active.getMap(key)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return nil, err
	}
	docPointers := make([]terms.DocPointerWithScore, len(mem))
	for i, v := range mem {
		if err := docPointers[i].FromKeyVal(v.Key, v.Value, v.Tombstone, propBoost); err != nil {
			return nil, err
		}
	}
	segments = append(segments, docPointers)

	if c.legacyRequireManualSorting {
		// Sort to support segments which were stored in an unsorted fashion
		for i := range segments {
			sort.Slice(segments[i], func(a, b int) bool {
				return segments[i][a].Id < segments[i][b].Id
			})
		}
	}

	return terms.NewSortedDocPointerWithScoreMerger().Do(ctx, segments)
}

func (b *Bucket) CreateDiskTerm(N float64, filterDocIds helpers.AllowList, query []string, propName string, propertyBoost float32, duplicateTextBoosts []int, config schema.BM25Config, ctx context.Context) ([][]*SegmentBlockMax, map[string]uint64, func(), error) {
	view := b.GetConsistentView()
	return b.createDiskTermFromCV(ctx, view, N, filterDocIds, query, propName, propertyBoost, duplicateTextBoosts, config)
}

func (b *Bucket) createDiskTermFromCV(ctx context.Context, view BucketConsistentView, N float64, filterDocIds helpers.AllowList, query []string, propName string, propertyBoost float32, duplicateTextBoosts []int, bm25Config schema.BM25Config) ([][]*SegmentBlockMax, map[string]uint64, func(), error) {
	defer func() {
		if !entcfg.Enabled(os.Getenv("DISABLE_RECOVERY_ON_PANIC")) {
			if r := recover(); r != nil {
				b.logger.Errorf("Recovered from panic in CreateDiskTerm: %v", r)
				enterrors.PrintStack(b.logger)
				view.ReleaseView()
			}
		}
	}()
	var err error

	averagePropLength, _ := b.GetAveragePropertyLength()

	// Synchronization was reworked as part of
	// https://github.com/weaviate/weaviate/pull/9104.
	//
	// Originally we would hold a maintenanceLock.RLock and pass the unlock
	// function to the caller. This is because the actual BlockMax calcluation
	// happens outside of this function. The lock is no longer necessary now that
	// we support consistent views. We do still need to guarantee that the
	// memtables, and segments do not disappear until the caller has completed.
	// This can be done by passing the view.ReleaseView() method to the caller.
	//
	// Panics at this level are caught and the view is released in the defer
	// function. The lock is released after the blockmax search is done, and
	// panics are also handled.

	output := make([][]*SegmentBlockMax, len(view.Disk)+2)
	idfs := make([]float64, len(query))
	idfCounts := make(map[string]uint64, len(query))
	// flusing memtable
	output[len(view.Disk)] = make([]*SegmentBlockMax, 0, len(query))

	// active memtable
	output[len(view.Disk)+1] = make([]*SegmentBlockMax, 0, len(query))

	// Memtable tombstones are invariant within a consistent view. ReadOnlyTombstones
	// returns a shared immutable snapshot, so reuse it directly when only one memtable
	// carries tombstones; allocate a merged bitmap only when both are present.
	var activeTombstones, flushingTombstones *sroar.Bitmap
	if view.Active != nil {
		activeTombstones, err = view.Active.ReadOnlyTombstones()
		if err != nil {
			view.ReleaseView()
			return nil, nil, func() {}, fmt.Errorf("active tombstones: %w", err)
		}
	}
	if view.Flushing != nil {
		flushingTombstones, err = view.Flushing.ReadOnlyTombstones()
		if err != nil {
			view.ReleaseView()
			return nil, nil, func() {}, fmt.Errorf("flushing tombstones: %w", err)
		}
	}
	var memTombstones *sroar.Bitmap
	switch {
	case activeTombstones != nil && flushingTombstones != nil:
		memTombstones = sroar.Or(activeTombstones, flushingTombstones)
	case activeTombstones != nil:
		memTombstones = activeTombstones
	case flushingTombstones != nil:
		memTombstones = flushingTombstones
	default:
		memTombstones = sroar.NewBitmap()
	}

	// One index descent per (segment, term): diskNodes/diskNodeOk cache the node
	// and doc count for reuse by both the count below and term construction.
	// diskSkip marks inverted segments where the key is absent, so construction
	// is skipped.
	qn := len(query)
	diskNodes := make([]segmentindex.Node, len(view.Disk)*qn)
	diskNodeOk := make([]bool, len(view.Disk)*qn)
	diskSkip := make([]bool, len(view.Disk)*qn)

	for i, queryTerm := range query {
		key := []byte(queryTerm)
		n := uint64(0)

		var active, flushing *SegmentBlockMax
		if view.Active != nil {
			if mapPairs, err := view.Active.getMap(key); err == nil {
				if active = NewSegmentBlockMaxDecoded(key, i, propertyBoost, filterDocIds, averagePropLength, bm25Config); active != nil {
					n2, _ := addDataToTerm(mapPairs, filterDocIds, active)
					if active.Count() > 0 {
						output[len(view.Disk)+1] = append(output[len(view.Disk)+1], active)
					}
					n += n2

					if !active.Exhausted() {
						active.advanceOnTombstoneOrFilter()
					}
				}
			}
		}

		if view.Flushing != nil {
			if mapPairs, err := view.Flushing.getMap(key); err == nil {
				if flushing = NewSegmentBlockMaxDecoded(key, i, propertyBoost, filterDocIds, averagePropLength, bm25Config); flushing != nil {
					n2, _ := addDataToTerm(mapPairs, filterDocIds, flushing)
					if flushing.Count() > 0 {
						output[len(view.Disk)] = append(output[len(view.Disk)], flushing)
					}
					n += n2

					if !flushing.Exhausted() {
						flushing.setTombstones(activeTombstones)
						flushing.advanceOnTombstoneOrFilter()
					}
				}
			}
		}

		for j, segment := range view.Disk {
			if segment.getStrategy() != segmentindex.StrategyInverted {
				continue
			}
			if node, docCount, ok := segment.getInvertedNodeAndDocCount(key); ok {
				n += docCount
				diskNodes[j*qn+i] = node
				diskNodeOk[j*qn+i] = true
			} else {
				diskSkip[j*qn+i] = true
			}
		}

		// we can only know the full n after we have checked all segments and all memtables
		idfs[i] = terms.Idf(float64(n), N) * float64(duplicateTextBoosts[i])

		// currentBlockImpact is a max-score upper bound, so it must carry
		// propertyBoost like Score and computeCurrentBlockImpact; bare idf
		// under-counts boosted terms and prunes genuine top-K docs.
		if active != nil {
			active.idf = idfs[i]
			active.currentBlockImpact = float32(idfs[i] * active.propertyBoost)
		}
		if flushing != nil {
			flushing.idf = idfs[i]
			flushing.currentBlockImpact = float32(idfs[i] * flushing.propertyBoost)
		}

		idfCounts[queryTerm] = n
	}

	if ctx.Err() != nil {
		view.ReleaseView()
		return nil, nil, func() {}, fmt.Errorf("after memtable terms: %w", ctx.Err())
	}

	// Fold tombstones into the filter when it pays: one membership check per
	// candidate instead of up to three, against an upfront AndNot per segment.
	// The AndNot clones the whole filter once per disk segment, so amortize scan
	// volume against the segment count, not a single clone — otherwise a broad
	// filter over many segments merges for a marginal per-doc saving at a large
	// per-query allocation. Skipped under deferTombstoneToScore, which deliberately
	// keeps tombstones out of the advance-time checks the merge would fold into.
	filterBl, _ := filterDocIds.(*helpers.BitmapAllowList)
	mergeFilterAndTombstones := false
	if filterBl != nil && !deferTombstoneToScore {
		// An empty filter already admits nothing, so folding would only burn
		// AndNots on a query that returns no results.
		if filterCard := filterBl.Bm.GetCardinality(); filterCard > 0 {
			var sumDf uint64
			for _, n := range idfCounts {
				sumDf += n
			}
			// nSeg (>=1) prices the per-segment clone into the gate: the fold runs
			// an AndNot only where a segment's tombstones shadow the next-older one
			// (Disk[1:], never the oldest), so count tombstone-carrying segments —
			// not len(view.Disk), which over-prices a broad filter over many
			// tombstone-free segments and skips folds that would have been cheap.
			// These reads warm the snapshot cache the fold loop reads again below.
			tombSegs := 0
			for k := 1; k < len(view.Disk); k++ {
				segTomb, tombErr := view.Disk[k].ReadOnlyTombstones()
				if tombErr != nil {
					view.ReleaseView()
					return nil, nil, func() {}, fmt.Errorf("read tombstones: %w", tombErr)
				}
				if !segTomb.IsEmpty() { // IsEmpty is nil-safe
					tombSegs++
				}
			}
			nSeg := float64(tombSegs)
			if nSeg < 1 {
				nSeg = 1
			}
			gateRatio := config.DefaultBM25FilterTombMergeGateRatio
			if b.bm25FilterTombMergeGateRatio != nil {
				gateRatio = b.bm25FilterTombMergeGateRatio.Get()
			}
			mergeFilterAndTombstones = float64(sumDf) >= gateRatio*float64(filterCard)*nSeg
		}
	}

	// Memtable tombstones are loop-invariant, so fold them out of the filter once
	// (filter \ memTombstones) and reuse that as the base every segment subtracts
	// its own tombstones from (or uses directly when it has none).
	memHasTomb := mergeFilterAndTombstones && !memTombstones.IsEmpty()
	var filterBase *sroar.Bitmap
	if mergeFilterAndTombstones {
		filterBase = filterBl.Bm
		if memHasTomb {
			// Clone-then-subtract rather than a fresh AndNot: memtable tombstones
			// are the small in-flight-deletes set, where removing bits from a copy
			// beats building the result from scratch (~10-20% faster, one alloc
			// fewer). Clone keeps the shared filter untouched.
			filterBase = filterBl.Bm.Clone().AndNot(memTombstones)
		}
	}
	// Wraps filterBase for segments with no tombstones of their own; built lazily
	// so it costs nothing when every segment has tombstones.
	var filterBaseList helpers.AllowList

	var segTombstones *sroar.Bitmap
	for j := len(view.Disk) - 1; j >= 0; j-- {
		segment := view.Disk[j]
		output[j] = make([]*SegmentBlockMax, 0, len(query))
		if j != len(view.Disk)-1 {
			segTombstones, err = view.Disk[j+1].ReadOnlyTombstones()
			if err != nil {
				view.ReleaseView()
				return nil, nil, func() {}, fmt.Errorf("read tombstones: %w", err)
			}
		}

		// Fold this segment's tombstones into a private filter clone. The free
		// function sroar.AndNot returns a fresh filter \ tombstones and never
		// mutates the shared filter, which concurrent readers depend on (unlike
		// the in-place method).
		segFilter, segTomb, segMemTomb := filterDocIds, segTombstones, memTombstones
		if mergeFilterAndTombstones { // implies filterBl != nil
			switch {
			case !segTombstones.IsEmpty(): // IsEmpty is nil-safe
				// filter \ memTombstones \ segTombstones, off the shared base.
				segFilter = helpers.NewAllowListFromBitmap(sroar.AndNot(filterBase, segTombstones))
			case memHasTomb:
				if filterBaseList == nil {
					filterBaseList = helpers.NewAllowListFromBitmap(filterBase)
				}
				segFilter = filterBaseList
			}
			// The fold moved tombstones into segFilter, so the term no longer
			// checks them separately.
			segTomb, segMemTomb = nil, nil
		}

		for i, key := range query {
			idx := j*qn + i
			if diskSkip[idx] {
				continue
			}
			// non-inverted segments have no prefetched node; nil makes the
			// constructor do its own index lookup.
			var node *segmentindex.Node
			if diskNodeOk[idx] {
				node = &diskNodes[idx]
			}
			term := segment.newSegmentBlockMax(node, []byte(key), i, idfs[i], propertyBoost, segTomb, segMemTomb, segFilter, averagePropLength, bm25Config)
			if term != nil {
				output[j] = append(output[j], term)
			}
		}
	}
	return output, idfCounts, view.ReleaseView, nil
}

func fillTerm(memtable memtable, key []byte, blockmax *SegmentBlockMax, filterDocIds helpers.AllowList) (uint64, error) {
	mapPairs, err := memtable.getMap(key)
	if err != nil && !errors.Is(err, lsmkv.NotFound) {
		return 0, err
	}
	if errors.Is(err, lsmkv.NotFound) {
		return 0, nil
	}
	n, err := addDataToTerm(mapPairs, filterDocIds, blockmax)
	if err != nil {
		return 0, err
	}
	return n, nil
}

func addDataToTerm(mem []MapPair, filterDocIds helpers.AllowList, term *SegmentBlockMax) (uint64, error) {
	n := uint64(0)
	term.blockDataDecoded = &terms.BlockDataDecoded{
		DocIds: make([]uint64, 0, len(mem)),
		Tfs:    make([]uint64, 0, len(mem)),
	}
	term.propLengths = make(map[uint64]uint32)

	// SetIdf later recomputes currentBlockImpact from MaxImpactTf/PropLength. If
	// those fields are left at zero, the recomputed impact — the WAND upper bound
	// — is zero too, so record the posting list's max-impact pair here.
	maxImpact := float64(0)
	var maxImpactTf, maxImpactPropLength uint32

	for _, v := range mem {
		if v.Tombstone {
			continue
		}
		n++
		if len(v.Value) < 8 {
			// b.logger.Warnf("Skipping pair in BM25: MapPair.Value should be 8 bytes long, but is %d.", len(v.Value))
			continue
		}
		d := terms.DocPointerWithScore{}
		if err := d.FromKeyVal(v.Key, v.Value, false, 1.0); err != nil {
			return 0, err
		}
		if filterDocIds != nil && !filterDocIds.Contains(d.Id) {
			continue
		}

		term.blockDataDecoded.DocIds = append(term.blockDataDecoded.DocIds, d.Id)
		term.blockDataDecoded.Tfs = append(term.blockDataDecoded.Tfs, uint64(d.Frequency))
		term.propLengths[d.Id] = uint32(d.PropLength)

		tf := float64(d.Frequency)
		pl := float64(d.PropLength)
		if impact := tf / (tf + term.k1*(1-term.b+term.b*(pl/term.averagePropLength))); impact > maxImpact {
			maxImpact = impact
			maxImpactTf = uint32(d.Frequency)
			maxImpactPropLength = uint32(d.PropLength)
		}
	}
	if len(term.blockDataDecoded.DocIds) == 0 {
		return n, nil
	}
	term.exhausted = false
	term.blockEntries = make([]terms.BlockEntry, 1)
	term.blockEntries[0] = terms.BlockEntry{
		MaxId:               term.blockDataDecoded.DocIds[len(term.blockDataDecoded.DocIds)-1],
		Offset:              0,
		MaxImpactTf:         maxImpactTf,
		MaxImpactPropLength: maxImpactPropLength,
	}

	term.currentBlockMaxId = term.blockDataDecoded.DocIds[len(term.blockDataDecoded.DocIds)-1]
	term.docCount = uint64(len(term.blockDataDecoded.DocIds))
	term.blockDataSize = len(term.blockDataDecoded.DocIds)
	term.idPointer = term.blockDataDecoded.DocIds[0]
	return n, nil
}

func (b *Bucket) getMemtablePropertyLengths() (uint64, uint64) {
	// fix potential race with buckets flushing
	propLengthCount := uint64(0)
	propLengthSum := uint64(0)

	if b.flushing != nil {
		propLengthSum, propLengthCount = b.flushing.GetPropLengths()
	}

	// if the active memtable is inverted, we need to get the average property
	if b.active != nil {
		propLengthSum2, propLengthCount2 := b.active.GetPropLengths()
		propLengthCount += propLengthCount2
		propLengthSum += propLengthSum2
	}
	if propLengthCount == 0 {
		return 0, 0
	}
	return propLengthSum, propLengthCount
}

func (b *Bucket) GetAveragePropertyLength() (float64, uint64) {
	if b.strategy != StrategyInverted {
		return 0, 0
	}

	b.flushLock.RLock()
	propLengthSum, propLengthCount := b.getMemtablePropertyLengths()
	b.flushLock.RUnlock()
	// weighted average of m.averagePropLength and the average of the current flush
	// averaged by propLengthCount and m.propLengthCount
	segmentAveragePropLength, segmentPropCount := b.disk.GetAveragePropertyLength()

	if segmentPropCount != 0 {
		propLengthSum += uint64(segmentAveragePropLength * float64(segmentPropCount))
		propLengthCount += segmentPropCount
	}
	if propLengthCount == 0 {
		return 0, 0
	}
	return float64(propLengthSum) / float64(propLengthCount), propLengthCount
}

func DetermineUnloadedBucketStrategy(bucketPath string) (string, error) {
	return DetermineUnloadedBucketStrategyAmong(bucketPath, prioritizedAllStrategies)
}

func DetermineUnloadedBucketStrategyAmong(bucketPath string, prioritizedStrategies []string) (string, error) {
	if len(prioritizedStrategies) == 0 {
		return "", fmt.Errorf("no prioritizedStrategies given")
	}
	defaultStrategy := prioritizedStrategies[0]

	entries, err := os.ReadDir(bucketPath)
	if err != nil {
		if !os.IsNotExist(err) {
			return "", err
		}
		return defaultStrategy, nil
	}
	if len(entries) == 0 {
		return defaultStrategy, nil
	}

	// check wals only after checking all segments
	var walEntries []os.DirEntry
	ec := errorcompounder.New()
	ecMismatchStrategy := errorcompounder.New()
	bufHeader := make([]byte, segmentindex.HeaderSize)

	for _, entry := range entries {
		switch filepath.Ext(entry.Name()) {
		case ".db":
			info, err := entry.Info()
			if err != nil {
				ec.Add(fmt.Errorf("%q:%w", entry.Name(), err))
				continue
			}
			if info.Size() <= 0 {
				continue
			}

			strategy, err := func() (string, error) {
				file, err := os.Open(filepath.Join(bucketPath, entry.Name()))
				if err != nil {
					return "", err
				}
				defer file.Close()

				_, err = io.ReadFull(file, bufHeader)
				if err != nil {
					return "", err
				}

				header, err := segmentindex.ParseHeader(bufHeader)
				if err != nil {
					return "", err
				}

				return header.Strategy.String(), nil
			}()
			if err != nil {
				ec.Add(fmt.Errorf("%q:%w", entry.Name(), err))
				continue
			}
			if !slices.Contains(prioritizedStrategies, strategy) {
				ecMismatchStrategy.Add(fmt.Errorf("%q:strategy %q does not match %v", entry.Name(), strategy, prioritizedStrategies))
				continue
			}
			return strategy, nil

		case ".wal":
			info, err := entry.Info()
			if err != nil {
				ec.Add(fmt.Errorf("%q:%w", entry.Name(), err))
				continue
			}
			if info.Size() <= 0 {
				continue
			}
			walEntries = append(walEntries, entry)

		default:
			continue
		}
	}

	if err := ecMismatchStrategy.ToError(); err != nil {
		return "", err
	}

	// strategy not yet determined. proceed with wal files
	for _, entry := range walEntries {
		strategy, err := func() (string, error) {
			file, err := os.Open(filepath.Join(bucketPath, entry.Name()))
			if err != nil {
				return "", err
			}
			defer file.Close()

			return guessCommitLogStrategyAmong(file, prioritizedStrategies)
		}()
		if err != nil {
			ec.Add(fmt.Errorf("%q:strategy %q does not match %v", entry.Name(), strategy, prioritizedStrategies))
			continue
		}
		return strategy, nil
	}

	if err := ec.ToError(); err != nil {
		return "", err
	}
	return defaultStrategy, nil
}

// PrependSegmentsFromBucket copies all segments from srcDir and prepends them
// into this bucket's segment group. See SegmentGroup.PrependSegmentsFromBucket
// for full semantics and preconditions.
func (b *Bucket) PrependSegmentsFromBucket(ctx context.Context, srcDir string) error {
	return b.disk.PrependSegmentsFromBucket(ctx, srcDir)
}
