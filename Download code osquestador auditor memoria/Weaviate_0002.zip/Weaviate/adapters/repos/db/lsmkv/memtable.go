//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"bufio"
	"context"
	"encoding/binary"
	"fmt"
	"math"
	"path/filepath"
	"sync"
	"sync/atomic"
	"time"

	"github.com/weaviate/weaviate/usecases/memwatch"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	"github.com/weaviate/sroar"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv/segmentindex"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringset"
	"github.com/weaviate/weaviate/adapters/repos/db/roaringsetrange"
	"github.com/weaviate/weaviate/entities/diskio"
	"github.com/weaviate/weaviate/entities/lsmkv"
	"github.com/weaviate/weaviate/entities/models"
)

type memtable interface {
	get(key []byte) ([]byte, error)
	getBySecondary(pos int, key []byte) ([]byte, []byte, error)
	exists(key []byte) error
	put(key, value []byte, opts ...SecondaryKeyOption) error
	setTombstone(key []byte, opts ...SecondaryKeyOption) error
	setTombstoneWith(key []byte, deletionTime time.Time, opts ...SecondaryKeyOption) error

	getCollection(key []byte) ([]value, error)
	getCollectionBytes(key []byte) ([][]byte, error)
	getMap(key []byte) ([]MapPair, error)
	append(key []byte, values []value) error
	appendMapSorted(key []byte, pair MapPair) error

	Size() uint64
	Path() string
	ActiveDuration() time.Duration
	DirtyDuration() time.Duration
	updateDirtyAt()
	countStats() *countStats
	netCount() int
	getStrategy() string
	commitlogSize() int64
	commitlogWalPath() string

	writeWAL() error
	flushWAL() error
	flush() (string, error)
	setAveragePropertyLength(avgPropLength float64, propLengthCount uint64)
	getAndUpdateWritesSinceLastSync(logger logrus.FieldLogger) bool

	ReadOnlyTombstones() (*sroar.Bitmap, error)
	SetTombstone(docId uint64) error
	GetPropLengths() (uint64, uint64)

	newCursor() innerCursorReplace
	newCursorWithRange(min, max []byte) innerCursorReplace
	newBlockingCursor() (innerCursorReplace, func())
	newCursorWithSecondaryIndex(pos int) innerCursorReplace
	newCollectionCursor() innerCursorCollection
	newRoaringSetCursor() roaringset.InnerCursor
	newRoaringSetRangeReader() roaringsetrange.InnerReader
	newMapCursor() innerCursorMap

	roaringSetAddOne(key []byte, value uint64) error
	roaringSetAddList(key []byte, values []uint64) error
	roaringSetAddBatch(entries []RoaringSetBatchEntry) error
	roaringSetAddBitmap(key []byte, bm *sroar.Bitmap) error
	roaringSetRemoveOne(key []byte, value uint64) error
	roaringSetRemoveList(key []byte, values []uint64) error
	roaringSetRemoveBatch(entries []RoaringSetBatchEntry) error
	roaringSetRemoveBitmap(key []byte, bm *sroar.Bitmap) error
	roaringSetAddRemoveSlices(key []byte, additions []uint64, deletions []uint64) error
	roaringSetGet(key []byte) (roaringset.BitmapLayer, error)
	roaringSetAdjustMeta(entriesChanged int)
	roaringSetAddCommitLog(node *roaringset.SegmentNodeList) error

	roaringSetRangeAdd(key uint64, values ...uint64) error
	roaringSetRangeRemove(key uint64, values ...uint64) error
	roaringSetRangeAddRemove(key uint64, additions []uint64, deletions []uint64) error
	roaringSetRangeAdjustMeta(entriesChanged int)
	roaringSetRangeAddCommitLog(key uint64, additions []uint64, deletions []uint64) error
	extractRoaringSetRange() *roaringsetrange.Memtable

	flushDataReplace(f *segmentindex.SegmentFile) ([]segmentindex.Key, error)
	flushDataSet(f *segmentindex.SegmentFile) ([]segmentindex.Key, error)
	flushDataMap(f *segmentindex.SegmentFile) ([]segmentindex.Key, error)
	flushDataCollection(f *segmentindex.SegmentFile, flat []*binarySearchNodeMulti) ([]segmentindex.Key, error)
	flushDataInverted(f *segmentindex.SegmentFile, ogF *diskio.MeteredWriter, bufw *bufio.Writer) ([]segmentindex.Key, *sroar.Bitmap, error)
	flushDataRoaringSet(f *segmentindex.SegmentFile) ([]segmentindex.Key, error)
	flushDataRoaringSetRange(f *segmentindex.SegmentFile) ([]segmentindex.Key, error)

	incWriterCount()
	decWriterCount()
	getWriterCount() int64
}

type Memtable struct {
	sync.RWMutex
	key             *binarySearchTree
	keyMulti        *binarySearchTreeMulti
	keyMap          *binarySearchTreeMap
	primaryIndex    *binarySearchTree
	roaringSet      *roaringset.BinarySearchTree
	roaringSetRange *roaringsetrange.Memtable
	commitlog       memtableCommitLogger
	allocChecker    memwatch.AllocChecker
	size            uint64
	// netCountAdditions approximates the net live keys this memtable adds on
	// top of the rest of the LSM tree. Whether a key already exists further
	// down is unknown at write time: updates of flushed keys over-count,
	// deletes of never-written keys under-count, and the drift is corrected by
	// the exact per-segment count at flush. StrategyReplace only.
	netCountAdditions  int
	path               string
	strategy           string
	secondaryIndices   uint16
	secondaryToPrimary []map[string][]byte
	// stores time memtable got dirty to determine when flush is needed
	dirtyAt             time.Time
	createdAt           time.Time
	metrics             *memtableMetrics
	writesSinceLastSync bool

	tombstones *sroar.Bitmap
	// tombstonesSnapshot is an immutable copy of tombstones published for lock-free
	// reads. SetTombstone clears it to nil to mark it stale; ReadOnlyTombstones
	// rebuilds it lazily when it loads nil. It is never mutated in place, so readers
	// share it without cloning or locking, and the read fast path is a single atomic
	// load that touches neither the memtable RWMutex nor a copy.
	tombstonesSnapshot atomic.Pointer[sroar.Bitmap]
	// invMu guards the inverted-strategy delete/prop-length state (tombstones,
	// propLengthExists, currPropLength*) independently of the tree RWMutex, so
	// SetTombstone does not take the exclusive lock that getMap readers wait on.
	// GetPropLengths only reads, so it takes the read lock.
	// Lock order when both are held: the tree lock first, then invMu (appendMapSorted).
	invMu sync.RWMutex

	enableChecksumValidation bool

	bm25config                   *models.BM25Config
	averagePropLength            float64
	propLengthCount              uint64
	writeSegmentInfoIntoFileName bool

	// We're only tracking the refcount for writers. Readers get a consistent
	// view of all memtables & segments, so they don't need ref-counting.
	// Writers do, because if we have an ongoing write, we cannot start flushing
	// the memtable. This prevents the memtable from being flushed while writers
	// are active, ensuring data consistency during concurrent operations.
	writerCount atomic.Int64

	// function to decide whether a key should be skipped
	// during flush for the SetCollection strategy
	shouldSkipKeyFunc func(key []byte, ctx context.Context) (bool, error)
	// Keep track of the current prop length count and sum in the memtable,
	// so that we don't have to compute it from scratch for search, flush and compaction.
	currPropLengthCount, currPropLengthSum uint64
	propLengthExists                       *sroar.Bitmap

	skipSecondaryKeyCheck bool
}

type memtableConfig struct {
	path                         string
	strategy                     string
	secondaryIndices             uint16
	enableChecksumValidation     bool
	writeSegmentInfoIntoFileName bool
	skipSecondaryKeyCheck        bool
	shouldSkipKeyFunc            func(key []byte, ctx context.Context) (bool, error)
	bm25config                   *models.BM25Config
}

func newMemtable(cl memtableCommitLogger, metrics *Metrics, logger logrus.FieldLogger,
	allocChecker memwatch.AllocChecker, config memtableConfig,
) (*Memtable, error) {
	memtableMetrics, err := newMemtableMetrics(metrics, filepath.Dir(config.path), config.strategy)
	if err != nil {
		return nil, fmt.Errorf("init memtable metrics: %w", err)
	}

	m := &Memtable{
		key:                          &binarySearchTree{},
		keyMulti:                     &binarySearchTreeMulti{},
		keyMap:                       &binarySearchTreeMap{},
		primaryIndex:                 &binarySearchTree{}, // todo, sort upfront
		roaringSet:                   &roaringset.BinarySearchTree{},
		roaringSetRange:              roaringsetrange.NewMemtable(logger),
		commitlog:                    cl,
		path:                         config.path,
		strategy:                     config.strategy,
		secondaryIndices:             config.secondaryIndices,
		dirtyAt:                      time.Time{},
		createdAt:                    time.Now(),
		metrics:                      memtableMetrics,
		enableChecksumValidation:     config.enableChecksumValidation,
		bm25config:                   config.bm25config,
		writeSegmentInfoIntoFileName: config.writeSegmentInfoIntoFileName,
		shouldSkipKeyFunc:            config.shouldSkipKeyFunc,
		skipSecondaryKeyCheck:        config.skipSecondaryKeyCheck,
	}

	if m.secondaryIndices > 0 {
		m.secondaryToPrimary = make([]map[string][]byte, m.secondaryIndices)
		for i := range m.secondaryToPrimary {
			m.secondaryToPrimary[i] = map[string][]byte{}
		}
	}

	m.metrics.observeSize(m.size)

	if m.strategy == StrategyInverted {
		m.tombstones = sroar.NewBitmap()
		m.propLengthExists = sroar.NewBitmap()
	}

	return m, nil
}

func (m *Memtable) get(key []byte) ([]byte, error) {
	start := time.Now()
	defer m.metrics.observeGet(start.UnixNano())

	if err := m.checkStrategy(StrategyReplace); err != nil {
		return nil, fmt.Errorf("Memtable::get(): %w", err)
	}

	m.RLock()
	defer m.RUnlock()

	return m.key.get(key)
}

// exists checks if a key exists and is not deleted, without returning the value.
// This is more efficient than get() when only existence check is needed.
func (m *Memtable) exists(key []byte) error {
	if err := m.checkStrategy(StrategyReplace); err != nil {
		return fmt.Errorf("Memtable::exists(): %w", err)
	}

	m.RLock()
	defer m.RUnlock()

	return m.key.exists(key)
}

func (m *Memtable) getBySecondary(pos int, key []byte) ([]byte, []byte, error) {
	start := time.Now()
	defer m.metrics.observeGetBySecondary(start.UnixNano())

	if err := m.checkStrategy(StrategyReplace); err != nil {
		return nil, nil, fmt.Errorf("Memtable::getBySecondary(): %w", err)
	}

	m.RLock()
	defer m.RUnlock()

	primary := m.secondaryToPrimary[pos][string(key)]
	if primary == nil {
		return nil, nil, lsmkv.NotFound
	}

	v, err := m.key.get(primary)
	return primary, v, err
}

func (m *Memtable) put(key, value []byte, opts ...SecondaryKeyOption) error {
	start := time.Now()
	defer m.metrics.observePut(start.UnixNano())

	if err := m.checkStrategy(StrategyReplace); err != nil {
		return fmt.Errorf("Memtable::put(): %w", err)
	}

	secondaryKeys, err := m.createSecondaryKeys(opts)
	if err != nil {
		return fmt.Errorf("put for key %q: %w", key, err)
	}

	node := segmentReplaceNode{
		primaryKey:          key,
		value:               value,
		secondaryIndexCount: m.secondaryIndices,
		secondaryKeys:       secondaryKeys,
		tombstone:           false,
	}

	m.Lock()
	defer m.Unlock()

	if err := m.commitlog.put(node); err != nil {
		return errors.Wrap(err, "write into commit log")
	}

	netAdditions, previousKeys, wasLive := m.key.insert(key, value, secondaryKeys)
	m.updateSecondaryToPrimary(key, secondaryKeys, previousKeys)
	if !wasLive {
		m.netCountAdditions++
	}

	m.size += uint64(netAdditions)
	m.metrics.observeSize(m.size)
	m.updateDirtyAt()
	m.writesSinceLastSync = true

	return nil
}

func (m *Memtable) setTombstone(key []byte, opts ...SecondaryKeyOption) error {
	start := time.Now()
	defer m.metrics.observeSetTombstone(start.UnixNano())

	if err := m.checkStrategy(StrategyReplace); err != nil {
		return fmt.Errorf("Memtable::setTombstone(): %w", err)
	}

	secondaryKeys, err := m.createSecondaryKeys(opts)
	if err != nil {
		return fmt.Errorf("setTombstone for key %q: %w", key, err)
	}

	node := segmentReplaceNode{
		primaryKey:          key,
		value:               nil,
		secondaryIndexCount: m.secondaryIndices,
		secondaryKeys:       secondaryKeys,
		tombstone:           true,
	}

	m.Lock()
	defer m.Unlock()

	if err := m.commitlog.put(node); err != nil {
		return errors.Wrap(err, "write into commit log")
	}

	previousKeys, wasTombstoned := m.key.setTombstone(key, nil, secondaryKeys)
	m.updateSecondaryToPrimary(key, secondaryKeys, previousKeys)
	if !wasTombstoned {
		m.netCountAdditions--
	}

	m.size += uint64(len(key)) + 1 // 1 byte for tombstone
	m.metrics.observeSize(m.size)
	m.updateDirtyAt()
	m.writesSinceLastSync = true

	return nil
}

func (m *Memtable) setTombstoneWith(key []byte, deletionTime time.Time, opts ...SecondaryKeyOption) error {
	start := time.Now()
	defer m.metrics.observeSetTombstone(start.UnixNano())

	if err := m.checkStrategy(StrategyReplace); err != nil {
		return fmt.Errorf("Memtable::setTombstoneWith(): %w", err)
	}

	secondaryKeys, err := m.createSecondaryKeys(opts)
	if err != nil {
		return fmt.Errorf("setTombstoneWith for key %q: %w", key, err)
	}

	tombstonedVal := tombstonedValue(deletionTime)
	node := segmentReplaceNode{
		primaryKey:          key,
		value:               tombstonedVal[:],
		secondaryIndexCount: m.secondaryIndices,
		secondaryKeys:       secondaryKeys,
		tombstone:           true,
	}

	m.Lock()
	defer m.Unlock()

	if err := m.commitlog.put(node); err != nil {
		return errors.Wrap(err, "write into commit log")
	}

	previousKeys, wasTombstoned := m.key.setTombstone(key, tombstonedVal[:], secondaryKeys)
	m.updateSecondaryToPrimary(key, secondaryKeys, previousKeys)
	if !wasTombstoned {
		m.netCountAdditions--
	}

	m.size += uint64(len(key)) + 1 // 1 byte for tombstone
	m.metrics.observeSize(m.size)
	m.updateDirtyAt()
	m.writesSinceLastSync = true

	return nil
}

func tombstonedValue(deletionTime time.Time) []byte {
	var tombstonedVal [1 + 8]byte // version=1 deletionTime
	tombstonedVal[0] = 1
	binary.LittleEndian.PutUint64(tombstonedVal[1:], uint64(deletionTime.UnixMilli()))
	return tombstonedVal[:]
}

func errorFromTombstonedValue(tombstonedVal []byte) error {
	if len(tombstonedVal) == 0 {
		return lsmkv.Deleted
	}

	if tombstonedVal[0] != 1 {
		return fmt.Errorf("unexpected tomstoned value, unsupported version %d", tombstonedVal[0])
	}

	if len(tombstonedVal) != 9 {
		return fmt.Errorf("unexpected tomstoned value, invalid length")
	}

	deletionTimeUnixMilli := int64(binary.LittleEndian.Uint64(tombstonedVal[1:]))

	return lsmkv.NewErrDeleted(time.UnixMilli(deletionTimeUnixMilli))
}

func (m *Memtable) createSecondaryKeys(opts []SecondaryKeyOption) ([][]byte, error) {
	var secondaryKeys [][]byte
	if m.secondaryIndices > 0 {
		secondaryKeys = make([][]byte, m.secondaryIndices)
		for _, opt := range opts {
			if err := opt(secondaryKeys); err != nil {
				return nil, err
			}
		}
		if !m.skipSecondaryKeyCheck {
			for i, sk := range secondaryKeys {
				if sk == nil {
					return nil, fmt.Errorf("missing secondary key at index %d", i)
				}
			}
		}
	}
	return secondaryKeys, nil
}

func (m *Memtable) updateSecondaryToPrimary(key []byte, secondaryKeys, previousKeys [][]byte) {
	for i, sec := range previousKeys {
		m.secondaryToPrimary[i][string(sec)] = nil
	}
	for i, sec := range secondaryKeys {
		m.secondaryToPrimary[i][string(sec)] = key
	}
}

func (m *Memtable) checkStrategy(strategy ...string) error {
	return CheckExpectedStrategy(m.strategy, strategy...)
}

func (m *Memtable) getCollection(key []byte) ([]value, error) {
	start := time.Now()
	defer m.metrics.observeGetCollection(start.UnixNano())

	// TODO amourao: check if this is needed for StrategyInverted
	if err := m.checkStrategy(StrategySetCollection, StrategyMapCollection, StrategyInverted); err != nil {
		return nil, fmt.Errorf("Memtable::getCollection(): %w", err)
	}

	m.RLock()
	defer m.RUnlock()

	v, err := m.keyMulti.get(key)
	if err != nil {
		return nil, err
	}

	return v, nil
}

func (m *Memtable) getCollectionBytes(key []byte) ([][]byte, error) {
	start := time.Now()
	defer m.metrics.observeGetCollection(start.UnixNano())

	// TODO amourao: check if this is needed for StrategyInverted
	if m.strategy != StrategySetCollection && m.strategy != StrategyMapCollection && m.strategy != StrategyInverted {
		return nil, errors.Errorf("getCollection only possible with strategies %q, %q, %q",
			StrategySetCollection, StrategyMapCollection, StrategyInverted)
	}

	m.RLock()
	defer m.RUnlock()

	v, err := m.keyMulti.get(key)
	if err != nil {
		return nil, err
	}
	out := make([][]byte, len(v))
	for i := range v {
		out[i] = v[i].value
	}

	return out, nil
}

func (m *Memtable) getMap(key []byte) ([]MapPair, error) {
	start := time.Now()
	defer m.metrics.observeGetMap(start.UnixNano())

	if err := m.checkStrategy(StrategyMapCollection, StrategyInverted); err != nil {
		return nil, fmt.Errorf("Memtable::getMap(): %w", err)
	}

	m.RLock()
	defer m.RUnlock()

	v, err := m.keyMap.get(key)
	if err != nil {
		return nil, err
	}

	return v, nil
}

func (m *Memtable) append(key []byte, values []value) error {
	start := time.Now()
	defer m.metrics.observeAppend(start.UnixNano())

	if err := m.checkStrategy(StrategySetCollection, StrategyMapCollection); err != nil {
		return fmt.Errorf("Memtable::append(): %w", err)
	}

	m.Lock()
	defer m.Unlock()
	m.writesSinceLastSync = true

	if err := m.commitlog.append(segmentCollectionNode{
		primaryKey: key,
		values:     values,
	}); err != nil {
		return errors.Wrap(err, "write into commit log")
	}

	m.keyMulti.insert(key, values)
	m.size += uint64(len(key))
	for _, value := range values {
		m.size += uint64(len(value.value))
	}
	m.metrics.observeSize(m.size)
	m.updateDirtyAt()

	return nil
}

func (m *Memtable) appendMapSorted(key []byte, pair MapPair) error {
	start := time.Now()
	defer m.metrics.observeAppendMapSorted(start.UnixNano())

	if err := m.checkStrategy(StrategyMapCollection, StrategyInverted); err != nil {
		return fmt.Errorf("Memtable::appendMapSorted(): %w", err)
	}

	valuesForCommitLog, err := pair.Bytes()
	if err != nil {
		return err
	}

	newNode := segmentCollectionNode{
		primaryKey: key,
		values: []value{
			{
				value:     valuesForCommitLog,
				tombstone: pair.Tombstone,
			},
		},
	}

	m.Lock()
	defer m.Unlock()
	m.writesSinceLastSync = true

	if err := m.commitlog.append(newNode); err != nil {
		return errors.Wrap(err, "write into commit log")
	}

	m.keyMap.insert(key, pair)
	m.size += uint64(len(key) + len(valuesForCommitLog))
	m.metrics.observeSize(m.size)
	m.updateDirtyAt()

	if m.strategy == StrategyInverted && !pair.Tombstone {
		// Must match SetTombstone's decode (BigEndian): StrategyInverted keys are
		// always BigEndian, required for byte-wise sortability. A mismatch here
		// makes propLengthExists.Set/Remove address different bitmap positions for
		// the same doc, so SetTombstone can't re-arm the dedup gate below — a doc
		// re-added after being tombstoned in the same memtable (e.g. an update)
		// has its new prop length silently dropped instead of recounted.
		docID := binary.BigEndian.Uint64(pair.Key)
		fieldLength := math.Float32frombits(binary.LittleEndian.Uint32(pair.Value[4:]))
		// propLengthExists + currPropLength* are shared with SetTombstone, which no
		// longer holds the tree lock; guard them with invMu (nested inside m.Lock).
		m.invMu.Lock()
		if m.propLengthExists.Set(docID) {
			m.currPropLengthSum += uint64(fieldLength)
			m.currPropLengthCount++
		}
		m.invMu.Unlock()
	}

	return nil
}

func (m *Memtable) Size() uint64 {
	m.RLock()
	defer m.RUnlock()

	return m.size
}

func (m *Memtable) Path() string {
	m.RLock()
	defer m.RUnlock()

	return m.path
}

func (m *Memtable) ActiveDuration() time.Duration {
	m.RLock()
	defer m.RUnlock()

	return time.Since(m.createdAt)
}

func (m *Memtable) updateDirtyAt() {
	if m.dirtyAt.IsZero() {
		m.dirtyAt = time.Now()
	}
}

// returns time memtable got dirty (1st write occurred)
// (0 if clean)
func (m *Memtable) DirtyDuration() time.Duration {
	m.RLock()
	defer m.RUnlock()

	if m.dirtyAt.IsZero() {
		return 0
	}
	return time.Since(m.dirtyAt)
}

func (m *Memtable) countStats() *countStats {
	m.RLock()
	defer m.RUnlock()
	return m.key.countStats()
}

func (m *Memtable) netCount() int {
	m.RLock()
	defer m.RUnlock()
	return m.netCountAdditions
}

// the WAL uses a buffer and isn't written until the buffer size is crossed or
// this function explicitly called. This allows to safge unnecessary disk
// writes in larger operations, such as batches. It is sufficient to call write
// on the WAL just once. This does not make a batch atomic, but it guarantees
// that the WAL is written before a successful response is returned to the
// user.
func (m *Memtable) writeWAL() error {
	m.Lock()
	defer m.Unlock()

	return m.commitlog.flushBuffers()
}

// ReadOnlyTombstones returns a shared, immutable snapshot of the memtable's tombstones.
// Returned bitmap must not be mutated: concurrent readers hold the same instance.
func (m *Memtable) ReadOnlyTombstones() (*sroar.Bitmap, error) {
	if err := m.checkStrategy(StrategyInverted); err != nil {
		return nil, fmt.Errorf("Memtable::ReadOnlyTombstones(): %w", err)
	}
	// checkStrategy passing implies the inverted constructor ran, which sets
	// m.tombstones to a non-nil bitmap, so the Clone below never nil-derefs.

	// Lock-free fast path: an already-published snapshot is served without touching
	// the memtable RWMutex. SetTombstone clears the snapshot to nil only after mutating
	// the bitmap, so a non-nil snapshot always reflects every tombstone set before it
	// was published. A tombstone set concurrently with this load may not yet be visible,
	// which is within consistent-view semantics — the query fixes its tombstone view at
	// setup, and a delete racing the query may order either way.
	if snap := m.tombstonesSnapshot.Load(); snap != nil {
		return snap, nil
	}

	// Rebuild under invMu (the same lock SetTombstone takes), re-checking after locking
	// in case another reader already republished the snapshot.
	m.invMu.Lock()
	defer m.invMu.Unlock()
	if snap := m.tombstonesSnapshot.Load(); snap != nil {
		return snap, nil
	}
	snap := m.tombstones.Clone()
	m.tombstonesSnapshot.Store(snap)
	return snap, nil
}

func (m *Memtable) SetTombstone(docId uint64) error {
	if err := m.checkStrategy(StrategyInverted); err != nil {
		return fmt.Errorf("Memtable::SetTombstone(): %w", err)
	}

	m.invMu.Lock()
	defer m.invMu.Unlock()

	m.tombstones.Set(docId)
	m.tombstonesSnapshot.Store(nil)
	m.propLengthExists.Remove(docId)

	return nil
}

func (m *Memtable) GetPropLengths() (uint64, uint64) {
	m.invMu.RLock()
	defer m.invMu.RUnlock()

	return m.currPropLengthSum, m.currPropLengthCount
}

func (m *Memtable) incWriterCount() {
	m.writerCount.Add(1)
}

func (m *Memtable) decWriterCount() {
	m.writerCount.Add(-1)
}

func (m *Memtable) getWriterCount() int64 {
	return m.writerCount.Load()
}

func (m *Memtable) getStrategy() string {
	return m.strategy
}

func (m *Memtable) setAveragePropertyLength(avgPropLength float64, propLengthCount uint64) {
	m.Lock()
	defer m.Unlock()

	m.averagePropLength = avgPropLength
	m.propLengthCount = propLengthCount
}

func (m *Memtable) commitlogSize() int64 {
	return m.commitlog.size()
}

func (m *Memtable) commitlogWalPath() string {
	return m.commitlog.walPath()
}

func (m *Memtable) getAndUpdateWritesSinceLastSync(logger logrus.FieldLogger) bool {
	m.Lock()
	defer m.Unlock()

	hasWrites := m.writesSinceLastSync
	if !hasWrites {
		// had no work this iteration, cycle manager can back off
		return false
	}

	err := m.commitlog.flushBuffers()
	if err != nil {
		logger.WithField("action", "lsm_memtable_flush").
			WithField("path", m.path).
			WithError(err).
			Errorf("flush and switch failed")

		return false
	}

	err = m.commitlog.sync()
	if err != nil {
		logger.WithField("action", "lsm_memtable_flush").
			WithField("path", m.path).
			WithError(err).
			Errorf("flush and switch failed")

		return false
	}
	m.writesSinceLastSync = false
	// there was work in this iteration, cycle manager should not back off and revisit soon
	return true
}

func (m *Memtable) extractRoaringSetRange() *roaringsetrange.Memtable {
	m.RLock()
	defer m.RUnlock()

	result := m.roaringSetRange
	return result
}
