//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"context"
	"encoding/binary"
	"testing"

	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/weaviate/weaviate/entities/lsmkv"
)

// Previous implementation of cursor called recursively Next() when empty entry occurred,
// which could lead to stack overflow. This test prevents a regression.
func TestMapCursor_StackOverflow(t *testing.T) {
	cursor := &CursorMap{
		unlock:       func() {},
		innerCursors: []innerCursorMap{&emptyInnerCursorMap{}},
		listCfg:      MapListOptionConfig{},
		keyOnly:      false,
	}

	k, mp := cursor.First(context.Background())
	assert.Nil(t, k)
	assert.Nil(t, mp)
}

type emptyInnerCursorMap struct {
	key uint64
}

func (c *emptyInnerCursorMap) first() ([]byte, []MapPair, error) {
	c.key = 0
	return c.bytes(), []MapPair{}, nil
}

func (c *emptyInnerCursorMap) next() ([]byte, []MapPair, error) {
	if c.key >= 1<<20 {
		return nil, nil, lsmkv.NotFound
	}
	c.key++
	return c.bytes(), []MapPair{}, nil
}

func (c *emptyInnerCursorMap) seek(key []byte) ([]byte, []MapPair, error) {
	return c.first()
}

func (c *emptyInnerCursorMap) bytes() []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, c.key)
	return b
}

func TestMapCursorConsistentView(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	logger, _ := test.NewNullLogger()

	// Initial disk: two segments A (key1->{1}) and B (key2->{2})
	diskSegments := &SegmentGroup{
		logger: logger,
		segments: []Segment{
			newFakeMapSegment(map[string][]MapPair{
				"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
			}),
			newFakeMapSegment(map[string][]MapPair{
				"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
			}),
		},
	}

	// Active memtable contains key3->{3}
	initialMemtable := newTestMemtableMap(map[string][]MapPair{
		"key3": {{Key: []byte("ak1"), Value: []byte("av1")}},
	})

	b := Bucket{
		active:   initialMemtable,
		disk:     diskSegments,
		strategy: StrategyMapCollection,
		logger:   nullLogger(),
	}

	// Open the cursor that should see key1..key3 only and stay stable
	cur, err := b.MapCursor()
	require.NoError(t, err)
	validateOriginalCursorView := func(t *testing.T, c *CursorMap) {
		expected := map[string][]MapPair{
			"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
			"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
			"key3": {{Key: []byte("ak1"), Value: []byte("av1")}},
		}

		actual := map[string][]MapPair{}
		for k, vs := c.First(ctx); k != nil; k, vs = c.Next(ctx) {
			actual[string(k)] = vs
		}

		require.Equal(t, expected, actual)
	}
	validateOriginalCursorView(t, cur)

	// 2) Switch memtables (new empty active, old active -> flushing)
	switched, err := b.atomicallySwitchMemtable(func() (memtable, error) {
		return newTestMemtableMap(nil), nil
	})
	require.NoError(t, err)
	require.True(t, switched)

	// Cursor remains stable (still key1..key3)
	validateOriginalCursorView(t, cur)

	// 3) New write to the new active: key4->{4}
	require.NoError(t, b.MapSet([]byte("key4"), MapPair{
		Key: []byte("ak2"), Value: []byte("av2"),
	}))

	// Cursor must still NOT see key4
	validateOriginalCursorView(t, cur)

	// 4) Flush the flushing memtable (which holds key3) to disk as segment C
	segC := flushMapTestMemtableIntoTestSegment(b.flushing)
	b.atomicallyAddDiskSegmentAndRemoveFlushing(segC)

	// Cursor remains unchanged
	validateOriginalCursorView(t, cur)

	// 5) Compact disk segments while cursor is open:
	//    initial: A, B, C
	//    compaction #1: A+B, C
	segAB := newFakeMapSegment(map[string][]MapPair{
		"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
		"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
	})
	newSegmentReplacer(b.disk, 0, 1, segAB).switchInMemory()

	//    compaction #2: (A+B) + C  => ABC
	segABC := newFakeMapSegment(map[string][]MapPair{
		"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
		"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
		"key3": {{Key: []byte("ak1"), Value: []byte("av1")}},
	})
	newSegmentReplacer(b.disk, 0, 1, segABC).switchInMemory()

	// Cursor still sees only key1..key3
	validateOriginalCursorView(t, cur)
	cur.Close()

	// 6) A new cursor now sees the latest state: key1..key4 (key4 is in active)
	cur2, err := b.MapCursor()
	require.NoError(t, err)
	defer cur2.Close()

	expected := map[string][]MapPair{
		"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
		"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
		"key3": {{Key: []byte("ak1"), Value: []byte("av1")}},
		"key4": {{Key: []byte("ak2"), Value: []byte("av2")}},
	}

	actual := map[string][]MapPair{}
	for k, v := cur2.First(ctx); k != nil; k, v = cur2.Next(ctx) {
		actual[string(k)] = v
	}
	require.Equal(t, expected, actual)
}

// MapCursorKeyOnly must walk every primary key just like MapCursor — it just
// drops the values from the returned tuple. Regression for a bug where the
// keyOnly fast-path left state[i].value=nil, the merger saw only empty
// per-segment results, and every key was skipped (callers like
// filterableToSearchableMigrator.isEmptyMapBucket then misclassified
// non-empty buckets as empty).
func TestMapCursorKeyOnly(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	logger, _ := test.NewNullLogger()

	diskSegments := &SegmentGroup{
		logger: logger,
		segments: []Segment{
			newFakeMapSegment(map[string][]MapPair{
				"key1": {{Key: []byte("dk1"), Value: []byte("dv1")}},
			}),
			newFakeMapSegment(map[string][]MapPair{
				"key2": {{Key: []byte("dk2"), Value: []byte("dv2")}},
			}),
		},
	}

	active := newTestMemtableMap(map[string][]MapPair{
		"key3": {{Key: []byte("ak1"), Value: []byte("av1")}},
	})

	b := Bucket{
		active:   active,
		disk:     diskSegments,
		strategy: StrategyMapCollection,
		logger:   nullLogger(),
	}

	cur, err := b.MapCursorKeyOnly()
	require.NoError(t, err)
	defer cur.Close()

	var keys []string
	for k, v := cur.First(ctx); k != nil; k, v = cur.Next(ctx) {
		assert.Nil(t, v, "keyOnly cursor must not return values")
		keys = append(keys, string(k))
	}
	require.Equal(t, []string{"key1", "key2", "key3"}, keys)
}

// Mirrors the filterableToSearchableMigrator.isEmptyMapBucket usage: only the
// first key is read. If the cursor's keyOnly path is broken, this looks like
// an empty bucket even though it has data.
func TestMapCursorKeyOnly_FirstKeyOnNonEmptyBucket(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	logger, _ := test.NewNullLogger()

	b := Bucket{
		active: newTestMemtableMap(map[string][]MapPair{
			"only": {{Key: []byte("sk"), Value: []byte("sv")}},
		}),
		disk:     &SegmentGroup{logger: logger},
		strategy: StrategyMapCollection,
		logger:   logger,
	}

	cur, err := b.MapCursorKeyOnly()
	require.NoError(t, err)
	defer cur.Close()

	k, _ := cur.First(ctx)
	require.Equal(t, []byte("only"), k)
}

// A cancelled context must end iteration like exhaustion (nil, nil), not
// panic. The sorted-map merger returns ctx.Err() and the cursor used to
// escalate every merger error to a panic ("unexpected error decoding map
// values: context canceled").
func TestMapCursor_CancelledContext(t *testing.T) {
	t.Parallel()

	logger, _ := test.NewNullLogger()

	newBucket := func() *Bucket {
		return &Bucket{
			active: newTestMemtableMap(map[string][]MapPair{
				"key1": {{Key: []byte("k1"), Value: []byte("v1")}},
				"key2": {{Key: []byte("k2"), Value: []byte("v2")}},
			}),
			disk:     &SegmentGroup{logger: logger},
			strategy: StrategyMapCollection,
			logger:   logger,
		}
	}

	t.Run("First with already-cancelled context", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		cur, err := newBucket().MapCursor()
		require.NoError(t, err)
		defer cur.Close()

		k, v := cur.First(ctx)
		assert.Nil(t, k)
		assert.Nil(t, v)
	})

	t.Run("cancel between Next calls", func(t *testing.T) {
		ctx, cancel := context.WithCancel(context.Background())

		cur, err := newBucket().MapCursor()
		require.NoError(t, err)
		defer cur.Close()

		k, _ := cur.First(ctx)
		require.Equal(t, []byte("key1"), k)

		cancel()
		k, v := cur.Next(ctx)
		assert.Nil(t, k)
		assert.Nil(t, v)
	})
}

// A key that is live on disk but tombstoned in the newer active memtable must
// NOT surface from a keyOnly cursor. This guards the merge semantics from the
// opposite direction of TestMapCursorKeyOnly: capturing values (needed to walk
// keys) must not resurface deleted keys. The tombstone lives in the memtable
// because the fake disk segment can't represent one.
func TestMapCursorKeyOnly_TombstonedKeyDropped(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	logger, _ := test.NewNullLogger()

	diskSegments := &SegmentGroup{
		logger: logger,
		segments: []Segment{
			// disk (older): both keys live
			newFakeMapSegment(map[string][]MapPair{
				"gone": {{Key: []byte("d1"), Value: []byte("v1")}},
				"keep": {{Key: []byte("d2"), Value: []byte("v2")}},
			}),
		},
	}

	b := Bucket{
		// active memtable (newer) tombstones "gone"'s only entry
		active: newTestMemtableMap(map[string][]MapPair{
			"gone": {{Key: []byte("d1"), Tombstone: true}},
		}),
		disk:     diskSegments,
		strategy: StrategyMapCollection,
		logger:   nullLogger(),
	}

	cur, err := b.MapCursorKeyOnly()
	require.NoError(t, err)
	defer cur.Close()

	var keys []string
	for k, v := cur.First(ctx); k != nil; k, v = cur.Next(ctx) {
		assert.Nil(t, v, "keyOnly cursor must not return values")
		keys = append(keys, string(k))
	}
	require.Equal(t, []string{"keep"}, keys, "a fully tombstoned key must not appear")
}
