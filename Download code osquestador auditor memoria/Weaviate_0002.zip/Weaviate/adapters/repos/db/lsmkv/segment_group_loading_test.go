//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/sirupsen/logrus"

	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/require"
	"github.com/weaviate/weaviate/entities/cyclemanager"
)

func TestCompactionCleanupBothSegmentsPresent(t *testing.T) {
	logger, _ := test.NewNullLogger()

	ctx := context.Background()

	// Tests that various states of the compaction being aborted are handled correctly
	// There are 3 files involved:
	// 1. The combined segment that is still a tmp file
	// 2+3. The two source segment files
	tests := []struct {
		name             string
		copyLeft         bool
		copyRight        bool
		expectErr        bool
		expectedSegments int
	}{
		{name: "only left present", copyLeft: true, copyRight: false, expectErr: true},
		{name: "only right present", copyLeft: false, copyRight: true, expectErr: false, expectedSegments: 1},
		{name: "nothing present", copyLeft: false, copyRight: false, expectErr: false, expectedSegments: 1},
		{name: "both present", copyLeft: true, copyRight: true, expectErr: false, expectedSegments: 2},
	}

	for _, tt := range tests {
		for _, addFileInfo := range []bool{true, false} {
			dirName := t.TempDir()
			tmpDir := t.TempDir()
			entriesTmp := createSegmentFiles(t, ctx, logger, dirName, tmpDir, []bool{addFileInfo})
			t.Run(tt.name, func(t *testing.T) {
				testDir := t.TempDir()
				if tt.copyLeft {
					copyFile(t, tmpDir+"/"+entriesTmp[0].Name(), testDir+"/"+entriesTmp[0].Name())
				}
				if tt.copyRight {
					copyFile(t, tmpDir+"/"+entriesTmp[2].Name(), testDir+"/"+entriesTmp[2].Name())
				}
				// always copy the combined file
				copyFile(t, tmpDir+"/"+entriesTmp[1].Name(), testDir+"/"+entriesTmp[1].Name())

				b2, err := NewBucketCreator().NewBucket(ctx, testDir, "", logger, nil,
					cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(addFileInfo), WithCalcCountNetAdditions(true), WithStrategy(StrategyReplace),
				)
				if tt.expectErr {
					// the only failing case is the missing right segment, which the
					// operator can only act on if both files are named
					require.ErrorContains(t, err, entriesTmp[1].Name())
					require.ErrorContains(t, err, segmentID(entriesTmp[2].Name()))
				} else {
					require.NoError(t, err)
					count, err := b2.Count(ctx)
					require.NoError(t, err)
					require.Equal(t, 20, count)
					entries, err := os.ReadDir(testDir)
					require.NoError(t, err)
					for _, entry := range entries {
						if filepath.Ext(entry.Name()) == ".db" {
							require.NotContains(t, entry.Name(), "_")
						}
					}
					require.Len(t, b2.disk.segments, tt.expectedSegments)
					for _, segment := range b2.disk.segments {
						path := segment.getPath()
						file := filepath.Base(path)
						require.NotContains(t, file, "_")
					}

					if !tt.copyLeft {
						// with the left source gone the combined file is taken over
						// under the name the interrupted switch would have given it,
						// level and strategy included
						extraInfo := ""
						if addFileInfo {
							extraInfo = ".l1.s0"
						}
						require.FileExists(t, filepath.Join(testDir, fmt.Sprintf("segment-%s%s.db",
							segmentID(entriesTmp[2].Name()), extraInfo)))
					}
				}
			})
		}
	}
}

func TestCompactionCleanupBothSegmentsPresentUpgrade(t *testing.T) {
	logger, _ := test.NewNullLogger()

	ctx := context.Background()

	// Tests that various states of the compaction being aborted are handled correctly
	// There are 3 files involved:
	// 1. The combined segment that is still a tmp file
	// 2+3. The two source segment files
	tests := []struct {
		name             string
		copyLeft         bool
		copyRight        bool
		expectErr        bool
		expectedSegments int
	}{
		{name: "only left present", copyLeft: true, copyRight: false, expectErr: true},
		{name: "only right present", copyLeft: false, copyRight: true, expectErr: false, expectedSegments: 1},
		{name: "nothing present", copyLeft: false, copyRight: false, expectErr: false, expectedSegments: 1},
		{name: "both present", copyLeft: true, copyRight: true, expectErr: false, expectedSegments: 2},
	}

	for _, tt := range tests {
		fileInfos := []struct {
			sourceFileLeft   bool
			sourceFileRight  bool
			compactedTmpFile bool
			loadingBucket    bool
		}{
			{sourceFileLeft: true, sourceFileRight: true, compactedTmpFile: false, loadingBucket: false},
			{sourceFileLeft: true, sourceFileRight: true, compactedTmpFile: true, loadingBucket: false},
			{sourceFileLeft: false, sourceFileRight: false, compactedTmpFile: true, loadingBucket: false},
			{sourceFileLeft: false, sourceFileRight: true, compactedTmpFile: true, loadingBucket: false},
			{sourceFileLeft: false, sourceFileRight: true, compactedTmpFile: false, loadingBucket: true},
			{sourceFileLeft: false, sourceFileRight: false, compactedTmpFile: true, loadingBucket: true},
			{sourceFileLeft: false, sourceFileRight: false, compactedTmpFile: false, loadingBucket: true},
			{sourceFileLeft: true, sourceFileRight: false, compactedTmpFile: true, loadingBucket: true},
		}
		for _, fileInfo := range fileInfos {
			dirName := t.TempDir()
			tmpDir := t.TempDir()
			entriesTmp := createSegmentFiles(t, ctx, logger, dirName, tmpDir, []bool{fileInfo.sourceFileLeft, fileInfo.sourceFileRight, fileInfo.compactedTmpFile})
			t.Run(tt.name, func(t *testing.T) {
				testDir := t.TempDir()
				if tt.copyLeft {
					copyFile(t, tmpDir+"/"+entriesTmp[0].Name(), testDir+"/"+entriesTmp[0].Name())
				}
				if tt.copyRight {
					copyFile(t, tmpDir+"/"+entriesTmp[2].Name(), testDir+"/"+entriesTmp[2].Name())
				}
				// always copy the combined file
				copyFile(t, tmpDir+"/"+entriesTmp[1].Name(), testDir+"/"+entriesTmp[1].Name())

				b2, err := NewBucketCreator().NewBucket(ctx, testDir, "", logger, nil,
					cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(fileInfo.loadingBucket), WithCalcCountNetAdditions(true), WithStrategy(StrategyReplace),
				)
				if tt.expectErr {
					require.Error(t, err)
				} else {
					require.NoError(t, err)
					count, err := b2.Count(ctx)
					require.NoError(t, err)

					require.Equal(t, 20, count)
					entries, err := os.ReadDir(testDir)
					require.NoError(t, err)
					for _, entry := range entries {
						if filepath.Ext(entry.Name()) == ".db" {
							require.NotContains(t, entry.Name(), "_")
						}
					}
					require.Len(t, b2.disk.segments, tt.expectedSegments)
					for _, segment := range b2.disk.segments {
						path := segment.getPath()
						file := filepath.Base(path)
						require.NotContains(t, file, "_")
					}
				}
			})
		}
	}
}

// TestSegmentGroupInit_RemovesStrayTempFiles pins the recovery-loop behavior
// that a segment sidecar .tmp left behind by a crash during a compaction/cleanup
// switch (e.g. a precomputed segment-X.bloom.tmp) is removed on init, while a
// .tmp not belonging to a segment is left untouched.
func TestSegmentGroupInit_RemovesStrayTempFiles(t *testing.T) {
	logger, _ := test.NewNullLogger()
	ctx := context.Background()

	tests := []struct {
		name    string
		file    string
		removed bool
	}{
		{name: "stray bloom tmp", file: "segment-1700000000000000000.bloom.tmp", removed: true},
		{name: "stray cna tmp", file: "segment-1700000000000000000.cna.tmp", removed: true},
		{name: "stray metadata tmp", file: "segment-1700000000000000000.metadata.tmp", removed: true},
		{name: "stray secondary bloom tmp", file: "segment-1700000000000000000.secondary.0.bloom.tmp", removed: true},
		{name: "non-segment tmp preserved", file: "something-else.tmp", removed: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dir := t.TempDir()
			path := filepath.Join(dir, tt.file)
			require.NoError(t, os.WriteFile(path, []byte("x"), 0o644))

			b, err := NewBucketCreator().NewBucket(ctx, dir, "", logger, nil,
				cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(),
				WithUseBloomFilter(false), WithStrategy(StrategyReplace))
			require.NoError(t, err)
			defer b.Shutdown(ctx)

			_, statErr := os.Stat(path)
			if tt.removed {
				require.True(t, os.IsNotExist(statErr), "expected %q to be removed on init", tt.file)
			} else {
				require.NoError(t, statErr, "expected %q to be preserved", tt.file)
			}
		})
	}
}

// TestCompactionRecoveryDropsRightSegmentDerivedFiles covers an aborted
// compaction where only the right source segment is left: it is deleted
// together with its derived files, and the compacted segment takes over its
// name, so those derived files must not be looked up when it is loaded.
func TestCompactionRecoveryDropsRightSegmentDerivedFiles(t *testing.T) {
	logger, _ := test.NewNullLogger()
	ctx := context.Background()

	tests := []struct {
		name             string
		useBloomFilter   bool
		calcCNA          bool
		writeMetadata    bool
		secondaryIndices uint16
		infoInFileName   bool
		// enable the metadata file only for the recovering bucket, so the segments
		// on disk still have separate derived files
		metadataOnRecovery bool
		// number of derived files per extension expected after the recovery
		wantDerivedFiles map[string]int
	}{
		{
			name: "cna", calcCNA: true, infoInFileName: true,
			wantDerivedFiles: map[string]int{".cna": 1},
		},
		{
			name: "bloom filter", useBloomFilter: true, infoInFileName: true,
			wantDerivedFiles: map[string]int{".bloom": 1},
		},
		{
			name: "bloom filter and cna", useBloomFilter: true, calcCNA: true, infoInFileName: true,
			wantDerivedFiles: map[string]int{".bloom": 1, ".cna": 1},
		},
		{
			name: "secondary bloom filters", useBloomFilter: true, calcCNA: true, secondaryIndices: 2, infoInFileName: true,
			wantDerivedFiles: map[string]int{".bloom": 3, ".cna": 1},
		},
		{
			name: "metadata", useBloomFilter: true, calcCNA: true, writeMetadata: true, infoInFileName: true,
			wantDerivedFiles: map[string]int{".metadata": 1},
		},
		{
			name: "metadata enabled on recovery", useBloomFilter: true, calcCNA: true, metadataOnRecovery: true, infoInFileName: true,
			wantDerivedFiles: map[string]int{".metadata": 1},
		},
		{
			name: "without segment info in file name", useBloomFilter: true, calcCNA: true, infoInFileName: false,
			wantDerivedFiles: map[string]int{".bloom": 1, ".cna": 1},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			opts := []BucketOption{
				WithStrategy(StrategyReplace),
				WithUseBloomFilter(tt.useBloomFilter),
				WithCalcCountNetAdditions(tt.calcCNA),
				WithWriteMetadata(tt.writeMetadata),
				WithSecondaryIndices(tt.secondaryIndices),
				WithWriteSegmentInfoIntoFileName(tt.infoInFileName),
			}

			srcDir := t.TempDir()
			b, err := NewBucketCreator().NewBucket(ctx, srcDir, "", logger, nil,
				cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), opts...)
			require.NoError(t, err)

			for i := range 20 {
				var secondaryKeys []SecondaryKeyOption
				for pos := range int(tt.secondaryIndices) {
					secondaryKeys = append(secondaryKeys, WithSecondaryKey(pos, fmt.Appendf(nil, "sec%d-%d", pos, i)))
				}
				require.NoError(t, b.Put(fmt.Appendf(nil, "hello%d", i), fmt.Appendf(nil, "world%d", i), secondaryKeys...))
				if i == 9 {
					require.NoError(t, b.FlushMemtable())
				}
			}
			require.NoError(t, b.FlushMemtable())
			require.Len(t, b.disk.segments, 2)

			leftID := segmentID(filepath.Base(b.disk.segments[0].getPath()))
			rightID := segmentID(filepath.Base(b.disk.segments[1].getPath()))

			// keep the right segment and its derived files as they were before the
			// compaction started
			backupDir := t.TempDir()
			copyFilesWithPrefix(t, srcDir, backupDir, "segment-"+rightID+".")

			once, err := b.disk.compactOnce(ctx)
			require.NoError(t, err)
			require.True(t, once)
			require.NoError(t, b.Shutdown(ctx))

			// the compacted segment is still a tmp file, the left source segment is
			// already gone
			extraInfo := ""
			if tt.infoInFileName {
				extraInfo = ".l1.s0"
			}
			testDir := t.TempDir()
			copyFile(t, filepath.Join(srcDir, singleDbFile(t, srcDir)),
				filepath.Join(testDir, fmt.Sprintf("segment-%s_%s%s.db.tmp", leftID, rightID, extraInfo)))
			copyFilesWithPrefix(t, backupDir, testDir, "segment-")

			recoveryOpts := opts
			if tt.metadataOnRecovery {
				recoveryOpts = append(slices.Clone(opts), WithWriteMetadata(true))
			}
			b2, err := NewBucketCreator().NewBucket(ctx, testDir, "", logger, nil,
				cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), recoveryOpts...)
			require.NoError(t, err)
			defer b2.Shutdown(ctx)

			for i := range 20 {
				value, err := b2.Get(fmt.Appendf(nil, "hello%d", i))
				require.NoError(t, err)
				require.Equal(t, fmt.Sprintf("world%d", i), string(value))
			}

			// the adopted file keeps the level the compaction put into the .tmp
			// name, which is not the level of the segment it replaces
			require.Equal(t, fmt.Sprintf("segment-%s%s.db", rightID, extraInfo),
				singleDbFile(t, testDir))

			fileTypes := countFileTypes(t, testDir)
			for _, ext := range []string{".bloom", ".cna", ".metadata"} {
				require.Equal(t, tt.wantDerivedFiles[ext], fileTypes[ext], "number of %s files", ext)
			}
		})
	}
}

// TestCompactionRecoveryOrdersLeftoverSegments pins that leftover compacted
// segments are recovered in a fixed order: adopting one of them decides which
// source segments the next one still finds.
func TestCompactionRecoveryOrdersLeftoverSegments(t *testing.T) {
	logger, _ := test.NewNullLogger()
	ctx := context.Background()

	opts := []BucketOption{WithStrategy(StrategyReplace), WithUseBloomFilter(false)}

	srcDir := t.TempDir()
	b, err := NewBucketCreator().NewBucket(ctx, srcDir, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), opts...)
	require.NoError(t, err)

	// three segments of different sizes, so that a segment replaced by another
	// one is recognizable by its content
	for _, keys := range []int{5, 10, 15} {
		for i := range keys {
			require.NoError(t, b.Put(fmt.Appendf(nil, "hello%d", i), fmt.Appendf(nil, "world%d", i)))
		}
		require.NoError(t, b.FlushMemtable())
	}
	require.Len(t, b.disk.segments, 3)

	var ids []string
	for _, seg := range b.disk.segments {
		ids = append(ids, segmentID(filepath.Base(seg.getPath())))
	}
	require.NoError(t, b.Shutdown(ctx))

	// two compactions were interrupted before their switch completed, the second
	// one over the output of the first
	fixtureDir := t.TempDir()
	copyFile(t, filepath.Join(srcDir, "segment-"+ids[0]+".db"),
		filepath.Join(fixtureDir, fmt.Sprintf("segment-%s_%s.db.tmp", ids[0], ids[1])))
	copyFile(t, filepath.Join(srcDir, "segment-"+ids[1]+".db"),
		filepath.Join(fixtureDir, fmt.Sprintf("segment-%s_%s.db.tmp", ids[1], ids[2])))
	copyFile(t, filepath.Join(srcDir, "segment-"+ids[2]+".db"),
		filepath.Join(fixtureDir, "segment-"+ids[2]+".db"))

	newest, err := os.ReadFile(filepath.Join(fixtureDir, "segment-"+ids[2]+".db"))
	require.NoError(t, err)

	// a single run could pick the right order by chance
	const runs = 20
	for range runs {
		testDir := t.TempDir()
		copyFilesWithPrefix(t, fixtureDir, testDir, "segment-")

		b2, err := NewBucketCreator().NewBucket(ctx, testDir, "", logger, nil,
			cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), opts...)
		require.NoError(t, err)

		recovered, err := os.ReadFile(filepath.Join(testDir, "segment-"+ids[2]+".db"))
		require.NoError(t, err)
		require.Equal(t, newest, recovered, "the newest segment must not be replaced")
		require.NoError(t, b2.Shutdown(ctx))
	}
}

func copyFilesWithPrefix(t *testing.T, srcDir, destDir, prefix string) {
	t.Helper()
	entries, err := os.ReadDir(srcDir)
	require.NoError(t, err)
	for _, entry := range entries {
		if strings.HasPrefix(entry.Name(), prefix) {
			copyFile(t, filepath.Join(srcDir, entry.Name()), filepath.Join(destDir, entry.Name()))
		}
	}
}

func singleDbFile(t *testing.T, dir string) string {
	t.Helper()
	entries, err := os.ReadDir(dir)
	require.NoError(t, err)
	var found []string
	for _, entry := range entries {
		if filepath.Ext(entry.Name()) == ".db" {
			found = append(found, entry.Name())
		}
	}
	require.Len(t, found, 1)
	return found[0]
}

func copyFile(t *testing.T, src, dest string) {
	t.Helper()
	target, err := os.Create(dest)
	require.NoError(t, err)

	source, err := os.Open(src)
	require.NoError(t, err)

	_, err = io.Copy(target, source)
	require.NoError(t, err)
	require.NoError(t, source.Sync())
	require.NoError(t, source.Close())
	require.NoError(t, target.Sync())
	require.NoError(t, target.Close())
}

func TestWalFilePresent(t *testing.T) {
	logger, _ := test.NewNullLogger()

	ctx := context.Background()
	dirName := t.TempDir()
	b, err := NewBucketCreator().NewBucket(ctx, dirName, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(true), WithStrategy(StrategyReplace),
	)

	// create "incomplete" segment
	require.NoError(t, err)
	require.NoError(t, b.Put([]byte("hello0"), []byte("world0")))
	require.NoError(t, b.Put([]byte("hello1"), []byte("world1")))
	require.NoError(t, b.FlushMemtable())

	// create wal file with more entries
	require.NoError(t, b.Put([]byte("hello0"), []byte("world0")))
	require.NoError(t, b.Put([]byte("hello1"), []byte("world1")))
	require.NoError(t, b.Put([]byte("hello2"), []byte("world2")))
	require.NoError(t, b.Shutdown(ctx))

	dbFiles, walFiles := countDbAndWalFiles(t, dirName)
	require.Equal(t, dbFiles, 1)
	require.Equal(t, walFiles, 1)

	// .wal file needs same (base)name as segment file
	entries, err := os.ReadDir(dirName)
	require.NoError(t, err)
	var segmentId string
	for _, entry := range entries {
		if filepath.Ext(entry.Name()) == ".db" {
			segmentId = segmentID(entry.Name())
		}
	}

	for _, entry := range entries {
		if filepath.Ext(entry.Name()) == ".wal" {
			require.NoError(t, os.Rename(dirName+"/"+entry.Name(), dirName+"/"+"segment-"+segmentId+".wal"))
		}
	}

	// incomplete segment will be deleted and memtable is reconstructed from .wal
	b2, err := NewBucketCreator().NewBucket(ctx, dirName, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(true), WithStrategy(StrategyReplace),
	)
	require.NoError(t, err)

	val, err := b2.Get([]byte("hello2"))
	require.NoError(t, err)
	require.Equal(t, string(val), "world2")

	dbFiles, walFiles = countDbAndWalFiles(t, dirName)
	require.Equal(t, dbFiles, 0)
	require.Equal(t, walFiles, 1)
}

func TestComputeNetCountAfterCompaction(t *testing.T) {
	logger, _ := test.NewNullLogger()

	ctx := context.Background()

	finalTestDir := t.TempDir()
	b, err := NewBucketCreator().NewBucket(ctx, finalTestDir, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithCalcCountNetAdditions(true), WithStrategy(StrategyReplace),
	)
	require.NoError(t, err)

	// create separate segments for each entry
	require.NoError(t, b.Put([]byte("hello1"), []byte("world1")))
	require.NoError(t, b.FlushMemtable())
	require.NoError(t, b.Put([]byte("hello2"), []byte("world2")))
	require.NoError(t, b.FlushMemtable())
	require.NoError(t, b.Put([]byte("hello3"), []byte("world3")))
	require.NoError(t, b.FlushMemtable())
	require.NoError(t, b.Put([]byte("hello4"), []byte("world4")))
	require.NoError(t, b.FlushMemtable())

	count, err := b.Count(ctx)
	require.NoError(t, err)
	require.Equal(t, 4, count)
	require.NoError(t, b.Shutdown(ctx))

	fileTypes := getFileTypeCount(t, finalTestDir)
	require.Equal(t, 4, fileTypes[".db"])
	require.Equal(t, 0, fileTypes[".wal"])
	require.Equal(t, 4, fileTypes[".cna"])

	oldSegmentID := fmt.Sprintf("%v", time.Now().UnixNano())

	require.NoError(t, b.Delete([]byte("hello1")))
	require.NoError(t, b.Delete([]byte("hello2")))
	require.NoError(t, b.Delete([]byte("hello3")))
	require.NoError(t, b.Delete([]byte("hello4")))
	require.NoError(t, b.FlushMemtable())

	// rename new segment file so it looks like a compaction output after a crash - we only need to cover the case where
	// none of the source files are present and the combined segment is kept
	entriesTmp, err := os.ReadDir(finalTestDir)
	require.NoError(t, err)
	require.NoError(t, os.Rename(finalTestDir+"/"+entriesTmp[len(entriesTmp)-1].Name(), finalTestDir+"/"+"segment-"+oldSegmentID+"_"+fmt.Sprintf("%v", time.Now().UnixNano())+".db.tmp"))

	// recover after "crash"
	b, err = NewBucketCreator().NewBucket(ctx, finalTestDir, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithCalcCountNetAdditions(true), WithStrategy(StrategyReplace),
	)
	require.NoError(t, err)
	count, err = b.Count(ctx)
	require.NoError(t, err)
	require.Equal(t, 0, count)
}

func createSegmentFiles(t *testing.T, ctx context.Context, logger logrus.FieldLogger, dirName, tmpDir string, addFileInfo []bool) []os.DirEntry {
	t.Helper()
	if len(addFileInfo) == 1 {
		addFileInfo = []bool{addFileInfo[0], addFileInfo[0], addFileInfo[0]}
	}

	b, err := NewBucketCreator().NewBucket(ctx, dirName, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(addFileInfo[0]), WithStrategy(StrategyReplace),
	)
	require.NoError(t, err)
	for i := 0; i < 10; i++ {
		require.NoError(t, b.Put([]byte(fmt.Sprintf("hello%d", i)), []byte(fmt.Sprintf("world%d", i))))
	}
	require.NoError(t, b.FlushMemtable())
	dbFiles, walFiles := countDbAndWalFiles(t, dirName)
	require.Equal(t, dbFiles, 1)
	require.Equal(t, walFiles, 0)
	require.NoError(t, b.Shutdown(ctx))

	b, err = NewBucketCreator().NewBucket(ctx, dirName, "", logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(), WithUseBloomFilter(false), WithWriteSegmentInfoIntoFileName(addFileInfo[1]), WithStrategy(StrategyReplace),
	)
	require.NoError(t, err)

	for i := 10; i < 20; i++ {
		require.NoError(t, b.Put([]byte(fmt.Sprintf("hello%d", i)), []byte(fmt.Sprintf("world%d", i))))
	}
	require.NoError(t, b.Put([]byte("hello1"), []byte("newworld")))
	require.NoError(t, b.FlushMemtable())
	dbFiles, walFiles = countDbAndWalFiles(t, dirName)
	require.Equal(t, dbFiles, 2)
	require.Equal(t, walFiles, 0)

	// copy segments to safe place
	var segments []string
	entriesTmp, err := os.ReadDir(dirName)
	require.NoError(t, err)
	for _, entry := range entriesTmp {
		if filepath.Ext(entry.Name()) == ".db" {
			copyFile(t, dirName+"/"+entry.Name(), tmpDir+"/"+entry.Name())
			segments = append(segments, segmentID(entry.Name()))
		}
	}

	once, err := b.disk.compactOnce(context.Background())
	require.NoError(t, err)
	require.True(t, once)
	dbFiles, walFiles = countDbAndWalFiles(t, dirName)
	require.Equal(t, dbFiles, 1)
	require.Equal(t, walFiles, 0)
	require.NoError(t, b.Shutdown(ctx))

	// move compacted segment to safe place
	entries, err := os.ReadDir(dirName)
	require.NoError(t, err)
	for _, entry := range entries {
		if filepath.Ext(entry.Name()) == ".db" {
			ext := ".db.tmp"
			if addFileInfo[2] {
				ext = ".l1.s0" + ext
			}
			require.NoError(t, os.Rename(dirName+"/"+entry.Name(), tmpDir+"/"+"segment-"+segments[0]+"_"+segments[1]+ext))
		}
	}

	// order after sorting is:
	// 0: left segment
	// 1: combined segment
	// 2: right segment
	entriesTmp, err = os.ReadDir(tmpDir)
	sort.Slice(entriesTmp, func(i, j int) bool {
		return entriesTmp[i].Name() < entriesTmp[j].Name()
	})
	require.NoError(t, err)
	return entriesTmp
}
