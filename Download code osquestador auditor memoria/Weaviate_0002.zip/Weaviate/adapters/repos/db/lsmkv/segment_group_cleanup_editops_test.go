//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"context"
	"errors"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/sirupsen/logrus/hooks/test"
	"github.com/stretchr/testify/require"
	"github.com/weaviate/weaviate/adapters/repos/db/lsmkv/editops"
	"github.com/weaviate/weaviate/entities/cyclemanager"
)

func prefixTransformer(className string, ops []ActiveOp) func([]byte) ([]byte, error) {
	return func(v []byte) ([]byte, error) { return append([]byte("X:"), v...), nil }
}

// denyAllocChecker always reports memory pressure, forcing the cleanup OOM guard.
type denyAllocChecker struct{}

func (denyAllocChecker) CheckAlloc(int64) error                  { return errors.New("no memory") }
func (denyAllocChecker) CheckMappingAndReserve(int64, int) error { return nil }
func (denyAllocChecker) Refresh(bool)                            {}

// newReplaceBucketWithEditOps wires a real cleaner (cleanupInterval > 0) plus an
// edit-ops facility, with a long cleanup interval so the time/size heuristic would
// never fire — proving the edit-ops path bypasses it. The facility is attached
// directly with an injected resolver so tests can use a fake transformer (and, for
// factory == nil, an empty resolver that yields a nil transformer to exercise the
// don't-mark-done guard). Owned by the segment group and closed on bucket shutdown.
func newReplaceBucketWithEditOps(t *testing.T, factory OpTransformerFactory) (*Bucket, *SegmentEditOps) {
	t.Helper()
	ctx := context.Background()
	dir := t.TempDir()
	logger, _ := test.NewNullLogger()

	bucket, err := NewBucketCreator().NewBucket(ctx, dir, dir, logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(),
		WithStrategy(StrategyReplace), WithSegmentsCleanupInterval(time.Hour))
	require.NoError(t, err)
	bucket.SetMemtableThreshold(1e9)

	transformers := map[OpType]OpTransformerFactory{}
	if factory != nil {
		transformers[OpTypeRemoveTargetVectors] = factory
	}
	bucket.disk.editOps = newSegmentEditOpsWithLookup(bucket.disk.dir, "TestClass", staticResolver(transformers))

	t.Cleanup(func() { require.NoError(t, bucket.Shutdown(ctx)) })
	return bucket, bucket.disk.editOps
}

func segIDsOf(bucket *Bucket) []string {
	var ids []string
	for _, s := range bucket.disk.segments {
		ids = append(ids, segmentID(s.getPath()))
	}
	return ids
}

// TestSegmentCleanerEditOps_PicksPendingRegardlessOfInterval cleans every pending
// segment through the transformer — including the last segment, which the
// time/size heuristic skips — even though the cleanup interval has not elapsed.
func TestSegmentCleanerEditOps_PicksPendingRegardlessOfInterval(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())
	require.NoError(t, bucket.Put([]byte("k2"), []byte("v2")))
	require.NoError(t, bucket.FlushAndSwitch())

	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", segIDsOf(bucket)))

	// Cleanup processes one segment per pass; drain.
	drainEditOpsCleanup(t, bucket)

	v1, err := bucket.Get([]byte("k1"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v1"), v1)
	v2, err := bucket.Get([]byte("k2"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v2"), v2)

	pending, err := editOps.Pending("op1")
	require.NoError(t, err)
	require.Empty(t, pending)
}

// drainEditOpsCleanup runs the cleanup cycle until the edit-ops pending set is
// empty (one segment is rewritten per pass). It stops on empty rather than on a
// no-work return so it doesn't fall through to the heuristic cleanup path (which
// would re-apply the non-idempotent test transformer).
func drainEditOpsCleanup(t *testing.T, bucket *Bucket) {
	t.Helper()
	for range 20 {
		pending, err := bucket.disk.editOps.AllPending()
		require.NoError(t, err)
		if len(pending) == 0 {
			return
		}
		_, err = bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
		require.NoError(t, err)
	}
	t.Fatal("edit-ops cleanup did not drain within 20 passes")
}

// TestSegmentCleanerEditOps_DrainsWithCleanupIntervalDisabled pins that the
// default config (cleanup interval 0, heuristic cleanup disabled) still drains
// the edit-ops pending set — otherwise a drop task would poll forever on a
// quiescent bucket. The heuristic path must stay off.
func TestSegmentCleanerEditOps_DrainsWithCleanupIntervalDisabled(t *testing.T) {
	ctx := context.Background()
	dir := t.TempDir()
	logger, _ := test.NewNullLogger()

	bucket, err := NewBucketCreator().NewBucket(ctx, dir, dir, logger, nil,
		cyclemanager.NewCallbackGroupNoop(), cyclemanager.NewCallbackGroupNoop(),
		WithStrategy(StrategyReplace), WithClassName("TestClass")) // NO cleanup interval
	require.NoError(t, err)
	bucket.SetMemtableThreshold(1e9)
	t.Cleanup(func() { require.NoError(t, bucket.Shutdown(ctx)) })

	editOps := newSegmentEditOpsWithLookup(bucket.disk.dir, "TestClass", staticResolver(map[OpType]OpTransformerFactory{
		OpTypeRemoveTargetVectors: prefixTransformer,
	}))
	bucket.disk.editOps = editOps

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", segIDsOf(bucket)))

	drainEditOpsCleanup(t, bucket)

	v1, err := bucket.Get([]byte("k1"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v1"), v1, "edit-ops drain must run even with heuristic cleanup disabled")

	// With the pending set empty, the edit-ops-only cleaner must not fall through
	// to the heuristic path (it is disabled by interval 0).
	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.False(t, cleaned)
}

// TestSegmentCleanerEditOps_FactorylessOpRowsStayPending pins the
// mixed-version gate AND its liveness: a rewrite strips only for the ops its
// transformer was built from, so a factory-less op's rows are never marked
// done (that would finalize the drop without stripping) — and a segment whose
// rows ALL belong to factory-less ops is skipped entirely, not rewritten:
// rewriting it would strip nothing, mark nothing done, and report work done —
// an endless full rewrite of the same segment on every prompt re-run, with
// built-op rows on later segments never reached. The op IDs here order the
// factory-less op's segment FIRST to pin exactly that shape.
func TestSegmentCleanerEditOps_FactorylessOpRowsStayPending(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())
	require.NoError(t, bucket.Put([]byte("k2"), []byte("v2")))
	require.NoError(t, bucket.FlushAndSwitch())
	segs := segIDsOf(bucket)
	require.Len(t, segs, 2)

	// "a-future" sorts before "b-covered", so the factory-less op's segment
	// (segs[0]) heads the pass's segment order.
	require.NoError(t, editOps.RegisterOp("a-future", OpDescriptor{Type: "op_type_from_a_newer_version", CreatedAt: 2}))
	require.NoError(t, editOps.RegisterOp("b-covered", OpDescriptor{Type: OpTypeRemoveTargetVectors, CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("a-future", segs[:1]))
	require.NoError(t, editOps.SnapshotSegments("b-covered", segs[1:]))

	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.True(t, cleaned, "the pass must skip past the factory-less segment and clean the covered op's")

	pCovered, err := editOps.Pending("b-covered")
	require.NoError(t, err)
	require.Empty(t, pCovered, "the built op's row drains despite the factory-less segment heading the order")
	pFuture, err := editOps.Pending("a-future")
	require.NoError(t, err)
	require.Equal(t, segs[:1], pFuture,
		"a factory-less op's row must not be marked done by a rewrite that did not strip for it")

	v, err := bucket.Get([]byte("k2"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v2"), v, "the covered op's transform ran")

	// Only factory-less work remains: the pass must report NO work done —
	// cleaned=true here would re-run promptly and rewrite the same segment
	// forever (unbounded write amplification while the drop stalls visibly).
	cleaned, err = bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.False(t, cleaned, "a pass with only factory-less rows must not claim progress")
	v, err = bucket.Get([]byte("k1"))
	require.NoError(t, err)
	require.Equal(t, []byte("v1"), v, "the factory-less op's segment is skipped, not pointlessly rewritten")
}

// TestSegmentCleanerEditOps_MixedRowsOnOneSegment pins the exact pre-gate bug
// shape: a built op AND a factory-less op both pending the SAME segment. The
// rewrite runs (the built op's rows justify it) and must mark done ONLY the
// built op's row — marking both would drain the factory-less op without its
// transform ever executing, and its drop would finalize without stripping.
func TestSegmentCleanerEditOps_MixedRowsOnOneSegment(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())
	segs := segIDsOf(bucket)
	require.Len(t, segs, 1)

	require.NoError(t, editOps.RegisterOp("covered", OpDescriptor{Type: OpTypeRemoveTargetVectors, CreatedAt: 1}))
	require.NoError(t, editOps.RegisterOp("future", OpDescriptor{Type: "op_type_from_a_newer_version", CreatedAt: 2}))
	require.NoError(t, editOps.SnapshotSegments("covered", segs))
	require.NoError(t, editOps.SnapshotSegments("future", segs))

	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.True(t, cleaned, "the built op's row justifies the rewrite")

	pCovered, err := editOps.Pending("covered")
	require.NoError(t, err)
	require.Empty(t, pCovered)
	pFuture, err := editOps.Pending("future")
	require.NoError(t, err)
	require.Equal(t, segs, pFuture,
		"the shared segment's rewrite ran without the factory-less op's transform; its row must survive")

	v, err := bucket.Get([]byte("k1"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v1"), v, "the built op's transform ran exactly once")
}

// TestSegmentEditOps_SweepOrphans pins the cleanup-cycle orphan sweep: an op with
// no live task is deleted, a live one is kept, the sweep is rate-limited, and a
// liveness error sweeps nothing.
func TestSegmentEditOps_SweepOrphans(t *testing.T) {
	ctx := context.Background()
	s := newSegmentEditOps(t.TempDir(), "")
	t.Cleanup(func() { require.NoError(t, s.Close()) })
	t.Cleanup(func() { editops.SetLivenessProvider(nil) })

	require.NoError(t, s.RegisterOp("orphan", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, s.RegisterOp("live", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 2}))

	editops.SetLivenessProvider(func(context.Context) (map[string]struct{}, error) {
		return map[string]struct{}{"live": {}}, nil
	})
	s.SweepOrphans(ctx)

	ops, err := s.LoadOps()
	require.NoError(t, err)
	require.Len(t, ops, 1)
	require.Equal(t, "live", ops[0].ID, "orphan swept, live op kept")

	// Rate limit: an immediate second sweep is a no-op even if everything is
	// orphaned now.
	editops.SetLivenessProvider(func(context.Context) (map[string]struct{}, error) {
		return map[string]struct{}{}, nil
	})
	s.SweepOrphans(ctx)
	ops, err = s.LoadOps()
	require.NoError(t, err)
	require.Len(t, ops, 1, "rate-limited sweep must not run again immediately")

	// Liveness error: sweep nothing (safe fallback).
	s.lastOrphanSweep = time.Time{}
	editops.SetLivenessProvider(func(context.Context) (map[string]struct{}, error) {
		return nil, errors.New("dtm unreachable")
	})
	s.SweepOrphans(ctx)
	ops, err = s.LoadOps()
	require.NoError(t, err)
	require.Len(t, ops, 1, "a liveness error must not sweep")
}

// TestSegmentCleanerEditOps_MultiOpSameSegment pins the grouping contract: when
// several ops have the same segment pending, it is rewritten exactly once (the
// transformer is applied a single time, not twice) and every op's row for it is
// marked done.
func TestSegmentCleanerEditOps_MultiOpSameSegment(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())

	segs := segIDsOf(bucket)
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.RegisterOp("op2", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 2}))
	require.NoError(t, editOps.SnapshotSegments("op1", segs))
	require.NoError(t, editOps.SnapshotSegments("op2", segs))

	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.True(t, cleaned)

	// Rewritten exactly once: a single transformer application (X:v1, not X:X:v1).
	v1, err := bucket.Get([]byte("k1"))
	require.NoError(t, err)
	require.Equal(t, []byte("X:v1"), v1)

	// Both ops' rows for the shared segment are marked done.
	p1, err := editOps.Pending("op1")
	require.NoError(t, err)
	require.Empty(t, p1)
	p2, err := editOps.Pending("op2")
	require.NoError(t, err)
	require.Empty(t, p2)
}

// TestSegmentCleanerEditOps_NilTransformerDoesNotMarkDone pins the guard against
// silently completing a drop without stripping: with a nil transformer (no
// builder) but pending rows, cleanup must not rewrite-and-mark-done.
func TestSegmentCleanerEditOps_NilTransformerDoesNotMarkDone(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, nil) // nil builder -> nil transformer

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())

	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", segIDsOf(bucket)))

	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.False(t, cleaned)

	// The row must stay pending: a nil transformer strips nothing, so marking it
	// done would falsely complete the drop.
	pending, err := editOps.Pending("op1")
	require.NoError(t, err)
	require.NotEmpty(t, pending)
}

// TestSegmentCleanerEditOps_MemoryPressurePausesWithoutBumping pins that an OOM
// guard hit pauses the pass (nothing cleaned) without counting as a failed
// attempt — so a transient low-memory window can't quarantine a healthy segment.
func TestSegmentCleanerEditOps_MemoryPressurePausesWithoutBumping(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)
	bucket.disk.allocChecker = denyAllocChecker{}

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())

	segID := segIDsOf(bucket)[0]
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", []string{segID}))

	// More passes than the quarantine budget: if pauses bumped attempts the
	// segment would be quarantined, so this proves a pause is not a failure.
	for range maxCleanupAttempts + 2 {
		cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
		require.NoError(t, err)
		require.False(t, cleaned)
	}

	all, err := editOps.AllPending()
	require.NoError(t, err)
	require.Len(t, all, 1)
	require.Equal(t, 0, all[0].Attempts)

	q, err := editOps.Quarantined()
	require.NoError(t, err)
	require.Empty(t, q)
}

// TestSegmentCleanerEditOps_AbortMidRewriteDoesNotBump pins that a shouldAbort
// firing mid-rewrite (e.g. shutdown, or a frequently-firing abort under load)
// pauses the pass WITHOUT counting as a failed attempt — an interrupted rewrite
// must not push a healthy segment toward quarantine. Mirrors the OOM-pause test.
func TestSegmentCleanerEditOps_AbortMidRewriteDoesNotBump(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	// >=100 keys so writeKeys reaches its i%100==0 shouldAbort check mid-rewrite
	// (a smaller segment would finish before the check ever fires).
	for i := range 150 {
		require.NoError(t, bucket.Put([]byte{byte(i)}, []byte("v")))
	}
	require.NoError(t, bucket.FlushAndSwitch())

	segID := segIDsOf(bucket)[0]
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", []string{segID}))

	// More passes than the quarantine budget: if aborts bumped attempts the
	// segment would be quarantined, so this proves an abort is not a failure.
	for range maxCleanupAttempts + 2 {
		// false on the first call (cleanupOnceEditOps' entry guard) so the pass
		// proceeds into the rewrite, then true — firing inside writeKeys.
		calls := 0
		shouldAbort := func() bool { calls++; return calls > 1 }
		cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(shouldAbort)
		require.NoError(t, err)
		require.False(t, cleaned)
	}

	all, err := editOps.AllPending()
	require.NoError(t, err)
	require.Len(t, all, 1)
	require.Equal(t, 0, all[0].Attempts, "an aborted rewrite must not count as a failed attempt")

	q, err := editOps.Quarantined()
	require.NoError(t, err)
	require.Empty(t, q)
}

// TestSegmentCleanerEditOps_GhostRowIsSkippedNotCompleted pins the ghost-row
// contract: a pending row whose segment is not in the live set is SKIPPED —
// never marked done — and must not stall the rest of the pass. Marking it done
// would drain the op's pending set and let a drop finalize without stripping
// that segment's data; reachable when the shard shuts down mid-pass (tenant
// deactivation no longer waits for cleanups). Truly-dead rows are pruned by
// the load-time Recover instead.
func TestSegmentCleanerEditOps_GhostRowIsSkippedNotCompleted(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, prefixTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())

	segID := segIDsOf(bucket)[0]
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	// The all-zero ghost sorts ahead of the real segment, so the pass hits it first.
	require.NoError(t, editOps.SnapshotSegments("op1", []string{"0000000000000000000", segID}))

	cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err)
	require.True(t, cleaned, "the ghost must not stall the pass; the real segment behind it is cleaned")

	pending, err := editOps.Pending("op1")
	require.NoError(t, err)
	require.Equal(t, []string{"0000000000000000000"}, pending,
		"the ghost row must survive the pass (only load-time Recover prunes it); the cleaned segment's row is done")
}

// TestSegmentCleanerEditOps_QuarantineAfterMaxAttempts quarantines a segment
// whose rewrite keeps failing, so it stops being retried (C6).
func TestSegmentCleanerEditOps_QuarantineAfterMaxAttempts(t *testing.T) {
	failing := func(className string, ops []ActiveOp) func([]byte) ([]byte, error) {
		return func(v []byte) ([]byte, error) { return nil, errors.New("boom") }
	}
	bucket, editOps := newReplaceBucketWithEditOps(t, failing)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())

	segID := segIDsOf(bucket)[0]
	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", []string{segID}))

	for range maxCleanupAttempts {
		cleaned, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
		require.NoError(t, err)
		require.False(t, cleaned)
	}

	pending, err := editOps.Pending("op1")
	require.NoError(t, err)
	require.Empty(t, pending)

	quarantined, err := editOps.Quarantined()
	require.NoError(t, err)
	require.Len(t, quarantined, 1)
	require.Equal(t, segID, quarantined[0].SegmentID)
}

// TestSegmentEditOps_SweepOrphans_StaleCacheDoesNotDeleteLiveOp pins the
// silent-incomplete-drop fix: a cached liveness set fetched BEFORE an op's task
// committed must not be the basis for deleting that op — a fresh confirmation
// read (which sees the now-committed task) must save it. Without the confirm,
// the draining unit would read the deleted op's empty pending set as "done" and
// the drop would finalize without stripping.
func TestSegmentEditOps_SweepOrphans_StaleCacheDoesNotDeleteLiveOp(t *testing.T) {
	ctx := context.Background()
	s := newSegmentEditOps(t.TempDir(), "")
	t.Cleanup(func() { require.NoError(t, s.Close()) })
	t.Cleanup(func() { editops.SetLivenessProvider(nil) })

	// Provider: first call (cache warm-up, pre-commit) sees no live ops; later
	// calls (post-commit) see opX.
	calls := 0
	editops.SetLivenessProvider(func(context.Context) (map[string]struct{}, error) {
		calls++
		if calls == 1 {
			return map[string]struct{}{}, nil
		}
		return map[string]struct{}{"opX": {}}, nil
	})

	// Warm the shared cache before the "commit".
	_, err := editops.LiveOps(ctx)
	require.NoError(t, err)

	// Task commits, op arms.
	require.NoError(t, s.RegisterOp("opX", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))

	// Sweep within the cache TTL: the stale set is missing opX; the fresh
	// confirmation read must keep it alive.
	s.SweepOrphans(ctx)

	ops, err := s.LoadOps()
	require.NoError(t, err)
	require.Len(t, ops, 1, "a live op must survive a sweep that consulted a pre-commit cache")
	require.Equal(t, "opX", ops[0].ID)
	require.GreaterOrEqual(t, calls, 2, "the sweep must have confirmed with a fresh read")
}

// TestSegmentEditOps_Recover_StaleCacheDoesNotDeleteLiveOp is the shard-load
// variant of the same window: Recover's sweep must confirm suspects fresh.
func TestSegmentEditOps_Recover_StaleCacheDoesNotDeleteLiveOp(t *testing.T) {
	s := newSegmentEditOps(t.TempDir(), "")
	t.Cleanup(func() { require.NoError(t, s.Close()) })

	require.NoError(t, s.RegisterOp("opX", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, s.SnapshotSegments("opX", []string{"100"}))

	stale := func() map[string]struct{} { return map[string]struct{}{} }          // pre-commit view
	fresh := func() map[string]struct{} { return map[string]struct{}{"opX": {}} } // authoritative
	require.NoError(t, s.Recover([]string{"100"}, stale, fresh))

	ops, err := s.LoadOps()
	require.NoError(t, err)
	require.Len(t, ops, 1, "the fresh confirmation must overrule the stale set")
	pending, err := s.Pending("opX")
	require.NoError(t, err)
	require.ElementsMatch(t, []string{"100"}, pending, "the live op stays armed")
}

// failingTransformer errors on the first value it is handed, which fails the
// rewrite after the .tmp file exists — the shape ENOSPC produces.
func failingTransformer(className string, ops []ActiveOp) func([]byte) ([]byte, error) {
	return func(v []byte) ([]byte, error) { return nil, errors.New("no space left on device") }
}

// TestSegmentCleanerEditOps_FailedRewriteLeavesNoPartial pins the cleanup of the
// .tmp file a failed rewrite leaves behind. The caller gets no path back on the
// error paths, so it cannot compensate — and the failure most likely to put us
// there is ENOSPC, where the orphan is as large as the space that ran out and
// the retry needs it back.
func TestSegmentCleanerEditOps_FailedRewriteLeavesNoPartial(t *testing.T) {
	bucket, editOps := newReplaceBucketWithEditOps(t, failingTransformer)

	require.NoError(t, bucket.Put([]byte("k1"), []byte("v1")))
	require.NoError(t, bucket.FlushAndSwitch())
	require.NoError(t, bucket.Put([]byte("k2"), []byte("v2")))
	require.NoError(t, bucket.FlushAndSwitch())

	require.NoError(t, editOps.RegisterOp("op1", OpDescriptor{Type: "remove_target_vectors", CreatedAt: 1}))
	require.NoError(t, editOps.SnapshotSegments("op1", segIDsOf(bucket)))

	tmpBefore := countTmpSegments(t, bucket.disk.dir)

	_, err := bucket.disk.segmentCleaner.cleanupOnce(func() bool { return false })
	require.NoError(t, err, "a failed rewrite is recorded on the row, not returned")

	pending, perr := editOps.AllPending()
	require.NoError(t, perr)
	require.NotEmpty(t, pending, "the rewrite failed, so the segment stays owed")
	require.Positive(t, pending[0].Attempts, "and the failure was counted against its budget")

	require.Equal(t, tmpBefore, countTmpSegments(t, bucket.disk.dir),
		"a rewrite that did not complete must not leave its partial segment behind")
}

func countTmpSegments(t *testing.T, dir string) int {
	t.Helper()
	entries, err := os.ReadDir(dir)
	require.NoError(t, err)
	n := 0
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".tmp") {
			n++
		}
	}
	return n
}
