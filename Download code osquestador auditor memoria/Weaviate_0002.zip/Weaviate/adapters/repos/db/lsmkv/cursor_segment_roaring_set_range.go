//                           _       _
// __      _____  __ ___   ___  __ _| |_ ___
// \ \ /\ / / _ \/ _` \ \ / / |/ _` | __/ _ \
//  \ V  V /  __/ (_| |\ V /| | (_| | ||  __/
//   \_/\_/ \___|\__,_| \_/ |_|\__,_|\__\___|
//
//  Copyright © 2016 - 2026 Weaviate B.V. All rights reserved.
//
//  CONTACT: hello@weaviate.io
//

package lsmkv

import (
	"io"

	"github.com/weaviate/weaviate/adapters/repos/db/roaringsetrange"
)

func (s *segment) newRoaringSetRangeReader() roaringsetrange.InnerReader {
	var segmentCursor roaringsetrange.SegmentCursor
	if s.readFromMemory {
		segmentCursor = roaringsetrange.NewSegmentCursorMmap(s.contents[s.dataStartPos:s.dataEndPos])
	} else {
		payloadSize := int64(s.dataEndPos - s.dataStartPos)
		sectionReader := io.NewSectionReader(s.contentFile, int64(s.dataStartPos), payloadSize)
		// since segment reader concurrenlty fetches next segment and merges bitmaps of previous segments
		// at least 2 buffers needs to be used by cursor not to overwrite data before they are consumed.
		segmentCursor = roaringsetrange.NewSegmentCursorPread(sectionReader, payloadSize, 2)
	}

	return roaringsetrange.NewSegmentReader(
		roaringsetrange.NewGaplessSegmentCursor(segmentCursor))
}

func (s *segment) newRoaringSetRangeCursor() roaringsetrange.SegmentCursor {
	if s.readFromMemory {
		return roaringsetrange.NewSegmentCursorMmap(s.contents[s.dataStartPos:s.dataEndPos])
	}

	payloadSize := int64(s.dataEndPos - s.dataStartPos)
	sectionReader := io.NewSectionReader(s.contentFile, int64(s.dataStartPos), payloadSize)
	// compactor does not work concurrently, next segment is fetched after previous one gets consumed,
	// therefore just one buffer is sufficient.
	return roaringsetrange.NewSegmentCursorPread(sectionReader, payloadSize, 1)
}
