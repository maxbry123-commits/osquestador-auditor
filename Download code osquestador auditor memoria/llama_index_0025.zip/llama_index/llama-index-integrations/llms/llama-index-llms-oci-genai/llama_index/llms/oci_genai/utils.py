import inspect
import json
import uuid
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Sequence, Dict, Union, Type, Callable, Optional, List
from llama_index.core.base.llms.types import (
    ChatMessage,
    MessageRole,
    ChatResponse,
    TextBlock,
    ImageBlock,
)
from llama_index.core.bridge.pydantic import BaseModel
from llama_index.core.tools import BaseTool
from oci.generative_ai_inference.models import CohereTool


class OCIAuthType(Enum):
    """OCI authentication types as enumerator."""

    API_KEY = 1
    SECURITY_TOKEN = 2
    INSTANCE_PRINCIPAL = 3
    RESOURCE_PRINCIPAL = 4


CUSTOM_ENDPOINT_PREFIX = "ocid1.generativeaiendpoint"

COMPLETION_MODELS = {}  # completion endpoint has been deprecated

CHAT_MODELS = {
    "cohere.command-a-03-2025": 256000,
    "cohere.command-r-16k": 16000,
    "cohere.command-r-plus": 128000,
    "cohere.command-r-08-2024": 128000,
    "cohere.command-r-plus-08-2024": 128000,
    "meta.llama-3-70b-instruct": 8192,
    "meta.llama-3.1-70b-instruct": 128000,
    "meta.llama-3.1-405b-instruct": 128000,
    "meta.llama-3.2-90b-vision-instruct": 128000,
    "meta.llama-3.3-70b-instruct": 128000,
    "meta.llama-4-scout-17b-16e-instruct": 192000,
    "meta.llama-4-maverick-17b-128e-instruct-fp8": 512000,
    "xai.grok-code-fast-1": 256000,
    "xai.grok-4-fast-reasoning": 2000000,
    "xai.grok-4-fast-non-reasoning": 2000000,
    "xai.grok-4": 128000,
    "xai.grok-3": 131072,
    "xai.grok-3-fast": 131072,
    "xai.grok-3-mini": 131072,
    "xai.grok-3-mini-fast": 131072,
}

OCIGENAI_LLMS = {**COMPLETION_MODELS, **CHAT_MODELS}

JSON_TO_PYTHON_TYPES = {
    "string": "str",
    "number": "float",
    "boolean": "bool",
    "integer": "int",
    "array": "List",
    "object": "Dict",
}


def _format_oci_tool_calls(
    tool_calls: Optional[List[Any]] = None,
) -> List[Dict]:
    """
    Formats an OCI GenAI API response into the tool call format used in LlamaIndex.
    Handles both dictionary and object formats.
    """
    if not tool_calls:
        return []

    formatted_tool_calls = []
    for tool_call in tool_calls:
        # Handle both object and dict formats
        if isinstance(tool_call, dict):
            name = tool_call.get("name", tool_call.get("functionName"))
            parameters = tool_call.get(
                "parameters", tool_call.get("functionParameters")
            )
        else:
            name = getattr(tool_call, "name", getattr(tool_call, "functionName", None))
            parameters = getattr(
                tool_call, "parameters", getattr(tool_call, "functionParameters", None)
            )

        if name and parameters:
            formatted_tool_calls.append(
                {
                    "toolUseId": uuid.uuid4().hex[:],
                    "name": name,
                    "input": json.dumps(parameters)
                    if isinstance(parameters, dict)
                    else parameters,
                }
            )

    return formatted_tool_calls


def create_client(auth_type, auth_profile, auth_file_location, service_endpoint):
    """
    OCI Gen AI client.

    Args:
        auth_type (Optional[str]): Authentication type, can be: API_KEY (default), SECURITY_TOKEN, INSTANCE_PRINCIPAL, RESOURCE_PRINCIPAL. If not specified, API_KEY will be used

        auth_profile (Optional[str]): The name of the profile in ~/.oci/config. If not specified , DEFAULT will be used

        auth_file_location (Optional[str]): Path to the config file. If not specified, ~/.oci/config will be used

        service_endpoint (str): service endpoint url, e.g., "https://inference.generativeai.us-chicago-1.oci.oraclecloud.com"

    """
    try:
        import oci

        client_kwargs = {
            "config": {},
            "signer": None,
            "service_endpoint": service_endpoint,
            "retry_strategy": oci.retry.DEFAULT_RETRY_STRATEGY,
            "timeout": (10, 240),  # default timeout config for OCI Gen AI service
        }

        if auth_type == OCIAuthType(1).name:
            client_kwargs["config"] = oci.config.from_file(
                file_location=auth_file_location, profile_name=auth_profile
            )
            client_kwargs.pop("signer", None)
        elif auth_type == OCIAuthType(2).name:

            def make_security_token_signer(oci_config):  # type: ignore[no-untyped-def]
                pk = oci.signer.load_private_key_from_file(
                    oci_config.get("key_file"), None
                )
                with open(oci_config.get("security_token_file"), encoding="utf-8") as f:
                    st_string = f.read()
                return oci.auth.signers.SecurityTokenSigner(st_string, pk)

            client_kwargs["config"] = oci.config.from_file(
                file_location=auth_file_location, profile_name=auth_profile
            )
            client_kwargs["signer"] = make_security_token_signer(
                oci_config=client_kwargs["config"]
            )
        elif auth_type == OCIAuthType(3).name:
            client_kwargs["signer"] = (
                oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
            )
        elif auth_type == OCIAuthType(4).name:
            client_kwargs["signer"] = oci.auth.signers.get_resource_principals_signer()
        else:
            raise ValueError(
                f"Please provide valid value to auth_type, {auth_type} is not valid."
            )

        return oci.generative_ai_inference.GenerativeAiInferenceClient(**client_kwargs)

    except ImportError as ex:
        raise ModuleNotFoundError(
            "Could not import oci python package. "
            "Please make sure you have the oci package installed."
        ) from ex
    except Exception as e:
        raise ValueError(
            """Could not authenticate with OCI client.
            If INSTANCE_PRINCIPAL or RESOURCE_PRINCIPAL is used, please check the specified
            auth_profile, auth_file_location and auth_type are valid.""",
            e,
        ) from e


def get_serving_mode(model_id: str) -> Any:
    try:
        from oci.generative_ai_inference import models

    except ImportError as ex:
        raise ModuleNotFoundError(
            "Could not import oci python package. "
            "Please make sure you have the oci package installed."
        ) from ex

    if model_id.startswith(CUSTOM_ENDPOINT_PREFIX):
        serving_mode = models.DedicatedServingMode(endpoint_id=model_id)
    else:
        serving_mode = models.OnDemandServingMode(model_id=model_id)

    return serving_mode


def get_completion_generator() -> Any:
    try:
        from oci.generative_ai_inference import models

    except ImportError as ex:
        raise ModuleNotFoundError(
            "Could not import oci python package. "
            "Please make sure you have the oci package installed."
        ) from ex

    return models.GenerateTextDetails


def get_chat_generator() -> Any:
    try:
        from oci.generative_ai_inference import models

    except ImportError as ex:
        raise ModuleNotFoundError(
            "Could not import oci python package. "
            "Please make sure you have the oci package installed."
        ) from ex

    return models.ChatDetails


class Provider(ABC):
    @abstractmethod
    def completion_response_to_text(self, response: Any) -> str: ...

    @abstractmethod
    def completion_stream_to_text(self, response: Any) -> str: ...

    @abstractmethod
    def chat_response_to_text(self, response: Any) -> str: ...

    @abstractmethod
    def chat_stream_to_text(self, event_data: Dict) -> str: ...

    @abstractmethod
    def chat_generation_info(self, response: Any) -> Dict[str, Any]: ...

    @abstractmethod
    def chat_stream_generation_info(self, event_data: Dict) -> Dict[str, Any]: ...

    @abstractmethod
    def messages_to_oci_params(
        self, messages: Sequence[ChatMessage]
    ) -> Dict[str, Any]: ...

    @abstractmethod
    def convert_to_oci_tool(
        self,
        tool: Union[Union[Dict[str, Any], Type[BaseModel], Callable, BaseTool]],
    ) -> Dict[str, Any]: ...


class CohereProvider(Provider):
    def __init__(self) -> None:
        try:
            from oci.generative_ai_inference import models

        except ImportError as ex:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            ) from ex

        self.oci_completion_request = models.CohereLlmInferenceRequest
        self.oci_chat_request = models.CohereChatRequest
        self.oci_tool = models.CohereTool
        self.oci_tool_param = models.CohereParameterDefinition
        self.oci_tool_result = models.CohereToolResult
        self.oci_tool_call = models.CohereToolCall
        self.oci_chat_message = {
            "USER": models.CohereUserMessage,
            "CHATBOT": models.CohereChatBotMessage,
            "SYSTEM": models.CohereSystemMessage,
            "TOOL": models.CohereToolMessage,
        }
        self.chat_api_format = models.BaseChatRequest.API_FORMAT_COHERE

    def completion_response_to_text(self, response: Any) -> str:
        return response.data.inference_response.generated_texts[0].text

    def completion_stream_to_text(self, event_data: Any) -> str:
        return event_data["text"]

    def chat_response_to_text(self, response: Any) -> str:
        return response.data.chat_response.text

    def chat_stream_to_text(self, event_data: Dict) -> str:
        if "text" in event_data:
            if "finishedReason" in event_data or "toolCalls" in event_data:
                return ""
            else:
                return event_data["text"]
        return ""

    def chat_generation_info(self, response: Any) -> Dict[str, Any]:
        generation_info: Dict[str, Any] = {
            "finish_reason": response.data.chat_response.finish_reason,
            "documents": response.data.chat_response.documents,
            "citations": response.data.chat_response.citations,
            "search_queries": response.data.chat_response.search_queries,
            "is_search_required": response.data.chat_response.is_search_required,
        }
        if response.data.chat_response.tool_calls:
            # Only populate tool_calls when 1) present on the response and
            #  2) has one or more calls.
            generation_info["tool_calls"] = _format_oci_tool_calls(
                response.data.chat_response.tool_calls
            )

        return generation_info

    def chat_stream_generation_info(self, event_data: Dict) -> Dict[str, Any]:
        """Extract generation info from a streaming chat response."""
        generation_info: Dict[str, Any] = {
            "finish_reason": event_data.get("finishReason"),
            "documents": event_data.get("documents", []),
            "citations": event_data.get("citations", []),
            "search_queries": event_data.get("searchQueries", []),
            "is_search_required": event_data.get("isSearchRequired", False),
        }

        # Handle tool calls if present
        if "toolCalls" in event_data:
            generation_info["tool_calls"] = _format_oci_tool_calls(
                event_data["toolCalls"]
            )

        return {k: v for k, v in generation_info.items() if v is not None}

    def messages_to_oci_params(self, messages: Sequence[ChatMessage]) -> Dict[str, Any]:
        role_map = {
            "user": "USER",
            "system": "SYSTEM",
            "assistant": "CHATBOT",
            "tool": "TOOL",
            "function": "TOOL",
            "chatbot": "CHATBOT",
            "model": "CHATBOT",
        }

        oci_chat_history = []

        for msg in messages[:-1]:
            role = role_map[msg.role.value]

            # Handle tool calls for AI/Assistant messages
            if role == "CHATBOT" and "tool_calls" in msg.additional_kwargs:
                tool_calls = []
                for tool_call in msg.additional_kwargs.get("tool_calls", []):
                    validate_tool_call(tool_call)
                    tool_calls.append(
                        self.oci_tool_call(
                            name=tool_call.get("name"),
                            parameters=json.loads(tool_call["input"])
                            if isinstance(tool_call["input"], str)
                            else tool_call["input"],
                        )
                    )

                oci_chat_history.append(
                    self.oci_chat_message[role](
                        message=msg.content if msg.content else " ",
                        tool_calls=tool_calls if tool_calls else None,
                    )
                )
            elif role == "TOOL":
                # tool message only has tool results field and no message field
                continue
            else:
                oci_chat_history.append(
                    self.oci_chat_message[role](message=msg.content or " ")
                )

        # Handling the current chat turn, especially the latest message
        current_chat_turn_messages = []
        for message in messages[::-1]:
            current_chat_turn_messages.append(message)
            if message.role == MessageRole.USER:
                break
        current_chat_turn_messages = current_chat_turn_messages[::-1]

        oci_tool_results = []
        for message in current_chat_turn_messages:
            if message.role == MessageRole.TOOL:
                tool_message = message
                previous_ai_msgs = [
                    message
                    for message in current_chat_turn_messages
                    if message.role == MessageRole.ASSISTANT
                    and "tool_calls" in message.additional_kwargs
                ]
                if previous_ai_msgs:
                    previous_ai_msg = previous_ai_msgs[-1]
                    for li_tool_call in previous_ai_msg.additional_kwargs.get(
                        "tool_calls", []
                    ):
                        validate_tool_call(li_tool_call)
                        if li_tool_call[
                            "toolUseId"
                        ] == tool_message.additional_kwargs.get("tool_call_id"):
                            tool_result = self.oci_tool_result()
                            tool_result.call = self.oci_tool_call(
                                name=li_tool_call.get("name"),
                                parameters=json.loads(li_tool_call["input"])
                                if isinstance(li_tool_call["input"], str)
                                else li_tool_call["input"],
                            )
                            tool_result.outputs = [{"output": tool_message.content}]
                            oci_tool_results.append(tool_result)

        if not oci_tool_results:
            oci_tool_results = None

        message_str = "" if oci_tool_results or not messages else messages[-1].content

        oci_params = {
            "message": message_str,
            "chat_history": oci_chat_history,
            "tool_results": oci_tool_results,
            "api_format": self.chat_api_format,
        }

        return {k: v for k, v in oci_params.items() if v is not None}

    def convert_to_oci_tool(
        self,
        tool: Union[Dict[str, Any], Type[BaseModel], Callable, BaseTool],
    ) -> CohereTool:
        """
        Convert a Pydantic class, JSON schema dict, callable, or BaseTool to a CohereTool format for OCI.

        Args:
            tool: The tool to convert, which can be a Pydantic class, a callable, or a JSON schema dictionary.

        Returns:
            A CohereTool representing the tool in the OCI API format.

        """
        if isinstance(tool, BaseTool):
            # Extract tool name and description for BaseTool
            tool_name, tool_description = (
                getattr(tool, "name", None),
                getattr(tool, "description", None),
            )
            if not tool_name or not tool_description:
                tool_name = getattr(tool.metadata, "name", None)
                if tool_fn := getattr(tool, "fn", None):
                    tool_description = tool_fn.__doc__
                    if not tool_name:
                        tool_name = tool_fn.__name__
                else:
                    tool_description = getattr(tool.metadata, "description", None)
                if not tool_name or not tool_description:
                    raise ValueError(
                        f"Tool {tool} does not have a name or description."
                    )

            return self.oci_tool(
                name=tool_name,
                description=tool_description,
                parameter_definitions={
                    p_name: self.oci_tool_param(
                        type=JSON_TO_PYTHON_TYPES.get(
                            p_def.get("type"), p_def.get("type")
                        ),
                        description=p_def.get("description", ""),
                        is_required=p_name
                        in tool.metadata.get_parameters_dict().get("required", []),
                    )
                    for p_name, p_def in tool.metadata.get_parameters_dict()
                    .get("properties", {})
                    .items()
                },
            )

        elif isinstance(tool, dict):
            # Ensure dict-based tools follow a standard schema format
            if not all(k in tool for k in ("title", "description", "properties")):
                raise ValueError(
                    "Unsupported dict type. Tool must be passed in as a BaseTool instance, JSON schema dict, or BaseModel type."
                )
            return self.oci_tool(
                name=tool.get("title"),
                description=tool.get("description"),
                parameter_definitions={
                    p_name: self.oci_tool_param(
                        type=JSON_TO_PYTHON_TYPES.get(
                            p_def.get("type"), p_def.get("type")
                        ),
                        description=p_def.get("description", ""),
                        is_required=p_name in tool.get("required", []),
                    )
                    for p_name, p_def in tool.get("properties", {}).items()
                },
            )

        elif isinstance(tool, type) and issubclass(tool, BaseModel):
            # Handle Pydantic BaseModel tools
            schema = tool.model_json_schema()
            properties = schema.get("properties", {})
            return self.oci_tool(
                name=schema.get("title", tool.__name__),
                description=schema.get("description", tool.__name__),
                parameter_definitions={
                    p_name: self.oci_tool_param(
                        type=JSON_TO_PYTHON_TYPES.get(
                            p_def.get("type"), p_def.get("type")
                        ),
                        description=p_def.get("description", ""),
                        is_required=p_name in schema.get("required", []),
                    )
                    for p_name, p_def in properties.items()
                },
            )

        elif callable(tool):
            # Use inspect to extract callable signature and arguments
            signature = inspect.signature(tool)
            parameters = {}
            for param_name, param in signature.parameters.items():
                param_type = (
                    param.annotation if param.annotation != inspect._empty else "string"
                )
                param_default = (
                    param.default if param.default != inspect._empty else None
                )

                # Convert type to JSON schema type (or leave as default)
                json_type = JSON_TO_PYTHON_TYPES.get(
                    param_type,
                    param_type.__name__ if isinstance(param_type, type) else "string",
                )

                parameters[param_name] = {
                    "type": json_type,
                    "description": f"Parameter: {param_name}",
                    "is_required": param_default is None,
                }

            return self.oci_tool(
                name=tool.__name__,
                description=tool.__doc__ or f"Callable function: {tool.__name__}",
                parameter_definitions={
                    param_name: self.oci_tool_param(
                        type=param_data["type"],
                        description=param_data["description"],
                        is_required=param_data["is_required"],
                    )
                    for param_name, param_data in parameters.items()
                },
            )

        else:
            raise ValueError(
                f"Unsupported tool type {type(tool)}. Tool must be passed in as a BaseTool instance, JSON schema dict, or BaseModel type."
            )


class MetaProvider(Provider):
    def __init__(self) -> None:
        try:
            from oci.generative_ai_inference import models

        except ImportError as ex:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            ) from ex

        self.oci_completion_request = models.LlamaLlmInferenceRequest

        # Chat request and message models
        self.oci_chat_request = models.GenericChatRequest
        self.oci_chat_message = {
            "USER": models.UserMessage,
            "SYSTEM": models.SystemMessage,
            "ASSISTANT": models.AssistantMessage,
        }

        # Content models
        self.oci_chat_message_content = models.ChatContent
        self.oci_chat_message_text_content = models.TextContent
        self.oci_chat_message_image_content = models.ImageContent
        self.oci_chat_message_image_url = models.ImageUrl

        self.chat_api_format = models.BaseChatRequest.API_FORMAT_GENERIC

    def completion_response_to_text(self, response: Any) -> str:
        return response.data.inference_response.choices[0].text

    def completion_stream_to_text(self, event_data: Any) -> str:
        return event_data["text"]

    def chat_response_to_text(self, response: Any) -> str:
        """Extract text from Meta chat response."""
        message = response.data.chat_response.choices[0].message
        content = message.content[0] if message.content else None
        return content.text if content else ""

    def chat_stream_to_text(self, event_data: Dict) -> str:
        """Extract text from Meta chat stream event."""
        content = event_data.get("message", {}).get("content", None)
        if not content:
            return ""
        return content[0]["text"]

    def chat_generation_info(self, response: Any) -> Dict[str, Any]:
        """Extract generation metadata from Meta chat response."""
        return {
            "finish_reason": response.data.chat_response.choices[0].finish_reason,
            "time_created": str(response.data.chat_response.time_created),
        }

    def chat_stream_generation_info(self, event_data: Dict) -> Dict[str, Any]:
        """Extract generation metadata from Meta chat stream event."""
        return {
            "finish_reason": event_data["finishReason"],
        }

    def messages_to_oci_params(self, messages: Sequence[ChatMessage]) -> Dict[str, Any]:
        """
        Convert LlamaIndex messages to OCI chat parameters.

        Args:
            messages: List of LlamaIndex ChatMessage objects

        Returns:
            Dict containing OCI chat parameters

        Raises:
            ValueError: If message content is invalid

        """
        """Map a LlamaIndex message to Meta's role representation."""
        role_map = {
            "user": "USER",
            "system": "SYSTEM",
            "chatbot": "ASSISTANT",
            "assistant": "ASSISTANT",
        }

        oci_messages = []
        for msg in messages:
            # Use blocks if available, otherwise fall back to legacy msg.content
            content = getattr(msg, "blocks", None) or msg.content or ""
            content = self._process_message_content(content)
            oci_message = self.oci_chat_message[role_map[msg.role]](content=content)
            oci_messages.append(oci_message)

        return {
            "messages": oci_messages,
            "api_format": self.chat_api_format,
            "top_k": -1,
        }

    def _process_message_content(
        self, content: Union[str, List[Union[TextBlock, ImageBlock]]]
    ) -> List[Any]:
        """
        Process message content into OCI chat content format.

        Args:
            content: Message content as string or blocks

        Returns:
            List of OCI chat content objects

        Raises:
            ValueError: If content format is invalid

        """
        if isinstance(content, str):
            return [self.oci_chat_message_text_content(text=content)]

        if not isinstance(content, list):
            raise ValueError("Message content must be a string or blocks.")

        processed_content = []
        for item in content:
            if isinstance(item, TextBlock):
                processed_content.append(
                    self.oci_chat_message_text_content(text=item.text)
                )
            elif isinstance(item, ImageBlock):
                processed_content.append(
                    self.oci_chat_message_image_content(
                        image_url=self.oci_chat_message_image_url(url=str(item.url))
                    )
                )
            else:
                raise ValueError(
                    f"Items in blocks must be TextBlock or ImageBlock, got: {type(item)}"
                )

        return processed_content

    def convert_to_oci_tool(
        self,
        tool: Union[Union[Dict[str, Any], Type[BaseModel], Callable, BaseTool]],
    ) -> Dict[str, Any]:
        raise NotImplementedError(
            "Tools not supported for OCI Generative AI Meta models"
        )


class XAIProvider(Provider):
    def __init__(self) -> None:
        try:
            from oci.generative_ai_inference import models
        except ImportError as ex:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            ) from ex

        # Completion
        self.oci_completion_request = models.LlamaLlmInferenceRequest

        # Generic chat request and message models
        self.oci_chat_request = models.GenericChatRequest
        self.oci_chat_message = {
            "USER": models.UserMessage,
            "SYSTEM": models.SystemMessage,
            "ASSISTANT": models.AssistantMessage,
            "TOOL": models.ToolMessage,
        }

        # Content models
        self.oci_chat_message_text_content = models.TextContent
        self.oci_chat_message_image_content = models.ImageContent
        self.oci_chat_message_image_url = models.ImageUrl

        # Tooling models for Generic format
        self.oci_tool = models.FunctionDefinition
        self.oci_tool_call = models.FunctionCall

        self.chat_api_format = models.BaseChatRequest.API_FORMAT_GENERIC

    def completion_response_to_text(self, response: Any) -> str:
        return response.data.inference_response.choices[0].text

    def completion_stream_to_text(self, event_data: Any) -> str:
        return event_data["text"]

    def chat_response_to_text(self, response: Any) -> str:
        message = response.data.chat_response.choices[0].message
        content = message.content[0] if getattr(message, "content", None) else None
        return content.text if content else ""

    def chat_stream_to_text(self, event_data: Dict) -> str:
        content = event_data.get("message", {}).get("content", None)
        if not content:
            return ""
        return content[0]["text"]

    def chat_generation_info(self, response: Any) -> Dict[str, Any]:
        chat_resp = response.data.chat_response
        info: Dict[str, Any] = {
            "finish_reason": chat_resp.choices[0].finish_reason,
        }
        if hasattr(chat_resp, "time_created"):
            try:
                info["time_created"] = str(chat_resp.time_created)
            except Exception:
                pass

        # Extract tool calls from assistant message (Generic format)
        try:
            print("Hello")
            assistant_message = chat_resp.choices[0].message

            tool_calls = getattr(assistant_message, "tool_calls", None)
            if tool_calls:
                formatted: List[Dict[str, Any]] = []
                for tc in tool_calls:
                    name = getattr(tc, "name", None)
                    arguments = getattr(tc, "arguments", None) or getattr(
                        tc, "parameters", None
                    )
                    tc_id = getattr(tc, "id", None) or uuid.uuid4().hex[:]
                    if name is None:
                        continue
                    if isinstance(arguments, dict):
                        input_str = json.dumps(arguments)
                    else:
                        input_str = arguments
                    formatted.append(
                        {"toolUseId": tc_id, "name": name, "input": input_str}
                    )
                if formatted:
                    info["tool_calls"] = formatted
        except Exception:
            pass

        return info

    def chat_stream_generation_info(self, event_data: Dict) -> Dict[str, Any]:
        info: Dict[str, Any] = {
            "finish_reason": event_data.get("finishReason"),
        }
        tc_list = (
            event_data.get("functionCalls")
            or event_data.get("toolCalls")
            or event_data.get("tool_calls")
        )
        if tc_list:
            formatted: List[Dict[str, Any]] = []
            for tc in tc_list:
                if isinstance(tc, dict):
                    name = tc.get("name")
                    arguments = tc.get("arguments") or tc.get("parameters")
                    tc_id = tc.get("id") or uuid.uuid4().hex[:]
                else:
                    name = getattr(tc, "name", None)
                    arguments = getattr(tc, "arguments", None) or getattr(
                        tc, "parameters", None
                    )
                    tc_id = getattr(tc, "id", None) or uuid.uuid4().hex[:]
                if name is None:
                    continue
                if isinstance(arguments, dict):
                    input_str = json.dumps(arguments)
                else:
                    input_str = arguments
                formatted.append({"toolUseId": tc_id, "name": name, "input": input_str})
            if formatted:
                info["tool_calls"] = formatted

        return {k: v for k, v in info.items() if v is not None}

    def messages_to_oci_params(self, messages: Sequence[ChatMessage]) -> Dict[str, Any]:
        role_map = {
            "user": "USER",
            "system": "SYSTEM",
            "chatbot": "ASSISTANT",
            "assistant": "ASSISTANT",
            "tool": "TOOL",
            "function": "TOOL",
        }

        oci_messages: List[Any] = []
        for msg in messages:
            content_blocks = getattr(msg, "blocks", None) or msg.content or ""
            role_key = msg.role if isinstance(msg.role, str) else msg.role.value
            role = role_map[role_key]

            if role == "TOOL":
                tool_call_id = msg.additional_kwargs.get("tool_call_id")
                if tool_call_id is None:
                    continue
                contents = self._process_message_content(content_blocks)
                oci_messages.append(
                    self.oci_chat_message[role](
                        role="TOOL", tool_call_id=tool_call_id, content=contents
                    )
                )
                continue

            if role == "ASSISTANT":
                contents = (
                    self._process_message_content(content_blocks)
                    if content_blocks
                    else None
                )
                tool_calls_li = msg.additional_kwargs.get("tool_calls", [])
                oci_tool_calls = None
                if tool_calls_li and self.oci_tool_call is not None:
                    oci_tool_calls = []
                    for tc in tool_calls_li:
                        validate_tool_call(tc)
                        name = tc.get("name")
                        arguments = tc.get("input")
                        if not isinstance(arguments, str):
                            arguments = json.dumps(arguments)
                        tc_id = tc.get("toolUseId")
                        try:
                            if tc_id is not None:
                                oci_tool_calls.append(
                                    self.oci_tool_call(
                                        name=name, arguments=arguments, id=tc_id
                                    )
                                )
                            else:
                                oci_tool_calls.append(
                                    self.oci_tool_call(name=name, arguments=arguments)
                                )
                        except TypeError:
                            oci_tool_calls.append(
                                self.oci_tool_call(name=name, arguments=arguments)
                            )

                kwargs: Dict[str, Any] = {}
                if contents is not None:
                    kwargs["content"] = contents
                if oci_tool_calls:
                    kwargs["tool_calls"] = oci_tool_calls
                oci_messages.append(self.oci_chat_message[role](**kwargs))
                continue

            contents = self._process_message_content(content_blocks)
            oci_messages.append(self.oci_chat_message[role](content=contents))

        return {
            "messages": oci_messages,
            "api_format": self.chat_api_format,
            "top_k": -1,
        }

    def _process_message_content(
        self, content: Union[str, List[Union[TextBlock, ImageBlock]]]
    ) -> List[Any]:
        if isinstance(content, str):
            return [self.oci_chat_message_text_content(text=content)]
        if not isinstance(content, list):
            raise ValueError("Message content must be a string or blocks.")
        processed: List[Any] = []
        for item in content:
            if isinstance(item, TextBlock):
                processed.append(self.oci_chat_message_text_content(text=item.text))
            elif isinstance(item, ImageBlock):
                processed.append(
                    self.oci_chat_message_image_content(
                        image_url=self.oci_chat_message_image_url(url=str(item.url))
                    )
                )
            else:
                raise ValueError(
                    f"Items in blocks must be TextBlock or ImageBlock, got: {type(item)}"
                )
        return processed

    def convert_to_oci_tool(
        self,
        tool: Union[Union[Dict[str, Any], Type[BaseModel], Callable, BaseTool]],
    ) -> Dict[str, Any]:
        try:
            from oci.generative_ai_inference import models
        except ImportError as ex:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            ) from ex

        def _fn_properties_from_callable(fn: Callable) -> Dict[str, Any]:
            sig = inspect.signature(fn)
            properties: Dict[str, Any] = {}
            required: List[str] = []
            py_to_json = {
                str: "string",
                int: "integer",
                float: "number",
                bool: "boolean",
            }
            for name, param in sig.parameters.items():
                ann = param.annotation
                json_type = (
                    py_to_json.get(ann, "string") if isinstance(ann, type) else "string"
                )
                if param.default is inspect._empty:
                    required.append(name)
                properties[name] = {
                    "type": json_type,
                    "description": f"Parameter: {name}",
                }
            return {"properties": properties, "required": required}

        if isinstance(tool, BaseTool):
            tool_name = getattr(tool, "name", None) or getattr(
                tool.metadata, "name", None
            )
            tool_desc = getattr(tool, "description", None)
            if tool_desc is None and (tool_fn := getattr(tool, "fn", None)) is not None:
                tool_desc = tool_fn.__doc__
                if tool_name is None:
                    tool_name = tool_fn.__name__
            if tool_desc is None:
                tool_desc = getattr(tool.metadata, "description", None)
            if not tool_name or not tool_desc:
                raise ValueError(f"Tool {tool} does not have a name or description.")

            params_dict = tool.metadata.get_parameters_dict() or {}
            properties = params_dict.get("properties", {})
            required = params_dict.get("required", [])
            return models.FunctionDefinition(
                type="FUNCTION",
                name=tool_name,
                description=tool_desc,
                parameters={
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            )

        if isinstance(tool, dict):
            if not all(k in tool for k in ("title", "description", "properties")):
                raise ValueError(
                    "Unsupported dict type. Tool must be passed in as a BaseTool instance, JSON schema dict, or BaseModel type."
                )
            return models.FunctionDefinition(
                type="FUNCTION",
                name=tool.get("title"),
                description=tool.get("description"),
                parameters={
                    "type": "object",
                    "properties": tool.get("properties", {}),
                    "required": tool.get("required", []),
                },
            )

        if isinstance(tool, type) and issubclass(tool, BaseModel):
            schema = tool.model_json_schema()
            return models.FunctionDefinition(
                type="FUNCTION",
                name=schema.get("title", tool.__name__),
                description=schema.get("description", tool.__name__),
                parameters={
                    "type": "object",
                    "properties": schema.get("properties", {}),
                    "required": schema.get("required", []),
                },
            )

        if callable(tool):
            schema_like = _fn_properties_from_callable(tool)
            return models.FunctionDefinition(
                type="FUNCTION",
                name=tool.__name__,
                description=tool.__doc__ or f"Callable function: {tool.__name__}",
                parameters={
                    "type": "object",
                    "properties": schema_like["properties"],
                    "required": schema_like["required"],
                },
            )

        raise ValueError(
            f"Unsupported tool type {type(tool)}. Tool must be passed in as a BaseTool instance, JSON schema dict, or BaseModel type."
        )


PROVIDERS = {"cohere": CohereProvider(), "meta": MetaProvider(), "xai": XAIProvider()}


def get_provider(model: str, provider_name: str = None) -> Any:
    if provider_name is None:
        provider_name = model.split(".")[0].lower()

    if provider_name not in PROVIDERS:
        raise ValueError(
            f"Invalid provider derived from model_id: {model} "
            "Please explicitly pass in the supported provider "
            "when using custom endpoint"
        )

    return PROVIDERS[provider_name]


def get_context_size(model: str, context_size: int = None) -> int:
    if context_size is None:
        try:
            return OCIGENAI_LLMS[model]
        except KeyError as e:
            if model.startswith(CUSTOM_ENDPOINT_PREFIX):
                raise ValueError(
                    f"Invalid context size derived from model_id: {model} "
                    "Please explicitly pass in the context size "
                    "when using custom endpoint",
                    e,
                ) from e
            else:
                raise ValueError(
                    f"Invalid model name {model} "
                    "Please double check the following OCI documentation if the model is supported "
                    "https://docs.public.oneportal.content.oci.oraclecloud.com/en-us/iaas/Content/generative-ai/pretrained-models.htm#pretrained-models",
                    e,
                ) from e
    else:
        return context_size


def validate_tool_call(tool_call: Dict[str, Any]):
    if (
        "input" not in tool_call
        or "toolUseId" not in tool_call
        or "name" not in tool_call
    ):
        raise ValueError("Invalid tool call.")


def force_single_tool_call(response: ChatResponse) -> None:
    tool_calls = response.message.additional_kwargs.get("tool_calls", [])
    if len(tool_calls) > 1:
        response.message.additional_kwargs["tool_calls"] = [tool_calls[0]]
