import os
import httpx
from unittest.mock import MagicMock
from typing import List

import pytest
from pathlib import Path
from pydantic import BaseModel, ValidationError
from anthropic.types.beta.parsed_beta_message import ParsedBetaMessage
from anthropic.types.beta import BetaUsage
from llama_index.core.prompts import PromptTemplate
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import (
    ChatMessage,
    DocumentBlock,
    TextBlock,
    MessageRole,
    ChatResponse,
    CachePoint,
    CacheControl,
    ToolCallBlock,
)
from llama_index.core.base.llms.types import ThinkingBlock
from llama_index.core.tools import FunctionTool
from llama_index.llms.anthropic import Anthropic
from llama_index.llms.anthropic.base import AnthropicChatResponse, _get_default_headers
from llama_index.llms.anthropic.utils import messages_to_anthropic_messages


def test_text_inference_embedding_class():
    names_of_base_classes = [b.__name__ for b in Anthropic.__mro__]
    assert BaseLLM.__name__ in names_of_base_classes


def test_get_default_headers_returns_user_agent():
    """Test that _get_default_headers returns a User-Agent header."""
    headers = _get_default_headers()
    assert isinstance(headers, dict)
    assert "User-Agent" in headers
    assert headers["User-Agent"].startswith("llama-index/")


def test_get_default_headers_merges_user_headers():
    """Test that user-provided headers are merged and take precedence."""
    user_headers = {"X-Custom": "value", "User-Agent": "my-app/1.0"}
    headers = _get_default_headers(user_headers)
    assert headers["X-Custom"] == "value"
    assert headers["User-Agent"] == "my-app/1.0"


def test_get_default_headers_preserves_default_when_no_conflict():
    """Test that default User-Agent is preserved when user headers don't override it."""
    user_headers = {"X-Custom": "value"}
    headers = _get_default_headers(user_headers)
    assert headers["X-Custom"] == "value"
    assert headers["User-Agent"].startswith("llama-index/")


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_PROJECT_ID") is None,
    reason="Project ID not available to test Vertex AI integration",
)
def test_anthropic_through_vertex_ai():
    anthropic_llm = Anthropic(
        model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5@20250929"),
        region=os.getenv("ANTHROPIC_REGION", "europe-west1"),
        project_id=os.getenv("ANTHROPIC_PROJECT_ID"),
    )

    completion_response = anthropic_llm.complete("Give me a recipe for banana bread")

    try:
        assert isinstance(completion_response.text, str)
        print("Assertion passed for completion_response.text")
    except AssertionError:
        print(
            f"Assertion failed for completion_response.text: {completion_response.text}"
        )
        raise


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_AWS_REGION") is None,
    reason="AWS region not available to test Bedrock integration",
)
def test_anthropic_through_bedrock():
    anthropic_llm = Anthropic(
        aws_region=os.getenv("ANTHROPIC_AWS_REGION", "us-east-1"),
        model=os.getenv("ANTHROPIC_MODEL", "anthropic.claude-sonnet-4-5-20250929-v1:0"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

    completion_response = anthropic_llm.complete("Give me a recipe for banana bread")
    print("testing completion")
    try:
        assert isinstance(completion_response.text, str)
        print("Assertion passed for completion_response.text")
    except AssertionError:
        print(
            f"Assertion failed for completion_response.text: {completion_response.text}"
        )
        raise

    # Test streaming completion
    stream_resp = anthropic_llm.stream_complete(
        "Answer in 5 sentences or less. Paul Graham is "
    )
    full_response = ""
    for chunk in stream_resp:
        full_response += chunk.delta

    try:
        assert isinstance(full_response, str)
        print("Assertion passed: full_response is a string")
    except AssertionError:
        print(f"Assertion failed: full_response is not a string")
        print(f"Type of full_response: {type(full_response)}")
        print(f"Content of full_response: {full_response}")
        raise

    messages = [
        ChatMessage(
            role="system", content="You are a pirate with a colorful personality"
        ),
        ChatMessage(role="user", content="Tell me a story"),
    ]

    chat_response = anthropic_llm.chat(messages)
    print("testing chat")
    try:
        assert isinstance(chat_response.message.content, str)
        print("Assertion passed for chat_response")
    except AssertionError:
        print(f"Assertion failed for chat_response: {chat_response}")
        raise

    # Test streaming chat
    stream_chat_resp = anthropic_llm.stream_chat(messages)
    print("testing stream chat")
    full_response = ""
    for chunk in stream_chat_resp:
        full_response += chunk.delta

    try:
        assert isinstance(full_response, str)
        print("Assertion passed: full_response is a string")
    except AssertionError:
        print(f"Assertion failed: full_response is not a string")
        print(f"Type of full_response: {type(full_response)}")
        print(f"Content of full_response: {full_response}")
        raise


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_AWS_REGION") is None,
    reason="AWS region not available to test Bedrock integration",
)
@pytest.mark.asyncio
async def test_anthropic_through_bedrock_async():
    # Note: this assumes you have AWS credentials configured.
    anthropic_llm = Anthropic(
        aws_region=os.getenv("ANTHROPIC_AWS_REGION", "us-east-1"),
        model=os.getenv("ANTHROPIC_MODEL", "anthropic.claude-sonnet-4-5-20250929-v1:0"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

    # Test standard async completion
    standard_resp = await anthropic_llm.acomplete(
        "Answer in two sentences or less. Paul Graham is "
    )
    try:
        assert isinstance(standard_resp.text, str)
    except AssertionError:
        print(f"Assertion failed for standard_resp.text: {standard_resp.text}")
        raise

    # Test async streaming
    stream_resp = await anthropic_llm.astream_complete(
        "Answer in 5 sentences or less. Paul Graham is "
    )
    full_response = ""
    async for chunk in stream_resp:
        full_response += chunk.delta

    try:
        assert isinstance(full_response, str)
    except AssertionError:
        print(f"Assertion failed: full_response is not a string")
        print(f"Content of full_response: {full_response}")
        raise
    # Test async chat
    messages = [
        ChatMessage(role="system", content="You are a helpful assistant"),
        ChatMessage(role="user", content="Tell me a short story about AI"),
    ]

    chat_resp = await anthropic_llm.achat(messages)
    try:
        assert isinstance(chat_resp.message.content, str)
    except AssertionError:
        print(f"Assertion failed for chat_resp: {chat_resp}")
        raise

    # Test async streaming chat
    stream_chat_resp = await anthropic_llm.astream_chat(messages)
    full_response = ""
    async for chunk in stream_chat_resp:
        full_response += chunk.delta

    try:
        assert isinstance(full_response, str)
    except AssertionError:
        print(f"Assertion failed: full_response is not a string")
        print(f"Content of full_response: {full_response}")
        raise


def test_anthropic_tokenizer():
    """Test that the Anthropic tokenizer properly implements the Tokenizer protocol."""
    # Create a mock Messages object that returns a predictable token count
    mock_messages = MagicMock()
    mock_messages.count_tokens.return_value.input_tokens = 5

    # Create a mock Beta object that returns our mock messages
    mock_beta = MagicMock()
    mock_beta.messages = mock_messages

    # Create a mock client that returns our mock beta
    mock_client = MagicMock()
    mock_client.beta = mock_beta

    # Create the Anthropic instance with our mock
    anthropic_llm = Anthropic(model="claude-sonnet-4-5-20250929")
    anthropic_llm._client = mock_client

    # Test that tokenizer implements the protocol
    tokenizer = anthropic_llm.tokenizer
    assert hasattr(tokenizer, "encode")

    # Test that encode returns a list of integers
    test_text = "Hello, world!"
    tokens = tokenizer.encode(test_text)
    assert isinstance(tokens, list)
    assert all(isinstance(t, int) for t in tokens)
    assert len(tokens) == 5  # Should match our mocked token count

    # Verify the mock was called correctly
    mock_messages.count_tokens.assert_called_once_with(
        messages=[{"role": "user", "content": test_text}],
        model="claude-sonnet-4-5-20250929",
    )


def test__prepare_chat_with_tools_empty():
    llm = Anthropic()
    retval = llm._prepare_chat_with_tools(tools=[])
    assert retval["tools"] == []


@pytest.fixture()
def pdf_url() -> str:
    return "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test Anthropic integration",
)
def test_tool_required():
    llm = Anthropic(model="claude-sonnet-4-5-20250929")

    search_tool = FunctionTool.from_defaults(fn=search, name="search")

    # Test with tool_required=True
    response = llm.chat_with_tools(
        user_msg="What is the weather in Paris?",
        tools=[search_tool],
        tool_required=True,
    )
    assert isinstance(response, AnthropicChatResponse)
    assert (
        len(
            [
                block
                for block in response.message.blocks
                if isinstance(block, ToolCallBlock)
            ]
        )
        > 0
    )
    assert (
        any(
            block.tool_name == "search"
            for block in response.message.blocks
            if isinstance(block, ToolCallBlock)
        )
        > 0
    )

    # Test with tool_required=False
    response = llm.chat_with_tools(
        user_msg="Say hello!",
        tools=[search_tool],
        tool_required=False,
    )
    assert isinstance(response, AnthropicChatResponse)
    # Should not use tools for a simple greeting
    assert (
        len(
            [
                block
                for block in response.message.blocks
                if isinstance(block, ToolCallBlock)
            ]
        )
        == 0
    )

    # should not blow up with no tools (regression test)
    response = llm.chat_with_tools(
        user_msg="Say hello!",
        tools=[],
        tool_required=False,
    )
    assert isinstance(response, AnthropicChatResponse)
    assert (
        len(
            [
                block
                for block in response.message.blocks
                if isinstance(block, ToolCallBlock)
            ]
        )
        == 0
    )


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test Anthropic document uploading ",
)
def test_document_upload(tmp_path: Path, pdf_url: str) -> None:
    llm = Anthropic(model="claude-sonnet-4-5-20250929")
    pdf_path = tmp_path / "test.pdf"
    pdf_content = httpx.get(pdf_url).content
    pdf_path.write_bytes(pdf_content)
    msg = ChatMessage(
        role=MessageRole.USER,
        blocks=[
            DocumentBlock(path=pdf_path),
            TextBlock(text="What does the document contain?"),
        ],
    )
    messages = [msg]
    response = llm.chat(messages)
    assert isinstance(response, ChatResponse)


def test_map_tool_choice_to_anthropic():
    """Test that tool_required is correctly mapped to Anthropic's tool_choice parameter."""
    llm = Anthropic()

    # Test with tool_required=True
    tool_choice = llm._map_tool_choice_to_anthropic(
        tool_required=True, allow_parallel_tool_calls=False
    )
    assert tool_choice["type"] == "any"
    assert tool_choice["disable_parallel_tool_use"]

    # Test with tool_required=False
    tool_choice = llm._map_tool_choice_to_anthropic(
        tool_required=False, allow_parallel_tool_calls=False
    )
    assert tool_choice["type"] == "auto"
    assert tool_choice["disable_parallel_tool_use"]

    # Test with allow_parallel_tool_calls=True
    tool_choice = llm._map_tool_choice_to_anthropic(
        tool_required=True, allow_parallel_tool_calls=True
    )
    assert tool_choice["type"] == "any"
    assert not tool_choice["disable_parallel_tool_use"]


def search(query: str) -> str:
    """Search for information about a query."""
    return f"Results for {query}"


search_tool = FunctionTool.from_defaults(
    fn=search, name="search_tool", description="A tool for searching information"
)


def test_prepare_chat_with_tools_tool_required():
    """Test that tool_required is correctly passed to the API request when True."""
    llm = Anthropic()

    # Test with tool_required=True
    result = llm._prepare_chat_with_tools(tools=[search_tool], tool_required=True)

    assert result["tool_choice"]["type"] == "any"
    assert len(result["tools"]) == 1
    assert result["tools"][0]["name"] == "search_tool"


def test_prepare_chat_with_tools_tool_not_required():
    """Test that tool_required is correctly passed to the API request when False."""
    llm = Anthropic()

    # Test with tool_required=False (default)
    result = llm._prepare_chat_with_tools(
        tools=[search_tool],
    )

    assert result["tool_choice"]["type"] == "auto"
    assert len(result["tools"]) == 1
    assert result["tools"][0]["name"] == "search_tool"


def test_prepare_chat_with_no_tools_tool_not_required():
    """Test that tool_required is correctly passed to the API request when False."""
    llm = Anthropic()

    result = llm._prepare_chat_with_tools(tools=[])

    assert "tool_choice" not in result
    assert len(result["tools"]) == 0


def test_cache_point_to_cache_control() -> None:
    messages = [
        ChatMessage(role="system", blocks=[TextBlock(text="Hello1")]),
        ChatMessage(
            role="user",
            blocks=[
                TextBlock(text="Hello"),
                CachePoint(cache_control=CacheControl(type="ephemeral")),
            ],
        ),
    ]
    ant_messages, _ = messages_to_anthropic_messages(messages)
    assert ant_messages[0]["content"][-1]["cache_control"]["type"] == "ephemeral"
    assert ant_messages[0]["content"][-1]["cache_control"]["ttl"] == "5m"


def test_thinking_input():
    messages = [
        ChatMessage(
            role="assistant",
            blocks=[
                ThinkingBlock(content="Hello"),
                TextBlock(text="World"),
            ],
        ),
    ]
    ant_messages, _ = messages_to_anthropic_messages(messages)
    assert ant_messages[0]["role"] == "assistant"
    assert ant_messages[0]["content"][0]["type"] == "thinking"
    assert ant_messages[0]["content"][0]["thinking"] == "Hello"
    assert ant_messages[0]["content"][1]["type"] == "text"
    assert ant_messages[0]["content"][1]["text"] == "World"


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test Anthropic document uploading ",
)
def test_thinking():
    llm = Anthropic(
        model="claude-sonnet-4-0",
        # max_tokens must be greater than budget_tokens
        max_tokens=64000,
        # temperature must be 1.0 for thinking to work
        temperature=1.0,
        thinking_dict={"type": "enabled", "budget_tokens": 1600},
    )
    res = llm.chat(
        messages=[
            ChatMessage(
                content="Please solve the following equation for x: x^2+12x+7=0. Please think before providing a response."
            )
        ]
    )
    assert any(isinstance(block, ThinkingBlock) for block in res.message.blocks)
    assert (
        len(
            "".join(
                [
                    block.content or ""
                    for block in res.message.blocks
                    if isinstance(block, ThinkingBlock)
                ]
            )
        )
        > 0
    )


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test Anthropic document uploading ",
)
def test_thinking_with_structured_output():
    # Example from: https://docs.llamaindex.ai/en/stable/examples/llm/anthropic/#structured-prediction
    class MenuItem(BaseModel):
        """A menu item in a restaurant."""

        course_name: str
        is_vegetarian: bool

    class Restaurant(BaseModel):
        """A restaurant with name, city, and cuisine."""

        name: str
        city: str
        cuisine: str
        menu_items: List[MenuItem]

    llm = Anthropic(
        model="claude-sonnet-4-5",
        # max_tokens must be greater than budget_tokens
        max_tokens=64000,
        # temperature must be 1.0 for thinking to work
        temperature=1.0,
        thinking_dict={"type": "enabled", "budget_tokens": 1600},
    )
    prompt_tmpl = PromptTemplate("Generate a restaurant in a given city {city_name}")

    restaurant_obj = (
        llm.as_structured_llm(Restaurant)
        .complete(prompt_tmpl.format(city_name="Miami"))
        .raw
    )

    assert isinstance(restaurant_obj, Restaurant)


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test Anthropic document uploading ",
)
def test_thinking_with_tool_should_fail():
    class MenuItem(BaseModel):
        """A menu item in a restaurant."""

        course_name: str
        is_vegetarian: bool

    class Restaurant(BaseModel):
        """A restaurant with name, city, and cuisine."""

        name: str
        city: str
        cuisine: str
        menu_items: List[MenuItem]

    def generate_restaurant(restaurant: Restaurant) -> Restaurant:
        return restaurant

    llm = Anthropic(
        model="claude-sonnet-4-0",
        # max_tokens must be greater than budget_tokens
        max_tokens=64000,
        # temperature must be 1.0 for thinking to work
        temperature=1.0,
        thinking_dict={"type": "enabled", "budget_tokens": 1600},
    )

    # Raises an exception because Anthropic doesn't support tool choice when thinking is enabled
    with pytest.raises(Exception):
        llm.chat_with_tools(
            user_msg="Generate a restaurant in a given city Miami",
            tools=[generate_restaurant],
            tool_choice={"type": "any"},
        )


def test_messages_to_anthropic_messages_with_cache_idx_supported_model():
    """Test cache_idx handling with a model that supports prompt caching."""
    messages = [
        ChatMessage(role=MessageRole.SYSTEM, content="System prompt"),
        ChatMessage(role=MessageRole.USER, content="User message 1"),
        ChatMessage(role=MessageRole.ASSISTANT, content="Assistant response 1"),
        ChatMessage(role=MessageRole.USER, content="User message 2"),
    ]

    # Use a model that supports caching with cache_idx=2
    # This should cache messages[0] (SYSTEM), messages[1] (USER), messages[2] (ASSISTANT)
    anthropic_messages, system_prompt = messages_to_anthropic_messages(
        messages, cache_idx=2, model="claude-sonnet-4-5-20250929"
    )

    # cache_idx=2 means cache up to and including index 2 in original messages
    # anthropic_messages[0] = messages[1] (USER) - should have cache
    # anthropic_messages[1] = messages[2] (ASSISTANT) - should have cache
    # anthropic_messages[2] = messages[3] (USER) - should NOT have cache
    assert "cache_control" in anthropic_messages[0]["content"][0]
    assert anthropic_messages[0]["content"][0]["cache_control"]["type"] == "ephemeral"
    assert "cache_control" in anthropic_messages[1]["content"][0]
    assert anthropic_messages[1]["content"][0]["cache_control"]["type"] == "ephemeral"
    assert "cache_control" not in anthropic_messages[2]["content"][0]


def test_messages_to_anthropic_messages_with_cache_idx_unsupported_model():
    """Test cache_idx handling with a model that doesn't support prompt caching."""
    messages = [
        ChatMessage(role=MessageRole.SYSTEM, content="System prompt"),
        ChatMessage(role=MessageRole.USER, content="User message 1"),
        ChatMessage(role=MessageRole.ASSISTANT, content="Assistant response 1"),
    ]

    # Use a model that doesn't support caching
    anthropic_messages, system_prompt = messages_to_anthropic_messages(
        messages, cache_idx=1, model="claude-2.1"
    )

    # No messages should have cache_control when model doesn't support it
    for msg in anthropic_messages:
        assert "cache_control" not in msg["content"][0]


def test_messages_to_anthropic_messages_with_cache_idx_no_model():
    """Test cache_idx handling when no model is specified (should allow caching)."""
    messages = [
        ChatMessage(role=MessageRole.USER, content="User message 1"),
        ChatMessage(role=MessageRole.ASSISTANT, content="Assistant response 1"),
    ]

    # No model specified - should include cache_control
    anthropic_messages, system_prompt = messages_to_anthropic_messages(
        messages, cache_idx=0, model=None
    )

    # First message should have cache_control when model is None
    assert "cache_control" in anthropic_messages[0]["content"][0]
    assert anthropic_messages[0]["content"][0]["cache_control"]["type"] == "ephemeral"


def test_prepare_chat_with_tools_caching_supported_model():
    """Test tool caching with a model that supports prompt caching."""
    llm = Anthropic(model="claude-sonnet-4-5-20250929")

    # Prepare tools with prompt caching enabled
    result = llm._prepare_chat_with_tools(
        tools=[search_tool],
        extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"},
    )

    # Should have cache_control on last tool
    assert len(result["tools"]) == 1
    assert "cache_control" in result["tools"][0]
    assert result["tools"][0]["cache_control"]["type"] == "ephemeral"


def test_prepare_chat_with_tools_caching_unsupported_model(caplog):
    """Test tool caching with a model that doesn't support prompt caching."""
    llm = Anthropic(model="claude-2.1")

    # Prepare tools with prompt caching enabled but unsupported model
    result = llm._prepare_chat_with_tools(
        tools=[search_tool],
        extra_headers={"anthropic-beta": "prompt-caching-2024-07-31"},
    )

    # Should not have cache_control when model doesn't support it
    assert len(result["tools"]) == 1
    assert "cache_control" not in result["tools"][0]

    # Check that warning was logged
    assert "does not support prompt caching" in caplog.text
    assert "claude-2.1" in caplog.text


def test_stream_chat_usage_and_stop_reason_mock():
    """
    Mock test for streaming usage metadata and stop_reason - no API key required.

    This test verifies that stream_chat properly captures and yields:
    - usage metadata (input_tokens, output_tokens) from RawMessageDeltaEvent
    - stop_reason from RawMessageDeltaEvent

    Related to issue #20194.
    """
    from unittest.mock import MagicMock
    from anthropic.types import TextDelta, Usage

    # Create mock events that simulate Anthropic streaming response
    mock_text_delta = MagicMock(spec=TextDelta)
    mock_text_delta.text = "Hello"
    mock_text_delta.type = "text_delta"

    mock_content_delta_event = MagicMock()
    mock_content_delta_event.delta = mock_text_delta
    mock_content_delta_event.index = 0

    mock_content_stop_event = MagicMock()
    mock_content_stop_event.index = 0

    # Create mock RawMessageDeltaEvent with usage and stop_reason
    # First event with initial usage
    mock_first_usage = MagicMock(spec=Usage)
    mock_first_usage.input_tokens = 15
    mock_first_usage.output_tokens = 1

    # Last event with final usage
    # Note that input_tokens can be None
    # Also note that output tokens are cumulative
    mock_last_usage = MagicMock(spec=Usage)
    mock_last_usage.input_tokens = None
    mock_last_usage.output_tokens = 8

    mock_delta = MagicMock()
    mock_delta.stop_reason = "end_turn"

    mock_message_delta_event = MagicMock()
    mock_message_delta_event.usage = mock_last_usage
    mock_message_delta_event.delta = mock_delta

    # Create mock streaming response generator
    def mock_stream_generator():
        from anthropic.types import (
            RawContentBlockDeltaEvent,
            ContentBlockStopEvent,
            RawMessageDeltaEvent,
            RawMessageStartEvent,
            Message,
        )

        # Simulate streaming events
        yield MagicMock(
            spec=RawMessageStartEvent,
            message=MagicMock(spec=Message, usage=mock_first_usage),
        )
        yield MagicMock(spec=RawContentBlockDeltaEvent, delta=mock_text_delta, index=0)
        yield MagicMock(spec=ContentBlockStopEvent, index=0)
        yield MagicMock(
            spec=RawMessageDeltaEvent,
            usage=mock_last_usage,
            delta=mock_delta,
        )

    # Create Anthropic LLM and mock its client
    llm = Anthropic(model="claude-sonnet-4-5")
    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_stream_generator()
    llm._client = mock_client

    # Test stream_chat
    messages = [ChatMessage(role="user", content="Test message")]
    stream_resp = llm.stream_chat(messages)

    # Collect all chunks
    chunks = list(stream_resp)

    # Verify we got responses
    assert len(chunks) > 0, "Should yield at least one chunk"
    last_chunk = chunks[-1]
    assert isinstance(last_chunk, AnthropicChatResponse)

    # Verify usage metadata was captured
    usage = last_chunk.message.additional_kwargs.get("usage")
    assert usage is not None, (
        "Usage metadata should be captured from RawMessageDeltaEvent"
    )
    assert usage["input_tokens"] == 15
    assert usage["output_tokens"] == 8

    # Verify stop_reason was captured
    stop_reason = last_chunk.message.additional_kwargs.get("stop_reason")
    assert stop_reason is not None, (
        "stop_reason should be captured from RawMessageDeltaEvent"
    )
    assert stop_reason == "end_turn"


@pytest.mark.asyncio
async def test_astream_chat_usage_and_stop_reason_mock():
    """
    Mock test for async streaming usage metadata and stop_reason - no API key required.

    Async version of test_stream_chat_usage_and_stop_reason_mock.
    Related to issue #20194.
    """
    from unittest.mock import MagicMock, AsyncMock
    from anthropic.types import TextDelta, Usage

    # Create mock events
    mock_text_delta = MagicMock(spec=TextDelta)
    mock_text_delta.text = "Hello async"
    mock_text_delta.type = "text_delta"

    mock_first_usage = MagicMock(spec=Usage)
    mock_first_usage.input_tokens = 20
    mock_first_usage.output_tokens = 1

    mock_last_usage = MagicMock(spec=Usage)
    mock_last_usage.input_tokens = None
    mock_last_usage.output_tokens = 12

    mock_delta = MagicMock()
    mock_delta.stop_reason = "max_tokens"

    # Create async mock streaming response generator
    async def mock_async_stream_generator():
        from anthropic.types import (
            RawContentBlockDeltaEvent,
            ContentBlockStopEvent,
            RawMessageDeltaEvent,
            RawMessageStartEvent,
            Message,
        )

        yield MagicMock(
            spec=RawMessageStartEvent,
            message=MagicMock(spec=Message, usage=mock_first_usage),
        )
        yield MagicMock(spec=RawContentBlockDeltaEvent, delta=mock_text_delta, index=0)
        yield MagicMock(spec=ContentBlockStopEvent, index=0)
        yield MagicMock(
            spec=RawMessageDeltaEvent,
            usage=mock_last_usage,
            delta=mock_delta,
        )

    # Create Anthropic LLM and mock its async client
    llm = Anthropic(model="claude-sonnet-4-5")
    mock_async_client = AsyncMock()
    # For async client, the create method should be an AsyncMock that returns the generator
    mock_async_client.messages.create = AsyncMock(
        return_value=mock_async_stream_generator()
    )
    llm._aclient = mock_async_client

    # Test astream_chat
    messages = [ChatMessage(role="user", content="Test async message")]
    stream_resp = await llm.astream_chat(messages)

    # Collect all chunks
    chunks = []
    async for chunk in stream_resp:
        chunks.append(chunk)

    # Verify we got responses
    assert len(chunks) > 0, "Should yield at least one chunk"
    last_chunk = chunks[-1]
    assert isinstance(last_chunk, AnthropicChatResponse)

    # Verify usage metadata was captured
    usage = last_chunk.message.additional_kwargs.get("usage")
    assert usage is not None, "Usage metadata should be captured in async streaming"
    assert usage["input_tokens"] == 20
    assert usage["output_tokens"] == 12

    # Verify stop_reason was captured
    stop_reason = last_chunk.message.additional_kwargs.get("stop_reason")
    assert stop_reason is not None, "stop_reason should be captured in async streaming"
    assert stop_reason == "max_tokens"


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test streaming metadata",
)
def test_stream_chat_usage_and_stop_reason():
    """
    Test that streaming captures usage metadata and stop_reason from RawMessageDeltaEvent.

    This addresses issue #20194 - Anthropic RawMessageDeltaEvent support.
    The streaming API should capture:
    - input_tokens and output_tokens from usage metadata
    - stop_reason (e.g., 'end_turn', 'max_tokens') to understand why streaming stopped
    """
    llm = Anthropic(model="claude-sonnet-4-5")
    messages = [
        ChatMessage(role="user", content="Say hello in 3 words"),
    ]

    # Stream the response
    stream_resp = llm.stream_chat(messages)
    last_chunk = None
    for chunk in stream_resp:
        last_chunk = chunk

    # Verify we got a response
    assert last_chunk is not None
    assert isinstance(last_chunk, AnthropicChatResponse)

    # Check that usage metadata was captured
    usage = last_chunk.message.additional_kwargs.get("usage")
    assert usage is not None, (
        "Usage metadata should be captured from RawMessageDeltaEvent"
    )
    assert "input_tokens" in usage, "Usage should include input_tokens"
    assert "output_tokens" in usage, "Usage should include output_tokens"
    assert isinstance(usage["input_tokens"], int)
    assert isinstance(usage["output_tokens"], int)
    assert usage["input_tokens"] > 0, "Should have processed input tokens"
    assert usage["output_tokens"] > 0, "Should have generated output tokens"

    # Check that stop_reason was captured
    stop_reason = last_chunk.message.additional_kwargs.get("stop_reason")
    assert stop_reason is not None, (
        "stop_reason should be captured from RawMessageDeltaEvent"
    )
    # Typical stop reasons: "end_turn", "max_tokens", "stop_sequence", "tool_use"
    assert isinstance(stop_reason, str)
    print(f"Stop reason: {stop_reason}")
    print(f"Usage: {usage}")


@pytest.mark.skipif(
    os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available to test async streaming metadata",
)
@pytest.mark.asyncio
async def test_astream_chat_usage_and_stop_reason():
    """
    Test that async streaming captures usage metadata and stop_reason.

    Async version of the streaming metadata test for issue #20194.
    """
    llm = Anthropic(model="claude-sonnet-4-5")
    messages = [
        ChatMessage(role="user", content="Count to 5"),
    ]

    # Stream the response asynchronously
    stream_resp = await llm.astream_chat(messages)
    last_chunk = None
    async for chunk in stream_resp:
        last_chunk = chunk

    # Verify we got a response
    assert last_chunk is not None
    assert isinstance(last_chunk, AnthropicChatResponse)

    # Check that usage metadata was captured
    usage = last_chunk.message.additional_kwargs.get("usage")
    assert usage is not None, "Usage metadata should be captured in async streaming"
    assert "input_tokens" in usage
    assert "output_tokens" in usage
    assert isinstance(usage["input_tokens"], int)
    assert isinstance(usage["output_tokens"], int)
    assert usage["output_tokens"] > 0

    # Check that stop_reason was captured
    stop_reason = last_chunk.message.additional_kwargs.get("stop_reason")
    assert stop_reason is not None, "stop_reason should be captured in async streaming"
    assert isinstance(stop_reason, str)
    print(f"Async - Stop reason: {stop_reason}")
    print(f"Async - Usage: {usage}")


class Note(BaseModel):
    content: str


STRUCT_MESSAGES = [
    ChatMessage(
        role="user",
        content="Could you please create a note to remind me that delivery service comes today at midday?",
    )
]


@pytest.mark.skipif(
    condition=os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available",
)
def test_structured_output_supported_sync() -> None:
    llm = Anthropic(model="claude-sonnet-4-5", max_tokens=8192).as_structured_llm(Note)
    response = llm.chat(messages=STRUCT_MESSAGES)
    assert response.message.content is not None
    try:
        struct_resp = Note.model_validate_json(response.message.content)
    except ValidationError:
        struct_resp = None
    assert struct_resp is not None


@pytest.mark.asyncio
@pytest.mark.skipif(
    condition=os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available",
)
async def test_structured_output_supported_async() -> None:
    llm = Anthropic(model="claude-sonnet-4-5", max_tokens=8192).as_structured_llm(Note)
    response = await llm.achat(messages=STRUCT_MESSAGES)
    assert response.message.content is not None
    try:
        struct_resp = Note.model_validate_json(response.message.content)
    except ValidationError:
        struct_resp = None
    assert struct_resp is not None


@pytest.mark.skipif(
    condition=os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available",
)
def test_structured_output_supported_stream() -> None:
    llm = Anthropic(model="claude-sonnet-4-5", max_tokens=8192).as_structured_llm(Note)
    response = llm.stream_chat(messages=STRUCT_MESSAGES)
    responses: list[ChatResponse] = []
    for r in response:
        responses.append(r)
    assert len(responses) == 1
    assert responses[0].message.content is not None
    try:
        struct_resp = Note.model_validate_json(responses[0].message.content)
    except ValidationError:
        struct_resp = None
    assert struct_resp is not None


@pytest.mark.skipif(
    condition=os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available",
)
@pytest.mark.asyncio
async def test_structured_output_supported_astream() -> None:
    llm = Anthropic(model="claude-sonnet-4-5", max_tokens=8192).as_structured_llm(Note)
    response = await llm.astream_chat(messages=STRUCT_MESSAGES)
    responses: list[ChatResponse] = []
    async for r in response:
        responses.append(r)
    assert len(responses) == 1
    assert responses[0].message.content is not None
    try:
        struct_resp = Note.model_validate_json(responses[0].message.content)
    except ValidationError:
        struct_resp = None
    assert struct_resp is not None


@pytest.mark.skipif(
    condition=os.getenv("ANTHROPIC_API_KEY") is None,
    reason="Anthropic API key not available",
)
def test_structured_output_unsupported_but_compatible() -> None:
    # simply make sure that LLMs that do not support
    # structured outputs in the anthropic SDK
    # are still producing structured output
    # with the legacy approach
    llm = Anthropic(model="claude-sonnet-4-0", max_tokens=8192).as_structured_llm(Note)
    response = llm.chat(messages=STRUCT_MESSAGES)
    assert response.message.content is not None
    try:
        struct_resp = Note.model_validate_json(response.message.content)
    except ValidationError:
        struct_resp = None
    assert struct_resp is not None


def test_structured_output_failure_mock() -> None:
    mock_client = MagicMock()
    mock_client.beta.messages.parse.return_value = ParsedBetaMessage(
        id="1",
        content=[],
        model="claude-sonnet-4-5",
        role="assistant",
        stop_reason="max_tokens",
        type="message",
        usage=BetaUsage(input_tokens=0, output_tokens=0),
    )
    llm = Anthropic(model="claude-sonnet-4-5")
    llm._client = mock_client
    sllm = llm.as_structured_llm(Note)
    with pytest.raises(
        ValueError,
        match="It was not possible to produce a structured response because of max_tokens",
    ):
        sllm.chat(STRUCT_MESSAGES)
