import asyncio
import json
import logging
import os
from dataclasses import dataclass
from unittest import mock

# import aiohttp to force Pants to include it in the required dependencies
import aiohttp  # noqa
import pytest
from azure.ai.inference.models import (
    ChatChoice,
    ChatCompletions,
    ChatCompletionsToolChoicePreset,
    ChatResponseMessage,
    ModelInfo,
)
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.core.tools import FunctionTool
from llama_index.llms.azure_inference import AzureAICompletionsModel

logger = logging.getLogger(__name__)


@dataclass
class AsyncClientFixture:
    llm: AzureAICompletionsModel
    client_instance: mock.MagicMock


@pytest.fixture(scope="session")
def loop():
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture()
def test_params() -> dict:
    return {
        "messages": [
            ChatMessage(
                role="system",
                content="You are a helpful assistant. When you are asked about if this "
                "is a test, you always reply 'Yes, this is a test.'",
            ),
            ChatMessage(role="user", content="Is this a test?"),
        ],
        "top_p": 1.0,
        "temperature": 0.0,
    }


@pytest.fixture()
def azure_llm_async_fixture():
    with mock.patch(
        "llama_index.llms.azure_inference.base.ChatCompletionsClient", autospec=True
    ):
        with mock.patch(
            "llama_index.llms.azure_inference.base.ChatCompletionsClientAsync",
            autospec=True,
        ) as mock_async_client_cls:
            llm = AzureAICompletionsModel(
                endpoint="https://my-endpoint.inference.ai.azure.com",
                credential="my-api-key",
            )
    client_instance = mock_async_client_cls.return_value
    # Azure async client's __aenter__ returns self; mirror that behavior in tests.
    client_instance.__aenter__.return_value = client_instance
    # llama-index-core accesses `metadata` (via `to_payload`) on every chat call,
    # which queries the sync client's model info.
    llm._client.get_model_info.return_value = ModelInfo(
        model_name="my_model_name",
        model_provider_name="my_provider_name",
        model_type="chat-completions",
    )
    return AsyncClientFixture(llm=llm, client_instance=client_instance)


@pytest.fixture()
def test_llm(azure_llm_async_fixture):
    llm = azure_llm_async_fixture.llm
    client_instance = azure_llm_async_fixture.client_instance
    entered_client = client_instance.__aenter__.return_value
    entered_client.complete = mock.AsyncMock(
        return_value=ChatCompletions(
            choices=[
                ChatChoice(
                    message=ChatResponseMessage(
                        content="Yes, this is a test.", role="assistant"
                    )
                )
            ]
        )
    )
    llm._client.complete.return_value = ChatCompletions(
        choices=[
            ChatChoice(
                message=ChatResponseMessage(
                    content="Yes, this is a test.", role="assistant"
                )
            )
        ]
    )
    llm._client.get_model_info.return_value = ModelInfo(
        model_name="my_model_name",
        model_provider_name="my_provider_name",
        model_type="chat-completions",
    )
    return llm


@pytest.fixture()
def test_llm_json():
    with mock.patch(
        "llama_index.llms.azure_inference.base.ChatCompletionsClient", autospec=True
    ):
        llm = AzureAICompletionsModel(
            endpoint="https://my-endpoint.inference.ai.azure.com",
            credential="my-api-key",
        )
    llm._client.complete.return_value = ChatCompletions(
        choices=[
            ChatChoice(
                message=ChatResponseMessage(
                    content='{ "message": "Yes, this is a test." }', role="assistant"
                )
            )
        ]
    )
    llm._client.get_model_info.return_value = ModelInfo(
        model_name="my_model_name",
        model_provider_name="my_provider_name",
        model_type="chat-completions",
    )
    return llm


@pytest.fixture()
def test_llm_tools():
    with mock.patch(
        "llama_index.llms.azure_inference.base.ChatCompletionsClient", autospec=True
    ):
        llm = AzureAICompletionsModel(
            endpoint="https://my-endpoint.inference.ai.azure.com",
            credential="my-api-key",
        )
    llm._client.complete.return_value = ChatCompletions(
        choices=[
            ChatChoice(
                message=ChatResponseMessage(
                    role="assistant",
                    content="",
                    tool_calls=[
                        {
                            "id": "abc0dF1gh",
                            "type": "function",
                            "function": {
                                "name": "echo",
                                "arguments": None,
                                "call_id": None,
                            },
                        }
                    ],
                )
            )
        ]
    )
    llm._client.get_model_info.return_value = ModelInfo(
        model_name="my_model_name",
        model_provider_name="my_provider_name",
        model_type="chat-completions",
    )
    return llm


def test_chat_completion(test_llm: AzureAICompletionsModel, test_params: dict):
    """Tests the basic chat completion functionality."""
    response = test_llm.chat(**test_params)

    assert response.message.role == MessageRole.ASSISTANT
    assert response.message.content.strip() == "Yes, this is a test."


def test_achat_completion(
    test_llm: AzureAICompletionsModel,
    loop: asyncio.AbstractEventLoop,
    test_params: dict,
):
    """Tests the basic chat completion functionality asynchronously."""
    response = loop.run_until_complete(test_llm.achat(**test_params))

    assert response.message.role == MessageRole.ASSISTANT
    assert response.message.content.strip() == "Yes, this is a test."


def test_achat_closes_async_client_context(
    loop: asyncio.AbstractEventLoop,
    test_params: dict,
    azure_llm_async_fixture,
):
    """Ensures async client context manager is used for proper session cleanup."""
    llm = azure_llm_async_fixture.llm
    client_instance = azure_llm_async_fixture.client_instance
    entered_client = client_instance.__aenter__.return_value
    entered_client.complete = mock.AsyncMock(
        return_value=ChatCompletions(
            choices=[
                ChatChoice(
                    message=ChatResponseMessage(
                        content="Yes, this is a test.", role="assistant"
                    )
                )
            ]
        )
    )

    response = loop.run_until_complete(llm.achat(**test_params))

    assert response.message.content.strip() == "Yes, this is a test."
    client_instance.__aenter__.assert_awaited_once()
    client_instance.__aexit__.assert_awaited_once()


def test_astream_chat_closes_async_client_context(
    loop: asyncio.AbstractEventLoop,
    test_params: dict,
    azure_llm_async_fixture,
):
    """Ensures async streaming path uses and closes async client context."""
    llm = azure_llm_async_fixture.llm
    client_instance = azure_llm_async_fixture.client_instance
    entered_client = client_instance.__aenter__.return_value

    async def stream_response():
        first_chunk = mock.Mock()
        first_chunk.choices = [mock.Mock(delta=mock.Mock(content="Yes"))]
        second_chunk = mock.Mock()
        second_chunk.choices = [mock.Mock(delta=mock.Mock(content=", this is a test."))]
        yield first_chunk
        yield second_chunk

    entered_client.complete = mock.AsyncMock(return_value=stream_response())

    async def collect() -> str:
        stream = await llm.astream_chat(**test_params)
        buffer = ""
        async for chunk in stream:
            buffer += chunk.delta
        return buffer

    response = loop.run_until_complete(collect())

    assert response == "Yes, this is a test."
    client_instance.__aenter__.assert_awaited_once()
    client_instance.__aexit__.assert_awaited_once()


@pytest.mark.skipif(
    not {
        "AZURE_INFERENCE_ENDPOINT",
        "AZURE_INFERENCE_CREDENTIAL",
    }.issubset(set(os.environ)),
    reason="Azure AI endpoint and/or credential are not set.",
)
def test_stream_chat_completion(test_params: dict):
    """Tests the basic chat completion functionality with streaming."""
    model_name = os.environ.get("AZURE_INFERENCE_MODEL", None)

    llm = AzureAICompletionsModel(model_name=model_name)

    response_stream = llm.stream_chat(**test_params)

    buffer = ""
    for chunk in response_stream:
        buffer += chunk.delta

    assert buffer.strip() == "Yes, this is a test."


@pytest.mark.skipif(
    not {
        "AZURE_INFERENCE_ENDPOINT",
        "AZURE_INFERENCE_CREDENTIAL",
    }.issubset(set(os.environ)),
    reason="Azure AI endpoint and/or credential are not set.",
)
def test_astream_chat_completion(test_params: dict, loop: asyncio.AbstractEventLoop):
    """Tests the basic chat completion functionality with streaming."""
    model_name = os.environ.get("AZURE_INFERENCE_MODEL", None)

    llm = AzureAICompletionsModel(model_name=model_name)

    async def iterate():
        stream = await llm.astream_chat(**test_params)
        buffer = ""
        async for chunk in stream:
            buffer += chunk.delta

        return buffer

    response = loop.run_until_complete(iterate())
    assert response.strip() == "Yes, this is a test."


def test_chat_completion_kwargs(
    test_llm_json: AzureAICompletionsModel,
):
    """Tests chat completions using extra parameters."""
    test_llm_json.model_kwargs.update({"response_format": {"type": "json_object"}})
    response = test_llm_json.chat(
        [
            ChatMessage(
                role="system",
                content="You are a helpful assistant. When you are asked about if this "
                "is a test, you always reply 'Yes, this is a test.' in a JSON object with "
                "key 'message'.",
            ),
            ChatMessage(role="user", content="Is this a test?"),
        ],
        temperature=0.0,
        top_p=1.0,
    )

    assert response.message.role == MessageRole.ASSISTANT
    assert (
        json.loads(response.message.content.strip()).get("message")
        == "Yes, this is a test."
    )


def test_chat_completion_with_tools(test_llm_tools: AzureAICompletionsModel):
    """Tests the chat completion functionality with the help of tools."""

    def echo(message: str) -> str:
        """Echoes the user's message."""
        print("Echo: " + message)
        return message

    response = test_llm_tools.chat_with_tools(
        user_msg="Is this a test?",
        chat_history=[
            ChatMessage(
                role="system",
                content="You are an assistant that always echoes the user's message. To echo a message, use the 'Echo' tool.",
            ),
        ],
        tools=[
            FunctionTool.from_defaults(
                fn=echo,
                name="echo",
                description="Echoes the user's message.",
            ),
        ],
        verbose=True,
    )

    assert response.message.role == MessageRole.ASSISTANT
    assert len(response.message.additional_kwargs["tool_calls"]) == 1
    assert (
        response.message.additional_kwargs["tool_calls"][0]["function"]["name"]
        == "echo"
    )


@pytest.mark.skipif(
    not {
        "AZURE_INFERENCE_ENDPOINT",
        "AZURE_INFERENCE_CREDENTIAL",
    }.issubset(set(os.environ)),
    reason="Azure AI endpoint and/or credential are not set.",
)
def test_chat_completion_gpt4o_api_version(test_params: dict):
    """Test chat completions endpoint with api_version indicated for a GPT model."""
    # In case the endpoint being tested serves more than one model
    model_name = os.environ.get("AZURE_INFERENCE_MODEL", "gpt-4o")

    llm = AzureAICompletionsModel(
        model_name=model_name, api_version="2024-05-01-preview"
    )

    response = llm.chat(**test_params)

    assert response.message.role == MessageRole.ASSISTANT
    assert response.message.content.strip() == "Yes, this is a test."


def test_get_metadata(test_llm: AzureAICompletionsModel, caplog):
    """
    Tests if we can get model metadata back from the endpoint. If so,
    model_name should not be 'unknown'. Some endpoints may not support this
    and in those cases a warning should be logged.
    """
    response = test_llm.metadata

    assert (
        response.model_name != "unknown"
        or "does not support model metadata retrieval" in caplog.text
    )


def test_to_azure_tool_choice():
    """Test that tool_required is correctly mapped to Azure's tool_choice parameter."""
    llm = AzureAICompletionsModel(
        endpoint="https://my-endpoint.inference.ai.azure.com",
        credential="my-api-key",
    )

    # Test with tool_required=True
    tool_choice = llm._to_azure_tool_choice(tool_required=True)
    assert tool_choice == ChatCompletionsToolChoicePreset.REQUIRED

    # Test with tool_required=False
    tool_choice = llm._to_azure_tool_choice(tool_required=False)
    assert tool_choice == ChatCompletionsToolChoicePreset.AUTO


def search(query: str) -> str:
    """Search for information about a query."""
    return f"Results for {query}"


search_tool = FunctionTool.from_defaults(
    fn=search, name="search_tool", description="A tool for searching information"
)


def test_prepare_chat_with_tools_tool_required():
    """Test that tool_required is correctly passed to the API request when True."""
    llm = AzureAICompletionsModel(
        endpoint="https://my-endpoint.inference.ai.azure.com",
        credential="my-api-key",
    )

    # Test with tool_required=True
    result = llm._prepare_chat_with_tools(tools=[search_tool], tool_required=True)

    assert result["tool_choice"] == ChatCompletionsToolChoicePreset.REQUIRED
    assert len(result["tools"]) == 1
    assert result["tools"][0]["function"]["name"] == "search_tool"


def test_prepare_chat_with_tools_tool_not_required():
    """Test that tool_required is correctly passed to the API request when False."""
    llm = AzureAICompletionsModel(
        endpoint="https://my-endpoint.inference.ai.azure.com",
        credential="my-api-key",
    )

    # Test with tool_required=False (default)
    result = llm._prepare_chat_with_tools(
        tools=[search_tool],
    )

    assert result["tool_choice"] == ChatCompletionsToolChoicePreset.AUTO
    assert len(result["tools"]) == 1
    assert result["tools"][0]["function"]["name"] == "search_tool"
