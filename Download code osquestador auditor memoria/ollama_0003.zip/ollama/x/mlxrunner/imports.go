package mlxrunner

import (
	_ "github.com/ollama/ollama/x/models/cohere2_moe"
	_ "github.com/ollama/ollama/x/models/dflash"
	_ "github.com/ollama/ollama/x/models/gemma4"
	_ "github.com/ollama/ollama/x/models/glimmer"
	_ "github.com/ollama/ollama/x/models/glm4_moe_lite"
	_ "github.com/ollama/ollama/x/models/laguna"
	_ "github.com/ollama/ollama/x/models/llama"
	_ "github.com/ollama/ollama/x/models/nemotron_h"
	_ "github.com/ollama/ollama/x/models/qwen3"
	_ "github.com/ollama/ollama/x/models/qwen3_5"
	_ "github.com/ollama/ollama/x/models/qwen3_5_moe"
	_ "github.com/ollama/ollama/x/models/qwen4_exp"
)
