# langchain-qdrant

[![PyPI - Version](https://img.shields.io/pypi/v/langchain-qdrant?label=%20)](https://pypi.org/project/langchain-qdrant/#history)
[![PyPI - License](https://img.shields.io/pypi/l/langchain-qdrant)](https://opensource.org/licenses/MIT)
[![PyPI - Downloads](https://img.shields.io/pepy/dt/langchain-qdrant)](https://pypistats.org/packages/langchain-qdrant)
[![Twitter](https://img.shields.io/twitter/url/https/twitter.com/langchain_oss.svg?style=social&label=Follow%20%40LangChain)](https://x.com/langchain_oss)

Looking for the JS/TS version? Check out [LangChain.js](https://github.com/langchain-ai/langchainjs).

## Quick Install

```bash
uv add langchain-qdrant
```

## 🤔 What is this?

This package contains the LangChain integration with [Qdrant](https://qdrant.tech/).

## 📖 Documentation

View the [documentation](https://docs.langchain.com/oss/python/integrations/providers/qdrant) for more details.

## Resources

- [LangChain Academy](https://academy.langchain.com/) — comprehensive, free courses on LangChain libraries and products, made by the LangChain team
- [Code of Conduct](https://github.com/langchain-ai/langchain/?tab=coc-ov-file) — community guidelines and standards
