"""Tests for Anthropic middleware."""
