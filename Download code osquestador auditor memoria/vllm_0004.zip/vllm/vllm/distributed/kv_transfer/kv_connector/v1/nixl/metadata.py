# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Metadata dataclasses and helpers for the NIXL connector."""

from dataclasses import dataclass
from typing import Any

from vllm.config import VllmConfig
from vllm.distributed.kv_transfer.kv_connector.utils import BlockIds, EngineId
from vllm.distributed.kv_transfer.kv_connector.v1.base import (
    KVConnectorHandshakeMetadata,
    KVConnectorMetadata,
)
from vllm.logger import init_logger

logger = init_logger(__name__)

TransferHandle = int
ReqId = str

GET_META_MSG = b"get_meta_msg"

# Push-mode (WRITE-based) registration notification.
# Sent worker-to-worker over NIXL: D worker -> P worker, encoded as
# PUSH_REG_NOTIF_PREFIX + msgpack(registration_data).
PUSH_REG_NOTIF_PREFIX = b"PUSH_REG:"
#
# NIXL Connector Version
#
# Increment this version whenever there is an incompatible change to:
#   - NixlAgentMetadata schema
#   - kv_transfer_params schema or semantics
#   - NIXL transfer protocol or wire format
#   - KV cache memory layout or block organization
#   - Any other change that breaks P/D interoperability
#
# Version History:
#   1: Initial version with compatibility checking
#   2: Add remote_request_id to kv_transfer_params
#   3: Add physical_blocks_per_logical_kv_block to NixlAgentMetadata
#   4: Add KV block lease renewal through heartbeats
#   5: Add remote_blocks_expiry_time to kv_transfer_params + handshake
#      clock-sync timestamp
#   6: Validate EAGLE/MTP speculative configuration compatibility
#   7: Include NIXL transfer mode (push vs pull) in the compatibility hash
#   8: Add dcp_size and pcp_size to NixlAgentMetadata
#   9: Add block_strides
#
NIXL_CONNECTOR_VERSION: int = 9


@dataclass
class NixlAgentMetadata:
    engine_id: str
    agent_metadata: bytes
    kv_caches_base_addr: list[int]
    device_id: int
    num_blocks: int
    block_lens: list[int]
    block_strides: list[int]
    kv_cache_layout: str
    block_size: int
    ssm_sizes: tuple[int, int]
    attn_backend_name: str
    physical_blocks_per_logical_kv_block: int
    dcp_size: int = 1
    pcp_size: int = 1


@dataclass
class NixlHandshakePayload(KVConnectorHandshakeMetadata):
    """
    Wrapper for NIXL handshake sent over the wire.

    Enables two-phase decoding for graceful compatibility checking:
    1. Decode NixlHandshakePayload to get compatibility_hash
    2. Compute local hash and compare
    3. Only if hashes match, decode agent_metadata_bytes

    This prevents decoder errors when NixlAgentMetadata schema is
    incompatible, allowing graceful failure with clear error message.
    """

    compatibility_hash: str
    agent_metadata_bytes: bytes  # NixlAgentMetadata encoded


def _get_speculative_compatibility_factors(
    vllm_config: VllmConfig,
) -> dict[str, Any] | None:
    """Return NIXL compatibility factors for hidden-state-based speculators."""
    speculative_config = vllm_config.speculative_config
    if speculative_config is None or not speculative_config.use_eagle():
        return None

    draft_model_config = speculative_config.draft_model_config
    assert draft_model_config is not None
    auxiliary_layer_ids = getattr(
        draft_model_config.hf_config,
        "eagle_aux_hidden_state_layer_ids",
        None,
    )

    # kv_cache_dtype is a user override that defaults to None, meaning "inherit
    # the target's --kv-cache-dtype". Resolve it to the effective value so an
    # explicit setting on one side and inheritance on the other (same effective
    # dtype) don't spuriously mismatch.
    kv_cache_dtype = (
        speculative_config.kv_cache_dtype or vllm_config.cache_config.cache_dtype
    )

    # Note: the draft attention_backend is intentionally not hashed. Its only
    # transfer-relevant effect is the KV block layout/size, which is validated
    # per region at runtime in _validate_remote_agent_handshake. The connector
    # only sees the raw override here (usually None = auto-select), never the
    # resolved backend, so hashing it would cause false mismatches without
    # catching anything the runtime layout check misses.
    return {
        "method": speculative_config.method,
        "model": draft_model_config.model,
        "revision": draft_model_config.revision,
        "code_revision": draft_model_config.code_revision,
        "parallel_drafting": speculative_config.parallel_drafting,
        "kv_cache_dtype": str(kv_cache_dtype),
        "auxiliary_layer_ids": (
            tuple(auxiliary_layer_ids) if auxiliary_layer_ids is not None else None
        ),
    }


def compute_nixl_compatibility_hash(
    vllm_config: VllmConfig,
    attn_backend_name: str,
    transfer_mode: str = "pull",
) -> str:
    """
    Compute compatibility hash for NIXL KV transfer.

    Hash only the factors that affect whether two NIXL instances can
    successfully transfer KV cache data.

    Factors included:
    - vLLM version and NIXL connector version
    - Model architecture (name, dtype, KV heads, layers)
    - KV cache format (dtype, sliding window)
    - Attention backend
    - EAGLE/MTP configuration that affects transferred state
    - Transfer mode (push vs pull)

    The transfer mode is included because the push (WRITE) and pull (READ)
    connectors use incompatible transfer protocols; a push connector and a
    pull connector must never complete a handshake with each other.

    Note: Factors like tensor_parallel_size, block_size, and kv_cache_layout
    are validated at runtime in _validate_remote_agent_handshake and are not
    included in this hash to support heterogeneous deployments.

    Note - the set of factors are likely to evolve significantly over
    time to be more or less permissive.

    Returns:
        SHA-256 hex digest
    """
    from vllm import __version__ as vllm_version
    from vllm.config.utils import hash_factors

    model_config = vllm_config.model_config
    cache_config = vllm_config.cache_config
    is_hma_enabled = not vllm_config.scheduler_config.disable_hybrid_kv_cache_manager

    factors = {
        # Version compatibility
        "vllm_version": vllm_version,
        "nixl_connector_version": NIXL_CONNECTOR_VERSION,
        # Model architecture - affects KV cache shape
        "model": model_config.model,
        "dtype": str(model_config.dtype),
        "num_kv_heads": model_config.get_total_num_kv_heads(),
        "head_size": model_config.get_head_size(),
        "num_hidden_layers": model_config.get_total_num_hidden_layers(),
        # Attention backend and KV cache dtype affect memory layout
        "attn_backend_name": attn_backend_name,
        "cache_dtype": str(cache_config.cache_dtype),
        "is_hma_enabled": is_hma_enabled,
        "speculative_config": _get_speculative_compatibility_factors(vllm_config),
        # push (WRITE) and pull (READ) connectors are protocol-incompatible
        "transfer_mode": transfer_mode,
    }

    compat_hash = hash_factors(factors)
    logger.debug(
        "NIXL compatibility hash: %s (model=%s, dtype=%s, num_kv_heads=%d, "
        "cache_dtype=%s, attn_backend=%s)",
        compat_hash,
        factors["model"],
        factors["dtype"],
        factors["num_kv_heads"],
        factors["cache_dtype"],
        attn_backend_name,
    )
    return compat_hash


@dataclass
class HeartbeatInfo:
    """Heartbeat data for a single remote engine, sent from D worker to P."""

    req_ids: set[ReqId]
    host: str
    port: int
    tp_size: int
    dcp_size: int = 1
    pp_size: int = 1


@dataclass
class RemoteMeta:
    block_ids: BlockIds
    host: str
    port: int
    engine_id: str
    request_id: str
    blocks_expiry_time: float | None = None


@dataclass
class ReqMeta:
    local_block_ids: BlockIds
    # To be used when logical block size does not match the kernel block size
    local_physical_block_ids: BlockIds
    tp_size: int
    dcp_size: int = 1
    # Per-KV-cache-group logical blocks this rank already holds, i.e. its
    # prefix-cache hit. Fixes where this rank's DCP slice starts relative to
    # the remote's; kept per-group since hybrid models (e.g. SWA+FA) can have
    # different cache-hit counts per group.
    local_num_computed_blocks: tuple[int, ...] = ()
    remote: RemoteMeta | None = None
    # Remote block size, discovered during NIXL handshake (push mode).
    remote_block_size: int | None = None
    # Remote producer pipeline-parallel size (push mode, D side).
    pp_size: int = 1


class NixlConnectorMetadata(KVConnectorMetadata):
    def __init__(self):
        self.reqs_to_recv: dict[ReqId, ReqMeta] = {}
        self.reqs_to_save: dict[ReqId, ReqMeta] = {}
        self.reqs_to_send: dict[ReqId, float] = {}
        # The scheduler process's time.perf_counter() when this metadata was
        # built. reqs_to_send deadlines are stamped with the scheduler's
        # clock, which is NOT comparable across processes (perf_counter is
        # process/boot-local): workers must rebase the remaining TTL onto
        # their own clock via this reference. 0.0 = unset (legacy metadata).
        self.scheduler_clock: float = 0.0
        self.reqs_in_batch: set[ReqId] = set()
        self.reqs_not_processed: set[ReqId] = set()
        # Heartbeat data grouped by remote engine, sent by D worker to P.
        self.heartbeat_by_engine: dict[EngineId, HeartbeatInfo] = {}
        # Push mode (D side): registration data the D worker should send to
        # P workers via NIXL notification on this step.
        self.push_registrations: dict[ReqId, dict[str, Any]] = {}
        # Push mode (P side): newly finished request blocks to be matched
        # against pending D registrations on the P worker.
        self.push_finished_blocks: dict[ReqId, BlockIds] = {}

    def _add_new_req(
        self,
        local_block_ids: BlockIds,
        kv_transfer_params: dict[str, Any],
        local_num_computed_blocks: tuple[int, ...] = (),
    ) -> ReqMeta:
        return ReqMeta(
            local_block_ids=local_block_ids,
            local_physical_block_ids=local_block_ids,
            # P workers don't need to receive these from proxy here.
            tp_size=kv_transfer_params.get("tp_size", 1),
            dcp_size=kv_transfer_params.get("dcp_size", 1),
            remote_block_size=kv_transfer_params.get("remote_block_size"),
            pp_size=kv_transfer_params.get("pp_size", 1),
            local_num_computed_blocks=local_num_computed_blocks,
        )

    def add_new_req_to_save(
        self,
        request_id: ReqId,
        local_block_ids: BlockIds,
        kv_transfer_params: dict[str, Any],
    ):
        self.reqs_to_save[request_id] = self._add_new_req(
            local_block_ids, kv_transfer_params
        )

    def add_new_req_to_recv(
        self,
        request_id: ReqId,
        local_block_ids: BlockIds,
        kv_transfer_params: dict[str, Any],
        local_num_computed_blocks: tuple[int, ...] = (),
    ):
        req = self._add_new_req(
            local_block_ids, kv_transfer_params, local_num_computed_blocks
        )
        req.remote = RemoteMeta(
            block_ids=kv_transfer_params["remote_block_ids"],
            engine_id=kv_transfer_params["remote_engine_id"],
            request_id=kv_transfer_params["remote_request_id"],
            host=kv_transfer_params["remote_host"],
            port=kv_transfer_params["remote_port"],
            blocks_expiry_time=kv_transfer_params.get("remote_blocks_expiry_time"),
        )
        self.reqs_to_recv[request_id] = req
