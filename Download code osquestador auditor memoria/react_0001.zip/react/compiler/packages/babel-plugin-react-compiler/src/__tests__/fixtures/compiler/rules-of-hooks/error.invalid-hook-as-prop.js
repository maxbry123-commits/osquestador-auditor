function Component({useFoo}) {
  useFoo();
}
