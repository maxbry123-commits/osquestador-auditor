/// <reference types="node" />

import { StrictMode, useEffect } from 'react'
import { act, render, screen } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { createStore } from 'zustand/vanilla'
import { replacer, reviver, sleep } from './test-utils'

const createPersistantStore = (initialValue: string | null) => {
  let state = initialValue

  const getItem = async (): Promise<string | null> => {
    getItemSpy()
    await sleep(10)
    return state
  }
  const setItem = async (name: string, newState: string) => {
    setItemSpy(name, newState)
    await sleep(10)
    state = newState
  }

  const removeItem = async (name: string) => {
    removeItemSpy(name)
    await sleep(10)
    state = null
  }

  const getItemSpy = vi.fn()
  const setItemSpy = vi.fn()
  const removeItemSpy = vi.fn()

  return {
    storage: { getItem, setItem, removeItem },
    getItemSpy,
    setItemSpy,
    removeItemSpy,
  }
}

describe('persist middleware with async configuration', () => {
  const consoleError = console.error

  beforeEach(() => {
    vi.useFakeTimers()
  })

  afterEach(() => {
    vi.useRealTimers()
    console.error = consoleError
  })

  it('can rehydrate state', async () => {
    const onRehydrateStorageSpy = vi.fn()
    const storage = {
      getItem: async (name: string) => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 42, name },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(
        () => ({
          count: 0,
          name: 'empty',
        }),
        {
          name: 'test-storage',
          storage: createJSONStorage(() => storage),
          onRehydrateStorage: () => onRehydrateStorageSpy,
        },
      ),
    )

    function Counter() {
      const { count, name } = useBoundStore()
      return (
        <div>
          count: {count}, name: {name}
        </div>
      )
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0, name: empty')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(
      screen.getByText('count: 42, name: test-storage'),
    ).toBeInTheDocument()
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      { count: 42, name: 'test-storage' },
      undefined,
    )
  })

  it('can throw rehydrate error', async () => {
    const onRehydrateStorageSpy = vi.fn()

    const storage = {
      getItem: async () => {
        await sleep(10)
        throw new Error('getItem error')
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: () => onRehydrateStorageSpy,
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      undefined,
      new Error('getItem error'),
    )
  })

  it('can persist state', async () => {
    const { storage, setItemSpy } = createPersistantStore(null)

    const createStore = () => {
      const onRehydrateStorageSpy = vi.fn()
      const useBoundStore = create(
        persist(() => ({ count: 0 }), {
          name: 'test-storage',
          storage: createJSONStorage(() => storage),
          onRehydrateStorage: () => onRehydrateStorageSpy,
        }),
      )
      return { useBoundStore, onRehydrateStorageSpy }
    }

    // Initialize from empty storage
    const { useBoundStore, onRehydrateStorageSpy } = createStore()

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith({ count: 0 }, undefined)

    // Write something to the store
    act(() => {
      useBoundStore.setState({ count: 42 })
    })
    expect(screen.getByText('count: 42')).toBeInTheDocument()
    expect(setItemSpy).toHaveBeenCalledWith(
      'test-storage',
      JSON.stringify({ state: { count: 42 }, version: 0 }),
    )

    // Create the same store a second time and check if the persisted state
    // is loaded correctly
    const {
      useBoundStore: useBoundStore2,
      onRehydrateStorageSpy: onRehydrateStorageSpy2,
    } = createStore()
    function Counter2() {
      const { count } = useBoundStore2()
      return <div>count2: {count}</div>
    }

    render(
      <StrictMode>
        <Counter2 />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count2: 42')).toBeInTheDocument()
    expect(onRehydrateStorageSpy2).toHaveBeenCalledWith(
      { count: 42 },
      undefined,
    )
  })

  it('can async migrate persisted state', async () => {
    const setItemSpy = vi.fn()
    const onRehydrateStorageSpy = vi.fn()
    const migrateSpy = vi.fn(async () => {
      await sleep(10)
      return { count: 99 }
    })

    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 42 },
          version: 12,
        })
      },
      setItem: setItemSpy,
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        version: 13,
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: () => onRehydrateStorageSpy,
        migrate: migrateSpy,
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(20))
    expect(screen.getByText('count: 99')).toBeInTheDocument()
    expect(migrateSpy).toHaveBeenCalledWith({ count: 42 }, 12)
    expect(setItemSpy).toHaveBeenCalledWith(
      'test-storage',
      JSON.stringify({
        state: { count: 99 },
        version: 13,
      }),
    )
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith({ count: 99 }, undefined)
  })

  it('can merge partial persisted state', async () => {
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 42 },
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create<{
      count: number
      name: string
      setName: (name: string) => void
    }>()(
      persist(
        (set) => ({
          count: 0,
          name: 'unknown',
          setName: (name: string) => {
            set({ name })
          },
        }),
        {
          name: 'test-storage',
          storage: createJSONStorage(() => storage),
        },
      ),
    )

    function Component() {
      const { count, setName, name } = useBoundStore()
      useEffect(() => {
        setName('test')
      }, [setName])
      return (
        <div>
          <div>count: {count}</div>
          <div>name: {name}</div>
        </div>
      )
    }

    render(
      <StrictMode>
        <Component />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 42')).toBeInTheDocument()
    expect(screen.getByText('name: test')).toBeInTheDocument()

    expect(useBoundStore.getState()).toEqual(
      expect.objectContaining({
        count: 42,
        name: 'test',
      }),
    )
  })

  it('can correctly handle a missing migrate function', async () => {
    console.error = vi.fn()
    const onRehydrateStorageSpy = vi.fn()
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 42 },
          version: 12,
        })
      },
      setItem: (_: string, _value: string) => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        version: 13,
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: () => onRehydrateStorageSpy,
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(console.error).toHaveBeenCalled()
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith({ count: 0 }, undefined)
  })

  it('can throw migrate error', async () => {
    console.error = vi.fn()
    const onRehydrateStorageSpy = vi.fn()

    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: {},
          version: 12,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        version: 13,
        storage: createJSONStorage(() => storage),
        migrate: () => {
          throw new Error('migrate error')
        },
        onRehydrateStorage: () => onRehydrateStorageSpy,
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      undefined,
      new Error('migrate error'),
    )
  })

  it('passes the latest state to onRehydrateStorage and onHydrate on first hydrate', async () => {
    const onRehydrateStorageSpy = vi.fn()

    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({ state: { count: 1 } })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: onRehydrateStorageSpy,
      }),
    )

    /**
     * NOTE: It's currently not possible to add an 'onHydrate' listener which will be
     * invoked prior to the first hydration. This is because, during first hydration,
     * the 'onHydrate' listener set (which will be empty) is evaluated before the
     * 'persist' API is exposed to the caller of 'create'/'createStore'.
     *
     * const onHydrateSpy = vi.fn()
     * useBoundStore.persist.onHydrate(onHydrateSpy)
     * ...
     * await act(() => vi.advanceTimersByTimeAsync(10))
     * expect(onHydrateSpy).toHaveBeenCalledWith({ count: 0 })
     */

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 1')).toBeInTheDocument()

    // The 'onRehydrateStorage' spy is invoked prior to rehydration, so it should
    // be passed the default state.
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith({ count: 0 })
  })

  it('gives the merged state to onRehydrateStorage', async () => {
    const onRehydrateStorageSpy = vi.fn()

    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 1 },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const unstorableMethod = () => {}

    const useBoundStore = create(
      persist(() => ({ count: 0, unstorableMethod }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: () => onRehydrateStorageSpy,
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    expect(screen.getByText('count: 0')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      { count: 1, unstorableMethod },
      undefined,
    )
  })

  it('can custom merge the stored state', async () => {
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: {
            count: 1,
            actions: {},
          },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const unstorableMethod = () => {}

    const useBoundStore = create(
      persist(() => ({ count: 0, actions: { unstorableMethod } }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        merge: (_persistedState, currentState) => {
          const persistedState = _persistedState as any
          delete persistedState.actions

          return {
            ...currentState,
            ...persistedState,
          }
        },
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 1')).toBeInTheDocument()
    expect(useBoundStore.getState()).toEqual({
      count: 1,
      actions: {
        unstorableMethod,
      },
    })
  })

  it("can merge the state when the storage item doesn't have a version", async () => {
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: {
            count: 1,
          },
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
      }),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 1')).toBeInTheDocument()
    expect(useBoundStore.getState()).toEqual({
      count: 1,
    })
  })

  it('can manually rehydrate through the api', async () => {
    const storageValue = '{"state":{"count":1},"version":0}'

    const storage = {
      getItem: async () => {
        await sleep(10)
        return ''
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
      }),
    )

    storage.getItem = async () => {
      await sleep(10)
      return storageValue
    }
    const rehydratePromise = useBoundStore.persist.rehydrate()
    await act(() => vi.advanceTimersByTimeAsync(10))
    await rehydratePromise
    expect(useBoundStore.getState()).toEqual({
      count: 1,
    })
  })

  it('can check if the store has been hydrated through the api', async () => {
    const storage = {
      getItem: async () => {
        await sleep(10)
        return null
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
      }),
    )
    expect(useBoundStore.persist.hasHydrated()).toBe(false)
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(useBoundStore.persist.hasHydrated()).toBe(true)

    const rehydratePromise = useBoundStore.persist.rehydrate()
    await act(() => vi.advanceTimersByTimeAsync(10))
    await rehydratePromise
    expect(useBoundStore.persist.hasHydrated()).toBe(true)
  })

  it('can skip initial hydration', async () => {
    const storage = {
      getItem: async (name: string) => {
        await sleep(10)
        return {
          state: { count: 42, name },
          version: 0,
        }
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const onRehydrateStorageSpy = vi.fn()
    const useBoundStore = create(
      persist(
        () => ({
          count: 0,
          name: 'empty',
        }),
        {
          name: 'test-storage',
          storage: storage,
          onRehydrateStorage: () => onRehydrateStorageSpy,
          skipHydration: true,
        },
      ),
    )

    expect(useBoundStore.getState()).toEqual({
      count: 0,
      name: 'empty',
    })

    // Asserting store hasn't hydrated
    expect(useBoundStore.persist.hasHydrated()).toBe(false)

    const rehydratePromise = useBoundStore.persist.rehydrate()
    await act(() => vi.advanceTimersByTimeAsync(10))
    await rehydratePromise

    expect(useBoundStore.getState()).toEqual({
      count: 42,
      name: 'test-storage',
    })
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      { count: 42, name: 'test-storage' },
      undefined,
    )
  })

  it('handles state updates during onRehydrateStorage', async () => {
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({ state: { count: 1 } })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create<{ count: number; inc: () => void }>()(
      persist(
        (set) => ({
          count: 0,
          inc: () => set((s) => ({ count: s.count + 1 })),
        }),
        {
          name: 'test-storage',
          storage: createJSONStorage(() => storage),
          onRehydrateStorage: () => (s) => s?.inc(),
        },
      ),
    )

    function Counter() {
      const { count } = useBoundStore()
      return <div>count: {count}</div>
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 2')).toBeInTheDocument()
    expect(useBoundStore.getState().count).toEqual(2)
  })

  it('passes latest state to post-rehydration callback after hydration-triggered updates', async () => {
    const onRehydrateStorageSpy = vi.fn()
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: { count: 1, bumped: false },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0, bumped: false }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        onRehydrateStorage: () => onRehydrateStorageSpy,
      }),
    )

    let patchedDuringHydration = false
    const unsubscribe = useBoundStore.subscribe((state) => {
      if (!patchedDuringHydration && state.count === 1 && !state.bumped) {
        patchedDuringHydration = true
        useBoundStore.setState({ bumped: true })
      }
    })

    function Counter() {
      const { count, bumped } = useBoundStore()
      return (
        <div>
          count: {count}, bumped: {String(bumped)}
        </div>
      )
    }

    render(
      <StrictMode>
        <Counter />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('count: 1, bumped: true')).toBeInTheDocument()
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      { count: 1, bumped: true },
      undefined,
    )
    unsubscribe()
  })

  it('can rehydrate state with custom deserialized Map', async () => {
    const onRehydrateStorageSpy = vi.fn()
    const storage = {
      getItem: async () => {
        await sleep(10)
        return JSON.stringify({
          state: {
            map: { type: 'Map', value: [['foo', 'bar']] },
          },
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(
        () => ({
          map: new Map(),
        }),
        {
          name: 'test-storage',
          storage: createJSONStorage(() => storage, { replacer, reviver }),
          onRehydrateStorage: () => onRehydrateStorageSpy,
        },
      ),
    )

    function MapDisplay() {
      const { map } = useBoundStore()
      return <div>map: {map.get('foo')}</div>
    }

    render(
      <StrictMode>
        <MapDisplay />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('map: bar')).toBeInTheDocument()
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith(
      { map: new Map([['foo', 'bar']]) },
      undefined,
    )
  })

  it('can persist state with custom serialization of Map', async () => {
    const { storage, setItemSpy } = createPersistantStore(null)
    const map = new Map()

    const createStore = () => {
      const onRehydrateStorageSpy = vi.fn()
      const useBoundStore = create(
        persist(() => ({ map }), {
          name: 'test-storage',
          storage: createJSONStorage(() => storage, { replacer, reviver }),
          onRehydrateStorage: () => onRehydrateStorageSpy,
        }),
      )
      return { useBoundStore, onRehydrateStorageSpy }
    }

    // Initialize from empty storage
    const { useBoundStore, onRehydrateStorageSpy } = createStore()

    function MapDisplay() {
      const { map } = useBoundStore()
      return <div>map-content: {map.get('foo')}</div>
    }

    render(
      <StrictMode>
        <MapDisplay />
      </StrictMode>,
    )

    expect(screen.getByText('map-content:')).toBeInTheDocument()
    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(onRehydrateStorageSpy).toHaveBeenCalledWith({ map }, undefined)

    // Write something to the store
    const updatedMap = new Map(map).set('foo', 'bar')
    act(() => {
      useBoundStore.setState({ map: updatedMap })
    })
    expect(screen.getByText('map-content: bar')).toBeInTheDocument()

    expect(setItemSpy).toHaveBeenCalledWith(
      'test-storage',
      JSON.stringify({
        state: { map: { type: 'Map', value: [['foo', 'bar']] } },
        version: 0,
      }),
    )

    // Create the same store a second time and check if the persisted state
    // is loaded correctly
    const {
      useBoundStore: useBoundStore2,
      onRehydrateStorageSpy: onRehydrateStorageSpy2,
    } = createStore()
    function MapDisplay2() {
      const { map } = useBoundStore2()
      return <div>map-content2: {map.get('foo')}</div>
    }

    render(
      <StrictMode>
        <MapDisplay2 />
      </StrictMode>,
    )

    await act(() => vi.advanceTimersByTimeAsync(10))
    expect(screen.getByText('map-content2: bar')).toBeInTheDocument()
    expect(onRehydrateStorageSpy2).toHaveBeenCalledWith(
      { map: updatedMap },
      undefined,
    )
  })

  it('should handle multiple concurrent rehydrate calls (only last one wins)', async () => {
    let callCount = 0
    const storage = {
      getItem: async () => {
        const currentCall = ++callCount
        await sleep(10)
        return JSON.stringify({
          state: { count: currentCall * 10 },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const onFinishHydrationSpy = vi.fn()
    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        skipHydration: true,
      }),
    )

    useBoundStore.persist.onFinishHydration(onFinishHydrationSpy)

    // Start first rehydration
    const promise1 = useBoundStore.persist.rehydrate()
    // Immediately start second rehydration (before first completes)
    const promise2 = useBoundStore.persist.rehydrate()
    // Start third rehydration
    const promise3 = useBoundStore.persist.rehydrate()

    // Advance time to complete all hydrations
    await act(() => vi.advanceTimersByTimeAsync(30))
    await Promise.all([promise1, promise2, promise3])

    // Only the last rehydration should have applied its state
    // callCount will be 3, so count should be 30
    expect(useBoundStore.getState().count).toBe(30)

    // onFinishHydration should only be called once (for the last hydration)
    expect(onFinishHydrationSpy).toHaveBeenCalledTimes(1)
    expect(onFinishHydrationSpy).toHaveBeenCalledWith({ count: 30 })
  })

  it('should not overwrite user state changes made during async hydration', async () => {
    const storage = {
      getItem: async () => {
        await sleep(20)
        return JSON.stringify({
          state: { count: 42, userValue: 'from-storage' },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0, userValue: 'initial' }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        // Custom merge that preserves user changes made during hydration
        merge: (persistedState, currentState) => ({
          ...currentState,
          ...(persistedState as object),
        }),
      }),
    )

    // User makes a change while hydration is in progress
    await act(() => vi.advanceTimersByTimeAsync(10))
    useBoundStore.setState({ count: 100 })

    // Complete hydration
    await act(() => vi.advanceTimersByTimeAsync(10))

    // The merge function combines storage state with current state
    // Storage has count: 42, userValue: 'from-storage'
    // Current state before merge has count: 100, userValue: 'initial'
    // After merge (storage overwrites): count: 42, userValue: 'from-storage'
    expect(useBoundStore.getState()).toEqual({
      count: 42,
      userValue: 'from-storage',
    })
  })

  it('should abort hydration with async migration when newer hydration starts', async () => {
    let migrationCount = 0
    const storage = {
      getItem: async () => {
        await sleep(5)
        return JSON.stringify({
          state: { count: 1 },
          version: 0,
        })
      },
      setItem: () => {},
      removeItem: () => {},
    }

    const useBoundStore = create(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        storage: createJSONStorage(() => storage),
        version: 1,
        migrate: async (state) => {
          migrationCount++
          await sleep(10)
          return { count: (state as { count: number }).count * 10 }
        },
        skipHydration: true,
      }),
    )

    // Start first rehydration (will trigger migration)
    useBoundStore.persist.rehydrate()
    await act(() => vi.advanceTimersByTimeAsync(5)) // getItem completes

    // Start second rehydration before migration completes
    useBoundStore.persist.rehydrate()

    // Advance time to complete everything
    await act(() => vi.advanceTimersByTimeAsync(20))

    // Both hydrations triggered migration, but only last one should apply
    expect(migrationCount).toBe(2)
    // Final state should be from second hydration's migration
    expect(useBoundStore.getState().count).toBe(10)
  })
})

type Deferred<T> = {
  promise: Promise<T>
  resolve: (value: T) => void
}

const deferred = <T,>(): Deferred<T> => {
  let resolve!: (value: T) => void
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise
  })
  return { promise, resolve }
}

describe('persist clearStorage hydration generation', () => {
  it('keeps a cleared delayed stored value from hydrating state', async () => {
    const storedValue = deferred<{
      state: { count: number }
      version: number
    } | null>()
    const removeItem = vi.fn()
    const store = createStore(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        skipHydration: true,
        storage: {
          getItem: () => storedValue.promise,
          removeItem,
          setItem: () => {},
        },
      }),
    )

    const hydration = store.persist.rehydrate()
    store.persist.clearStorage()
    storedValue.resolve({ state: { count: 1 }, version: 0 })
    await hydration

    expect(removeItem).toHaveBeenCalledTimes(1)
    expect(store.getState().count).toBe(0)
  })

  it('keeps a cleared delayed migration from hydrating state', async () => {
    const migratedValue = deferred<{ count: number }>()
    const migrate = vi.fn(() => migratedValue.promise)
    const removeItem = vi.fn()
    const store = createStore(
      persist(() => ({ count: 0 }), {
        migrate,
        name: 'test-storage',
        skipHydration: true,
        storage: {
          getItem: () => ({ state: { count: 1 }, version: 1 }),
          removeItem,
          setItem: () => {},
        },
        version: 2,
      }),
    )

    const hydration = store.persist.rehydrate()
    expect(migrate).toHaveBeenCalledWith({ count: 1 }, 1)
    store.persist.clearStorage()
    migratedValue.resolve({ count: 2 })
    await hydration

    expect(removeItem).toHaveBeenCalledTimes(1)
    expect(store.getState().count).toBe(0)
  })

  it('revokes the active hydration even when storage removal throws', async () => {
    const olderValue = deferred<{
      state: { count: number }
      version: number
    } | null>()
    const removeError = new Error('remove failed')
    let readCount = 0
    const store = createStore(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        skipHydration: true,
        storage: {
          getItem: () => {
            readCount += 1
            return readCount === 1
              ? olderValue.promise
              : { state: { count: 2 }, version: 0 }
          },
          removeItem: () => {
            throw removeError
          },
          setItem: () => {},
        },
      }),
    )

    const olderHydration = store.persist.rehydrate()
    expect(() => store.persist.clearStorage()).toThrow(removeError)
    olderValue.resolve({ state: { count: 1 }, version: 0 })
    await olderHydration

    expect(store.getState().count).toBe(0)

    await store.persist.rehydrate()
    expect(store.getState().count).toBe(2)
  })

  it('does not reset live state when clearing after hydration', async () => {
    const removeItem = vi.fn()
    const store = createStore(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        skipHydration: true,
        storage: {
          getItem: () => ({ state: { count: 1 }, version: 0 }),
          removeItem,
          setItem: () => {},
        },
      }),
    )

    await store.persist.rehydrate()
    store.persist.clearStorage()

    expect(removeItem).toHaveBeenCalledTimes(1)
    expect(store.getState().count).toBe(1)
  })

  it('suppresses stale completion signals and allows a later hydration', async () => {
    const olderValue = deferred<{
      state: { count: number }
      version: number
    } | null>()
    const postRehydrationCallback = vi.fn()
    const finishHydrationListener = vi.fn()
    let readCount = 0
    const store = createStore(
      persist(() => ({ count: 0 }), {
        name: 'test-storage',
        onRehydrateStorage: () => postRehydrationCallback,
        skipHydration: true,
        storage: {
          getItem: () => {
            readCount += 1
            return readCount === 1
              ? olderValue.promise
              : { state: { count: 2 }, version: 0 }
          },
          removeItem: () => {},
          setItem: () => {},
        },
      }),
    )
    store.persist.onFinishHydration(finishHydrationListener)

    const olderHydration = store.persist.rehydrate()
    store.persist.clearStorage()
    olderValue.resolve({ state: { count: 1 }, version: 0 })
    await olderHydration

    expect(store.getState().count).toBe(0)
    expect(store.persist.hasHydrated()).toBe(false)
    expect(postRehydrationCallback).not.toHaveBeenCalled()
    expect(finishHydrationListener).not.toHaveBeenCalled()

    await store.persist.rehydrate()

    expect(store.getState().count).toBe(2)
    expect(store.persist.hasHydrated()).toBe(true)
    expect(postRehydrationCallback).toHaveBeenCalledExactlyOnceWith(
      { count: 2 },
      undefined,
    )
    expect(finishHydrationListener).toHaveBeenCalledExactlyOnceWith({
      count: 2,
    })
  })
})
