import configparser
from pathlib import Path

import pytest

from tests.fixtures import *
from ytmusicapi import YTMusic

#: serial xdist groups, longest first (see tests/README.rst)
LANE_ORDER = ["playlist", "uploads", "search_history", "history"]


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """xdist pops work units in collection order and only refills a worker at <=2 pending,
    so a long lane collected late strands a worker at the end of the run.
    """
    if config.getoption("dist", "no") != "loadgroup":
        return

    def lane(item: pytest.Item) -> int:
        marker = item.get_closest_marker("xdist_group")
        return LANE_ORDER.index(marker.args[0]) if marker else len(LANE_ORDER)

    items.sort(key=lane)  # stable, so order within each lane is preserved


def get_resource(file: str) -> str:
    data_dir = Path(__file__).parent
    return data_dir.joinpath(file).as_posix()


def get_config() -> configparser.RawConfigParser:
    config = configparser.RawConfigParser()
    config.read(get_resource("test.cfg"), "utf-8")
    return config


@pytest.fixture(name="config")
def fixture_config() -> configparser.RawConfigParser:
    return get_config()


@pytest.fixture(name="sample_album")
def fixture_sample_album() -> str:
    """Eminem - Revival"""
    return "MPREb_4pL8gzRtw1p"


@pytest.fixture(name="sample_video")
def fixture_sample_video() -> str:
    """Oasis - Wonderwall"""
    return "hpSrLjc5SMs"


@pytest.fixture(name="browser_filepath")
def fixture_browser_filepath(config) -> str:
    return get_resource(config["auth"]["browser_file"])


@pytest.fixture(name="oauth_filepath")
def fixture_oauth_filepath(config) -> str:
    return get_resource(config["auth"]["oauth_file"])


@pytest.fixture(name="yt")
def fixture_yt() -> YTMusic:
    return YTMusic()


@pytest.fixture(name="yt_auth")
def fixture_yt_auth(browser_filepath) -> YTMusic:
    """a non-brand account that is able to create uploads"""
    return YTMusic(browser_filepath, location="GB")


@pytest.fixture(name="yt_oauth")
def fixture_yt_oauth(browser_filepath, config) -> YTMusic:
    # replaced with browser fixture yt_auth for now due to oauth not working, see #813
    return YTMusic(browser_filepath)
    # credentials = OAuthCredentials(
    #     client_id=config["auth"]["client_id"], client_secret=config["auth"]["client_secret"]
    # )
    # return YTMusic(oauth_filepath, oauth_credentials=credentials)


@pytest.fixture(name="yt_brand")
def fixture_yt_brand(config) -> YTMusic:
    return YTMusic(config["auth"]["headers"], config["auth"]["brand_account"])


@pytest.fixture(name="yt_empty")
def fixture_yt_empty(config) -> YTMusic:
    return YTMusic(config["auth"]["headers_empty"], config["auth"]["brand_account_empty"])


@pytest.fixture(name="sample_credits")
def fixture_sample_credits() -> str:
    """KANGTA - The Cure"""
    return "MPTCJpKLGcWBJ5Y"
