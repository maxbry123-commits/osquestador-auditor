// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

import { expect } from '@playwright/test';
import { clientEventEmitter } from '../../../packages/playwright-core/lib/coreBundle';

export const mustNotCall = (msg?: string) => {
  return function mustNotCall() {
    expect(false, msg || 'function should not have been called').toBeTruthy();
  };
};

let count;

export const beforeEach = () => {
  count = 0;
};

export const afterEach = () => {
  expect(count).toBe(0);
};

export const mustCall = (fn?: Function, exact?: number) => {
  count += exact || 1;
  return (...args: any[]) => {
    fn?.(...args);
    --count;
  };
};

/** as any breaks long TS resolution chain that makes tests unhappy */
export class EventEmitter extends (clientEventEmitter as any) {
  constructor() {
    super();
  }
}
