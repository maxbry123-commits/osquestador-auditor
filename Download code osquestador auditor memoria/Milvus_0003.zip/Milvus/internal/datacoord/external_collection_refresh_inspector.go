// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package datacoord

import (
	"context"
	"time"

	"github.com/milvus-io/milvus/internal/datacoord/task"
	"github.com/milvus-io/milvus/pkg/v3/mlog"
	"github.com/milvus-io/milvus/pkg/v3/proto/datapb"
	"github.com/milvus-io/milvus/pkg/v3/proto/indexpb"
)

// externalCollectionRefreshInspector handles task scheduling and recovery for external collection refresh.
//
// This is an internal component of ExternalCollectionRefreshManager, responsible for:
// 1. Reload published InProgress/Init/Retry tasks on DataCoord restart
// 2. Re-enqueue InProgress siblings of a Failed job so their DataNode tasks are canceled
// 3. Periodically enqueue pending tasks to the global task scheduler for execution
//
// TASK STATE TRANSITIONS:
// Init → InProgress (inspector enqueues to scheduler, scheduler dispatches to DataNode)
// InProgress → Finished/Failed (DataNode reports execution result)
type externalCollectionRefreshInspector struct {
	ctx         context.Context
	refreshMeta *externalCollectionRefreshMeta
	scheduler   task.GlobalScheduler
	closeChan   chan struct{}
	// wrapTask builds a scheduler-facing task wrapper with all callbacks
	// wired (processFinishedJob → checker.processJobByID). The manager owns
	// the wiring logic and injects this factory so the inspector doesn't
	// need a direct reference to the checker (avoids construction-order
	// circular dependency).
	wrapTask func(t *datapb.ExternalCollectionRefreshTask) *refreshExternalCollectionTask
}

func newRefreshInspector(
	ctx context.Context,
	refreshMeta *externalCollectionRefreshMeta,
	scheduler task.GlobalScheduler,
	closeChan chan struct{},
) *externalCollectionRefreshInspector {
	return &externalCollectionRefreshInspector{
		ctx:         ctx,
		refreshMeta: refreshMeta,
		scheduler:   scheduler,
		closeChan:   closeChan,
	}
}

// run starts the inspector loop.
func (i *externalCollectionRefreshInspector) run() {
	// Reload tasks on startup for idempotent recovery
	i.reloadFromMeta()

	// Log inspection interval for observability
	inspectInterval := Params.DataCoordCfg.ExternalCollectionCheckInterval.GetAsDuration(time.Second)
	mlog.Info(i.ctx, "start external collection inspector", mlog.Duration("inspectInterval", inspectInterval))

	ticker := time.NewTicker(inspectInterval)
	defer ticker.Stop()

	for {
		select {
		case <-i.closeChan:
			mlog.Info(i.ctx, "external collection inspector exited")
			return
		case <-ticker.C:
			i.inspect()
		}
	}
}

// inspect runs a single inspection cycle to re-enqueue any pending tasks.
func (i *externalCollectionRefreshInspector) inspect() {
	i.enqueueCommittedTasks(false)
}

// reloadFromMeta reloads active tasks from metadata on startup.
func (i *externalCollectionRefreshInspector) reloadFromMeta() {
	i.enqueueCommittedTasks(true)
}

// enqueueCommittedTasks schedules only tasks referenced by their parent job's
// published task_ids. Periodic scans enqueue Init/Retry tasks. Startup recovery
// also enqueues InProgress tasks; for a Failed job, this is solely to drive the
// QueryTaskOnWorker cancellation path and release the DataNode task.
func (i *externalCollectionRefreshInspector) enqueueCommittedTasks(includeInProgress bool) {
	for jobID, job := range i.refreshMeta.GetAllJobs() {
		if job.GetState() == indexpb.JobState_JobStateFinished {
			continue
		}
		failedJob := job.GetState() == indexpb.JobState_JobStateFailed
		if failedJob && !includeInProgress {
			continue
		}

		tasks, err := i.refreshMeta.GetCommittedTasksByJobID(jobID)
		if err != nil {
			mlog.Warn(i.ctx, "failed to resolve committed external refresh tasks",
				mlog.FieldJobID(jobID),
				mlog.Err(err))
			continue
		}
		for _, task := range tasks {
			if failedJob {
				if task.GetState() == indexpb.JobState_JobStateInProgress {
					i.scheduler.Enqueue(i.wrapTask(task))
				}
				continue
			}
			switch task.GetState() {
			case indexpb.JobState_JobStateInit, indexpb.JobState_JobStateRetry:
				i.scheduler.Enqueue(i.wrapTask(task))
			case indexpb.JobState_JobStateInProgress:
				if includeInProgress {
					i.scheduler.Enqueue(i.wrapTask(task))
				}
			}
		}
	}
}
