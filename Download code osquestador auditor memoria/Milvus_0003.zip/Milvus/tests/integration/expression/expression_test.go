// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package expression

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"

	"github.com/stretchr/testify/suite"
	"google.golang.org/protobuf/proto"

	"github.com/milvus-io/milvus-proto/go-api/v3/milvuspb"
	"github.com/milvus-io/milvus-proto/go-api/v3/schemapb"
	"github.com/milvus-io/milvus/pkg/v3/common"
	"github.com/milvus-io/milvus/pkg/v3/mlog"
	"github.com/milvus-io/milvus/pkg/v3/util/funcutil"
	"github.com/milvus-io/milvus/pkg/v3/util/merr"
	"github.com/milvus-io/milvus/pkg/v3/util/metric"
	"github.com/milvus-io/milvus/tests/integration"
)

type ExpressionSuite struct {
	integration.MiniClusterSuite
	dbName         string
	collectionName string
	dim            int
	rowNum         int
}

func (s *ExpressionSuite) setParams() {
	prefix := "TestExpression"
	s.dbName = ""
	s.collectionName = prefix + funcutil.GenRandomStr()
	s.dim = 128
	s.rowNum = 100
}

func newJSONData(fieldName string, rowNum int) *schemapb.FieldData {
	jsonData := make([][]byte, 0, rowNum)
	for i := 0; i < rowNum; i++ {
		data := map[string]interface{}{
			"A": i,
			"B": rowNum - i,
			"C": []int{i, rowNum - i},
			"D": fmt.Sprintf("name-%d", i),
			"E": map[string]interface{}{
				"F": i,
				"G": i + 10,
			},
			"str1": `abc\"def-` + string(rune(i)),
			"str2": fmt.Sprintf("abc\"def-%d", i),
			"str3": fmt.Sprintf("abc\ndef-%d", i),
			"str4": fmt.Sprintf("abc\367-%d", i),
		}
		if i%2 == 0 {
			data = map[string]interface{}{
				"B": rowNum - i,
				"C": []int{i, rowNum - i},
				"D": fmt.Sprintf("name-%d", i),
				"E": map[string]interface{}{
					"F": i,
					"G": i + 10,
				},
			}
		}
		if i == 100 {
			data = nil
		}
		jsonBytes, err := json.MarshalIndent(data, "", "  ")
		if err != nil {
			return nil
		}
		jsonData = append(jsonData, jsonBytes)
	}
	return &schemapb.FieldData{
		Type:      schemapb.DataType_JSON,
		FieldName: fieldName,
		Field: &schemapb.FieldData_Scalars{
			Scalars: &schemapb.ScalarField{
				Data: &schemapb.ScalarField_JsonData{
					JsonData: &schemapb.JSONArray{
						Data: jsonData,
					},
				},
			},
		},
	}
}

func (s *ExpressionSuite) insertFlushIndexLoad(ctx context.Context, fieldData []*schemapb.FieldData) {
	hashKeys := integration.GenerateHashKeys(s.rowNum)
	insertResult, err := s.Cluster.MilvusClient.Insert(ctx, &milvuspb.InsertRequest{
		DbName:         s.dbName,
		CollectionName: s.collectionName,
		FieldsData:     fieldData,
		HashKeys:       hashKeys,
		NumRows:        uint32(s.rowNum),
	})
	s.NoError(err)
	s.NoError(merr.Error(insertResult.GetStatus()))

	// flush
	flushResp, err := s.Cluster.MilvusClient.Flush(ctx, &milvuspb.FlushRequest{
		DbName:          s.dbName,
		CollectionNames: []string{s.collectionName},
	})
	s.NoError(err)
	segmentIDs, has := flushResp.GetCollSegIDs()[s.collectionName]
	ids := segmentIDs.GetData()
	s.Require().NotEmpty(segmentIDs)
	s.Require().True(has)
	flushTs, has := flushResp.GetCollFlushTs()[s.collectionName]
	s.True(has)

	s.WaitForFlush(ctx, ids, flushTs, s.dbName, s.collectionName)
	segments, err := s.Cluster.ShowSegments(s.collectionName)
	s.NoError(err)
	s.NotEmpty(segments)
	for _, segment := range segments {
		mlog.Info(ctx, "ShowSegments result", mlog.String("segment", segment.String()))
	}

	// create index
	createIndexStatus, err := s.Cluster.MilvusClient.CreateIndex(context.TODO(), &milvuspb.CreateIndexRequest{
		CollectionName: s.collectionName,
		FieldName:      integration.FloatVecField,
		IndexName:      "_default",
		ExtraParams:    integration.ConstructIndexParam(s.dim, integration.IndexFaissIvfFlat, metric.IP),
	})
	s.NoError(err)
	err = merr.Error(createIndexStatus)
	s.NoError(err)
	s.WaitForIndexBuilt(context.TODO(), s.collectionName, integration.FloatVecField)
	mlog.Info(ctx, "=========================Index created=========================")

	// load
	loadStatus, err := s.Cluster.MilvusClient.LoadCollection(ctx, &milvuspb.LoadCollectionRequest{
		DbName:         s.dbName,
		CollectionName: s.collectionName,
	})
	s.NoError(err)
	err = merr.Error(loadStatus)
	s.NoError(err)
	s.WaitForLoad(context.TODO(), s.collectionName)
	mlog.Info(ctx, "=========================Collection loaded=========================")
}

func (s *ExpressionSuite) setupData() {
	c := s.Cluster
	ctx, cancel := context.WithCancel(c.GetContext())
	defer cancel()

	schema := integration.ConstructSchema(s.collectionName, s.dim, true)
	schema.EnableDynamicField = true
	marshaledSchema, err := proto.Marshal(schema)
	s.NoError(err)

	createCollectionStatus, err := c.MilvusClient.CreateCollection(ctx, &milvuspb.CreateCollectionRequest{
		DbName:         s.dbName,
		CollectionName: s.collectionName,
		Schema:         marshaledSchema,
		ShardsNum:      2,
	})
	s.NoError(err)
	err = merr.Error(createCollectionStatus)
	s.NoError(err)

	showCollectionsResp, err := c.MilvusClient.ShowCollections(ctx, &milvuspb.ShowCollectionsRequest{})
	s.NoError(err)
	err = merr.Error(showCollectionsResp.GetStatus())
	s.NoError(err)

	describeCollectionResp, err := c.MilvusClient.DescribeCollection(ctx, &milvuspb.DescribeCollectionRequest{CollectionName: s.collectionName})
	s.NoError(err)
	err = merr.Error(describeCollectionResp.GetStatus())
	s.NoError(err)
	s.True(describeCollectionResp.Schema.EnableDynamicField)
	s.Equal(2, len(describeCollectionResp.GetSchema().GetFields()))

	fVecColumn := integration.NewFloatVectorFieldData(integration.FloatVecField, s.rowNum, s.dim)
	jsonData := newJSONData(common.MetaFieldName, s.rowNum)
	jsonData.IsDynamic = true
	s.insertFlushIndexLoad(ctx, []*schemapb.FieldData{fVecColumn, jsonData})
}

type testCase struct {
	expr   string
	topK   int
	resNum int
}

func (s *ExpressionSuite) searchWithExpression() {
	testcases := []testCase{
		{"A + 5 > 0", 10, 10},
		{"B - 5 >= 0", 10, 10},
		{"C[0] * 5 < 500", 10, 10},
		{"E['F'] / 5 <= 100", 10, 10},
		{"E['G'] % 5 == 4", 10, 10},
		{"A / 5 != 4", 10, 10},
	}
	for _, c := range testcases {
		params := integration.GetSearchParams(integration.IndexFaissIDMap, metric.IP)
		searchReq := integration.ConstructSearchRequest(s.dbName, s.collectionName, c.expr,
			integration.FloatVecField, schemapb.DataType_FloatVector, nil, metric.IP, params, 1, s.dim, c.topK, -1)

		searchResult, err := s.Cluster.MilvusClient.Search(context.Background(), searchReq)
		s.NoError(err)
		err = merr.Error(searchResult.GetStatus())
		s.NoError(err)
		s.Equal(c.resNum, len(searchResult.GetResults().GetScores()))
		mlog.Info(context.TODO(),
			fmt.Sprintf("=========================Search done with expr:%s =========================", c.expr))
	}
}

// searchWithBitwiseExpression verifies bitwise filter operators end-to-end with
// EXACT result counts. The JSON dynamic fields satisfy E['F'] == i and
// B == rowNum-i for every row i in [0, rowNum), so each filter's match count is
// computable. topK is set to rowNum so the returned count equals the number of
// rows passing the filter (rather than being capped by a small topK).
func (s *ExpressionSuite) searchWithBitwiseExpression() {
	testcases := []testCase{
		{"(E['F'] & 1) == 0", s.rowNum, 50}, // i even
		{"(E['F'] & 1) == 1", s.rowNum, 50}, // i odd
		{"(E['F'] & 4) == 4", s.rowNum, 48}, // bit 2 set: i%8 in {4,5,6,7}
		{"(E['F'] | 1) == 1", s.rowNum, 2},  // i in {0,1}
		{"(E['F'] ^ 1) == 0", s.rowNum, 1},  // i == 1
		{"(E['F'] ^ 1) != 0", s.rowNum, 99}, // i != 1
		{"(B & 1) == 0", s.rowNum, 50},      // B = rowNum-i even <=> i even
	}
	for _, c := range testcases {
		params := integration.GetSearchParams(integration.IndexFaissIDMap, metric.IP)
		searchReq := integration.ConstructSearchRequest(s.dbName, s.collectionName, c.expr,
			integration.FloatVecField, schemapb.DataType_FloatVector, nil, metric.IP, params, 1, s.dim, c.topK, -1)

		searchResult, err := s.Cluster.MilvusClient.Search(context.Background(), searchReq)
		s.NoError(err)
		err = merr.Error(searchResult.GetStatus())
		s.NoError(err)
		s.Equal(c.resNum, len(searchResult.GetResults().GetScores()),
			fmt.Sprintf("unexpected match count for bitwise expr: %s", c.expr))
		mlog.Info(context.TODO(),
			fmt.Sprintf("=========================Bitwise search done with expr:%s =========================", c.expr))
	}
}

// searchWithShiftNotExpression verifies shift (<<, >>) and bitwise NOT (~)
// filter operators end-to-end with EXACT result counts. As above, E['F'] == i
// and B == rowNum-i for every row i in [0, rowNum). ~ is rewritten to (x ^ -1)
// at plan time, so this also exercises that rewrite end-to-end.
func (s *ExpressionSuite) searchWithShiftNotExpression() {
	testcases := []testCase{
		{"(E['F'] << 1) == 4", s.rowNum, 1}, // 2*i == 4 -> i == 2
		{"(E['F'] >> 1) == 0", s.rowNum, 2}, // i>>1 == 0 -> i in {0,1}
		{"(E['F'] >> 2) == 1", s.rowNum, 4}, // i>>2 == 1 -> i in {4,5,6,7}
		{"(E['F'] >> 3) == 0", s.rowNum, 8}, // i>>3 == 0 -> i in {0..7}
		{"(B >> 1) == 0", s.rowNum, 1},      // B = 100-i in {0,1} -> i == 99
		{"~E['F'] == -1", s.rowNum, 1},      // ~i == -1 -> i == 0
		{"~E['F'] < -50", s.rowNum, 50},     // ~i = -i-1 < -50 -> i > 49 -> i in {50..99}
	}
	for _, c := range testcases {
		params := integration.GetSearchParams(integration.IndexFaissIDMap, metric.IP)
		searchReq := integration.ConstructSearchRequest(s.dbName, s.collectionName, c.expr,
			integration.FloatVecField, schemapb.DataType_FloatVector, nil, metric.IP, params, 1, s.dim, c.topK, -1)

		searchResult, err := s.Cluster.MilvusClient.Search(context.Background(), searchReq)
		s.NoError(err)
		err = merr.Error(searchResult.GetStatus())
		s.NoError(err)
		s.Equal(c.resNum, len(searchResult.GetResults().GetScores()),
			fmt.Sprintf("unexpected match count for shift/not expr: %s", c.expr))
		mlog.Info(context.TODO(),
			fmt.Sprintf("=========================Shift/Not search done with expr:%s =========================", c.expr))
	}
}

func (s *ExpressionSuite) TestDivisionByZeroError() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	type errorTestCase struct {
		expr             string
		topK             int
		shouldError      bool
		expectedInReason string
	}

	testcases := []errorTestCase{
		// Valid division/modulo operations should succeed
		{"A / 5 > 0", 10, false, ""},
		{"B % 3 == 0", 10, false, ""},
		{"E['F'] / 2 <= 100", 10, false, ""},

		// Division by zero should fail gracefully
		{"A / 0 > 0", 10, true, "division"},
		{"B / 0 == 5", 10, true, "division"},
		{"E['F'] / 0 <= 100", 10, true, "division"},

		// Modulo by zero should fail gracefully
		{"A % 0 == 1", 10, true, "modulus"},
		{"B % 0 != 3", 10, true, "modulus"},
		{"E['G'] % 0 == 4", 10, true, "modulus"},

		// Array field division by zero
		{"C[0] / 0 > 10", 10, true, "division"},
		{"C[0] % 0 == 2", 10, true, "modulus"},
	}

	for _, c := range testcases {
		params := integration.GetSearchParams(integration.IndexFaissIDMap, metric.IP)
		searchReq := integration.ConstructSearchRequest(
			s.dbName, s.collectionName, c.expr,
			integration.FloatVecField, schemapb.DataType_FloatVector,
			nil, metric.IP, params, 1, s.dim, c.topK, -1)

		searchResult, err := s.Cluster.MilvusClient.Search(ctx, searchReq)
		s.NoError(err) // RPC should succeed

		if c.shouldError {
			// For error cases, check status indicates failure
			status := searchResult.GetStatus()
			s.False(merr.Ok(status),
				fmt.Sprintf("Expected error for expr: %s", c.expr))
			if c.expectedInReason != "" {
				s.Contains(status.GetReason(), c.expectedInReason,
					fmt.Sprintf("Error message should contain '%s' for expr: %s",
						c.expectedInReason, c.expr))
			}
			mlog.Info(context.TODO(), "Got expected error",
				mlog.String("expr", c.expr),
				mlog.String("reason", status.GetReason()))
		} else {
			// For valid cases, check successful execution
			err = merr.Error(searchResult.GetStatus())
			s.NoError(err, fmt.Sprintf("Valid expr should succeed: %s", c.expr))
			s.NotEmpty(searchResult.GetResults().GetScores())
		}
	}
}

func (s *ExpressionSuite) TestExpression() {
	s.setParams()
	s.setupData()
	s.searchWithExpression()
	s.searchWithBitwiseExpression()
	s.searchWithShiftNotExpression()
	s.TestDivisionByZeroError()
}

func TestExpression(t *testing.T) {
	suite.Run(t, new(ExpressionSuite))
}
