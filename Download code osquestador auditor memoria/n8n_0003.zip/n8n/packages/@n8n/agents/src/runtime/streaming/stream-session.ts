import { StreamWriterGuard } from './stream-writer-guard';
import type { StreamChunk } from '../../types';
import { AgentEvent } from '../../types/runtime/event';
import type { AgentEventData } from '../../types/runtime/event';
import type { ExecutionOptions, RunOptions, TokenUsage } from '../../types/sdk/agent';
import type { AgentAbortScope, AgentEventBus } from '../state/event-bus';

export interface StreamSessionDeps {
	eventBus: AgentEventBus;
	abortScope: AgentAbortScope;
	runId: string;
	options: (RunOptions & ExecutionOptions) | undefined;
	/** Wrap the loop in the telemetry root span (bound `RuntimeTelemetry.withRootSpan`). */
	withRootSpan: <T>(
		operation: 'generate' | 'stream',
		options: ExecutionOptions | undefined,
		runId: string,
		fn: () => Promise<T>,
	) => Promise<T>;
	/** Run the stream loop, writing chunks through the provided guard. */
	runLoop: (guard: StreamWriterGuard) => Promise<void>;
	flushTelemetry: (options: ExecutionOptions | undefined) => Promise<void>;
	cleanupRun: () => Promise<void>;
	updateState: (status: 'failed' | 'cancelled') => void;
	emitError: (error: unknown) => void;
	/**
	 * Durably persist the turn-so-far when the run is aborted, so a cancelled stream still
	 * leaves its assistant work in memory. Best-effort — must not throw out of the catch.
	 */
	persistTurnOnAbort?: () => Promise<void>;
	/**
	 * Usage + model to stamp on the terminal finish chunk of an aborted or failed
	 * run, so a run cut short still bills the tokens consumed before the stop.
	 */
	getTerminalFinish?: () => { usage?: TokenUsage; model?: string };
}

/**
 * Owns the streaming run lifecycle: creates the `TransformStream`, bridges
 * event-bus lifecycle events to chunks, runs the loop inside the telemetry root
 * span, and guarantees a single shutdown (error/abort translation, listener
 * cleanup, abort-scope disposal). Returns the readable side immediately while
 * the loop runs in the background.
 */
export function startStreamSession(deps: StreamSessionDeps): ReadableStream<StreamChunk> {
	const { readable, writable } = new TransformStream<StreamChunk, StreamChunk>();
	const guard = new StreamWriterGuard(writable.getWriter());

	// Bridge tool-execution / sub-agent lifecycle events into the stream so
	// consumers can show mid-flight indicators. Writes go through the guard, so
	// they are safely dropped once the stream is closed.
	const onToolExecutionStart = (data: AgentEventData): void => {
		if (data.type !== AgentEvent.ToolExecutionStart) return;
		void guard.write({
			type: 'tool-execution-start',
			toolCallId: data.toolCallId,
			toolName: data.toolName,
			startTime: Date.now(),
		});
	};
	const onToolExecutionEnd = (data: AgentEventData): void => {
		if (data.type !== AgentEvent.ToolExecutionEnd) return;
		void guard.write({
			type: 'tool-execution-end',
			toolCallId: data.toolCallId,
			toolName: data.toolName,
			isError: data.isError,
			endTime: Date.now(),
		});
	};
	const onSubAgentStarted = (data: AgentEventData): void => {
		if (data.type !== AgentEvent.SubAgentStarted) return;
		const { type: _type, ...payload } = data;
		void guard.write({ type: 'subagent-started', ...payload });
	};
	const onSubAgentCompleted = (data: AgentEventData): void => {
		if (data.type !== AgentEvent.SubAgentCompleted) return;
		const { type: _type, ...payload } = data;
		void guard.write({ type: 'subagent-completed', ...payload });
	};
	const onSubAgentChunk = (data: AgentEventData): void => {
		if (data.type !== AgentEvent.SubAgentChunk) return;
		const { type: _type, ...payload } = data;
		void guard.write({ type: 'subagent-chunk', ...payload });
	};

	deps.eventBus.on(AgentEvent.ToolExecutionStart, onToolExecutionStart);
	deps.eventBus.on(AgentEvent.ToolExecutionEnd, onToolExecutionEnd);
	deps.eventBus.on(AgentEvent.SubAgentStarted, onSubAgentStarted);
	deps.eventBus.on(AgentEvent.SubAgentCompleted, onSubAgentCompleted);
	deps.eventBus.on(AgentEvent.SubAgentChunk, onSubAgentChunk);

	deps
		.withRootSpan('stream', deps.options, deps.runId, async () => await deps.runLoop(guard))
		.catch(async (error: unknown) => {
			const isAbort = deps.abortScope.isAborted;
			deps.updateState(isAbort ? 'cancelled' : 'failed');
			if (isAbort) {
				// Best-effort: a persistence failure must never skip the shutdown steps
				// below (cleanup, telemetry flush, terminal failure signal).
				try {
					await deps.persistTurnOnAbort?.();
				} catch {
					// swallowed — persistTurnDelta already logs; shutdown must proceed
				}
			} else {
				deps.emitError(error);
			}
			await deps.cleanupRun();
			await deps.flushTelemetry(deps.options);
			// Attach usage on both abort and error shutdowns: turns completed before
			// a mid-run failure were already reported to the sink and must still be
			// billed on the terminal chunk.
			await guard.fail(
				isAbort ? new Error('Agent run was aborted') : error,
				'error',
				deps.getTerminalFinish?.(),
			);
		})
		.finally(() => {
			deps.eventBus.off(AgentEvent.ToolExecutionStart, onToolExecutionStart);
			deps.eventBus.off(AgentEvent.ToolExecutionEnd, onToolExecutionEnd);
			deps.eventBus.off(AgentEvent.SubAgentStarted, onSubAgentStarted);
			deps.eventBus.off(AgentEvent.SubAgentCompleted, onSubAgentCompleted);
			deps.eventBus.off(AgentEvent.SubAgentChunk, onSubAgentChunk);
			void guard.close();
			deps.abortScope.dispose();
		});

	return readable;
}
