// The module's only public entry. The shell imports the descriptor from here via
// `modules.manifest.ts`; anything else the shell (or a test) needs must be exported
// here too — deep paths into `src/` are not part of the contract.
export { InstanceRegistryModule } from './instance-registry.module';
export { useInstanceRegistryStore } from './instance-registry.store';
