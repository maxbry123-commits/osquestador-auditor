// SiYuan - From thought to insight, with agents
// Copyright (c) 2020-present, b3log.org
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package api

import (
	"errors"
	"fmt"
	"net/http"

	"github.com/88250/gulu"
	"github.com/gin-gonic/gin"
	goccyJSON "github.com/goccy/go-json"
	"github.com/siyuan-note/logging"
	"github.com/siyuan-note/siyuan/kernel/av"
	"github.com/siyuan-note/siyuan/kernel/model"
	"github.com/siyuan-note/siyuan/kernel/treenode"
	"github.com/siyuan-note/siyuan/kernel/util"
)

func removeUnusedAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["id"].(string)
	if util.InvalidIDPattern(avID, ret) {
		return
	}
	model.RemoveUnusedAttributeView(avID)
	ret.Data = map[string]any{
		"id": avID,
	}
}

func removeUnusedAttributeViews(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	paths := model.RemoveUnusedAttributeViews()
	ret.Data = map[string]any{
		"paths": paths,
	}
}

func getUnusedAttributeViews(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	unusedAttributeViews := model.UnusedAttributeViews(true)
	total := len(unusedAttributeViews)

	const maxUnusedAttributeViews = 512
	if total > maxUnusedAttributeViews {
		unusedAttributeViews = unusedAttributeViews[:maxUnusedAttributeViews]
		util.PushMsg(fmt.Sprintf(model.Conf.Language(279), total, maxUnusedAttributeViews), 5000)
	}

	ret.Data = unusedAttributeViews
}

func getAttributeViewItemIDsByBoundIDs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	blockIDsArg := arg["blockIDs"].([]any)
	var blockIDs []string
	for _, v := range blockIDsArg {
		blockIDs = append(blockIDs, v.(string))
	}

	ret.Data = model.GetAttributeViewItemIDs(avID, blockIDs)
}

func getAttributeViewBoundBlockIDsByItemIDs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	itemIDsArg := arg["itemIDs"].([]any)
	var itemIDs []string
	for _, v := range itemIDsArg {
		itemIDs = append(itemIDs, v.(string))
	}

	ret.Data = model.GetAttributeViewBoundBlockIDs(avID, itemIDs)
}

func getAttributeViewItemStatuses(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["id"].(string)
	blockID, _ := arg["blockID"].(string)
	viewID, _ := arg["viewID"].(string)
	query, _ := arg["query"].(string)
	itemIDsArg := arg["itemIDs"].([]any)
	itemIDs := make([]string, 0, len(itemIDsArg))
	for _, itemIDArg := range itemIDsArg {
		itemIDs = append(itemIDs, itemIDArg.(string))
	}
	if err := holdAttributeViewRequest(c, blockID, avID); nil != err {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}

	statuses, err := model.GetAttributeViewItemStatuses(blockID, avID, viewID, query, itemIDs)
	if nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = statuses
}

// getAttributeViewAddingBlockDefaultValues 用于获取添加块时的默认值。
// 存在过滤或分组条件时，添加块时需要填充默认值到过滤字段或分组字段中，前端需要调用该接口来获取这些默认值以便填充。
func getAttributeViewAddingBlockDefaultValues(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	blockID, _ := arg["blockID"].(string)
	var viewID string
	if viewIDArg := arg["viewID"]; nil != viewIDArg {
		viewID = viewIDArg.(string)
	}
	var groupID string
	if groupIDArg := arg["groupID"]; nil != groupIDArg {
		groupID = groupIDArg.(string)
	}
	var previousID string
	if nil != arg["previousID"] {
		previousID = arg["previousID"].(string)
	}
	var addingBlockID string
	if nil != arg["addingBlockID"] {
		addingBlockID = arg["addingBlockID"].(string)
	}

	values, err := model.GetAttrViewAddingBlockDefaultValues(avID, blockID, viewID, groupID, previousID, addingBlockID)
	if nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if 1 > len(values) {
		values = nil
	}
	ret.Data = map[string]any{
		"values": values,
	}
}

func batchReplaceAttributeViewBlocks(c *gin.Context) {
	// Add kernel API `/api/av/batchReplaceAttributeViewBlocks` https://github.com/siyuan-note/siyuan/issues/15313
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	isDetached := arg["isDetached"].(bool)
	oldNewArg := arg["oldNew"].([]any)
	var oldNew []map[string]string
	for _, v := range oldNewArg {
		for o, n := range v.(map[string]any) {
			oldNew = append(oldNew, map[string]string{o: n.(string)})
		}
	}

	err := model.BatchReplaceAttributeViewBlocks(avID, isDetached, oldNew)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func setAttrViewGroup(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	avID := arg["avID"].(string)
	blockID := arg["blockID"].(string)
	groupArg := arg["group"].(map[string]any)
	ignoreRows, _ := arg["ignoreRows"].(bool)

	data, err := gulu.JSON.MarshalJSON(groupArg)
	if nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
		c.JSON(http.StatusOK, ret)
		return
	}
	group := &av.ViewGroup{}
	if err = gulu.JSON.UnmarshalJSON(data, group); nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
		c.JSON(http.StatusOK, ret)
		return
	}

	err = model.SetAttributeViewGroup(avID, blockID, group)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()

		c.JSON(http.StatusOK, ret)
		return
	}

	ret = renderAttrView(blockID, avID, "", "", 1, -1, nil, "", false, ignoreRows, "", "")
	if ret.Code == 0 && model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		retDataMap := ret.Data.(map[string]any)
		retDataMap["view"] = model.FilterViewByPublishAccess(c, publishAccess, retDataMap["view"].(av.Viewable))
	}

	c.JSON(http.StatusOK, ret)
}

func setAttrViewFilters(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	avID := arg["avID"].(string)
	blockID := arg["blockID"].(string)
	data := arg["data"].([]any)

	err := model.SetAttrViewFilters(avID, blockID, data)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		c.JSON(http.StatusOK, ret)
		return
	}

	model.ReloadAttrView(avID)
	c.JSON(http.StatusOK, ret)
}

func setAttrViewSorts(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	avID := arg["avID"].(string)
	blockID := arg["blockID"].(string)
	data := arg["data"].([]any)

	err := model.SetAttrViewSorts(avID, blockID, data)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		c.JSON(http.StatusOK, ret)
		return
	}

	model.ReloadAttrView(avID)
	c.JSON(http.StatusOK, ret)
}

func changeAttrViewLayout(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	blockID := arg["blockID"].(string)
	avID := arg["avID"].(string)
	layoutType := arg["layoutType"].(string)
	err := model.ChangeAttrViewLayout(blockID, avID, av.LayoutType(layoutType))
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		c.JSON(http.StatusOK, ret)
		return
	}

	ret = renderAttrView(blockID, avID, "", "", 1, -1, nil, "", false, false, "", "")
	if ret.Code == 0 && model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		retDataMap := ret.Data.(map[string]any)
		retDataMap["view"] = model.FilterViewByPublishAccess(c, publishAccess, retDataMap["view"].(av.Viewable))
	}

	c.JSON(http.StatusOK, ret)
}

func duplicateAttributeViewBlock(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	avID := arg["avID"].(string)

	newAvID, newBlockID, err := model.DuplicateDatabaseBlock(avID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ret.Data = map[string]any{
		"avID":    newAvID,
		"blockID": newBlockID,
	}
}

func getAttributeViewKeysByAvID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	avID := arg["avID"].(string)
	ret.Data = model.GetAttributeViewKeysByID(avID)
}

func getAttributeViewKeysByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	avID := arg["avID"].(string)
	keyIDsArg := arg["keyIDs"].([]any)
	var keyIDs []string
	for _, v := range keyIDsArg {
		keyIDs = append(keyIDs, v.(string))
	}
	ret.Data = model.GetAttributeViewKeysByID(avID, keyIDs...)
}

func getMirrorDatabaseBlocks(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	blockIDs := treenode.GetMirrorAttrViewBlockIDs(avID)
	var retRefDefs []model.RefDefs
	for _, blockID := range blockIDs {
		retRefDefs = append(retRefDefs, model.RefDefs{RefID: blockID, DefIDs: []string{}})
	}
	if 1 > len(retRefDefs) {
		retRefDefs = []model.RefDefs{}
	}

	ret.Data = map[string]any{
		"refDefs": retRefDefs,
	}
}

func setDatabaseBlockView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	blockID := arg["id"].(string)
	viewID := arg["viewID"].(string)
	avID := arg["avID"].(string)

	err := model.SetDatabaseBlockView(blockID, avID, viewID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
}

func getAttributeViewPrimaryKeyValues(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id := arg["id"].(string)
	page := 1
	pageArg := arg["page"]
	if nil != pageArg {
		page = int(pageArg.(float64))
	}

	pageSize := -1
	pageSizeArg := arg["pageSize"]
	if nil != pageSizeArg {
		pageSize = int(pageSizeArg.(float64))
	}

	keyword := ""
	if keywordArg := arg["keyword"]; nil != keywordArg {
		keyword = keywordArg.(string)
	}
	var blockIDs []string
	if blockIDsArg := arg["blockIDs"]; nil != blockIDsArg {
		if blockIDArgs, ok := blockIDsArg.([]any); ok {
			for _, blockIDArg := range blockIDArgs {
				if blockID, ok := blockIDArg.(string); ok && "" != blockID {
					blockIDs = append(blockIDs, blockID)
				}
			}
		}
	}
	attributeViewName, databaseBlockIDs, rows, total, err := model.GetAttributeViewPrimaryKeyValues(id, keyword, blockIDs, page, pageSize)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ret.Data = map[string]any{
		"name":     attributeViewName,
		"blockIDs": databaseBlockIDs,
		"rows":     rows,
		"total":    total,
	}
}

func getAttributeViewRelationCandidates(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID, _ := arg["avID"].(string)
	keyID, _ := arg["keyID"].(string)
	if "" == avID {
		avID, _ = arg["id"].(string)
	}
	keyword := ""
	if keywordArg := arg["keyword"]; nil != keywordArg {
		keyword = keywordArg.(string)
	}
	page := 1
	if pageArg := arg["page"]; nil != pageArg {
		page = int(pageArg.(float64))
	}
	pageSize := -1
	if pageSizeArg := arg["pageSize"]; nil != pageSizeArg {
		pageSize = int(pageSizeArg.(float64))
	}
	var selectedBlockIDs []string
	if selectedBlockIDsArg, ok := arg["selectedBlockIDs"].([]any); ok {
		for _, selectedBlockIDArg := range selectedBlockIDsArg {
			if selectedBlockID, ok := selectedBlockIDArg.(string); ok && "" != selectedBlockID {
				selectedBlockIDs = append(selectedBlockIDs, selectedBlockID)
			}
		}
	}

	name, blockIDs, columns, selectedRows, rows, total, err := model.GetAttributeViewRelationCandidates(
		avID, keyID, keyword, selectedBlockIDs, page, pageSize)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	notebookID := ""
	if 0 < len(blockIDs) {
		if blockTree := treenode.GetBlockTree(blockIDs[0]); nil != blockTree {
			notebookID = blockTree.BoxID
		}
	}
	ret.Data = map[string]any{
		"name":         name,
		"blockIDs":     blockIDs,
		"notebookID":   notebookID,
		"columns":      columns,
		"selectedRows": selectedRows,
		"rows":         rows,
		"total":        total,
	}
}

func appendAttributeViewDetachedBlocksWithValues(c *gin.Context) {
	// Add an internal kernel API `/api/av/appendAttributeViewDetachedBlocksWithValues` https://github.com/siyuan-note/siyuan/issues/11608

	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	var values [][]*av.Value
	for _, blocksVals := range arg["blocksValues"].([]any) {
		vals := blocksVals.([]any)
		var rowValues []*av.Value
		for _, val := range vals {
			data, marshalErr := gulu.JSON.MarshalJSON(val)
			if nil != marshalErr {
				ret.Code = -1
				ret.Msg = marshalErr.Error()
				return
			}
			value := av.Value{}
			if unmarshalErr := gulu.JSON.UnmarshalJSON(data, &value); nil != unmarshalErr {
				ret.Code = -1
				ret.Msg = unmarshalErr.Error()
				return
			}
			rowValues = append(rowValues, &value)
		}
		values = append(values, rowValues)
	}

	err := model.AppendAttributeViewDetachedBlocksWithValues(avID, values)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
}

func addAttributeViewBlocks(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	var blockID string
	if blockIDArg := arg["blockID"]; nil != blockIDArg {
		blockID = blockIDArg.(string)
	}
	var viewID string
	if viewIDArg := arg["viewID"]; nil != viewIDArg {
		viewID = viewIDArg.(string)
	}
	var groupID string
	if groupIDArg := arg["groupID"]; nil != groupIDArg {
		groupID = groupIDArg.(string)
	}
	var previousID string
	if nil != arg["previousID"] {
		previousID = arg["previousID"].(string)
	}

	var srcs []map[string]any
	for _, v := range arg["srcs"].([]any) {
		src := v.(map[string]any)
		srcs = append(srcs, src)
	}

	var ignoreDefaultFill bool
	if nil != arg["ignoreDefaultFill"] {
		ignoreDefaultFill = arg["ignoreDefaultFill"].(bool)
	}

	err := model.AddAttributeViewBlock(nil, srcs, avID, blockID, viewID, groupID, previousID, ignoreDefaultFill)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func removeAttributeViewBlocks(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	var srcIDs []string
	for _, v := range arg["srcIDs"].([]any) {
		srcIDs = append(srcIDs, v.(string))
	}

	err := model.RemoveAttributeViewBlock(srcIDs, avID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func addAttributeViewKey(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	blockID, _ := arg["blockID"].(string)
	keyID := arg["keyID"].(string)
	keyName := arg["keyName"].(string)
	keyType := arg["keyType"].(string)
	keyIcon := arg["keyIcon"].(string)
	previousKeyID := arg["previousKeyID"].(string)

	err := model.AddAttributeViewKey(avID, blockID, keyID, keyName, keyType, keyIcon, previousKeyID, av.DateDisplayFormatFull)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func removeAttributeViewKey(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	keyID := arg["keyID"].(string)
	removeRelationDest := false
	if nil != arg["removeRelationDest"] {
		removeRelationDest = arg["removeRelationDest"].(bool)
	}

	err := model.RemoveAttributeViewKey(avID, keyID, removeRelationDest)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func sortAttributeViewViewKey(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	viewID := ""
	if viewIDArg := arg["viewID"]; nil != viewIDArg {
		viewID = viewIDArg.(string)
	}
	keyID := arg["keyID"].(string)
	previousKeyID := arg["previousKeyID"].(string)

	err := model.SortAttributeViewViewKey(avID, viewID, keyID, previousKeyID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func sortAttributeViewKey(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	keyID := arg["keyID"].(string)
	previousKeyID := arg["previousKeyID"].(string)

	err := model.SortAttributeViewKey(avID, keyID, previousKeyID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}

func getAttributeViewFilterSort(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["id"].(string)
	blockID := arg["blockID"].(string)

	filters, sorts := model.GetAttributeViewFilterSort(avID, blockID)
	ret.Data = map[string]any{
		"filters": filters,
		"sorts":   sorts,
	}
}

func searchAttributeViewRollupDestKeys(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	keyword := arg["keyword"].(string)

	rollupDestKeys := model.SearchAttributeViewRollupDestKeys(avID, keyword)
	ret.Data = map[string]any{
		"keys": rollupDestKeys,
	}
}

func searchAttributeViewRelationKey(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	avID := arg["avID"].(string)
	keyword := arg["keyword"].(string)

	relationKeys := model.SearchAttributeViewRelationKey(avID, keyword)
	ret.Data = map[string]any{
		"keys": relationKeys,
	}
}

func getAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	id := arg["id"].(string)
	ret.Data = map[string]any{
		"av": model.NewAttributeViewData(model.GetAttributeView(id)),
	}
}

func getAttributeViewPasteRows(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var avID, blockID, viewID, groupID, query, startItemID string
	var countArg float64
	if !util.ParseJsonArgs(arg, ret,
		util.BindJsonArg("avID", &avID, true, true),
		util.BindJsonArg("blockID", &blockID, true, true),
		util.BindJsonArg("viewID", &viewID, false, false),
		util.BindJsonArg("groupID", &groupID, false, false),
		util.BindJsonArg("query", &query, false, false),
		util.BindJsonArg("startItemID", &startItemID, true, true),
		util.BindJsonArg("count", &countArg, true, false),
	) {
		return
	}
	if util.InvalidIDPattern(avID, ret) || util.InvalidIDPattern(blockID, ret) ||
		util.InvalidIDPattern(startItemID, ret) ||
		("" != viewID && util.InvalidIDPattern(viewID, ret)) ||
		("" != groupID && util.InvalidIDPattern(groupID, ret)) {
		return
	}
	count := int(countArg)
	if countArg != float64(count) || count < 1 || 100000 < count {
		ret.Code = -1
		ret.Msg = "invalid paste row count"
		return
	}

	view, inferableKeyIDs, err := model.GetAttributeViewPasteRows(blockID, avID, viewID, groupID, query, startItemID, count)
	if nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = map[string]any{"view": view, "inferableKeyIDs": inferableKeyIDs}
}

func getAttributeViewFieldViews(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var avID, keyID string
	if !util.ParseJsonArgs(arg, ret,
		util.BindJsonArg("avID", &avID, true, true),
		util.BindJsonArg("keyID", &keyID, true, true),
	) {
		return
	}
	if util.InvalidIDPattern(avID, ret) || util.InvalidIDPattern(keyID, ret) {
		return
	}

	views, err := model.GetAttributeViewFieldViews(avID, keyID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = map[string]any{
		"views": views,
	}
}

func createAttributeViewItem(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	var avID, blockID, viewID, templateID, previousID, groupID, app, session string
	if !util.ParseJsonArgs(arg, ret,
		util.BindJsonArg("avID", &avID, true, false),
		util.BindJsonArg("blockID", &blockID, true, false),
		util.BindJsonArg("viewID", &viewID, false, false),
		util.BindJsonArg("templateID", &templateID, false, false),
		util.BindJsonArg("previousID", &previousID, false, false),
		util.BindJsonArg("groupID", &groupID, false, false),
		util.BindJsonArg("app", &app, false, false),
		util.BindJsonArg("session", &session, false, false),
	) {
		return
	}
	result, err := model.CreateAttributeViewItem(avID, blockID, viewID, templateID, previousID, groupID)
	setCreateAttributeViewItemResult(ret, result, err, app, session)
}

func createAttributeViewItemWithMarkdown(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	var avID, blockID, viewID, templateID, previousID, groupID, title, markdown, tags, clippingHref, app, session string
	var withMath, listDocTree bool
	if !util.ParseJsonArgs(arg, ret,
		util.BindJsonArg("avID", &avID, true, true),
		util.BindJsonArg("blockID", &blockID, true, true),
		util.BindJsonArg("viewID", &viewID, false, false),
		util.BindJsonArg("templateID", &templateID, true, true),
		util.BindJsonArg("previousID", &previousID, false, false),
		util.BindJsonArg("groupID", &groupID, false, false),
		util.BindJsonArg("title", &title, true, true),
		util.BindJsonArg("markdown", &markdown, true, false),
		util.BindJsonArg("tags", &tags, false, false),
		util.BindJsonArg("withMath", &withMath, false, false),
		util.BindJsonArg("clippingHref", &clippingHref, false, false),
		util.BindJsonArg("listDocTree", &listDocTree, false, false),
		util.BindJsonArg("app", &app, false, false),
		util.BindJsonArg("session", &session, false, false),
	) {
		return
	}
	result, err := model.CreateAttributeViewItemWithMarkdown(avID, blockID, viewID, templateID, previousID, groupID,
		&model.CreateAttributeViewItemMarkdown{
			Title: title, Markdown: markdown, Tags: tags, WithMath: withMath, ClippingHref: clippingHref,
			ListDocTree: listDocTree,
		})
	setCreateAttributeViewItemResult(ret, result, err, app, session)
}

func setCreateAttributeViewItemResult(ret *gulu.Result, result *model.CreateAttributeViewItemResult, err error, app, session string) {
	if nil != err {
		if errors.Is(err, model.ErrBoxNotFound) {
			ret.Code = 1
			ret.Data = map[string]any{"unavailableNotebook": true}
			return
		}
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = result
	if nil != result.Transaction {
		for _, operation := range result.Transaction.DoOperations {
			if "insertAttrViewBlock" == operation.Action {
				operation.Context = map[string]any{
					"filteredTipScope": "target",
					"filteredTipToken": result.ItemID,
					"filteredTipAppID": app,
					"protyleID":        session,
					"openFilteredItem": "true",
				}
				break
			}
		}
		pushTransactions(app, session, []*model.Transaction{result.Transaction})
	}
}

func createAttributeViewItemDocs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	var itemIDsArg []any
	var avID, blockID, saveMode, app, session string
	if !util.ParseJsonArgs(arg, ret,
		util.BindJsonArg("avID", &avID, true, false),
		util.BindJsonArg("blockID", &blockID, true, false),
		util.BindJsonArg("saveMode", &saveMode, true, false),
		util.BindJsonArg("itemIDs", &itemIDsArg, true, false),
		util.BindJsonArg("app", &app, false, false),
		util.BindJsonArg("session", &session, false, false),
	) {
		return
	}
	var itemIDs []string
	for _, itemIDArg := range itemIDsArg {
		itemID, itemOK := itemIDArg.(string)
		if itemOK && "" != itemID {
			itemIDs = append(itemIDs, itemID)
		}
	}
	result, err := model.CreateAttributeViewItemDocs(avID, blockID, saveMode, itemIDs)
	if nil != err {
		if errors.Is(err, model.ErrBoxNotFound) {
			ret.Code = 1
			ret.Data = map[string]any{"unavailableNotebook": true}
			return
		}
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = result
	if nil != result.Transaction {
		pushTransactions(app, session, []*model.Transaction{result.Transaction})
	}
}

func searchAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, _ := util.JsonArg(c, ret)
	if nil == arg {
		return
	}

	keyword := arg["keyword"].(string)
	currentAvID := ""
	if nil != arg["avID"] {
		currentAvID = arg["avID"].(string)
	}
	currentBlockID := ""
	if nil != arg["blockID"] {
		currentBlockID = arg["blockID"].(string)
	}
	var excludes []string
	if nil != arg["excludes"] {
		for _, e := range arg["excludes"].([]any) {
			excludes = append(excludes, e.(string))
		}
	}
	includeViewMatches, _ := arg["includeViewMatches"].(bool)
	results := model.SearchAttributeViewWithOptions(model.SearchAttributeViewOptions{
		Keyword:            keyword,
		ExcludeAvIDs:       excludes,
		CurrentAvID:        currentAvID,
		CurrentBlockID:     currentBlockID,
		IncludeViewMatches: includeViewMatches,
	})
	ret.Data = map[string]any{
		"results": results,
	}
}

func renderSnapshotAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	index := arg["snapshot"].(string)
	id := arg["id"].(string)
	blockID, _ := arg["blockID"].(string)
	viewID, _ := arg["viewID"].(string)
	carrierViewID, _ := arg["carrierViewID"].(string)
	if err := holdAttributeViewRequest(c, blockID, id); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}
	boxID, err := model.ResolveRepoSnapshotAttributeViewBoxID(index, id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if err = holdEncryptedBoxRequest(c, boxID); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}
	view, attrView, err := model.RenderRepoSnapshotAttributeView(index, id, viewID, carrierViewID)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	var views []*av.ViewData
	for _, v := range attrView.Views {
		views = append(views, &av.ViewData{
			ID:               v.ID,
			Icon:             v.Icon,
			Name:             v.Name,
			Desc:             v.Desc,
			HideAttrViewName: v.HideAttrViewName,
			Type:             v.LayoutType,
			PageSize:         v.PageSize,
		})
	}

	ret.Data = map[string]any{
		"name":              attrView.Name,
		"id":                attrView.ID,
		"viewType":          view.GetType(),
		"viewID":            view.GetID(),
		"views":             views,
		"view":              view,
		"isMirror":          av.IsMirror(attrView.ID),
		"newItemTemplates":  attrView.NewItemTemplates,
		"defaultTemplateID": attrView.DefaultTemplateID,
	}
}

func renderHistoryAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id := arg["id"].(string)
	created := arg["created"].(string)
	blockIDArg := arg["blockID"]
	var blockID string
	if nil != blockIDArg {
		blockID = blockIDArg.(string)
	}
	viewIDArg := arg["viewID"]
	var viewID string
	if nil != viewIDArg {
		viewID = viewIDArg.(string)
	}
	carrierViewID, _ := arg["carrierViewID"].(string)
	page := 1
	pageArg := arg["page"]
	if nil != pageArg {
		page = int(pageArg.(float64))
	}

	pageSize := -1
	pageSizeArg := arg["pageSize"]
	if nil != pageSizeArg {
		pageSize = int(pageSizeArg.(float64))
	}

	query := ""
	queryArg := arg["query"]
	if nil != queryArg {
		query = queryArg.(string)
	}

	groupPaging := map[string]any{}
	groupPagingArg := arg["groupPaging"]
	if nil != groupPagingArg {
		groupPaging = groupPagingArg.(map[string]any)
	}
	if err := holdAttributeViewRequest(c, blockID, id); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}
	boxID, err := model.ResolveHistoryAttributeViewBoxID(id, created)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if err = holdEncryptedBoxRequest(c, boxID); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}

	view, attrView, err := model.RenderHistoryAttributeView(id, viewID, carrierViewID, query, page, pageSize, groupPaging, created)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	var views []*av.ViewData
	for _, v := range attrView.Views {
		views = append(views, &av.ViewData{
			ID:               v.ID,
			Icon:             v.Icon,
			Name:             v.Name,
			Desc:             v.Desc,
			HideAttrViewName: v.HideAttrViewName,
			Type:             v.LayoutType,
			PageSize:         v.PageSize,
		})
	}

	ret.Data = map[string]any{
		"name":              attrView.Name,
		"id":                attrView.ID,
		"viewType":          view.GetType(),
		"viewID":            view.GetID(),
		"views":             views,
		"view":              view,
		"isMirror":          av.IsMirror(attrView.ID),
		"newItemTemplates":  attrView.NewItemTemplates,
		"defaultTemplateID": attrView.DefaultTemplateID,
	}
}

func renderAttributeView(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	id := arg["id"].(string)
	blockIDArg := arg["blockID"]
	var blockID string
	if nil != blockIDArg {
		blockID = blockIDArg.(string)
	}
	viewIDArg := arg["viewID"]
	var viewID string
	if nil != viewIDArg {
		viewID = viewIDArg.(string)
	}
	page := 1
	pageArg := arg["page"]
	if nil != pageArg {
		page = int(pageArg.(float64))
	}

	pageSize := -1
	pageSizeArg := arg["pageSize"]
	if nil != pageSizeArg {
		pageSize = int(pageSizeArg.(float64))
	}

	query := ""
	queryArg := arg["query"]
	if nil != queryArg {
		query = queryArg.(string)
	}

	groupPaging := map[string]any{}
	groupPagingArg := arg["groupPaging"]
	if nil != groupPagingArg {
		groupPaging = groupPagingArg.(map[string]any)
	}

	initialLayout := av.LayoutType("")
	if initialLayoutArg, ok := arg["initialLayout"].(string); ok {
		initialLayout = av.LayoutType(initialLayoutArg)
	}

	createIfNotExist := true
	createIfNotExistArg := arg["createIfNotExist"]
	if nil != createIfNotExistArg {
		createIfNotExist = createIfNotExistArg.(bool)
	}

	ignoreRows := false
	ignoreRowsArg := arg["ignoreRows"]
	if nil != ignoreRowsArg {
		ignoreRows = ignoreRowsArg.(bool)
	}
	targetItemID := ""
	if targetItemIDArg := arg["targetItemID"]; nil != targetItemIDArg {
		targetItemID = targetItemIDArg.(string)
	}
	targetGroupID := ""
	if targetGroupIDArg := arg["targetGroupID"]; nil != targetGroupIDArg {
		targetGroupID = targetGroupIDArg.(string)
	}
	if err := holdAttributeViewRequest(c, blockID, id); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		c.JSON(http.StatusOK, ret)
		return
	}

	readOnlyRole := model.IsReadOnlyRoleContext(c)
	publishAccess := model.PublishAccess(nil)
	if readOnlyRole {
		publishAccess = model.GetPublishAccess()
		if !model.CheckAttributeViewBlockAccessableByPublishAccess(c, publishAccess, id, blockID) {
			ret.Code = -1
			ret.Msg = av.ErrAttributeViewNotFound.Error()
			c.JSON(http.StatusOK, ret)
			return
		}
	}

	ret = renderAttrView(blockID, id, viewID, query, page, pageSize, groupPaging, initialLayout, createIfNotExist, ignoreRows, targetItemID, targetGroupID)
	if ret.Code == 0 && readOnlyRole {
		retDataMap := ret.Data.(map[string]any)
		retDataMap["view"] = model.FilterAttributeViewByPublishAccess(c, publishAccess, id, blockID, retDataMap["view"].(av.Viewable))
	}

	// 大体量响应（如全量数据库视图）用 goccy 序列化后直接写字节，跳过 gin 内部基于标准库的二次序列化
	marshalBytes, marshalErr := goccyJSON.Marshal(ret)
	if nil != marshalErr || 0 == len(marshalBytes) {
		c.JSON(http.StatusOK, ret)
		return
	}
	c.Data(http.StatusOK, "application/json; charset=utf-8", marshalBytes)
}

func holdAttributeViewRequest(c *gin.Context, blockID, avID string) error {
	if blockID != "" {
		if block := treenode.GetBlockTree(blockID); block != nil && model.IsEncryptedBox(block.BoxID) {
			return holdEncryptedBoxRequest(c, block.BoxID)
		}
	}
	if _, boxID := av.FindAttributeViewPath(avID); boxID != "" {
		return holdEncryptedBoxRequest(c, boxID)
	}
	return nil
}

func renderAttrView(blockID, avID, viewID, query string, page, pageSize int, groupPaging map[string]any, initialLayout av.LayoutType, createIfNotExist, ignoreRows bool, targetItemID, targetGroupID string) (ret *gulu.Result) {
	ret = gulu.Ret.NewResult()
	view, attrView, target, err := model.RenderAttributeViewWithTarget(blockID, avID, viewID, query, page, pageSize, groupPaging, initialLayout, createIfNotExist, ignoreRows, targetItemID, targetGroupID)
	if err != nil {
		ret.Code = -1
		if errors.Is(err, av.ErrSpecTooNew) {
			ret.Msg = model.Conf.Language(215)
		} else {
			ret.Msg = err.Error()
		}
		if errors.Is(err, av.ErrViewNotFound) {
			ret.Data = map[string]any{"error": "viewNotFound"}
		}
		return
	}

	var views []*av.ViewData
	for _, v := range attrView.Views {
		views = append(views, &av.ViewData{
			ID:               v.ID,
			Icon:             v.Icon,
			Name:             v.Name,
			Desc:             v.Desc,
			HideAttrViewName: v.HideAttrViewName,
			Type:             v.LayoutType,
			PageSize:         v.PageSize,
		})
	}

	retData := map[string]any{
		"name":              attrView.Name,
		"id":                attrView.ID,
		"viewType":          view.GetType(),
		"viewID":            view.GetID(),
		"views":             views,
		"view":              view,
		"isMirror":          av.IsMirror(attrView.ID),
		"newItemTemplates":  attrView.NewItemTemplates,
		"defaultTemplateID": attrView.DefaultTemplateID,
	}
	if nil != target {
		retData["target"] = target
	}
	ret.Data = retData
	return
}

func getCurrentAttrViewImages(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id := arg["id"].(string)
	viewIDArg := arg["viewID"]
	var viewID string
	if nil != viewIDArg {
		viewID = viewIDArg.(string)
	}

	query := ""
	queryArg := arg["query"]
	if nil != queryArg {
		query = queryArg.(string)
	}

	images, err := model.GetCurrentAttributeViewImages(c, id, viewID, query)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = images
}

func getAttributeViewKeys(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id, _ := arg["id"].(string)
	avID, _ := arg["avID"].(string)
	itemID, _ := arg["itemID"].(string)
	valueID, _ := arg["valueID"].(string)
	var blockAttributeViewKeys []*model.BlockAttributeViewKeys
	if "" != avID && ("" != itemID || "" != valueID) {
		blockAttributeViewKeys = model.GetAttributeViewItemKeys(avID, itemID, valueID)
	} else {
		blockAttributeViewKeys = model.GetBlockAttributeViewKeys(id)
	}
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		blockAttributeViewKeys = model.FilterBlockAttributeViewKeysByPublishAccess(c, publishAccess, blockAttributeViewKeys)
	}
	ret.Data = blockAttributeViewKeys
}

func getAttributeViewSearchTarget(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id, _ := arg["id"].(string)
	keywordsArg, _ := arg["keywords"].([]any)
	var keywords []string
	for _, keywordArg := range keywordsArg {
		if keyword, ok := keywordArg.(string); ok {
			keywords = append(keywords, keyword)
		}
	}
	ret.Data = model.GetAttributeViewSearchTarget(id, keywords)
}

func getAttributeViewBacklinks(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id, _ := arg["id"].(string)
	avID, _ := arg["avID"].(string)
	itemID, _ := arg["itemID"].(string)
	valueID, _ := arg["valueID"].(string)
	backlinks := model.GetAttributeViewBacklinks(id, avID, itemID, valueID)
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		backlinks = model.FilterAttributeViewBacklinksByPublishAccess(c, publishAccess, backlinks)
	}
	ret.Data = backlinks
}

func setAttributeViewBlockAttr(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	keyID := arg["keyID"].(string)
	var itemID string
	if _, ok := arg["itemID"]; ok {
		itemID = arg["itemID"].(string)
	} else if _, ok := arg["rowID"]; ok {
		// TODO 该参数将于 2026 年 12 月 1 日后删除
		msg := fmt.Sprintf("[%s] parameter [%s] is deprecated, visit [https://github.com/siyuan-note/siyuan/issues/15727] for details",
			c.Request.RequestURI, "rowID")
		logging.LogWarn(msg)
		ret.Code = -1
		ret.Msg = msg
		return
	}
	value := arg["value"].(any)
	updatedVal, err := model.UpdateAttributeViewCell(nil, avID, keyID, itemID, value)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ret.Data = map[string]any{
		"value": updatedVal,
	}

	model.ReloadAttrView(avID)
}

func batchSetAttributeViewBlockAttrs(c *gin.Context) {
	// Add kernel API `/api/av/batchSetAttributeViewBlockAttrs` https://github.com/siyuan-note/siyuan/issues/15310
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	avID := arg["avID"].(string)
	values := arg["values"].([]any)
	err := model.BatchUpdateAttributeViewCells(nil, avID, values)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	model.ReloadAttrView(avID)
}
