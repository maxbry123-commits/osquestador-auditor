// SiYuan - From thought to insight, with agents
// Copyright (c) 2020-present, b3log.org
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package api

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/88250/gulu"
	"github.com/88250/lute/ast"
	"github.com/gin-gonic/gin"
	"github.com/siyuan-note/siyuan/kernel/filesys"
	"github.com/siyuan-note/siyuan/kernel/model"
	"github.com/siyuan-note/siyuan/kernel/treenode"
	"github.com/siyuan-note/siyuan/kernel/util"
)

func moveLocalShorthands(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	ids, err := model.MoveLocalShorthands(notebook)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ret.Data = ids
}

func listDocTree(c *gin.Context) {
	// Add kernel API `/api/filetree/listDocTree` https://github.com/siyuan-note/siyuan/issues/10482

	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	// 加密笔记本锁定时拒绝直接列举磁盘目录，防止泄漏文档 ID、层级和数量
	if err := holdEncryptedBoxRequest(c, notebook); err != nil {
		ret.Code = -1
		ret.Msg = model.Conf.Language(314)
		return
	}

	p := arg["path"].(string)
	p = strings.TrimSuffix(p, ".sy")
	// 越界校验：拒绝 ..，确保路径位于 <data>/<notebook>/ 内。
	// 无需 filepath.IsAbs —— notebook 路径全为 notebook 内相对路径，且跨 OS 对 "/" 判定不一致。
	if found := strings.Contains(p, ".."); found {
		ret.Code = -1
		ret.Msg = "path must not contain '..'"
		return
	}
	var doctree []*DocFile
	root := filepath.Join(util.WorkspaceDir, "data", notebook, p)
	if !gulu.File.IsSubPath(filepath.Join(util.WorkspaceDir, "data", notebook), root) {
		ret.Code = -1
		ret.Msg = "path escapes notebook directory"
		return
	}
	dir, err := os.ReadDir(root)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ids := map[string]bool{}
	for _, entry := range dir {
		if strings.HasPrefix(entry.Name(), ".") {
			continue
		}

		if entry.IsDir() {
			if !ast.IsNodeIDPattern(entry.Name()) {
				continue
			}

			parent := &DocFile{ID: entry.Name()}
			ids[parent.ID] = true
			doctree = append(doctree, parent)

			subPath := filepath.Join(root, entry.Name())
			if err = walkDocTree(subPath, parent, ids); err != nil {
				ret.Code = -1
				ret.Msg = err.Error()
				return
			}
		} else {
			id := strings.TrimSuffix(entry.Name(), ".sy")
			if !ast.IsNodeIDPattern(id) {
				continue
			}

			doc := &DocFile{ID: id}
			if !ids[doc.ID] {
				doctree = append(doctree, doc)
			}
			ids[doc.ID] = true
		}
	}

	ret.Data = map[string]any{
		"tree": doctree,
	}
}

type DocFile struct {
	ID       string     `json:"id"`
	Children []*DocFile `json:"children,omitempty"`
}

func walkDocTree(p string, docFile *DocFile, ids map[string]bool) (err error) {
	dir, err := os.ReadDir(p)
	if err != nil {
		return
	}

	for _, entry := range dir {
		if entry.IsDir() {
			if strings.HasPrefix(entry.Name(), ".") {
				continue
			}

			if !ast.IsNodeIDPattern(entry.Name()) {
				continue
			}

			parent := &DocFile{ID: entry.Name()}
			ids[parent.ID] = true
			docFile.Children = append(docFile.Children, parent)

			subPath := filepath.Join(p, entry.Name())
			if err = walkDocTree(subPath, parent, ids); err != nil {
				return
			}
		} else {
			doc := &DocFile{ID: strings.TrimSuffix(entry.Name(), ".sy")}
			if !ids[doc.ID] {
				docFile.Children = append(docFile.Children, doc)
			}
			ids[doc.ID] = true
		}
	}
	return
}

func upsertIndexes(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	pathsArg := arg["paths"].([]any)
	var paths []string
	for _, p := range pathsArg {
		paths = append(paths, p.(string))
	}
	model.UpsertIndexes(paths)
}

func removeIndexes(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	pathsArg := arg["paths"].([]any)
	var paths []string
	for _, p := range pathsArg {
		paths = append(paths, p.(string))
	}
	model.RemoveIndexes(paths)
}

func doc2Heading(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	srcID := arg["srcID"].(string)
	targetID := arg["targetID"].(string)
	after := arg["after"].(bool)
	srcTreeBox, srcTreePath, err := model.Doc2Heading(srcID, targetID, after)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}

	ret.Data = map[string]any{
		"srcTreeBox":  srcTreeBox,
		"srcTreePath": srcTreePath,
	}
}

func heading2Doc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	srcHeadingID := arg["srcHeadingID"].(string)
	targetNotebook := arg["targetNoteBook"].(string)

	// 禁止跨加密笔记本移动块：加密笔记本是孤岛
	if bt := treenode.GetBlockTree(srcHeadingID); bt != nil && model.IsEncryptedBox(bt.BoxID) && bt.BoxID != targetNotebook {
		ret.Code = -1
		ret.Msg = model.Conf.Language(313)
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}
	var targetPath string
	if arg["targetPath"] != nil {
		targetPath = arg["targetPath"].(string)
	}
	var previousPath string
	if arg["previousPath"] != nil {
		previousPath = arg["previousPath"].(string)
	}
	var toTop bool
	if arg["toTop"] != nil {
		toTop = arg["toTop"].(bool)
	}
	srcRootBlockID, targetPath, err := model.Heading2Doc(srcHeadingID, targetNotebook, targetPath, previousPath, toTop)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}

	model.FlushTxQueue()

	box := model.Conf.Box(targetNotebook)
	evt := util.NewCmdResult("heading2doc", 0, util.PushModeBroadcast)
	evt.Data = map[string]any{
		"box":            box,
		"path":           targetPath,
		"srcRootBlockID": srcRootBlockID,
	}
	util.PushEvent(evt)
}

func li2Doc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	srcListItemID := arg["srcListItemID"].(string)
	targetNotebook := arg["targetNoteBook"].(string)

	// 禁止跨加密笔记本移动块：加密笔记本是孤岛
	if bt := treenode.GetBlockTree(srcListItemID); bt != nil && model.IsEncryptedBox(bt.BoxID) && bt.BoxID != targetNotebook {
		ret.Code = -1
		ret.Msg = model.Conf.Language(313)
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}

	var targetPath string
	if arg["targetPath"] != nil {
		targetPath = arg["targetPath"].(string)
	}
	var previousPath string
	if arg["previousPath"] != nil {
		previousPath = arg["previousPath"].(string)
	}
	var toTop bool
	if arg["toTop"] != nil {
		toTop = arg["toTop"].(bool)
	}
	srcRootBlockID, targetPath, err := model.ListItem2Doc(srcListItemID, targetNotebook, targetPath, previousPath, toTop)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}

	model.FlushTxQueue()

	box := model.Conf.Box(targetNotebook)
	evt := util.NewCmdResult("li2doc", 0, util.PushModeBroadcast)
	evt.Data = map[string]any{
		"box":            box,
		"path":           targetPath,
		"srcRootBlockID": srcRootBlockID,
	}
	util.PushEvent(evt)
}

func getHPathByPath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	p := arg["path"].(string)

	hPath, err := model.GetHPathByPath(notebook, p)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if p != "/" && model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		id := util.GetTreeID(p)
		if !model.CheckBlockIdMetadataAccessableByPublishAccessInBox(c, publishAccess, id, notebook) {
			ret.Code = -1
			ret.Msg = model.ErrBlockNotFound.Error()
			return
		}
	}
	ret.Data = hPath
}

func getHPathsByPaths(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	pathsArg := arg["paths"].([]any)
	var paths []string
	for _, p := range pathsArg {
		paths = append(paths, p.(string))
	}
	paths = filterFileTreePathsByPublishMetadataAccess(c, paths)
	hPath, err := model.GetHPathsByPaths(paths)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = hPath
}

func getHPathByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id := arg["id"].(string)
	if util.InvalidIDPattern(id, ret) {
		return
	}

	hPath, err := model.GetHPathByID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		if !model.CheckBlockIdMetadataAccessableByPublishAccess(c, publishAccess, id) {
			ret.Code = -1
			ret.Msg = model.ErrTreeNotFound.Error()
			return
		}
	}
	ret.Data = hPath
}

func getPathByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var id string
	if !util.ParseJsonArgs(arg, ret, util.BindJsonArg("id", &id, true, true)) {
		return
	}
	if util.InvalidIDPattern(id, ret) {
		return
	}

	p, notebook, err := model.GetPathByID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		if !model.CheckBlockIdMetadataAccessableByPublishAccessInBox(c, publishAccess, id, notebook) {
			ret.Code = -1
			ret.Msg = model.ErrTreeNotFound.Error()
			return
		}
	}
	ret.Data = map[string]any{
		"path":     p,
		"notebook": notebook,
	}
}

func getFullHPathByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	if nil == arg["id"] {
		return
	}

	id := arg["id"].(string)
	if util.InvalidIDPattern(id, ret) {
		return
	}
	hPath, err := model.GetFullHPathByID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		if !model.CheckBlockIdMetadataAccessableByPublishAccess(c, publishAccess, id) {
			ret.Code = -1
			ret.Msg = model.ErrTreeNotFound.Error()
			return
		}
	}
	ret.Data = hPath
}

func getIDsByHPath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	if nil == arg["path"] {
		return
	}
	if nil == arg["notebook"] {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	p := arg["path"].(string)
	ids, err := model.GetIDsByHPath(p, notebook)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ids = filterFileTreeBlockIDsByPublishDiscoverability(c, ids, notebook)
	ret.Data = ids
}

func filterFileTreePathsByPublishMetadataAccess(c *gin.Context, paths []string) (ret []string) {
	if !model.IsReadOnlyRoleContext(c) {
		return paths
	}

	ids := make([]string, 0, len(paths))
	for _, p := range paths {
		ids = append(ids, util.GetTreeID(p))
	}
	blockTrees := treenode.GetBlockTrees(ids)
	publishAccess := model.GetPublishAccess()
	ret = make([]string, 0, len(paths))
	for i, p := range paths {
		if model.CheckBlockTreeMetadataAccessableByPublishAccess(c, publishAccess, blockTrees[ids[i]]) {
			ret = append(ret, p)
		}
	}
	return
}

func filterFileTreeBlockIDsByPublishDiscoverability(c *gin.Context, ids []string, boxID string) (ret []string) {
	if !model.IsReadOnlyRoleContext(c) {
		return ids
	}

	blockTrees := treenode.GetBlockTreesInBox(ids, boxID)
	publishAccess := model.GetPublishAccess()
	ret = make([]string, 0, len(ids))
	for _, id := range ids {
		if model.CheckBlockTreeDiscoverableByPublishAccess(publishAccess, blockTrees[id]) {
			ret = append(ret, id)
		}
	}
	return
}

func moveDocs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var fromPaths []string
	fromPathsArg := arg["fromPaths"].([]any)
	for _, fromPath := range fromPathsArg {
		fromPaths = append(fromPaths, fromPath.(string))
	}
	toPath := arg["toPath"].(string)
	toNotebook := arg["toNotebook"].(string)
	if util.InvalidIDPattern(toNotebook, ret) {
		return
	}
	callback := arg["callback"]
	err := model.MoveDocs(fromPaths, toNotebook, toPath, callback)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}
}

func moveDocsByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	fromIDsArg := arg["fromIDs"].([]any)
	var fromIDs []string
	for _, fromIDArg := range fromIDsArg {
		fromID := fromIDArg.(string)
		if util.InvalidIDPattern(fromID, ret) {
			return
		}
		fromIDs = append(fromIDs, fromID)
	}
	toID := arg["toID"].(string)
	if util.InvalidIDPattern(toID, ret) {
		return
	}

	var fromPaths []string
	for _, fromID := range fromIDs {
		tree, err := model.LoadTreeByBlockID(fromID)
		if err != nil {
			ret.Code = -1
			ret.Msg = err.Error()
			ret.Data = map[string]any{"closeTimeout": 7000}
			return
		}
		fromPaths = append(fromPaths, tree.Path)
	}
	fromPaths = gulu.Str.RemoveDuplicatedElem(fromPaths)

	var box *model.Box
	toTree, err := model.LoadTreeByBlockID(toID)
	if err != nil {
		box = model.Conf.Box(toID)
		if nil == box {
			ret.Code = -1
			ret.Msg = "can't found box or tree by id [" + toID + "]"
			ret.Data = map[string]any{"closeTimeout": 7000}
			return
		}
	}

	var toNotebook, toPath string
	if nil != toTree {
		toNotebook = toTree.Box
		toPath = toTree.Path
	} else if nil != box {
		toNotebook = box.ID
		toPath = "/"
	}
	callback := arg["callback"]
	err = model.MoveDocs(fromPaths, toNotebook, toPath, callback)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}
}

func removeDoc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	p := arg["path"].(string)
	if err := model.RemoveDoc(notebook, p); err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
	}
}

func removeDocByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var id string
	if !util.ParseJsonArgs(arg, ret, util.BindJsonArg("id", &id, true, true)) {
		return
	}
	if util.InvalidIDPattern(id, ret) {
		return
	}

	p, notebook, err := model.GetPathByID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}

	if err = model.RemoveDoc(notebook, p); err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
	}
}

func removeDocs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	pathsArg := arg["paths"].([]any)
	var paths []string
	for _, path := range pathsArg {
		paths = append(paths, path.(string))
	}
	if err := model.RemoveDocs(paths); err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
	}
}

func renameDoc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	p := arg["path"].(string)
	title := arg["title"].(string)

	err := model.RenameDoc(notebook, p, title)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	return
}

func renameDocByID(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}
	if nil == arg["id"] {
		return
	}

	id := arg["id"].(string)
	if util.InvalidIDPattern(id, ret) {
		return
	}

	title := arg["title"].(string)

	tree, err := model.LoadTreeByBlockID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}

	err = model.RenameDoc(tree.Box, tree.Path, title)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
}

func duplicateDoc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	id := arg["id"].(string)
	tree, err := model.LoadTreeByBlockID(id)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}

	notebook := tree.Box
	model.DuplicateDoc(tree)

	ret.Data = map[string]any{
		"id":       tree.Root.ID,
		"notebook": notebook,
		"path":     tree.Path,
		"hPath":    tree.HPath,
	}
}

func createDoc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	p := arg["path"].(string)
	title := arg["title"].(string)
	md := arg["md"].(string)
	sortsArg := arg["sorts"]
	var sorts []string
	if nil != sortsArg {
		for _, sort := range sortsArg.([]any) {
			sorts = append(sorts, sort.(string))
		}
	}

	tree, err := model.CreateDocByMd(notebook, p, title, md, sorts, arg)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		ret.Data = map[string]any{"closeTimeout": 7000}
		return
	}

	ret.Data = map[string]any{
		"id": tree.Root.ID,
	}
}

func createDailyNote(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	p, existed, err := model.CreateDailyNote(notebook)
	if err != nil {
		if errors.Is(err, model.ErrBoxNotFound) {
			ret.Code = 1
		} else {
			ret.Code = -1
		}
		ret.Msg = err.Error()
		return
	}

	model.FlushTxQueue()
	box := model.Conf.Box(notebook)
	luteEngine := util.NewLute()
	tree, err := filesys.LoadTree(box.ID, p, luteEngine)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	if !existed {
		// 只有创建的情况才推送，已经存在的情况不推送
		// Creating a dailynote existed no longer expands the doc tree https://github.com/siyuan-note/siyuan/issues/9959
		appArg := arg["app"]
		app := ""
		if nil != appArg {
			app = appArg.(string)
		}
		evt := util.NewCmdResult("createdailynote", 0, util.PushModeBroadcast)
		evt.AppId = app
		evt.Data = map[string]any{
			"box":  box,
			"path": p,
		}
		util.PushEvent(evt)
	}

	ret.Data = map[string]any{
		"id": tree.Root.ID,
	}
}

func createDocWithMd(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	if util.InvalidIDPattern(notebook, ret) {
		return
	}

	tagsArg := arg["tags"]
	var tags string
	if nil != tagsArg {
		tags = tagsArg.(string)
	}

	var parentID string
	parentIDArg := arg["parentID"]
	if nil != parentIDArg {
		parentID = parentIDArg.(string)
	}

	id := ast.NewNodeID()
	idArg := arg["id"]
	if nil != idArg {
		id = idArg.(string)
	}

	hPath := arg["path"].(string)
	markdown := arg["markdown"].(string)

	baseName := path.Base(hPath)
	dir := path.Dir(hPath)
	r, _ := regexp.Compile("\r\n|\r|\n|\u2028|\u2029|\t|/")
	baseName = r.ReplaceAllString(baseName, "")
	if 512 < utf8.RuneCountInString(baseName) {
		baseName = gulu.Str.SubStr(baseName, 512)
	}
	hPath = path.Join(dir, baseName)
	if !strings.HasPrefix(hPath, "/") {
		hPath = "/" + hPath
	}

	withMath := false
	withMathArg := arg["withMath"]
	if nil != withMathArg {
		withMath = withMathArg.(bool)
	}
	clippingHref := ""
	clippingHrefArg := arg["clippingHref"]
	if nil != clippingHrefArg {
		clippingHref = clippingHrefArg.(string)
	}

	id, err := model.CreateWithMarkdown(tags, notebook, hPath, markdown, parentID, id, withMath, clippingHref, arg)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = id
}

func getDocCreateSavePath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	docCreateSaveBox, docCreateSavePathTpl := model.ResolveDocCreateSaveLocation(notebook)
	docCreateTemplatePath := model.Conf.FileTree.DocCreateTemplatePath
	if box := model.Conf.Box(notebook); nil != box {
		boxConf := box.GetConf()
		if "" != boxConf.DocCreateTemplatePath {
			docCreateTemplatePath = boxConf.DocCreateTemplatePath
		}
	}
	docCreateSavePathTpl = strings.TrimSpace(docCreateSavePathTpl)

	if docCreateSaveBox != notebook {
		if "" != docCreateSavePathTpl && !strings.HasPrefix(docCreateSavePathTpl, "/") {
			// 如果配置的笔记本不是当前笔记本，则将相对路径转换为绝对路径
			docCreateSavePathTpl = "/" + docCreateSavePathTpl
		}
	}

	docCreateSavePath, err := model.RenderGoTemplateInBox(docCreateSavePathTpl, docCreateSaveBox)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}

	ret.Data = map[string]any{
		"box":                   docCreateSaveBox,
		"path":                  docCreateSavePath,
		"docCreateTemplatePath": docCreateTemplatePath,
	}
}

func getRefCreateSavePath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	box := model.Conf.Box(notebook)
	var refCreateSaveBox string
	refCreateSavePathTpl := model.Conf.FileTree.RefCreateSavePath
	if nil != box {
		boxConf := box.GetConf()
		refCreateSaveBox = boxConf.RefCreateSaveBox
		refCreateSavePathTpl = boxConf.RefCreateSavePath
	}
	if "" == refCreateSaveBox && "" == refCreateSavePathTpl {
		refCreateSaveBox = model.Conf.FileTree.RefCreateSaveBox
	}
	if "" != refCreateSaveBox {
		if nil == model.Conf.Box(refCreateSaveBox) {
			// 如果配置的笔记本未打开或者不存在，则使用当前笔记本
			refCreateSaveBox = notebook
		}
	}
	if "" == refCreateSaveBox {
		refCreateSaveBox = notebook
	}
	if "" == refCreateSavePathTpl {
		refCreateSavePathTpl = model.Conf.FileTree.RefCreateSavePath
	}

	if refCreateSaveBox != notebook {
		if "" != refCreateSavePathTpl && !strings.HasPrefix(refCreateSavePathTpl, "/") {
			// 如果配置的笔记本不是当前笔记本，则将相对路径转换为绝对路径
			refCreateSavePathTpl = "/" + refCreateSavePathTpl
		}
	}

	refCreateSavePath, err := model.RenderGoTemplateInBox(refCreateSavePathTpl, refCreateSaveBox)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = map[string]any{
		"box":  refCreateSaveBox,
		"path": refCreateSavePath,
	}
}

func getShorthandSavePath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)

	shorthandSaveBox := model.Conf.FileTree.ShorthandSaveBox
	shorthandSavePathTpl := model.Conf.FileTree.ShorthandSavePath

	if "" == shorthandSaveBox {
		shorthandSaveBox = notebook
	}

	if shorthandSaveBox != notebook {
		if "" != shorthandSavePathTpl && !strings.HasPrefix(shorthandSavePathTpl, "/") {
			shorthandSavePathTpl = "/" + shorthandSavePathTpl
		}
	}

	shorthandSavePath, err := model.RenderGoTemplateInBox(shorthandSavePathTpl, shorthandSaveBox)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	ret.Data = map[string]any{
		"box":  shorthandSaveBox,
		"path": shorthandSavePath,
	}
}

func changeSort(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	pathsArg := arg["paths"].([]any)
	var paths []string
	for _, p := range pathsArg {
		paths = append(paths, p.(string))
	}
	model.ChangeFileTreeSort(notebook, paths)
}

type sortRequestItem struct {
	ID   string `json:"id"`
	Sort *int   `json:"sort"`
}

func setSort(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	request := &struct {
		NotebookSorts []*sortRequestItem `json:"notebookSorts"`
		DocSorts      []*sortRequestItem `json:"docSorts"`
	}{}
	if err := c.ShouldBindJSON(request); err != nil {
		ret.Code = -1
		ret.Msg = fmt.Sprintf("Parses request [%s] failed: %s", c.Request.URL.Path, err)
		return
	}
	if 1 > len(request.NotebookSorts)+len(request.DocSorts) {
		ret.Code = -1
		ret.Msg = "Fields [notebookSorts] and [docSorts] must not both be empty"
		return
	}
	notebookSorts, ok := parseSortItems("notebookSorts", request.NotebookSorts, ret)
	if !ok {
		return
	}
	docSorts, ok := parseSortItems("docSorts", request.DocSorts, ret)
	if !ok {
		return
	}

	result, err := model.SetFileTreeSort(notebookSorts, docSorts)
	ret.Data = result
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
	}
}

func setDocSortMode(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	request := &struct {
		ID       string          `json:"id"`
		SortMode json.RawMessage `json:"sortMode"`
	}{}
	if err := c.ShouldBindJSON(request); nil != err {
		ret.Code = -1
		ret.Msg = fmt.Sprintf("Parses request [%s] failed: %s", c.Request.URL.Path, err)
		return
	}
	if util.InvalidIDPattern(request.ID, ret) {
		return
	}
	if 0 == len(request.SortMode) {
		ret.Code = -1
		ret.Msg = "Field [sortMode] is required"
		return
	}

	var sortMode *int
	if !bytes.Equal(bytes.TrimSpace(request.SortMode), []byte("null")) {
		value := 0
		if err := json.Unmarshal(request.SortMode, &value); nil != err {
			ret.Code = -1
			ret.Msg = fmt.Sprintf("Field [sortMode] must be an integer or null: %s", err)
			return
		}
		sortMode = &value
	}

	result, err := model.SetDocSortMode(request.ID, sortMode)
	ret.Data = result
	if nil != err {
		ret.Code = -1
		ret.Msg = err.Error()
	}
}

func parseSortItems(field string, items []*sortRequestItem, ret *gulu.Result) (retItems []*model.SortItem, ok bool) {
	ids := map[string]struct{}{}
	for i, item := range items {
		if nil == item {
			ret.Code = -1
			ret.Msg = fmt.Sprintf("Field [%s][%d] must not be null", field, i)
			return
		}
		if util.InvalidIDPattern(item.ID, ret) {
			return
		}
		if nil == item.Sort {
			ret.Code = -1
			ret.Msg = fmt.Sprintf("Field [%s][%d].sort is required", field, i)
			return
		}
		if _, ok := ids[item.ID]; ok {
			ret.Code = -1
			ret.Msg = fmt.Sprintf("Field [%s] contains duplicate ID [%s]", field, item.ID)
			return nil, false
		}
		ids[item.ID] = struct{}{}
		retItems = append(retItems, &model.SortItem{ID: item.ID, Sort: *item.Sort})
	}
	return retItems, true
}

func searchDocs(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	flashcard := false
	if arg["flashcard"] != nil {
		flashcard = arg["flashcard"].(bool)
	}

	var excludeIDs []string
	if arg["excludeIDs"] != nil {
		excludeIDsArg := arg["excludeIDs"].([]any)
		for _, excludeID := range excludeIDsArg {
			excludeIDs = append(excludeIDs, excludeID.(string))
		}
	}

	k := arg["k"].(string)
	docs := model.SearchDocs(k, flashcard, excludeIDs)
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		docs = model.FilterSearchDocsByPublishAccess(c, publishAccess, docs)
	}
	ret.Data = docs
}

func listDocsByPath(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	notebook := arg["notebook"].(string)
	p := arg["path"].(string)

	// 越界校验：拒绝 ..，确保路径位于 <data>/<notebook>/ 内
	if strings.Contains(p, "..") {
		ret.Code = -1
		ret.Msg = "path must not contain '..' and must be relative"
		return
	}

	if isEncryptedNotebookDeniedForPublish(c, notebook) {
		ret.Data = map[string]any{
			"box":               notebook,
			"path":              p,
			"files":             []*model.File{},
			"effectiveSortMode": model.Conf.FileTree.Sort,
		}
		return
	}

	sortParam := arg["sort"]
	sortMode := util.SortModeUnassigned
	if nil != sortParam {
		sortMode = int(sortParam.(float64))
	}
	effectiveSortMode := sortMode
	if util.SortModeUnassigned == effectiveSortMode {
		var resolveErr error
		effectiveSortMode, resolveErr = model.ResolveDocTreeSortMode(notebook, p)
		if nil != resolveErr {
			ret.Code = -1
			ret.Msg = resolveErr.Error()
			return
		}
	}
	flashcard := false
	if arg["flashcard"] != nil {
		flashcard = arg["flashcard"].(bool)
	}
	maxListCount := model.Conf.FileTree.MaxListCount
	if arg["maxListCount"] != nil {
		// API `listDocsByPath` add an optional parameter `maxListCount` https://github.com/siyuan-note/siyuan/issues/7993
		maxListCount = int(arg["maxListCount"].(float64))
		if 0 >= maxListCount {
			maxListCount = math.MaxInt
		}
	}
	showHidden := false
	if arg["showHidden"] != nil {
		showHidden = arg["showHidden"].(bool)
	}

	files, totals, err := model.ListDocTree(notebook, p, effectiveSortMode, flashcard, showHidden, maxListCount)
	if err != nil {
		ret.Code = -1
		ret.Msg = err.Error()
		return
	}
	// 过滤掉发布不可见的文件
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		publishInvisible := model.GetInvisiblePublishAccess(publishAccess)
		publishDisable := model.GetDisablePublishAccess(publishAccess)
		tempFiles := []*model.File{}
		for _, file := range files {
			if model.CheckPathAccessableByPublishIgnore(notebook, file.Path, publishInvisible) &&
				model.CheckPathAccessableByPublishIgnore(notebook, file.Path, publishDisable) {
				tempFiles = append(tempFiles, file)
			}
		}
		files = tempFiles
	}
	if maxListCount < totals {
		// API `listDocsByPath` add an optional parameter `ignoreMaxListHint` https://github.com/siyuan-note/siyuan/issues/10290
		ignoreMaxListHintArg := arg["ignoreMaxListHint"]
		if nil == ignoreMaxListHintArg || !ignoreMaxListHintArg.(bool) {
			var app string
			if nil != arg["app"] {
				app = arg["app"].(string)
			}
			if nil == util.NotificationsCfg || util.NotificationsCfg.DocTreeMaxList {
				util.PushMsgWithApp(app, fmt.Sprintf(model.Conf.Language(48), len(files)), 7000)
			}
		}
	}

	ret.Data = map[string]any{
		"box":               notebook,
		"path":              p,
		"files":             files,
		"effectiveSortMode": effectiveSortMode,
	}
}

func getDoc(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var id string
	if !util.ParseJsonArgs(arg, ret, util.BindJsonArg("id", &id, true, true)) {
		return
	}
	if util.InvalidIDPattern(id, ret) {
		return
	}
	requestedNotebook, _ := arg["notebook"].(string)
	if model.IsReadOnlyRoleContext(c) &&
		((requestedNotebook != "" && model.IsEncryptedBoxDeniedByPublishAccess(requestedNotebook)) ||
			model.IsEncryptedPublishRuntimeTarget(id)) {
		ret.Code = 3
		return
	}
	if err := holdEncryptedBoxRequest(c, requestedNotebook); err != nil {
		ret.Code = 1
		ret.Msg = err.Error()
		return
	}
	includeDocInfo, _ := arg["includeDocInfo"].(bool)
	if includeDocInfo && model.IsReadOnlyRoleContext(c) {
		includeDocInfo = isBlockPublishAccessible(c, id, requestedNotebook)
	}
	idx := arg["index"]
	index := 0
	if nil != idx {
		index = int(idx.(float64))
	}

	var query string
	if queryArg := arg["query"]; nil != queryArg {
		query = queryArg.(string)
	}
	var queryMethod int
	if queryMethodArg := arg["queryMethod"]; nil != queryMethodArg {
		queryMethod = int(queryMethodArg.(float64))
	}
	var queryTypes map[string]bool
	if queryTypesArg := arg["queryTypes"]; nil != queryTypesArg {
		typesArg := queryTypesArg.(map[string]any)
		queryTypes = map[string]bool{}
		for t, b := range typesArg {
			queryTypes[t] = b.(bool)
		}
	}
	var querySubTypes map[string]bool
	if querySubTypesArg := arg["querySubTypes"]; nil != querySubTypesArg {
		typesArg := querySubTypesArg.(map[string]any)
		querySubTypes = map[string]bool{}
		for t, b := range typesArg {
			querySubTypes[t] = b.(bool)
		}
	}

	m := arg["mode"] // 0: 仅当前 ID，1：向上 2：向下，3：上下都加载，4：加载末尾
	mode := 0
	if nil != m {
		mode = int(m.(float64))
	}
	s := arg["size"]
	size := 102400 // 默认最大加载块数
	if nil != s {
		size = int(s.(float64))
	}
	startID := ""
	endID := ""
	startIDArg := arg["startID"]
	endIDArg := arg["endID"]
	if nil != startIDArg && nil != endIDArg {
		startID = startIDArg.(string)
		endID = endIDArg.(string)
		size = model.Conf.Editor.DynamicLoadBlocks
	}
	isBacklinkArg := arg["isBacklink"]
	isBacklink := false
	if nil != isBacklinkArg {
		isBacklink = isBacklinkArg.(bool)
	}
	originalRefBlockIDsArg := arg["originalRefBlockIDs"]
	originalRefBlockIDs := map[string]string{}
	if nil != originalRefBlockIDsArg {
		m := originalRefBlockIDsArg.(map[string]any)
		for k, v := range m {
			originalRefBlockIDs[k] = v.(string)
		}
	}
	highlightArg := arg["highlight"]
	highlight := true
	if nil != highlightArg {
		highlight = highlightArg.(bool)
	}

	var blockCount int
	var content, parentID, parent2ID, rootID, typ string
	var eof, scroll bool
	var boxID, docPath string
	var isBacklinkExpand bool
	var keywords []string
	var headingNumbers map[string]string
	var docInfo *model.BlockInfo
	var err error
	// 加密笔记本的打开文档走 InBox 版（查加密 blocktree + content db）
	if requestedNotebook != "" && model.IsEncryptedBox(requestedNotebook) {
		blockCount, content, parentID, parent2ID, rootID, typ, eof, scroll, boxID, docPath, isBacklinkExpand, keywords, headingNumbers, docInfo, err =
			model.GetDocInBox(startID, endID, id, index, query, queryTypes, querySubTypes, queryMethod, mode, size, isBacklink, originalRefBlockIDs, highlight, includeDocInfo, requestedNotebook)
	} else {
		blockCount, content, parentID, parent2ID, rootID, typ, eof, scroll, boxID, docPath, isBacklinkExpand, keywords, headingNumbers, docInfo, err =
			model.GetDoc(startID, endID, id, index, query, queryTypes, querySubTypes, queryMethod, mode, size, isBacklink, originalRefBlockIDs, highlight, includeDocInfo)
	}
	if errors.Is(err, model.ErrBlockNotFound) {
		ret.Code = 3
		return
	}

	if err != nil {
		ret.Code = 1
		ret.Msg = err.Error()
		return
	}

	// 判断是否正在同步中 https://github.com/siyuan-note/siyuan/issues/6290
	isSyncing := model.IsSyncingFile(rootID)

	publishAccessRequired := false
	if model.IsReadOnlyRoleContext(c) {
		publishAccess := model.GetPublishAccess()
		newContent, publishAccessStatus := model.FilterContentByPublishAccessWithStatus(c, publishAccess, boxID, docPath, content, false)
		publishAccessRequired = publishAccessStatus == model.PublishAccessPasswordRequired
		if newContent != content {
			content = newContent
			headingNumbers = nil
			scroll = false // 避免长页面可通过滚动无限刷出多个锁
		}
		if nil != docInfo {
			if publishAccessRequired {
				docInfo = nil
			} else {
				docInfo = model.FilterBlockInfoByPublishAccess(c, publishAccess, docInfo)
			}
		}
	}

	data := map[string]any{
		"id":                    id,
		"mode":                  mode,
		"parentID":              parentID,
		"parent2ID":             parent2ID,
		"rootID":                rootID,
		"type":                  typ,
		"content":               content,
		"blockCount":            blockCount,
		"eof":                   eof,
		"scroll":                scroll,
		"box":                   boxID,
		"path":                  docPath,
		"isSyncing":             isSyncing,
		"isBacklinkExpand":      isBacklinkExpand,
		"keywords":              keywords,
		"headingNumbers":        headingNumbers,
		"publishAccessRequired": publishAccessRequired,
		"reqId":                 arg["reqId"],
	}
	if nil != docInfo {
		data["docInfo"] = docInfo
	}
	ret.Data = data
}

func setPublishAccess(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	publishAccess := model.GetPublishAccess()
	ID := arg["id"].(string)
	if model.IsEncryptedPublishAccessTarget(ID) {
		ret.Code = -1
		ret.Msg = model.Conf.Language(313)
		return
	}
	visible := arg["visible"].(bool)
	password := arg["password"].(string)
	disable := arg["disable"].(bool)

	foundIndex := -1
	updated := false
	for i, item := range publishAccess {
		if ID == item.ID {
			foundIndex = i
			break
		}
	}
	if foundIndex >= 0 {
		if visible && len(password) == 0 && !disable {
			publishAccess = append(publishAccess[:foundIndex], publishAccess[foundIndex+1:]...)
		} else {
			publishAccess[foundIndex].Visible = visible
			publishAccess[foundIndex].Password = password
			publishAccess[foundIndex].Disable = disable
		}
		updated = true
	} else {
		if !visible || len(password) != 0 || disable {
			publishAccess = append(publishAccess, &model.PublishAccessItem{
				ID:       ID,
				Visible:  visible,
				Password: password,
				Disable:  disable,
			})
			updated = true
		}
	}

	if updated {
		err := model.SetPublishAccess(publishAccess)
		if err != nil {
			ret.Code = -1
			ret.Msg = err.Error()
			return
		}
	}

	model.PurgePublishAccess()
}

func getPublishAccess(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var IDs []string
	for _, ID := range arg["ids"].([]any) {
		id := ID.(string)
		if model.IsEncryptedPublishAccessTarget(id) {
			ret.Code = -1
			ret.Msg = model.Conf.Language(313)
			return
		}
		IDs = append(IDs, id)
	}

	publishAccess := model.GetPublishAccess()
	maskedPublishAccess := model.PublishAccess{}
	for _, ID := range IDs {
		found := false
		for _, item := range publishAccess {
			if item.ID == ID {
				found = true
				maskedPublishAccess = append(maskedPublishAccess, item)
				break
			}
		}
		if !found {
			maskedPublishAccess = append(maskedPublishAccess, &model.PublishAccessItem{
				ID:       ID,
				Visible:  true,
				Password: "",
				Disable:  false,
			})
		}
	}

	ret.Data = map[string]any{
		"publishAccess": maskedPublishAccess,
	}
}

func authFilePublishAccess(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	arg, ok := util.JsonArg(c, ret)
	if !ok {
		c.JSON(http.StatusOK, ret)
		return
	}

	ID := arg["id"].(string)
	if util.InvalidIDPattern(ID, ret) {
		c.JSON(http.StatusOK, ret)
		return
	}
	password := arg["password"].(string)

	ret.Code = -1
	ret.Msg = model.Conf.Language(285)
	if model.IsEncryptedPublishRuntimeTarget(ID) {
		c.JSON(http.StatusOK, ret)
		return
	}

	// 按来源 IP 对发布密码认证进行限流，防止无限次暴力破解密码 https://github.com/siyuan-note/siyuan/security/advisories/GHSA-v362-968x-gp2v
	ip := c.ClientIP()
	if retryAfter := util.AuthThrottleCheck(ip); 0 < retryAfter {
		// 锁定期间持续记录失败，不断延长锁定时间
		util.AuthThrottleFail(ip)
		c.Header("Retry-After", strconv.Itoa(retryAfter))
		ret.Msg = model.Conf.Language(354)
		c.JSON(http.StatusTooManyRequests, ret)
		return
	}

	publishAccess := model.GetPublishAccess()
	for _, item := range publishAccess {
		if item.ID != ID {
			continue
		}
		if item.Disable || item.Password == "" || !util.AuthCodeEquals(item.Password, password) {
			// 恒定时间比较，避免通过响应时间差异猜测密码
			util.AuthThrottleFail(ip)
			c.JSON(http.StatusOK, ret)
			return
		}
		util.AuthThrottleReset(ip)
		model.SetPublishAuthCookie(c, ID, password)
		ret.Code = 0
		ret.Msg = ""
		c.JSON(http.StatusOK, ret)
		return
	}

	// 目标 ID 不在发布配置中，同样记录失败以限制尝试次数
	util.AuthThrottleFail(ip)
	c.JSON(http.StatusOK, ret)
}
