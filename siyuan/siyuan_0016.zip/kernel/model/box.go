// SiYuan - From thought to insight, with agents
// Copyright (c) 2020-present, b3log.org
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package model

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path"
	"path/filepath"
	"runtime/debug"
	"sort"
	"strings"
	"time"

	"github.com/88250/go-humanize"
	"github.com/88250/gulu"
	"github.com/88250/lute/ast"
	"github.com/88250/lute/html"
	"github.com/88250/lute/lex"
	"github.com/88250/lute/parse"
	"github.com/araddon/dateparse"
	"github.com/siyuan-note/filelock"
	"github.com/siyuan-note/logging"
	"github.com/siyuan-note/siyuan/kernel/cache"
	"github.com/siyuan-note/siyuan/kernel/conf"
	"github.com/siyuan-note/siyuan/kernel/filesys"
	"github.com/siyuan-note/siyuan/kernel/heif"
	"github.com/siyuan-note/siyuan/kernel/sql"
	"github.com/siyuan-note/siyuan/kernel/task"
	"github.com/siyuan-note/siyuan/kernel/treenode"
	"github.com/siyuan-note/siyuan/kernel/util"
	"gopkg.in/yaml.v3"
)

// Box 笔记本。
type Box struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	Icon         string `json:"icon"`
	Sort         int    `json:"sort"`
	SortMode     int    `json:"sortMode"`
	Closed       bool   `json:"closed"`
	SubFileCount int    `json:"subFileCount"`

	NewFlashcardCount int `json:"newFlashcardCount"`
	DueFlashcardCount int `json:"dueFlashcardCount"`
	FlashcardCount    int `json:"flashcardCount"`

	Encrypted bool              `json:"encrypted"` // 是否为加密笔记本
	Unlocked  bool              `json:"unlocked"`  // 加密笔记本是否已解锁（DEK 在内存），非加密笔记本恒为 false
	State     EncryptedBoxState `json:"state,omitempty"`
}

func StatJob() {

	Conf.m.Lock()
	Conf.Stat.TreeCount = treenode.CountTrees()
	Conf.Stat.CTreeCount = treenode.CeilTreeCount(Conf.Stat.TreeCount)
	Conf.Stat.BlockCount = treenode.CountBlocks()
	Conf.Stat.CBlockCount = treenode.CeilBlockCount(Conf.Stat.BlockCount)
	Conf.Stat.DataSize, Conf.Stat.AssetsSize = util.DataSize()
	Conf.Stat.CDataSize = util.CeilSize(Conf.Stat.DataSize)
	Conf.Stat.CAssetsSize = util.CeilSize(Conf.Stat.AssetsSize)
	Conf.m.Unlock()
	Conf.Save()

	logging.LogInfof("auto stat [trees=%d, blocks=%d, dataSize=%s, assetsSize=%s]", Conf.Stat.TreeCount, Conf.Stat.BlockCount, humanize.BytesCustomCeil(uint64(Conf.Stat.DataSize), 2), humanize.BytesCustomCeil(uint64(Conf.Stat.AssetsSize), 2))

	// 桌面端检查磁盘可用空间 https://github.com/siyuan-note/siyuan/issues/6873
	if util.ContainerStd != util.Container {
		return
	}

	if util.NeedWarnDiskUsage(Conf.Stat.DataSize) {
		util.PushMsg(Conf.Language(179), 7000)
	}
}

func ListNotebooks() (ret []*Box, err error) {
	ret = []*Box{}
	dirs, err := os.ReadDir(util.DataDir)
	if err != nil {
		logging.LogErrorf("read dir [%s] failed: %s", util.DataDir, err)
		return ret, err
	}
	for _, dir := range dirs {
		if util.IsReservedFilename(dir.Name()) {
			continue
		}

		if !dir.IsDir() {
			continue
		}

		id := dir.Name()
		if !ast.IsNodeIDPattern(id) {
			continue
		}

		boxConf := conf.NewBoxConf()
		boxDirPath := filepath.Join(util.DataDir, id)
		boxConfPath := filepath.Join(boxDirPath, ".siyuan", "conf.json")
		isExistConf := filelock.IsExist(boxConfPath)
		missingEncryptedIdentity := false
		if !isExistConf {
			if !IsUserGuide(id) {
				// conf.json 缺失时检查加密备份，确认是否为加密笔记本
				backup, backupErr := readNotebookCryptBackup(id)
				if backupErr != nil {
					logging.LogErrorf("read notebook crypt backup [%s] failed: %s", boxDirPath, backupErr)
					markRuntimeEncryptedBox(id)
					boxConf.Encrypted = true
					missingEncryptedIdentity = true
					setEncryptedBoxState(id, EncryptedBoxStateError)
				} else if backup != nil {
					// 从备份恢复 conf.json，避免加密笔记本被当作普通笔记本处理
					markRuntimeEncryptedBox(id)
					boxConf.Encrypted = true
					boxConf.BoxCrypt = backup
					tmpBox := &Box{ID: id}
					if saveErr := tmpBox.SaveConf(boxConf); saveErr != nil {
						logging.LogErrorf("restore encrypted notebook conf from backup failed [%s]: %s", boxDirPath, saveErr)
						continue
					}
					logging.LogWarnf("restored encrypted notebook conf from backup [%s]", boxDirPath)
				} else if IsEncryptedBox(id) {
					boxConf.Encrypted = true
					missingEncryptedIdentity = true
					setEncryptedBoxState(id, EncryptedBoxStateError)
					logging.LogErrorf("encrypted notebook key identity is missing [%s]", boxDirPath)
				} else {
					// 数据同步时展开文档树操作可能导致数据丢失 https://github.com/siyuan-note/siyuan/issues/7129
					logging.LogWarnf("found a corrupted box [%s]", boxDirPath)
				}
			} else {
				continue
			}
		} else {
			data, readErr := filelock.ReadFile(boxConfPath)
			if nil != readErr {
				logging.LogErrorf("read box conf [%s] failed: %s", boxConfPath, readErr)
				continue
			}
			if readErr = gulu.JSON.UnmarshalJSON(data, boxConf); nil != readErr {
				logging.LogErrorf("parse box conf [%s] failed: %s", boxConfPath, readErr)
				// 检查加密备份，有备份则保留损坏 conf 不删（避免标记为缺失后自动恢复旧数据）
				backup, backupErr := readNotebookCryptBackup(id)
				if backupErr != nil || backup != nil {
					markRuntimeEncryptedBox(id)
					continue
				}
				filelock.Remove(boxConfPath)
				continue
			}
		}
		if !boxConf.Encrypted && IsEncryptedBox(id) {
			backup, backupErr := readNotebookCryptBackup(id)
			boxConf.Encrypted = true
			if backupErr == nil && backup != nil {
				boxConf.BoxCrypt = backup
			} else {
				missingEncryptedIdentity = true
				setEncryptedBoxState(id, EncryptedBoxStateError)
			}
			logging.LogWarnf("normal notebook configuration conflicts with encrypted identity [%s]", boxDirPath)
		}
		if boxConf.Encrypted {
			markRuntimeEncryptedBox(id)
		}
		if boxConf.Encrypted && !missingEncryptedIdentity {
			repairEncryptedBoxStateFromDEK(id)
			if metadataErr := revealBoxMetadataIfUnlocked(id, boxConf); metadataErr != nil {
				logging.LogErrorf("decrypt encrypted notebook metadata [%s] failed: %s", id, metadataErr)
			}
		}

		unlocked := boxConf.Encrypted && !missingEncryptedIdentity && isBoxUnlockedForAccess(id)
		closed := boxConf.Closed
		if boxConf.Encrypted {
			// 加密笔记本的打开状态不能从其他设备继承，仅本机已挂载且持有 DEK 时才视为打开。
			closed = !unlocked || !isEncryptedBoxMounted(id)
		}
		box := &Box{
			ID:        id,
			Name:      boxConf.Name,
			Icon:      filterBoxIcon(boxConf.Icon),
			Sort:      boxConf.Sort,
			SortMode:  boxConf.SortMode,
			Closed:    closed,
			Encrypted: boxConf.Encrypted,
			Unlocked:  unlocked,
		}
		if box.Encrypted {
			if missingEncryptedIdentity {
				box.State = EncryptedBoxStateError
			} else {
				box.State = GetEncryptedBoxState(id)
			}
		}

		if !isExistConf && !missingEncryptedIdentity {
			// Automatically create notebook conf.json if not found it https://github.com/siyuan-note/siyuan/issues/9647
			if err := box.SaveConf(boxConf); err != nil {
				logging.LogErrorf("save box conf [%s] failed: %s", boxDirPath, err)
			}
			box.Unindex()
			logging.LogWarnf("fixed a corrupted box [%s]", boxDirPath)
		}
		ret = append(ret, box)
	}

	switch Conf.FileTree.Sort {
	case util.SortModeNameASC:
		sort.Slice(ret, func(i, j int) bool {
			return util.PinYinCompare4FileTree(ret[i].Name, ret[j].Name)
		})
	case util.SortModeNameDESC:
		sort.Slice(ret, func(i, j int) bool {
			return util.PinYinCompare4FileTree(ret[j].Name, ret[i].Name)
		})
	case util.SortModeAlphanumASC:
		sort.Slice(ret, func(i, j int) bool {
			return util.NaturalCompare(ret[i].Name, ret[j].Name)
		})
	case util.SortModeAlphanumDESC:
		sort.Slice(ret, func(i, j int) bool {
			return util.NaturalCompare(ret[j].Name, ret[i].Name)
		})
	case util.SortModeCustom:
		sort.Slice(ret, func(i, j int) bool { return ret[i].Sort < ret[j].Sort })
	case util.SortModeCreatedASC:
		sort.Slice(ret, func(i, j int) bool { return ret[i].ID < ret[j].ID })
	case util.SortModeCreatedDESC:
		sort.Slice(ret, func(i, j int) bool { return ret[i].ID > ret[j].ID })
	}
	return
}

func (box *Box) GetConf() (ret *conf.BoxConf) {
	ret = conf.NewBoxConf()

	confPath := filepath.Join(util.DataDir, box.ID, ".siyuan/conf.json")
	if !filelock.IsExist(confPath) {
		return
	}

	data, err := filelock.ReadFile(confPath)
	if err != nil {
		logging.LogErrorf("read box conf [%s] failed: %s", confPath, err)
		return
	}

	if err = gulu.JSON.UnmarshalJSON(data, ret); err != nil {
		logging.LogErrorf("parse box conf [%s] failed: %s", confPath, err)
		return
	}

	if ret.Encrypted {
		if err = revealBoxMetadataIfUnlocked(box.ID, ret); err != nil {
			logging.LogErrorf("decrypt encrypted notebook metadata [%s] failed: %s", box.ID, err)
		}
	} else {
		ret.Icon = filterBoxIcon(ret.Icon)
	}
	return
}

func (box *Box) SaveConf(conf *conf.BoxConf) error {
	confPath := filepath.Join(util.DataDir, box.ID, ".siyuan/conf.json")
	persisted, err := prepareBoxConfForSave(box.ID, conf)
	if err != nil {
		return fmt.Errorf("prepare box conf [%s] failed: %w", confPath, err)
	}
	newData, err := gulu.JSON.MarshalIndentJSON(persisted, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal box conf [%s] failed: %w", confPath, err)
	}

	oldData, err := filelock.ReadFile(confPath)
	if err != nil {
		if err = box.saveConf0(newData); err != nil {
			return err
		}
		return syncBoxConfCryptoBackup(box.ID, persisted)
	}

	if bytes.Equal(newData, oldData) {
		return syncBoxConfCryptoBackup(box.ID, persisted)
	}

	if err = box.saveConf0(newData); err != nil {
		return err
	}
	return syncBoxConfCryptoBackup(box.ID, persisted)
}

func syncBoxConfCryptoBackup(boxID string, boxConf *conf.BoxConf) error {
	if !boxConf.Encrypted || boxConf.BoxCrypt == nil {
		return nil
	}
	if needWriteNotebookCryptBackup(boxID, boxConf.BoxCrypt) {
		return writeNotebookCryptBackup(boxID, boxConf.BoxCrypt)
	}
	return nil
}

func (box *Box) saveConf0(data []byte) error {
	confPath := filepath.Join(util.DataDir, box.ID, ".siyuan/conf.json")
	if err := os.MkdirAll(filepath.Join(util.DataDir, box.ID, ".siyuan"), 0755); err != nil {
		return fmt.Errorf("mkdir box conf dir failed: %w", err)
	}
	if err := filelock.WriteFile(confPath, data); err != nil {
		util.ReportFileSysFatalError(err)
		return fmt.Errorf("write box conf [%s] failed: %w", confPath, err)
	}
	invalidateEncryptedPublishAccessCache()
	return nil
}

// validateBoxPath 校验 box 内相对路径，拒绝 .. 和绝对路径，确保最终路径在 <DataDir>/<boxID>/ 内。
func (box *Box) validateBoxPath(p string) (string, error) {
	return filesys.ValidateBoxRelativePath(box.ID, p)
}

func (box *Box) Ls(p string) (ret []*FileInfo, totals int, err error) {
	if _, err = box.validateBoxPath(p); err != nil {
		return
	}
	boxLocalPath := filepath.Join(util.DataDir, box.ID)
	if before, ok := strings.CutSuffix(p, ".sy"); ok {
		dir := before
		absDir := filepath.Join(boxLocalPath, dir)
		if gulu.File.IsDir(absDir) {
			p = dir
		} else {
			return
		}
	}

	entries, err := os.ReadDir(filepath.Join(util.DataDir, box.ID, p))
	if err != nil {
		return
	}

	for _, f := range entries {
		info, infoErr := f.Info()
		if nil != infoErr {
			logging.LogErrorf("read file info failed: %s", infoErr)
			continue
		}

		name := f.Name()
		if util.IsReservedFilename(name) {
			continue
		}
		if strings.HasSuffix(name, ".tmp") {
			// 移除写入失败时产生的并且早于 30 分钟前的临时文件，近期创建的临时文件可能正在写入中
			removePath := filepath.Join(util.DataDir, box.ID, p, name)
			if info.ModTime().Before(time.Now().Add(-30 * time.Minute)) {
				if removeErr := os.Remove(removePath); nil != removeErr {
					logging.LogWarnf("remove tmp file [%s] failed: %s", removePath, removeErr)
				}
			}
			continue
		}

		totals += 1
		fi := &FileInfo{}
		fi.name = name
		fi.isdir = f.IsDir()
		fi.size = info.Size()
		fPath := path.Join(p, name)
		if f.IsDir() {
			fPath += "/"
		}
		fi.path = fPath
		ret = append(ret, fi)
	}
	return
}

func (box *Box) Stat(p string) (ret *FileInfo) {
	if _, err := box.validateBoxPath(p); err != nil {
		return
	}
	absPath := filepath.Join(util.DataDir, box.ID, p)
	info, err := os.Stat(absPath)
	if err != nil {
		if !os.IsNotExist(err) {
			logging.LogErrorf("stat [%s] failed: %s", absPath, err)
		}
		return
	}
	ret = &FileInfo{
		path:  p,
		name:  info.Name(),
		size:  info.Size(),
		isdir: info.IsDir(),
	}
	return
}

func (box *Box) Exist(p string) bool {
	if _, err := box.validateBoxPath(p); err != nil {
		return false
	}
	return filelock.IsExist(filepath.Join(util.DataDir, box.ID, p))
}

func (box *Box) Mkdir(path string) error {
	if _, err := box.validateBoxPath(path); err != nil {
		return err
	}
	if err := os.Mkdir(filepath.Join(util.DataDir, box.ID, path), 0755); err != nil {
		msg := fmt.Sprintf(Conf.Language(6), box.Name, path, err)
		logging.LogErrorf("mkdir [path=%s] in box [%s] failed: %s", path, box.ID, err)
		return errors.New(msg)
	}
	IncSync()
	return nil
}

func (box *Box) MkdirAll(path string) error {
	if _, err := box.validateBoxPath(path); err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Join(util.DataDir, box.ID, path), 0755); err != nil {
		msg := fmt.Sprintf(Conf.Language(6), box.Name, path, err)
		logging.LogErrorf("mkdir all [path=%s] in box [%s] failed: %s", path, box.ID, err)
		return errors.New(msg)
	}
	IncSync()
	return nil
}

func (box *Box) Move(oldPath, newPath string) error {
	if _, err := box.validateBoxPath(oldPath); err != nil {
		return err
	}
	if _, err := box.validateBoxPath(newPath); err != nil {
		return err
	}
	boxLocalPath := filepath.Join(util.DataDir, box.ID)
	fromPath := filepath.Join(boxLocalPath, oldPath)
	toPath := filepath.Join(boxLocalPath, newPath)

	if err := filelock.Rename(fromPath, toPath); err != nil {
		msg := fmt.Sprintf(Conf.Language(5), box.Name, fromPath, err)
		logging.LogErrorf("move [path=%s] in box [%s] failed: %s", fromPath, box.Name, err)
		return errors.New(msg)
	}

	if oldDir := path.Dir(oldPath); ast.IsNodeIDPattern(path.Base(oldDir)) {
		fromDir := filepath.Join(boxLocalPath, oldDir)
		if util.IsEmptyDir(fromDir) {
			filelock.Remove(fromDir)
		}
	}
	IncSync()
	return nil
}

func (box *Box) Remove(path string) error {
	if _, err := box.validateBoxPath(path); err != nil {
		return err
	}
	boxLocalPath := filepath.Join(util.DataDir, box.ID)
	filePath := filepath.Join(boxLocalPath, path)
	if err := filelock.Remove(filePath); err != nil {
		msg := fmt.Sprintf(Conf.Language(7), box.Name, path, err)
		logging.LogErrorf("remove [path=%s] in box [%s] failed: %s", path, box.ID, err)
		return errors.New(msg)
	}
	IncSync()
	return nil
}

func (box *Box) ListFiles(path string) (ret []*FileInfo) {
	// ListFiles 委托给 Ls，后者已有 validateBoxPath
	fis, _, err := box.Ls(path)
	if err != nil {
		return
	}
	box.listFiles(&fis, &ret)
	return
}

func (box *Box) listFiles(files, ret *[]*FileInfo) {
	for _, file := range *files {
		if file.isdir {
			fis, _, err := box.Ls(file.path)
			if err == nil {
				box.listFiles(&fis, ret)
			}
			*ret = append(*ret, file)
		} else {
			*ret = append(*ret, file)
		}
	}
	return
}

type BoxInfo struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	DocCount int    `json:"docCount"`
	Size     uint64 `json:"size"`
	HSize    string `json:"hSize"`
	Mtime    int64  `json:"mtime"`
	CTime    int64  `json:"ctime"`
	HMtime   string `json:"hMtime"`
	HCtime   string `json:"hCtime"`
}

func (box *Box) GetInfo() (ret *BoxInfo) {
	ret = &BoxInfo{
		ID:   box.ID,
		Name: util.EscapeHTML(box.Name),
	}

	fileInfos := box.ListFiles("/")

	t, _ := time.ParseInLocation("20060102150405", box.ID[:14], time.Local)
	ret.CTime = t.Unix()
	ret.HCtime = t.Format("2006-01-02 15:04:05") + ", " + util.HumanizeTime(t, Conf.Lang)

	docLatestModTime := t
	for _, fileInfo := range fileInfos {
		if fileInfo.isdir {
			continue
		}

		if strings.HasPrefix(fileInfo.name, ".") {
			continue
		}

		if !strings.HasSuffix(fileInfo.path, ".sy") {
			continue
		}

		id := strings.TrimSuffix(fileInfo.name, ".sy")
		if !ast.IsNodeIDPattern(id) {
			continue
		}

		absPath := filepath.Join(util.DataDir, box.ID, fileInfo.path)
		info, err := os.Stat(absPath)
		if err != nil {
			logging.LogErrorf("stat [%s] failed: %s", absPath, err)
			continue
		}

		if id != box.ID {
			ret.DocCount++
		}
		ret.Size += uint64(info.Size())
		docModT := info.ModTime()
		if docModT.After(docLatestModTime) {
			docLatestModTime = docModT
		}
	}

	ret.HSize = humanize.BytesCustomCeil(ret.Size, 2)
	ret.Mtime = docLatestModTime.Unix()
	ret.HMtime = docLatestModTime.Format("2006-01-02 15:04:05") + ", " + util.HumanizeTime(docLatestModTime, Conf.Lang)
	return
}

func isSkipFile(filename string) bool {
	return strings.HasPrefix(filename, ".") || "node_modules" == filename || "dist" == filename || "target" == filename
}

func moveTree(tree *parse.Tree) {
	treenode.SetBlockTreePath(tree)
	sql.MoveTreeQueue(tree)

	box := Conf.Box(tree.Box)
	subFiles := box.ListFiles(tree.Path)
	luteEngine := util.NewLute()
	for _, subFile := range subFiles {
		if !strings.HasSuffix(subFile.path, ".sy") {
			continue
		}

		subTree, err := filesys.LoadTree(box.ID, subFile.path, luteEngine) // LoadTree 会重新构造 HPath
		if err != nil {
			continue
		}

		treenode.SetBlockTreePath(subTree)
		sql.MoveTreeQueue(subTree)
		msg := fmt.Sprintf(Conf.Language(107), html.EscapeString(subTree.HPath))
		util.PushStatusBar(msg)
	}

	refreshDocInfoWithoutParent(tree)
}

func parseKTree(kramdown []byte) (ret *parse.Tree) {
	luteEngine := NewLute()
	ret = parse.Parse("", kramdown, luteEngine.ParseOptions)
	normalizeTree(ret)
	return
}

func normalizeTree(tree *parse.Tree) (yfmRootID, yfmTitle, yfmUpdated string) {
	if nil == tree.Root.FirstChild {
		tree.Root.AppendChild(treenode.NewParagraph(""))
	} else if !tree.Root.FirstChild.IsBlock() || ast.NodeKramdownBlockIAL == tree.Root.FirstChild.Type {
		tree.Root.PrependChild(treenode.NewParagraph(""))
	}

	var unlinks []*ast.Node
	ast.Walk(tree.Root, func(n *ast.Node, entering bool) ast.WalkStatus {
		if !entering {
			return ast.WalkContinue
		}

		if n.IsEmptyBlockIAL() {
			// 空段落保留
			p := &ast.Node{Type: ast.NodeParagraph}
			p.KramdownIAL = parse.Tokens2IAL(n.Tokens)
			p.ID = p.IALAttr("id")
			n.InsertBefore(p)
			return ast.WalkContinue
		}

		id := n.IALAttr("id")
		if "" == id && n.IsBlock() {
			n.SetIALAttr("id", n.ID)
		}

		if "" == n.IALAttr("id") && (ast.NodeParagraph == n.Type || ast.NodeList == n.Type || ast.NodeListItem == n.Type || ast.NodeBlockquote == n.Type ||
			ast.NodeMathBlock == n.Type || ast.NodeCodeBlock == n.Type || ast.NodeHeading == n.Type || ast.NodeTable == n.Type || ast.NodeThematicBreak == n.Type ||
			ast.NodeYamlFrontMatter == n.Type || ast.NodeBlockQueryEmbed == n.Type || ast.NodeSuperBlock == n.Type || ast.NodeAttributeView == n.Type ||
			ast.NodeHTMLBlock == n.Type || ast.NodeIFrame == n.Type || ast.NodeWidget == n.Type || ast.NodeAudio == n.Type || ast.NodeVideo == n.Type || ast.NodeCallout == n.Type) {
			n.ID = ast.NewNodeID()
			n.KramdownIAL = [][]string{{"id", n.ID}}
			n.InsertAfter(&ast.Node{Type: ast.NodeKramdownBlockIAL, Tokens: []byte("{: id=\"" + n.ID + "\"}")})
			n.SetIALAttr("updated", util.TimeFromID(n.ID))
		}
		if "" == n.ID && 0 < len(n.KramdownIAL) && ast.NodeDocument != n.Type {
			n.ID = n.IALAttr("id")
		}

		if ast.NodeHTMLBlock == n.Type {
			tokens := bytes.TrimSpace(n.Tokens)
			if !bytes.HasPrefix(tokens, []byte("<div>")) {
				tokens = []byte("<div>\n" + string(tokens))
			}
			if !bytes.HasSuffix(tokens, []byte("</div>")) {
				tokens = append(tokens, []byte("\n</div>")...)
			}
			n.Tokens = tokens
			return ast.WalkContinue
		}

		if ast.NodeInlineHTML == n.Type {
			n.Type = ast.NodeText
			return ast.WalkContinue
		}

		if ast.NodeParagraph == n.Type && nil != n.FirstChild && ast.NodeTaskListItemMarker == n.FirstChild.Type {
			// 踢掉任务列表的第一个子节点左侧空格
			n.FirstChild.Next.Tokens = bytes.TrimLeft(n.FirstChild.Next.Tokens, " ")
			// 调整 li.p.tlim 为 li.tlim.p
			n.InsertBefore(n.FirstChild)
		}

		if ast.NodeLinkTitle == n.Type {
			// 避免重复转义图片标题内容 Repeat the escaped content of the image title https://github.com/siyuan-note/siyuan/issues/11681
			n.Tokens = html.UnescapeBytes(n.Tokens)
		}

		if ast.NodeYamlFrontMatterContent == n.Type {
			// Parsing YAML Front Matter as document custom attributes when importing Markdown files https://github.com/siyuan-note/siyuan/issues/10878
			attrs := map[string]any{}
			parseErr := yaml.Unmarshal(n.Tokens, &attrs)
			if parseErr != nil {
				logging.LogWarnf("parse YAML front matter [%s] failed: %s", n.Tokens, parseErr)
				return ast.WalkContinue
			}

			for attrK, attrV := range attrs {
				// Improve parsing of YAML Front Matter when importing Markdown https://github.com/siyuan-note/siyuan/issues/12962
				if "title" == attrK {
					yfmTitle = fmt.Sprint(attrV)
					tree.Root.SetIALAttr("title", yfmTitle)
					continue
				}
				if "date" == attrK {
					created, parseTimeErr := dateparse.ParseIn(fmt.Sprint(attrV), time.Local)
					if nil == parseTimeErr {
						yfmRootID = created.Format("20060102150405") + "-" + gulu.Rand.String(7)
						tree.Root.ID = yfmRootID
						tree.Root.SetIALAttr("id", yfmRootID)
					}
					continue
				}
				if "lastmod" == attrK {
					updated, parseTimeErr := dateparse.ParseIn(fmt.Sprint(attrV), time.Local)
					if nil == parseTimeErr {
						yfmUpdated = updated.Format("20060102150405")
						tree.Root.SetIALAttr("updated", yfmUpdated)
					}
					continue
				}
				if "tags" == attrK && nil != attrV {
					var tags string
					if str, ok := attrV.(string); ok {
						tags = strings.TrimSpace(str)
						tree.Root.SetIALAttr("tags", tags)
						continue
					}

					for _, tag := range attrV.([]any) {
						tagStr := fmt.Sprintf("%v", tag)
						if "" == tag {
							continue
						}
						tagStr = strings.TrimLeft(tagStr, "#,'\"")
						tagStr = strings.TrimRight(tagStr, "#,'\"")
						tags += tagStr + ","
					}
					tags = strings.TrimRight(tags, ",")
					tags = strings.TrimSpace(tags)
					if "" != tags {
						tree.Root.SetIALAttr("tags", tags)
					}
					continue
				}

				validKeyName := true
				for i := 0; i < len(attrK); i++ {
					if !lex.IsASCIILetterNumHyphen(attrK[i]) {
						validKeyName = false
						break
					}
				}
				if !validKeyName {
					logging.LogWarnf("invalid YAML key [%s] in [%s]", attrK, n.ID)
					continue
				}

				tree.Root.SetIALAttr("custom-"+attrK, fmt.Sprint(attrV))
			}

			// Import the YAML at the beginning of the Markdown as a code block https://github.com/siyuan-note/siyuan/issues/16488
			codeBlock := &ast.Node{Type: ast.NodeCodeBlock, ID: ast.NewNodeID()}
			codeBlock.SetIALAttr("id", codeBlock.ID)
			codeBlock.SetIALAttr("updated", codeBlock.ID[:14])
			openMarker := &ast.Node{Type: ast.NodeCodeBlockFenceOpenMarker, Tokens: []byte("```"), CodeBlockFenceLen: 3}
			codeBlock.AppendChild(openMarker)
			info := &ast.Node{Type: ast.NodeCodeBlockFenceInfoMarker, CodeBlockInfo: []byte("yaml")}
			codeBlock.AppendChild(info)
			content := []byte("---\n")
			content = append(content, n.Tokens...)
			content = append(content, []byte("\n---")...)
			code := &ast.Node{Type: ast.NodeCodeBlockCode, Tokens: content}
			codeBlock.AppendChild(code)
			closeMarker := &ast.Node{Type: ast.NodeCodeBlockFenceCloseMarker, Tokens: []byte("```"), CodeBlockFenceLen: 3}
			codeBlock.AppendChild(closeMarker)
			tree.Root.PrependChild(codeBlock)
		}

		if ast.NodeYamlFrontMatter == n.Type {
			unlinks = append(unlinks, n)
		}

		return ast.WalkContinue
	})
	for _, n := range unlinks {
		n.Unlink()
	}

	rootIAL := parse.Tokens2IAL(tree.Root.LastChild.Tokens)
	for _, kv := range rootIAL {
		tree.Root.SetIALAttr(kv[0], kv[1])
	}
	return
}

func ClearTempFiles() {
	var count int
	var size int64

	msgId := util.PushMsg(Conf.Language(276), 30*1000)
	defer func() {
		msg := fmt.Sprintf(Conf.Language(277), count, humanize.BytesCustomCeil(uint64(size), 2))
		util.PushUpdateMsg(msgId, msg, 7000)
	}()

	clearTempFiles(&count, &size)
}

func clearTempFiles(count *int, size *int64) {
	heif.ClearMemoryCache("")
	for _, name := range []string{
		"assets-cache", "bazaar", "export", "import", "convert", "pandoc", "os", "base64", "install", "thumbnails", "repo", "clipboard",
	} {
		clearTempDir(filepath.Join(util.TempDir, name), count, size)
	}
}

func clearTempDir(dir string, count *int, size *int64) {
	if IsObsidianVaultTaskActive() && sameObsidianPath(dir, filepath.Join(util.TempDir, "import", "obsidian")) {
		return
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}

	for _, entry := range entries {
		entryPath := filepath.Join(dir, entry.Name())
		info, err := os.Stat(entryPath)
		if err != nil {
			continue
		}

		if info.IsDir() {
			clearTempDir(entryPath, count, size)
		} else {
			if err := os.Remove(entryPath); err != nil {
				continue
			}

			*count++
			*size += info.Size()
		}
	}

	if util.IsEmptyDir(dir) {
		os.Remove(dir)
	}
	return
}

func VacuumDataIndex() {
	util.PushEndlessProgress(Conf.language(270))
	defer util.PushClearProgress()

	var oldsyDbSize, newSyDbSize, oldHistoryDbSize, newHistoryDbSize, oldAssetContentDbSize, newAssetContentDbSize int64
	info, _ := os.Stat(util.DBPath)
	if nil != info {
		oldsyDbSize = info.Size()
	}
	info, _ = os.Stat(util.HistoryDBPath)
	if nil != info {
		oldHistoryDbSize = info.Size()
	}
	info, _ = os.Stat(util.AssetContentDBPath)
	if nil != info {
		oldAssetContentDbSize = info.Size()
	}

	sql.Vacuum()

	info, _ = os.Stat(util.DBPath)
	if nil != info {
		newSyDbSize = info.Size()
	}
	info, _ = os.Stat(util.HistoryDBPath)
	if nil != info {
		newHistoryDbSize = info.Size()
	}
	info, _ = os.Stat(util.AssetContentDBPath)
	if nil != info {
		newAssetContentDbSize = info.Size()
	}

	logging.LogInfof("vacuum database [siyuan.db: %s -> %s, history.db: %s -> %s, asset_content.db: %s -> %s]",
		humanize.BytesCustomCeil(uint64(oldsyDbSize), 2), humanize.BytesCustomCeil(uint64(newSyDbSize), 2),
		humanize.BytesCustomCeil(uint64(oldHistoryDbSize), 2), humanize.BytesCustomCeil(uint64(newHistoryDbSize), 2),
		humanize.BytesCustomCeil(uint64(oldAssetContentDbSize), 2), humanize.BytesCustomCeil(uint64(newAssetContentDbSize), 2))

	releaseSize := max((oldsyDbSize-newSyDbSize)+(oldHistoryDbSize-newHistoryDbSize)+(oldAssetContentDbSize-newAssetContentDbSize), 0)
	msg := fmt.Sprintf(Conf.language(271), humanize.BytesCustomCeil(uint64(releaseSize), 2))
	util.PushMsg(msg, 7000)
}

func FullReindex(needResetScroll bool) {
	util.PushEndlessProgress(Conf.language(35))

	task.AppendTask(task.DatabaseIndexFull, fullReindex)
	task.AppendTask(task.DatabaseIndexRef, IndexRefs)
	go func() {
		sql.FlushQueue()
		ResetVirtualBlockRefCache()
	}()
	task.AppendTaskWithTimeout(task.DatabaseIndexEmbedBlock, 30*time.Second, autoIndexEmbedBlock)
	if needResetScroll {
		task.AppendTask(task.ReloadUI, util.ReloadUIResetScroll)
	} else {
		task.AppendTask(task.ReloadUI, util.ReloadUI)
	}
}

func FullReindexDirect() {
	fullReindex()
}

func ReindexFTS() {
	defer logging.Recover()

	util.PushEndlessProgress(Conf.language(296))
	defer util.PushClearProgress()

	sql.FlushQueue()
	FlushTxQueue()
	if err := sql.RebuildFTSIndex(); err != nil {
		logging.LogErrorf("rebuild fts index failed, falling back to full reindex: %s", err)
		FullReindex(false)
	}
}

func fullReindex() {
	cache.ClearTreeCache()
	cache.ClearDocsIAL()
	cache.ClearBlocksIAL()
	cache.ClearAVCache()

	pushSQLInsertBlocksFTSMsg, pushSQLDeleteBlocksMsg = true, true
	defer func() {
		sql.FlushQueue()
		pushSQLInsertBlocksFTSMsg, pushSQLDeleteBlocksMsg = false, false
	}()

	FlushTxQueue()

	sql.InitDatabase(true)

	sql.IndexIgnoreCached = false
	openedBoxes := Conf.GetOpenedBoxes()
	for _, openedBox := range openedBoxes {
		indexBox(openedBox.ID)
	}
	LoadFlashcards()
	debug.FreeOSMemory()
}

func ChangeBoxSort(boxIDs []string) {
	fileTreeSortLock.Lock()
	defer fileTreeSortLock.Unlock()

	for i, boxID := range boxIDs {
		box := &Box{ID: boxID}
		boxConf := box.GetConf()
		boxConf.Sort = i + 1
		box.SaveConf(boxConf)
	}
	pushNotebookSortChanged()
}

func pushNotebookSortChanged() {
	var notebookIDs []string
	for _, box := range Conf.GetOpenedBoxes() {
		notebookIDs = append(notebookIDs, box.ID)
	}
	util.BroadcastByType("main", "notebookSortChanged", 0, "", map[string]any{
		"notebookIDs": notebookIDs,
	})
}

func SetBoxIcon(boxID, icon string) {
	icon = filterBoxIcon(icon)

	box := &Box{ID: boxID}
	boxConf := box.GetConf()
	oldIcon := boxConf.Icon
	boxConf.Icon = icon
	if err := box.SaveConf(boxConf); err != nil {
		logging.LogErrorf("save box icon [%s] failed: %s", boxID, err)
		return
	}
	if err := setBoxDocIcon(boxID, icon); err != nil {
		logging.LogErrorf("set box document icon [%s] failed: %s", boxID, err)
		return
	}
	if oldIcon != icon {
		pushNotebookIconChanged(boxID, icon)
	}
	IncSync()
}

func filterBoxIcon(icon string) string {
	if filtered, valid := util.FilterIconValue(icon); valid {
		return filtered
	}
	return ""
}

func isNetworkIconURL(icon string) bool {
	return util.IsNetworkIconURL(icon)
}

func (box *Box) UpdateHistoryGenerated() {
	boxLatestHistoryTime[box.ID] = time.Now()
}

func getBoxesByPaths(paths []string) (ret map[string]*Box) {
	ret = map[string]*Box{}
	var ids []string
	for _, p := range paths {
		ids = append(ids, util.GetTreeID(p))
	}

	bts := treenode.GetBlockTrees(ids)
	for _, id := range ids {
		bt := bts[id]
		if nil != bt {
			ret[bt.Path] = Conf.Box(bt.BoxID)
		}
	}
	return
}

func getBoxesByPathsStrict(paths []string) (ret map[string]*Box, err error) {
	if 1 > len(paths) {
		return nil, ErrBlockNotFound
	}

	var ids []string
	for _, p := range paths {
		id := util.GetTreeID(p)
		if !ast.IsNodeIDPattern(id) {
			return nil, ErrBlockNotFound
		}
		ids = append(ids, id)
	}

	ret = map[string]*Box{}
	bts := treenode.GetBlockTrees(ids)
	for i, id := range ids {
		bt := bts[id]
		if nil == bt || "d" != bt.Type || bt.ID != bt.RootID {
			return nil, ErrBlockNotFound
		}

		box := Conf.Box(bt.BoxID)
		if nil == box {
			return nil, ErrBoxNotFound
		}

		p := filepath.ToSlash(paths[i])
		if !strings.HasPrefix(p, "/") {
			p = "/" + p
		}
		if _, validateErr := filesys.ValidateBoxRelativePath(bt.BoxID, p); validateErr != nil {
			return nil, ErrBlockNotFound
		}
		p = normalizeBoxDocPath(bt.BoxID, path.Clean(p))
		if p != path.Clean(bt.Path) {
			return nil, ErrBlockNotFound
		}
		ret[bt.Path] = box
	}
	return
}
