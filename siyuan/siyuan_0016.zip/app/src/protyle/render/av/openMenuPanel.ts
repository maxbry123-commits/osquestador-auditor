import {transaction} from "../../wysiwyg/transaction";
import {fetchPost} from "../../../util/fetch";
import {
    addCol,
    bindEditEvent,
    duplicateCol,
    getColIconByType,
    getColId,
    getColNameByType,
    getEditHTML,
    removeCol
} from "./col";
import {setPosition} from "../../../util/setPosition";
import {hasClosestByAttribute, hasClosestByClassName} from "../../util/hasClosest";
import {addColOptionOrCell, bindSelectEvent, getSelectHTML, removeCellOption, setColOption} from "./select";
import {
    addFilter,
    addFilterGroup,
    bindInlineFilterEvents,
    convertFilterToGroup,
    convertGroupToFilter,
    duplicateFilterByPath,
    getDefaultOperatorByType,
    getEditableFilters,
    getFilterByPath,
    getFiltersHTML,
    hasFilterForColumn,
    removeFilterByPath,
    removeFiltersByColumn,
    prepareFilterColumns
} from "./filter";
import {genCellValue, updateCellsValue} from "./cell";
import {addSort, bindSortsEvent, getSortsHTML} from "./sort";
import {bindDateEvent, getDateHTML} from "./date";
import {formatNumber} from "./number";
import {formatDate} from "./dateFormatMenu";
import {updateAttrViewCellAnimation} from "./action";
import {addAssetLink, bindAssetEvent, editAssetItem, getAssetHTML, updateAssetCell} from "./asset";
import {Constants} from "../../../constants";
import {hideElements} from "../../ui/hideElements";
import {getAssetExtension} from "../../../util/pathName";
import {isBrowserRenderableImagePath} from "../../../util/imageURL";
import {openEmojiPanel, unicode2Emoji} from "../../../emoji";
import {isMobile} from "../../../util/functions";
import {openLink} from "../../../editor/openLink";
import {previewAttrViewImages} from "../../preview/image";
import {assetMenu} from "../../../menus/protyle";
import {
    addView,
    bindSwitcherEvent,
    bindViewEvent,
    getFieldsByData,
    getSwitcherHTML,
    getViewHTML,
    openViewMenu,
    setAVBlockVisibleViewIDs
} from "./view";
import {focusBlock} from "../../util/selection";
import {getFieldIdByCellElement, setPageSize} from "./row";
import {getAVVisibleViewIDs, getAVVisibleViewIDsAfterHidingAll} from "./viewVisibility";
import {bindRelationEvent, getRelationHTML, openSearchAV, setRelationCell, updateRelation} from "./relation";
import {bindRollupData, getRollupHTML, goSearchRollupCol} from "./rollup";
import {openCalcMenu} from "./calc";
import {escapeAttr, escapeHtml} from "../../../util/escape";
import {Dialog} from "../../../dialog";
import {Menu} from "../../../plugin/Menu";
import {bindLayoutEvent, getLayoutHTML, updateLayout} from "./layout";
import {setGalleryCover, setGalleryRatio, setGallerySize} from "./gallery/util";
import {
    bindGroupsEvent,
    bindGroupsNumber,
    getGroupsHTML,
    getGroupsMethodHTML,
    getGroupsNumberHTML,
    getLanguageByIndex,
    getPageSize,
    goGroupsDate,
    goGroupsSort,
    setGroupMethod
} from "./groups";
import {openFieldVisibilityPanel} from "./fieldVisibility";
import {clearSelect} from "../../util/clear";

export const openMenuPanel = (options: {
    protyle: IProtyle,
    blockElement: Element,
    type: "select" | "properties" | "config" | "sorts" | "filters" | "edit" | "date" | "asset" | "switcher" | "relation" | "rollup",
    colId?: string, // for edit, rollup
    // 使用前端构造的数据
    editData?: {
        previousID: string,
        colData: IAVColumn,
    },
    cellElements?: HTMLElement[],   // for select & date & relation & asset
    // 复用调用方已构造好的视图数据，跳过内部 fetch，避免与刚提交的事务产生读写时序竞争
    data?: IAV,
    cb?: (avPanelElement: Element) => void,
    destroyCallback?: () => void,
    keepMenuOpen?: boolean,
    filterOperation?: IAVFilterOperation,
    requireExplicitChange?: boolean,
}) => {
    let avPanelElement = document.querySelector(".av__panel");
    if (avPanelElement) {
        avPanelElement.remove();
        options.destroyCallback?.();
        return;
    }
    const avID = options.blockElement.getAttribute("data-av-id");
    const avPageSize = getPageSize(options.blockElement);
    // config/properties/sorts/filters/switcher 菜单只需要字段/视图元数据，不需要行数据，跳过行渲染以提升大体量视图下的响应速度
    const ignoreRows = ["config", "properties", "sorts", "filters", "switcher"].includes(options.type);
    const fetchPayload = {
        id: avID,
        query: options.blockElement.querySelector('[data-type="av-search"]')?.textContent.trim() || "",
        pageSize: avPageSize.unGroupPageSize,
        groupPaging: avPageSize.groupPageSize,
        blockID: options.blockElement.getAttribute("data-node-id"),
        ignoreRows,
    };
    // 接收视图数据并构建面板 DOM、绑定事件。fetch 回调与 options.data 复用两条路径都走这里
    const renderData = async (responseData: IAV) => {
        const response = {data: responseData} as IWebSocketData;
        avPanelElement = document.querySelector(".av__panel");
        if (avPanelElement) {
            avPanelElement.remove();
            return;
        }
        if (!options.keepMenuOpen) {
            window.siyuan.menus.menu.remove();
        }
        const blockID = options.blockElement.getAttribute("data-node-id");
        const saveFilters = (newFilters: IAVFilter[], oldFilters: IAVFilter[]) => {
            const operation = (filters: IAVFilter[]): IOperation => ({
                action: options.filterOperation?.action || "setAttrViewFilters",
                avID,
                keyID: options.filterOperation?.keyID,
                data: filters,
                blockID,
            });
            transaction(options.protyle, [operation(newFilters)], [operation(oldFilters)]);
        };

        const isCustomAttr = !options.blockElement.classList.contains("av");
        let data = response.data as IAV;
        if (options.type === "filters") {
            await prepareFilterColumns(data);
        }
        let html;
        let fields = getFieldsByData(data);
        if (options.type === "config") {
            html = getViewHTML(data);
        } else if (options.type === "properties") {
            html = getPropertiesHTML(fields, data.viewType);
        } else if (options.type === "sorts") {
            html = getSortsHTML(fields, data.view.sorts);
        } else if (options.type === "switcher") {
            html = getSwitcherHTML(data.views, data.viewID, options.blockElement);
        } else if (options.type === "filters") {
            html = getFiltersHTML(data);
        } else if (options.type === "select") {
            html = getSelectHTML(fields, options.cellElements, true, options.blockElement);
        } else if (options.type === "asset") {
            html = getAssetHTML(options.cellElements);
        } else if (options.type === "edit") {
            if (options.editData) {
                if (typeof options.editData.colData.wrap === "undefined") {
                    options.editData.colData.wrap = data.view.wrapField;
                }
                if (options.editData.previousID) {
                    fields.find((item, index) => {
                        if (item.id === options.editData.previousID) {
                            fields.splice(index + 1, 0, options.editData.colData);
                            return true;
                        }
                    });
                } else {
                    if (data.viewType === "table") {
                        fields.splice(0, 0, options.editData.colData);
                    } else {
                        fields.push(options.editData.colData);
                    }
                }
            }
            html = getEditHTML({protyle: options.protyle, data, colId: options.colId, isCustomAttr});
        } else if (options.type === "date") {
            html = getDateHTML(options.cellElements);
        } else if (options.type === "rollup") {
            html = `<div class="b3-menu__items">${getRollupHTML({data, cellElements: options.cellElements})}</div>`;
        } else if (options.type === "relation") {
            html = getRelationHTML(data, options.cellElements);
            if (!html) {
                openMenuPanel({
                    protyle: options.protyle,
                    blockElement: options.blockElement,
                    type: "edit",
                    colId: getColId(options.cellElements[0], data.viewType)
                });
                return;
            }
        }

        document.body.insertAdjacentHTML("beforeend", `<div class="av__panel" style="z-index: ${++window.siyuan.zIndex};">
    <div class="b3-dialog__scrim" data-type="close"></div>
    <div class="b3-menu${options.type === "filters" ? " av__filter-panel" : ""}${options.type === "relation" ? " av__relation-panel" : ""}" ${options.keepMenuOpen ? "data-menu=\"true\"" : ""} ${["select", "date", "asset", "relation", "rollup"].includes(options.type) ? `style="${["select", "asset", "relation"].includes(options.type) ? "max-height: calc(100vh - 32px);display: flex;flex-direction: column;" : ""}min-width: 200px;${options.type === "relation" ? `width: 760px;max-width: ${isMobile() ? "90vw" : "calc(100vw - 32px)"};` : isMobile() ? "max-width: 90vw;" : "max-width: 50vw;"}"` : ""}>${html}</div>
</div>`);
        avPanelElement = document.querySelector(".av__panel");
        if (options.destroyCallback) {
            const renderedPanelElement = avPanelElement;
            const parentElement = renderedPanelElement.parentElement;
            const observer = new MutationObserver(() => {
                if (!renderedPanelElement.isConnected) {
                    observer.disconnect();
                    options.destroyCallback();
                }
            });
            observer.observe(parentElement, {childList: true});
        }
        let closeCB: () => void;
        const menuElement = avPanelElement.lastElementChild as HTMLElement;
        const rerenderSwitcher = () => {
            const keyword = (menuElement.querySelector(".b3-text-field") as HTMLInputElement)?.value || "";
            menuElement.innerHTML = getSwitcherHTML(data.views, data.viewID, options.blockElement);
            bindSwitcherEvent({
                protyle: options.protyle,
                menuElement,
                blockElement: options.blockElement
            });
            if (keyword) {
                const inputElement = menuElement.querySelector(".b3-text-field") as HTMLInputElement;
                inputElement.value = keyword;
                inputElement.dispatchEvent(new Event("input"));
            }
        };
        let tabRect = options.blockElement.querySelector(`.av__views, .av__row[data-col-id="${options.colId}"] > .block__logo`)?.getBoundingClientRect();
        if (["select", "date", "asset", "relation", "rollup"].includes(options.type)) {
            let lastElement = options.cellElements[options.cellElements.length - 1];
            if (!options.blockElement.contains(lastElement)) {
                // https://github.com/siyuan-note/siyuan/issues/15839
                const rowID = getFieldIdByCellElement(lastElement, data.viewType);
                if (data.viewType === "table") {
                    lastElement = options.blockElement.querySelector(`.av__row[data-id="${rowID}"] .av__cell[data-col-id="${lastElement.dataset.colId}"]`);
                } else {
                    lastElement = options.blockElement.querySelector(`.av__gallery-item[data-id="${rowID}"] .av__cell[data-field-id="${lastElement.dataset.fieldId}"]`);
                }
            }
            const cellRect = (lastElement || options.cellElements[options.cellElements.length - 1]).getBoundingClientRect();

            if (options.type === "select") {
                bindSelectEvent(options.protyle, data, menuElement, options.cellElements, options.blockElement);
            } else if (options.type === "date") {
                closeCB = bindDateEvent({
                    protyle: options.protyle,
                    data,
                    menuElement,
                    cellElements: options.cellElements,
                    blockElement: options.blockElement,
                    requireExplicitChange: options.requireExplicitChange,
                });
            } else if (options.type === "asset") {
                bindAssetEvent({
                    protyle: options.protyle,
                    menuElement,
                    cellElements: options.cellElements,
                    blockElement: options.blockElement
                });
                setTimeout(() => {
                    setPosition(menuElement, cellRect.left, cellRect.bottom, cellRect.height, 0, true);
                }, Constants.TIMEOUT_LOAD);  // 等待加载
            } else if (options.type === "relation") {
                closeCB = bindRelationEvent({
                    menuElement,
                    cellElements: options.cellElements,
                    protyle: options.protyle,
                    blockElement: options.blockElement
                });
            } else if (options.type === "rollup") {
                bindRollupData({protyle: options.protyle, data, menuElement});
            }
            if (["select", "date", "relation", "rollup"].includes(options.type)) {
                const inputElement = menuElement.querySelector("input");
                if (inputElement) {
                    inputElement.select();
                    inputElement.focus();
                }
                setPosition(menuElement, cellRect.left, cellRect.bottom, cellRect.height, 0, true);
            }
        } else {
            setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
            if (options.type === "sorts") {
                bindSortsEvent(options.protyle, menuElement, data, blockID);
            } else if (options.type === "filters") {
                bindInlineFilterEvents(avPanelElement as HTMLElement, data, options.protyle, blockID, avID,
                    options.filterOperation);
            } else if (options.type === "edit") {
                bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
            } else if (options.type === "config") {
                bindViewEvent({protyle: options.protyle, data, menuElement, blockElement: options.blockElement});
            } else if (options.type === "switcher") {
                bindSwitcherEvent({protyle: options.protyle, menuElement, blockElement: options.blockElement});
            }
        }
        if (options.cb) {
            options.cb(avPanelElement);
        }
        let counter = 0;
        avPanelElement.addEventListener("dragstart", (event: DragEvent) => {
            window.siyuan.dragElement = event.target as HTMLElement;
            if (window.siyuan.dragElement.dataset.relationType === "selected") {
                const primaryElement = window.siyuan.dragElement.querySelector(".av__relation-table-primary");
                if (primaryElement) {
                    const ghostElement = primaryElement.cloneNode(true) as HTMLElement;
                    ghostElement.className = "av__relation-drag-ghost";
                    ghostElement.removeAttribute("style");
                    ghostElement.querySelector(".av__relation-row-open")?.remove();
                    document.body.append(ghostElement);
                    event.dataTransfer.setDragImage(ghostElement, 16, 17);
                    setTimeout(() => {
                        ghostElement.remove();
                    });
                }
            }
            window.siyuan.dragElement.style.opacity = ".38";
            return;
        });
        avPanelElement.addEventListener("drop", (event) => {
            counter = 0;
            if (!window.siyuan.dragElement) {
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            window.siyuan.dragElement.style.opacity = "";
            const sourceElement = window.siyuan.dragElement;
            window.siyuan.dragElement = undefined;
            if (options.protyle && options.protyle.disabled) {
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            if (!options.protyle && window.siyuan.config.readonly) {
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            const targetElement = avPanelElement.querySelector(".dragover__bottom, .dragover__top") as HTMLElement;
            if (!targetElement) {
                return;
            }
            const isTop = targetElement.classList.contains("dragover__top");
            const sourceId = sourceElement.dataset.id;
            const targetId = targetElement.dataset.id;
            // 排序条件拖拽排序
            if (targetElement.querySelector('[data-type="removeSort"]')) {
                const changeData = data.view.sorts;
                const oldData = Object.assign([], changeData);
                let sortFilter: IAVSort;
                changeData.find((sort, index: number) => {
                    if (sort.column === sourceId) {
                        sortFilter = changeData.splice(index, 1)[0];
                        return true;
                    }
                });
                changeData.find((sort, index: number) => {
                    if (sort.column === targetId) {
                        if (isTop) {
                            changeData.splice(index, 0, sortFilter);
                        } else {
                            changeData.splice(index + 1, 0, sortFilter);
                        }
                        return true;
                    }
                });
                transaction(options.protyle, [{
                    action: "setAttrViewSorts",
                    avID,
                    data: changeData,
                    blockID
                }], [{
                    action: "setAttrViewSorts",
                    avID,
                    data: oldData,
                    blockID
                }]);
                menuElement.innerHTML = getSortsHTML(fields, data.view.sorts);
                bindSortsEvent(options.protyle, menuElement, data, blockID);
                return;
            }
            // 视图切换拖拽排序
            if (targetElement.querySelector('[data-type="av-view-edit"]')) {
                transaction(options.protyle, [{
                    action: "sortAttrViewView",
                    avID,
                    blockID,
                    id: sourceId,
                    previousID: isTop ? targetElement.previousElementSibling?.getAttribute("data-id") : targetElement.getAttribute("data-id")
                }], [{
                    action: "sortAttrViewView",
                    avID,
                    blockID,
                    id: sourceId,
                    previousID: sourceElement.previousElementSibling?.getAttribute("data-id")
                }]);
                if (isTop) {
                    targetElement.before(sourceElement);
                    targetElement.classList.remove("dragover__top");
                } else {
                    targetElement.after(sourceElement);
                    targetElement.classList.remove("dragover__bottom");
                }
                return;
            }
            // 资源拖拽排序
            if (targetElement.querySelector('[data-type="editAssetItem"]')) {
                if (isTop) {
                    targetElement.before(sourceElement);
                } else {
                    targetElement.after(sourceElement);
                }
                const replaceValue: IAVCellAssetValue[] = [];
                Array.from(targetElement.parentElement.children).forEach((item: HTMLElement) => {
                    if (["image", "file"].includes(item.dataset.type)) {
                        replaceValue.push({
                            content: item.dataset.content,
                            name: item.dataset.name,
                            type: item.dataset.type as "image" | "file",
                        });
                    }
                });
                updateAssetCell({
                    protyle: options.protyle,
                    cellElements: options.cellElements,
                    replaceValue,
                    blockElement: options.blockElement
                });
                return;
            }
            // 选项拖拽排序
            if (targetElement.querySelector('[data-type="setColOption"]')) {
                const colId = options.cellElements ? getColId(options.cellElements[0], data.viewType) : menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                const changeData = fields.find((column) => column.id === colId).options;
                const oldData = Object.assign([], changeData);
                let targetOption: { name: string, color: string };
                changeData.find((option, index: number) => {
                    if (option.name === sourceElement.dataset.name) {
                        targetOption = changeData.splice(index, 1)[0];
                        return true;
                    }
                });
                changeData.find((option, index: number) => {
                    if (option.name === targetElement.dataset.name) {
                        if (isTop) {
                            changeData.splice(index, 0, targetOption);
                        } else {
                            changeData.splice(index + 1, 0, targetOption);
                        }
                        return true;
                    }
                });
                transaction(options.protyle, [{
                    action: "updateAttrViewColOptions",
                    id: colId,
                    avID,
                    data: changeData,
                }], [{
                    action: "updateAttrViewColOptions",
                    id: colId,
                    avID,
                    data: oldData,
                }]);
                const oldScroll = menuElement.querySelector(".b3-menu__items").scrollTop;
                if (options.cellElements) {
                    menuElement.innerHTML = getSelectHTML(fields, options.cellElements, false, options.blockElement);
                    bindSelectEvent(options.protyle, data, menuElement, options.cellElements, options.blockElement);
                } else {
                    menuElement.innerHTML = getEditHTML({
                        protyle: options.protyle,
                        data,
                        colId,
                        isCustomAttr
                    });
                    bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
                }
                menuElement.querySelector(".b3-menu__items").scrollTop = oldScroll;
                return;
            }
            // 关联列拖拽排序
            if (targetElement.getAttribute("data-type") === "setRelationCell") {
                if (targetElement.dataset.relationType !== "selected") {
                    targetElement.classList.remove("dragover__bottom", "dragover__top");
                    return;
                }
                if (isTop) {
                    targetElement.before(sourceElement);
                } else {
                    targetElement.after(sourceElement);
                }
                targetElement.classList.remove("dragover__bottom", "dragover__top");
                const blockIDs: string[] = [];
                const contents: IAVCellValue[] = [];
                targetElement.parentElement.querySelectorAll(".fn__grab").forEach(item => {
                    const dateElement = item.nextElementSibling as HTMLElement;
                    blockIDs.push(dateElement.parentElement.dataset.rowId);
                    contents.push({
                        isDetached: !dateElement.style.color,
                        type: "block",
                        block: {
                            content: dateElement.textContent,
                            id: dateElement.dataset.id
                        }
                    });
                });
                updateCellsValue(options.protyle, options.blockElement as HTMLElement, {
                    blockIDs,
                    contents,
                }, options.cellElements);
                return;
            }
            // 字段列表拖拽排序
            if (targetElement.getAttribute("data-type") === "editCol") {
                const previousID = (isTop ? targetElement.previousElementSibling?.getAttribute("data-id") : targetElement.getAttribute("data-id")) || "";
                const undoPreviousID = sourceElement.previousElementSibling?.getAttribute("data-id") || "";
                if (previousID !== undoPreviousID && previousID !== sourceId) {
                    transaction(options.protyle, [{
                        action: "sortAttrViewCol",
                        avID,
                        previousID,
                        id: sourceId,
                        blockID,
                    }], [{
                        action: "sortAttrViewCol",
                        avID,
                        previousID: undoPreviousID,
                        id: sourceId,
                        blockID
                    }]);
                    let column: IAVColumn;
                    fields.find((item, index: number) => {
                        if (item.id === sourceId) {
                            column = fields.splice(index, 1)[0];
                            return true;
                        }
                    });
                    fields.find((item, index: number) => {
                        if (item.id === targetId) {
                            if (isTop) {
                                fields.splice(index, 0, column);
                            } else {
                                fields.splice(index + 1, 0, column);
                            }
                            return true;
                        }
                    });
                }
                menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                return;
            }
            // 分组项拖拽排序
            if (targetElement.querySelector('[data-type="hideGroup"]')) {
                const previousID = (isTop ? targetElement.previousElementSibling?.getAttribute("data-id") : targetElement.getAttribute("data-id")) || "";
                const undoPreviousID = sourceElement.previousElementSibling?.getAttribute("data-id") || "";
                if (previousID !== undoPreviousID && previousID !== sourceId) {
                    const oldGroup: IAVGroup = {
                        ...data.view.group,
                        range: data.view.group.range ? {...data.view.group.range} : undefined,
                    };
                    const undoOperations: IOperation[] = oldGroup.order === 2 ? [{
                        action: "sortAttrViewGroup",
                        avID,
                        blockID,
                        previousID: undoPreviousID,
                        id: sourceId,
                    }] : [{
                        action: "setAttrViewGroup",
                        avID,
                        blockID,
                        data: oldGroup,
                    }];
                    transaction(options.protyle, [{
                        action: "sortAttrViewGroup",
                        avID,
                        blockID,
                        previousID,
                        id: sourceId,
                    }], undoOperations);
                    menuElement.querySelector('[data-type="goGroupsSort"] .b3-menu__accelerator').textContent = getLanguageByIndex(2, "sort");
                    data.view.group.order = 2;
                    data.view.groups.find((group, index) => {
                        if (group.id === sourceId) {
                            const groupData = data.view.groups.splice(index, 1)[0];
                            data.view.groups.find((item, index: number) => {
                                if (item.id === targetId) {
                                    if (isTop) {
                                        data.view.groups.splice(index, 0, groupData);
                                    } else {
                                        data.view.groups.splice(index + 1, 0, groupData);
                                    }
                                    return true;
                                }
                            });
                            return true;
                        }
                    });
                    if (isTop) {
                        targetElement.before(sourceElement);
                    } else {
                        targetElement.after(sourceElement);
                    }
                }
                targetElement.classList.remove("dragover__top", "dragover__bottom");
                return;
            }
        });
        let dragoverElement: HTMLElement;
        avPanelElement.addEventListener("dragover", (event: DragEvent) => {
            if (event.dataTransfer.types.includes("Files")) {
                event.preventDefault();
                return;
            }
            const target = event.target as HTMLElement;
            let targetElement = hasClosestByAttribute(target, "draggable", "true");
            if (!targetElement) {
                targetElement = hasClosestByAttribute(document.elementFromPoint(event.clientX, event.clientY - 1), "draggable", "true");
            }
            if (!targetElement || targetElement === window.siyuan.dragElement) {
                return;
            }
            event.preventDefault();
            if (dragoverElement && targetElement === dragoverElement) {
                const nodeRect = targetElement.getBoundingClientRect();
                avPanelElement.querySelectorAll(".dragover__bottom, .dragover__top").forEach((item: HTMLElement) => {
                    item.classList.remove("dragover__bottom", "dragover__top");
                });
                if (event.clientY > nodeRect.top + nodeRect.height / 2) {
                    targetElement.classList.add("dragover__bottom");
                } else {
                    targetElement.classList.add("dragover__top");
                }
                return;
            }
            dragoverElement = targetElement;
        });
        avPanelElement.addEventListener("dragleave", () => {
            counter--;
            if (counter === 0) {
                avPanelElement.querySelectorAll(".dragover__bottom, .dragover__top").forEach((item: HTMLElement) => {
                    item.classList.remove("dragover__bottom", "dragover__top");
                });
            }
        });
        avPanelElement.addEventListener("dragenter", (event) => {
            event.preventDefault();
            counter++;
        });
        avPanelElement.addEventListener("dragend", () => {
            if (window.siyuan.dragElement) {
                window.siyuan.dragElement.style.opacity = "";
                window.siyuan.dragElement = undefined;
            }
        });
        // 过滤分组 AND/OR 切换（select 的 change 事件，不走 click 分发）
        avPanelElement.addEventListener("change", (event: Event) => {
            const select = event.target as HTMLElement;
            if (select.dataset.type !== "toggleCombination") {
                return;
            }
            const path = select.dataset.path;
            const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
            const node = "" === path
                ? (data.view.filters[0] && (data.view.filters[0].filters || data.view.filters[0].combination) ? data.view.filters[0] : undefined)
                : getFilterByPath(getEditableFilters(data), path);
            if (node) {
                node.combination = (select as HTMLSelectElement).value === "or" ? "or" : "and";
            }
            saveFilters(JSON.parse(JSON.stringify(data.view.filters)), oldFilters);
            // 重渲染以同步所有只读且/或标签（index >= 2 的节点显示的是只读 span）
            menuElement.innerHTML = getFiltersHTML(data);
            bindInlineFilterEvents(avPanelElement as HTMLElement, data, options.protyle, blockID, avID,
                options.filterOperation);
            setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
            event.stopPropagation();
        });
        let suppressSelectClick = false;
        // 多选排序
        avPanelElement.addEventListener("mousedown", (event: MouseEvent & { target: HTMLElement }) => {
            if (event.button === 1 && !hasClosestByClassName(event.target, "b3-menu")) {
                document.querySelector(".av__panel").dispatchEvent(new CustomEvent("click", {detail: "close"}));
            }
            if (event.button !== 0 || options.type !== "select") return;
            const selectedElement = event.target.closest(".b3-chip--middle") as HTMLElement;
            if (!selectedElement || !selectedElement.parentElement.classList.contains("b3-chips") ||
                event.target.closest('[data-type="removeCellOption"]')) {
                return;
            }
            const colId = getColId(options.cellElements[0], data.viewType);
            const colData = fields.find((item) => item.id === colId);
            if (colData?.type !== "mSelect" ||
                selectedElement.parentElement.querySelectorAll(".b3-chip--middle").length < 2) {
                return;
            }
            event.preventDefault();
            const documentSelf = document;
            documentSelf.ondragstart = () => false;
            let ghostElement: HTMLElement;
            const diffPosition = {x: 0, y: 0};
            const startPosition = {x: event.clientX, y: event.clientY};
            const oldValue = Array.from(selectedElement.parentElement.querySelectorAll(".b3-chip--middle"))
                .map((item: HTMLElement) => item.dataset.content);
            documentSelf.onmousemove = (moveEvent: MouseEvent & { target: HTMLElement }) => {
                moveEvent.preventDefault();
                moveEvent.stopPropagation();
                if (!ghostElement) {
                    if (Math.hypot(moveEvent.clientX - startPosition.x, moveEvent.clientY - startPosition.y) < 5) {
                        return;
                    }
                    ghostElement = selectedElement.cloneNode(true) as HTMLElement;
                    document.body.append(ghostElement);
                    ghostElement.setAttribute("id", "dragGhost");
                    ghostElement.style.pointerEvents = "none";
                    ghostElement.style.position = "fixed";
                    ghostElement.style.zIndex = (window.siyuan.zIndex++).toString();
                    selectedElement.style.opacity = ".38";
                    document.body.style.cursor = "grabbing";
                    const selectedRect = selectedElement.getBoundingClientRect();
                    diffPosition.x = moveEvent.clientX - selectedRect.left;
                    diffPosition.y = moveEvent.clientY - selectedRect.top;
                }
                ghostElement.style.top = (moveEvent.clientY - diffPosition.y) + "px";
                ghostElement.style.left = (moveEvent.clientX - diffPosition.x) + "px";
                const targetElement = moveEvent.target.closest(".b3-chip--middle") as HTMLElement;
                if (targetElement && targetElement !== selectedElement) {
                    const nodeRect = targetElement.getBoundingClientRect();
                    if (moveEvent.clientX > nodeRect.left + nodeRect.width / 2 &&
                        moveEvent.clientX < nodeRect.right + 8) {
                        targetElement.after(selectedElement);
                    } else if (moveEvent.clientX <= nodeRect.left + nodeRect.width / 2 &&
                        moveEvent.clientX > nodeRect.left - 8) {
                        targetElement.before(selectedElement);
                    }
                }
            };

            documentSelf.onmouseup = () => {
                documentSelf.onmousemove = null;
                documentSelf.onmouseup = null;
                documentSelf.ondragstart = null;
                documentSelf.onselectstart = null;
                documentSelf.onselect = null;
                ghostElement?.remove();
                selectedElement.style.opacity = "";
                document.body.style.cursor = "";
                if (!ghostElement) {
                    return;
                }
                const newValue: IAVCellSelectValue[] = [];
                selectedElement.parentElement.querySelectorAll(".b3-chip--middle").forEach((item: HTMLElement) => {
                    newValue.push({content: item.dataset.content, color: item.dataset.valueColor});
                });
                suppressSelectClick = true;
                setTimeout(() => {
                    suppressSelectClick = false;
                });
                if (newValue.some((item, index) => item.content !== oldValue[index])) {
                    updateCellsValue(options.protyle, options.blockElement as HTMLElement, newValue, options.cellElements);
                }
            };
        });
        avPanelElement.addEventListener("click", async (event: MouseEvent) => {
            let type: string;
            let target = event.target as HTMLElement;
            const isProgrammaticClose = typeof event.detail === "string";
            if (typeof event.detail === "string") {
                type = event.detail;
            } else if (typeof event.detail === "object") {
                type = (event.detail as { type: string }).type;
                target = (event.detail as { target: HTMLElement }).target;
            }
            const selectedElement = target?.closest(".b3-chip--middle") as HTMLElement;
            if (options.type === "select" && selectedElement?.parentElement.classList.contains("b3-chips") &&
                !target.closest('[data-type="removeCellOption"]')) {
                if (!suppressSelectClick) {
                    setColOption(options.protyle, data, selectedElement, options.blockElement, isCustomAttr,
                        options.cellElements, options.keepMenuOpen);
                }
                suppressSelectClick = false;
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            while (target && target !== avPanelElement || type) {
                type = target?.dataset.type || type;
                // toggleCombination 由 change 事件处理，click 直接跳过避免空跑
                if (type === "toggleCombination") {
                    break;
                }
                if (type === "close") {
                    if (!options.protyle.toolbar.subElement.classList.contains("fn__none")) {
                        // 优先关闭资源文件搜索
                        hideElements(["util"], options.protyle);
                    } else if (!options.keepMenuOpen &&
                        !window.siyuan.menus.menu.element.classList.contains("fn__none")) {
                        // 过滤面板先关闭过滤条件
                    } else {
                        closeCB?.();
                        avPanelElement.remove();
                        setTimeout(() => {
                            focusBlock(options.blockElement);
                        }, Constants.TIMEOUT_TRANSITION);  // 单选使用 enter 修改选项后会滚动
                    }
                    if (!options.keepMenuOpen || !isProgrammaticClose) {
                        window.siyuan.menus.menu.remove();
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "go-config") {
                    if (options.filterOperation) {
                        avPanelElement.remove();
                        event.preventDefault();
                        event.stopPropagation();
                        break;
                    }
                    menuElement.classList.remove("av__filter-panel");
                    menuElement.innerHTML = getViewHTML(data);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    bindViewEvent({protyle: options.protyle, data, menuElement, blockElement: options.blockElement});
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "go-properties") {
                    // 复制列后点击返回到属性面板，宽度不一致，需重新计算
                    tabRect = options.blockElement.querySelector(".av__views").getBoundingClientRect();
                    menuElement.classList.remove("av__filter-panel");
                    menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "fieldVisibility") {
                    const colId = menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                    openFieldVisibilityPanel({
                        protyle: options.protyle,
                        blockElement: options.blockElement,
                        colId,
                        menuElement,
                        field: fields.find((item) => item.id === colId),
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "go-layout") {
                    menuElement.classList.remove("av__filter-panel");
                    menuElement.innerHTML = getLayoutHTML(data);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    bindLayoutEvent({protyle: options.protyle, data, menuElement, blockElement: options.blockElement});
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goSorts") {
                    menuElement.classList.remove("av__filter-panel");
                    menuElement.innerHTML = getSortsHTML(fields, data.view.sorts);
                    bindSortsEvent(options.protyle, menuElement, data, blockID);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeSorts") {
                    transaction(options.protyle, [{
                        action: "setAttrViewSorts",
                        avID,
                        data: [],
                        blockID
                    }], [{
                        action: "setAttrViewSorts",
                        avID,
                        data: data.view.sorts,
                        blockID
                    }]);
                    data.view.sorts = [];
                    menuElement.innerHTML = getSortsHTML(fields, data.view.sorts);
                    bindSortsEvent(options.protyle, menuElement, data, blockID);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addSort") {
                    addSort({
                        data,
                        rect: target.getBoundingClientRect(),
                        menuElement,
                        tabRect,
                        avId: avID,
                        protyle: options.protyle,
                        blockID,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeSort") {
                    const oldSorts = Object.assign([], data.view.sorts);
                    data.view.sorts.find((item: IAVSort, index: number) => {
                        if (item.column === target.parentElement.dataset.id) {
                            data.view.sorts.splice(index, 1);
                            return true;
                        }
                    });
                    transaction(options.protyle, [{
                        action: "setAttrViewSorts",
                        avID,
                        data: data.view.sorts,
                        blockID
                    }], [{
                        action: "setAttrViewSorts",
                        avID,
                        data: oldSorts,
                        blockID
                    }]);
                    menuElement.innerHTML = getSortsHTML(fields, data.view.sorts);
                    bindSortsEvent(options.protyle, menuElement, data, blockID);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goFilters") {
                    menuElement.innerHTML = getFiltersHTML(data);
                    menuElement.classList.add("av__filter-panel");
                    bindInlineFilterEvents(avPanelElement as HTMLElement, data, options.protyle, blockID, avID,
                        options.filterOperation);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeFilters") {
                    saveFilters([], JSON.parse(JSON.stringify(data.view.filters)));
                    // 本地状态保持“顶层单个空根组”不变量（后端会同样归一化），避免后续 addFilterGroup 误把新分组当成根组
                    data.view.filters = [{combination: "and", filters: []}];
                    menuElement.innerHTML = getFiltersHTML(data);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    window.siyuan.menus.menu.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addFilter") {
                    const path = target.closest("[data-path]")?.getAttribute("data-path") || "";
                    addFilter({
                        data,
                        rect: target.getBoundingClientRect(),
                        menuElement,
                        tabRect,
                        avId: avID,
                        protyle: options.protyle,
                        blockElement: options.blockElement,
                        parentPath: path,
                        filterOperation: options.filterOperation,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addFilterCondition") {
                    const path = target.dataset.path || target.closest("[data-path]")?.getAttribute("data-path") || "";
                    const depth = parseInt(target.dataset.depth || target.closest("[data-depth]")?.getAttribute("data-depth") || "0", 10);
                    const menu = new Menu("addFilterCondition");
                    menu.addItem({
                        icon: "iconAdd",
                        label: window.siyuan.languages.addFilter,
                        click: () => {
                            addFilter({
                                data,
                                rect: {left: event.clientX, bottom: event.clientY, height: 28} as DOMRect,
                                menuElement,
                                tabRect,
                                avId: avID,
                                protyle: options.protyle,
                                blockElement: options.blockElement,
                                parentPath: path,
                                filterOperation: options.filterOperation,
                            });
                        }
                    });
                    if (depth < 3) {
                        menu.addItem({
                            icon: "iconListFilterPlus",
                            label: window.siyuan.languages.addFilterGroup,
                            click: () => {
                                const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
                                addFilterGroup(data, path);
                                const fields = getFieldsByData(data);
                                const blockField = fields.find(f => f.type === "block") || fields.find(f => f.type !== "lineNumber");
                                if (blockField) {
                                    let target: IAVFilter[];
                                    if ("" === path) {
                                        target = getEditableFilters(data);
                                    } else {
                                        const n = getFilterByPath(getEditableFilters(data), path);
                                        target = n?.filters || getEditableFilters(data);
                                        if (!target) {
                                            target = getEditableFilters(data);
                                        }
                                    }
                                    const newGroup = target[target.length - 1];
                                    if (newGroup?.filters) {
                                        newGroup.filters.push({
                                            column: blockField.id,
                                            operator: getDefaultOperatorByType(blockField.type),
                                            value: genCellValue(blockField.type, ""),
                                        });
                                    }
                                }
                                saveFilters(JSON.parse(JSON.stringify(data.view.filters)), oldFilters);
                                menuElement.innerHTML = getFiltersHTML(data);
                                setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                            }
                        });
                    }
                    menu.open({x: event.clientX, y: event.clientY, h: 28});
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "moreFilter") {
                    const path = target.getAttribute("data-path") || target.closest("[data-path]")?.getAttribute("data-path") || "";
                    const node = getFilterByPath(getEditableFilters(data), path);
                    const isGroup = node && node.filters;
                    const menu = new Menu("moreFilter");
                    menu.addItem({
                        icon: "iconAdd",
                        label: window.siyuan.languages.duplicateCopy,
                        click: () => {
                            const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
                            duplicateFilterByPath(getEditableFilters(data), path);
                            saveFilters(JSON.parse(JSON.stringify(data.view.filters)), oldFilters);
                            menuElement.innerHTML = getFiltersHTML(data);
                            setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                        }
                    });
                    if (!isGroup) {
                        menu.addItem({
                            icon: "iconListFilterPlus",
                            label: window.siyuan.languages.convertToFilterGroup,
                            click: () => {
                                const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
                                convertFilterToGroup(getEditableFilters(data), path);
                                saveFilters(JSON.parse(JSON.stringify(data.view.filters)), oldFilters);
                                menuElement.innerHTML = getFiltersHTML(data);
                                setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                            }
                        });
                    } else if (node && node.filters && 1 === node.filters.length) {
                        menu.addItem({
                            icon: "iconListFilterPlus",
                            label: window.siyuan.languages.convertGroupToFilter,
                            click: () => {
                                const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
                                convertGroupToFilter(getEditableFilters(data), path);
                                saveFilters(JSON.parse(JSON.stringify(data.view.filters)), oldFilters);
                                menuElement.innerHTML = getFiltersHTML(data);
                                setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                            }
                        });
                    }
                    menu.addItem({
                        icon: "iconTrashcan",
                        label: window.siyuan.languages.delete,
                        click: () => {
                            const cloneBefore = JSON.parse(JSON.stringify(data.view.filters));
                            removeFilterByPath(getEditableFilters(data), path);
                            const cloneAfter = JSON.parse(JSON.stringify(data.view.filters));
                            saveFilters(cloneAfter, cloneBefore);
                            menuElement.innerHTML = getFiltersHTML(data);
                            setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                        }
                    });
                    menu.open({x: event.clientX, y: event.clientY, h: 28});
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "numberFormat") {
                    formatNumber({
                        avPanelElement,
                        element: target,
                        protyle: options.protyle,
                        oldFormat: target.dataset.format,
                        colId: menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id"),
                        avID
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "dateFormat") {
                    const colId = menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                    const colData = fields.find((item) => item.id === colId);
                    formatDate({
                        avPanelElement,
                        element: target,
                        protyle: options.protyle,
                        oldFormat: target.dataset.format as TAVDateFormat,
                        colId,
                        avID,
                        type: colData.type as "date" | "created" | "updated",
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "newCol") {
                    avPanelElement.remove();
                    const addMenu = addCol(options.protyle, options.blockElement);
                    addMenu.open({
                        x: tabRect.right,
                        y: tabRect.bottom,
                        h: tabRect.height,
                        isLeft: true
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "update-view-icon") {
                    const rect = target.getBoundingClientRect();
                    openEmojiPanel("", "av", {
                        x: rect.left,
                        y: rect.bottom + 4,
                        h: rect.height,
                        w: rect.width
                    }, (unicode) => {
                        transaction(options.protyle, [{
                            action: "setAttrViewViewIcon",
                            avID,
                            id: data.viewID,
                            data: unicode,
                        }], [{
                            action: "setAttrViewViewIcon",
                            id: data.viewID,
                            avID,
                            data: target.dataset.icon,
                        }]);
                        target.innerHTML = unicode ? unicode2Emoji(unicode) : '<svg style="width: 14px;height: 14px;"><use xlink:href="#iconTable"></use></svg>';
                        target.dataset.icon = unicode;
                    }, target.querySelector("img"), {
                        ownerElement: options.protyle.element,
                        targetID: options.protyle.block.rootID,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "set-page-size") {
                    setPageSize({
                        target,
                        protyle: options.protyle,
                        avID,
                        nodeElement: options.blockElement
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "duplicate-view") {
                    const id = Lute.NewNodeID();
                    transaction(options.protyle, [{
                        action: "duplicateAttrViewView",
                        avID,
                        previousID: data.viewID,
                        id,
                        blockID
                    }], [{
                        action: "removeAttrViewView",
                        avID,
                        id,
                        blockID
                    }]);
                    avPanelElement.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "delete-view") {
                    transaction(options.protyle, [{
                        action: "removeAttrViewView",
                        avID,
                        id: data.viewID,
                        blockID
                    }]);
                    avPanelElement.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "update-icon") {
                    const rect = target.getBoundingClientRect();
                    openEmojiPanel("", "av", {
                        x: rect.left,
                        y: rect.bottom + 4,
                        h: rect.height,
                        w: rect.width
                    }, (unicode) => {
                        const colId = menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                        transaction(options.protyle, [{
                            action: "setAttrViewColIcon",
                            id: colId,
                            avID,
                            data: unicode,
                        }], [{
                            action: "setAttrViewColIcon",
                            id: colId,
                            avID,
                            data: target.dataset.icon,
                        }]);
                        target.innerHTML = unicode ? unicode2Emoji(unicode) : `<svg style="height: 14px;width: 14px"><use xlink:href="#${getColIconByType(target.dataset.colType as TAVCol)}"></use></svg>`;
                        if (isCustomAttr) {
                            const iconElement = options.blockElement.querySelector(`.av__row[data-col-id="${colId}"] .block__logoicon`);
                            iconElement.outerHTML = unicode ? unicode2Emoji(unicode, "block__logoicon", true) : `<svg class="block__logoicon"><use xlink:href="#${getColIconByType(iconElement.nextElementSibling.getAttribute("data-type") as TAVCol)}"></use></svg>`;
                        } else {
                            updateAttrViewCellAnimation(options.blockElement.querySelector(`.av__row--header .av__cell[data-col-id="${colId}"]`), undefined, {icon: unicode});
                        }
                        target.dataset.icon = unicode;
                    }, target.querySelector("img"), {
                        ownerElement: options.protyle.element,
                        targetID: options.protyle.block.rootID,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "showAllCol") {
                    const doOperations: IOperation[] = [];
                    const undoOperations: IOperation[] = [];
                    fields.forEach((item: IAVColumn) => {
                        if (item.hidden) {
                            doOperations.push({
                                action: "setAttrViewColHidden",
                                id: item.id,
                                avID,
                                data: false,
                                blockID,
                                viewID: data.viewID,
                            });
                            undoOperations.push({
                                action: "setAttrViewColHidden",
                                id: item.id,
                                avID,
                                data: true,
                                blockID,
                                viewID: data.viewID,
                            });
                            item.hidden = false;
                        }
                    });
                    if (doOperations.length > 0) {
                        transaction(options.protyle, doOperations, undoOperations);
                        menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                        setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "hideAllCol") {
                    const doOperations: IOperation[] = [];
                    const undoOperations: IOperation[] = [];
                    fields.forEach((item: IAVColumn) => {
                        if (!item.hidden && (item.type !== "block" || data.viewType === "gallery")) {
                            doOperations.push({
                                action: "setAttrViewColHidden",
                                id: item.id,
                                avID,
                                data: true,
                                blockID,
                                viewID: data.viewID,
                            });
                            undoOperations.push({
                                action: "setAttrViewColHidden",
                                id: item.id,
                                avID,
                                data: false,
                                blockID,
                                viewID: data.viewID,
                            });
                            item.hidden = true;
                        }
                    });
                    if (doOperations.length > 0) {
                        transaction(options.protyle, doOperations, undoOperations);
                        menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                        setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "editCol") {
                    menuElement.innerHTML = getEditHTML({
                        protyle: options.protyle,
                        data,
                        colId: target.dataset.id,
                        isCustomAttr
                    });
                    bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "updateColType") {
                    const colId = options.colId || menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                    if (target.dataset.newType !== target.dataset.oldType) {
                        const nameElement = avPanelElement.querySelector('.b3-text-field[data-type="name"]') as HTMLInputElement;
                        const name = nameElement.value;
                        let newName = name;
                        fields.find((item: IAVColumn) => {
                            if (item.id === colId) {
                                item.type = target.dataset.newType as TAVCol;
                                if (getColNameByType(target.dataset.oldType as TAVCol) === name) {
                                    newName = getColNameByType(target.dataset.newType as TAVCol);
                                    item.name = newName;
                                }
                                return true;
                            }
                        });

                        transaction(options.protyle, [{
                            action: "updateAttrViewCol",
                            id: colId,
                            avID,
                            name: newName,
                            type: target.dataset.newType as TAVCol,
                        }], [{
                            action: "updateAttrViewCol",
                            id: colId,
                            avID,
                            name,
                            type: target.dataset.oldType as TAVCol,
                        }]);

                        // 需要取消行号列的筛选和排序
                        if (target.dataset.newType === "lineNumber") {
                            const sortExist = data.view.sorts.find((sort) => sort.column === colId);
                            if (sortExist) {
                                const oldSorts = Object.assign([], data.view.sorts);
                                const newSorts = data.view.sorts.filter((sort) => sort.column !== colId);

                                transaction(options.protyle, [{
                                    action: "setAttrViewSorts",
                                    avID: data.id,
                                    data: newSorts,
                                    blockID,
                                }], [{
                                    action: "setAttrViewSorts",
                                    avID: data.id,
                                    data: oldSorts,
                                    blockID,
                                }]);
                            }

                            const filterExist = hasFilterForColumn(data.view.filters, colId);
                            if (filterExist) {
                                const oldFilters = JSON.parse(JSON.stringify(data.view.filters));
                                // 递归移除引用该列的叶子并裁剪空分组。spec 5 下顶层为根组，操作其子节点；
                                // 兜底旧扁平数据（无根组）时直接处理顶层。
                                const root = data.view.filters[0] && data.view.filters[0].filters ? data.view.filters[0] : null;
                                if (root) {
                                    root.filters = removeFiltersByColumn(root.filters, colId);
                                } else {
                                    data.view.filters = removeFiltersByColumn(data.view.filters, colId);
                                }

                                transaction(options.protyle, [{
                                    action: "setAttrViewFilters",
                                    avID: data.id,
                                    data: JSON.parse(JSON.stringify(data.view.filters)),
                                    blockID
                                }], [{
                                    action: "setAttrViewFilters",
                                    avID: data.id,
                                    data: oldFilters,
                                    blockID
                                }]);
                            }
                        }
                    }
                    menuElement.innerHTML = getEditHTML({
                        protyle: options.protyle,
                        data,
                        colId,
                        isCustomAttr
                    });
                    bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goUpdateColType") {
                    window.siyuan.menus.menu.remove();
                    const editMenuElement = hasClosestByClassName(target, "b3-menu");
                    if (editMenuElement) {
                        editMenuElement.firstElementChild.classList.add("fn__none");
                        editMenuElement.lastElementChild.classList.remove("fn__none");
                    }
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goSearchAV") {
                    openSearchAV({
                        avID,
                        target,
                        purpose: "selectRelation",
                        blockID: options.blockElement.getAttribute("data-node-id"),
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goAttrViewColFilters") {
                    if (target.classList.contains("b3-menu__item--disabled")) {
                        break;
                    }
                    const colId = options.colId ||
                        menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                    const colData = fields.find((item) => item.id === colId);
                    const isRelationFilter = target.dataset.filterType === "relation";
                    const relationKey = isRelationFilter ? colData :
                        fields.find((item) => item.id === colData?.rollup?.relationKeyID);
                    const selectedTargetAvID = isRelationFilter ?
                        (menuElement.querySelector('[data-type="goSearchAV"]') as HTMLElement)?.dataset.avId : "";
                    const targetAvID = selectedTargetAvID || relationKey?.relation?.avID;
                    if (!colData || !targetAvID) {
                        break;
                    }
                    const targetChanged = isRelationFilter && targetAvID !== colData.relation?.avID;
                    const filters = targetChanged ? [] :
                        (isRelationFilter ? colData.relation?.candidateFilters : colData.rollup?.filters);
                    const openFilters = (sourcePanelElement?: Element) => {
                        fetchPost("/api/av/getAttributeView", {id: targetAvID}, (response) => {
                            if (sourcePanelElement && !sourcePanelElement.isConnected) {
                                return;
                            }
                            const targetAttrView = response.data?.av;
                            if (!targetAttrView) {
                                return;
                            }
                            const targetFields = (targetAttrView.keyValues || []).
                                map((item: { key: IAVColumn }) => item.key);
                            const filterData = {
                                id: targetAttrView.id,
                                name: targetAttrView.name,
                                viewID: "",
                                viewType: "table",
                                views: [],
                                view: {
                                    id: "",
                                    type: "table",
                                    filters: JSON.parse(JSON.stringify(filters?.length ? filters :
                                        [{combination: "and", filters: []}])),
                                    sorts: [],
                                    columns: targetFields,
                                    rows: [],
                                },
                            } as IAV;
                            sourcePanelElement?.remove();
                            openMenuPanel({
                                protyle: options.protyle,
                                blockElement: options.blockElement,
                                type: "filters",
                                colId,
                                data: filterData,
                                filterOperation: {
                                    action: isRelationFilter ? "setAttrViewColRelationFilters" :
                                        "setAttrViewColRollupFilters",
                                    keyID: colId,
                                },
                            });
                        });
                    };
                    const updateRelationButton = menuElement.querySelector('[data-type="updateRelation"]');
                    const updateRelationItem = updateRelationButton?.closest(".b3-menu__item");
                    const hasPendingRelation = isRelationFilter && !!updateRelationItem &&
                        !updateRelationItem.classList.contains("fn__none");
                    if (hasPendingRelation) {
                        updateRelation({
                            protyle: options.protyle,
                            avElement: avPanelElement,
                            avID,
                            colsData: fields,
                            blockElement: options.blockElement,
                            callback: openFilters,
                        });
                    } else {
                        openFilters(avPanelElement);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goSearchRollupCol") {
                    goSearchRollupCol({
                        target,
                        data,
                        isRelation: true,
                        protyle: options.protyle,
                        colId: options.colId || menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id")
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goSearchRollupTarget") {
                    goSearchRollupCol({
                        target,
                        data,
                        isRelation: false,
                        protyle: options.protyle,
                        colId: options.colId || menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id")
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goSearchRollupCalc") {
                    openCalcMenu(options.protyle, target, {
                        data,
                        colId: options.colId || menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id"),
                        blockID
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "updateRelation") {
                    updateRelation({
                        protyle: options.protyle,
                        avElement: avPanelElement,
                        avID,
                        colsData: fields,
                        blockElement: options.blockElement,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goEditCol") {
                    const editMenuElement = hasClosestByClassName(target, "b3-menu");
                    if (editMenuElement) {
                        editMenuElement.firstElementChild.classList.remove("fn__none");
                        editMenuElement.lastElementChild.classList.add("fn__none");
                    }
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "hideCol") {
                    const isEdit = menuElement.querySelector('[data-type="go-properties"]');
                    const colId = isEdit ? menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id") : target.parentElement.getAttribute("data-id");
                    transaction(options.protyle, [{
                        action: "setAttrViewColHidden",
                        id: colId,
                        avID,
                        data: true,
                        blockID,
                        viewID: data.viewID,
                    }], [{
                        action: "setAttrViewColHidden",
                        id: colId,
                        avID,
                        data: false,
                        blockID,
                        viewID: data.viewID,
                    }]);
                    fields.find((item: IAVColumn) => item.id === colId).hidden = true;
                    if (isEdit) {
                        menuElement.innerHTML = getEditHTML({
                            protyle: options.protyle,
                            data,
                            colId,
                            isCustomAttr
                        });
                        bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
                    } else {
                        menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                    }
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "showCol") {
                    const isEdit = menuElement.querySelector('[data-type="go-properties"]');
                    const colId = isEdit ? menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id") : target.parentElement.getAttribute("data-id");
                    transaction(options.protyle, [{
                        action: "setAttrViewColHidden",
                        id: colId,
                        avID,
                        data: false,
                        blockID,
                        viewID: data.viewID,
                    }], [{
                        action: "setAttrViewColHidden",
                        id: colId,
                        avID,
                        data: true,
                        blockID,
                        viewID: data.viewID,
                    }]);
                    fields.find((item: IAVColumn) => item.id === colId).hidden = false;
                    if (isEdit) {
                        menuElement.innerHTML = getEditHTML({
                            protyle: options.protyle,
                            data,
                            colId,
                            isCustomAttr
                        });
                        bindEditEvent({protyle: options.protyle, data, menuElement, isCustomAttr, blockID});
                    } else {
                        menuElement.innerHTML = getPropertiesHTML(fields, data.viewType);
                    }
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "duplicateCol") {
                    duplicateCol({
                        blockElement: options.blockElement,
                        protyle: options.protyle,
                        colId: menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id"),
                        data,
                        viewID: data.viewID,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeCol") {
                    if (!isCustomAttr) {
                        tabRect = options.blockElement.querySelector(".av__views").getBoundingClientRect();
                    }
                    const colId = menuElement.querySelector(".b3-menu__item").getAttribute("data-col-id");
                    const colData = fields.find((item: IAVColumn) => {
                        if (item.id === colId) {
                            return true;
                        }
                    });
                    const isTwoWay = colData.type === "relation" && colData.relation?.isTwoWay;
                    if (isCustomAttr || isTwoWay) {
                        const dialog = new Dialog({
                            title: isTwoWay ? window.siyuan.languages.removeColConfirm : window.siyuan.languages.deleteOpConfirm,
                            content: `<div class="b3-dialog__content">
    ${isTwoWay ? window.siyuan.languages.confirmRemoveRelationField
                                    .replace("${x}", menuElement.querySelector("input").value || window.siyuan.languages._kernel[272])
                                    .replace("${y}", menuElement.querySelector('.b3-menu__item[data-type="goSearchAV"] .b3-menu__accelerator').textContent)
                                    .replace("${z}", (menuElement.querySelector('input[data-type="colName"]') as HTMLInputElement).value || window.siyuan.languages._kernel[272])
                                : window.siyuan.languages.removeCol.replace("${x}", menuElement.querySelector("input").value || window.siyuan.languages._kernel[272])}
    <div class="fn__hr--b"></div>
    <button class="fn__block b3-button b3-button--remove" data-action="delete">${isTwoWay ? window.siyuan.languages.removeBothRelationField : window.siyuan.languages.delete}</button>
    <div class="fn__hr"></div>
    <button class="fn__block b3-button b3-button--remove${isTwoWay ? "" : " fn__none"}" data-action="keep-relation">${window.siyuan.languages.removeButKeepRelationField}</button>
    <div class="fn__hr"></div>
    <button class="fn__block b3-button b3-button--cancel">${window.siyuan.languages.cancel}</button>
</div>`,
                            width: "520px",
                        });
                        dialog.element.addEventListener("click", (dialogEvent) => {
                            let target = dialogEvent.target as HTMLElement;
                            const isDispatch = typeof dialogEvent.detail === "string";
                            while (target && target !== dialog.element || isDispatch) {
                                const action = target.getAttribute("data-action");
                                if (action === "delete" || (isDispatch && dialogEvent.detail === "Enter")) {
                                    removeCol({
                                        protyle: options.protyle,
                                        fields,
                                        avID,
                                        blockID,
                                        menuElement,
                                        isCustomAttr,
                                        blockElement: options.blockElement,
                                        avPanelElement,
                                        tabRect,
                                        isTwoWay: true
                                    });
                                    dialog.destroy();
                                    break;
                                } else if (action === "keep-relation") {
                                    removeCol({
                                        protyle: options.protyle,
                                        fields,
                                        avID,
                                        blockID,
                                        menuElement,
                                        isCustomAttr,
                                        blockElement: options.blockElement,
                                        avPanelElement,
                                        tabRect,
                                        isTwoWay: false
                                    });
                                    dialog.destroy();
                                    break;
                                } else if (target.classList.contains("b3-button--cancel") || (isDispatch && dialogEvent.detail === "Escape")) {
                                    dialog.destroy();
                                    break;
                                }
                                target = target.parentElement;
                            }
                        });
                        dialog.element.setAttribute("data-key", Constants.DIALOG_CONFIRM);
                    } else {
                        removeCol({
                            protyle: options.protyle,
                            fields,
                            avID,
                            blockID,
                            menuElement,
                            isCustomAttr,
                            blockElement: options.blockElement,
                            avPanelElement,
                            tabRect,
                            isTwoWay: false
                        });
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "setColOption") {
                    setColOption(options.protyle, data, target, options.blockElement, isCustomAttr,
                        options.cellElements, options.keepMenuOpen);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "setRelationCell") {
                    menuElement.querySelector(".b3-menu__item--current")?.classList.remove("b3-menu__item--current");
                    target.classList.add("b3-menu__item--current");
                    setRelationCell(options.protyle, options.blockElement as HTMLElement, target, options.cellElements);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addColOptionOrCell") {
                    menuElement.querySelector(".b3-menu__item--current")?.classList.remove("b3-menu__item--current");
                    target.classList.add("b3-menu__item--current");
                    if (target.querySelector(".b3-menu__checked")) {
                        removeCellOption(options.protyle, options.cellElements, menuElement.querySelector(`.b3-chips .b3-chip[data-content="${escapeAttr(target.dataset.name)}"]`), options.blockElement);
                    } else {
                        addColOptionOrCell(options.protyle, data, options.cellElements, target, menuElement, options.blockElement);
                    }
                    if (!options.keepMenuOpen) {
                        window.siyuan.menus.menu.remove();
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeCellOption") {
                    removeCellOption(options.protyle, options.cellElements, target.parentElement, options.blockElement);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addAssetLink") {
                    addAssetLink(options.protyle, options.cellElements, target, options.blockElement,
                        target.dataset.assetType as "image" | "file",
                        options.keepMenuOpen);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "addAssetExist") {
                    const rect = target.getBoundingClientRect();
                    assetMenu(options.protyle, {
                        x: rect.right,
                        y: rect.bottom,
                        w: target.parentElement.clientWidth + 8,
                        h: rect.height
                    }, (url, name) => {
                        let value: IAVCellAssetValue;
                        if (Constants.SIYUAN_ASSETS_IMAGE.includes(getAssetExtension(url).toLowerCase()) &&
                            isBrowserRenderableImagePath(url)) {
                            value = {
                                type: "image",
                                content: url,
                                name: ""
                            };
                        } else {
                            value = {
                                type: "file",
                                content: url,
                                name
                            };
                        }
                        updateAssetCell({
                            protyle: options.protyle,
                            cellElements: options.cellElements,
                            addValue: [value],
                            blockElement: options.blockElement
                        });
                        if (!options.keepMenuOpen) {
                            window.siyuan.menus.menu.remove();
                        }
                    }, undefined, options.keepMenuOpen);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "openAssetItem") {
                    const assetLink = target.parentElement.dataset.content;
                    if (target.parentElement.dataset.type === "image" &&
                        isBrowserRenderableImagePath(assetLink)) {
                        previewAttrViewImages(assetLink, avID, options.blockElement.getAttribute(Constants.CUSTOM_SY_AV_VIEW),
                            options.blockElement.querySelector('[data-type="av-search"]')?.textContent.trim() || "");
                    } else {
                        openLink(options.protyle.app, assetLink, event, event.ctrlKey || event.metaKey);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "editAssetItem") {
                    editAssetItem({
                        protyle: options.protyle,
                        cellElements: options.cellElements,
                        blockElement: options.blockElement,
                        content: target.parentElement.dataset.content,
                        type: target.parentElement.dataset.type as "image" | "file",
                        name: target.parentElement.dataset.name,
                        index: parseInt(target.parentElement.dataset.index),
                        rect: target.parentElement.getBoundingClientRect(),
                        keepMenuOpen: options.keepMenuOpen,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "clearDate") {
                    const colData = fields.find((item: IAVColumn) => {
                        if (item.id === getColId(options.cellElements[0], data.viewType)) {
                            return true;
                        }
                    });
                    updateCellsValue(options.protyle, options.blockElement as HTMLElement, {
                        isNotEmpty2: false,
                        isNotEmpty: false,
                        content: null,
                        content2: null,
                        hasEndDate: false,
                        isNotTime: colData.date ? !colData.date.fillSpecificTime : true,
                    }, options.cellElements, fields);
                    avPanelElement.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-add") {
                    window.siyuan.menus.menu.remove();
                    addView(options.protyle, options.blockElement);
                    avPanelElement.remove();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-view-show-all") {
                    if (setAVBlockVisibleViewIDs(options.protyle, options.blockElement, data.views.map((view) => view.id))) {
                        rerenderSwitcher();
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-view-hide-all") {
                    const visibleViewIDs = getAVVisibleViewIDs(options.blockElement, data.views);
                    const viewIDs = getAVVisibleViewIDsAfterHidingAll(visibleViewIDs, data.viewID);
                    if (setAVBlockVisibleViewIDs(options.protyle, options.blockElement, viewIDs)) {
                        rerenderSwitcher();
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-view-visibility") {
                    const viewID = target.closest<HTMLElement>(".b3-menu__item")?.dataset.id;
                    const visibleViewIDs = getAVVisibleViewIDs(options.blockElement, data.views);
                    const viewIDs = visibleViewIDs.includes(viewID) ?
                        visibleViewIDs.filter((item) => item !== viewID) :
                        visibleViewIDs.concat(viewID);
                    if (setAVBlockVisibleViewIDs(options.protyle, options.blockElement, viewIDs)) {
                        rerenderSwitcher();
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-view-switch") {
                    if (!target.parentElement.classList.contains("b3-menu__item--current")) {
                        const previousViewID = data.viewID;
                        data.viewID = target.parentElement.dataset.id;
                        options.blockElement.setAttribute(Constants.CUSTOM_SY_AV_VIEW, data.viewID);
                        clearSelect(["row", "galleryItem"], options.blockElement);
                        avPanelElement.querySelector(".b3-menu__item--current")?.classList.remove("b3-menu__item--current");
                        target.parentElement.classList.add("b3-menu__item--current");
                        transaction(options.protyle, [{
                            action: "setAttrViewBlockView",
                            blockID,
                            id: target.parentElement.dataset.id,
                            avID
                        }], [{
                            action: "setAttrViewBlockView",
                            blockID,
                            id: previousViewID,
                            avID
                        }]);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "av-view-edit") {
                    if (target.parentElement.classList.contains("b3-menu__item--current")) {
                        openViewMenu({
                            protyle: options.protyle,
                            blockElement: options.blockElement as HTMLElement,
                            element: target.parentElement
                        });
                    } else {
                        const previousViewID = data.viewID;
                        data.viewID = target.parentElement.dataset.id;
                        options.blockElement.setAttribute(Constants.CUSTOM_SY_AV_VIEW, data.viewID);
                        clearSelect(["row", "galleryItem"], options.blockElement);
                        avPanelElement.querySelector(".b3-menu__item--current")?.classList.remove("b3-menu__item--current");
                        target.parentElement.classList.add("b3-menu__item--current");
                        transaction(options.protyle, [{
                            action: "setAttrViewBlockView",
                            blockID,
                            id: target.parentElement.dataset.id,
                            avID,
                        }], [{
                            action: "setAttrViewBlockView",
                            blockID,
                            id: previousViewID,
                            avID,
                        }]);
                        window.siyuan.menus.menu.remove();
                        openViewMenu({
                            protyle: options.protyle,
                            blockElement: options.blockElement as HTMLElement,
                            element: target.parentElement
                        });
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "set-gallery-cover") {
                    setGalleryCover({
                        target,
                        protyle: options.protyle,
                        nodeElement: options.blockElement,
                        view: data.view as IAVGallery
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "set-gallery-size") {
                    setGallerySize({
                        target,
                        protyle: options.protyle,
                        nodeElement: options.blockElement,
                        view: data.view as IAVGallery
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "set-gallery-ratio") {
                    setGalleryRatio({
                        target,
                        protyle: options.protyle,
                        nodeElement: options.blockElement,
                        view: data.view as IAVGallery
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "set-layout") {
                    data = await updateLayout({
                        target,
                        protyle: options.protyle,
                        nodeElement: options.blockElement,
                        data
                    });
                    fields = getFieldsByData(data);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goGroupsDate") {
                    goGroupsDate({
                        target,
                        menuElement,
                        protyle: options.protyle,
                        blockElement: options.blockElement,
                        data
                    });
                    fields = getFieldsByData(data);
                    event.stopPropagation();
                    event.preventDefault();
                    break;
                } else if (type === "goGroupsSort") {
                    goGroupsSort({
                        target,
                        menuElement,
                        protyle: options.protyle,
                        blockElement: options.blockElement,
                        data
                    });
                    fields = getFieldsByData(data);
                    event.stopPropagation();
                    event.preventDefault();
                    break;
                } else if (type === "setGroupMethod") {
                    setGroupMethod({
                        protyle: options.protyle,
                        fieldId: target.getAttribute("data-id"),
                        data,
                        menuElement,
                        blockElement: options.blockElement,
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goGroups") {
                    if (menuElement.querySelector('[data-type="avGroupRange"]') && closeCB) {
                        await closeCB();
                    }
                    closeCB = undefined;
                    if ((data.view.group && data.view.group.field) || target.classList.contains("block__icon")) {
                        menuElement.innerHTML = getGroupsHTML(fields, data.view);
                        bindGroupsEvent({
                            protyle: options.protyle,
                            menuElement: menuElement,
                            blockElement: options.blockElement,
                            data
                        });
                    } else {
                        menuElement.innerHTML = getGroupsMethodHTML(fields, data.view.group, data.viewType);
                    }
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "goGroupsMethod") {
                    window.siyuan.menus.menu.remove();
                    menuElement.innerHTML = getGroupsMethodHTML(fields, data.view.group, data.viewType);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "getGroupsNumber") {
                    window.siyuan.menus.menu.remove();
                    menuElement.innerHTML = getGroupsNumberHTML(data.view.group);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    closeCB = bindGroupsNumber({
                        protyle: options.protyle,
                        data,
                        menuElement,
                        blockElement: options.blockElement
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "hideGroup") {
                    window.siyuan.menus.menu.remove();
                    const useElement = target.firstElementChild;
                    const isHide = useElement.getAttribute("xlink:href") !== "#iconEye";
                    useElement.setAttribute("xlink:href", isHide ? "#iconEye" : "#iconEyeoff");
                    let oldGroupHidden;
                    let showCount = 0;
                    data.view.groups.forEach((item) => {
                        if (item.id === target.dataset.id) {
                            oldGroupHidden = item.groupHidden;
                            item.groupHidden = isHide ? 0 : 2;
                        }
                        if (item.groupHidden === 0) {
                            showCount++;
                        }
                    });
                    target.parentElement.classList[isHide ? "remove" : "add"]("b3-menu__item--hidden");
                    menuElement.querySelector('[data-type="hideGroups"]').innerHTML = `${window.siyuan.languages[showCount === 0 ? "showAll" : "hideAll"]}
<span class="fn__space"></span>
<svg><use xlink:href="#iconEye${showCount === 0 ? "" : "off"}"></use></svg>`;
                    transaction(options.protyle, [{
                        action: "hideAttrViewGroup",
                        avID: data.id,
                        blockID,
                        id: target.dataset.id,
                        data: isHide ? 0 : 2,
                    }], [{
                        action: "hideAttrViewGroup",
                        avID: data.id,
                        blockID,
                        id: target.dataset.id,
                        data: oldGroupHidden
                    }]);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "hideGroups") {
                    window.siyuan.menus.menu.remove();
                    const isShow = target.querySelector("use").getAttribute("xlink:href") === "#iconEyeoff";
                    target.innerHTML = `${window.siyuan.languages[isShow ? "showAll" : "hideAll"]}
<span class="fn__space"></span>
<svg><use xlink:href="#iconEye${isShow ? "" : "off"}"></use></svg>`;
                    data.view.groups.forEach((item) => {
                        item.groupHidden = isShow ? 2 : 0;
                        const itemElement = target.parentElement.parentElement.querySelector(`.b3-menu__item[data-id="${item.id}"]`);
                        itemElement.classList[isShow ? "add" : "remove"]("b3-menu__item--hidden");
                        itemElement.querySelector(".b3-menu__action use")?.setAttribute("xlink:href", `#iconEye${isShow ? "off" : ""}`);
                    });
                    transaction(options.protyle, [{
                        action: "hideAttrViewAllGroups",
                        avID: data.id,
                        blockID,
                        data: isShow,
                    }], [{
                        action: "hideAttrViewAllGroups",
                        avID: data.id,
                        blockID,
                        data: !isShow
                    }]);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "removeGroups") {
                    window.siyuan.menus.menu.remove();
                    transaction(options.protyle, [{
                        action: "removeAttrViewGroup",
                        avID: data.id,
                        blockID,
                    }], [{
                        action: "setAttrViewGroup",
                        avID: data.id,
                        blockID,
                        data: data.view.group
                    }]);
                    data.view.group = null;
                    delete data.view.groups;
                    menuElement.innerHTML = getGroupsHTML(fields, data.view);
                    setPosition(menuElement, tabRect.right - menuElement.clientWidth, tabRect.bottom, tabRect.height, 0, true);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                }
                // 有错误日志，没找到重现步骤，需先判断一下
                if (!target || !target.parentElement) {
                    break;
                }
                target = target.parentElement;
            }
        });
    };
    // 复用调用方传入的数据时直接渲染，跳过 fetch，避免与刚提交的事务产生读写竞争（拿到旧数据）
    if (options.data) {
        renderData(options.data);
    } else {
        fetchPost("/api/av/renderAttributeView", fetchPayload, response => renderData(response.data as IAV));
    }
};

export const getPropertiesHTML = (fields: IAVColumn[], viewType: TAVView) => {
    let showHTML = "";
    let hideHTML = "";
    fields.forEach((item: IAVColumn) => {
        if (item.hidden) {
            hideHTML += `<button class="b3-menu__item" data-type="editCol" draggable="true" data-id="${item.id}">
    <svg class="b3-menu__icon fn__grab"><use xlink:href="#iconDrag"></use></svg>
    <div class="b3-menu__label fn__flex">
        ${item.icon ? unicode2Emoji(item.icon, "b3-menu__icon", true) : `<svg class="b3-menu__icon"><use xlink:href="#${getColIconByType(item.type)}"></use></svg>`}
        ${escapeHtml(item.name) || "&nbsp;"}
    </div>
    <svg class="b3-menu__action" data-type="showCol"><use xlink:href="#iconEye"></use></svg>
    <svg class="b3-menu__icon b3-menu__icon--small"><use xlink:href="#iconRight"></use></svg>
</button>`;
        } else {
            showHTML += `<button class="b3-menu__item" data-type="editCol" draggable="true" data-id="${item.id}">
    <svg class="b3-menu__icon fn__grab"><use xlink:href="#iconDrag"></use></svg>
    <div class="b3-menu__label fn__flex">
        ${item.icon ? unicode2Emoji(item.icon, "b3-menu__icon", true) : `<svg class="b3-menu__icon"><use xlink:href="#${getColIconByType(item.type)}"></use></svg>`}
        ${escapeHtml(item.name) || "&nbsp;"}
    </div>
    <svg class="b3-menu__action${item.type === "block" && viewType !== "gallery" ? " fn__none" : ""}" data-type="hideCol"><use xlink:href="#iconEyeoff"></use></svg>
    <svg class="b3-menu__icon b3-menu__icon--small"><use xlink:href="#iconRight"></use></svg>
</button>`;
        }
    });
    if (hideHTML) {
        hideHTML = `<button class="b3-menu__separator"></button>
<button class="b3-menu__item" data-type="nobg">
    <span class="b3-menu__label">
        ${window.siyuan.languages.hideCol} 
    </span>
    <span class="block__icon" data-type="showAllCol">
        ${window.siyuan.languages.showAll}
        <span class="fn__space"></span>
        <svg><use xlink:href="#iconEye"></use></svg>
    </span>
</button>
${hideHTML}`;
    }
    return `<div class="b3-menu__items">
<button class="b3-menu__item" data-type="nobg">
    <span class="block__icon" style="padding: 8px;margin-left: -4px;" data-type="go-config">
        <svg><use xlink:href="#iconLeft"></use></svg>
    </span>
    <span class="b3-menu__label ft__center">${window.siyuan.languages.fields}</span>
</button>
<button class="b3-menu__separator"></button>
<button class="b3-menu__item" data-type="nobg">
    <span class="b3-menu__label">
        ${window.siyuan.languages.showCol} 
    </span>
    <span class="block__icon" data-type="hideAllCol">
        ${window.siyuan.languages.hideAll}
        <span class="fn__space"></span>
        <svg><use xlink:href="#iconEyeoff"></use></svg>
    </span>
</button>
${showHTML}
${hideHTML}
<button class="b3-menu__separator"></button>
<button class="b3-menu__item" data-type="newCol">
    <svg class="b3-menu__icon"><use xlink:href="#iconAdd"></use></svg>
    <span class="b3-menu__label">${window.siyuan.languages.new}</span>
</button>
</div>`;
};
