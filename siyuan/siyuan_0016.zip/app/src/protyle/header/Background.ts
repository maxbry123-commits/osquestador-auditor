import {hasClosestByClassName} from "../util/hasClosest";
import {getRandom, isMobile} from "../../util/functions";
import {hideElements} from "../ui/hideElements";
import {uploadFiles} from "../upload";
import {fetchPost} from "../../util/fetch";
import {getRandomEmoji, openEmojiPanel, unicode2Emoji, updateFileTreeEmoji, updateOutlineEmoji} from "../../emoji";
import {upDownHint} from "../../util/upDownHint";
/// #if !MOBILE
import {openGlobalSearch} from "../../search/util";
/// #else
import {popSearch} from "../../mobile/menu/search";
/// #endif
import {Dialog} from "../../dialog";
import {Constants} from "../../constants";
import {assetMenu} from "../../menus/protyle";
import {previewImages} from "../preview/image";
import {Menu} from "../../plugin/Menu";
import {escapeHtml} from "../../util/escape";
import {fetchCoverData, getCategoryLabel} from "./coverData";
/// #if !MOBILE
import {openDocTagMenu} from "./openDocTagMenu";
/// #endif

const bindPopoverDialog = (dialog: Dialog, ownerElement: HTMLElement) => {
    const popoverElement = ownerElement.closest<HTMLElement>(".block__popover");
    const popoverOID = popoverElement?.dataset.oid;
    const popoverLevel = popoverElement?.dataset.level;
    if (popoverOID && popoverLevel) {
        dialog.element.dataset.popoverOid = popoverOID;
        dialog.element.dataset.popoverLevel = popoverLevel;
    }
};

const bgs = [
    "background:radial-gradient(black 3px, transparent 4px),radial-gradient(black 3px, transparent 4px),linear-gradient(#fff 4px, transparent 0),linear-gradient(45deg, transparent 74px, transparent 75px, #a4a4a4 75px, #a4a4a4 76px, transparent 77px, transparent 109px),linear-gradient(-45deg, transparent 75px, transparent 76px, #a4a4a4 76px, #a4a4a4 77px, transparent 78px, transparent 109px),#fff;background-size: 109px 109px, 109px 109px,100% 6px, 109px 109px, 109px 109px;background-position: 54px 55px, 0px 0px, 0px 0px, 0px 0px, 0px 0px;",
    "background: linear-gradient(45deg, #dca 12%, transparent 0, transparent 88%, #dca 0),linear-gradient(135deg, transparent 37%, #a85 0, #a85 63%, transparent 0),linear-gradient(45deg, transparent 37%, #dca 0, #dca 63%, transparent 0) #753;background-size: 25px 25px;",
    "background: linear-gradient(315deg, transparent 75%, #d45d55 0)-10px 0, linear-gradient(45deg, transparent 75%, #d45d55 0)-10px 0, linear-gradient(135deg, #a7332b 50%, transparent 0) 0 0, linear-gradient(45deg, #6a201b 50%, #561a16 0) 0 0 #561a16;background-size: 20px 20px;",
    "background: linear-gradient(#ffffff 50%, rgba(255,255,255,0) 0) 0 0, radial-gradient(circle closest-side, #FFFFFF 53%, rgba(255,255,255,0) 0) 0 0, radial-gradient(circle closest-side, #FFFFFF 50%, rgba(255,255,255,0) 0) 55px 0 #48B;background-size: 110px 200px;background-repeat: repeat-x;",
    "background:radial-gradient(circle farthest-side at 0% 50%,#fb1 23.5%,rgba(240,166,17,0) 0)21px 30px, radial-gradient(circle farthest-side at 0% 50%,#B71 24%,rgba(240,166,17,0) 0)19px 30px, linear-gradient(#fb1 14%,rgba(240,166,17,0) 0, rgba(240,166,17,0) 85%,#fb1 0)0 0, linear-gradient(150deg,#fb1 24%,#B71 0,#B71 26%,rgba(240,166,17,0) 0,rgba(240,166,17,0) 74%,#B71 0,#B71 76%,#fb1 0)0 0, linear-gradient(30deg,#fb1 24%,#B71 0,#B71 26%,rgba(240,166,17,0) 0,rgba(240,166,17,0) 74%,#B71 0,#B71 76%,#fb1 0)0 0, linear-gradient(90deg,#B71 2%,#fb1 0,#fb1 98%,#B71 0%)0 0 #fb1;background-size: 40px 60px;",
    "background-color: gray;background-image: linear-gradient(transparent 50%, rgba(255,255,255,.5) 50%);background-size: 50px 50px;",
    "background-color: gray;background-image: linear-gradient(90deg, transparent 50%, rgba(255,255,255,.5) 50%);background-size: 50px 50px;",
    "background-color: #026873;background-image: linear-gradient(90deg, rgba(255,255,255,.07) 50%, transparent 50%),linear-gradient(90deg, rgba(255,255,255,.13) 50%, transparent 50%),linear-gradient(90deg, transparent 50%, rgba(255,255,255,.17) 50%),linear-gradient(90deg, transparent 50%, rgba(255,255,255,.19) 50%);background-size: 13px, 29px, 37px, 53px;",
    "background-color: gray;background-image: repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,255,255,.5) 35px, rgba(255,255,255,.5) 70px);",
    "background-color:white;background-image: linear-gradient(90deg, rgba(200,0,0,.5) 50%, transparent 50%),linear-gradient(rgba(200,0,0,.5) 50%, transparent 50%);background-size:50px 50px;",
    "background-color:#269;background-image: linear-gradient(white 2px, transparent 2px),linear-gradient(90deg, white 2px, transparent 2px),linear-gradient(rgba(255,255,255,.3) 1px, transparent 1px),linear-gradient(90deg, rgba(255,255,255,.3) 1px, transparent 1px);background-size: 100px 100px, 100px 100px, 20px 20px, 20px 20px;background-position:-2px -2px, -2px -2px, -1px -1px, -1px -1px;",
    "background-color: #fff;background-image:linear-gradient(90deg, transparent 79px, #abced4 79px, #abced4 81px, transparent 81px),linear-gradient(#eee .1em, transparent .1em);background-size: 100% 1.2em;",
    "background-color: hsl(34, 53%, 82%);background-image: repeating-linear-gradient(45deg, transparent 5px, hsla(197, 62%, 11%, 0.5) 5px, hsla(197, 62%, 11%, 0.5) 10px, hsla(5, 53%, 63%, 0) 10px, hsla(5, 53%, 63%, 0) 35px, hsla(5, 53%, 63%, 0.5) 35px, hsla(5, 53%, 63%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 50px, hsla(197, 62%, 11%, 0) 50px, hsla(197, 62%, 11%, 0) 60px, hsla(5, 53%, 63%, 0.5) 60px, hsla(5, 53%, 63%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 80px, hsla(35, 91%, 65%, 0) 80px, hsla(35, 91%, 65%, 0) 90px, hsla(5, 53%, 63%, 0.5) 90px, hsla(5, 53%, 63%, 0.5) 110px, hsla(5, 53%, 63%, 0) 110px, hsla(5, 53%, 63%, 0) 120px, hsla(197, 62%, 11%, 0.5) 120px, hsla(197, 62%, 11%, 0.5) 140px),repeating-linear-gradient(135deg, transparent 5px, hsla(197, 62%, 11%, 0.5) 5px, hsla(197, 62%, 11%, 0.5) 10px, hsla(5, 53%, 63%, 0) 10px, hsla(5, 53%, 63%, 0) 35px, hsla(5, 53%, 63%, 0.5) 35px, hsla(5, 53%, 63%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 50px, hsla(197, 62%, 11%, 0) 50px, hsla(197, 62%, 11%, 0) 60px, hsla(5, 53%, 63%, 0.5) 60px, hsla(5, 53%, 63%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 80px, hsla(35, 91%, 65%, 0) 80px, hsla(35, 91%, 65%, 0) 90px, hsla(5, 53%, 63%, 0.5) 90px, hsla(5, 53%, 63%, 0.5) 110px, hsla(5, 53%, 63%, 0) 110px, hsla(5, 53%, 63%, 0) 140px, hsla(197, 62%, 11%, 0.5) 140px, hsla(197, 62%, 11%, 0.5) 160px);",
    "background-color: hsl(2, 57%, 40%);background-image: repeating-linear-gradient(transparent, transparent 50px, rgba(0,0,0,.4) 50px, rgba(0,0,0,.4) 53px, transparent 53px, transparent 63px, rgba(0,0,0,.4) 63px, rgba(0,0,0,.4) 66px, transparent 66px, transparent 116px, rgba(0,0,0,.5) 116px, rgba(0,0,0,.5) 166px, rgba(255,255,255,.2) 166px, rgba(255,255,255,.2) 169px, rgba(0,0,0,.5) 169px, rgba(0,0,0,.5) 179px, rgba(255,255,255,.2) 179px, rgba(255,255,255,.2) 182px, rgba(0,0,0,.5) 182px, rgba(0,0,0,.5) 232px, transparent 232px),repeating-linear-gradient(270deg, transparent, transparent 50px, rgba(0,0,0,.4) 50px, rgba(0,0,0,.4) 53px, transparent 53px, transparent 63px, rgba(0,0,0,.4) 63px, rgba(0,0,0,.4) 66px, transparent 66px, transparent 116px, rgba(0,0,0,.5) 116px, rgba(0,0,0,.5) 166px, rgba(255,255,255,.2) 166px, rgba(255,255,255,.2) 169px, rgba(0,0,0,.5) 169px, rgba(0,0,0,.5) 179px, rgba(255,255,255,.2) 179px, rgba(255,255,255,.2) 182px, rgba(0,0,0,.5) 182px, rgba(0,0,0,.5) 232px, transparent 232px),repeating-linear-gradient(125deg, transparent, transparent 2px, rgba(0,0,0,.2) 2px, rgba(0,0,0,.2) 3px, transparent 3px, transparent 5px, rgba(0,0,0,.2) 5px);",
    "background-color: #eee;background-image: linear-gradient(45deg, black 25%, transparent 25%, transparent 75%, black 75%, black),linear-gradient(-45deg, black 25%, transparent 25%, transparent 75%, black 75%, black);background-size: 60px 60px;",
    "background-color: #eee;background-image: linear-gradient(45deg, black 25%, transparent 25%, transparent 75%, black 75%, black),linear-gradient(45deg, black 25%, transparent 25%, transparent 75%, black 75%, black);background-size: 60px 60px;background-position: 0 0, 30px 30px;",
    "background:linear-gradient(-45deg, white 25%, transparent 25%, transparent 75%, black 75%, black) 0 0, linear-gradient(-45deg, black 25%, transparent 25%, transparent 75%, white 75%, white) 1em 1em, linear-gradient(45deg, black 17%, transparent 17%, transparent 25%, black 25%, black 36%, transparent 36%, transparent 64%, black 64%, black 75%, transparent 75%, transparent 83%, black 83%) 1em 1em;background-color: white;background-size: 2em 2em;",
    "background-color:#001;background-image: radial-gradient(white 15%, transparent 16%),radial-gradient(white 15%, transparent 16%);background-size: 60px 60px;background-position: 0 0, 30px 30px;",
    "background-color:#556;background-image: linear-gradient(30deg, #445 12%, transparent 12.5%, transparent 87%, #445 87.5%, #445),linear-gradient(150deg, #445 12%, transparent 12.5%, transparent 87%, #445 87.5%, #445),linear-gradient(30deg, #445 12%, transparent 12.5%, transparent 87%, #445 87.5%, #445),linear-gradient(150deg, #445 12%, transparent 12.5%, transparent 87%, #445 87.5%, #445),linear-gradient(60deg, #99a 25%, transparent 25.5%, transparent 75%, #99a 75%, #99a),linear-gradient(60deg, #99a 25%, transparent 25.5%, transparent 75%, #99a 75%, #99a);background-size:80px 140px;background-position: 0 0, 0 0, 40px 70px, 40px 70px, 0 0, 40px 70px;",
    "background-color:silver;background-image:radial-gradient(circle at 100% 150%, silver 24%, white 24%, white 28%, silver 28%, silver 36%, white 36%, white 40%, transparent 40%, transparent),radial-gradient(circle at 0    150%, silver 24%, white 24%, white 28%, silver 28%, silver 36%, white 36%, white 40%, transparent 40%, transparent),radial-gradient(circle at 50%  100%, white 10%, silver 10%, silver 23%, white 23%, white 30%, silver 30%, silver 43%, white 43%, white 50%, silver 50%, silver 63%, white 63%, white 71%, transparent 71%, transparent),radial-gradient(circle at 100% 50%, white 5%, silver 5%, silver 15%, white 15%, white 20%, silver 20%, silver 29%, white 29%, white 34%, silver 34%, silver 44%, white 44%, white 49%, transparent 49%, transparent),radial-gradient(circle at 0    50%, white 5%, silver 5%, silver 15%, white 15%, white 20%, silver 20%, silver 29%, white 29%, white 34%, silver 34%, silver 44%, white 44%, white 49%, transparent 49%, transparent);background-size: 100px 50px;",
    "background-color: silver;background-image: linear-gradient(335deg, #b00 23px, transparent 23px),linear-gradient(155deg, #d00 23px, transparent 23px),linear-gradient(335deg, #b00 23px, transparent 23px),linear-gradient(155deg, #d00 23px, transparent 23px);background-size: 58px 58px;background-position: 0px 2px, 4px 35px, 29px 31px, 34px 6px;",
    "background-color:#def;background-image: radial-gradient(closest-side, transparent 98%, rgba(0,0,0,.3) 99%),radial-gradient(closest-side, transparent 98%, rgba(0,0,0,.3) 99%);background-size:80px 80px;background-position:0 0, 40px 40px;",
    "background-image:radial-gradient(closest-side, transparent 0%, transparent 75%, #B6CC66 76%, #B6CC66 85%, #EDFFDB 86%, #EDFFDB 94%, #FFFFFF 95%, #FFFFFF 103%, #D9E6A7 104%, #D9E6A7 112%, #798B3C 113%, #798B3C 121%, #FFFFFF 122%, #FFFFFF 130%, #E0EAD7 131%, #E0EAD7 140%),radial-gradient(closest-side, transparent 0%, transparent 75%, #B6CC66 76%, #B6CC66 85%, #EDFFDB 86%, #EDFFDB 94%, #FFFFFF 95%, #FFFFFF 103%, #D9E6A7 104%, #D9E6A7 112%, #798B3C 113%, #798B3C 121%, #FFFFFF 122%, #FFFFFF 130%, #E0EAD7 131%, #E0EAD7 140%);background-size: 110px 110px;background-color: #C8D3A7;background-position: 0 0, 55px 55px;",
    "background:linear-gradient(324deg, #232927 4%,   transparent 4%) -70px 43px, linear-gradient( 36deg, #232927 4%,   transparent 4%) 30px 43px, linear-gradient( 72deg, #e3d7bf 8.5%, transparent 8.5%) 30px 43px, linear-gradient(288deg, #e3d7bf 8.5%, transparent 8.5%) -70px 43px, linear-gradient(216deg, #e3d7bf 7.5%, transparent 7.5%) -70px 23px, linear-gradient(144deg, #e3d7bf 7.5%, transparent 7.5%) 30px 23px, linear-gradient(324deg, #232927 4%,   transparent 4%) -20px 93px, linear-gradient( 36deg, #232927 4%,   transparent 4%) 80px 93px, linear-gradient( 72deg, #e3d7bf 8.5%, transparent 8.5%) 80px 93px, linear-gradient(288deg, #e3d7bf 8.5%, transparent 8.5%) -20px 93px, linear-gradient(216deg, #e3d7bf 7.5%, transparent 7.5%) -20px 73px, linear-gradient(144deg, #e3d7bf 7.5%, transparent 7.5%) 80px 73px;background-color: #232927;background-size: 100px 100px;",
    "background:radial-gradient(circle at 50% 59%, #D2CAAB 3%, #364E27 4%, #364E27 11%, rgba(54,78,39,0) 12%, rgba(54,78,39,0)) 50px 0, radial-gradient(circle at 50% 41%, #364E27 3%, #D2CAAB 4%, #D2CAAB 11%, rgba(210,202,171,0) 12%, rgba(210,202,171,0)) 50px 0, radial-gradient(circle at 50% 59%, #D2CAAB 3%, #364E27 4%, #364E27 11%, rgba(54,78,39,0) 12%, rgba(54,78,39,0)) 0 50px, radial-gradient(circle at 50% 41%, #364E27 3%, #D2CAAB 4%, #D2CAAB 11%, rgba(210,202,171,0) 12%, rgba(210,202,171,0)) 0 50px, radial-gradient(circle at 100% 50%, #D2CAAB 16%, rgba(210,202,171,0) 17%),radial-gradient(circle at 0% 50%, #364E27 16%, rgba(54,78,39,0) 17%),radial-gradient(circle at 100% 50%, #D2CAAB 16%, rgba(210,202,171,0) 17%) 50px 50px, radial-gradient(circle at 0% 50%, #364E27 16%, rgba(54,78,39,0) 17%) 50px 50px;background-color:#63773F;background-size:100px 100px;",
    "background:radial-gradient(circle, transparent 20%, slategray 20%, slategray 80%, transparent 80%, transparent),radial-gradient(circle, transparent 20%, slategray 20%, slategray 80%, transparent 80%, transparent) 50px 50px, linear-gradient(#A8B1BB 8px, transparent 8px) 0 -4px, linear-gradient(90deg, #A8B1BB 8px, transparent 8px) -4px 0;background-color: slategray;background-size:100px 100px, 100px 100px, 50px 50px, 50px 50px;",
    "background:radial-gradient(circle at 100% 50%, transparent 20%, rgba(255,255,255,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent),radial-gradient(circle at 0% 50%, transparent 20%, rgba(255,255,255,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent) 0 -50px;background-color: slategray;background-size:75px 100px;",
    "background-color: #FF7D9D;background-size: 58px 58px;background-position: 0px 2px, 4px 35px, 29px 31px, 33px 6px, 0px 36px, 4px 2px, 29px 6px, 33px 30px;background-image:linear-gradient(335deg, #C90032 23px, transparent 23px),linear-gradient(155deg, #C90032 23px, transparent 23px),linear-gradient(335deg, #C90032 23px, transparent 23px),linear-gradient(155deg, #C90032 23px, transparent 23px),linear-gradient(335deg, #C90032 10px, transparent 10px),linear-gradient(155deg, #C90032 10px, transparent 10px),linear-gradient(335deg, #C90032 10px, transparent 10px),linear-gradient(155deg, #C90032 10px, transparent 10px);",
    "background-color: #6d695c;background-image:repeating-linear-gradient(120deg, rgba(255,255,255,.1), rgba(255,255,255,.1) 1px, transparent 1px, transparent 60px),repeating-linear-gradient(60deg, rgba(255,255,255,.1), rgba(255,255,255,.1) 1px, transparent 1px, transparent 60px),linear-gradient(60deg, rgba(0,0,0,.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,.1) 75%, rgba(0,0,0,.1)),linear-gradient(120deg, rgba(0,0,0,.1) 25%, transparent 25%, transparent 75%, rgba(0,0,0,.1) 75%, rgba(0,0,0,.1));background-size: 70px 120px;",
    "background:radial-gradient(circle closest-side at 60% 43%, #b03 26%, rgba(187,0,51,0) 27%),radial-gradient(circle closest-side at 40% 43%, #b03 26%, rgba(187,0,51,0) 27%),radial-gradient(circle closest-side at 40% 22%, #d35 45%, rgba(221,51,85,0) 46%),radial-gradient(circle closest-side at 60% 22%, #d35 45%, rgba(221,51,85,0) 46%),radial-gradient(circle closest-side at 50% 35%, #d35 30%, rgba(221,51,85,0) 31%),radial-gradient(circle closest-side at 60% 43%, #b03 26%, rgba(187,0,51,0) 27%) 50px 50px, radial-gradient(circle closest-side at 40% 43%, #b03 26%, rgba(187,0,51,0) 27%) 50px 50px, radial-gradient(circle closest-side at 40% 22%, #d35 45%, rgba(221,51,85,0) 46%) 50px 50px, radial-gradient(circle closest-side at 60% 22%, #d35 45%, rgba(221,51,85,0) 46%) 50px 50px, radial-gradient(circle closest-side at 50% 35%, #d35 30%, rgba(221,51,85,0) 31%) 50px 50px;background-color:#b03;background-size:100px 100px;",
    "background:radial-gradient(black 15%, transparent 16%) 0 0, radial-gradient(black 15%, transparent 16%) 8px 8px, radial-gradient(rgba(255,255,255,.1) 15%, transparent 20%) 0 1px, radial-gradient(rgba(255,255,255,.1) 15%, transparent 20%) 8px 9px;background-color:#282828;background-size:16px 16px;",
    "background:linear-gradient(27deg, #151515 5px, transparent 5px) 0 5px, linear-gradient(207deg, #151515 5px, transparent 5px) 10px 0px, linear-gradient(27deg, #222 5px, transparent 5px) 0px 10px, linear-gradient(207deg, #222 5px, transparent 5px) 10px 5px, linear-gradient(90deg, #1b1b1b 10px, transparent 10px),linear-gradient(#1d1d1d 25%, #1a1a1a 25%, #1a1a1a 50%, transparent 50%, transparent 75%, #242424 75%, #242424);background-color: #131313;background-size: 20px 20px;",
    "background:radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.15) 30%, rgba(255,255,255,.3) 32%, rgba(255,255,255,0) 33%) 0 0, radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.1) 11%, rgba(255,255,255,.3) 13%, rgba(255,255,255,0) 14%) 0 0, radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.2) 17%, rgba(255,255,255,.43) 19%, rgba(255,255,255,0) 20%) 0 110px, radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.2) 11%, rgba(255,255,255,.4) 13%, rgba(255,255,255,0) 14%) -130px -170px, radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.2) 11%, rgba(255,255,255,.4) 13%, rgba(255,255,255,0) 14%) 130px 370px, radial-gradient(rgba(255,255,255,0) 0, rgba(255,255,255,.1) 11%, rgba(255,255,255,.2) 13%, rgba(255,255,255,0) 14%) 0 0, linear-gradient(45deg, #343702 0%, #184500 20%, #187546 30%, #006782 40%, #0b1284 50%, #760ea1 60%, #83096e 70%, #840b2a 80%, #b13e12 90%, #e27412 100%);background-size: 470px 470px, 970px 970px, 410px 410px, 610px 610px, 530px 530px, 730px 730px, 100% 100%;background-color: #840b2a;",
    "background-color:white;background-image:radial-gradient(midnightblue 9px, transparent 10px),repeating-radial-gradient(midnightblue 0, midnightblue 4px, transparent 5px, transparent 20px, midnightblue 21px, midnightblue 25px, transparent 26px, transparent 50px);background-size: 30px 30px, 90px 90px;background-position: 0 0;",
    "background-color:black;background-image:radial-gradient(white, rgba(255,255,255,.2) 2px, transparent 40px),radial-gradient(white, rgba(255,255,255,.15) 1px, transparent 30px),radial-gradient(white, rgba(255,255,255,.1) 2px, transparent 40px),radial-gradient(rgba(255,255,255,.4), rgba(255,255,255,.1) 2px, transparent 30px);background-size: 550px 550px, 350px 350px, 250px 250px, 150px 150px;background-position: 0 0, 40px 60px, 130px 270px, 70px 100px;",
    "background:radial-gradient(hsl(0, 100%, 27%) 4%, hsl(0, 100%, 18%) 9%, hsla(0, 100%, 20%, 0) 9%) 0 0, radial-gradient(hsl(0, 100%, 27%) 4%, hsl(0, 100%, 18%) 8%, hsla(0, 100%, 20%, 0) 10%) 50px 50px, radial-gradient(hsla(0, 100%, 30%, 0.8) 20%, hsla(0, 100%, 20%, 0)) 50px 0, radial-gradient(hsla(0, 100%, 30%, 0.8) 20%, hsla(0, 100%, 20%, 0)) 0 50px, radial-gradient(hsla(0, 100%, 20%, 1) 35%, hsla(0, 100%, 20%, 0) 60%) 50px 0, radial-gradient(hsla(0, 100%, 20%, 1) 35%, hsla(0, 100%, 20%, 0) 60%) 100px 50px, radial-gradient(hsla(0, 100%, 15%, 0.7), hsla(0, 100%, 20%, 0)) 0 0, radial-gradient(hsla(0, 100%, 15%, 0.7), hsla(0, 100%, 20%, 0)) 50px 50px, linear-gradient(45deg, hsla(0, 100%, 20%, 0) 49%, hsla(0, 100%, 0%, 1) 50%, hsla(0, 100%, 20%, 0) 70%) 0 0, linear-gradient(-45deg, hsla(0, 100%, 20%, 0) 49%, hsla(0, 100%, 0%, 1) 50%, hsla(0, 100%, 20%, 0) 70%) 0 0;background-color: #300;background-size: 100px 100px;",
    "background:linear-gradient(135deg, #708090 21px, #d9ecff 22px, #d9ecff 24px, transparent 24px, transparent 67px, #d9ecff 67px, #d9ecff 69px, transparent 69px),linear-gradient(225deg, #708090 21px, #d9ecff 22px, #d9ecff 24px, transparent 24px, transparent 67px, #d9ecff 67px, #d9ecff 69px, transparent 69px)0 64px;background-color:#708090;background-size: 64px 128px;",
    "background:linear-gradient(135deg, #ECEDDC 25%, transparent 25%) -50px 0, linear-gradient(225deg, #ECEDDC 25%, transparent 25%) -50px 0, linear-gradient(315deg, #ECEDDC 25%, transparent 25%),linear-gradient(45deg, #ECEDDC 25%, transparent 25%);background-size: 100px 100px;background-color: #EC173A;",
    "background:linear-gradient(45deg, #92baac 45px, transparent 45px)64px 64px, linear-gradient(45deg, #92baac 45px, transparent 45px,transparent 91px, #e1ebbd 91px, #e1ebbd 135px, transparent 135px),linear-gradient(-45deg, #92baac 23px, transparent 23px, transparent 68px,#92baac 68px,#92baac 113px,transparent 113px,transparent 158px,#92baac 158px);background-color:#e1ebbd;background-size: 128px 128px;",
    "background:linear-gradient(63deg, #999 23%, transparent 23%) 7px 0,linear-gradient(63deg, transparent 74%, #999 78%),linear-gradient(63deg, transparent 34%, #999 38%, #999 58%, transparent 62%),#444;background-size: 16px 48px;",
    "background:#36c;background:linear-gradient(115deg, transparent 75%, rgba(255,255,255,.8) 75%) 0 0,linear-gradient(245deg, transparent 75%, rgba(255,255,255,.8) 75%) 0 0,linear-gradient(115deg, transparent 75%, rgba(255,255,255,.8) 75%) 7px -15px,linear-gradient(245deg, transparent 75%, rgba(255,255,255,.8) 75%) 7px -15px,#36c;background-size: 15px 30px;",
    "background:radial-gradient(circle at 0% 50%, rgba(96, 16, 48, 0) 9px, #613 10px, rgba(96, 16, 48, 0) 11px) 0px 10px,radial-gradient(at 100% 100%,rgba(96, 16, 48, 0) 9px, #613 10px, rgba(96, 16, 48, 0) 11px),#8a3;background-size: 20px 20px;",
    "background-image:linear-gradient(to top, #a18cd1 0%, #fbc2eb 100%)",
    "background-image:linear-gradient(to top, #fbc2eb 0%, #a6c1ee 100%)",
    "background-image:linear-gradient(120deg, #a6c0fe 0%, #f68084 100%)",
    "background-image:linear-gradient(120deg, #e0c3fc 0%, #8ec5fc 100%)",
    "background-image:linear-gradient(to right, #fa709a 0%, #fee140 100%)",
    "background-image:linear-gradient(to top, #30cfd0 0%, #330867 100%)",
    "background-image:linear-gradient(to top, #a8edea 0%, #fed6e3 100%)",
    "background-image:linear-gradient(to top, #d299c2 0%, #fef9d7 100%)",
    "background-image:linear-gradient(to top, #fddb92 0%, #d1fdff 100%)",
    "background-image:linear-gradient(to top, #9890e3 0%, #b1f4cf 100%)",
    "background-image:linear-gradient(to top, #96fbc4 0%, #f9f586 100%)",
    "background-image:linear-gradient(to right, #eea2a2 0%, #bbc1bf 19%, #57c6e1 42%, #b49fda 79%, #7ac5d8 100%)",
    "background-image:linear-gradient(to top, #9795f0 0%, #fbc8d4 100%)",
    "background-image:linear-gradient(to top, #3f51b1 0%, #5a55ae 13%, #7b5fac 25%, #8f6aae 38%, #a86aa4 50%, #cc6b8e 62%, #f18271 75%, #f3a469 87%, #f7c978 100%)",
    "background-image:linear-gradient(to top, #f43b47 0%, #453a94 100%)",
    "background-image:linear-gradient(to top, #88d3ce 0%, #6e45e2 100%)",
    "background-image:linear-gradient(to top, #d9afd9 0%, #97d9e1 100%)",
    "background-image:linear-gradient(-20deg, #b721ff 0%, #21d4fd 100%)",
    "background-image:linear-gradient(60deg, #abecd6 0%, #fbed96 100%)",
    "background-image:linear-gradient(to top, #3b41c5 0%, #a981bb 49%, #ffc8a9 100%)",
    "background-image:linear-gradient(to top, #0fd850 0%, #f9f047 100%)",
    "background-image:linear-gradient(to top, #d5dee7 0%, #ffafbd 0%, #c9ffbf 100%)",
    "background-image:linear-gradient(to top, #65bd60 0%, #5ac1a8 25%, #3ec6ed 50%, #b7ddb7 75%, #fef381 100%)",
    "background-image:linear-gradient(to top, #50cc7f 0%, #f5d100 100%)",
    "background-image:linear-gradient(to top, #df89b5 0%, #bfd9fe 100%)",
    "background-image:linear-gradient(to top, #e14fad 0%, #f9d423 100%)",
    "background-image:linear-gradient(to right, #ec77ab 0%, #7873f5 100%)",
    "background-image:linear-gradient(-225deg, #2CD8D5 0%, #C5C1FF 56%, #FFBAC3 100%)",
    "background-image:linear-gradient(-225deg, #5271C4 0%, #B19FFF 48%, #ECA1FE 100%)",
    "background-image:linear-gradient(-225deg, #FF3CAC 0%, #562B7C 52%, #2B86C5 100%)",
    "background-image:linear-gradient(-225deg, #69EACB 0%, #EACCF8 48%, #6654F1 100%)",
    "background-image:linear-gradient(-225deg, #231557 0%, #44107A 29%, #FF1361 67%, #FFF800 100%)"
];

export class Background {
    public element: HTMLElement;
    public ial: Record<string, string>;
    private imgElement: HTMLImageElement;
    private iconElement: HTMLElement;
    private actionElements: NodeListOf<Element>;
    private tagsElement: HTMLElement;
    private transparentData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
    private dragOccurred = false;

    constructor(protyle: IProtyle) {
        this.element = document.createElement("div");
        this.element.className = "protyle-background";
        this.element.innerHTML = `<div class="protyle-background__img">
    <img src="${this.transparentData}">
    <div class="protyle-icons">
        <span class="protyle-icon protyle-icon--first" style="position: relative;overflow: hidden"><input aria-label="${window.siyuan.languages.upload}" class="ariaLabel b3-form__upload" type="file"><svg><use xlink:href="#iconUpload"></use></svg></span>
        <span class="protyle-icon ariaLabel" data-type="link" aria-label="${window.siyuan.languages.link}"><svg><use xlink:href="#iconLink"></use></svg></span>
        <span class="protyle-icon ariaLabel" data-type="asset" aria-label="${window.siyuan.languages.assets}"><svg><use xlink:href="#iconImage"></use></svg></span>
        <span class="protyle-icon ariaLabel" data-type="show-random" aria-label="${window.siyuan.languages.builtIn}"><svg><use xlink:href="#iconRefresh"></use></svg></span>
        <span class="protyle-icon ariaLabel fn__none" data-type="position" aria-label="${window.siyuan.languages.dragPosition}"><svg><use xlink:href="#iconMove"></use></svg></span>
        <span class="protyle-icon protyle-icon--last ariaLabel" data-type="remove" aria-label="${window.siyuan.languages.remove}"><svg><use xlink:href="#iconTrashcan"></use></svg></span>
    </div>
    <div class="protyle-icons fn__none"><span class="protyle-icon protyle-icon--text">${window.siyuan.languages.dragPosition}</span></div>
    <div class="protyle-icons fn__none" style="opacity: .86;">
        <span class="protyle-icon protyle-icon--first" data-type="cancel">${window.siyuan.languages.cancel}</span>
        <span class="protyle-icon protyle-icon--last" data-type="confirm">${window.siyuan.languages.confirm}</span>
    </div>
</div>
<div class="protyle-background__ia">
    <div class="protyle-background__icon" data-menu="true" data-type="open-emoji"></div>
    <div class="b3-chips b3-chips__doctag fn__none"></div>
    <div class="protyle-background__action">
        <button class="b3-button b3-button--cancel" data-menu="true" data-type="tag">
            <svg><use xlink:href="#iconTags"></use></svg>
            ${window.siyuan.languages.addTag}
        </button>
        <button class="b3-button b3-button--cancel" data-type="icon">
            <svg><use xlink:href="#iconEmoji"></use></svg>
            ${window.siyuan.languages.addIcon}
        </button>
        <button class="b3-button b3-button--cancel" data-type="random">
            <svg><use xlink:href="#iconImage"></use></svg>
            ${window.siyuan.languages.titleBg}
        </button>
    </div>
</div>`;
        this.tagsElement = this.element.querySelector(".b3-chips") as HTMLElement;
        this.iconElement = this.element.querySelector(".protyle-background__icon") as HTMLElement;
        this.imgElement = this.element.querySelector(".protyle-background__img img") as HTMLImageElement;
        this.actionElements = this.element.querySelectorAll(".protyle-background__action:not(.fn__flex-center) .b3-button");

        this.element.addEventListener("dragover", async (event) => {
            event.preventDefault();
        });
        this.element.addEventListener("drop", async (event: DragEvent & { target: HTMLElement }) => {
            if (event.dataTransfer.types[0] === "Files" && event.dataTransfer.files[0].type.indexOf("image") !== -1) {
                uploadFiles(protyle, [event.dataTransfer.files[0]], undefined, (responseText) => {
                    const response = JSON.parse(responseText);
                    const style = `background-image:url("${response.data.succMap[Object.keys(response.data.succMap)[0]]}")`;
                    this.ial["title-img"] = style;
                    this.render(this.ial, protyle.block.rootID);
                    fetchPost("/api/attr/setBlockAttrs", {
                        id: protyle.block.rootID,
                        attrs: {"title-img": style}
                    });
                });
            }
        });
        this.imgElement.addEventListener("mousedown", (event: MouseEvent & { target: HTMLElement }) => {
            event.preventDefault();
            if (!this.element.firstElementChild.querySelector(".protyle-icons").classList.contains("fn__none")) {
                return;
            }
            const y = event.clientY;
            const documentSelf = document;
            const height = this.imgElement.naturalHeight * this.imgElement.clientWidth / this.imgElement.naturalWidth - this.imgElement.clientHeight;
            let originalPositionY = parseFloat(this.imgElement.style.objectPosition.substring(7)) || 50;
            if (this.imgElement.style.objectPosition.endsWith("px")) {
                originalPositionY = -parseInt(this.imgElement.style.objectPosition.substring(7)) / height * 100;
            }
            documentSelf.onmousemove = (moveEvent: MouseEvent) => {
                this.imgElement.style.objectPosition = `center ${((y - moveEvent.clientY) / height * 100 + originalPositionY).toFixed(2)}%`;
                event.preventDefault();
            };

            documentSelf.onmouseup = () => {
                documentSelf.onmousemove = null;
                documentSelf.onmouseup = null;
                documentSelf.ondragstart = null;
                documentSelf.onselectstart = null;
                documentSelf.onselect = null;
            };
        });
        this.element.querySelector("input").addEventListener("change", (event: InputEvent & {
            target: HTMLInputElement
        }) => {
            if (event.target.files.length === 0) {
                return;
            }
            uploadFiles(protyle, event.target.files, event.target, (responseText) => {
                const response = JSON.parse(responseText);
                const style = `background-image:url("${response.data.succMap[Object.keys(response.data.succMap)[0]]}")`;
                this.ial["title-img"] = style;
                this.render(this.ial, protyle.block.rootID);
                fetchPost("/api/attr/setBlockAttrs", {
                    id: protyle.block.rootID,
                    attrs: {"title-img": style}
                });
            });
        });
        this.element.addEventListener("click", (event) => {
            if (this.dragOccurred) {
                this.dragOccurred = false;
                return;
            }
            let target = event.target as HTMLElement;
            hideElements(["gutter"], protyle);

            while (target && !target.isEqualNode(this.element)) {
                const type = target.getAttribute("data-type");
                if (target.tagName === "IMG" && target.parentElement.classList.contains("protyle-background__img")) {
                    const imgSrc = target.getAttribute("src");
                    if (event.detail > 1 && !imgSrc.startsWith("data:image/png;base64")) {
                        previewImages([imgSrc]);
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    // 点击题头图菜单无法消失
                    window.siyuan.menus.menu.remove();
                    break;
                } else if (type === "position" && !protyle.disabled) {
                    const iconElements = this.element.firstElementChild.querySelectorAll(".protyle-icons");
                    iconElements[0].classList.add("fn__none");
                    iconElements[1].classList.remove("fn__none");
                    iconElements[2].classList.remove("fn__none");
                    this.imgElement.style.cursor = "move";
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "cancel" || type === "confirm") {
                    this.imgElement.style.cursor = "";
                    const iconElements = this.element.firstElementChild.querySelectorAll(".protyle-icons");
                    iconElements[0].classList.remove("fn__none");
                    iconElements[1].classList.add("fn__none");
                    iconElements[2].classList.add("fn__none");
                    if (type === "confirm") {
                        const style = `background-image:url("${this.imgElement.getAttribute("src")}");object-position:${this.imgElement.style.objectPosition}`;
                        this.ial["title-img"] = style;
                        fetchPost("/api/attr/setBlockAttrs", {
                            id: protyle.block.rootID,
                            attrs: {"title-img": style}
                        });
                    } else {
                        this.render(this.ial, protyle.block.rootID);
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "open-emoji" && !protyle.disabled) {
                    const rect = this.iconElement.getBoundingClientRect();
                    openEmojiPanel(protyle.block.rootID, "doc", {
                        x: rect.left,
                        y: rect.bottom,
                        h: rect.height,
                        w: rect.width
                    }, undefined, target.querySelector("img"), {ownerElement: protyle.element});
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "show-random" && !protyle.disabled) {
                    window.siyuan.menus.menu.remove();
                    // 内置题头图对话框：优先展示封面图片，加载失败时回退到 CSS 图案
                    const dialog = new Dialog({
                        title: window.siyuan.languages.builtIn,
                        content: `<div class="b3-cards" style="padding:16px;justify-content:center;align-items:center;min-height:200px">
            <img src="/stage/loading-pure.svg" style="width:64px;height:64px">
        </div>`,
                        width: isMobile() ? "92vw" : "912px",
                        height: isMobile() ? "80vh" : "70vh",
                    });
                    dialog.element.setAttribute("data-key", Constants.DIALOG_BACKGROUNDRANDOM);
                    bindPopoverDialog(dialog, protyle.element);

                    const renderCSSPatterns = (d: Dialog) => {
                        let html = "";
                        bgs.forEach((item: string, index: number) => {
                            html += `<div data-index="${index}" style="height: 128px;${item}" class="b3-card"></div>`;
                        });
                        const bodyEl = d.element.querySelector(".b3-dialog__body");
                        if (bodyEl) {
                            bodyEl.innerHTML = `<div class="b3-cards" style="padding: 16px">${html}</div>`;
                        }
                        d.element.addEventListener("click", (event) => {
                            const target = event.target as HTMLElement;
                            if (target.classList.contains("b3-card")) {
                                this.ial["title-img"] = bgs[parseInt(target.getAttribute("data-index"))];
                                this.render(this.ial, protyle.block.rootID);
                                fetchPost("/api/attr/setBlockAttrs", {
                                    id: protyle.block.rootID,
                                    attrs: {"title-img": this.ial["title-img"]}
                                });
                                d.destroy();
                            }
                        });
                    };

                    fetchCoverData().then((coverData) => {
                        if (!coverData) {
                            renderCSSPatterns(dialog);
                            return;
                        }
                        const { categories, coversByCategory, allCovers } = coverData;

                        const buildCards = (category: string): string => {
                            const covers = category === "all" ? allCovers : (coversByCategory.get(category) || []);
                            return covers.map(c => {
                                const url = `/appearance/covers/${c.file}`;
                                return `<div class="b3-card b3-cover__card" data-name="${c.file}"><img src="${url}" loading="lazy"></div>`;
                            }).join("");
                        };

                        const buildTabs = (activeCategory: string): string => {
                            let tabs = `<span class="b3-chip b3-chip--hover${activeCategory === "all" ? " b3-chip--current" : ""}" data-category="all">${window.siyuan.languages.coverAll}</span>`;
                            for (const cat of categories) {
                                tabs += `<span class="b3-chip b3-chip--hover${activeCategory === cat ? " b3-chip--current" : ""}" data-category="${cat}">${getCategoryLabel(cat)}</span>`;
                            }
                            return `<div class="b3-cover__tabs">${tabs}</div>`;
                        };

                        let activeCategory = "all";

                        const renderContent = (): void => {
                            const bodyEl = dialog.element.querySelector(".b3-dialog__body");
                            if (bodyEl) {
                                bodyEl.innerHTML = `${buildTabs(activeCategory)}
        <div class="b3-cards b3-cover__cards" style="padding:16px">${buildCards(activeCategory)}</div>`;
                            }
                        };

                        renderContent();

                        // 点击事件委托
                        dialog.element.querySelector(".b3-dialog__body")!.addEventListener("click", (event) => {
                            const target = event.target as HTMLElement;
                            const chip = target.closest(".b3-chip") as HTMLElement;
                            if (chip && chip.hasAttribute("data-category")) {
                                activeCategory = chip.getAttribute("data-category") || "all";
                                renderContent();
                                dialog.element.querySelector(".b3-dialog__body")!.scrollTop = 0;
                            } else if (target.closest(".b3-cover__card")) {
                                const card = target.closest(".b3-cover__card") as HTMLElement;
                                const name = card.getAttribute("data-name");
                                fetchPost("/api/asset/insertCover", {
                                    id: protyle.block.rootID,
                                    name
                                }, (response) => {
                                    const succMap = response.data.succMap;
                                    const url = succMap[Object.keys(succMap)[0]];
                                    this.ial["title-img"] = `background-image:url("${url}")`;
                                    this.render(this.ial, protyle.block.rootID);
                                    fetchPost("/api/attr/setBlockAttrs", {
                                        id: protyle.block.rootID,
                                        attrs: {"title-img": this.ial["title-img"]}
                                    });
                                });
                                dialog.destroy();
                            }
                        });
                    }).catch(() => {
                        renderCSSPatterns(dialog);
                    });

                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "random" && !protyle.disabled) {
                    // 随机题头图：优先使用图片封面，加载失败时回退到 CSS 图案
                    fetchCoverData().then((coverData) => {
                        if (coverData && coverData.allCovers.length > 0) {
                            const randomCover = coverData.allCovers[getRandom(0, coverData.allCovers.length - 1)];
                            fetchPost("/api/asset/insertCover", {
                                id: protyle.block.rootID,
                                name: randomCover.file
                            }, (response) => {
                                const succMap = response.data.succMap;
                                const url = succMap[Object.keys(succMap)[0]];
                                this.ial["title-img"] = `background-image:url("${url}")`;
                                this.render(this.ial, protyle.block.rootID);
                                fetchPost("/api/attr/setBlockAttrs", {
                                    id: protyle.block.rootID,
                                    attrs: {"title-img": this.ial["title-img"]}
                                });
                            });
                        } else {
                            this.ial["title-img"] = bgs[getRandom(0, bgs.length - 1)];
                            this.render(this.ial, protyle.block.rootID);
                            fetchPost("/api/attr/setBlockAttrs", {
                                id: protyle.block.rootID,
                                attrs: {"title-img": this.ial["title-img"]}
                            });
                        }
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "asset" && !protyle.disabled) {
                    const rect = target.getBoundingClientRect();
                    assetMenu(protyle, {
                        x: target.parentElement.getBoundingClientRect().right,
                        y: rect.bottom + 8,
                        isLeft: true,
                    }, (url) => {
                        this.ial["title-img"] = `background-image:url("${url}")`;
                        this.render(this.ial, protyle.block.rootID);
                        fetchPost("/api/attr/setBlockAttrs", {
                            id: protyle.block.rootID,
                            attrs: {"title-img": this.ial["title-img"]}
                        });
                        /// #if MOBILE
                        window.siyuan.menus.menu.remove();
                        /// #endif
                    }, Constants.SIYUAN_ASSETS_IMAGE);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "remove" && !protyle.disabled) {
                    delete this.ial["title-img"];
                    this.render(this.ial, protyle.block.rootID);
                    fetchPost("/api/attr/setBlockAttrs", {
                        id: protyle.block.rootID,
                        attrs: {"title-img": ""}
                    });
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "icon" && !protyle.disabled) {
                    const emoji = getRandomEmoji();
                    if (emoji) {
                        updateFileTreeEmoji(emoji, protyle.block.rootID);
                        updateOutlineEmoji(emoji, protyle.block.rootID);
                        fetchPost("/api/attr/setBlockAttrs", {
                            id: protyle.block.rootID,
                            attrs: {"icon": emoji}
                        });
                        if (protyle.model) {
                            protyle.model.parent.setDocIcon(emoji);
                        }
                        this.iconElement.classList.remove("fn__none");
                        const rect = this.iconElement.getBoundingClientRect();
                        openEmojiPanel(protyle.block.rootID, "doc", {
                            x: rect.left,
                            y: rect.bottom,
                            h: rect.height,
                            w: rect.width
                        }, undefined, undefined, {ownerElement: protyle.element});
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "tag" && !protyle.disabled) {
                    this.openTag(protyle, target);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "link" && !protyle.disabled) {
                    const dialog = new Dialog({
                        title: window.siyuan.languages.link,
                        width: isMobile() ? "92vw" : "520px",
                        content: `<div class="b3-dialog__content">
        <input class="b3-text-field fn__block" value="${this.imgElement.src.startsWith("data:") ? "" : this.imgElement.getAttribute("src")}">
</div>
<div class="b3-dialog__action">
    <button class="b3-button b3-button--cancel">${window.siyuan.languages.cancel}</button><div class="fn__space"></div>
    <button class="b3-button b3-button--text">${window.siyuan.languages.confirm}</button>
</div>`,
                    });
                    dialog.element.setAttribute("data-key", Constants.DIALOG_BACKGROUNDLINK);
                    bindPopoverDialog(dialog, protyle.element);
                    const btnsElement = dialog.element.querySelectorAll(".b3-button");
                    btnsElement[0].addEventListener("click", () => {
                        dialog.destroy();
                    });
                    btnsElement[1].addEventListener("click", () => {
                        const style = `background-image:url("${dialog.element.querySelector("input").value}");`;
                        this.ial["title-img"] = style;
                        this.render(this.ial, protyle.block.rootID);
                        fetchPost("/api/attr/setBlockAttrs", {
                            id: protyle.block.rootID,
                            attrs: {"title-img": this.ial["title-img"]}
                        });
                        dialog.destroy();
                    });
                    dialog.element.querySelector("input").focus();
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "open-search") {
                    /// #if !MOBILE
                    openGlobalSearch(protyle.app, `#${target.textContent}#`, !window.siyuan.ctrlIsPressed, {method: 0});
                    /// #else
                    popSearch(protyle.app, {
                        hasReplace: false,
                        method: 0,
                        hPath: "",
                        idPath: [],
                        k: `#${target.textContent}#`,
                        r: "",
                        page: 1,
                    });
                    /// #endif
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                } else if (type === "remove-tag" && !protyle.disabled) {
                    target.parentElement.remove();
                    this.removeTag(protyle);
                    event.preventDefault();
                    event.stopPropagation();
                    break;
                }
                target = target.parentElement;
            }
        });

        /// #if !MOBILE
        this.tagsElement.addEventListener("contextmenu", (event: MouseEvent) => {
            if (event.shiftKey || protyle.disabled) {
                return;
            }
            const tagElement = (event.target as HTMLElement).closest(".b3-chip") as HTMLElement;
            if (!tagElement || !this.tagsElement.contains(tagElement)) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            const tagName = tagElement.textContent.trim();
            openDocTagMenu({
                protyle,
                tagElement,
                position: {x: event.clientX, y: event.clientY},
                update: (tag) => {
                    this.updateTag(protyle, tagName, tag);
                },
                remove: () => {
                    this.removeTagByName(protyle, tagName);
                }
            });
        });
        /// #endif

        this.element.addEventListener("mousedown", (event: MouseEvent) => {
            this.dragOccurred = false;
            if (protyle.disabled || event.button !== 0) return;

            const target = event.target as HTMLElement;
            let chipElement = target.closest(".b3-chip") as HTMLElement;

            // 自动定位最近的标签逻辑
            if (!chipElement && target.closest(".b3-chips__doctag")) {
                const rects = Array.from(this.element.querySelectorAll(".b3-chip")).map(el => ({
                    el: el as HTMLElement,
                    rect: el.getBoundingClientRect()
                }));
                if (rects.length > 0) {
                    chipElement = rects.reduce((prev, curr) => {
                        return Math.abs(curr.rect.left + curr.rect.width / 2 - event.clientX) <
                        Math.abs(prev.rect.left + prev.rect.width / 2 - event.clientX) ? curr : prev;
                    }).el;
                }
            }

            if (!chipElement) return;

            event.preventDefault();

            // --- 核心变量初始化 ---
            const startX = event.clientX;
            const startY = event.clientY;
            const initialRect = chipElement.getBoundingClientRect();

            // 计算鼠标点击位置相对于元素左上角的偏移，这是“跟手”的关键
            const offsetX = startX - initialRect.left;
            const offsetY = startY - initialRect.top;

            let isDragging = false;
            let dragClone: HTMLElement | null = null;

            const onMouseMove = (moveEvent: MouseEvent) => {
                const deltaX = moveEvent.clientX - startX;
                const deltaY = moveEvent.clientY - startY;

                // 阈值判断：移动超过 5 像素才视为拖拽，防止手抖误操作
                if (!isDragging) {
                    if (Math.abs(deltaX) < Constants.SIZE_DRAG_THRESHOLD &&
                        Math.abs(deltaY) < Constants.SIZE_DRAG_THRESHOLD) return;
                    isDragging = true;

                    // 创建克隆体
                    dragClone = chipElement.cloneNode(true) as HTMLElement;
                    dragClone.classList.add("b3-chip--dragclone");

                    // 初始样式设置
                    Object.assign(dragClone.style, {
                        position: "fixed",
                        left: `${moveEvent.clientX - offsetX}px`,
                        top: `${moveEvent.clientY - offsetY}px`,
                        width: `${initialRect.width}px`,
                        height: `${initialRect.height}px`,
                        margin: "0",
                        zIndex: "9999",
                        pointerEvents: "none",
                        transition: "none",
                        opacity: "0.8",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
                    });

                    document.body.appendChild(dragClone);
                    chipElement.classList.add("b3-chip--dragging"); // 占位符设为透明/灰色
                    document.body.style.cursor = "grabbing";
                    event.preventDefault();
                }

                if (isDragging && dragClone) {
                    dragClone.style.left = `${moveEvent.clientX - offsetX}px`;
                    dragClone.style.top = `${moveEvent.clientY - offsetY}px`;

                    // 排序碰撞检测
                    const pointTarget = document.elementFromPoint(moveEvent.clientX, moveEvent.clientY);
                    const targetChip = pointTarget?.closest(".b3-chip") as HTMLElement;

                    if (targetChip && targetChip !== chipElement && this.tagsElement.contains(targetChip)) {
                        const rect = targetChip.getBoundingClientRect();
                        // 根据鼠标位置决定插入在目标的前面还是后面
                        if (moveEvent.clientX > rect.left + rect.width / 2) {
                            targetChip.after(chipElement);
                        } else {
                            targetChip.before(chipElement);
                        }
                    }
                }
            };

            const onMouseUp = (upEvent: MouseEvent) => {
                document.onmousemove = null;
                document.onmouseup = null;
                document.body.style.cursor = "";

                if (isDragging) {
                    this.dragOccurred = true;
                    // 阻止拖拽结束后可能触发的点击事件（搜索或打开链接）
                    upEvent.preventDefault();
                    upEvent.stopPropagation();

                    if (dragClone) {
                        dragClone.remove();
                        dragClone = null;
                    }
                    chipElement.classList.remove("b3-chip--dragging");

                    // 持久化排序结果
                    const tags = this.getTags();
                    const tagsString = tags.toString();
                    if (tagsString !== this.ial.tags) {
                        this.ial.tags = tagsString;
                        fetchPost("/api/attr/setBlockAttrs", {
                            id: protyle.block.rootID,
                            attrs: {"tags": tagsString}
                        });
                    }
                }
            };

            document.onmousemove = (e) => onMouseMove(e as MouseEvent);
            document.onmouseup = (e) => onMouseUp(e as MouseEvent);
        });
    }

    private removeTag(protyle: IProtyle, cb?: () => void) {
        this.updateTags(protyle, this.getTags(), cb);
    }

    private removeTagByName(protyle: IProtyle, tagName: string) {
        this.updateTags(protyle, this.getTags().filter((tag) => tag !== tagName));
    }

    private updateTag(protyle: IProtyle, oldTag: string, newTag: string) {
        if (oldTag === newTag) {
            return;
        }
        const tags = this.getTags();
        const index = tags.indexOf(oldTag);
        if (index === -1) {
            return;
        }
        if (newTag) {
            tags[index] = newTag;
        } else {
            tags.splice(index, 1);
        }
        this.updateTags(protyle, Array.from(new Set(tags)));
    }

    private updateTags(protyle: IProtyle, tags: string[], cb?: () => void) {
        const tagsString = tags.toString();
        if (tagsString === (this.ial.tags || "")) {
            cb?.();
            return;
        }
        fetchPost("/api/attr/setBlockAttrs", {
            id: protyle.block.rootID,
            attrs: {"tags": tagsString}
        }, () => {
            cb?.();
        });
        if (tags.length === 0) {
            delete this.ial.tags;
        } else {
            this.ial.tags = tagsString;
        }
        this.render(this.ial, protyle.block.rootID);
    }

    public render(ial: Record<string, string>, rootId: string) {
        const img = ial["title-img"];
        const icon = ial.icon;
        const tags = ial.tags;
        this.ial = ial;
        // 为主题提供样式基础
        this.element.setAttribute("data-node-id", rootId);
        if (tags) {
            let html = "";
            Array.from(new Set(tags.split(",").map(item => item.trim()))).forEach((item) => {
                if (!item.replace(/ /g, "")) {
                    return;
                }
                html += `<div class="b3-chip b3-chip--middle b3-chip--pointer" data-type="open-search">${escapeHtml(item)}<svg class="b3-chip__close" data-type="remove-tag"><use xlink:href="#iconClose"></use></svg></div>`;
            });
            this.tagsElement.innerHTML = `${html}
<div class="protyle-background__action fn__flex-center">
    <button class="b3-button b3-button--cancel" style="margin-bottom: 8px" data-menu="true" data-type="tag"><svg><use xlink:href="#iconAdd"></use></svg>${window.siyuan.languages.addTag}</button>
</div>`;
            this.tagsElement.classList.remove("fn__none");
            this.actionElements[0].classList.add("fn__none");
        } else {
            this.tagsElement.innerHTML = "";
            this.tagsElement.classList.add("fn__none");
            this.actionElements[0].classList.remove("fn__none");
        }

        if (icon) {
            this.iconElement.classList.remove("fn__none");
            this.iconElement.innerHTML = unicode2Emoji(icon);
            this.actionElements[1].classList.add("fn__none");
        } else {
            this.actionElements[1].classList.remove("fn__none");
            this.iconElement.classList.add("fn__none");
        }

        if (img) {
            // 历史数据解析：background-image: url(\"assets/沙发背景墙11-20220418171700-w6vilzt.jpeg\"); background-position: center -254px; background-size: cover; background-repeat: no-repeat; min-height: 30vh
            this.imgElement.setAttribute("style", Lute.UnEscapeHTMLStr(img));
            if (img.indexOf("url(") > -1) {
                const position = this.imgElement.style.backgroundPosition || this.imgElement.style.objectPosition;
                const url = this.imgElement.style.backgroundImage?.replace(/^url\(["']?/, "").replace(/["']?\)$/, "");
                this.imgElement.removeAttribute("style");
                this.imgElement.setAttribute("src", url);
                this.imgElement.style.objectPosition = position;
                this.element.querySelector('[data-type="position"]').classList.remove("fn__none");
            } else {
                this.imgElement.setAttribute("src", this.transparentData);
                this.element.querySelector('[data-type="position"]').classList.add("fn__none");
            }
            this.actionElements[2].classList.add("fn__none");
            this.imgElement.parentElement.classList.remove("fn__none");
            this.iconElement.style.marginTop = "";
            /// #if MOBILE
            // 移动端键盘弹起和点击加号需保持滚动高度一致
            this.imgElement.style.height = "200px";
            /// #endif
        } else {
            this.imgElement.parentElement.classList.add("fn__none");
            this.actionElements[2].classList.remove("fn__none");
            this.iconElement.style.marginTop = "8px";
        }

        if (img || icon) {
            this.iconElement.parentElement.style.marginTop = "";
        } else {
            this.iconElement.parentElement.style.marginTop = "8px";
        }
    }

    private openTag(protyle: IProtyle, target: HTMLElement) {
        window.siyuan.menus.menu.remove();
        const menu = new Menu();
        menu.addItem({
            iconHTML: "",
            type: "empty",
            label: `<div class="fn__flex-column b3-menu__filter">
    <input class="b3-text-field fn__flex-shrink" placeholder="${window.siyuan.languages.tag}"/>
    <div class="fn__hr"></div>
    <div class="b3-list fn__flex-1 b3-list--background">
        <img style="margin: 0 auto;display: block;width: 64px;height: 64px" src="/stage/loading-pure.svg">
    </div>
</div>`,
            bind: (element) => {
                const listElement = element.querySelector(".b3-list--background");
                fetchPost("/api/search/searchTag", {
                    k: "",
                }, (response) => {
                    let html = "";
                    const currentTags = this.getTags();
                    response.data.tags.forEach((item: string, index: number) => {
                        html += `<div class="b3-list-item b3-list-item--narrow${index === 0 ? " b3-list-item--focus" : ""}">
    <div class="fn__flex-1">${item}</div>
    ${currentTags.includes(Lute.UnEscapeHTMLStr(item)) ? '<svg class="b3-menu__checked"><use xlink:href="#iconSelect"></use></svg>' : ""}
</div>`;
                    });
                    listElement.innerHTML = html;
                });
                const inputElement = element.querySelector("input");
                inputElement.addEventListener("keydown", (event: KeyboardEvent) => {
                    event.stopPropagation();
                    if (event.isComposing) {
                        return;
                    }
                    upDownHint(listElement, event);
                    if (event.key === "Enter") {
                        const currentElement = listElement.querySelector(".b3-list-item--focus") as HTMLElement;
                        this.addTags(currentElement ?
                            (currentElement.dataset.type === "new" ? currentElement.querySelector("mark").textContent.trim() : currentElement.textContent.trim()) :
                            inputElement.value.trim(), protyle, () => {
                            inputElement.value = "";
                            inputElement.dispatchEvent(new CustomEvent("input"));
                        });
                    } else if (event.key === "Escape") {
                        window.siyuan.menus.menu.remove();
                    }
                });
                inputElement.addEventListener("input", (event) => {
                    event.stopPropagation();
                    fetchPost("/api/search/searchTag", {
                        k: inputElement.value.trim(),
                    }, (response) => {
                        let searchHTML = "";
                        let hasKey = false;
                        const currentTags = this.getTags();
                        response.data.tags.forEach((item: string, index: number) => {
                            searchHTML += `<div class="b3-list-item b3-list-item--narrow${index === 0 ? " b3-list-item--focus" : ""}">
    <div class="fn__flex-1">${item}</div>
    ${currentTags.includes(Lute.UnEscapeHTMLStr(item.replace(/<mark>/g, "").replace(/<\/mark>/g, ""))) ? '<svg class="b3-menu__checked"><use xlink:href="#iconSelect"></use></svg>' : ""}
</div>`;
                            if (item === `<mark>${response.data.k}</mark>`) {
                                hasKey = true;
                            }
                        });
                        if (!hasKey && response.data.k) {
                            searchHTML = `<div data-type="new" class="b3-list-item b3-list-item--narrow${searchHTML ? "" : " b3-list-item--focus"}"><div class="fn__flex-1">${window.siyuan.languages.new} <mark>${escapeHtml(response.data.k)}</mark></div></div>` + searchHTML;
                        }
                        listElement.innerHTML = searchHTML;
                    });
                });
                listElement.addEventListener("click", (event) => {
                    const target = event.target as HTMLElement;
                    const listItemElement = hasClosestByClassName(target, "b3-list-item");
                    if (!listItemElement) {
                        return;
                    }
                    this.addTags(listItemElement.dataset.type === "new" ? listItemElement.querySelector("mark").textContent.trim() : listItemElement.textContent.trim(),
                        protyle, () => {
                            inputElement.value = "";
                            inputElement.dispatchEvent(new CustomEvent("input"));
                            inputElement.focus();
                        });
                });
            }
        });
        const itemsElement = menu.element.querySelector(".b3-menu__items");
        itemsElement.setAttribute("style", "overflow: initial");
        /// #if MOBILE
        menu.fullscreen("bottom");
        itemsElement.firstElementChild.setAttribute("style", "padding: 0 8px;height: 100%;");
        /// #else
        const rect = target.getBoundingClientRect();
        menu.open({x: rect.left, y: rect.top + rect.height});
        menu.element.querySelector("input").focus();
        /// #endif
    }

    private getTags(removeTag?: string) {
        const tags: string[] = [];
        this.tagsElement.querySelectorAll(".b3-chip").forEach(item => {
            const tagText = item.textContent.trim();
            if (removeTag && tagText === removeTag) {
                item.remove();
            }
            tags.push(tagText);
        });
        return tags;
    }

    private addTags(tag: string, protyle: IProtyle, cb: () => void) {
        const tags = this.getTags(tag);
        if (tags.includes(tag)) {
            this.removeTag(protyle, cb);
            return;
        }
        tags.push(tag);
        fetchPost("/api/attr/setBlockAttrs", {
            id: protyle.block.rootID,
            attrs: {"tags": tags.toString()}
        }, () => {
            cb();
        });
        this.ial.tags = tags.toString();
        this.render(this.ial, protyle.block.rootID);
    }
}
