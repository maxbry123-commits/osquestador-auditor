import {Constants} from "../../constants";
import {hideElements} from "../ui/hideElements";
import {fetchPost} from "../../util/fetch";
import {processRender} from "./processCode";
import {highlightRender} from "../render/highlightRender";
import {blockRender} from "../render/blockRender";
import {bgFade, scrollCenter} from "../../util/highlightById";
/// #if !MOBILE
import {pushBack} from "../../util/backForward";
/// #endif
import {focusBlock, focusByOffset} from "./selection";
import {hasClosestByAttribute} from "./hasClosest";
import {preventScroll} from "../scroll/preventScroll";
import {removeLoading} from "../ui/initUI";
import {isMobile} from "../../util/functions";
import {foldPassiveType} from "../wysiwyg/renderBacklink";
import {showMessage} from "../../dialog/message";
import {avRender} from "../render/av/render";
import {hideTooltip} from "../../dialog/tooltip";
import {stickyRow} from "../render/av/row";
import {getContenteditableElement} from "../wysiwyg/getBlock";
import {activeBlur} from "../../mobile/util/keyboardToolbar";
import {isEncryptedBox} from "../../util/pathName";
import {
    invalidateHeadingNumberRefresh,
    queueHeadingNumberRefresh,
    renderHeadingNumbers
} from "./headingNumber";
import {updateDocumentBottomEof} from "./documentRange";
import {disabledWYSIWYG} from "./disabledWYSIWYG";
import {getEmbeddedDocInfoResponse} from "./docInfo";
import {updateWidgetCacheVersion} from "./widgetCache";
import {normalizeHTMLAssetIFrameSources} from "../../asset/html";
import {hasFocusOffsets} from "./focusRestore";
/// #if MOBILE
import {updateMobileTitleReadonly} from "./setEditMode";
/// #endif

export const onGet = (options: {
    data: IWebSocketData,
    protyle: IProtyle,
    action?: TProtyleAction[],
    scrollAttr?: IScrollAttr
    updateReadonly?: boolean,
    scrollPosition?: ScrollLogicalPosition,
    afterCB?: () => void,
    dataDocType?: string,
    isValid?: () => boolean,
    focusAfterZoom?: boolean,
}) => {
    if (options.isValid && !options.isValid()) {
        return;
    }
    if (!options.action) {
        options.action = [];
    }
    if (!options.action.includes(Constants.CB_GET_APPEND) &&
        !options.action.includes(Constants.CB_GET_BEFORE)) {
        options.protyle.scroll?.invalidateDynamicLoad(options.protyle);
    }
    options.protyle.wysiwyg.element.removeAttribute("data-top");
    if (options.data.code === 1) {
        // 其他报错
        if (!options.action.includes(Constants.CB_GET_APPEND)) {    // 向下加载时块可能还没有创建 https://github.com/siyuan-note/siyuan/issues/10851
            if (options.protyle.model) {
                options.protyle.model.parent.parent.removeTab(options.protyle.model.parent.id);
            } else {
                options.protyle.element.innerHTML = `<div class="ft__smaller ft__secondary b3-form__space--small" contenteditable="false">${window.siyuan.languages.refExpired}</div>`;
            }
        }
        return;
    }
    if (options.data.code === 3) {
        // block not found
        return;
    }
    options.protyle.notebookId = options.data.data.box;
    options.protyle.path = options.data.data.path;

    if (options.data.data.eof && !options.scrollAttr) {
        if (options.action.includes(Constants.CB_GET_BEFORE)) {
            options.protyle.wysiwyg.element.firstElementChild.setAttribute("data-eof", "1");
        } else {
            options.protyle.wysiwyg.element.lastElementChild.setAttribute("data-eof", "2");
        }
        updateDocumentBottomEof(
            options.protyle.wysiwyg.element,
            options.action.includes(Constants.CB_GET_BEFORE)
        );
        if (options.data.data.mode !== 4) {
            return;
        }
    }
    hideElements(["gutterOnly"], options.protyle);
    options.protyle.block.parentID = options.data.data.parentID;
    options.protyle.block.parent2ID = options.data.data.parent2ID;
    options.protyle.block.rootID = options.data.data.rootID;
    options.protyle.block.showAll = options.action.includes(Constants.CB_GET_ALL);
    options.protyle.block.mode = options.data.data.mode;
    options.protyle.block.blockCount = options.data.data.blockCount;
    options.protyle.block.scroll = options.data.data.scroll;
    options.protyle.block.action = options.action;
    const replacesDocument = options.data.data.mode === 0 || options.data.data.mode === 3;
    const refreshHeadingNumbers = replacesDocument && !options.data.data.headingNumbers &&
        window.siyuan.config.editor.headingNumber;
    if (replacesDocument) {
        invalidateHeadingNumberRefresh(options.protyle);
        options.protyle.block.headingNumbers = options.data.data.headingNumbers || {};
    } else if (options.data.data.headingNumbers) {
        options.protyle.block.headingNumbers = options.data.data.headingNumbers;
    }
    if (!options.action.includes(Constants.CB_GET_UNCHANGEID)) {
        options.protyle.block.id = options.data.data.id;    // 非缩放情况时不一定是 rootID（搜索打开页签）；缩放时必为缩放 id，否则需查看代码
        options.protyle.scroll.lastScrollTop = 0;
        options.protyle.contentElement.scrollTop = 0;
        options.protyle.wysiwyg.element.setAttribute("data-doc-type", options.dataDocType || options.data.data.type);
    }

    if (options.protyle.options.render.title && options.protyle.title.element.getAttribute("data-render") !== "true") {
        // 文档A的大纲，关闭文档A后，点击大纲无法渲染头部
    } else if (options.action.includes(Constants.CB_GET_APPEND) || options.action.includes(Constants.CB_GET_BEFORE) || options.action.includes(Constants.CB_GET_HTML)) {
        if (options.protyle.options.render.title && options.protyle.options.render.hideTitleOnZoom) {
            if (options.protyle.block.showAll) {
                options.protyle.title.element.classList.add("fn__none");
            } else {
                options.protyle.title.element.classList.remove("fn__none");
            }
        }
        // 防止动态加载加载过多的内容
        setHTML({
            content: options.data.data.content,
            eof: options.data.data.eof,
            expand: options.data.data.isBacklinkExpand,
            action: options.action,
            scrollAttr: options.scrollAttr,
            updateReadonly: options.updateReadonly,
            isSyncing: options.data.data.isSyncing,
            refreshHeadingNumbers,
            afterCB: options.afterCB,
            scrollPosition: options.scrollPosition,
            focusAfterZoom: options.focusAfterZoom
        }, options.protyle);
        removeLoading(options.protyle);
        return;
    }

    if (options.data.data.publishAccessRequired) {
        setHTML({
            content: options.data.data.content,
            eof: options.data.data.eof,
            expand: options.data.data.isBacklinkExpand,
            action: options.action,
            scrollAttr: options.scrollAttr,
            updateReadonly: options.updateReadonly,
            isSyncing: options.data.data.isSyncing,
            refreshHeadingNumbers,
            afterCB: options.afterCB,
            scrollPosition: options.scrollPosition,
            focusAfterZoom: options.focusAfterZoom
        }, options.protyle);
        removeLoading(options.protyle);
        return;
    }

    const renderDoc = (response: IWebSocketData) => {
        if (options.isValid && !options.isValid()) {
            return;
        }
        if (options.protyle.options.render.title) {
            // 页签没有打开
            options.protyle.title.render(options.protyle, response);
        } else {
            if (options.protyle.options.render.background) {
                options.protyle.background.render(response.data.ial, options.protyle.block.rootID);
            }
            options.protyle.wysiwyg.renderCustom(response.data.ial);
        }

        setHTML({
            content: options.data.data.content,
            eof: options.data.data.eof,
            expand: options.data.data.isBacklinkExpand,
            action: options.action,
            scrollAttr: options.scrollAttr,
            updateReadonly: options.updateReadonly,
            isSyncing: options.data.data.isSyncing,
            refreshHeadingNumbers,
            afterCB: options.afterCB,
            scrollPosition: options.scrollPosition,
            focusAfterZoom: options.focusAfterZoom
        }, options.protyle);
        removeLoading(options.protyle);
    };
    const embeddedDocInfoResponse = getEmbeddedDocInfoResponse(options.data);
    if (embeddedDocInfoResponse) {
        renderDoc(embeddedDocInfoResponse);
        return;
    }

    const docInfoParam: IObject = {
        id: options.protyle.block.rootID
    };
    if (isEncryptedBox(options.protyle.notebookId)) {
        docInfoParam.notebook = options.protyle.notebookId;
    }
    fetchPost("/api/block/getDocInfo", docInfoParam, renderDoc);
};

const setHTML = (options: {
    content: string,
    eof: boolean,
    action?: string[],
    isSyncing: boolean,
    expand: boolean,
    updateReadonly?: boolean,
    scrollAttr?: IScrollAttr,
    scrollPosition?: ScrollLogicalPosition,
    refreshHeadingNumbers?: boolean,
    afterCB?: () => void,
    focusAfterZoom?: boolean,
}, protyle: IProtyle) => {
    if (protyle.contentElement.classList.contains("fn__none") && protyle.wysiwyg.element.innerHTML !== "") {
        return;
    }

    // XSS in inline memo elements https://github.com/siyuan-note/siyuan/issues/15280
    const parser = new DOMParser();
    const doc = parser.parseFromString(options.content, "text/html");
    doc.querySelectorAll("[data-inline-memo-content]").forEach(item => {
        const content = item.getAttribute("data-inline-memo-content");
        if (content) {
            item.setAttribute("data-inline-memo-content", window.DOMPurify.sanitize(content));
        }
    });
    normalizeHTMLAssetIFrameSources(doc);
    updateWidgetCacheVersion(doc, Constants.SIYUAN_VERSION);
    options.content = doc.body.innerHTML;
    const REMOVED_OVER_HEIGHT = protyle.contentElement.clientHeight * 8;
    const updateReadonly = typeof options.updateReadonly === "undefined" ? protyle.wysiwyg.element.innerHTML === "" : options.updateReadonly;
    if (options.action.includes(Constants.CB_GET_APPEND)) {
        // 动态加载移除
        if (!protyle.wysiwyg.element.querySelector(".protyle-wysiwyg--select") &&
            !protyle.scroll.shouldKeepLoadedContent() && protyle.contentElement.scrollHeight > REMOVED_OVER_HEIGHT) {
            let removeElement = protyle.wysiwyg.element.firstElementChild as HTMLElement;
            const removeElements = [];
            while (protyle.wysiwyg.element.childElementCount > 2 && removeElements &&
            protyle.wysiwyg.element.lastElementChild !== removeElement) {
                if (protyle.contentElement.scrollHeight - removeElement.offsetTop > REMOVED_OVER_HEIGHT) {
                    removeElements.push(removeElement);
                } else {
                    break;
                }
                removeElement = removeElement.nextElementSibling as HTMLElement;
            }
            const lastRemoveTop = removeElement.getBoundingClientRect().top;
            removeElements.forEach(item => {
                item.remove();
            });
            protyle.contentElement.scrollTop = protyle.contentElement.scrollTop + (removeElement.getBoundingClientRect().top - lastRemoveTop) - 1;
            protyle.scroll.lastScrollTop = protyle.contentElement.scrollTop;
            hideElements(["toolbar"], protyle);
        }
        protyle.wysiwyg.element.insertAdjacentHTML("beforeend", options.content);
    } else if (options.action.includes(Constants.CB_GET_BEFORE)) {
        const firstElement = protyle.wysiwyg.element.firstElementChild as HTMLElement;
        const lastTop = firstElement.getBoundingClientRect().top;
        protyle.wysiwyg.element.insertAdjacentHTML("afterbegin", options.content);
        protyle.contentElement.scrollTop = protyle.contentElement.scrollTop + (firstElement.getBoundingClientRect().top - lastTop);
        protyle.scroll.lastScrollTop = protyle.contentElement.scrollTop;
        // 动态加载移除
        if (!protyle.wysiwyg.element.querySelector(".protyle-wysiwyg--select") &&
            !protyle.scroll.shouldKeepLoadedContent()) {
            const removeElements: Element[] = [];
            let childCount = protyle.wysiwyg.element.childElementCount;
            let scrollHeight = protyle.contentElement.scrollHeight;
            let lastElement = protyle.wysiwyg.element.lastElementChild;
            while (childCount > 2 && scrollHeight > REMOVED_OVER_HEIGHT && lastElement.getBoundingClientRect().top > window.innerHeight) {
                removeElements.push(lastElement);
                lastElement = lastElement.previousElementSibling;
                childCount--;
                scrollHeight -= lastElement.clientHeight + 8;   // 大部分元素的 margin
            }
            removeElements.forEach((item) => {
                item.remove();
            });
            hideElements(["toolbar"], protyle);
        }
    } else {
        protyle.wysiwyg.element.innerHTML = options.content;
        // 设置 innerHTML 会导致浏览器将 scrollTop 重置为 0，此处立即恢复以避免页面跳转到开头
        // https://github.com/siyuan-note/siyuan/issues/17886
        if (options.scrollAttr && typeof options.scrollAttr.scrollTop === "number") {
            protyle.contentElement.scrollTop = options.scrollAttr.scrollTop;
            protyle.scroll.lastScrollTop = options.scrollAttr.scrollTop;
        }
    }

    if (options.eof) {
        const eofElement = options.action.includes(Constants.CB_GET_BEFORE) ?
            protyle.wysiwyg.element.firstElementChild : protyle.wysiwyg.element.lastElementChild;
        eofElement?.setAttribute("data-eof", options.action.includes(Constants.CB_GET_BEFORE) ? "1" : "2");
    }
    updateDocumentBottomEof(protyle.wysiwyg.element);

    /// #if MOBILE
    protyle.wysiwyg.element.querySelectorAll("video, audio").forEach(item => {
        item.addEventListener("playing", () => {
            activeBlur();
        });
    });
    /// #endif
    // https://github.com/siyuan-note/siyuan/issues/10528
    if (!protyle.block.showAll && protyle.wysiwyg.element.childElementCount === 1 && protyle.wysiwyg.element.firstElementChild.classList.contains("p")) {
        const editElement = getContenteditableElement(protyle.wysiwyg.element.firstElementChild);
        if (editElement && editElement.textContent === "") {
            editElement.classList.add("protyle-wysiwyg--empty");
            /// #if MOBILE
            editElement.setAttribute("placeholder", window.siyuan.languages.emptyMobilePlaceholder);
            /// #else
            editElement.setAttribute("placeholder", window.siyuan.languages.emptyPlaceholder);
            /// #endif
        }
    }

    if (options.action.includes(Constants.CB_GET_BACKLINK)) {
        foldPassiveType(options.expand, protyle.wysiwyg.element);
    }
    processRender(protyle.wysiwyg.element);
    highlightRender(protyle.wysiwyg.element);
    avRender(protyle.wysiwyg.element, protyle);
    blockRender(protyle, protyle.wysiwyg.element);
    renderHeadingNumbers(protyle);
    if (options.refreshHeadingNumbers) {
        queueHeadingNumberRefresh(protyle);
    }
    protyle.databaseAttributePanel?.render();
    if (options.action.includes(Constants.CB_GET_HISTORY)) {
        return;
    }
    if (protyle.options.render.scroll) {
        protyle.scroll.update(protyle);
    }
    if (options.action.includes(Constants.CB_GET_FOCUSFIRST)) {
        // settimeout 时间需短一点，否则定位后快速滚动无效
        const headerHeight = protyle.wysiwyg.element.offsetTop - 16;
        preventScroll(protyle, headerHeight, Constants.TIMEOUT_INPUT);
        protyle.contentElement.scrollTop = headerHeight;
    }
    if (options.isSyncing) {
        disabledForeverProtyle(protyle);
    } else {
        if (protyle.breadcrumb) {
            protyle.breadcrumb.element.nextElementSibling.textContent = "";
        }
        if (protyle.element.hasAttribute("disabled-forever")) {
            if (protyle.wysiwyg.element.getAttribute("custom-sy-readonly") !== "true") {
                protyle.disabled = false;
            }
            protyle.element.removeAttribute("disabled-forever");
        }
        if (options.action.includes(Constants.CB_GET_OPENNEW) && window.siyuan.config.editor.readOnly && !window.siyuan.config.readonly) {
            enableProtyle(protyle);
        } else {
            setReadonlyByConfig(protyle, updateReadonly);
        }
    }

    focusElementById(protyle, options.action, options.scrollAttr, options.scrollPosition, options.focusAfterZoom);

    if (options.action.includes(Constants.CB_GET_SETID) ||
        (protyle.model && !protyle.block.showAll)) {
        // 完整文档在定位后需将 block.id 恢复为 rootID，聚焦状态下则保留聚焦块 ID
        protyle.block.id = protyle.block.rootID;
        protyle.wysiwyg.element.setAttribute("data-doc-type", "NodeDocument");
    }
    protyle.options.defIds?.forEach(item => {
        protyle.wysiwyg.element.querySelectorAll(`[data-id="${item}"]`).forEach(item => {
            item.classList.add("def--mark");
        });
    });
    protyle.options.defIds = [];
    if (options.action.includes(Constants.CB_GET_APPEND) || options.action.includes(Constants.CB_GET_BEFORE)) {
        protyle.app.plugins.forEach(item => {
            item.eventBus.emit("loaded-protyle-dynamic", {
                protyle,
                position: options.action.includes(Constants.CB_GET_APPEND) ? "afterend" : "beforebegin"
            });
        });
        return;
    }

    /// #if MOBILE
    if (protyle.background) {
        protyle.background.element.classList.toggle(
            "protyle-background--mobileshow",
            !options.action.includes(Constants.CB_GET_ALL)
        );
    }
    /// #endif

    if (protyle.options.render.breadcrumb) {
        protyle.breadcrumb.toggleExit(!options.action.includes(Constants.CB_GET_ALL));
        protyle.breadcrumb.render(protyle);
    }
    if (options.afterCB) {
        options.afterCB();
    }
    // 需等待 afterCB 执行后 resize 计算出高度后再进行计算
    // 屏幕太高的页签 https://github.com/siyuan-note/siyuan/issues/5018
    if (options.scrollAttr && !protyle.scroll.element.classList.contains("fn__none") &&
        !protyle.element.classList.contains("block__edit") &&   // 不能为浮窗，否则悬浮为根文档无法打开整个文档 https://github.com/siyuan-note/siyuan/issues/9082
        protyle.wysiwyg.element.lastElementChild.getAttribute("data-eof") !== "2" &&
        protyle.contentElement.scrollHeight > 0 && // 没有激活的页签 https://github.com/siyuan-note/siyuan/issues/5255
        !options.action.includes(Constants.CB_GET_FOCUSFIRST) && // 防止 eof 为true https://github.com/siyuan-note/siyuan/issues/5291
        protyle.contentElement.scrollHeight <= protyle.contentElement.clientHeight) {
        protyle.scroll.loadDynamic(protyle, 2);
    }
    // 动态滚动条拖拽到最后几个块时需多加载一点块 https://github.com/siyuan-note/siyuan/issues/16906
    if (options.action.includes(Constants.CB_GET_FOCUSFIRST) &&
        protyle.wysiwyg.element.getBoundingClientRect().top > protyle.breadcrumb.element.getBoundingClientRect().bottom) {
        protyle.scroll.loadDynamic(protyle, 1);
    }
    if (options.scrollAttr && !protyle.scroll.element.classList.contains("fn__none") && !protyle.element.classList.contains("fn__none")) {
        // 使用动态滚动条定位到最后一个块，重启后无法触发滚动事件，需要再次更新 index
        const startId = options.scrollAttr.startId || protyle.wysiwyg.element.firstElementChild?.getAttribute("data-node-id");
        if (startId) {
            protyle.scroll.updateIndex(protyle, startId, (index) => {
                // https://github.com/siyuan-note/siyuan/issues/8224
                // https://github.com/siyuan-note/siyuan/issues/10716
                if (index > 1 && protyle.block.blockCount > 1 && protyle.contentElement.scrollHeight <= protyle.contentElement.clientHeight) {
                    showMessage(window.siyuan.languages.scrollGetMore);
                }
            });
        }

    }
    protyle.app.plugins.forEach(item => {
        item.eventBus.emit("loaded-protyle-static", {protyle});
    });
};

export const disabledForeverProtyle = (protyle: IProtyle) => {
    disabledProtyle(protyle);
    if (protyle.breadcrumb && !isMobile()) {
        protyle.breadcrumb.element.nextElementSibling.textContent = window.siyuan.languages["_kernel"][81];
    } else {
        showMessage(window.siyuan.languages["_kernel"][81]);
    }
    protyle.element.setAttribute("disabled-forever", "true");
};

/** 禁用编辑器 */
export const disabledProtyle = (protyle: IProtyle) => {
    window.siyuan.menus.menu.remove();
    hideElements(["gutter", "toolbar", "select", "hint", "util"], protyle);
    protyle.disabled = true;
    if (protyle.title && protyle.title.editElement) {
        protyle.title.editElement.setAttribute("contenteditable", "false");
        protyle.title.editElement.style.userSelect = "text";
    }
    /// #if MOBILE
    updateMobileTitleReadonly(protyle);
    /// #endif
    if (protyle.background) {
        protyle.background.element.classList.remove("protyle-background--enable");
    }
    disabledWYSIWYG(protyle.wysiwyg.element);
    if (protyle.breadcrumb) {
        const readonlyButton = protyle.breadcrumb.element.parentElement.querySelector('[data-type="readonly"]');
        readonlyButton.querySelector("use").setAttribute("xlink:href", "#iconLock");
        readonlyButton.setAttribute("aria-label", window.siyuan.config.editor.readOnly ? window.siyuan.languages.tempUnlock : window.siyuan.languages.unlockEdit);
        readonlyButton.setAttribute("data-subtype", "lock");
        const undoElement = protyle.breadcrumb.element.parentElement.querySelector('[data-type="undo"]');
        if (undoElement && !undoElement.classList.contains("fn__none")) {
            undoElement.classList.add("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="redo"]').classList.add("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="indent"]').classList.add("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="outdent"]').classList.add("fn__none");
        }
    }
    hideTooltip();
};

/** 解除编辑器禁用 */
export const enableProtyle = (protyle: IProtyle) => {
    if (protyle.element.getAttribute("disabled-forever") === "true") {
        return;
    }
    protyle.disabled = false;
    if (isMobile()) {
        /// #if MOBILE
        updateMobileTitleReadonly(protyle);
        /// #endif
    }
    protyle.wysiwyg.element.setAttribute("contenteditable", "true");
    protyle.wysiwyg.element.style.userSelect = "";
    // 用于区分移动端样式
    protyle.wysiwyg.element.setAttribute("data-readonly", "false");
    if (protyle.title && protyle.title.editElement) {
        protyle.title.editElement.setAttribute("contenteditable", "true");
        protyle.title.editElement.style.userSelect = "";
    }
    if (protyle.background) {
        protyle.background.element.classList.add("protyle-background--enable");
    }

    protyle.wysiwyg.element.querySelectorAll(".render-node .protyle-action__edit").forEach(item => {
        item.classList.remove("fn__none");
        if (item.classList.contains("protyle-icon--first")) {
            item.nextElementSibling?.classList.remove("protyle-icon--first");
        }
    });
    protyle.wysiwyg.element.querySelectorAll('[contenteditable="false"][spellcheck]').forEach(item => {
        item.setAttribute("contenteditable", "true");
    });
    protyle.wysiwyg.element.querySelectorAll('.protyle-action[draggable="false"]').forEach(item => {
        item.setAttribute("draggable", "true");
    });
    protyle.wysiwyg.element.querySelectorAll(".av").forEach((item: HTMLElement) => {
        stickyRow(item, protyle.contentElement, "all");
    });
    if (protyle.breadcrumb) {
        const readonlyButton = protyle.breadcrumb.element.parentElement.querySelector('[data-type="readonly"]');
        readonlyButton.querySelector("use").setAttribute("xlink:href", "#iconUnlock");
        readonlyButton.setAttribute("aria-label", window.siyuan.config.editor.readOnly ? window.siyuan.languages.cancelTempUnlock : window.siyuan.languages.lockEdit);
        readonlyButton.setAttribute("data-subtype", "unlock");
        const undoElement = protyle.breadcrumb.element.parentElement.querySelector('[data-type="undo"]');
        if (undoElement && undoElement.classList.contains("fn__none")) {
            undoElement.classList.remove("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="redo"]').classList.remove("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="indent"]').classList.remove("fn__none");
            protyle.breadcrumb.element.parentElement.querySelector('[data-type="outdent"]').classList.remove("fn__none");
        }
    }
    hideElements(["gutter"], protyle);
    hideTooltip();
};

const focusElementById = (protyle: IProtyle, action: string[], scrollAttr?: IScrollAttr,
                          scrollPosition?: ScrollLogicalPosition, focusAfterZoom = false) => {
    let focusElement: Element;
    if (scrollAttr && scrollAttr.focusId) {
        focusElement = protyle.wysiwyg.element.querySelector(`[data-node-id="${scrollAttr.focusId}"]`);
    } else {
        Array.from(protyle.wysiwyg.element.querySelectorAll(`[data-node-id="${protyle.block.id}"]`)).find((item: HTMLElement) => {
            if (!hasClosestByAttribute(item, "data-type", "block-render", true)) {
                focusElement = item;
                return true;
            }
        });
    }
    if (!focusElement && protyle.title?.editElement &&
        (protyle.block.id === protyle.block.rootID || scrollAttr?.focusId === protyle.block.rootID)) {
        focusElement = protyle.title.editElement;
    }
    if (protyle.block.mode === 4) {
        preventScroll(protyle);
        focusElement = protyle.wysiwyg.element.lastElementChild;
    } else if (!focusElement || action.includes(Constants.CB_GET_FOCUSFIRST)) {
        focusElement = protyle.wysiwyg.element.firstElementChild;
    }
    if (action.includes(Constants.CB_GET_HL)) {
        preventScroll(protyle); // 搜索页签滚动会导致再次请求
        bgFade(focusElement);
    }
    if (action.includes(Constants.CB_GET_FOCUS) || action.includes(Constants.CB_GET_FOCUSFIRST)) {
        setTimeout(() => {
            let range: Range;
            if (hasFocusOffsets(scrollAttr)) {
                range = focusByOffset(focusElement, scrollAttr.focusStart, scrollAttr.focusEnd) as Range;
            } else {
                range = focusBlock(focusElement, undefined, !action.includes(Constants.CB_GET_OUTLINE),
                    focusAfterZoom) as Range;
            }
            /// #if !MOBILE
            if (!action.includes(Constants.CB_GET_UNUNDO)) {
                pushBack(protyle, range, focusElement);
            }
            /// #endif
        }, focusElement.getAttribute("data-type") === "NodeCodeBlock" ? Constants.TIMEOUT_TRANSITION : 0);
    }
    const hasScrollTop = scrollAttr && typeof scrollAttr.scrollTop === "number";
    if (hasScrollTop) {
        protyle.contentElement.scrollTop = scrollAttr.scrollTop;
    }
    // 下一个请求过来前需断开，否则 observerLoad 重新赋值后无法 disconnect https://ld246.com/article/1704612002446
    protyle.observerLoad?.disconnect();
    if (action.includes(Constants.CB_GET_FOCUS) || action.includes(Constants.CB_GET_SCROLL) || action.includes(Constants.CB_GET_HL) || action.includes(Constants.CB_GET_FOCUSFIRST)) {
        if (!hasScrollTop) {
            scrollCenter(protyle, focusElement, scrollPosition);
        }
    } else {
        return;
    }
    // 加强定位
    // 使用 AbortController 监听用户手势（滚轮/触摸/方向键），一旦用户主动滚动即停止强制定位，否则顶部为数据库等异步渲染块撑高内容时会反复重置滚动位置
    const userScrollAbort = new AbortController();
    const onUserScroll = () => userScrollAbort.abort();
    protyle.contentElement.addEventListener("wheel", onUserScroll, {
        capture: true,
        passive: true,
        signal: userScrollAbort.signal
    });
    protyle.contentElement.addEventListener("touchstart", onUserScroll, {
        capture: true,
        passive: true,
        signal: userScrollAbort.signal
    });
    protyle.contentElement.addEventListener("touchmove", onUserScroll, {
        capture: true,
        passive: true,
        signal: userScrollAbort.signal
    });
    protyle.contentElement.addEventListener("keydown", (event: KeyboardEvent) => {
        // 仅拦截会触发滚动的按键，避免影响正常编辑输入
        if (["PageUp", "PageDown", "Home", "End", "ArrowUp", "ArrowDown", " "].includes(event.key)) {
            userScrollAbort.abort();
        }
    }, {capture: true, signal: userScrollAbort.signal});
    protyle.observerLoad = new ResizeObserver(() => {
        if (userScrollAbort.signal.aborted) {
            // 用户已主动滚动，停止强制定位并将滚动权交还给用户
            protyle.observerLoad.disconnect();
            protyle.observer.observe(protyle.wysiwyg.element);
            return;
        }
        if (hasScrollTop) {
            protyle.contentElement.scrollTop = scrollAttr.scrollTop;
        }
        if (action.includes(Constants.CB_GET_FOCUS) || action.includes(Constants.CB_GET_HL) || action.includes(Constants.CB_GET_FOCUSFIRST)) {
            if (!hasScrollTop) {
                scrollCenter(protyle, focusElement, scrollPosition);
            }
        }
    });
    protyle.observerLoad.observe(protyle.wysiwyg.element);
    protyle.observer.unobserve(protyle.wysiwyg.element);
    setTimeout(() => {
        protyle.observerLoad.disconnect();
        userScrollAbort.abort();
        protyle.observer.observe(protyle.wysiwyg.element);
    }, 1000 * 3);

    if (focusElement === protyle.wysiwyg.element.firstElementChild && !hasScrollTop) {
        protyle.observerLoad.disconnect();
        userScrollAbort.abort();
    }
};

export const setReadonlyByConfig = (protyle: IProtyle, updateReadonly: boolean) => {
    let readOnly = window.siyuan.config.readonly ? "true" : "false";
    if (!updateReadonly) {
        readOnly = protyle.disabled ? "true" : "false";
    } else if (readOnly === "false") {
        readOnly = window.siyuan.config.editor.readOnly ? "true" : "false";
        if (readOnly === "false") {
            readOnly = protyle.wysiwyg.element.getAttribute(Constants.CUSTOM_SY_READONLY);
        }
    }
    if (readOnly === "true") {
        disabledProtyle(protyle);
    } else {
        enableProtyle(protyle);
    }
};
