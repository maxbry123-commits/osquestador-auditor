import {showMessage} from "../dialog/message";
import {hasClosestBlock, hasTopClosestByTag} from "../protyle/util/hasClosest";
/// #if !MOBILE
import {Files} from "../layout/dock/Files";
import {Editor} from "../editor";
import {openFileById} from "../editor/util";
import {getActiveTab, getDockByType} from "../layout/tabUtil";
/// #endif
import {fetchPost, fetchSyncPost} from "./fetch";
import {getDisplayName, getOpenNotebookCount, pathPosix} from "./pathName";
import {Constants} from "../constants";
import {replaceFileName, validateName} from "../editor/rename";
import {hideElements} from "../protyle/ui/hideElements";
import {openMobileFileById} from "../mobile/editor";
import type {App} from "../index";
import {
    NewDocTargetByHPath,
    NewDocTargetSubDoc,
    getNewDocTargetFromSavePath,
    getNewDocTargetFromTree,
    isCurrentDocSubDocTarget
} from "./parseNewDocTarget";
import {focusByRange, selectAll} from "../protyle/util/selection";
import {
    createNewFileSelectionContext,
    isNewFileSelectionValid,
    isRangeInEditor,
    isSameBlockRange,
    isSameRange,
    NewFileSelectionContext
} from "./newFileSelection";
import {getContenteditableElement} from "../protyle/wysiwyg/getBlock";

export const getBlockRefAnchorText = (title: string) => {
    const trimmed = (title || "").trim();
    if (!trimmed) {
        return window.siyuan.languages._kernel[16];
    }
    return trimmed.substring(0, window.siyuan.config.editor.blockRefDynamicAnchorTextMaxLen);
};

type NewDocRequest = {
    app: App;
    notebookId: string;
    currentPath: string;
    /** 是否有来自编辑器或文件树选中项的焦点目标 */
    hasFocusTarget: boolean;
    name?: string;
    paths?: string[];
    listDocTree?: boolean;
    onCreated?: (id: string, title: string) => void;
};

/** 按配置路径创建文档；从聚焦编辑器或文件树推断上下文；可选 name 指定文档名 */
export const newFile = (app: App, name?: string) => {
    if (getOpenNotebookCount() === 0) {
        showMessage(window.siyuan.languages.newFileTip);
        return;
    }
    const {notebookId, currentPath, hasFocusTarget} = getNewFilePath();
    if (name === undefined) {
        runNewDoc({
            app,
            notebookId,
            currentPath,
            hasFocusTarget,
        });
    } else {
        runNewDoc({
            app,
            notebookId,
            currentPath,
            hasFocusTarget,
            name: replaceFileName(name.trim()),
            onCreated: () => hideElements(["dialog"]),
        });
    }
};

export const newFileInProtyle = (protyle: IProtyle, onCreated: (id: string, title: string) => void) => {
    runNewDoc({
        app: protyle.app,
        notebookId: protyle.notebookId,
        currentPath: protyle.path,
        hasFocusTarget: true,
        onCreated,
    });
};

export const newFileInTree = (app: App, notebookId: string, currentPath: string, paths?: string[]) => {
    runNewDocInTree({
        app,
        notebookId,
        currentPath,
        hasFocusTarget: true,
        paths,
        listDocTree: true,
    });
};

const insertNewFileRef = (protyle: IProtyle, context: NewFileSelectionContext, id: string, refText: string,
                          refSubtype: "d" | "s") => {
    if (!isNewFileSelectionValid(protyle, context)) {
        return;
    }
    const selection = document.getSelection();
    const currentRange = selection?.rangeCount ? selection.getRangeAt(0).cloneRange() : undefined;
    const selectionMoved = currentRange && !isSameRange(currentRange, context.range);
    protyle.toolbar.range = context.range;
    const anchorText = refSubtype === "s" ? getBlockRefAnchorText(context.text) : refText;
    const refElements = protyle.toolbar.setInlineMark(protyle, "block-ref", "range", {
        type: "id",
        color: `${id}${Constants.ZWSP}${refSubtype}${Constants.ZWSP}${anchorText}`
    }, false, context.undoContext);
    if (!refElements?.[0]) {
        return;
    }
    const refRange = protyle.toolbar.range;
    refRange.selectNodeContents(refElements[0]);
    if (selectionMoved) {
        if (isRangeInEditor(protyle.wysiwyg.element, currentRange)) {
            protyle.toolbar.range = currentRange;
            focusByRange(currentRange);
        }
    } else {
        focusByRange(refRange);
    }
};

export const newFileBySelect = (protyle: IProtyle, newFileName: string, context: NewFileSelectionContext,
                                pathDir: string, targetNotebookId: string, refSubtype: "d" | "s" = "d") => {
    if (!isNewFileSelectionValid(protyle, context)) {
        return;
    }
    const hPath = pathPosix().join(pathDir, newFileName || window.siyuan.languages._kernel[16]);
    fetchPost("/api/filetree/getIDsByHPath", {
        path: hPath,
        notebook: targetNotebookId
    }, (idResponse) => {
        const refText = getBlockRefAnchorText(newFileName);
        if (idResponse.data && idResponse.data.length > 0) {
            insertNewFileRef(protyle, context, idResponse.data[0], refText, refSubtype);
        } else {
            if (!isNewFileSelectionValid(protyle, context)) {
                return;
            }
            fetchPost("/api/filetree/createDocWithMd", {
                notebook: targetNotebookId,
                path: hPath,
                parentID: context.notebookId === targetNotebookId ? context.rootID : "",
                markdown: "",
                titleEmpty: newFileName === "",
            }, response => {
                insertNewFileRef(protyle, context, response.data, refText, refSubtype);
            });
        }
    });
};

export const newFileBySelectRange = (protyle: IProtyle, range: Range, target: "subDoc" | "configured",
                                     refSubtype: "d" | "s" = "d", name?: string,
                                     undoContext?: Record<string, string>) => {
    if (!isSameBlockRange(range)) {
        return;
    }
    const nodeElement = hasClosestBlock(range.startContainer);
    if (!nodeElement) {
        return;
    }
    const selectText = range.toString();
    if (!selectText.trim() && (nodeElement.querySelector("tr") || nodeElement.querySelector("span"))) {
        // 没选中时，都是纯文本就创建子文档 https://ld246.com/article/1663073488381/comment/1664804353295#comments
        return;
    }
    if (!selectText.trim() &&
        getContenteditableElement(nodeElement).textContent // https://github.com/siyuan-note/siyuan/issues/8099
    ) {
        selectAll(protyle, nodeElement, range);
    }
    const selectionContext = createNewFileSelectionContext(protyle, range, undoContext);
    if (!selectionContext) {
        return;
    }
    const sourceNotebookId = selectionContext.notebookId;
    const sourcePath = selectionContext.path;
    const fileName = name === undefined ? (selectText.trim() ||
        protyle.lute.BlockDOM2Content(nodeElement.outerHTML).replace(/\n/g, "").trim()) : name.trim();
    const newFileName = replaceFileName(fileName);
    if (target === "subDoc") {
        fetchPost("/api/filetree/getHPathByPath", {
            notebook: sourceNotebookId,
            path: sourcePath,
        }, (response) => {
            newFileBySelect(protyle, newFileName, selectionContext, response.data, sourceNotebookId, refSubtype);
        });
    } else {
        getRefCreateSavePath(sourceNotebookId, sourcePath, (targetNotebookId, hPath) => {
            newFileBySelect(protyle, newFileName, selectionContext, hPath, targetNotebookId, refSubtype);
        });
    }
    hideElements(["toolbar"], protyle);
};

export const getRefCreateSavePath = (notebookId: string, currentPath: string, cb: (targetNotebookId: string, hPath: string) => void) => {
    fetchPost("/api/filetree/getRefCreateSavePath", {
        notebook: notebookId
    }, (data) => {
        let targetPath = currentPath;
        if (notebookId !== data.data.box) {
            targetPath = data.data.path || "/";
        }
        if (data.data.path) {
            if (data.data.path.startsWith("/")) {
                cb(data.data.box, getDisplayName(data.data.path, false, true));
            } else {
                fetchPost("/api/filetree/getHPathByPath", {
                    notebook: data.data.box,
                    path: targetPath
                }, (response) => {
                    cb(data.data.box, getDisplayName(pathPosix().join(response.data, data.data.path), false, true));
                });
            }
        } else {
            fetchPost("/api/filetree/getHPathByPath", {
                notebook: data.data.box,
                path: targetPath
            }, (response) => {
                cb(data.data.box, getDisplayName(response.data, false, true));
            });
        }
    });
};

function getNewFilePath(): Pick<NewDocRequest, "notebookId" | "currentPath" | "hasFocusTarget"> {
    let notebookId = "";
    let currentPath = "";
    let hasFocusTarget = false;
    /// #if !MOBILE
    const tab = getActiveTab(false);
    if (tab?.model instanceof Editor) {
        notebookId = tab.model.editor.protyle.notebookId;
        currentPath = tab.model.editor.protyle.path;
        hasFocusTarget = true;
    }
    if (!notebookId) {
        const fileModel = getDockByType("file").data.file;
        if (fileModel instanceof Files) {
            const currentElement = fileModel.element.querySelector(".b3-list-item--focus");
            if (currentElement) {
                const topElement = hasTopClosestByTag(currentElement, "UL");
                if (topElement) {
                    notebookId = topElement.getAttribute("data-url");
                }
                currentPath = currentElement.getAttribute("data-path");
                hasFocusTarget = true;
            }
        }
    }
    /// #else
    if (window.siyuan.mobile.editor && document.getElementById("empty").classList.contains("fn__none")) {
        notebookId = window.siyuan.mobile.editor.protyle.notebookId;
        currentPath = window.siyuan.mobile.editor.protyle.path;
        hasFocusTarget = true;
    }
    /// #endif
    if (!notebookId) {
        const openNotebook = window.siyuan.notebooks.find(item => !item.closed);
        if (openNotebook) {
            notebookId = openNotebook.id;
            currentPath = "/";
        }
    }
    return {notebookId, currentPath, hasFocusTarget};
}

function runNewDoc(request: NewDocRequest) {
    fetchPost("/api/filetree/getDocCreateSavePath", {notebook: request.notebookId}, (savePathResponse) => {
        const templatePath = savePathResponse.data.path as string;
        const docCreateTemplatePath = savePathResponse.data.docCreateTemplatePath as string;
        const targetNotebookId = savePathResponse.data.box as string;
        getNewDocHPath(targetNotebookId, request.notebookId, request.currentPath, (hPath) => {
            createNewDoc(request, templatePath, docCreateTemplatePath, targetNotebookId, hPath);
        });
    });
}

function getNewDocHPath(targetNotebookId: string, currentNotebookId: string, currentPath: string, callback: (hPath: string) => void) {
    if (targetNotebookId !== currentNotebookId) {
        // 跨笔记本时当前文档路径在目标笔记本中不存在，直接按目标笔记本根路径解析
        callback("/");
        return;
    }
    fetchPost("/api/filetree/getHPathByPath", {
        notebook: targetNotebookId,
        path: currentPath,
    }, (hPathResponse) => {
        callback(hPathResponse.data);
    });
}

/** 判断配置的新建位置是否与在当前文档下直接创建子文档等价 */
export const isConfiguredCreateTargetCurrentSubDoc = async (
    protyle: IProtyle,
    type: "doc" | "ref",
) => {
    if (!protyle.notebookId || !protyle.path) {
        return false;
    }
    const savePathResponse = await fetchSyncPost(
        type === "doc" ? "/api/filetree/getDocCreateSavePath" : "/api/filetree/getRefCreateSavePath",
        {notebook: protyle.notebookId},
    );
    if (savePathResponse.code !== 0 || !savePathResponse.data) {
        return false;
    }
    const targetNotebookId = savePathResponse.data.box as string;
    if (targetNotebookId !== protyle.notebookId) {
        return false;
    }
    const templatePath = (savePathResponse.data.path as string || "").trim();
    if (!templatePath) {
        return true;
    }
    const hPathResponse = await fetchSyncPost("/api/filetree/getHPathByPath", {
        notebook: protyle.notebookId,
        path: protyle.path,
    });
    if (hPathResponse.code !== 0 || typeof hPathResponse.data !== "string") {
        return false;
    }
    const title = type === "ref" ? "__siyuan_ref_target__" : "";
    const target = getNewDocTargetFromSavePath({
        templatePath,
        hPath: hPathResponse.data || "/",
        targetNotebookId,
        currentNotebookId: protyle.notebookId,
        name: title || undefined,
        hasFocusTarget: true,
        currentPath: protyle.path,
    });
    return isCurrentDocSubDocTarget({
        target,
        currentNotebookId: protyle.notebookId,
        currentPath: protyle.path,
        currentHPath: hPathResponse.data || "/",
        title,
    });
};

function createNewDoc(request: NewDocRequest, templatePath: string, docCreateTemplatePath: string,
                      targetNotebookId: string, hPath: string) {
    const target = getNewDocTargetFromSavePath({
        templatePath,
        hPath: hPath || "/",
        targetNotebookId,
        currentNotebookId: request.notebookId,
        name: request.name,
        hasFocusTarget: request.hasFocusTarget,
        currentPath: request.currentPath,
    });
    if (target.kind === "hPath") {
        createNewDocByHPath(request, target, docCreateTemplatePath);
    } else if (target.kind === "subDoc") {
        createNewDocAsSubDoc(request, target, docCreateTemplatePath);
    }
}

function runNewDocInTree(request: NewDocRequest) {
    fetchPost("/api/filetree/getDocCreateSavePath", {notebook: request.notebookId}, (savePathResponse) => {
        const target = getNewDocTargetFromTree({
            templatePath: savePathResponse.data.path as string,
            currentNotebookId: request.notebookId,
            currentPath: request.currentPath,
            name: request.name,
        });
        createNewDocAsSubDoc(request, target, savePathResponse.data.docCreateTemplatePath as string);
    });
}

/** 同笔记本 + 有聚焦 + 非根路径 时取当前文档 ID */
function getCreateDocParentID(hasFocusTarget: boolean, notebookId: string, currentPath: string, targetNotebookId: string): string | undefined {
    return hasFocusTarget && notebookId === targetNotebookId && currentPath !== "/"
        ? getDisplayName(currentPath, true, true)
        : undefined;
}

function createNewDocByHPath(request: NewDocRequest, target: NewDocTargetByHPath, docCreateTemplatePath: string) {
    if (target.title && !validateName(target.title)) {
        return;
    }
    const parentID = getCreateDocParentID(request.hasFocusTarget, request.notebookId, request.currentPath, target.targetNotebookId);
    fetchPost("/api/filetree/createDocWithMd", {
        notebook: target.targetNotebookId,
        path: target.hPath,
        parentID,
        markdown: "",
        titleEmpty: !target.title,
        docCreateTemplatePath,
    }, (response) => {
        openCreatedDoc(request.app, response.data, request.onCreated, target.title);
    });
}

function createNewDocAsSubDoc(request: NewDocRequest, target: NewDocTargetSubDoc, docCreateTemplatePath: string) {
    const id = Lute.NewNodeID();
    const newPath = pathPosix().join(getDisplayName(target.parentPath, false, true), id + ".sy");
    if (request.paths) {
        request.paths[request.paths.indexOf(undefined)] = newPath;
    }
    fetchPost("/api/filetree/createDoc", {
        notebook: target.targetNotebookId,
        path: newPath,
        title: target.title,
        md: "",
        docCreateTemplatePath,
        sorts: request.paths,
        listDocTree: request.listDocTree,
    }, () => {
        openCreatedDoc(request.app, id, request.onCreated, target.title);
    });
}

export const getDocCreateTemplatePath = (notebookId: string, callback: (templatePath: string) => void) => {
    fetchPost("/api/filetree/getDocCreateSavePath", {notebook: notebookId}, (response) => {
        callback(response.data.docCreateTemplatePath as string);
    });
};

function openCreatedDoc(app: App, id: string, onCreated?: (id: string, title: string) => void, title?: string) {
    if (onCreated) {
        onCreated(id, title || "");
    }
    /// #if !MOBILE
    openFileById({
        app,
        id,
        action: [Constants.CB_GET_CONTEXT, Constants.CB_GET_OPENNEW]
    });
    /// #else
    openMobileFileById(app, id, [Constants.CB_GET_CONTEXT, Constants.CB_GET_OPENNEW]);
    /// #endif
}

/**
 * 块引新建文档。
 * 
 * 与 `newFile` 入口路径解析规则对齐；创建后仅回调插入引用，不打开新文档页签。
 * 独立于 `runNewDoc` 编排，避免给通用入口引入块引专用参数。
 */
export const newFileByRefHint = (
    protyle: IProtyle,
    name: string,
    onCreated?: (id: string, title: string) => void,
    presetId?: string,
) => {
    const requestName = replaceFileName(name.trim());
    fetchPost("/api/filetree/getRefCreateSavePath", {notebook: protyle.notebookId}, (savePathResponse) => {
        const templatePath = savePathResponse.data.path as string;
        const targetNotebookId = savePathResponse.data.box as string;
        getNewDocHPath(targetNotebookId, protyle.notebookId, protyle.path, (hPath) => {
            const target = getNewDocTargetFromSavePath({
                templatePath,
                hPath: hPath || "/",
                targetNotebookId,
                currentNotebookId: protyle.notebookId,
                name: requestName,
                hasFocusTarget: true,
                currentPath: protyle.path,
            });
            if (target.kind === "hPath") {
                createRefDocByHPath(protyle, target, onCreated, presetId);
            } else {
                createRefDocAsSubDoc(target, onCreated, presetId);
            }
        });
    });
};

/** 在当前文档下新建子文档，创建后仅回调插入引用或绑定数据库条目 */
export const newSubDocByRefHint = (
    protyle: IProtyle,
    name: string,
    onCreated?: (id: string, title: string) => void,
    presetId?: string,
) => {
    const target = getNewDocTargetFromTree({
        templatePath: "",
        currentNotebookId: protyle.notebookId,
        currentPath: protyle.path,
        name: replaceFileName(name.trim()),
    });
    createRefDocAsSubDoc(target, onCreated, presetId);
};

function createRefDocByHPath(
    protyle: IProtyle,
    target: NewDocTargetByHPath,
    onCreated?: (id: string, title: string) => void,
    presetId?: string,
) {
    if (target.title && !validateName(target.title)) {
        return;
    }
    const parentID = getCreateDocParentID(true, protyle.notebookId, protyle.path, target.targetNotebookId);
    fetchPost("/api/filetree/createDocWithMd", {
        notebook: target.targetNotebookId,
        path: target.hPath,
        parentID,
        markdown: "",
        titleEmpty: !target.title,
        id: presetId,
    }, (response) => {
        onCreated?.(response.data, target.title || "");
    });
}

function createRefDocAsSubDoc(
    target: NewDocTargetSubDoc,
    onCreated?: (id: string, title: string) => void,
    presetId?: string,
) {
    const id = presetId || Lute.NewNodeID();
    const newPath = pathPosix().join(getDisplayName(target.parentPath, false, true), id + ".sy");
    fetchPost("/api/filetree/createDoc", {
        notebook: target.targetNotebookId,
        path: newPath,
        title: target.title,
        md: "",
    }, () => {
        onCreated?.(id, target.title || "");
    });
}
