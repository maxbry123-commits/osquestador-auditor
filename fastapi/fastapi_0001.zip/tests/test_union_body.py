from fastapi import FastAPI
from fastapi.testclient import TestClient
from inline_snapshot import snapshot
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str | None = None


class OtherItem(BaseModel):
    price: int


@app.post("/items/")
def save_union_body(item: OtherItem | Item):
    return {"item": item}


client = TestClient(app)


def test_post_other_item():
    response = client.post("/items/", json={"price": 100})
    assert response.status_code == 200, response.text
    assert response.json() == {"item": {"price": 100}}


def test_post_item():
    response = client.post("/items/", json={"name": "Foo"})
    assert response.status_code == 200, response.text
    assert response.json() == {"item": {"name": "Foo"}}


def test_openapi_schema():
    response = client.get("/openapi.json")
    assert response.status_code == 200, response.text
    assert response.json() == snapshot(
        {
            "openapi": "3.1.0",
            "info": {"title": "FastAPI", "version": "0.1.0"},
            "paths": {
                "/items/": {
                    "post": {
                        "responses": {
                            "200": {
                                "description": "Successful Response",
                                "content": {"application/json": {"schema": {}}},
                            },
                            "422": {
                                "description": "Validation Error",
                                "content": {
                                    "application/json": {
                                        "schema": {
                                            "$ref": "#/components/schemas/HTTPValidationError"
                                        }
                                    }
                                },
                            },
                        },
                        "summary": "Save Union Body",
                        "operationId": "save_union_body_items__post",
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "title": "Item",
                                        "anyOf": [
                                            {"$ref": "#/components/schemas/OtherItem"},
                                            {"$ref": "#/components/schemas/Item"},
                                        ],
                                    }
                                }
                            },
                            "required": True,
                        },
                    }
                }
            },
            "components": {
                "schemas": {
                    "OtherItem": {
                        "title": "OtherItem",
                        "required": ["price"],
                        "type": "object",
                        "properties": {"price": {"title": "Price", "type": "integer"}},
                    },
                    "Item": {
                        "title": "Item",
                        "type": "object",
                        "properties": {
                            "name": {
                                "title": "Name",
                                "anyOf": [{"type": "string"}, {"type": "null"}],
                            }
                        },
                    },
                    "ValidationError": {
                        "title": "ValidationError",
                        "required": ["loc", "msg", "type"],
                        "type": "object",
                        "properties": {
                            "loc": {
                                "title": "Location",
                                "type": "array",
                                "items": {
                                    "anyOf": [{"type": "string"}, {"type": "integer"}]
                                },
                            },
                            "msg": {"title": "Message", "type": "string"},
                            "type": {"title": "Error Type", "type": "string"},
                            "input": {"title": "Input"},
                            "ctx": {"title": "Context", "type": "object"},
                        },
                    },
                    "HTTPValidationError": {
                        "title": "HTTPValidationError",
                        "type": "object",
                        "properties": {
                            "detail": {
                                "title": "Detail",
                                "type": "array",
                                "items": {
                                    "$ref": "#/components/schemas/ValidationError"
                                },
                            }
                        },
                    },
                }
            },
        }
    )
