# 在云服务商上部署 FastAPI { #deploy-fastapi-on-cloud-providers }

你几乎可以使用**任何云服务商**来部署你的 FastAPI 应用。

在大多数情况下，主流云服务商都有部署 FastAPI 的指南。

## FastAPI Cloud { #fastapi-cloud }

**[FastAPI Cloud](https://fastapicloud.com)** 由 **FastAPI** 背后的同一作者与团队打造。

它简化了**构建**、**部署**和**访问** API 的流程，几乎不费力。

它把使用 FastAPI 构建应用时相同的**开发者体验**带到了将应用**部署**到云上的过程。🎉

FastAPI Cloud 是 *FastAPI and friends* 开源项目的主要赞助方和资金提供者。✨

## 云服务商 - 赞助商 { #cloud-providers-sponsors }

还有一些云服务商也会 ✨ [**赞助 FastAPI**](https://github.com/sponsors/tiangolo) ✨。🙇

你也可以考虑按照他们的指南尝试他们的服务：

* [Render](https://docs.render.com/deploy-fastapi?utm_source=deploydoc&utm_medium=referral&utm_campaign=fastapi)
* [Railway](https://docs.railway.com/guides/fastapi?utm_medium=integration&utm_source=docs&utm_campaign=fastapi)
