# 特性 { #features }

## FastAPI 特性 { #fastapi-features }

**FastAPI** 提供了以下内容：

### 基于开放标准 { #based-on-open-standards }

* [**OpenAPI**](https://github.com/OAI/OpenAPI-Specification) 用于创建 API，包含对<dfn title="也称为：端点、路由">路径</dfn> <dfn title="也称为 HTTP 方法，如 POST、GET、PUT、DELETE">操作</dfn>、参数、请求体、安全等的声明。
* 使用 [**JSON Schema**](https://json-schema.org/) 自动生成数据模型文档（因为 OpenAPI 本身就是基于 JSON Schema 的）。
* 经过了缜密的研究后围绕这些标准而设计。并非狗尾续貂。
* 这也允许了在很多语言中自动**生成客户端代码**。

### 自动生成文档 { #automatic-docs }

交互式 API 文档以及具探索性 web 界面。因为该框架是基于 OpenAPI，所以有很多可选项，FastAPI 默认自带两个交互式 API 文档。

* [**Swagger UI**](https://github.com/swagger-api/swagger-ui)，可交互式操作，能在浏览器中直接调用和测试你的 API。

![Swagger UI interaction](https://fastapi.tiangolo.com/img/index/index-03-swagger-02.png)

* 另外的 API 文档：[**ReDoc**](https://github.com/Redocly/redoc)。

![ReDoc](https://fastapi.tiangolo.com/img/index/index-06-redoc-02.png)

### 就是现代 Python { #just-modern-python }

全部都基于标准的 **Python 类型** 声明（感谢 Pydantic）。没有新的语法需要学习。只需要标准的现代 Python。

如果你需要2分钟来学习如何使用 Python 类型（即使你不使用 FastAPI），看看这个简短的教程：[Python 类型](python-types.md)。

编写带有类型标注的标准 Python：

```Python
from datetime import date

from pydantic import BaseModel

# 将变量声明为 str
# 并在函数内获得编辑器支持
def main(user_id: str):
    return user_id


# 一个 Pydantic 模型
class User(BaseModel):
    id: int
    name: str
    joined: date
```

可以像这样来使用：

```Python
my_user: User = User(id=3, name="John Doe", joined="2018-07-19")

second_user_data = {
    "id": 4,
    "name": "Mary",
    "joined": "2018-11-30",
}

my_second_user: User = User(**second_user_data)
```


/// note | 注意

`**second_user_data` 意思是：

直接将 `second_user_data` 字典的键和值作为 key-value 参数传入，等同于：`User(id=4, name="Mary", joined="2018-11-30")`

///

### 编辑器支持 { #editor-support }

整个框架都被设计得易于使用且直观，所有的决定都在开发之前就在多个编辑器上进行了测试，来确保最佳的开发体验。

在 Python 开发者调查中，我们能看到[被使用最多的功能之一是“自动补全”](https://www.jetbrains.com/research/python-developers-survey-2017/#tools-and-features)。

整个 **FastAPI** 框架就是基于这一点的。任何地方都可以进行自动补全。

你几乎不需要经常回来看文档。

在这里，你的编辑器可能会这样帮助你：

* 在 [Visual Studio Code](https://code.visualstudio.com/) 中:

![editor support](https://fastapi.tiangolo.com/img/vscode-completion.png)

* 在 [PyCharm](https://www.jetbrains.com/pycharm/) 中:

![editor support](https://fastapi.tiangolo.com/img/pycharm-completion.png)

你将能进行代码补全，这是在之前你可能曾认为不可能的事。例如，在来自请求 JSON 体（可能是嵌套的）中的键 `price`。

不会再输错键名，来回翻看文档，或者来回滚动寻找你最后使用的 `username` 或者 `user_name`。

### 简洁 { #short }

任何类型都有合理的**默认值**，任何地方都有可选配置。所有的参数被微调，来满足你的需求，定义成你需要的 API。

但是默认情况下，一切都能**“顺利工作”**。

### 验证 { #validation }

* 校验大部分（甚至所有？）的 Python **数据类型**，包括：
    * JSON 对象 (`dict`)。
    * JSON 数组 (`list`) 定义成员类型。
    * 字符串 (`str`) 字段，定义最小或最大长度。
    * 数字 (`int`, `float`) 有最大值和最小值，等等。

* 校验更特殊的类型，比如：
    * URL。
    * Email。
    * UUID。
    * ...及其他。

所有的校验都由完善且强大的 **Pydantic** 处理。

### 安全性及身份验证 { #security-and-authentication }

集成了安全性和身份验证。不需要在数据库或数据模型上作出任何妥协。

OpenAPI 中定义的所有安全模式，包括：

* HTTP 基本认证。
* **OAuth2**（也使用 **JWT tokens**）。在 [使用 JWT 的 OAuth2](tutorial/security/oauth2-jwt.md) 查看教程。
* API 密钥，在:
    * 请求头。
    * 查询参数。
    * Cookies，等等。

加上来自 Starlette（包括 **session cookies**）的所有安全特性。

所有的这些都是可复用的工具和组件，可以轻松与你的系统，数据仓库，关系型以及 NoSQL 数据库等等集成。

### 依赖注入 { #dependency-injection }

FastAPI 有一个使用非常简单，但是非常强大的<dfn title='也称为 "components"、"resources"、"services"、"providers"'><strong>依赖注入</strong></dfn>系统。

* 甚至依赖也可以有依赖，创建一个层级或者**“图”依赖**。
* 所有**自动化处理**都由框架完成。
* 所有的依赖关系都可以从请求中获取数据，并且**增加了路径操作**约束和自动文档生成。
* 即使是在依赖项中定义的*路径操作*参数也会**自动验证**。
* 支持复杂的用户身份认证系统，**数据库连接**等等。
* **不依赖**数据库，前端等。但是和它们集成很简单。

### 无限制的“插件” { #unlimited-plug-ins }

或者说，导入并使用你需要的代码，而不需要它们。

任何集成都被设计得被易于使用（用依赖关系），你可以用和*路径操作*相同的结构和语法，在两行代码中为你的应用创建一个“插件”。

### 测试 { #tested }

* 100% <dfn title="自动测试的代码量">测试覆盖</dfn>。
* 代码库100% <dfn title="Python 类型注解，有了这个你的编辑器和外部工具可以给你更好的支持">类型标注</dfn>。
* 用于生产应用。

## Starlette 特性 { #starlette-features }

**FastAPI** 与 [**Starlette**](https://starlette.dev/) 完全兼容（并基于它构建）。所以，你有的其他的 Starlette 代码也能正常工作。

`FastAPI` 实际上是 `Starlette` 的一个子类。所以，如果你已经知道或者使用 Starlette，大部分的功能会以相同的方式工作。

通过 **FastAPI** 你可以获得所有 **Starlette** 的特性（FastAPI 就像加强版的 Starlette）：

* 令人惊叹的性能。它是[Python 可用的最快的框架之一，和 **NodeJS** 及 **Go** 相当](https://github.com/encode/starlette#performance)。
* **支持 WebSocket**。
* 进程内后台任务。
* Startup 和 shutdown 事件。
* 测试客户端基于 HTTPX。
* **CORS**、GZip、静态文件、流响应。
* 支持 **Session 和 Cookie**。
* 100% 测试覆盖率。
* 代码库 100% 类型标注。

## Pydantic 特性 { #pydantic-features }

**FastAPI** 与 [**Pydantic**](https://pydantic.dev/docs/) 完全兼容（并基于它构建）。所以，你有的其他的 Pydantic 代码也能正常工作。

兼容包括基于 Pydantic 的外部库，例如用于数据库的 <abbr title="Object-Relational Mapper - 对象关系映射">ORM</abbr>s、<abbr title="Object-Document Mapper - 对象文档映射">ODM</abbr>s。

这也意味着在很多情况下，你可以将从请求中获得的相同对象**直接传到数据库**，因为所有的验证都是自动的。

反之亦然，在很多情况下，你也可以将从数据库中获取的对象**直接传到客户端**。

通过 **FastAPI** 你可以获得所有 **Pydantic**（FastAPI 基于 Pydantic 做了所有的数据处理）：

* **不烧脑**：
    * 没有新的模式定义 micro-language 需要学习。
    * 如果你知道 Python 类型，你就知道如何使用 Pydantic。
* 和你 **<abbr title="Integrated Development Environment - 集成开发环境: 类似于代码编辑器">IDE</abbr>/<dfn title="一个检查代码错误的程序">linter</dfn>/brain** 适配:
    * 因为 pydantic 数据结构仅仅是你定义的类的实例；自动补全，linting，mypy 以及你的直觉应该可以和你验证的数据一起正常工作。
* 验证**复杂结构**:
    * 使用分层的 Pydantic 模型，Python `typing` 的 `List` 和 `Dict` 等等。
    * 验证器使我们能够简单清楚地将复杂的数据模式定义、检查并记录为 JSON Schema。
    * 你可以拥有深度**嵌套的 JSON** 对象并对它们进行验证和注释。
* **可扩展**:
    * Pydantic 允许定义自定义数据类型或者你可以用验证器装饰器对被装饰的模型上的方法扩展验证。
* 100% 测试覆盖率。
