# 请求表单与文件 { #request-forms-and-files }

FastAPI 支持同时使用 `File` 和 `Form` 定义文件和表单字段。

/// note | 注意

接收上传的文件和/或表单数据，首先安装 [`python-multipart`](https://github.com/Kludex/python-multipart)。

将它添加到你的项目中：

```console
$ uv add python-multipart
```

///

## 导入 `File` 与 `Form` { #import-file-and-form }

{* ../../docs_src/request_forms_and_files/tutorial001_an_py310.py hl[3] *}

## 定义 `File` 与 `Form` 参数 { #define-file-and-form-parameters }

创建文件和表单参数的方式与 `Body` 和 `Query` 一样：

{* ../../docs_src/request_forms_and_files/tutorial001_an_py310.py hl[10:12] *}

文件和表单字段作为表单数据上传与接收。

并且你可以将部分文件声明为 `bytes`，将部分文件声明为 `UploadFile`。

/// warning | 警告

可在一个*路径操作*中声明多个 `File` 与 `Form` 参数，但不能同时声明要接收 JSON 的 `Body` 字段。因为此时请求体的编码为 `multipart/form-data`，不是 `application/json`。

这不是 **FastAPI** 的问题，而是 HTTP 协议的规定。

///

## 小结 { #recap }

在同一个请求中接收数据和文件时，应同时使用 `File` 和 `Form`。
