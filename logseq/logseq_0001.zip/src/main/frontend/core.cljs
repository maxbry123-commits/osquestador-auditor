(ns frontend.core
  "Entry ns for the mobile, browser and electron frontend apps"
  {:dev/always true}
  (:require ["react-dom/client" :as rdc]
            [frontend.background-tasks]
            [frontend.common-keywords]
            [frontend.components.plugins :as plugins]
            [frontend.config :as config]
            [frontend.handler :as handler]
            [frontend.handler.db-based.rtc-background-tasks]
            [frontend.handler.plugin :as plugin-handler]
            [frontend.handler.route :as route-handler]
            [frontend.log]
            [frontend.page :as page]
            [frontend.rfx :as rfx]
            [frontend.routes :as routes]
            [frontend.runtime.globals :as runtime-globals]
            [frontend.spec]
            [frontend.util :as util]
            [lambdaisland.glogi :as log]
            [logseq.api]
            [logseq.db.frontend.kv-entity]
            [malli.dev.cljs :as md]
            [reitit.frontend :as rf]
            [reitit.frontend.easy :as rfe]))

(defn- build-router
  []
  (rf/router (plugins/hook-custom-routes routes/routes) nil))

(defn- on-navigate
  [route]
  (route-handler/set-route-match! route)
  (plugin-handler/hook-plugin-app
   :route-changed (select-keys route [:template :path :parameters])))

(defn refresh-router!
  "Rebuilds the reitit router so route renderers registered by plugins after
   the app started take effect. Safe to call repeatedly; `rfe/start!` stops the
   previous history instance internally."
  []
  (rfe/start!
   (build-router)
   on-navigate
   ;; set to false to enable HistoryAPI
   {:use-fragment true}))

(defonce ^:private *popstate-installed? (atom false))

(defn set-router!
  []
  (when (compare-and-set! *popstate-installed? false true)
    (.addEventListener js/window "popstate" route-handler/restore-scroll-pos))
  (refresh-router!)
  (plugin-handler/set-route-renderer-refresh-fn! refresh-router!))

(defn display-welcome-message
  []
  (js/console.log
   "
    Welcome to Logseq!
    If you encounter any problem, feel free to file an issue on GitHub (https://github.com/logseq/logseq)
    or join our forum (https://discuss.logseq.com).
    .____
    |    |    ____   ____  ______ ____  ______
    |    |   /  _ \\ / ___\\/  ___// __ \\/ ____/
    |    |__(  <_> ) /_/  >___ \\\\  ___< <_|  |
    |_______ \\____/\\___  /____  >\\___  >__   |
            \\/    /_____/     \\/     \\/   |__|
     "))

(defonce root (rdc/createRoot (.getElementById js/document "root")))

(defn ^:export start []
  (when-not (util/capacitor?)
    (when config/dev?
      (md/start!))
    (set-router!)

    (.render ^js root (rfx/provider (page/current-page)))

    (display-welcome-message)))

(defn ^:export init []
  ;; init is called ONCE when the page loads
  ;; this is called in the index.html and must be exported
  ;; so it is available even in :advanced release builds

  ;; (setup-entity-profile!)
  (runtime-globals/install!)
  (log/info ::init "App started")
  (handler/start! start))

(defn ^:export stop []
  ;; stop is called before any code is reloaded
  ;; this is controlled by :before-load in the config
  (js/console.log "stop"))

(defn ^:export delay-remount
  [delay]
  (js/setTimeout #(start) delay))
