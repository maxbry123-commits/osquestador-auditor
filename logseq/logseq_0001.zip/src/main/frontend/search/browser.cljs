(ns frontend.search.browser
  "Browser implementation of search protocol"
  (:require [frontend.search.protocol :as protocol]
            [frontend.state :as state]
            [promesa.core :as p]))

(defrecord Browser [repo]
  protocol/Engine
  (query [_this q option]
    (state/<invoke-db-worker :thread-api/search-blocks (state/get-current-repo) q option))
  (rebuild-pages-indice! [_this]
    (state/<invoke-db-worker :thread-api/search-build-pages-indice repo))
  (rebuild-blocks-indice! [_this]
    (state/<invoke-db-worker :thread-api/search-build-blocks-indice-in-worker (state/get-current-repo) true))
  (transact-blocks! [_this {:keys [blocks-to-remove-set
                                   blocks-to-add]}]
    (let [repo (state/get-current-repo)]
      (p/let [_ (when (seq blocks-to-remove-set)
                  (state/<invoke-db-worker :thread-api/search-delete-blocks repo blocks-to-remove-set))]
        (when (seq blocks-to-add)
          (state/<invoke-db-worker :thread-api/search-upsert-blocks repo blocks-to-add)))))
  (truncate-blocks! [_this]
    (state/<invoke-db-worker :thread-api/search-truncate-tables (state/get-current-repo)))
  (remove-db! [_this]
    ;; Already removed in OPFS
    (p/resolved nil)))
