(ns frontend.schema.handler.common-config
  "Schema that is common for global-config and repo-config"
  (:require [malli.util :as mu]))

(def Config-edn
  (mu/optional-keys
   [:map
    [:meta/version :int]
    [:ui/enable-tooltip? :boolean]
    [:ui/show-brackets? :boolean]
    [:feature/enable-search-remove-accents? :boolean]
    [:feature/enable-flashcards? :boolean]
    [:feature/disable-scheduled-and-deadline-query? :boolean]
    [:scheduled/future-days :int]
    [:start-of-week [:enum 0 1 2 3 4 5 6]]
    [:custom-css-url :string]
    [:custom-js-url :string]
    [:export/bullet-indentation
     [:enum :eight-spaces :four-spaces :two-spaces :tab]]
    [:publishing/all-pages-public? :boolean]
    [:default-home [:map
                    [:page {:optional true} :string]
                    [:sidebar {:optional true} [:or :string [:vector :string]]]]]
    [:shortcuts [:map-of
                 :keyword
                 [:or :string false? [:vector :string]]]]
    [:shortcut/doc-mode-enter-for-new-block? :boolean]
    [:block/title-max-length :int]
    [:ui/show-command-doc? :boolean]
    [:ui/show-empty-bullets? :boolean]
    [:ui/show-full-blocks? :boolean]
    [:ui/hide-empty-properties? :boolean]
    [:ui/auto-expand-block-refs? :boolean]
    [:query/views [:map-of
                   :keyword
                   [:sequential any?]]]
    [:query/result-transforms [:map-of
                               :keyword
                               [:sequential any?]]]
    [:default-queries [:map
                       ;; Maybe validate these query maps later
                       [:journals {:optional true} [:vector :map]]]]
    [:commands [:vector [:tuple
                         :string
                         [:or :string [:vector :some]]]]]
    [:outliner/block-title-collapse-enabled? :boolean]
    [:macros [:map-of
              [:or :string :keyword]
              :string]]
    [:ref/default-open-blocks-level :int]
    [:mobile/photo [:map
                    [:allow-editing? {:optional true} :boolean]
                    [:quality {:optional true} :int]]]
    [:mobile [:map
              [:gestures/disabled-in-block-with-tags {:optional true} [:vector :string]]]]
    [:editor/extra-codemirror-options :map]
    [:editor/logical-outdenting? :boolean]
    [:editor/preferred-pasting-file? :boolean]
    [:quick-capture-templates (mu/optional-keys [:map
                                                 [:text :string]
                                                 [:media :string]])]
    [:quick-capture-options (mu/optional-keys [:map
                                               [:insert-today? :boolean]
                                               [:redirect-page? :boolean]
                                               [:default-page :string]
                                               [:prettify-url? :boolean]])]]))
