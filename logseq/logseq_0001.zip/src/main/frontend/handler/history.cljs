(ns ^:no-doc frontend.handler.history
  (:require [frontend.handler.editor :as editor]
            [frontend.handler.route :as route-handler]
            [frontend.persist-db.browser :as db-browser]
            [frontend.state :as state]
            [frontend.util :as util]
            [goog.functions :refer [debounce]]
            [logseq.db :as ldb]
            [promesa.core :as p]))

(defn- <pull-block
  [block-uuid]
  (when-let [repo (and block-uuid (state/get-current-repo))]
    (state/<invoke-db-worker :thread-api/pull
                             repo
                             '[*]
                             [:block/uuid block-uuid])))

(defn- restore-cursor!
  [{:keys [editor-cursors block-content undo?]}]
  (let [cursor (if undo?
                 (first editor-cursors)
                 (or (last editor-cursors) (first editor-cursors)))
        {:keys [selected-block-uuids selection-direction block-uuid container-id start-pos end-pos]} cursor
        selected-blocks (when (seq selected-block-uuids)
                          (->> selected-block-uuids
                               (mapcat util/get-blocks-by-id)
                               vec))
        pos (if undo? (or start-pos end-pos) (or end-pos start-pos))]
    (if (seq selected-blocks)
      (do
        (state/exit-editing-and-set-selected-blocks! selected-blocks selection-direction)
        nil)
      (p/let [block (<pull-block block-uuid)]
        (when block
          (editor/edit-block! block pos
                              {:container-id container-id
                               :custom-content block-content}))))))

(defn- restore-app-state!
  [state]
  (let [route-data (:route-data state)
        current-route (:route-match (state/get-state))
        current-route-data (db-browser/get-route-data current-route)]
    (when (and (not= route-data current-route-data) route-data
               (contains? #{:home :page :page-block :all-journals} (:to route-data)))
      (route-handler/redirect! route-data))
    (state/swap-state! merge (dissoc state :route-data))))

(defn- restore-cursor-and-state!
  [result]
  (state/set-state! :history/paused? true)
  (let [{:keys [ui-state-str undo?] :as data} result
        restore-result (if ui-state-str
                         (let [{:keys [old-state new-state]} (ldb/read-transit-str ui-state-str)]
                           (if undo? (restore-app-state! old-state) (restore-app-state! new-state)))
                         (restore-cursor! data))]
    (if (p/promise? restore-result)
      (p/finally restore-result #(state/set-state! :history/paused? false))
      (do
        (state/set-state! :history/paused? false)
        restore-result))))

(let [*last-request (atom nil)]
  (defn- undo-aux!
    [e]
    (when-not (:editor/code-block-context (state/get-state))
      (state/set-state! :editor/op :undo)
      (p/do!
       @*last-request
       (when-let [repo (state/get-current-repo)]
         (util/stop e)
         (p/do!
          (state/set-state! [:editor/last-replace-ref-content-tx repo] nil)
          (editor/save-current-block!)
          (state/clear-editor-action!)
          (reset! *last-request (state/<invoke-db-worker :thread-api/undo-redo-undo repo))
          (p/let [result @*last-request]
            (restore-cursor-and-state! result))))))))
(defonce undo! (debounce undo-aux! 20))

(let [*last-request (atom nil)]
  (defn- redo-aux!
    [e]
    (when-not (:editor/code-block-context (state/get-state))
      (state/set-state! :editor/op :redo)
      (p/do!
       @*last-request
       (when-let [repo (state/get-current-repo)]
         (util/stop e)
         (state/clear-editor-action!)
         (reset! *last-request (state/<invoke-db-worker :thread-api/undo-redo-redo repo))
         (p/let [result @*last-request]
           (restore-cursor-and-state! result)))))))
(defonce redo! (debounce redo-aux! 20))
