(ns frontend.handler.search
  "Provides util handler fns for search"
  (:require [clojure.string :as string]
            [dommy.core :as dom]
            [electron.ipc :as ipc]
            [frontend.common.search-fuzzy :as fuzzy]
            [frontend.config :as config]
            [frontend.search :as search]
            [frontend.state :as state]
            [frontend.util :as util]
            [promesa.core :as p]))

(defn- <resolve-page-db-id
  [repo page-db-id]
  (if (string? page-db-id)
    (p/let [page (state/<invoke-db-worker :thread-api/pull repo [:db/id] [:block/name page-db-id])]
      (:db/id page))
    page-db-id))

(defn search
  "The aggregation of search results"
  ([q]
   (search (state/get-current-repo) q))
  ([repo q]
   (search repo q {:limit 10}))
  ([repo q {:keys [page-db-id limit more?]
            :or {page-db-id nil
                 limit 10}
            :as opts}]
   (when-not (string/blank? q)
     (p/let [page-db-id (<resolve-page-db-id repo page-db-id)
             opts (if page-db-id (assoc opts :page (str page-db-id)) opts)
             blocks (search/block-search repo q opts)
             files (search/file-search q)]
       (let [result (merge
                     {:blocks blocks
                      :has-more? (= limit (count blocks))}
                     (when-not page-db-id
                       {:files files}))
             search-key (if more? :search/more-result :search/result)]
         (state/swap-state! assoc search-key result)
         result)))))

(defn open-find-in-page!
  []
  (when (util/electron?)
    (let [{:keys [active?]} (:ui/find-in-page (state/get-state))]
      (when-not active? (state/set-state! [:ui/find-in-page :active?] true)))))

(defn electron-find-in-page!
  []
  (when (util/electron?)
    (let [{:keys [active? backward? match-case? q]} (:ui/find-in-page (state/get-state))
          option (cond->
                  {}

                   (not active?)
                   (assoc :findNext true)

                   backward?
                   (assoc :forward false)

                   match-case?
                   (assoc :matchCase true))]
      (open-find-in-page!)
      (when-not (string/blank? q)
        (dom/set-style! (dom/by-id "search-in-page-input")
                        :visibility "hidden")
        (when (> (count q) 1)
          (dom/set-html! (dom/by-id "search-in-page-placeholder")
                         (util/format
                          "<span><span>%s</span><span style=\"margin-left: -4px;\">%s</span></span>"
                          (first q)
                          (str " " (subs q 1)))))
        (ipc/ipc "find-in-page" q option)))))

(let [cancelable-debounce-search (util/cancelable-debounce electron-find-in-page! 500)]
  (defonce debounced-search (first cancelable-debounce-search))
  (defonce stop-debounced-search! (second cancelable-debounce-search)))

(defn loop-find-in-page!
  [backward?]
  (if (and (get-in (state/get-state) [:ui/find-in-page :active?])
           (not (state/editing?)))
    (do (state/set-state! [:ui/find-in-page :backward?] backward?)
        (debounced-search))
    ;; return false to skip prevent default event behavior (Enter key)
    false))

(defn electron-exit-find-in-page!
  [& {:keys [clear-state?]
      :or {clear-state? true}}]
  (when (util/electron?)
    (ipc/ipc "clear-find-in-page")
    (when clear-state?
      (state/set-state! :ui/find-in-page nil))))

(defn clear-search!
  ([]
   (clear-search! true))
  ([clear-search-mode?]
   (let [m {:search/result nil
            :search/q ""}]
     (state/swap-state! merge m)
     (when config/lsp-enabled? (state/reset-plugin-search-engines)))
   (when clear-search-mode?
     (state/set-search-mode! :global))))

(defn rebuild-indices!
  ([]
   (rebuild-indices! false))
  ([notice?]
   (println "Starting to rebuild search indices!")
   (when-let [repo (state/get-current-repo)]
     (when notice?
       (state/set-state! [:search/index-build-notify-repos repo] true))
     (p/do!
      (search/rebuild-indices!)))))

(defn highlight-exact-query
  [content q]
  (if (or (string/blank? content) (string/blank? q))
    content
    (when (and content q)
      (let [q-words (string/split q #" ")
            lc-content (fuzzy/search-normalize content (state/enable-search-remove-accents?))
            lc-q (fuzzy/search-normalize q (state/enable-search-remove-accents?))]
        (if (and (string/includes? lc-content lc-q)
                 (not (util/safe-re-find #" " q)))
          (let [i (string/index-of lc-content lc-q)
                [before after] [(subs content 0 i) (subs content (+ i (count q)))]]
            [:span
             (when-not (string/blank? before)
               [:span before])
             [:mark {:style {:padding 0 :border-radius 0}} (subs content i (+ i (count q)))]
             (when-not (string/blank? after)
               [:span after])])
          (let [elements (loop [words q-words
                                content content
                                result []]
                           (if (and (seq words) content)
                             (let [word (first words)
                                   lc-word (fuzzy/search-normalize word (state/enable-search-remove-accents?))
                                   lc-content (fuzzy/search-normalize content (state/enable-search-remove-accents?))]
                               (if-let [i (string/index-of lc-content lc-word)]
                                 (recur (rest words)
                                        (subs content (+ i (count word)))
                                        (vec
                                         (concat result
                                                 [[:span (subs content 0 i)]
                                                  [:mark {:style {:padding 0 :border-radius 0}} (subs content i (+ i (count word)))]])))
                                 (recur nil
                                        content
                                        result)))
                             (conj result [:span content])))]
            (into [:span {:class "m-0"}] elements)))))))
