(ns frontend.handler.repo
  "System-component-like ns that manages user's repos/graphs"
  (:require [clojure.string :as string]
            [electron.ipc :as ipc]
            [frontend.config :as config]
            [frontend.context.i18n :refer [t]]
            [frontend.date :as date]
            [frontend.db.async :as db-async]
            [frontend.db.persist :as db-persist]
            [frontend.db.restore :as db-restore]
            [frontend.db.subs :as db-subs]
            [frontend.handler.global-config :as global-config-handler]
            [frontend.handler.graph :as graph-handler]
            [frontend.handler.notification :as notification]
            [frontend.handler.repo-config :as repo-config-handler]
            [frontend.handler.route :as route-handler]
            [frontend.handler.ui :as ui-handler]
            [frontend.persist-db :as persist-db]
            [frontend.search :as search]
            [frontend.state :as state]
            [frontend.util :as util]
            [frontend.util.text :as text-util]
            [logseq.common.version :as build-version]
            [logseq.db.frontend.schema :as db-schema]
            [promesa.core :as p]))

;; Project settings should be checked in two situations:
;; 1. User changes the config.edn directly in logseq.com (fn: alter-file)
;; 2. Git pulls the new change (fn: load-files)

(defn- repo-urls
  [repos]
  (->> repos
       (keep :url)
       distinct))

(defn demo-only-repo?
  [repo repos]
  (let [url (:url repo)
        urls (repo-urls repos)]
    (and (some? url)
         (config/demo-graph? url)
         (= 1 (count urls)))))

(defn removable-repo?
  [repo repos]
  (not (demo-only-repo? repo repos)))

(defn remove-repo!
  [{:keys [url] :as repo} & {:keys [switch-graph?]
                             :or {switch-graph? true}}]
  (if-not (removable-repo? repo (state/get-repos))
    (p/rejected (ex-info "Cannot delete the demo graph when it is the only graph"
                         {:code :demo-only-graph-delete
                          :repo url}))
    (let [current-repo (state/get-current-repo)]
      (p/do!
       (persist-db/<close-db url)
       (db-persist/delete-graph! url)
       (search/remove-db! url)
       (state/delete-repo! repo)
       (when switch-graph?
         (if (= current-repo url)
           (do
             (state/set-current-repo! nil)
             (db-subs/reset-graph! nil)
             (when-let [graph (:url (first (state/get-repos)))]
               (notification/show! (t :graph/removed-and-redirecting
                                      (text-util/get-graph-name-from-path url)
                                      (text-util/get-graph-name-from-path graph))
                                   :success)
               (state/pub-event! [:graph/switch graph {:persist? false}])))
           (notification/show! (t :graph/removed (text-util/get-graph-name-from-path url)) :success)))))))

(defn restore-and-setup-repo!
  "Restore the db of a graph from the persisted data, and setup. Create a new
  conn, or replace the conn in state with a new one."
  [repo & {:as opts}]
  (p/do!
   (state/set-db-restoring! true)
   (db-restore/restore-graph! repo opts)
   (p/let [date-formatter (db-async/<get-date-formatter repo)]
     (state/set-date-formatter! repo date-formatter))
   (repo-config-handler/restore-repo-config! repo)
   (when (config/global-config-enabled?)
     (global-config-handler/restore-global-config!))
    ;; Don't have to unlisten the old listener, as it will be destroyed with the conn
   (when-not (true? (:ignore-style? opts))
     (ui-handler/add-style-if-exists!))
   (when-not config/publishing?
     (state/set-db-restoring! false))))

(defn get-repos
  []
  (p/let [dbs (db-persist/get-all-graphs)]
    (->> dbs
         (remove (fn [{:keys [name]}]
                   (= "upload-temp" (some-> name str string/lower-case))))
         (map (fn [db]
                (let [graph-name (:name db)]
                  {:url graph-name
                   :metadata (:metadata db)
                   :root (config/get-local-dir graph-name)
                   :nfs? true}))))))

(defn combine-local-&-remote-graphs
  [local-repos remote-repos]
  (when-let [repos' (seq (concat (map (fn [{:keys [sync-meta metadata] :as repo}]
                                        (let [graph-id (some-> (or (:kv/value metadata)
                                                                   (second sync-meta)) str)]
                                          (if (and graph-id (nil? (:GraphUUID repo)))
                                            (assoc repo :GraphUUID graph-id)
                                            repo)))
                                      local-repos)
                                 (some->> remote-repos
                                          (map #(assoc % :remote? true)))))]
    (let [app-major-schema-version (str (:major (db-schema/parse-schema-version db-schema/version)))
          repos' (group-by :url repos')
          repos'' (mapcat (fn [[k vs]]
                            (if (some? k)
                              (let [remote-repos (filter :remote? vs)
                                    version-matched-remote-repo
                                    (first
                                     (filter
                                      #(= app-major-schema-version (:GraphSchemaVersion %))
                                      remote-repos))]
                                [(merge (first vs) (second vs) version-matched-remote-repo)])
                              vs))
                          repos')]
      (sort-by (fn [repo]
                 (let [graph-name (or (:GraphName repo)
                                      (last (string/split (:root repo) #"/")))]
                   [(:remote? repo) (string/lower-case graph-name)])) repos''))))

(defn refresh-repos!
  []
  (p/let [repos (get-repos)
          repos' (combine-local-&-remote-graphs
                  repos
                  (state/get-rtc-graphs))]
    (state/set-repos! repos')
    repos'))

(defn graph-ready!
  ;; FIXME: Call electron that the graph is loaded, an ugly implementation for redirect to page when graph is restored
  [graph]
  (when (util/electron?)
    (ipc/ipc "graphReady" graph)))

(defn graph-already-exists?
  "Checks to see if given db graph name already exists"
  [graph-name]
  (let [full-graph-name (string/lower-case (str config/db-version-prefix graph-name))]
    (some #(= (some-> (:url %) string/lower-case) full-graph-name) (state/get-repos))))

(defn- create-db [full-graph-name {:keys [file-graph-import? creating-remote-graph?]}]
  (->
   (p/let [config config/config-default-content
           _ (persist-db/<new full-graph-name
                              (cond-> {:config config
                                       :graph-git-sha (build-version/revision)
                                       :creating-remote-graph? creating-remote-graph?}
                                file-graph-import? (assoc :import-type :file-graph)))
           _ (state/add-repo! {:url full-graph-name :root (config/get-local-dir full-graph-name)})
           _ (restore-and-setup-repo! full-graph-name {:file-graph-import? file-graph-import?})
           _ (when-not file-graph-import? (route-handler/redirect-to-home!))
           _ (repo-config-handler/set-repo-config-state! full-graph-name config/config-default-content)
          ;; TODO: handle global graph
           _ (state/pub-event! [:init/commands])
           _ (when-not file-graph-import? (state/pub-event! [:page/create (date/today) {:redirect? false}]))]
     (state/pub-event! [:shortcut/refresh])
     (route-handler/redirect-to-home!)
     (ui-handler/re-render-root!)
     (graph-handler/settle-metadata-to-local! {:created-at (js/Date.now)})
     (prn "New db created: " full-graph-name)
     full-graph-name)
   (p/catch (fn [error]
              (notification/show! (t :graph/create-error) :error)
              (js/console.error error)))))

(defn new-db!
  "Handler for creating a new database graph"
  ([graph] (new-db! graph {}))
  ([graph opts]
   (let [full-graph-name (str config/db-version-prefix graph)]
     (if (graph-already-exists? graph)
       (state/pub-event! [:notification/show
                          {:content (t :graph/already-exists-error graph)
                           :status :error}])
       (create-db full-graph-name opts)))))

(defn gc-graph!
  [graph]
  (p/do!
   (state/<invoke-db-worker :thread-api/gc-graph graph)
   (state/pub-event! [:notification/show
                      {:content (t :graph/gc-success)
                       :status :success}])))
