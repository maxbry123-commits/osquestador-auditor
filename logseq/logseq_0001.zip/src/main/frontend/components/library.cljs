(ns frontend.components.library
  "Library page"
  (:require [clojure.string :as string]
            [frontend.components.select :as components-select]
            [frontend.context.i18n :refer [t]]
            [frontend.handler.editor :as editor-handler]
            [frontend.search :as search]
            [frontend.state :as state]
            [frontend.ui :as ui]
            [logseq.shui.hooks :as hooks]
            [logseq.shui.ui :as shui]
            [promesa.core :as p]
            [io.factorhouse.hsx.core :as hsx]))

(hsx/defc select-pages
  [library-page]
  (let [[result set-result!] (hooks/use-state nil)
        [input set-input!] (hooks/use-state "")
        [selected-choices set-selected-choices!] (hooks/use-state #{})
        items (map (fn [block]
                     {:value (:db/id block)
                      :label (:block/title block)})
                   result)]
    (hooks/use-effect!
     (fn []
       (if (string/blank? input)
         (set-result! nil)
         (p/let [result (search/block-search (state/get-current-repo) input {:enable-snippet? false
                                                                             :built-in? false
                                                                             :page-only? true
                                                                             :library-page-search? true})]
           (set-result! result))))
     [(hooks/use-debounced-value input 200)])
    (components-select/select
     {:items items
      :extract-fn :label
	      :extract-chosen-fn :value
	      :selected-choices selected-choices
	      :on-chosen (fn [chosen selected?]
	                   (if selected?
	                     (let [chosen-block (some #(when (= chosen (:db/id %)) %) result)]
	                       (editor-handler/move-blocks! [chosen-block] library-page {:bottom? true})
	                       (set-selected-choices! (conj selected-choices chosen)))
                     (do
	                       (state/<invoke-db-worker :thread-api/transact
	                                                (state/get-current-repo)
	                                                [[:db/retract chosen :block/parent]]
	                                                {:outliner-op :save-block}
	                                                nil)
                       (set-selected-choices! (disj selected-choices chosen)))))
      :multiple-choices? true
      :input-default-placeholder (t :library/add-pages)
      :show-new-when-not-exact-match? false
      :on-input set-input!
      :input-opts {:class "!p-1 !text-sm"}
      :clear-input-on-chosen? false})))

(hsx/defc add-pages
  [library-page]
  [:div.ls-add-pages.px-1.mt-4
   (shui/button
    {:variant :secondary
     :size :sm
     :class "text-muted-foreground hover:text-foreground"
     :on-click (fn [e]
                 (shui/popup-show!
                  (.-target e)
                  (fn []
                    [:div {:style {:min-height 120}}
                     (select-pages library-page)])
                  {:align :start}))}
    (ui/icon "plus" {:size 16})
    (t :library/add-existing-pages))])
