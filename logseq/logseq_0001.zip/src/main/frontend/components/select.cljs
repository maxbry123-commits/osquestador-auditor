(ns frontend.components.select
  "Generic component for fuzzy searching items to select an item. See
  select-config to add a new use or select-type for this component. To use the
  new select-type, create an event that calls `select/dialog-select!` with the
  select-type. See the :graph/open command for a full example."
  (:require [clojure.string :as string]
            [frontend.config :as config]
            [frontend.context.i18n :refer [t]]
            [frontend.handler.common.developer :as dev-common-handler]
            [frontend.handler.repo :as repo-handler]
            [frontend.modules.shortcut.core :as shortcut]
            [frontend.search :as search]
            [frontend.state :as state]
            [frontend.ui :as ui]
            [frontend.util :as util]
            [frontend.util.text :as text-util]
            [logseq.shui.hooks :as hooks]
            [logseq.shui.ui :as shui]
            [reitit.frontend.easy :as rfe]
            [io.factorhouse.hsx.core :as hsx]))

(hsx/defc render-item
  [result chosen? multiple-choices? *selected-choices]
  (let [value (if (map? result) (or (:label result)
                                    (:value result)) result)
        header (:header result)
        [selected-choices] (hooks/use-atom *selected-choices)
        row [:div.flex.flex-row.justify-between.w-full
	             {:class (when chosen? "chosen")
	              :on-pointer-down util/stop-propagation}
	             [:div.flex.flex-row.items-center.gap-1
	              (when multiple-choices?
	                (ui/checkbox {:checked (boolean (selected-choices (:value result)))
	                              :on-click (fn [e]
	                                          (.preventDefault e))
	                              :disabled (:disabled? result)}))
	              value]
             (when (and (map? result) (:id result))
               [:div.tip.flex
                [:code.opacity-20.bg-transparent (:id result)]])]]
    (if header
      [:div.flex.flex-col.gap-1
       header
       row]
      row)))

(hsx/defc search-input
  [*input {:keys [prompt-key input-default-placeholder input-opts on-input]}]
  (let [[input set-input!] (hooks/use-state @*input)
        *input-el (hooks/use-ref nil)
        auto-focus? (not (util/mobile?))]
    (hooks/use-effect!
     (fn []
       (when auto-focus?
         (let [timeout (js/setTimeout #(some-> (hooks/deref *input-el) (.focus)) 16)]
           #(js/clearTimeout timeout))))
     [auto-focus?])

    (hooks/use-effect!
     (fn []
       (reset! *input input)
       (when (fn? on-input) (on-input input)))
     [(hooks/use-debounced-value input 100)])

    (hooks/use-effect!
     (fn []
       (when (= "" @*input)
         (set-input! "")))
     [(hooks/use-debounced-value @*input 100)])

    (hooks/use-effect!
     (fn []
       (when-not (util/mobile?)
         (js/setTimeout
          (fn []
            (some-> (hooks/deref *input-el) (.focus)))
          0))
       (fn []))
     [])

    [:div.input-wrap
     [:input.cp__select-input.w-full
      (merge {:type "text"
              :ref *input-el
              :class "!p-1.5"
              :placeholder (or input-default-placeholder (t prompt-key))
              :auto-focus auto-focus?
              :value input
              :on-change (fn [e]
                           (let [v (util/evalue e)]
                             (set-input! v)))}
             input-opts)]]))

(hsx/defc ^:large-vars/cleanup-todo select
  "Provides a select dropdown powered by a fuzzy search. Takes the following options:
   * :items - Vec of things to select from. Assumes a vec of maps with :value key by default. Required option
   * :limit - Limit number of items to search. Default is 100
   * :on-chosen - Optional fn to perform an action with chosen item
   * :extract-fn - Fn applied to each item during fuzzy search. Default is :value
   * :extract-chosen-fn - Fn applied to each item when choosing an item. Default is identity
   * :show-new-when-not-exact-match? - Boolean to allow new values be entered. Default is false
   * :exact-match-exclude-items - A set of strings that can't be added as a new item. Default is #{}
   * :transform-fn - Optional fn to transform search results given results and current input
   * :new-case-sensitive? - Boolean to allow new values to be case sensitive
   * :loading? - whether it's loading the items
   TODO: Describe more options"
  [{:keys [items limit on-chosen empty-placeholder grouped?
           prompt-key input-default-placeholder close-modal?
           extract-fn extract-chosen-fn host-opts on-input input-opts
           item-cp transform-fn tap-*input-val
           multiple-choices? on-apply new-case-sensitive?
           dropdown? show-new-when-not-exact-match? exact-match-exclude-items
           input-container initial-open? loading?
           choose-first-on-enter?
           clear-input-on-chosen?]
    :or {limit 100
         prompt-key :select/default-prompt
         empty-placeholder (fn [_t] [:div])
         close-modal? true
         extract-fn :value
         extract-chosen-fn identity
         exact-match-exclude-items #{}
         initial-open? true
         clear-input-on-chosen? true}
    :as opts}]
  (shortcut/use-disable-all-shortcuts!)
  (let [*input (hooks/use-memo #(atom "") [])
        *toggle (hooks/use-memo #(atom nil) [])
        *selected-choices (hooks/use-memo #(atom (set (:selected-choices opts))) [])
        [input] (hooks/use-atom *input)
        [selected-choices] (hooks/use-atom *selected-choices)
        _ (hooks/use-effect!
           (fn []
             (let [choices (set (:selected-choices opts))]
               (when (not= choices @*selected-choices)
                 (reset! *selected-choices choices))))
           [(:selected-choices opts)])
        _ (hooks/use-effect!
           (fn []
             #(shui/dialog-close! :ls-select-modal))
           [])
        _ (hooks/use-effect!
           (fn []
             (when (fn? tap-*input-val)
               (tap-*input-val *input)))
           [tap-*input-val *input])
        full-choices (cond->>
                      (remove nil? items)
                       (seq input)
                       (remove :clear?))
        search-result' (->>
                        (cond-> (search/fuzzy-search full-choices input :limit limit :extract-fn extract-fn)
                          (fn? transform-fn)
                          (transform-fn input))
                        (remove nil?))
        exact-transform-fn (if new-case-sensitive? identity string/lower-case)
        exact-match? (contains? (set (map (comp exact-transform-fn str extract-fn) search-result'))
                                (exact-transform-fn input))
        search-result' (if (and multiple-choices? (not (string/blank? input)))
                         (sort-by (fn [item]
                                    (not (contains? selected-choices (:value item))))
                                  search-result')
                         search-result')
        new-option {:value input
                    :label (t :select/new-option input)}
        search-result (if (and show-new-when-not-exact-match?
                               (not exact-match?)
                               (not (string/blank? input))
                               (not (exact-match-exclude-items input)))
                        (let [current-input (exact-transform-fn input)
                              matches? (some (fn [item]
                                               (and (string? item)
                                                    (string? current-input)
                                                    (string/includes?
                                                     (string/lower-case item)
                                                     (string/lower-case current-input))))
                                             (set (map (comp exact-transform-fn str extract-fn) search-result')))]
                          (->>
                           (if matches?
                             (cons
                              (first search-result')
                              (cons
                               new-option
                               (rest search-result')))
                             (cons new-option search-result'))
                           (remove nil?)))
                        search-result')
        choose-result! (fn [raw-chosen e]
                         (util/stop-propagation e)
                         (when clear-input-on-chosen?
                           (reset! *input ""))
                         (let [chosen (extract-chosen-fn raw-chosen)]
                           (if multiple-choices?
                             (if (selected-choices chosen)
                               (do
                                 (swap! *selected-choices disj chosen)
                                 (when on-chosen (on-chosen chosen false @*selected-choices e)))
                               (do
                                 (swap! *selected-choices conj chosen)
                                 (when on-chosen (on-chosen chosen true @*selected-choices e))))
                             (do
                               (when (and close-modal? (not multiple-choices?))
                                 (state/close-dialog!))
                               (when on-chosen
                                 (on-chosen chosen true @*selected-choices e))))))
        input-opts* (if (fn? input-opts) (input-opts (empty? search-result)) input-opts)
        input-opts' (if choose-first-on-enter?
                      (let [on-key-down (:on-key-down input-opts*)]
                        (assoc input-opts*
                               :on-key-down
                               (fn [e]
                                 (if (and (= "Enter" (util/ekey e)) (seq search-result))
                                   (do
                                     (util/stop e)
                                     (choose-result! (first search-result) e))
                                   (when on-key-down
                                     (on-key-down e))))))
                      input-opts*)
        input-container (or
                         input-container
                         (search-input *input
                                       {:prompt-key prompt-key
                                        :input-default-placeholder input-default-placeholder
                                        :input-opts input-opts'
                                        :on-input on-input}))
        results-container-f (fn []
                              (if loading?
                                [:div.px-1.py-2
                                 (ui/loading (t :ui/loading))]
                                [:div
                                 {:class (when (seq search-result) "py-1")}
                                 [:div.item-results-wrap
                                  (ui/auto-complete
                                   search-result
                                   {:grouped? grouped?
                                    :item-render       (or item-cp (fn [result chosen?]
                                                                     (render-item result chosen? multiple-choices? *selected-choices)))
                                    :class             "cp__select-results"
                                    :on-chosen         choose-result!
                                    :empty-placeholder (empty-placeholder t)})]

                                 (when (and multiple-choices? (fn? on-apply))
                                   [:div.p-4 (ui/button (t :ui/apply)
                                                        {:small? true
                                                         :on-pointer-down (fn [e]
                                                                            (util/stop e)
                                                                            (when @*toggle (@*toggle))
                                                                            (on-apply selected-choices)
                                                                            (when close-modal? (state/close-dialog!)))})])]))]
    (hooks/use-effect!
     (fn []
       (when (fn? tap-*input-val)
         (tap-*input-val *input))
       nil)
     [tap-*input-val])
    [:div.cp__select
     (merge {:class "cp__select-main"}
            host-opts)

     (if dropdown?
       (ui/dropdown
        (if (fn? input-container) input-container (fn [] input-container))
        results-container-f
        {:initial-open? initial-open?
         :*toggle-fn *toggle})
       [:<>
        (if (fn? input-container) (input-container) input-container)
        (results-container-f)])]))

(defn select-config
  "Config that supports multiple types (uses) of this component. To add a new
  type, add a key with the value being a map with the following keys:

  * :items-fn - fn that returns items with a :value key that are used for the
    fuzzy search and selection. Items can have an optional :id and are displayed
    lightly for a given item.
  * :on-chosen - fn that is given item when it is chosen.
  * :empty-placeholder (optional) - fn that returns hiccup html to render if no
    matched graphs found.
  * :prompt-key (optional) - dictionary keyword that prompts when components is
    first open. Defaults to :select/default-prompt."
  []
  {:graph-open
   {:items-fn (fn []
                (->>
                 (state/get-repos)
                 (remove (fn [{:keys [url]}]
                           (or (config/demo-graph? url)
                               (= url (state/get-current-repo)))))
                 (map (fn [{:keys [url]}]
                        {:value (text-util/get-graph-name-from-path url)
                         :id (config/get-repo-dir url)
                         :graph url}))))
    :prompt-key :graph.switch/select-prompt
    :on-chosen #(state/pub-event! [:graph/switch (:graph %)])
    :empty-placeholder (fn [t]
                         [:div.px-4.py-2
                          [:div.mb-2 (t :graph.switch/empty-desc)]
                          (ui/button
                           (t :graph.switch/add-graph-action)
                           :href (rfe/href :graphs)
                           :on-click state/close-dialog!)])}
   :graph-remove
   {:items-fn (fn []
                (->> (state/get-repos)
                     (remove (fn [{:keys [url]}]
                               (config/demo-graph? url)))
                     (map (fn [{:keys [url] :as original-graph}]
                            {:value (text-util/get-graph-name-from-path url)
                             :id (config/get-repo-dir url)
                             :graph url
                             :original-graph original-graph}))))
    :on-chosen #(repo-handler/remove-repo! (:original-graph %))}
   :db-graph-replace
   {:items-fn (fn []
                (let [current-repo (state/get-current-repo)]
                  (->> (state/get-repos)
                       (remove (fn [{:keys [url]}]
                                ;; Can't replace current graph as ui wouldn't reload properly
                                 (= url current-repo)))
                       (map (fn [{:keys [url] :as original-graph}]
                              {:value (text-util/get-graph-name-from-path url)
                               :id (config/get-repo-dir url)
                               :graph url
                               :original-graph original-graph})))))
    :on-chosen #(dev-common-handler/import-chosen-graph (:graph %))}})

(defn dialog-select!
  [select-type]
  (when select-type
    (let [select-type-config (get (select-config) select-type)
          on-chosen' (:on-chosen select-type-config)]
      (shui/dialog-open!
       #(select (-> select-type-config
                    (assoc :on-chosen (fn [it]
                                        (on-chosen' it)
                                        (shui/dialog-close-all!)))
                    (select-keys [:on-chosen :empty-placeholder :prompt-key])
                    (assoc :items ((:items-fn select-type-config)))))
       {:id :ls-select-modal
        :close-btn?  false
        :align :top
        :content-props {:class "ls-dialog-select"}}))))
