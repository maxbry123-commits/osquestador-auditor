(ns frontend.components.right-sidebar
  (:require ["react" :as react]
            [cljs-bean.core :as bean]
            [clojure.string :as string]
            [frontend.components.block :as block]
            [frontend.components.cmdk.core :as cmdk]
            [frontend.components.icon :as icon]
            [frontend.components.onboarding :as onboarding]
            [frontend.components.page :as page]
            [frontend.components.profiler :as profiler]
            [frontend.components.shortcut-help :as shortcut-help]
            [frontend.components.plugins :as plugins]
            [frontend.config :as config]
            [frontend.context.i18n :refer [t]]
            [frontend.date :as date]
            [frontend.db.async :as db-async]
            [frontend.db.hooks :as db-hooks]
            [frontend.db.rtc.debug-ui :as rtc-debug-ui]
            [frontend.handler.editor :as editor-handler]
            [frontend.handler.route :as route-handler]
            [frontend.handler.ui :as ui-handler]
            [frontend.handler.plugin :as plugin-handler]
            [frontend.rfx :as rfx]
            [frontend.state :as state]
            [frontend.ui :as ui]
            [frontend.undo-redo.debug-ui :as undo-redo-debug-ui]
            [frontend.util :as util]
            [frontend.util.entity :as entity]
            [logseq.shui.hooks :as hooks]
            [logseq.shui.ui :as shui]
            [medley.core :as medley]
            [promesa.core :as p]
            [io.factorhouse.hsx.core :as hsx]))

(hsx/defc toggle
  []
  (when-not (util/sm-breakpoint?)
    (ui/with-shortcut :ui/toggle-right-sidebar "left"
      (shui/button-ghost-icon :layout-sidebar-right
                              {:class "toggle-right-sidebar"
                               :on-click ui-handler/toggle-right-sidebar!})
      (t :sidebar.right/toggle))))

(hsx/defc block-cp
  [repo idx block]
  (let [id (:block/uuid block)]
    [:div.mt-2
     (page/page-cp {:parameters  {:path {:name (str id)}}
                    :sidebar?    true
                    :sidebar/idx idx
                    :repo        repo})]))

(defn get-scrollable-container
  []
  (js/document.querySelector ".sidebar-item-list"))

(hsx/defc page-cp
  [repo page-name]
  (page/page-cp {:page-name page-name
                 :sidebar?   true
                 :scroll-container (get-scrollable-container)
                 :repo repo}))

(hsx/defc shortcut-settings
  []
  [:div.contents.flex-col.flex.ml-3
   (shortcut-help/shortcut-page {:show-title? false})])

(defn- block-with-breadcrumb
  [repo block idx sidebar-key ref?]
  (when-let [block-id (:block/uuid block)]
    [[:.flex.items-center {:class (when ref? "ml-2")}
      (block/breadcrumb {:id     "block-parent"
                         :block? true
                         :sidebar-key sidebar-key} repo block-id {:indent? false
                                                                 :block block})]
     (block-cp repo idx block)]))

(hsx/defc search-title
  [*input]
  (let [input (first (hooks/use-atom *input))
        input' (if (string/blank? input) (t :search/blank-input) input)]
    [:span.overflow-hidden.text-ellipsis input']))

(hsx/defc sidebar-search
  [repo block-type init-key input *input]
  ^{:key (str init-key)}
  [cmdk/cmdk-block {:initial-input input
                    :sidebar? true
                    :on-input-change (fn [new-value]
                                       (reset! *input new-value))
                    :on-input-blur (fn [new-value]
                                     (state/sidebar-replace-block! [repo input block-type]
                                                                   [repo new-value block-type]))}])

(hsx/defc page-title
  [page-uuid]
  (when-let [page (db-hooks/use-block page-uuid)]
    [:.flex.items-center.page-title.gap-1
     (icon/get-node-icon-cp page {:class "text-md"})
     [:span.overflow-hidden.text-ellipsis (:block/title page)]]))

(defn- build-sidebar-item
  [repo idx db-id block-type *db-id init-key entity contents-page]
  (let [page? (entity/page? entity)
        item-meta {:drag-name (:block/name entity)}
        block-render (fn []
                       (when entity
                         (if page?
                           [(page-title (:block/uuid entity))
                            (page-cp repo (str (:block/uuid entity)))
                            item-meta]
                           (conj (block-with-breadcrumb repo entity idx [repo db-id block-type] false)
                                 item-meta))))]
    (case (keyword block-type)
      :contents
      (when-let [page contents-page]
        [[:.flex.items-center (ui/icon "list-details" {:class "text-md mr-2"}) (t :page/contents)]
         (page-cp repo (str (:block/uuid page)))
         {:drag-name (:block/name page)}])

      :help
      [[:.flex.items-center (ui/icon "help" {:class "text-md mr-2"}) (t :nav/help)] (onboarding/help)]

      :page-graph
      [[:.flex.items-center (ui/icon "hierarchy" {:class "text-md mr-2"}) (t :graph.page/title)]
       (page/page-graph)]

      :block-ref
      (let [block entity]
        (when block
          [(t :reference/blocks)
           (block-with-breadcrumb repo block idx [repo db-id block-type] true)
           {:drag-name (:block/name block)}]))

      :block
      (block-render)

      :page
      (block-render)

      :plugin
      [[:.flex.items-center.page-title
        (ui/icon "puzzle" {:class "text-md mr-2"})
        [:h3 {:id db-id} (str db-id)]]
       (plugins/renderer-resolver db-id)]

      :search
      [[:.flex.items-center.page-title
        (ui/icon "search" {:class "text-md mr-2"})
        (search-title *db-id)]
       (sidebar-search repo block-type init-key db-id *db-id)]

      :shortcut-settings
      [[:.flex.items-center (ui/icon "command" {:class "text-md mr-2"}) (t :help.shortcuts/label)]
       (shortcut-settings)]

      :rtc
      [[:.flex.items-center (ui/icon "cloud" {:class "text-md mr-2"}) "(Dev) RTC"]
       (rtc-debug-ui/rtc-debug-ui)]

      :undo-redo
      [[:.flex.items-center (ui/icon "rotate-clockwise" {:class "text-md mr-2"}) "(Dev) Undo/Redo"]
       (undo-redo-debug-ui/undo-redo-debug-ui)]

      :profiler
      [[:.flex.items-center (ui/icon "cloud" {:class "text-md mr-2"}) "(Dev) Profiler"]
       (profiler/profiler)]

      ["" [:span]])))

(defn- <build-sidebar-item
  [repo idx db-id block-type *db-id init-key]
  (-> (p/let [entity (when (or (integer? db-id) (uuid? db-id))
                       (db-async/<get-block repo db-id {:children? false
                                                       :block-metadata? true}))
              contents-page (when (= :contents (keyword block-type))
                              (db-async/<get-block repo "Contents" {:children? false}))]
       (build-sidebar-item repo idx db-id block-type *db-id init-key entity contents-page))
      (p/catch (fn [error]
                 (js/console.error error)))))

(defonce *drag-to
  (atom nil))

(defonce *drag-from
  (atom nil))

(defn dev-sidebar-items
  [developer-mode?]
  (cond-> []
    (and developer-mode? (not config/publishing?))
    (conj {:db-id "rtc" :block-type :rtc :label "(Dev) RTC"})

    developer-mode?
    (conj {:db-id "undo-redo" :block-type :undo-redo :label "(Dev) Undo/Redo"})

    developer-mode?
    (conj {:db-id "profiler" :block-type :profiler :label "(Dev) Profiler"})))

(hsx/defc actions-menu-content
  [db-id idx type collapsed? block-count]
  (let [multi-items? (> block-count 1)
        menu-item shui/dropdown-menu-item
        [block set-block!] (hooks/use-state nil)
        page? (or (contains? #{:page :contents} type) (entity/page? block))]
    (hooks/use-effect!
     (fn []
       (if (integer? db-id)
         (p/let [block (db-async/<get-block (state/get-current-repo) db-id {:children? false})]
           (set-block! block))
         (set-block! nil))
       nil)
     [db-id])
    [:<>
     (menu-item {:on-click #(state/sidebar-remove-block! idx)} (t :sidebar.right/close))
     (when multi-items? (menu-item {:on-click #(state/sidebar-remove-rest! db-id)} (t :sidebar.right/close-others)))
     (when multi-items? (menu-item {:on-click (fn []
                                                (state/clear-sidebar-blocks!)
                                                (state/hide-right-sidebar!))} (t :sidebar.right/close-all)))
     (when (and (not collapsed?) multi-items?) [:hr.menu-separator])
     (when-not collapsed? (menu-item {:on-click #(state/sidebar-block-toggle-collapse! db-id)} (t :sidebar.right/collapse)))
     (when multi-items? (menu-item {:on-click #(state/sidebar-block-collapse-rest! db-id)} (t :sidebar.right/collapse-others)))
     (when multi-items? (menu-item {:on-click #(state/sidebar-block-set-collapsed-all! true)} (t :sidebar.right/collapse-all)))
     (when (and collapsed? multi-items?) [:hr.menu-separator])
     (when collapsed? (menu-item {:on-click #(state/sidebar-block-toggle-collapse! db-id)} (t :sidebar.right/expand)))
     (when multi-items? (menu-item {:on-click #(state/sidebar-block-set-collapsed-all! false)} (t :sidebar.right/expand-all)))
     (when page? [:hr.menu-separator])
     (when page?
       (menu-item {:on-click (fn [] (route-handler/redirect-to-page! (:block/uuid block)))}
                  (t :sidebar.right/open-as-page)))]))

(hsx/defc drop-indicator
  [idx drag-to]
  [:.sidebar-drop-indicator {:on-drag-enter #(when drag-to (reset! *drag-to idx))
                             :on-drag-over util/stop
                             :class (when (= idx drag-to) "drag-over")}])

(hsx/defc drop-area
  [idx]
  [:.sidebar-item-drop-area
   {:on-drag-over util/stop}
   [:.sidebar-item-drop-area-overlay.top
    {:on-drag-enter #(reset! *drag-to (dec idx))}]
   [:.sidebar-item-drop-area-overlay.bottom
    {:on-drag-enter #(reset! *drag-to idx)}]])

(hsx/defc inner-component-inner
  [component _should-update?]
  component)

(def inner-component
  (let [memo-class (react/memo
                    (fn [^js props]
                      (apply inner-component-inner (.-args props)))
                    (fn [_prev-props ^js next-props]
                      (not (last (.-args next-props)))))]
    (fn [& args]
      (react/createElement memo-class #js {:args (vec args)}))))

(hsx/defc sidebar-item-inner
  [db-id {:keys [repo idx block-type collapsed? drag-from drag-to block-count *db-id init-key]}]
  (let [[item set-item!] (hooks/use-state nil)]
    (hooks/use-effect!
     (fn []
       (p/let [item (<build-sidebar-item repo idx db-id block-type *db-id init-key)]
         (set-item! item)))
     [])
    (when item
      [:<>
       (when (zero? idx) (drop-indicator (dec idx) drag-to))
       [:div.flex.sidebar-item.content.color-level.rounded-md.shadow-lg
        {:class [(str "item-type-" (name block-type))
                 (when collapsed? "collapsed")]}
        (let [[title component {:keys [drag-name]}] item]
          [:div.flex.flex-col.w-full.relative
           [:.flex.flex-row.justify-between.sidebar-item-header.color-level.rounded-t-md
            {:class         (when collapsed? "rounded-b-md")
             :draggable     true
             :on-context-menu (fn [e]
                                (util/stop e)
                                (shui/popup-show! e
                                                  (actions-menu-content db-id idx block-type collapsed? block-count)
                                                  {:as-dropdown? true
                                                   :content-props {:on-click (fn [] (shui/popup-hide!))}}))
             :on-drag-start (fn [event]
                              (editor-handler/block->data-transfer! drag-name event true)
                              (reset! *drag-from idx))
             :on-drag-end   (fn [_event]
                              (when drag-to (state/sidebar-move-block! idx drag-to))
                              (reset! *drag-to nil)
                              (reset! *drag-from nil))
             :on-pointer-up   (fn [event]
                                (when (= (.-which (.-nativeEvent event)) 2)
                                  (state/sidebar-remove-block! idx)))}

            [:button.flex.flex-row.px-2.items-center.w-full.overflow-hidden
             {:aria-expanded (str (not collapsed?))
              :id            (str "sidebar-panel-header-" idx)
              :aria-controls (str "sidebar-panel-content-" idx)
              :on-click      (fn [event]
                               (util/stop event)
                               (state/sidebar-block-toggle-collapse! db-id))}
             [:span.opacity-50.hover:opacity-100.flex.items-center.pr-1
              (ui/rotating-arrow collapsed?)]
             [:div.ml-1.font-medium.text-sm.overflow-hidden.whitespace-nowrap
              title]]
            [:.item-actions.flex.items-center
             (ui/tooltip
              (shui/button
               {:class "px-2 py-2 h-8 w-8 text-muted-foreground"
                :variant :ghost
                :on-click #(shui/popup-show!
                            (.-target %)
                            (actions-menu-content db-id idx block-type collapsed? block-count)
                            {:as-dropdown? true
                             :content-props {:on-click (fn [] (shui/popup-hide!))}})}
               (ui/icon "dots"))
              (t :sidebar.right/more))

             (ui/tooltip
              (shui/button
               {:variant :ghost
                :class "px-2 py-2 h-8 w-8 text-muted-foreground"
                :on-click #(state/sidebar-remove-block! idx)}
               (ui/icon "x"))
              (t :sidebar.right/close))]
            ]

           [:div {:role "region"
                  :id (str "sidebar-panel-content-" idx)
                  :aria-labelledby (str "sidebar-panel-header-" idx)
                  :class           (util/classnames [{:hidden  collapsed?
                                                      :initial (not collapsed?)
                                                      :sidebar-panel-content true
                                                      :px-2    (not (contains? #{:search :shortcut-settings} block-type))}])}
            (inner-component component (not drag-from))]
           (when drag-from (drop-area idx))])]
       (drop-indicator idx drag-to)])))

(hsx/defc sidebar-item-component
  [repo idx db-id block-type block-count]
  (let [*db-id (hooks/use-memo #(atom db-id) [])
        init-key (hooks/use-memo #(random-uuid) [])
        drag-from (first (hooks/use-atom *drag-from))
        drag-to (first (hooks/use-atom *drag-to))
        collapsed? (rfx/use-sub [:ui/sidebar-collapsed-blocks db-id])]
    (sidebar-item-inner db-id {:repo repo
                               :idx idx
                               :block-type block-type
                               :collapsed? collapsed?
                               :drag-from drag-from
                               :drag-to drag-to
                               :block-count block-count
                               :*db-id *db-id
                               :init-key init-key})))

(def sidebar-item
  (let [memo-class (react/memo
                    (fn [^js props]
                      (apply sidebar-item-component (.-args props)))
                    (fn [^js prev-props ^js next-props]
                      (= (.-args prev-props) (.-args next-props))))]
    (fn [& args]
      (react/createElement memo-class #js {:args (vec args)}))))

(defn- get-page
  [match]
  (let [route-name (get-in match [:data :name])
        page (case route-name
               :page
               (get-in match [:path-params :name])

               :file
               (get-in match [:path-params :path])

               (date/today))]
    (when page
      (string/lower-case page))))

(defn get-current-page
  []
  (let [match (state/get-state :route-match)]
    (get-page match)))

(hsx/defc sidebar-resizer
  [sidebar-open? sidebar-id handler-position]
  (let [el-ref (hooks/use-ref nil)
        min-px-width 320 ; Custom window controls width
        min-ratio 0.1
        max-ratio 0.7
        keyboard-step 5
        add-resizing-class #(.. js/document.documentElement -classList (add "is-resizing-buf"))
        remove-resizing-class (fn []
                                (.. js/document.documentElement -classList (remove "is-resizing-buf"))
                                (reset! ui-handler/*right-sidebar-resized-at (js/Date.now)))
        set-width! (fn [ratio]
                     (when el-ref
                       (let [value (* ratio 100)
                             width (str value "%")]
                         (.setAttribute (hooks/deref el-ref) "aria-valuenow" value)
                         (ui-handler/persist-right-sidebar-width! width))))]
    (hooks/use-effect!
     (fn []
       (when-let [el (and (fn? js/window.interact) (hooks/deref el-ref))]
         (-> (js/interact el)
             (.draggable
              (bean/->js
               {:listeners
                {:move
                 (fn [^js/MouseEvent e]
                   (let [width js/document.documentElement.clientWidth
                         min-ratio (max min-ratio (/ min-px-width width))
                         sidebar-el (js/document.getElementById sidebar-id)
                         offset (.-pageX e)
                         ratio (.toFixed (/ offset width) 6)
                         ratio (if (= handler-position :west) (- 1 ratio) ratio)
                         cursor-class (str "cursor-" (first (name handler-position)) "-resize")]
                     (if (= (.getAttribute el "data-expanded") "true")
                       (cond
                         (< ratio (/ min-ratio 2))
                         (state/hide-right-sidebar!)

                         (< ratio min-ratio)
                         (.. js/document.documentElement -classList (add cursor-class))

                         (and (< ratio max-ratio) sidebar-el)
                         (when sidebar-el
                           (#(.. js/document.documentElement -classList (remove cursor-class))
                            (set-width! ratio)))
                         :else
                         #(.. js/document.documentElement -classList (remove cursor-class)))
                       (when (> ratio (/ min-ratio 2)) (state/open-right-sidebar!)))))}}))
             (.styleCursor false)
             (.on "dragstart" add-resizing-class)
             (.on "dragend" remove-resizing-class)
             (.on "keydown" (fn [e]
                              (when-let [sidebar-el (js/document.getElementById sidebar-id)]
                                (let [width js/document.documentElement.clientWidth
                                      min-ratio (max min-ratio (/ min-px-width width))
                                      keyboard-step (case (.-code e)
                                                      "ArrowLeft" (- keyboard-step)
                                                      "ArrowRight" keyboard-step
                                                      0)
                                      offset (+ (.-x (.getBoundingClientRect sidebar-el)) keyboard-step)
                                      ratio (.toFixed (/ offset width) 6)
                                      ratio (if (= handler-position :west) (- 1 ratio) ratio)]
                                  (when (and (> ratio min-ratio) (< ratio max-ratio) (not (zero? keyboard-step)))
                                    (add-resizing-class)
                                    (set-width! ratio))))))
             (.on "keyup" remove-resizing-class)))
       #())
     [])

    (hooks/use-effect!
     (fn []
        ;; sidebar animation duration
       (js/setTimeout
        #(reset! ui-handler/*right-sidebar-resized-at (js/Date.now)) 300))
     [sidebar-open?])

    [:.resizer
     {:ref              el-ref
      :role             "separator"
      :aria-orientation "vertical"
      :aria-label       (t :sidebar.right/resize-handle)
      :aria-valuemin    (* min-ratio 100)
      :aria-valuemax    (* max-ratio 100)
      :aria-valuenow    50
      :tabIndex         "0"
      :data-expanded    sidebar-open?}]))

(hsx/defc plugin-renderer-menu-items
  [renderers]
  (for [r renderers]
    (shui/dropdown-menu-item
      {:on-click #(state/sidebar-add-block!
                    (state/get-current-repo)
                    (keyword (:pid r) (:key r))
                    :plugin
                    )}
      [:div.flex.items-center
       {:title (str (:pid r))}
       [:span.pr-1.flex.items-center (shui/tabler-icon "puzzle")]
       [:strong (:title r)]])))

(hsx/defc sidebar-inner
  [repo t blocks]
  (let [block-count (count blocks)
        developer-mode? (rfx/use-sub [:ui/developer-mode?])]
    [:div.cp__right-sidebar-inner.flex.flex-col.h-full#right-sidebar-container

     [:div.cp__right-sidebar-scrollable
      {:on-drag-over util/stop}
      [:div.cp__right-sidebar-topbar.flex.flex-row.justify-between.items-center
       [:div.cp__right-sidebar-settings.hide-scrollbar.gap-1 {:key "right-sidebar-settings"}
        ;; sidebar renderers from plugins
        (when-let [renderers (and config/lsp-enabled?
                               (some->> (plugin-handler/get-hosted-renderers)
                                 (filter #(= (:type %) "sidebar"))
                                 (seq)))]
          [:div.text-sm
           [:button.button.cp__right-sidebar-settings-btn
            {:on-click (fn [e]
                         (shui/popup-show! e
                           (plugin-renderer-menu-items renderers)
                           {:as-dropdown? true
                            :content-props {:on-click (fn [] (shui/popup-hide!))}}))}
            [:span.nu.flex.items-center.opacity-80 (shui/tabler-icon "cube-plus")]]])

        [:div.text-sm
         [:button.button.cp__right-sidebar-settings-btn {:on-click (fn [_e]
                                                                     (state/sidebar-add-block! repo "contents" :contents))}
          (t :page/contents)]]

        [:div.text-sm
         [:button.button.cp__right-sidebar-settings-btn {:on-click (fn []
                                                                     (when-let [page (get-current-page)]
                                                                       (state/sidebar-add-block!
                                                                        repo
                                                                        page
                                                                        :page-graph)))}
          (t :graph.page/title)]]

        [:div.text-sm
         [:button.button.cp__right-sidebar-settings-btn {:on-click (fn [_e]
                                                                     (state/sidebar-add-block! repo "help" :help))}
          (t :nav/help)]]

        (for [{:keys [db-id block-type label]} (dev-sidebar-items developer-mode?)]
          [:div.text-sm {:key (str "dev-sidebar-item-" (name block-type))}
           [:button.button.cp__right-sidebar-settings-btn
            {:on-click (fn [_e]
                         (state/sidebar-add-block! repo db-id block-type))}
            label]])]]

      [:.sidebar-item-list.flex-1.scrollbar-spacing.px-2
       (for [[idx [repo db-id block-type]] (medley/indexed blocks)]
         ^{:key (str "sidebar-block-" db-id)}
         [:<> (sidebar-item repo idx db-id block-type block-count)])]]]))

(hsx/defc sidebar-component
  []
  (let [blocks (state/use-right-sidebar-blocks)
        blocks (if (empty? blocks)
                 [[(state/get-current-repo) "contents" :contents nil]]
                 blocks)
        sidebar-open? (rfx/use-sub [:ui/sidebar-open?])
        width (rfx/use-sub [:ui/sidebar-width])
        repo (rfx/use-sub [:git/current-repo])]
    [:div#right-sidebar.cp__right-sidebar.h-screen
     {:class (if sidebar-open? "open" "closed")
      :style {:width width}}
     (sidebar-resizer sidebar-open? "right-sidebar" :west)
     (when sidebar-open?
       (sidebar-inner repo t blocks))]))

(def sidebar
  (let [memo-class (react/memo
                    (fn [_props]
                      (sidebar-component)))]
    (fn []
      (react/createElement memo-class #js {}))))
