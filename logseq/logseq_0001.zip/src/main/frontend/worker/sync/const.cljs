(ns frontend.worker.sync.const
  "RTC constants"
  (:require [logseq.common.defkeywords :as common-def :refer [defkeywords]]
            [logseq.db.frontend.kv-entity :as kv-entity]
            [logseq.db.frontend.property :as db-property]))

(defkeywords
  :db-sync/invalid-e2ee-password
  {:doc "The supplied E2EE password cannot decrypt the current server private key."}
  :rtc/ignore-attr-when-syncing
  {:doc "keyword option for RTC. ignore this *attr* when syncing graph. Default false"}
  :rtc/ignore-entity-when-init-upload
  {:doc "keyword option for RTC. ignore this *entity* when initial uploading graph. Default false"})

(def ignore-attrs-when-syncing
  (into #{}
        (keep (fn [[kw config]] (when (get-in config [:rtc :rtc/ignore-attr-when-syncing]) kw)))
        db-property/built-in-properties))

(def ignore-entities-when-init-upload
  (into #{}
        (keep (fn [[kw config]] (when (get-in config [:rtc :rtc/ignore-entity-when-init-upload]) kw)))
        kv-entity/kv-entities))

(def encrypt-attr-set
  "block attributes that need to be encrypted"
  #{:block/title :block/name})
