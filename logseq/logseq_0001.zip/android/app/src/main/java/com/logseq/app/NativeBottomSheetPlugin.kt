package com.logseq.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

@CapacitorPlugin(name = "NativeBottomSheetPlugin")
class NativeBottomSheetPlugin : Plugin() {
    private val snapshotTag = "bottom-sheet"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var dialog: BottomSheetDialog? = null
    private var pendingPresentation: (() -> Unit)? = null
    private var awaitingContentReady = false
    private var previousParent: ViewGroup? = null
    private var previousIndex: Int = -1
    private var previousLayoutParams: ViewGroup.LayoutParams? = null
    private var placeholder: View? = null
    private var container: FrameLayout? = null
    private var pendingRestoreWebView: View? = null
    private var dismissalFallback: Runnable? = null

    @PluginMethod
    fun present(call: PluginCall) {
        val activity = activity ?: run {
            call.reject("No activity")
            return
        }
        val webView = bridge.webView ?: run {
            call.reject("No webview")
            return
        }

        activity.runOnUiThread {
            WebViewSnapshotManager.registerWindow(activity.window)
            if (dialog != null || pendingPresentation != null || awaitingContentReady) {
                call.resolve()
                return@runOnUiThread
            }

            val ctx = activity
            container = FrameLayout(ctx)
            container!!.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            val cornerRadius = NativeUiUtils.dp(ctx, 16f).toFloat()
            val roundedBackground = GradientDrawable().apply {
                setColor(LogseqTheme.current().background)
                cornerRadii = floatArrayOf(
                    cornerRadius, cornerRadius,  // 左上角
                    cornerRadius, cornerRadius,  // 右上角
                    0f, 0f,                      // 右下角
                    0f, 0f                       // 左下角
                )
            }
            container!!.background = roundedBackground
            container!!.clipToOutline = true

            val sheet = BottomSheetDialog(ctx)
            sheet.setContentView(container!!)

            sheet.setOnShowListener {
                val bottomSheet = sheet.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
                bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            }

            WebViewSnapshotManager.showSnapshot(snapshotTag, webView)

            val behavior = sheet.behavior
            val defaultHeight = call.getInt("defaultHeight", null)
            val allowFullHeight = call.getBoolean("allowFullHeight") ?: true
            if (defaultHeight != null) {
                val peek = NativeUiUtils.dp(ctx, defaultHeight.toFloat())
                behavior.peekHeight = peek
                behavior.state = BottomSheetBehavior.STATE_COLLAPSED
            } else {
                behavior.state = BottomSheetBehavior.STATE_COLLAPSED
            }
            behavior.skipCollapsed = !allowFullHeight

            sheet.setOnDismissListener {
                awaitingContentReady = true

                // Forcefully detach WebView before restoring
                try {
                    (webView.parent as? ViewGroup)?.removeView(webView)
                    container?.removeAllViews()
                } catch (_: Exception) {}

                // Delay restoration slightly to let Android clean up window surfaces
                mainHandler.post {
                    restoreWebView(webView)
                    webView.alpha = 0f
                    pendingRestoreWebView = webView
                    awaitingContentReady = true
                    scheduleDismissalFallback()
                }

                notifyListeners("state", JSObject().put("dismissing", true))
                dialog = null
                container = null
            }

            pendingPresentation = {
                detachWebView(webView, ctx)
                container!!.addView(
                    webView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                sheet.show()
                notifyListeners("state", JSObject().put("presented", true))
                dialog = sheet
                call.resolve()
            }
            notifyListeners("state", JSObject().put("presenting", true))
        }
    }

    @PluginMethod
    fun dismiss(call: PluginCall) {
        activity?.runOnUiThread {
            if (pendingPresentation != null) {
                pendingPresentation = null
                container = null
                WebViewSnapshotManager.clearSnapshot(snapshotTag)
                notifyListeners("state", JSObject().put("dismissing", true))
                notifyListeners(
                    "state",
                    JSObject()
                        .put("presented", false)
                        .put("dismissing", false)
                )
                call.resolve()
                return@runOnUiThread
            }

            if (dialog == null) {
                pendingRestoreWebView?.let { finishDismissal(it) }
                    ?: WebViewSnapshotManager.clearSnapshot(snapshotTag)
                call.resolve()
                return@runOnUiThread
            }

            dialog?.dismiss()
            call.resolve()
        } ?: call.resolve()
    }

    @PluginMethod
    fun contentReady(call: PluginCall) {
        activity?.runOnUiThread {
            pendingPresentation?.let { presentation ->
                pendingPresentation = null
                presentation()
                call.resolve()
                return@runOnUiThread
            }

            val webView = pendingRestoreWebView
            if (!awaitingContentReady || webView == null) {
                call.resolve()
                return@runOnUiThread
            }

            finishDismissal(webView)
            call.resolve()
        } ?: call.resolve()
    }

    private fun detachWebView(webView: View, ctx: android.content.Context) {
        val parent = webView.parent as? ViewGroup ?: return
        previousParent = parent
        previousIndex = parent.indexOfChild(webView)
        previousLayoutParams = webView.layoutParams

        parent.removeView(webView)
        placeholder = View(ctx).apply {
            setBackgroundColor(LogseqTheme.current().background)
            layoutParams = previousLayoutParams ?: ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        parent.addView(placeholder, previousIndex)
    }

    private fun restoreWebView(webView: View) {
        val parent = previousParent ?: return
        val lp = previousLayoutParams ?: ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        // Fully detach from any container
        (webView.parent as? ViewGroup)?.removeView(webView)
        placeholder?.let { parent.removeView(it) }
        placeholder = null

        // Reattach WebView
        if (previousIndex in 0..parent.childCount) {
            parent.addView(webView, previousIndex, lp)
        } else {
            parent.addView(webView, lp)
        }

        // ✅ Force WebView to recreate its SurfaceView and redraw
        webView.visibility = View.INVISIBLE
        webView.post {
            webView.visibility = View.VISIBLE
            webView.requestLayout()
            webView.invalidate()
            webView.dispatchWindowVisibilityChanged(View.VISIBLE)
        }

        previousParent = null
        previousLayoutParams = null
        previousIndex = -1
        container = null
    }

    private fun finishDismissal(webView: View) {
        dismissalFallback?.let(mainHandler::removeCallbacks)
        dismissalFallback = null
        awaitingContentReady = false
        pendingRestoreWebView = null

        webView.alpha = 1f
        webView.requestLayout()
        webView.invalidate()

        WebViewSnapshotManager.clearSnapshot(snapshotTag)
        notifyListeners(
            "state",
            JSObject()
                .put("presented", false)
                .put("dismissing", false)
        )
    }

    private fun scheduleDismissalFallback() {
        dismissalFallback?.let(mainHandler::removeCallbacks)

        val runnable = Runnable {
            val webView = pendingRestoreWebView
            if (awaitingContentReady && webView != null) {
                finishDismissal(webView)
            }
        }

        dismissalFallback = runnable
        mainHandler.postDelayed(runnable, 2_000)
    }
}
