(ns logseq.e2e.graph
  (:require [logseq.e2e.assert :as assert]
            [logseq.e2e.keyboard :as k]
            [logseq.e2e.util :as util]
            [wally.main :as w])
  (:import [com.microsoft.playwright Locator$ClickOptions]))

(defn refresh-all-remote-graphs
  []
  (let [enabled-refresh "button:not([disabled]):has-text(\"Refresh\")"]
    (w/wait-for enabled-refresh {:timeout 30000})
    (w/click enabled-refresh
             (-> (Locator$ClickOptions.)
                 (.setTimeout 30000)))))

(defn goto-all-graphs
  []
  (util/search-and-click "Go to all graphs"))

(def ^:private e2ee-password-modal ".e2ee-password-modal-content")
(def ^:private e2ee-new-password-input (str e2ee-password-modal " input[placeholder=\"Enter password\"]"))
(def ^:private e2ee-new-password-confirm-input (str e2ee-password-modal " input[placeholder=\"Enter password again\"]"))
(def ^:private e2ee-password-input (str e2ee-password-modal " .ls-toggle-password-input input"))
(def ^:private e2ee-password-submit (str e2ee-password-modal " button:text(\"Submit\")"))
(def ^:private cloud-ready-indicator "button.cloud.on.idle")
(def ^:private new-graph-dialog ".new-graph")
(def ^:private new-graph-submit (str new-graph-dialog " button:not([disabled]):text(\"Submit\")"))
(def ^:private rtc-sync-toggle "button#rtc-sync")
(def ^:private rtc-graph-e2ee-toggle "button#rtc-graph-e2ee")
(def ^:private e2ee-password-poll-ms 250)
(def ^:private e2ee-password-prompt-grace-ms 2000)

(defn- input-e2ee-password
  []
  (if (w/visible? e2ee-new-password-confirm-input)
    (do
      (w/click e2ee-new-password-input)
      (util/input "e2etest")
      (w/click e2ee-new-password-confirm-input)
      (util/input "e2etest"))
    (do
      (w/click (.first (w/-query e2ee-password-input)))
      (util/input "e2etest")))
  (w/click e2ee-password-submit)
  (w/wait-for-not-visible e2ee-password-modal))

(defn- maybe-input-e2ee-password
  []
  ;; Password input prompt is optional for accounts with already initialized keys/password.
  ;; Cloud-ready can still be visible from the previous graph right after submit,
  ;; so wait for it to stay visible briefly before treating it as the terminal state.
  (loop [remaining-ms 20000
         cloud-ready-ms 0]
    (cond
      (w/visible? e2ee-password-modal)
      (input-e2ee-password)

      (and (>= cloud-ready-ms e2ee-password-prompt-grace-ms)
           (w/visible? cloud-ready-indicator))
      nil

      (<= remaining-ms 0)
      nil

      :else
      (let [cloud-ready? (w/visible? cloud-ready-indicator)]
        (util/wait-timeout e2ee-password-poll-ms)
        (recur (- remaining-ms e2ee-password-poll-ms)
               (if cloud-ready?
                 (+ cloud-ready-ms e2ee-password-poll-ms)
                 0))))))

(defn- new-graph-helper
  [graph-name enable-sync? graph-e2ee?]
  (util/search-and-click "Add a DB graph")
  (w/wait-for "h2:text(\"Create a new graph\")")
  (w/click "input[placeholder=\"your graph name\"]")
  (util/input graph-name)
  (when enable-sync?
    (w/wait-for rtc-sync-toggle {:timeout 3000})
    (w/click rtc-sync-toggle)
    (when-not graph-e2ee?
      (w/wait-for rtc-graph-e2ee-toggle {:timeout 3000})
      (w/click rtc-graph-e2ee-toggle)))

  (w/click new-graph-submit)

  (when enable-sync?
    (maybe-input-e2ee-password)
    (w/wait-for cloud-ready-indicator {:timeout 20000}))

  (w/wait-for-not-visible new-graph-dialog {:timeout 30000})
  (assert/assert-graph-loaded?))

(defn new-graph
  ([graph-name enable-sync?]
   (new-graph graph-name enable-sync? true))
  ([graph-name enable-sync? graph-e2ee?]
   (new-graph-helper graph-name enable-sync? graph-e2ee?)))

(defn wait-for-remote-graph
  [graph-name]
  (goto-all-graphs)
  (util/repeat-until-visible 5
                             (format "div[data-testid='logseq_db_%s']" graph-name)
                             refresh-all-remote-graphs))

(defn remove-local-graph
  [graph-name]
  (wait-for-remote-graph graph-name)
  (let [action-btn
        (.first (w/-query (format "div[data-testid='logseq_db_%s'] .graph-action-btn" graph-name)))]
    (w/click action-btn)
    (w/click ".delete-local-graph-menu-item")
    (w/click "div[role='alertdialog'] button:text('Confirm')")))

(defn remove-remote-graph
  [graph-name]
  (wait-for-remote-graph graph-name)
  (let [action-btn
        (.first (w/-query (format "div[data-testid='logseq_db_%s'] .graph-action-btn" graph-name)))]
    (w/click action-btn)
    (w/click ".delete-remote-graph-menu-item")
    (w/click "div[role='alertdialog'] button:text('Confirm')")))

(defn switch-graph
  [to-graph-name wait-sync? need-input-password?]
  (goto-all-graphs)
  (w/click (.last (w/-query (format "div[data-testid='logseq_db_%1$s'] span:has-text('%1$s')" to-graph-name))))
  (when wait-sync?
    (when need-input-password? (maybe-input-e2ee-password))
    (w/wait-for cloud-ready-indicator {:timeout 20000}))
  (assert/assert-graph-loaded?))

(defn validate-graph
  []
  (let [success-toast ".ui__toast:has-text('Your graph is valid')"]
    (k/esc)
    (k/esc)
    (util/search-and-click "(Dev) Validate current graph")
    (w/wait-for success-toast {:timeout 30000})
    (w/eval-js
     "() => document.querySelectorAll('.ui__toast.success button')
       .forEach((button) => button.click())")
    {:valid? true}))
