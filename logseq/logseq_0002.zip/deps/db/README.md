## Description

This library provides an API to the
frontend([datascript](https://github.com/tonsky/datascript)) and
backend([SQLite](https://www.sqlite.org/index.html)) databases from the Logseq
app and the CLI. This library defines the core schema and fns for DB graphs.
There are a few namespaces that also support file graphs for the graph-parser.
This library is compatible with ClojureScript and with
[nbb-logseq](https://github.com/logseq/nbb-logseq) to respectively provide
frontend and commandline functionality.

## API

This library is under the parent namespace `logseq.db`. It provides the following namespaces:
* `logseq.db` - main public ns. Most often used by frontend
* `logseq.db.frontend.*` - frontend namespaces for DB graphs
* `logseq.db.sqlite.*` - backend/sqlite namespaces for DB graphs
* `logseq.db.common.*` - frontend and backend namespaces for DB graphs

The following namespaces are used with file graphs via the graph-parser: `logseq.db.common.order, logseq.db.frontend.entity-util and logseq.db.common.entity-plus`.

## Usage

See the frontend for example usage.

## Dev

This follows the practices that [the Logseq frontend
follows](/docs/dev-practices.md). Most of the same linters are used, with
configurations that are specific to this library. See [this library's CI
file](/.github/workflows/deps-db.yml) for linting examples.

### Setup

To run linters and tests, you'll want to install pnpm dependencies once:
```
pnpm install
```

This step is not needed if you're just running the application.

### Testing

Testing is done with nbb-logseq and
[nbb-test-runner](https://github.com/nextjournal/nbb-test-runner). Some basic
usage:

```
# Run all tests
$ pnpm test
# List available options
$ pnpm test -H
# Run tests with :focus metadata flag
$ pnpm test -i focus
```
### Datalog linting

Datalog rules for the client are linted through a script that also uses the datalog-parser. To run this linter:
```
bb lint:rules
```

### Managing dependencies

The package.json dependencies are just for testing and should be updated if there is
new behavior to test.

The deps.edn dependencies are used by both ClojureScript and nbb-logseq. Their
versions should be backwards compatible with each other with priority given to
the frontend. _No new dependency_ should be introduced to this library without
an understanding of the tradeoffs of adding this to nbb-logseq.
