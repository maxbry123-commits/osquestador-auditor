/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.shell.state;

import java.util.Iterator;
import java.util.List;
import org.neo4j.driver.Record;
import org.neo4j.driver.summary.ResultSummary;

/**
 * The result of executing some Cypher over bolt.
 */
public interface BoltResult {

    List<String> getKeys();

    List<Record> getRecords();

    Iterator<Record> iterate();

    ResultSummary getSummary();

    default List<String> getRawKeys() {
        return List.of();
    }
}
