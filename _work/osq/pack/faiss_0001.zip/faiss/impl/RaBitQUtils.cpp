/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#include <faiss/impl/RaBitQUtils.h>

#include <faiss/impl/FaissAssert.h>
#include <faiss/impl/simd_dispatch.h>
#include <faiss/utils/distances.h>
#include <faiss/utils/rabitq_simd.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>

namespace faiss {
namespace rabitq_utils {

// Verify no unexpected padding in structures used for per-vector storage.
// These checks ensure compute_per_vector_storage_size() remains accurate.
static_assert(
        sizeof(SignBitFactors) == 8,
        "SignBitFactors has unexpected padding");
static_assert(
        sizeof(SignBitFactorsWithError) == 12,
        "SignBitFactorsWithError has unexpected padding");
static_assert(
        sizeof(ExtraBitsFactors) == 8,
        "ExtraBitsFactors has unexpected padding");

// Ideal quantizer radii for quantizers of 1..8 bits, optimized to minimize
// L2 reconstruction error.
const float Z_MAX_BY_QB[8] = {
        0.79688, // qb = 1.
        1.49375,
        2.05078,
        2.50938,
        2.91250,
        3.26406,
        3.59844,
        3.91016, // qb = 8.
};

void compute_vector_intermediate_values(
        const float* x,
        size_t d,
        const float* centroid,
        float& norm_L2sqr,
        float& or_L2sqr,
        float& dp_oO) {
    norm_L2sqr = 0.0f;
    or_L2sqr = 0.0f;
    dp_oO = 0.0f;

    for (size_t j = 0; j < d; j++) {
        const float x_val = x[j];
        const float centroid_val = (centroid != nullptr) ? centroid[j] : 0.0f;
        const float or_minus_c = x_val - centroid_val;

        const float or_minus_c_sq = or_minus_c * or_minus_c;
        norm_L2sqr += or_minus_c_sq;
        or_L2sqr += x_val * x_val;

        const bool xb = (or_minus_c > 0.0f);
        dp_oO += xb ? or_minus_c : -or_minus_c;
    }
}

SignBitFactorsWithError compute_factors_from_intermediates(
        float norm_L2sqr,
        float or_L2sqr,
        float dp_oO,
        size_t d,
        MetricType metric_type,
        bool compute_error) {
    constexpr float epsilon = std::numeric_limits<float>::epsilon();
    constexpr float kConstEpsilon =
            1.9f; // Error bound constant from RaBitQ paper
    const float inv_d_sqrt =
            (d == 0) ? 1.0f : (1.0f / std::sqrt(static_cast<float>(d)));

    const float sqrt_norm_L2 = std::sqrt(norm_L2sqr);
    const float inv_norm_L2 =
            (norm_L2sqr < epsilon) ? 1.0f : (1.0f / sqrt_norm_L2);

    const float normalized_dp = dp_oO * inv_norm_L2 * inv_d_sqrt;
    const float inv_dp_oO =
            (std::abs(normalized_dp) < epsilon) ? 1.0f : (1.0f / normalized_dp);

    SignBitFactorsWithError factors;
    factors.or_minus_c_l2sqr = (metric_type == MetricType::METRIC_INNER_PRODUCT)
            ? (norm_L2sqr - or_L2sqr)
            : norm_L2sqr;
    factors.dp_multiplier = inv_dp_oO * sqrt_norm_L2;

    // Compute error bound only if needed (skip for 1-bit mode)
    if (compute_error) {
        const float xu_cb_norm_sqr = static_cast<float>(d) * 0.25f;
        const float ip_resi_xucb = 0.5f * dp_oO;

        float tmp_error = 0.0f;
        if (std::abs(ip_resi_xucb) > epsilon) {
            const float ratio_sq = (norm_L2sqr * xu_cb_norm_sqr) /
                    (ip_resi_xucb * ip_resi_xucb);
            if (ratio_sq > 1.0f) {
                if (d == 1) {
                    tmp_error = sqrt_norm_L2 * kConstEpsilon *
                            std::sqrt(ratio_sq - 1.0f);
                } else {
                    tmp_error = sqrt_norm_L2 * kConstEpsilon *
                            std::sqrt((ratio_sq - 1.0f) /
                                      static_cast<float>(d - 1));
                }
            }
        }

        // Apply metric-specific multiplier
        if (metric_type == MetricType::METRIC_L2) {
            factors.f_error = 2.0f * tmp_error;
        } else if (metric_type == MetricType::METRIC_INNER_PRODUCT) {
            factors.f_error = 1.0f * tmp_error;
        } else {
            factors.f_error = 0.0f;
        }
    }

    return factors;
}

SignBitFactorsWithError compute_vector_factors(
        const float* x,
        size_t d,
        const float* centroid,
        MetricType metric_type,
        bool compute_error) {
    float norm_L2sqr, or_L2sqr, dp_oO;
    compute_vector_intermediate_values(
            x, d, centroid, norm_L2sqr, or_L2sqr, dp_oO);
    return compute_factors_from_intermediates(
            norm_L2sqr, or_L2sqr, dp_oO, d, metric_type, compute_error);
}

QueryFactorsData compute_query_factors(
        const float* query,
        size_t d,
        const float* centroid,
        uint8_t qb,
        bool centered,
        MetricType metric_type,
        std::vector<float>& rotated_q,
        std::vector<uint8_t>& rotated_qq) {
    FAISS_THROW_IF_NOT(qb <= 8);
    FAISS_THROW_IF_NOT(qb > 0);
    FAISS_THROW_IF_NOT(d > 0);

    QueryFactorsData query_factors;

    // Compute distance from query to centroid
    if (centroid != nullptr) {
        query_factors.qr_to_c_L2sqr = fvec_L2sqr(query, centroid, d);
    } else {
        query_factors.qr_to_c_L2sqr = fvec_norm_L2sqr(query, d);
    }
    query_factors.g_error = std::sqrt(query_factors.qr_to_c_L2sqr);

    // Rotate the query (subtract centroid)
    // Save aliasing state before resize(), which may reallocate the buffer.
    const bool query_aliased = (query == rotated_q.data());
    FAISS_THROW_IF_NOT_MSG(
            !query_aliased || centroid == nullptr,
            "query aliasing is only supported in the IVF residual path "
            "(centroid == nullptr)");
    rotated_q.resize(d);
    if (centroid == nullptr) {
        // Caller may pass query == rotated_q.data() (IVF residual path);
        // memcpy with overlapping src/dst is UB, so skip the copy in that case.
        if (!query_aliased) {
            memcpy(rotated_q.data(), query, d * sizeof(float));
        }
    } else {
        for (size_t i = 0; i < d; i++) {
            rotated_q[i] = query[i] - centroid[i];
        }
    }

    const float inv_d_sqrt = 1.0f / std::sqrt(static_cast<float>(d));

    const float* rq = rotated_q.data();
    float v_min;
    float v_max;
    float delta;
    size_t sum_qq = 0;
    int64_t sum2_signed_odd_int = 0;
    const uint8_t max_code = (1 << qb) - 1;
    rotated_qq.resize(d);
    uint8_t* rqq = rotated_qq.data();

    // Select the SIMD implementation once for both range computation and
    // quantization. This function runs once per query/probe pair.
    with_selected_simd_levels<rabitq::RABITQ_QUANTIZATION_SIMD_LEVELS>(
            [&]<SIMDLevel SL>() {
                if (centered) {
                    const float z_max = Z_MAX_BY_QB[qb - 1];
                    const float v_radius =
                            z_max * std::sqrt(query_factors.qr_to_c_L2sqr / d);
                    v_min = -v_radius;
                    v_max = v_radius;
                } else {
                    v_min = std::numeric_limits<float>::max();
                    v_max = std::numeric_limits<float>::lowest();
                    rabitq::minmax_values<SL>(rq, d, v_min, v_max);
                }

                delta = (v_max - v_min) / max_code;
                // A constant (or zero-norm) query has delta == 0. Preserve the
                // scalar path's centered correction terms while avoiding
                // 0 * inf during quantization.
                if (delta <= 0.0f) {
                    memset(rqq, 0, d * sizeof(uint8_t));
                    if (centered) {
                        sum2_signed_odd_int = int64_t(d) * max_code * max_code;
                    }
                } else {
                    rabitq::quantize_query_values<SL>(
                            rq,
                            d,
                            v_min,
                            1.0f / delta,
                            max_code,
                            centered,
                            rqq,
                            sum_qq,
                            sum2_signed_odd_int);
                }
            });

    // Compute query factors
    query_factors.c1 = 2 * delta * inv_d_sqrt;
    query_factors.c2 = 2 * v_min * inv_d_sqrt;
    query_factors.c34 = inv_d_sqrt * (delta * sum_qq + d * v_min);

    if (centered) {
        query_factors.int_dot_scale = std::sqrt(
                query_factors.qr_to_c_L2sqr / (sum2_signed_odd_int * d));
    } else {
        query_factors.int_dot_scale = 1.0f;
    }

    // Compute query norm for inner product metric.
    // When centroid is nullptr (IVF residual path), qr_to_c_L2sqr already
    // holds fvec_norm_L2sqr(query, d) from line 164, so reuse it.
    query_factors.qr_norm_L2sqr = 0.0f;
    query_factors.q_dot_c = 0.0f;
    if (metric_type == MetricType::METRIC_INNER_PRODUCT) {
        query_factors.qr_norm_L2sqr = (centroid == nullptr)
                ? query_factors.qr_to_c_L2sqr
                : fvec_norm_L2sqr(query, d);
        if (centroid != nullptr) {
            query_factors.q_dot_c = fvec_inner_product(query, centroid, d);
        }
    }

    return query_factors;
}

bool extract_bit_standard(const uint8_t* code, size_t bit_index) {
    const size_t byte_idx = bit_index / 8;
    const size_t bit_offset = bit_index % 8;
    return (code[byte_idx] >> bit_offset) & 1;
}

bool extract_bit_fastscan(const uint8_t* code, size_t bit_index) {
    const size_t m = bit_index / 4; // Sub-quantizer index
    const size_t dim_offset =
            bit_index % 4;         // Bit position within sub-quantizer
    const size_t byte_idx = m / 2; // Byte index (2 sub-quantizers per byte)
    const uint8_t bit_mask = static_cast<uint8_t>(1 << dim_offset);

    if (m % 2 == 0) {
        // Lower 4 bits of byte
        return (code[byte_idx] & bit_mask) != 0;
    } else {
        // Upper 4 bits of byte (shifted)
        return (code[byte_idx] & (bit_mask << 4)) != 0;
    }
}

void set_bit_standard(uint8_t* code, size_t bit_index) {
    const size_t byte_idx = bit_index / 8;
    const size_t bit_offset = bit_index % 8;
    code[byte_idx] |= (1 << bit_offset);
}

void set_bit_fastscan(uint8_t* code, size_t bit_index) {
    const size_t m = bit_index / 4;
    const size_t dim_offset = bit_index % 4;
    const uint8_t bit_mask = static_cast<uint8_t>(1 << dim_offset);
    const size_t byte_idx = m / 2;

    if (m % 2 == 0) {
        code[byte_idx] |= bit_mask;
    } else {
        code[byte_idx] |= (bit_mask << 4);
    }
}

size_t compute_per_vector_storage_size(size_t nb_bits, size_t d) {
    const size_t ex_bits = nb_bits - 1;
    if (ex_bits == 0) {
        return sizeof(SignBitFactors);
    } else {
        return sizeof(SignBitFactorsWithError) + sizeof(ExtraBitsFactors) +
                (d * ex_bits + 7) / 8;
    }
}

// Non-template wrapper with dynamic dispatch (one dispatch per call).
// The hot path in RaBitQuantizer dispatches once at distance computer
// construction, so per-vector dispatch only affects this utility path.
float compute_full_multibit_distance(
        const uint8_t* sign_bits,
        const uint8_t* ex_code,
        const ExtraBitsFactors& ex_fac,
        const float* rotated_q,
        float qr_base,
        size_t d,
        size_t ex_bits,
        MetricType metric_type) {
    return with_selected_simd_levels<AVAILABLE_SIMD_LEVELS_A0_SPR>(
            [&]<SIMDLevel SL>() {
                return compute_full_multibit_distance<SL>(
                        sign_bits,
                        ex_code,
                        ex_fac,
                        rotated_q,
                        qr_base,
                        d,
                        ex_bits,
                        metric_type);
            });
}

void populate_block_aux_from_flat_storage(
        const std::vector<uint8_t>& flat_storage,
        AlignedTable<uint8_t>& codes,
        size_t num_vectors,
        size_t bbs,
        size_t M2,
        size_t old_block_stride,
        size_t new_block_stride,
        size_t storage_size,
        const int64_t* id_map) {
    if (flat_storage.empty() || num_vectors == 0) {
        return;
    }

    const size_t packed_block_size = ((M2 + 1) / 2) * bbs;
    const size_t n_blocks = (num_vectors + bbs - 1) / bbs;

    if (old_block_stride < new_block_stride) {
        AlignedTable<uint8_t> old_data;
        old_data.resize(codes.size());
        memcpy(old_data.data(), codes.data(), codes.size());

        codes.resize(n_blocks * new_block_stride);
        memset(codes.data(), 0, n_blocks * new_block_stride);
        for (size_t b = 0; b < n_blocks; b++) {
            memcpy(codes.data() + b * new_block_stride,
                   old_data.data() + b * old_block_stride,
                   packed_block_size);
        }
    }

    for (size_t offset = 0; offset < num_vectors; offset++) {
        const int64_t global_id =
                id_map ? id_map[offset] : static_cast<int64_t>(offset);
        FAISS_THROW_IF_NOT_MSG(
                global_id >= 0 &&
                        static_cast<size_t>(global_id) * storage_size +
                                        storage_size <=
                                flat_storage.size(),
                "global_id out of bounds for flat_storage during migration");

        const uint8_t* src = flat_storage.data() + global_id * storage_size;
        uint8_t* dst = get_block_aux_ptr(
                codes.data(),
                offset,
                bbs,
                packed_block_size,
                new_block_stride,
                storage_size);
        memcpy(dst, src, storage_size);
    }
}

} // namespace rabitq_utils
} // namespace faiss
