/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#pragma once

#include <functional>
#include <optional>
#include <queue>
#include <utility>
#include <vector>

#include <omp.h>

#include <faiss/Index.h>
#include <faiss/impl/DistanceComputer.h>
#include <faiss/impl/FaissAssert.h>
#include <faiss/impl/maybe_owned_vector.h>
#include <faiss/utils/Heap.h>
#include <faiss/utils/random.h>

namespace faiss {

// Forward declarations to avoid circular dependency.
struct IndexHNSW;
struct IndexHNSWFlatPanorama;
template <class HC_>
struct MinimaxHeapT;
using MinimaxHeap = MinimaxHeapT<CMax<float, int32_t>>;
class LockVector;

/** Implementation of the Hierarchical Navigable Small World
 * datastructure.
 *
 * Efficient and robust approximate nearest neighbor search using
 * Hierarchical Navigable Small World graphs
 *
 *  Yu. A. Malkov, D. A. Yashunin, arXiv 2017
 *
 * This implementation is heavily influenced by the NMSlib
 * implementation by Yury Malkov and Leonid Boytsov
 * (https://github.com/searchivarius/nmslib)
 *
 * The HNSW object stores only the neighbor link structure, see
 * IndexHNSW.h for the full index object.
 */

struct VisitedTable;
struct DistanceComputer; // from AuxIndexStructures
struct HNSWStats;

struct SearchParametersHNSW : SearchParameters {
    int efSearch = 16;
    bool check_relative_distance = true;
    bool bounded_queue = true;

    ~SearchParametersHNSW() {}
};

struct HNSW {
    /// internal storage of vectors (32 bits: this is expensive)
    using storage_idx_t = int32_t;

    // The two comparator flavors HNSW supports. CMax (smaller-is-better)
    // is the default; CMin (larger-is-better) is used when `is_similarity`
    // is set on the owning index.
    using C_distance = CMax<float, int64_t>;
    using C_similarity = CMin<float, int64_t>;

    // Back-compat alias: keeps `HNSW::C` resolving to the distance
    // (CMax) comparator everywhere the type is referenced directly.
    using C = C_distance;

    typedef std::pair<float, storage_idx_t> Node;

    /// to sort pairs of (id, distance) from nearest to farthest or the reverse
    template <class CT>
    struct NodeDistCloserT {
        float d;
        int id;
        NodeDistCloserT(float d_in, int id_in) : d(d_in), id(id_in) {}
        bool operator<(const NodeDistCloserT& obj1) const {
            // priority_queue keeps the "worst" element at the top so that
            // when the queue is full we can pop it. For CMax (distance) the
            // worst element is the largest d; for CMin (similarity) it is
            // the smallest d. Equivalent to: obj1.d "better than" d.
            return CT::cmp(obj1.d, d);
        }
    };

    template <class CT>
    struct NodeDistFartherT {
        float d;
        int id;
        NodeDistFartherT(float d_in, int id_in) : d(d_in), id(id_in) {}
        bool operator<(const NodeDistFartherT& obj1) const {
            // priority_queue here keeps the "best" element at the top so we
            // can process the nearest candidate first. For CMax (distance)
            // the best is the smallest d; for CMin (similarity) the best is
            // the largest d. Equivalent to: d "better than" obj1.d.
            return CT::cmp(d, obj1.d);
        }
    };

    // Back-compat aliases: default to the distance (CMax) comparator so
    // existing call sites that mention `HNSW::NodeDist*` keep working.
    using NodeDistCloser = NodeDistCloserT<C_distance>;
    using NodeDistFarther = NodeDistFartherT<C_distance>;

    /// assignment probability to each layer (sum=1)
    std::vector<double> assign_probas;

    /// number of neighbors stored per layer (cumulative), should not
    /// be changed after first add
    std::vector<int> cum_nneighbor_per_level;

    /// level of each vector (base level = 1), size = ntotal
    std::vector<int> levels;

    /// offsets[i] is the offset in the neighbors array where vector i is stored
    /// size ntotal + 1
    std::vector<size_t> offsets;

    /// neighbors[offsets[i]:offsets[i+1]] is the list of neighbors of vector i
    /// for all levels. this is where all storage goes.
    MaybeOwnedVector<storage_idx_t> neighbors;

    /// entry point in the search structure (one of the points with maximum
    /// level
    storage_idx_t entry_point = -1;

    faiss::RandomGenerator rng;

    /// maximum level
    int max_level = -1;

    /// expansion factor at construction time
    int efConstruction = 40;

    /// expansion factor at search time
    int efSearch = 16;

    /// when pruning, leave room for more neighbors to avoid O(n^2)
    /// costs and lock contention on frequently-pruned nodes.
    float prune_headroom = 0.2f;

    /// during search: do we check whether the next best distance is good
    /// enough?
    bool check_relative_distance = true;

    /// use bounded queue during exploration
    bool search_bounded_queue = true;

    /// use Panorama progressive pruning in search
    bool is_panorama = false;

    /// distance comparison semantics: when true, distances are treated as
    /// similarity scores (larger is better). Default false matches the
    /// historical L2/Hamming behavior (smaller is better).
    /// Not serialized: must be re-set by the owning Index after loading.
    bool is_similarity = false;

    // See impl/VisitedTable.h.
    std::optional<bool> use_visited_hashset;

    // methods that initialize the tree sizes

    /// initialize the assign_probas and cum_nneighbor_per_level to
    /// have 2*M links on level 0 and M links on levels > 0
    void set_default_probas(int M, float levelMult);

    /// set nb of neighbors for this level (before adding anything)
    void set_nb_neighbors(int level_no, int n);

    // methods that access the tree sizes

    /// nb of neighbors for this level
    int nb_neighbors(int layer_no) const;

    /// cumulative nb up to (and excluding) this level
    int cum_nb_neighbors(int layer_no) const;

    /// range of entries in the neighbors table of vertex no at layer_no
    void neighbor_range(idx_t no, int layer_no, size_t* begin, size_t* end)
            const;

    /// only mandatory parameter: nb of neighbors
    explicit HNSW(int M = 32);

    /// pick a random level for a new point
    int random_level();

    /// add n random levels to table (for debugging...)
    void fill_with_random_links(size_t n);

    void add_links_starting_from(
            DistanceComputer& ptdis,
            storage_idx_t pt_id,
            storage_idx_t nearest,
            float d_nearest,
            int level,
            LockVector& locks,
            VisitedTable& vt,
            bool keep_max_size_level0 = false);

    /** add point pt_id on all levels <= pt_level and build the link
     * structure for them. */
    void add_with_locks(
            DistanceComputer& ptdis,
            int pt_level,
            int pt_id,
            LockVector& locks,
            VisitedTable& vt,
            bool keep_max_size_level0 = false);

    /** Deterministic build, phase A: write pt_id's forward links against an
     * immutable snapshot, touching only pt_id's own slots. Reciprocal edges
     * are collected in `pt_reverse_edges` for phase B, not applied. Requires
     * entry_point set. */
    void compute_forward_links_deterministic(
            DistanceComputer& ptdis,
            int pt_level,
            storage_idx_t pt_id,
            VisitedTable& vt,
            std::vector<std::pair<storage_idx_t, int>>& pt_reverse_edges,
            bool keep_max_size_level0 = false);

    /** Deterministic build, phase B: merge `incoming` into `node` and
     * re-prune in a total order (distance, ties by id) so the result is
     * order-independent. Touches only `node`'s slots; `incoming` is sorted
     * and deduplicated in place. */
    void merge_reverse_links_deterministic(
            DistanceComputer& dis,
            storage_idx_t node,
            int level,
            std::vector<storage_idx_t>& incoming,
            bool keep_max_size_level0 = false);

    /// Search interface for 1 point, single thread
    ///
    /// NOTE: We pass a reference to the index itself to allow for additional
    /// state information to be passed (used for Panorama progressive pruning).
    /// The alternative would be to override both HNSW::search and
    /// HNSWIndex::search, which would be a nuisance of code duplication.
    HNSWStats search(
            DistanceComputer& qdis,
            const IndexHNSW* index,
            ResultHandler& res,
            VisitedTable& vt,
            const SearchParameters* params = nullptr) const;

    /// search only in level 0 from a given vertex
    void search_level_0(
            DistanceComputer& qdis,
            ResultHandler& res,
            idx_t nprobe,
            const storage_idx_t* nearest_i,
            const float* nearest_d,
            int search_type,
            HNSWStats& search_stats,
            VisitedTable& vt,
            const SearchParameters* params = nullptr) const;

    void reset();

    void clear_neighbor_tables(int level);
    void print_neighbor_stats(int level) const;

    int prepare_level_tab(size_t n, bool preset_levels = false);

    template <class C = C_distance>
    static void shrink_neighbor_list(
            DistanceComputer& qdis,
            std::priority_queue<NodeDistFartherT<C>>& input,
            std::vector<NodeDistFartherT<C>>& output,
            size_t max_size,
            bool keep_max_size_level0 = false);

    void permute_entries(const idx_t* map);
};

/** Deterministic, lock-free HNSW graph build, shared by IndexHNSW and
 * IndexBinaryHNSW. The callbacks let both share the algorithm:
 * `make_distance_computer()` returns a fresh DistanceComputer per thread
 * (caller-owned) and `set_query(dc, pt_id)` points it at pt_id's vector. */
void hnsw_add_vertices_deterministic(
        HNSW& hnsw,
        size_t n0,
        size_t n,
        int d,
        bool init_level0,
        bool keep_max_size_level0,
        bool preset_levels,
        bool verbose,
        const std::function<DistanceComputer*()>& make_distance_computer,
        const std::function<void(DistanceComputer&, HNSW::storage_idx_t)>&
                set_query);

struct HNSWStats {
    size_t n1 = 0; /// number of vectors searched
    size_t n2 =
            0; /// number of queries for which the candidate list is exhausted
    size_t ndis = 0;  /// number of distances computed
    size_t nhops = 0; /// number of hops aka number of edges traversed

    void reset() {
        n1 = n2 = 0;
        ndis = 0;
        nhops = 0;
    }

    void combine(const HNSWStats& other) {
        n1 += other.n1;
        n2 += other.n2;
        ndis += other.ndis;
        nhops += other.nhops;
    }
};

// global var that collects them all
FAISS_API extern HNSWStats hnsw_stats;

/** Use the lock-free deterministic graph build in add() rather than the
 * lock-based one. Transitional: it will become the only path.
 *
 * NOT thread-safe: set before calling add(). Sampled once per add(). */
FAISS_API extern bool hnsw_deterministic_build;

/// Internal HNSW algorithm helpers. These are not part of the public API; they
/// are exposed here only so that unit tests (and a few cross-TU callers such as
/// the Panorama search variant) can reach them.
namespace hnsw_detail {

int search_from_candidates(
        const HNSW& hnsw,
        DistanceComputer& qdis,
        ResultHandler& res,
        MinimaxHeap& candidates,
        VisitedTable& vt,
        HNSWStats& stats,
        int level,
        int nres_in = 0,
        const SearchParameters* params = nullptr);

/// Equivalent to `search_from_candidates`, but applies pruning with progressive
/// refinement bounds.
/// This is used in `IndexHNSWFlatPanorama` to improve the search performance
/// for higher dimensional vectors.
int search_from_candidates_panorama(
        const HNSW& hnsw,
        const IndexHNSW* index,
        DistanceComputer& qdis,
        ResultHandler& res,
        MinimaxHeap& candidates,
        VisitedTable& vt,
        HNSWStats& stats,
        int level,
        int nres_in = 0,
        const SearchParameters* params = nullptr);

HNSWStats greedy_update_nearest(
        const HNSW& hnsw,
        DistanceComputer& qdis,
        int level,
        HNSW::storage_idx_t& nearest,
        float& d_nearest);

std::priority_queue<HNSW::Node> search_from_candidate_unbounded(
        const HNSW& hnsw,
        const HNSW::Node& node,
        DistanceComputer& qdis,
        int ef,
        VisitedTable* vt,
        HNSWStats& stats);

void search_neighbors_to_add(
        HNSW& hnsw,
        DistanceComputer& qdis,
        std::priority_queue<HNSW::NodeDistCloser>& results,
        int entry_point,
        float d_entry_point,
        int level,
        VisitedTable& vt,
        bool reference_version = false);

} // namespace hnsw_detail

} // namespace faiss
