# @trigger.dev/python

## 4.5.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.14`
  - `@trigger.dev/sdk@4.5.14`
  - `@trigger.dev/build@4.5.14`

## 4.5.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.13`
  - `@trigger.dev/core@4.5.13`
  - `@trigger.dev/build@4.5.13`

## 4.5.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.12`
  - `@trigger.dev/sdk@4.5.12`
  - `@trigger.dev/build@4.5.12`

## 4.5.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.11`
  - `@trigger.dev/sdk@4.5.11`
  - `@trigger.dev/build@4.5.11`

## 4.5.10

### Patch Changes

- Refresh package builds for TypeScript 7 compatibility while preserving existing runtime entry points. Projects using `emitDecoratorMetadata()` with TypeScript 7 can install the `@typescript/typescript6` compatibility package alongside it; the package remains optional, so installing the Trigger.dev CLI does not install an additional compiler. ([#4318](https://github.com/triggerdotdev/trigger.dev/pull/4318))
- Updated dependencies:
  - `@trigger.dev/sdk@4.5.10`
  - `@trigger.dev/core@4.5.10`
  - `@trigger.dev/build@4.5.10`

## 4.5.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.9`
  - `@trigger.dev/core@4.5.9`
  - `@trigger.dev/build@4.5.9`

## 4.5.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.8`
  - `@trigger.dev/core@4.5.8`
  - `@trigger.dev/build@4.5.8`

## 4.5.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.7`
  - `@trigger.dev/core@4.5.7`
  - `@trigger.dev/build@4.5.7`

## 4.5.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.6`
  - `@trigger.dev/build@4.5.6`
  - `@trigger.dev/sdk@4.5.6`

## 4.5.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.5`
  - `@trigger.dev/build@4.5.5`
  - `@trigger.dev/sdk@4.5.5`

## 4.5.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.4`
  - `@trigger.dev/core@4.5.4`
  - `@trigger.dev/build@4.5.4`

## 4.5.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.3`
  - `@trigger.dev/build@4.5.3`
  - `@trigger.dev/core@4.5.3`

## 4.5.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.2`
  - `@trigger.dev/sdk@4.5.2`
  - `@trigger.dev/build@4.5.2`

## 4.5.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.5.1`
  - `@trigger.dev/core@4.5.1`
  - `@trigger.dev/sdk@4.5.1`

## 4.5.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0`
  - `@trigger.dev/core@4.5.0`
  - `@trigger.dev/build@4.5.0`

## 4.5.0-rc.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.7`
  - `@trigger.dev/core@4.5.0-rc.7`
  - `@trigger.dev/build@4.5.0-rc.7`

## 4.5.0-rc.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.6`
  - `@trigger.dev/core@4.5.0-rc.6`
  - `@trigger.dev/build@4.5.0-rc.6`

## 4.5.0-rc.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.5`
  - `@trigger.dev/core@4.5.0-rc.5`
  - `@trigger.dev/build@4.5.0-rc.5`

## 4.5.0-rc.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.4`
  - `@trigger.dev/core@4.5.0-rc.4`
  - `@trigger.dev/build@4.5.0-rc.4`

## 4.5.0-rc.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.3`
  - `@trigger.dev/build@4.5.0-rc.3`
  - `@trigger.dev/sdk@4.5.0-rc.3`

## 4.5.0-rc.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.2`
  - `@trigger.dev/build@4.5.0-rc.2`
  - `@trigger.dev/core@4.5.0-rc.2`

## 4.5.0-rc.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.1`
  - `@trigger.dev/build@4.5.0-rc.1`
  - `@trigger.dev/sdk@4.5.0-rc.1`

## 4.5.0-rc.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.5.0-rc.0`
  - `@trigger.dev/core@4.5.0-rc.0`
  - `@trigger.dev/build@4.5.0-rc.0`

## 4.4.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.6`
  - `@trigger.dev/build@4.4.6`
  - `@trigger.dev/sdk@4.4.6`

## 4.4.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.5`
  - `@trigger.dev/build@4.4.5`
  - `@trigger.dev/sdk@4.4.5`

## 4.4.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.4.4`
  - `@trigger.dev/core@4.4.4`
  - `@trigger.dev/build@4.4.4`

## 4.4.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.3`
  - `@trigger.dev/build@4.4.3`
  - `@trigger.dev/sdk@4.4.3`

## 4.4.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.4.2`
  - `@trigger.dev/build@4.4.2`
  - `@trigger.dev/core@4.4.2`

## 4.4.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.4.1`
  - `@trigger.dev/build@4.4.1`
  - `@trigger.dev/core@4.4.1`

## 4.4.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.0`
  - `@trigger.dev/sdk@4.4.0`
  - `@trigger.dev/build@4.4.0`

## 4.3.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.3.3`
  - `@trigger.dev/core@4.3.3`
  - `@trigger.dev/build@4.3.3`

## 4.3.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.3.2`
  - `@trigger.dev/build@4.3.2`
  - `@trigger.dev/core@4.3.2`

## 4.3.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.3.1`
  - `@trigger.dev/core@4.3.1`
  - `@trigger.dev/build@4.3.1`

## 4.3.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.0`
  - `@trigger.dev/build@4.3.0`
  - `@trigger.dev/sdk@4.3.0`

## 4.2.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.2.0`
  - `@trigger.dev/sdk@4.2.0`
  - `@trigger.dev/core@4.2.0`

## 4.1.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.1.2`
  - `@trigger.dev/core@4.1.2`
  - `@trigger.dev/sdk@4.1.2`

## 4.1.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.1.1`
  - `@trigger.dev/core@4.1.1`
  - `@trigger.dev/sdk@4.1.1`

## 4.1.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.1.0`
  - `@trigger.dev/build@4.1.0`
  - `@trigger.dev/core@4.1.0`

## 4.0.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.7`
  - `@trigger.dev/core@4.0.7`
  - `@trigger.dev/sdk@4.0.7`

## 4.0.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.6`
  - `@trigger.dev/build@4.0.6`
  - `@trigger.dev/sdk@4.0.6`

## 4.0.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.5`
  - `@trigger.dev/build@4.0.5`
  - `@trigger.dev/sdk@4.0.5`

## 4.0.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.4`
  - `@trigger.dev/core@4.0.4`
  - `@trigger.dev/sdk@4.0.4`

## 4.0.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.3`
  - `@trigger.dev/sdk@4.0.3`
  - `@trigger.dev/build@4.0.3`

## 4.0.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.2`
  - `@trigger.dev/core@4.0.2`
  - `@trigger.dev/sdk@4.0.2`

## 4.0.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.1`
  - `@trigger.dev/core@4.0.1`
  - `@trigger.dev/sdk@4.0.1`

## 4.0.0

### Major Changes

- Trigger.dev v4 release. Please see our upgrade to v4 docs to view the full changelog: https://trigger.dev/docs/upgrade-to-v4 ([#1869](https://github.com/triggerdotdev/trigger.dev/pull/1869))

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0`
  - `@trigger.dev/core@4.0.0`
  - `@trigger.dev/build@4.0.0`

## 4.0.0-v4-beta.28

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.28`
  - `@trigger.dev/core@4.0.0-v4-beta.28`
  - `@trigger.dev/build@4.0.0-v4-beta.28`

## 4.0.0-v4-beta.27

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.27`
  - `@trigger.dev/build@4.0.0-v4-beta.27`
  - `@trigger.dev/core@4.0.0-v4-beta.27`

## 4.0.0-v4-beta.26

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.26`
  - `@trigger.dev/build@4.0.0-v4-beta.26`
  - `@trigger.dev/core@4.0.0-v4-beta.26`

## 4.0.0-v4-beta.25

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.25`
  - `@trigger.dev/core@4.0.0-v4-beta.25`
  - `@trigger.dev/sdk@4.0.0-v4-beta.25`

## 4.0.0-v4-beta.24

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.24`
  - `@trigger.dev/build@4.0.0-v4-beta.24`
  - `@trigger.dev/core@4.0.0-v4-beta.24`

## 4.0.0-v4-beta.23

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.23`
  - `@trigger.dev/core@4.0.0-v4-beta.23`
  - `@trigger.dev/build@4.0.0-v4-beta.23`

## 4.0.0-v4-beta.22

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.22`
  - `@trigger.dev/sdk@4.0.0-v4-beta.22`
  - `@trigger.dev/build@4.0.0-v4-beta.22`

## 4.0.0-v4-beta.21

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.21`
  - `@trigger.dev/build@4.0.0-v4-beta.21`
  - `@trigger.dev/sdk@4.0.0-v4-beta.21`

## 4.0.0-v4-beta.20

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.20`
  - `@trigger.dev/core@4.0.0-v4-beta.20`
  - `@trigger.dev/sdk@4.0.0-v4-beta.20`

## 4.0.0-v4-beta.19

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.19`
  - `@trigger.dev/sdk@4.0.0-v4-beta.19`
  - `@trigger.dev/build@4.0.0-v4-beta.19`

## 4.0.0-v4-beta.18

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.18`
  - `@trigger.dev/core@4.0.0-v4-beta.18`
  - `@trigger.dev/sdk@4.0.0-v4-beta.18`

## 4.0.0-v4-beta.17

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.17`
  - `@trigger.dev/build@4.0.0-v4-beta.17`
  - `@trigger.dev/sdk@4.0.0-v4-beta.17`

## 4.0.0-v4-beta.16

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.16`
  - `@trigger.dev/core@4.0.0-v4-beta.16`
  - `@trigger.dev/sdk@4.0.0-v4-beta.16`

## 4.0.0-v4-beta.15

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.15`
  - `@trigger.dev/core@4.0.0-v4-beta.15`
  - `@trigger.dev/sdk@4.0.0-v4-beta.15`

## 4.0.0-v4-beta.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.14`
  - `@trigger.dev/build@4.0.0-v4-beta.14`
  - `@trigger.dev/core@4.0.0-v4-beta.14`

## 4.0.0-v4-beta.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.13`
  - `@trigger.dev/build@4.0.0-v4-beta.13`
  - `@trigger.dev/sdk@4.0.0-v4-beta.13`

## 4.0.0-v4-beta.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.12`
  - `@trigger.dev/build@4.0.0-v4-beta.12`
  - `@trigger.dev/core@4.0.0-v4-beta.12`

## 4.0.0-v4-beta.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.11`
  - `@trigger.dev/build@4.0.0-v4-beta.11`
  - `@trigger.dev/core@4.0.0-v4-beta.11`

## 4.0.0-v4-beta.10

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.10`
  - `@trigger.dev/build@4.0.0-v4-beta.10`
  - `@trigger.dev/sdk@4.0.0-v4-beta.10`

## 4.0.0-v4-beta.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.9`
  - `@trigger.dev/core@4.0.0-v4-beta.9`
  - `@trigger.dev/sdk@4.0.0-v4-beta.9`

## 4.0.0-v4-beta.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.8`
  - `@trigger.dev/build@4.0.0-v4-beta.8`
  - `@trigger.dev/sdk@4.0.0-v4-beta.8`

## 4.0.0-v4-beta.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.7`
  - `@trigger.dev/build@4.0.0-v4-beta.7`
  - `@trigger.dev/sdk@4.0.0-v4-beta.7`

## 4.0.0-v4-beta.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.6`
  - `@trigger.dev/sdk@4.0.0-v4-beta.6`
  - `@trigger.dev/build@4.0.0-v4-beta.6`

## 4.0.0-v4-beta.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.5`
  - `@trigger.dev/build@4.0.0-v4-beta.5`
  - `@trigger.dev/core@4.0.0-v4-beta.5`

## 4.0.0-v4-beta.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.4`
  - `@trigger.dev/build@4.0.0-v4-beta.4`
  - `@trigger.dev/core@4.0.0-v4-beta.4`

## 4.0.0-v4-beta.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.3`
  - `@trigger.dev/build@4.0.0-v4-beta.3`
  - `@trigger.dev/sdk@4.0.0-v4-beta.3`

## 4.0.0-v4-beta.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.2`
  - `@trigger.dev/build@4.0.0-v4-beta.2`
  - `@trigger.dev/sdk@4.0.0-v4-beta.2`

## 4.0.0-v4-beta.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/build@4.0.0-v4-beta.1`
  - `@trigger.dev/core@4.0.0-v4-beta.1`
  - `@trigger.dev/sdk@4.0.0-v4-beta.1`

## 4.0.0-v4-beta.0

### Major Changes

- Trigger.dev v4 release. Please see our upgrade to v4 docs to view the full changelog: https://trigger.dev/docs/upgrade-to-v4 ([#1869](https://github.com/triggerdotdev/trigger.dev/pull/1869))

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/sdk@4.0.0-v4-beta.0`
  - `@trigger.dev/build@4.0.0-v4-beta.0`
  - `@trigger.dev/core@4.0.0-v4-beta.0`

## 3.3.17

### Patch Changes

- Introduced a new Python extension to enhance the build process. It now allows users to execute Python scripts with improved support and error handling. ([#1686](https://github.com/triggerdotdev/trigger.dev/pull/1686))
- Updated dependencies:
  - `@trigger.dev/sdk@3.3.17`
  - `@trigger.dev/core@3.3.17`
  - `@trigger.dev/build@3.3.17`
