import type { RetrieveRunResponse } from "../schemas/api.js";
import type { InferRunTypes } from "./tasks.js";
import type { Prettify } from "./utils.js";

export * from "./idempotencyKeys.js";
export * from "./jsonSchema.js";
export * from "./queues.js";
export * from "./tasks.js";
export * from "./tools.js";
export * from "./utils.js";
export * from "./webhooks.js";
export * from "./chatEvents.js";

type ResolveEnvironmentVariablesOptions = {
  variables: Record<string, string> | Array<{ name: string; value: string }>;
  override?: boolean;
};

export type ResolveEnvironmentVariablesResult =
  | ResolveEnvironmentVariablesOptions
  | Promise<void | undefined | ResolveEnvironmentVariablesOptions>
  | void
  | undefined;

export type ResolveEnvironmentVariablesParams = {
  projectRef: string;
  environment: string;
  env: Record<string, string>;
};

export type ResolveEnvironmentVariablesFunction = (
  params: ResolveEnvironmentVariablesParams
) => ResolveEnvironmentVariablesResult;

export type RetrieveRunResult<T> = Prettify<
  Omit<RetrieveRunResponse, "output" | "payload"> & {
    output?: InferRunTypes<T>["output"];
    payload?: InferRunTypes<T>["payload"];
  }
>;

export type AnyRetrieveRunResult = RetrieveRunResult<any>;
