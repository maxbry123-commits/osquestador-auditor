let x = bad();
