#
# Copyright (c) 2020-2025 Semgrep Inc.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# version 2.1 as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file
# LICENSE for more details.
#
import pytest
from tests.fixtures import RunSemgrep


@pytest.mark.kinda_slow
def test_severity_error(run_semgrep_in_tmp: RunSemgrep, posix_snapshot):
    json_str = run_semgrep_in_tmp(
        "rules/inside.yaml", options=["--severity", "ERROR"]
    ).stdout
    assert json_str != ""
    assert '"severity": "INFO"' not in json_str
    assert '"severity": "WARNING"' not in json_str
    posix_snapshot.assert_match(json_str, "results.json")


@pytest.mark.kinda_slow
def test_severity_info(run_semgrep_in_tmp: RunSemgrep, posix_snapshot):
    # Shouldn't return errors or results, since inside.yaml has 'severity: ERROR'
    posix_snapshot.assert_match(
        run_semgrep_in_tmp("rules/inside.yaml", options=["--severity", "INFO"]).stdout,
        "results.json",
    )


@pytest.mark.kinda_slow
def test_severity_warning(run_semgrep_in_tmp: RunSemgrep, posix_snapshot):
    # Shouldn't return errors or results, since inside.yaml has 'severity: ERROR'
    posix_snapshot.assert_match(
        run_semgrep_in_tmp(
            "rules/inside.yaml", options=["--severity", "WARNING"]
        ).stdout,
        "results.json",
    )


@pytest.mark.kinda_slow
def test_severity_multiple(run_semgrep_in_tmp: RunSemgrep, posix_snapshot):
    # Shouldn't return errors or results, since inside.yaml has 'severity: ERROR'
    # Differs from the two preceding tests in that we're testing adding multiple severity strings
    posix_snapshot.assert_match(
        run_semgrep_in_tmp(
            "rules/inside.yaml", options=["--severity", "INFO", "--severity", "WARNING"]
        ).stdout,
        "results.json",
    )
