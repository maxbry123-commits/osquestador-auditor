bad_hcl()
