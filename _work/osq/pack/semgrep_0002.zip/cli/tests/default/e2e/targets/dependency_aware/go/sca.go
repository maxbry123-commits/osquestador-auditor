func f() {
	return bad()
}