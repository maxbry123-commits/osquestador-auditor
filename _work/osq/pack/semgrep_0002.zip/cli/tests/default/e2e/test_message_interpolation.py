#
# Copyright (c) 2022-2025 Semgrep Inc.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# version 2.1 as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file
# LICENSE for more details.
#
import pytest
from tests.fixtures import RunSemgrep

from semgrep.constants import OutputFormat


@pytest.mark.kinda_slow
@pytest.mark.parametrize(
    "rule,target",
    [
        (
            "rules/message_interpolation/pattern-inside.yaml",
            "message_interpolation/pattern_inside_basic.py",
        ),
        (
            "rules/message_interpolation/pattern-inside.yaml",
            "message_interpolation/pattern_inside_complex.py",
        ),
        (
            "rules/message_interpolation/propagated-constant.yaml",
            "message_interpolation/propagated_constant.py",
        ),
        # pattern-not-inside is not currently interpolated. These tests make sure
        # something doesn't break accidentally.
        (
            "rules/message_interpolation/pattern-not-inside.yaml",
            "message_interpolation/pattern_not_inside_basic.py",
        ),
        (
            "rules/message_interpolation/pattern-not-inside.yaml",
            "message_interpolation/pattern_not_inside_complex.py",
        ),
        (
            "rules/message_interpolation/pattern-either.yaml",
            "message_interpolation/pattern_either_basic.py",
        ),
        (
            "rules/message_interpolation/multi-pattern-inside.yaml",
            "message_interpolation/multi_pattern_inside.py",
        ),
        (
            "rules/message_interpolation/multi-pattern-inside.yaml",
            "message_interpolation/multi_pattern_inside_nested.py",
        ),
    ],
)
def test_message_interpolation(
    run_semgrep_in_tmp: RunSemgrep, posix_snapshot, rule, target
):
    posix_snapshot.assert_match(
        run_semgrep_in_tmp(rule, target_name=target).stdout, "results.json"
    )


@pytest.mark.slow
def test_no_double_interpolation(run_semgrep_in_tmp: RunSemgrep, posix_snapshot):
    stdout, _ = run_semgrep_in_tmp(
        "rules/message_interpolation/interpolated_message.yaml",
        target_name="message_interpolation/target_with_metavariable.py",
        output_format=OutputFormat.JSON,  # Not the real output format; just disables JSON parsing
    )
    posix_snapshot.assert_match(stdout, "report.json")
