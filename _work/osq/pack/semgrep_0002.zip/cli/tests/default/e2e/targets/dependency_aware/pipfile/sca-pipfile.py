bad()
