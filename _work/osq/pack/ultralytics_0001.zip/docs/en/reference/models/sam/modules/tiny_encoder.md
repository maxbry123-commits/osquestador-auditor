---
title: models.sam.modules.tiny_encoder API Reference
description: Explore the detailed implementation of TinyViT architecture including Conv2d_BN, PatchEmbed, MBConv, and more in Ultralytics.
keywords: Ultralytics, TinyViT, Conv2d_BN, PatchEmbed, MBConv, Attention, PyTorch, YOLO, Deep Learning
---

# Reference for `ultralytics/models/sam/modules/tiny_encoder.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/models/sam/modules/tiny_encoder.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/models/sam/modules/tiny_encoder.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing) — thank you! 🙏

<br>

## ::: ultralytics.models.sam.modules.tiny_encoder.Conv2d_BN

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.PatchEmbed

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.MBConv

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.PatchMerging

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.ConvLayer

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.MLP

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.Attention

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.TinyViTBlock

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.BasicLayer

<br><br><hr><br>

## ::: ultralytics.models.sam.modules.tiny_encoder.TinyViT

<br><br>
