---
title: utils.events API Reference
description: Reference for utilities supporting telemetry, analytics, and event handling with lightweight background requests.
keywords: Ultralytics, YOLO, utils, telemetry, analytics, events, anonymization, background, JSON, POST, Python
---

# Reference for `ultralytics/utils/events.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/events.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/events.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing) — thank you! 🙏

<br>

## ::: ultralytics.utils.events.Events

<br><br><hr><br>

## ::: ultralytics.utils.events._post

<br><br><hr><br>

## ::: ultralytics.utils.events._arch

<br><br><hr><br>

## ::: ultralytics.utils.events.on_train_end

<br><br><hr><br>

## ::: ultralytics.utils.events.on_val_start

<br><br><hr><br>

## ::: ultralytics.utils.events.on_predict_end

<br><br><hr><br>

## ::: ultralytics.utils.events.on_export_start

<br><br>
