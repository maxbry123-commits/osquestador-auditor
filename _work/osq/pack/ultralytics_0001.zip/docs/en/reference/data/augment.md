---
title: data.augment API Reference
description: Explore Ultralytics image augmentation techniques like MixUp, Mosaic, and Random Perspective for enhancing model training. Improve your deep learning models now.
keywords: Ultralytics, image augmentation, MixUp, Mosaic, Random Perspective, deep learning, model training, YOLO
---

# Reference for `ultralytics/data/augment.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/data/augment.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/data/augment.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing) — thank you! 🙏

<br>

## ::: ultralytics.data.augment.BaseTransform

<br><br><hr><br>

## ::: ultralytics.data.augment.Compose

<br><br><hr><br>

## ::: ultralytics.data.augment.BaseMixTransform

<br><br><hr><br>

## ::: ultralytics.data.augment.Mosaic

<br><br><hr><br>

## ::: ultralytics.data.augment.MixUp

<br><br><hr><br>

## ::: ultralytics.data.augment.CutMix

<br><br><hr><br>

## ::: ultralytics.data.augment.RandomPerspective

<br><br><hr><br>

## ::: ultralytics.data.augment.RandomHSV

<br><br><hr><br>

## ::: ultralytics.data.augment.RandomFlip

<br><br><hr><br>

## ::: ultralytics.data.augment.LetterBox

<br><br><hr><br>

## ::: ultralytics.data.augment.CopyPaste

<br><br><hr><br>

## ::: ultralytics.data.augment.Albumentations

<br><br><hr><br>

## ::: ultralytics.data.augment.Format

<br><br><hr><br>

## ::: ultralytics.data.augment.SemanticFormat

<br><br><hr><br>

## ::: ultralytics.data.augment.LoadVisualPrompt

<br><br><hr><br>

## ::: ultralytics.data.augment.RandomLoadText

<br><br><hr><br>

## ::: ultralytics.data.augment.DepthFormat

<br><br><hr><br>

## ::: ultralytics.data.augment.ClassifyLetterBox

<br><br><hr><br>

## ::: ultralytics.data.augment.CenterCrop

<br><br><hr><br>

## ::: ultralytics.data.augment.ToTensor

<br><br><hr><br>

## ::: ultralytics.data.augment.v8_transforms

<br><br><hr><br>

## ::: ultralytics.data.augment.classify_transforms

<br><br><hr><br>

## ::: ultralytics.data.augment.classify_augmentations

<br><br>
