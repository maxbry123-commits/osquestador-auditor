---
plans: [free, pro, enterprise]
comments: true
description: Connect Slack to Ultralytics Platform and choose which training, export, and deployment results are posted to your channel.
keywords: Ultralytics Platform, Slack, alerts, notifications, training, model export, deployment, YOLO, computer vision
title: Slack Alerts - Ultralytics Platform
---

# Slack Integration

Connect [Slack](https://slack.com) to [Ultralytics Platform](https://platform.ultralytics.com) to learn when long-running work finishes without keeping Platform open. You choose one Slack channel and the results that matter to your workspace.

You do not need a Slack API key, webhook, or technical setup. Before you start, sign in to Slack and decide which channel should receive Platform alerts. If you use a team workspace in Platform, you must be a workspace admin or owner.

## Connect Slack

1. Open [**Settings > Integrations**](https://platform.ultralytics.com/settings?tab=integrations) and select **Slack**
   from the integration list.
2. Review the setup summary and click **Continue to Slack**.
3. Choose a channel and click **Allow**. Platform requests permission to post only to that channel. If Slack shows
   **Request approval**, send the request and ask your Slack workspace admin to approve the app.
4. After returning to Platform, choose the alerts you want and click **Save alerts**. **Training complete** and
   **Training failed** are selected initially.

![Ultralytics Platform Slack Integration Setup](https://cdn.ul.run/i/9a47efa8a0df9db1d13e941e7572ca49.avif)<!-- screenshot -->

Platform posts a confirmation in the selected channel as soon as the connection succeeds, and the integration then shows which Slack workspace and channel it is connected to. Workspace admins manage the connection and alert choices for the whole workspace from the [Integrations tab](../account/settings.md#integrations-tab).

!!! info "What Slack Allows"

    Slack lets Platform post messages to the channel you choose. Platform cannot read your Slack messages or post to other channels through this connection.

## Available Alerts

| Alert                 | When it is sent                                                                |
| --------------------- | ------------------------------------------------------------------------------ |
| **Training complete** | A model [finishes training](../train/cloud-training.md#training-job-lifecycle) |
| **Training failed**   | A training run stops with an error                                             |
| **Export complete**   | A [model export](../train/models.md#export-model) is ready                     |
| **Export failed**     | A model export stops with an error                                             |
| **Deployment ready**  | A [deployment](../deploy/endpoints.md#deployment-lifecycle) is ready           |
| **Deployment failed** | A deployment fails to start                                                    |

Each message says what finished and links straight to the related model or deployment in Platform. Training alerts add the dataset name, the model's primary metric, how long the run took, and what it cost; export alerts add the format and file size. Failed-job alerts include a short error summary when one is available, as an inline note or a code block for longer messages. Slack delivery does not change the result of the training, export, or deployment. Review the current result from the model's [training](../train/cloud-training.md#monitor-training) or [export](../train/models.md#export-model) page, or from the [Deployments page](../deploy/index.md#deployments-page).

## Change or Disconnect Slack

To change which results are posted, check or uncheck alerts and click **Save alerts**. At least one alert must remain selected.

To use a different channel, click **Disconnect**, then connect Slack again and choose the new channel. Disconnecting stops all Slack alerts immediately and does not affect Platform jobs or resources.

## Troubleshooting

- **The Slack integration says an admin must connect it:** ask a Platform workspace admin or owner to complete the
  connection.
- **Slack shows Request approval instead of Allow:** send the request and ask your Slack workspace admin to approve the app. You do not need to create an API key or webhook.
- **Your Slack workspace or channel is missing:** confirm that you are signed in to the correct Slack workspace and that you can add apps to the channel.
- **The connection worked, but alerts stopped:** reconnect Slack to refresh the channel permission. This is usually needed if the app permission was revoked or the channel was removed.
- **A job finished without a Slack message:** check the selected alerts in **Settings > Integrations**, then open the related [model](../train/models.md) or [deployment](../deploy/index.md) in Platform. Slack alerts are informational and never control job processing.

Return to the [Platform integrations overview](index.md) to connect data, storage, or On Premise services.
