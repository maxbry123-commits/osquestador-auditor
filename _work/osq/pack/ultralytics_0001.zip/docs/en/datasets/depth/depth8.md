---
comments: true
license:
    name: None
description: Explore the Ultralytics Depth8 dataset, a compact set of 8 indoor RGB-D images for testing monocular depth estimation models and training pipelines.
keywords: Depth8, Ultralytics, dataset, depth estimation, monocular depth, YOLO26, training, validation, debugging, SUN RGB-D
---

# Depth8 Dataset

## Introduction

The [Ultralytics](https://www.ultralytics.com) Depth8 dataset is a compact [monocular depth estimation](index.md) dataset with 8 images sampled from the [SUN RGB-D](sunrgbd.md) dataset: 4 for training and 4 for validation, drawn from its Kinect v1 and Kinect v2 captures (two per sensor in each split) for dense, artifact-free ground-truth depth maps. It is designed for rapid testing, debugging, and experimentation with [YOLO26](../../models/yolo26.md) depth estimation models and training pipelines — the 1.3 MB archive auto-downloads on first use, so `yolo depth train data=depth8.yaml` starts training within seconds.

Explore [Depth8 on Ultralytics Platform](https://platform.ultralytics.com/ultralytics/datasets/depth8) to preview its RGB-depth pairs and clone it for training.

!!! note

    Depth8 is for pipeline testing only, not benchmarking — its 8 images are far too few for meaningful depth metrics. Use the full [NYU Depth V2](nyu-depth-v2.md) or [SUN RGB-D](sunrgbd.md) validation sets for representative results.

## Dataset Structure

Depth8 follows the standard [Ultralytics depth dataset layout](index.md#supported-dataset-format): RGB images with paired uint16 millimeter depth PNGs (`depth_scale: 1000`), matched by file stem.

```text
depth8-png/
├── images/
│   ├── train/  # 4 images
│   └── val/    # 4 images
└── depth/
    ├── train/  # 4 16-bit PNG depth maps
    └── val/    # 4 16-bit PNG depth maps
```

Depth values are real indoor sensor captures ranging from roughly 0.5 m to 4 m, well within the ≤10 m range of the full SUN RGB-D dataset.

## Dataset YAML

The Depth8 dataset configuration is defined in a dataset YAML file, which specifies dataset paths, class names, and the download URL for the small packaged subset.

!!! example "ultralytics/cfg/datasets/depth8.yaml"

    ```yaml
    --8<-- "ultralytics/cfg/datasets/depth8.yaml"
    ```

## Usage

To train a YOLO26n-depth model on the Depth8 dataset with an image size of 640, use the following examples. For a full list of training options, see the [YOLO Training documentation](../../modes/train.md).

!!! example "Train Example"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a pretrained YOLO26n-depth model
        model = YOLO("yolo26n-depth.pt")

        # Train the model on Depth8
        results = model.train(data="depth8.yaml", epochs=100, imgsz=640)
        ```

    === "CLI"

        ```bash
        # Train YOLO26n-depth on Depth8 using the command line
        yolo depth train data=depth8.yaml model=yolo26n-depth.pt epochs=100 imgsz=640
        ```

## Citations and Acknowledgments

Depth8 is sampled from SUN RGB-D — see the full [SUN RGB-D dataset page](sunrgbd.md#citations-and-acknowledgments) for source attribution and citation details. The source dataset does not specify a license.

If you use the SUN RGB-D dataset in your research or development work, please cite the following paper:

!!! quote ""

    === "BibTeX"

        ```bibtex
        @inproceedings{song2015sunrgbd,
              title={SUN RGB-D: A RGB-D Scene Understanding Benchmark Suite},
              author={Song, Shuran and Lichtenberg, Samuel P. and Xiao, Jianxiong},
              booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)},
              year={2015}
        }
        ```

## FAQ

### What is the Ultralytics Depth8 dataset used for?

The Ultralytics Depth8 dataset is designed for rapid testing and debugging of [monocular depth estimation](../../tasks/depth.md) pipelines. With only 8 images (4 train, 4 val) in a 1.3 MB auto-downloading archive, it verifies the full train / val / predict cycle — paired depth-map loading, augmentation, loss computation, and metrics — in seconds, before scaling to a full dataset such as [SUN RGB-D](sunrgbd.md) or [NYU Depth V2](nyu-depth-v2.md).

### How does Depth8 differ from the full SUN RGB-D dataset?

Depth8 samples 8 images from SUN RGB-D's 9,245-train/1,090-val split, favoring Kinect v1/v2 captures with clean, dense depth maps. It uses the identical 16-bit PNG depth format, so a pipeline that runs on Depth8 runs unmodified on the full dataset. Unlike the full dataset, Depth8 downloads in seconds and needs no conversion step.

### Should I use Depth8 for benchmarking?

No. Depth8 is too small for meaningful model comparison and is intended for training and evaluation pipeline checks. Use the full [NYU Depth V2](nyu-depth-v2.md) or [SUN RGB-D](sunrgbd.md) validation sets when you need representative depth estimation metrics.
