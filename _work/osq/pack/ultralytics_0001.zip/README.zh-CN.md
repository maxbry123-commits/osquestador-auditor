<div align="center">
  <p>
    <a href="https://www.ultralytics.com/events/yolovision?utm_source=github&utm_medium=social&utm_campaign=yolovision26&utm_content=banner" target="_blank">
      <img width="100%" src="https://raw.githubusercontent.com/ultralytics/assets/main/yolov8/banner-yolov8.png" alt="Ultralytics YOLO banner"></a>
  </p>

[中文](https://docs.ultralytics.com/zh) | [한국어](https://docs.ultralytics.com/ko) | [日本語](https://docs.ultralytics.com/ja) | [Русский](https://docs.ultralytics.com/ru) | [Deutsch](https://docs.ultralytics.com/de) | [Français](https://docs.ultralytics.com/fr) | [Español](https://docs.ultralytics.com/es) | [Português](https://docs.ultralytics.com/pt) | [Türkçe](https://docs.ultralytics.com/tr) | [Tiếng Việt](https://docs.ultralytics.com/vi) | [العربية](https://docs.ultralytics.com/ar) <br>

<div>
    <a href="https://github.com/ultralytics/ultralytics/actions/workflows/ci.yml"><img src="https://github.com/ultralytics/ultralytics/actions/workflows/ci.yml/badge.svg" alt="Ultralytics CI"></a>
    <a href="https://clickpy.clickhouse.com/dashboard/ultralytics"><img src="https://static.pepy.tech/badge/ultralytics" alt="Ultralytics Downloads"></a>
    <a href="https://discord.com/invite/ultralytics"><img alt="Ultralytics Discord" src="https://img.shields.io/discord/1089800235347353640?logo=discord&logoColor=white&label=Discord&color=blue"></a>
    <a href="https://community.ultralytics.com"><img alt="Ultralytics Forums" src="https://img.shields.io/discourse/users?server=https%3A%2F%2Fcommunity.ultralytics.com&logo=discourse&label=Forums&color=blue"></a>
    <a href="https://www.reddit.com/r/ultralytics/"><img alt="Ultralytics Reddit" src="https://img.shields.io/reddit/subreddit-subscribers/ultralytics?style=flat&logo=reddit&logoColor=white&label=Reddit&color=blue"></a>
    <br>
    <a href="https://console.paperspace.com/github/ultralytics/ultralytics"><img src="https://assets.paperspace.io/img/gradient-badge.svg" alt="Run Ultralytics on Gradient"></a>
    <a href="https://colab.research.google.com/github/ultralytics/ultralytics/blob/main/examples/tutorial.ipynb"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open Ultralytics In Colab"></a>
    <a href="https://www.kaggle.com/models/ultralytics/yolo26"><img src="https://kaggle.com/static/images/open-in-kaggle.svg" alt="Open Ultralytics In Kaggle"></a>
    <a href="https://mybinder.org/v2/gh/ultralytics/ultralytics/HEAD?labpath=examples%2Ftutorial.ipynb"><img src="https://mybinder.org/badge_logo.svg" alt="Open Ultralytics In Binder"></a>
</div>
</div>
<br>

<div align="center">
  <a href="https://trendshift.io/repositories/1556?utm_source=repository-badge&amp;utm_medium=badge&amp;utm_campaign=badge-repository-1556" target="_blank" rel="noopener noreferrer"><img src="https://trendshift.io/api/badge/repositories/1556" alt="ultralytics%2Fultralytics | Trendshift" width="250" height="55"/></a>
</div>
<br>

[Ultralytics](https://www.ultralytics.com) 基于多年在计算机视觉和人工智能领域的基础研究，创造了尖端的、最先进的 (SOTA) [YOLO 模型](https://www.ultralytics.com/yolo)。我们的模型不断更新以提高性能和灵活性，具有**速度快**、**精度高**和**易于使用**的特点。它们在[目标检测](https://docs.ultralytics.com/tasks/detect)、[实例分割](https://docs.ultralytics.com/tasks/segment)、[语义分割](https://docs.ultralytics.com/tasks/semantic)、[图像分类](https://docs.ultralytics.com/tasks/classify)和[姿态估计](https://docs.ultralytics.com/tasks/pose)任务中表现出色，并可在视频帧间[跟踪](https://docs.ultralytics.com/modes/track)已检测到的目标。

在 [Ultralytics 文档](https://docs.ultralytics.com)中查找详细文档。通过 [GitHub Issues](https://github.com/ultralytics/ultralytics/issues/new/choose) 获取支持。加入 [Discord](https://discord.com/invite/ultralytics)、[Reddit](https://www.reddit.com/r/ultralytics/) 和 [Ultralytics 社区论坛](https://community.ultralytics.com)参与讨论！

如需商业用途，请在 [Ultralytics 授权许可](https://www.ultralytics.com/license)申请企业许可证。

<a href="https://platform.ultralytics.com/ultralytics/yolo26" target="_blank">
  <img width="100%" src="https://raw.githubusercontent.com/ultralytics/assets/refs/heads/main/yolo/performance-comparison.png" alt="YOLO26 performance plots">
</a>

<div align="center">
  <a href="https://github.com/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-github.png" width="2%" alt="Ultralytics GitHub"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://www.linkedin.com/company/ultralytics/"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-linkedin.png" width="2%" alt="Ultralytics LinkedIn"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://twitter.com/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-twitter.png" width="2%" alt="Ultralytics Twitter"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://www.youtube.com/ultralytics?sub_confirmation=1"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-youtube.png" width="2%" alt="Ultralytics YouTube"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://www.tiktok.com/@ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-tiktok.png" width="2%" alt="Ultralytics TikTok"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://ultralytics.com/bilibili"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-bilibili.png" width="2%" alt="Ultralytics BiliBili"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="2%" alt="space">
  <a href="https://discord.com/invite/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-discord.png" width="2%" alt="Ultralytics Discord"></a>
</div>

## 📄 文档

请参阅下文了解快速安装和使用示例。有关训练、验证、预测和部署的全面指南，请参阅我们的完整 [Ultralytics 文档](https://docs.ultralytics.com)。

<details open>
<summary>安装</summary>

在 [**Python>=3.8**](https://www.python.org/) 环境中安装 `ultralytics` 包，包括所有[依赖项](https://github.com/ultralytics/ultralytics/blob/main/pyproject.toml)，并确保 [**PyTorch>=1.8**](https://pytorch.org/get-started/locally/)。

[![PyPI - Version](https://img.shields.io/pypi/v/ultralytics?logo=pypi&logoColor=white)](https://pypi.org/project/ultralytics/) [![Ultralytics Downloads](https://static.pepy.tech/badge/ultralytics)](https://clickpy.clickhouse.com/dashboard/ultralytics) [![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ultralytics?logo=python&logoColor=gold)](https://pypi.org/project/ultralytics/)

```bash
pip install ultralytics
```

有关其他安装方法，包括 [Conda](https://anaconda.org/conda-forge/ultralytics)、[Docker](https://hub.docker.com/r/ultralytics/ultralytics) 以及通过 Git 从源代码构建，请查阅[快速入门指南](https://docs.ultralytics.com/quickstart)。

[![Conda Version](https://img.shields.io/conda/vn/conda-forge/ultralytics?logo=condaforge)](https://anaconda.org/conda-forge/ultralytics) [![Docker Image Version](https://img.shields.io/docker/v/ultralytics/ultralytics?sort=semver&logo=docker)](https://hub.docker.com/r/ultralytics/ultralytics) [![Ultralytics Docker Pulls](https://img.shields.io/docker/pulls/ultralytics/ultralytics?logo=docker)](https://hub.docker.com/r/ultralytics/ultralytics)

</details>

<details open>
<summary>使用方法</summary>

### CLI

您可以直接通过命令行界面 (CLI) 使用 `yolo` 命令来运行 Ultralytics YOLO：

```bash
# 使用预训练的 YOLO 模型 (例如 YOLO26n) 对图像进行预测
yolo predict model=yolo26n.pt source='https://ultralytics.com/images/bus.jpg'
```

`yolo` 命令支持各种任务和模式，并接受额外的参数，如 `imgsz=640`。浏览 YOLO [CLI 文档](https://docs.ultralytics.com/usage/cli)获取更多示例。

### Python

Ultralytics YOLO 也可以直接集成到您的 Python 项目中。它接受与 CLI 相同的[配置参数](https://docs.ultralytics.com/usage/cfg)：

```python
from ultralytics import YOLO

# 加载一个预训练的 YOLO26n 模型
model = YOLO("yolo26n.pt")

# 在 COCO8 数据集上训练模型 100 个周期
train_results = model.train(
    data="coco8.yaml",  # 数据集配置文件路径
    epochs=100,  # 训练周期数
    imgsz=640,  # 训练图像尺寸
    device="cpu",  # 运行设备 (例如 'cpu', 0, [0,1,2,3])
)

# 评估模型在验证集上的性能
metrics = model.val()

# 对图像执行目标检测
results = model("path/to/image.jpg")  # 对图像进行预测
results[0].show()  # 显示结果

# 将模型导出为 ONNX 格式以进行部署
path = model.export(format="onnx")  # 返回导出模型的路径
```

在 YOLO [Python 文档](https://docs.ultralytics.com/usage/python)中发现更多示例。

</details>

## ✨ 模型

Ultralytics 支持广泛的 YOLO 模型，从早期的版本如 [YOLOv3](https://docs.ultralytics.com/models/yolov3) 到最新的 [YOLO26](https://docs.ultralytics.com/models/yolo26)。下表展示了在 [COCO](https://docs.ultralytics.com/datasets/detect/coco) 上预训练的 YOLO26 模型，用于[检测](https://docs.ultralytics.com/tasks/detect)、[分割](https://docs.ultralytics.com/tasks/segment)和[姿态估计](https://docs.ultralytics.com/tasks/pose)任务。[语义分割](https://docs.ultralytics.com/tasks/semantic)模型在 [Cityscapes](https://docs.ultralytics.com/datasets/semantic/cityscapes) 上预训练，[深度估计](https://docs.ultralytics.com/tasks/depth)模型在广泛的多数据集混合上预训练并在 [NYU Depth V2](https://cs.nyu.edu/~fergus/datasets/nyu_depth_v2.html) 上评估，[分类](https://docs.ultralytics.com/tasks/classify)模型在 [ImageNet](https://docs.ultralytics.com/datasets/classify/imagenet) 上预训练。[跟踪](https://docs.ultralytics.com/modes/track)模式与检测、分割、姿态和 OBB 模型兼容。所有[模型](https://docs.ultralytics.com/models)在首次使用时都会自动从最新的 Ultralytics [发布版本](https://github.com/ultralytics/assets/releases)下载。

<a href="https://docs.ultralytics.com/tasks" target="_blank">
    <img width="100%" src="https://cdn.ul.run/i/c99d914c3958d0755b5a3d7204b6f24a.avif" alt="Ultralytics YOLO supported tasks">
</a>
<br>
<br>

<details open><summary>检测 (COCO)</summary>

浏览[检测文档](https://docs.ultralytics.com/tasks/detect)获取使用示例。这些模型在 [COCO 数据集](https://cocodataset.org/)上训练，包含 80 个对象类别。

| 模型                                                                   | 尺寸<br><sup>(像素) | mAP<sup>val<br>50-95 | mAP<sup>val<br>50-95(e2e) | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| ---------------------------------------------------------------------- | ------------------- | -------------------- | ------------------------- | ------------------------------- | ------------------------------------ | ------------------- | -------------------- |
| [YOLO26n](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n) | 640                 | 40.9                 | 40.1                      | 38.9 ± 0.7                      | 1.7 ± 0.0                            | 2.4                 | 5.4                  |
| [YOLO26s](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s) | 640                 | 48.6                 | 47.8                      | 87.2 ± 0.9                      | 2.5 ± 0.0                            | 9.5                 | 20.7                 |
| [YOLO26m](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m) | 640                 | 53.1                 | 52.5                      | 220.0 ± 1.4                     | 4.7 ± 0.1                            | 20.4                | 68.2                 |
| [YOLO26l](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l) | 640                 | 55.0                 | 54.4                      | 286.2 ± 2.0                     | 6.2 ± 0.2                            | 24.8                | 86.4                 |
| [YOLO26x](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x) | 640                 | 57.5                 | 56.9                      | 525.8 ± 4.0                     | 11.8 ± 0.2                           | 55.7                | 193.9                |

- **mAP<sup>val</sup>** 值指的是在 [COCO val2017](https://cocodataset.org/) 数据集上的单模型单尺度性能。详见 [YOLO 性能指标](https://docs.ultralytics.com/guides/yolo-performance-metrics)。<br>使用 `yolo val detect data=coco.yaml device=0` 复现结果。
- **速度** 指标是在 [Amazon EC2 P4d](https://aws.amazon.com/ec2/instance-types/p4/) 实例上对 COCO val 图像进行平均测量的。CPU 速度使用 [ONNX](https://onnx.ai/) 导出进行测量。GPU 速度使用 [TensorRT](https://developer.nvidia.com/tensorrt) 导出进行测量。<br>使用 `yolo val detect data=coco.yaml batch=1 device=0|cpu` 复现结果。

</details>

<details><summary>分割 (COCO)</summary>

请参阅[分割文档](https://docs.ultralytics.com/tasks/segment)获取使用示例。这些模型在 [COCO-Seg](https://docs.ultralytics.com/datasets/segment/coco) 数据集上训练，包含 80 个类别。

| 模型                                                                           | 尺寸<br><sup>(像素) | mAP<sup>box<br>50-95(e2e) | mAP<sup>mask<br>50-95(e2e) | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| ------------------------------------------------------------------------------ | ------------------- | ------------------------- | -------------------------- | ------------------------------- | ------------------------------------ | ------------------- | -------------------- |
| [YOLO26n-seg](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-seg) | 640                 | 39.6                      | 33.9                       | 53.3 ± 0.5                      | 2.1 ± 0.0                            | 2.7                 | 9.1                  |
| [YOLO26s-seg](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-seg) | 640                 | 47.3                      | 40.0                       | 118.4 ± 0.9                     | 3.3 ± 0.0                            | 10.4                | 34.2                 |
| [YOLO26m-seg](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-seg) | 640                 | 52.5                      | 44.1                       | 328.2 ± 2.4                     | 6.7 ± 0.1                            | 23.6                | 121.5                |
| [YOLO26l-seg](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-seg) | 640                 | 54.4                      | 45.5                       | 387.0 ± 3.7                     | 8.0 ± 0.1                            | 28.0                | 139.8                |
| [YOLO26x-seg](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-seg) | 640                 | 56.5                      | 47.0                       | 787.0 ± 6.8                     | 16.4 ± 0.1                           | 62.8                | 313.5                |

- **mAP<sup>val</sup>** 值指的是在 [COCO val2017](https://cocodataset.org/) 数据集上的单模型单尺度性能。详见 [YOLO 性能指标](https://docs.ultralytics.com/guides/yolo-performance-metrics)。<br>使用 `yolo val segment data=coco.yaml device=0` 复现结果。
- **速度** 指标是在 [Amazon EC2 P4d](https://aws.amazon.com/ec2/instance-types/p4/) 实例上对 COCO val 图像进行平均测量的。CPU 速度使用 [ONNX](https://onnx.ai/) 导出进行测量。GPU 速度使用 [TensorRT](https://developer.nvidia.com/tensorrt) 导出进行测量。<br>使用 `yolo val segment data=coco.yaml batch=1 device=0|cpu` 复现结果。

</details>

<details><summary>语义分割 (Cityscapes)</summary>

请参阅[语义分割文档](https://docs.ultralytics.com/tasks/semantic)获取使用示例。这些模型在 [Cityscapes](https://docs.ultralytics.com/datasets/semantic/cityscapes) 数据集上训练，包含 19 个类别。

| 模型                                                                           | 尺寸<br><sup>(像素) | mIoU<sup>val | 速度<br><sup>RTX3090 PyTorch<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| ------------------------------------------------------------------------------ | ------------------- | ------------ | -------------------------------------- | ------------------- | -------------------- |
| [YOLO26n-sem](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-sem) | 1024 &times; 2048   | 78.3         | 4.4 ± 0.0                              | 1.6                 | 22.7                 |
| [YOLO26s-sem](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-sem) | 1024 &times; 2048   | 80.8         | 8.4 ± 0.0                              | 6.5                 | 88.8                 |
| [YOLO26m-sem](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-sem) | 1024 &times; 2048   | 82.0         | 19.9 ± 0.1                             | 14.3                | 304.5                |
| [YOLO26l-sem](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-sem) | 1024 &times; 2048   | 82.9         | 26.5 ± 0.1                             | 17.9                | 384.7                |
| [YOLO26x-sem](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-sem) | 1024 &times; 2048   | 83.6         | 48.9 ± 0.2                             | 40.2                | 861.7                |

- **mIoU<sup>val</sup>** 值指的是在 [Cityscapes](https://www.cityscapes-dataset.com/) 验证集上的单模型单尺度性能。<br>使用 `yolo semantic val data=cityscapes.yaml device=0 imgsz=2048` 复现结果。
- **速度** 指标是在 RTX3090 实例上对 Cityscapes 验证集图像进行平均测量的。<br>使用 `yolo semantic val data=cityscapes.yaml batch=1 device=0|cpu imgsz=2048` 复现结果。

</details>

<details><summary>深度估计 (NYU Depth V2)</summary>

请参阅[深度估计文档](https://docs.ultralytics.com/tasks/depth)获取使用示例。这些模型在广泛的多数据集混合上预训练，并在 [NYU Depth V2](https://cs.nyu.edu/~fergus/datasets/nyu_depth_v2.html) Eigen 测试集上评估，预测每像素深度（单位为米）。

| 模型                                                                               | 尺寸<br><sup>(像素) | delta1<sup>NYU</sup> | abs_rel<sup>NYU</sup> | rmse<sup>NYU</sup> | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| ---------------------------------------------------------------------------------- | ------------------- | -------------------- | --------------------- | ------------------ | ------------------------------- | ------------------------------------ | ------------------- | -------------------- |
| [YOLO26n-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-depth) | 768                 | 0.882                | 0.109                 | 0.414              | 272.0 ± 27.2                    | 2.7 ± 0.1                            | 6.4                 | 46.9                 |
| [YOLO26s-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-depth) | 768                 | 0.896                | 0.104                 | 0.399              | 393.7 ± 13.1                    | 3.8 ± 0.0                            | 13.2                | 67.9                 |
| [YOLO26m-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-depth) | 768                 | 0.921                | 0.089                 | 0.364              | 621.5 ± 49.7                    | 6.0 ± 0.1                            | 23.3                | 130.7                |
| [YOLO26l-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-depth) | 768                 | 0.930                | 0.083                 | 0.351              | 821.9 ± 50.7                    | 7.7 ± 0.1                            | 27.7                | 157.2                |
| [YOLO26x-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-depth) | 768                 | 0.933                | 0.080                 | 0.344              | 1240.9 ± 73.3                   | 13.6 ± 0.2                           | 57.0                | 302.0                |

- **delta1<sup>NYU</sup>** 是在 NYU Depth V2 Eigen 测试集（654 张图像）上，通过多尺度 + 水平翻转 TTA 和对数最小二乘对齐后，预测深度在真实深度 1.25 倍范围内的像素比例。
- 不使用 TTA 的单尺度准确率可通过 `yolo depth val model=yolo26n-depth.pt data=nyu-depth.yaml imgsz=768 device=0`（为每个模型尺寸替换 `model=` 参数）复现，该方法采用中值（仅尺度）对齐，得分较低：delta1 0.785 (n), 0.786 (s), 0.827 (m), 0.839 (l), 0.843 (x)。
- **abs_rel** 是预测深度与真实深度之间的平均绝对相对误差。
- **rmse** 是均方根误差（单位为米）。
- **速度** 为纯推理延迟（不含前/后处理），在 `imgsz=768`、`batch=1` 下测得，经预热后取多次计时运行的均值 ± 标准差。**CPU ONNX** 为在 32 核 Intel Xeon (Skylake) 上以 ONNX Runtime fp32 运行；**T4 TensorRT10** 为在 Tesla T4 上以 TensorRT fp16 运行。
- **参数** 和 **FLOPs** 在 768×768（已发布权重的训练分辨率）下测量。

</details>

<details><summary>分类 (ImageNet)</summary>

请查阅[分类文档](https://docs.ultralytics.com/tasks/classify)获取使用示例。这些模型在 [ImageNet](https://docs.ultralytics.com/datasets/classify/imagenet) 数据集上训练，涵盖 1000 个类别。

| 模型                                                                           | 尺寸<br><sup>(像素) | acc<br><sup>top1 | acc<br><sup>top5 | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) @ 224 |
| ------------------------------------------------------------------------------ | ------------------- | ---------------- | ---------------- | ------------------------------- | ------------------------------------ | ------------------- | -------------------------- |
| [YOLO26n-cls](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-cls) | 224                 | 71.4             | 90.1             | 5.0 ± 0.3                       | 1.1 ± 0.0                            | 2.8                 | 0.5                        |
| [YOLO26s-cls](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-cls) | 224                 | 76.0             | 92.9             | 7.9 ± 0.2                       | 1.3 ± 0.0                            | 6.7                 | 1.6                        |
| [YOLO26m-cls](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-cls) | 224                 | 78.1             | 94.2             | 17.2 ± 0.4                      | 2.0 ± 0.0                            | 11.6                | 4.9                        |
| [YOLO26l-cls](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-cls) | 224                 | 79.0             | 94.6             | 23.2 ± 0.3                      | 2.8 ± 0.0                            | 14.1                | 6.2                        |
| [YOLO26x-cls](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-cls) | 224                 | 79.9             | 95.0             | 41.4 ± 0.9                      | 3.8 ± 0.0                            | 29.6                | 13.6                       |

- **acc** 值表示模型在 [ImageNet](https://www.image-net.org/) 数据集验证集上的准确率。<br>使用 `yolo val classify data=path/to/ImageNet device=0` 复现结果。
- **速度** 指标是在 [Amazon EC2 P4d](https://aws.amazon.com/ec2/instance-types/p4/) 实例上对 ImageNet val 图像进行平均测量的。CPU 速度使用 [ONNX](https://onnx.ai/) 导出进行测量。GPU 速度使用 [TensorRT](https://developer.nvidia.com/tensorrt) 导出进行测量。<br>使用 `yolo val classify data=path/to/ImageNet batch=1 device=0|cpu` 复现结果。

</details>

<details><summary>姿态估计 (COCO)</summary>

请参阅[姿态估计文档](https://docs.ultralytics.com/tasks/pose)获取使用示例。这些模型在 [COCO-Pose](https://docs.ultralytics.com/datasets/pose/coco) 数据集上训练，专注于 'person' 类别。

| 模型                                                                             | 尺寸<br><sup>(像素) | mAP<sup>pose<br>50-95(e2e) | mAP<sup>pose<br>50(e2e) | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| -------------------------------------------------------------------------------- | ------------------- | -------------------------- | ----------------------- | ------------------------------- | ------------------------------------ | ------------------- | -------------------- |
| [YOLO26n-pose](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-pose) | 640                 | 57.2                       | 83.3                    | 40.3 ± 0.5                      | 1.8 ± 0.0                            | 2.9                 | 7.5                  |
| [YOLO26s-pose](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-pose) | 640                 | 63.0                       | 86.6                    | 85.3 ± 0.9                      | 2.7 ± 0.0                            | 10.4                | 23.9                 |
| [YOLO26m-pose](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-pose) | 640                 | 68.8                       | 89.6                    | 218.0 ± 1.5                     | 5.0 ± 0.1                            | 21.5                | 73.1                 |
| [YOLO26l-pose](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-pose) | 640                 | 70.4                       | 90.5                    | 275.4 ± 2.4                     | 6.5 ± 0.1                            | 25.9                | 91.3                 |
| [YOLO26x-pose](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-pose) | 640                 | 71.6                       | 91.6                    | 565.4 ± 3.0                     | 12.2 ± 0.2                           | 57.6                | 201.7                |

- **mAP<sup>val</sup>** 值指的是在 [COCO Keypoints val2017](https://docs.ultralytics.com/datasets/pose/coco) 数据集上的单模型单尺度性能。详见 [YOLO 性能指标](https://docs.ultralytics.com/guides/yolo-performance-metrics)。<br>使用 `yolo val pose data=coco-pose.yaml device=0` 复现结果。
- **速度** 指标是在 [Amazon EC2 P4d](https://aws.amazon.com/ec2/instance-types/p4/) 实例上对 COCO val 图像进行平均测量的。CPU 速度使用 [ONNX](https://onnx.ai/) 导出进行测量。GPU 速度使用 [TensorRT](https://developer.nvidia.com/tensorrt) 导出进行测量。<br>使用 `yolo val pose data=coco-pose.yaml batch=1 device=0|cpu` 复现结果。

</details>

<details><summary>定向边界框 (DOTAv1)</summary>

请查阅 [OBB 文档](https://docs.ultralytics.com/tasks/obb)获取使用示例。这些模型在 [DOTAv1](https://docs.ultralytics.com/datasets/obb/dota-v2#dota-v10) 数据集上训练，包含 15 个类别。

| 模型                                                                           | 尺寸<br><sup>(像素) | mAP<sup>test<br>50-95(e2e) | mAP<sup>test<br>50(e2e) | 速度<br><sup>CPU ONNX<br>(毫秒) | 速度<br><sup>T4 TensorRT10<br>(毫秒) | 参数<br><sup>(百万) | FLOPs<br><sup>(十亿) |
| ------------------------------------------------------------------------------ | ------------------- | -------------------------- | ----------------------- | ------------------------------- | ------------------------------------ | ------------------- | -------------------- |
| [YOLO26n-obb](https://platform.ultralytics.com/ultralytics/yolo26/yolo26n-obb) | 1024                | 52.4                       | 78.9                    | 97.7 ± 0.9                      | 2.8 ± 0.0                            | 2.5                 | 14.0                 |
| [YOLO26s-obb](https://platform.ultralytics.com/ultralytics/yolo26/yolo26s-obb) | 1024                | 54.8                       | 80.9                    | 218.0 ± 1.4                     | 4.9 ± 0.1                            | 9.8                 | 55.1                 |
| [YOLO26m-obb](https://platform.ultralytics.com/ultralytics/yolo26/yolo26m-obb) | 1024                | 55.3                       | 81.0                    | 579.2 ± 3.8                     | 10.2 ± 0.3                           | 21.2                | 183.3                |
| [YOLO26l-obb](https://platform.ultralytics.com/ultralytics/yolo26/yolo26l-obb) | 1024                | 56.2                       | 81.6                    | 735.6 ± 3.1                     | 13.0 ± 0.2                           | 25.6                | 230.0                |
| [YOLO26x-obb](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-obb) | 1024                | 56.7                       | 81.7                    | 1485.7 ± 11.5                   | 30.5 ± 0.9                           | 57.6                | 516.5                |

- **mAP<sup>test</sup>** 值指的是在 [DOTAv1 测试集](https://captain-whu.github.io/DOTA/dataset.html)上的单模型多尺度性能。<br>通过 `yolo val obb data=DOTAv1.yaml device=0 split=test` 复现结果，并将合并后的结果提交到 [DOTA 评估服务器](https://captain-whu.github.io/DOTA/evaluation.html)。
- **速度** 指标是在 [Amazon EC2 P4d](https://aws.amazon.com/ec2/instance-types/p4/) 实例上对 [DOTAv1 val 图像](https://docs.ultralytics.com/datasets/obb/dota-v2#dota-v10)进行平均测量的。CPU 速度使用 [ONNX](https://onnx.ai/) 导出进行测量。GPU 速度使用 [TensorRT](https://developer.nvidia.com/tensorrt) 导出进行测量。<br>通过 `yolo val obb data=DOTAv1.yaml batch=1 device=0|cpu` 复现结果。

</details>

## 🧩 集成

我们与领先 AI 平台的关键集成扩展了 Ultralytics 产品的功能，增强了数据集标注、训练、可视化和模型管理等任务。了解 Ultralytics 如何与 [Weights & Biases](https://docs.ultralytics.com/integrations/weights-biases)、[Comet ML](https://docs.ultralytics.com/integrations/comet)、[Roboflow](https://docs.ultralytics.com/integrations/roboflow) 和 [Intel OpenVINO](https://docs.ultralytics.com/integrations/openvino) 等合作伙伴协作，优化您的 AI 工作流程。在 [Ultralytics 集成](https://docs.ultralytics.com/integrations)了解更多信息。

<a href="https://platform.ultralytics.com" target="_blank">
    <img width="100%" src="https://github.com/ultralytics/assets/raw/main/yolov8/banner-integrations.png" alt="Ultralytics active learning integrations">
</a>

## 🤝 贡献

我们依靠社区协作蓬勃发展！没有像您这样的开发者的贡献，Ultralytics YOLO 就不会成为如今最先进的框架。请参阅我们的[贡献指南](https://docs.ultralytics.com/help/contributing)开始贡献。我们也欢迎您的反馈——通过完成我们的[调查问卷](https://www.ultralytics.com/survey?utm_source=github&utm_medium=social&utm_campaign=Survey)分享您的体验。非常**感谢** 🙏 每一位贡献者！

<!-- SVG image from https://opencollective.com/ultralytics/contributors.svg?width=1280 -->

[![Ultralytics open-source contributors](https://raw.githubusercontent.com/ultralytics/assets/main/im/image-contributors.png)](https://github.com/ultralytics/ultralytics/graphs/contributors)

我们期待您的贡献，帮助 Ultralytics 生态系统变得更好！

## 📜 许可证

Ultralytics 提供两种许可选项以满足不同需求：

- **AGPL-3.0 许可证**：这种经 [OSI 批准](https://opensource.org/license/agpl-3.0)的开源许可证非常适合学生、研究人员和爱好者。它鼓励开放协作和知识共享。有关完整详细信息，请参阅 [LICENSE](https://github.com/ultralytics/ultralytics/blob/main/LICENSE) 文件。
- **Ultralytics 企业许可证**：适用于开发和生产用途，此许可证允许将 Ultralytics 软件和 AI 模型无缝集成到业务产品和服务中，包括内部工具、自动化工作流和生产部署，绕过 AGPL-3.0 的开源要求。如需开始使用，请通过 [Ultralytics 授权许可](https://www.ultralytics.com/license)与我们联系。

## 📞 联系方式

有关 Ultralytics 软件的错误报告和功能请求，请访问 [GitHub Issues](https://github.com/ultralytics/ultralytics/issues)。如有疑问、讨论和社区支持，请加入我们在 [Discord](https://discord.com/invite/ultralytics)、[Reddit](https://www.reddit.com/r/ultralytics/) 和 [Ultralytics 社区论坛](https://community.ultralytics.com)上的活跃社区。我们随时为您提供有关 Ultralytics 的所有帮助！

<br>
<div align="center">
  <a href="https://github.com/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-github.png" width="3%" alt="Ultralytics GitHub"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://www.linkedin.com/company/ultralytics/"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-linkedin.png" width="3%" alt="Ultralytics LinkedIn"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://twitter.com/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-twitter.png" width="3%" alt="Ultralytics Twitter"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://www.youtube.com/ultralytics?sub_confirmation=1"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-youtube.png" width="3%" alt="Ultralytics YouTube"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://www.tiktok.com/@ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-tiktok.png" width="3%" alt="Ultralytics TikTok"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://ultralytics.com/bilibili"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-bilibili.png" width="3%" alt="Ultralytics BiliBili"></a>
  <img src="https://github.com/ultralytics/assets/raw/main/social/logo-transparent.png" width="3%" alt="space">
  <a href="https://discord.com/invite/ultralytics"><img src="https://github.com/ultralytics/assets/raw/main/social/logo-social-discord.png" width="3%" alt="Ultralytics Discord"></a>
</div>
