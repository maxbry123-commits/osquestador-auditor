package sql

import (
	"bytes"
	"net/url"
	"strings"

	"github.com/88250/lute"
	"github.com/88250/lute/ast"
	"github.com/88250/lute/html"
	"github.com/88250/lute/parse"
	"github.com/88250/lute/render"
	"github.com/siyuan-note/logging"
	"github.com/siyuan-note/siyuan/kernel/av"
	"github.com/siyuan-note/siyuan/kernel/filesys"
	"github.com/siyuan-note/siyuan/kernel/treenode"
	"github.com/siyuan-note/siyuan/kernel/util"
)

func RenderAttributeViewGallery(attrView *av.AttributeView, view *av.View, query string, depth *int, cachedAttrViews map[string]*av.AttributeView, ignoreRows bool) (ret *av.Gallery) {
	context := NewAttributeViewRenderContext()
	ret = renderAttributeViewGallery(attrView, view, query, depth, cachedAttrViews, ignoreRows, false, context)
	context.PushTemplateErrors()
	return
}

func renderAttributeViewGallery(attrView *av.AttributeView, view *av.View, query string, depth *int,
	cachedAttrViews map[string]*av.AttributeView, ignoreRows, deferTemplateValues bool,
	renderContext *AttributeViewRenderContext) (ret *av.Gallery) {
	if !ignoreRows && !deferTemplateValues {
		viewable := attrView.RenderedViewables[view.ID]
		if nil != viewable {
			ret = viewable.(*av.Gallery)
			return
		}
	}

	ret = &av.Gallery{
		BaseInstance:         av.NewViewBaseInstance(view),
		CoverFrom:            view.Gallery.CoverFrom,
		CoverFromAssetKeyID:  view.Gallery.CoverFromAssetKeyID,
		CardAspectRatio:      view.Gallery.CardAspectRatio,
		CardAspectRatioValue: view.Gallery.CardAspectRatioValue,
		CardSize:             view.Gallery.CardSize,
		CardWidth:            view.Gallery.CardWidth,
		CardLayout:           view.Gallery.CardLayout,
		FitImage:             view.Gallery.FitImage,
		DisplayFieldName:     view.Gallery.DisplayFieldName,
		DisplayEmptyFields:   view.Gallery.DisplayEmptyFields,
		Fields:               []*av.GalleryField{},
		Cards:                []*av.GalleryCard{},
	}

	// 组装字段
	for _, field := range view.Gallery.CardFields {
		key, getErr := attrView.GetKey(field.ID)
		if nil != getErr {
			// 找不到字段则在视图中删除（元数据查询场景不写盘）
			if !ignoreRows {
				removeMissingField(attrView, view, field.ID)
			}
			continue
		}

		ret.Fields = append(ret.Fields, &av.GalleryField{
			BaseInstanceField: &av.BaseInstanceField{
				ID:           key.ID,
				Name:         key.Name,
				Type:         key.Type,
				Icon:         key.Icon,
				Wrap:         field.Wrap,
				Hidden:       field.Hidden,
				Desc:         key.Desc,
				Calc:         field.Calc,
				Options:      key.Options,
				NumberFormat: key.NumberFormat,
				DateFormat:   key.DateFormat,
				Template:     key.Template,
				Relation:     key.Relation,
				Rollup:       key.Rollup,
				Date:         key.Date,
				Created:      key.Created,
				Updated:      key.Updated,
			},
			FullRow: field.FullRow,
		})
	}

	// 菜单等只需要字段/视图元数据的场景，跳过全部卡片处理
	if ignoreRows {
		return
	}

	cardsValues := generateAttrViewItems(attrView, view) // 生成卡片
	filterNotFoundAttrViewItems(cardsValues)             // 过滤掉不存在的卡片

	// 批量加载绑定块对应的树
	var ialIDs []string
	for _, keyValues := range cardsValues {
		for _, kValues := range keyValues {
			blockVal := kValues.GetBlockValue()
			if nil != blockVal && !blockVal.IsDetached {
				ialIDs = append(ialIDs, blockVal.Block.ID)
			}
		}
	}
	boundTrees := filesys.LoadTrees(ialIDs)

	// 生成卡片字段值
	for cardID, cardValues := range cardsValues {
		// 按字段 ID 建索引，避免后续字段循环里对每个字段做线性查找
		kvByField := map[string]*av.KeyValues{}
		for _, keyValues := range cardValues {
			if _, ok := kvByField[keyValues.Key.ID]; !ok { // 同一字段存在多个值时只取第一个
				kvByField[keyValues.Key.ID] = keyValues
			}
		}

		var galleryCard av.GalleryCard
		for _, field := range ret.Fields {
			var fieldValue *av.GalleryFieldValue
			if keyValues, ok := kvByField[field.ID]; ok {
				fieldValue = &av.GalleryFieldValue{
					BaseValue: &av.BaseValue{
						ID:        keyValues.Values[0].ID,
						Value:     keyValues.Values[0],
						ValueType: field.Type,
					},
				}
			}
			if nil == fieldValue {
				fieldValue = &av.GalleryFieldValue{
					BaseValue: &av.BaseValue{
						ID:        cardID[:14] + ast.NewNodeID()[14:],
						ValueType: field.Type,
					},
				}
			}
			galleryCard.ID = cardID

			filedDateIsTime := false
			if nil != field.Date {
				filedDateIsTime = field.Date.FillSpecificTime
			}
			fillAttributeViewBaseValue(fieldValue.BaseValue, field.ID, cardID, field.NumberFormat, field.DateFormat,
				field.Template, filedDateIsTime)
			galleryCard.Values = append(galleryCard.Values, fieldValue)
		}

		fillAttributeViewGalleryCardCover(attrView, view, cardValues, &galleryCard, cardID, luteEngine, boundTrees)
		galleryCard.CoverPosition = attrView.GetCardCoverPosition(cardID,
			av.CardCoverSource(view.Gallery.CoverFrom, view.Gallery.CoverFromAssetKeyID), galleryCard.CoverURL)
		ret.Cards = append(ret.Cards, &galleryCard)
	}

	// 回填补全数据
	fillAttributeViewKeyValues(attrView, ret)

	// 批量获取块属性以提升性能
	ials := BatchGetBlockAttrsWitTrees(ialIDs, boundTrees)

	// 渲染自动生成的字段值，比如关联、汇总、创建时间和更新时间
	fillAttributeViewAutoGeneratedValues(attrView, ret, ials, depth, cachedAttrViews, renderContext)

	if !deferTemplateValues {
		// 最后渲染模板字段，这样模板就可以使用汇总、关联、创建时间和更新时间的值了
		fillAttributeViewTemplateValues(attrView, view, ret, ials, renderContext)
	}

	filterByQuery(query, ret)
	manualSort(view, ret)
	return
}

func fillAttributeViewGalleryCardCover(attrView *av.AttributeView, view *av.View, cardValues []*av.KeyValues, galleryCard *av.GalleryCard, cardID string, luteEngine *lute.Lute, trees map[string]*parse.Tree) {
	switch view.Gallery.CoverFrom {
	case av.CoverFromNone:
	case av.CoverFromContentImage:
		blockValue := getBlockValue(cardValues)
		if blockValue.IsDetached {
			break
		}

		tree := trees[blockValue.Block.ID]
		if nil == tree {
			break
		}
		node := treenode.GetNodeInTree(tree, blockValue.Block.ID)
		if nil == node {
			break
		}

		if ast.NodeDocument == node.Type {
			if titleImg := treenode.GetDocTitleImgPath(node); "" != titleImg {
				galleryCard.CoverURL = titleImg
				break
			}

			if titleImgCSS := node.IALAttr("title-img"); "" != titleImgCSS {
				galleryCard.CoverURL = titleImgCSS
				break
			}
		}

		ast.Walk(node, func(n *ast.Node, entering bool) ast.WalkStatus {
			if !entering {
				return ast.WalkContinue
			}

			if ast.NodeImage != n.Type {
				return ast.WalkContinue
			}

			dest := n.ChildByType(ast.NodeLinkDest)
			if nil == dest {
				return ast.WalkContinue
			}
			galleryCard.CoverURL = dest.TokensStr()
			return ast.WalkStop
		})

		if "" == galleryCard.CoverURL {
			galleryCard.CoverContent = renderCoverContentBlock(node, luteEngine)
			return
		}
	case av.CoverFromAssetField:
		if "" == view.Gallery.CoverFromAssetKeyID {
			break
		}

		assetValue := attrView.GetValue(view.Gallery.CoverFromAssetKeyID, cardID)
		if nil == assetValue || 1 > len(assetValue.MAsset) {
			break
		}

		for _, asset := range assetValue.MAsset {
			if asset.Type == av.AssetTypeImage && util.IsPossiblyImage(asset.Content) {
				galleryCard.CoverURL = asset.Content
				break
			}
		}
		return
	case av.CoverFromContentBlock:
		blockValue := getBlockValue(cardValues)
		if blockValue.IsDetached {
			break
		}

		tree := trees[blockValue.Block.ID]
		if nil == tree {
			break
		}
		node := treenode.GetNodeInTree(tree, blockValue.Block.ID)
		if nil == node {
			break
		}
		galleryCard.CoverContent = renderCoverContentBlock(node, luteEngine)
	}
}

func renderCoverContentBlock(node *ast.Node, luteEngine *lute.Lute) string {
	isDoc := ast.NodeDocument == node.Type
	if isDoc {
		node = node.FirstChild
	}
	heading := node
	isHeading := ast.NodeHeading == node.Type
	headingLevel := node.HeadingLevel
	if isHeading {
		node = node.Next
	}

	buf := bytes.Buffer{}
	for c := node; nil != c; c = c.Next {
		if isHeading && ast.NodeHeading == c.Type && c.HeadingLevel <= headingLevel {
			if 1 > buf.Len() {
				buf.WriteString(renderBlockDOMByNode(heading, luteEngine))
			}
			break
		}
		buf.WriteString(renderBlockDOMByNode(c, luteEngine))
		if (!isDoc && !isHeading) || 1024*4 < buf.Len() {
			break
		}
	}
	return buf.String()
}

func renderBlockDOMByNode(node *ast.Node, luteEngine *lute.Lute) string {
	tree := &parse.Tree{Root: &ast.Node{Type: ast.NodeDocument}, Context: &parse.Context{ParseOption: luteEngine.ParseOptions}}
	blockRenderer := render.NewProtyleRenderer(tree, luteEngine.RenderOptions, luteEngine.ParseOptions)
	blockRenderer.Options.ProtyleContenteditable = false
	resetIDs := map[string]string{}
	ast.Walk(node, func(n *ast.Node, entering bool) ast.WalkStatus {
		if entering {
			if n.IsBlock() {
				// 内容图中不需要渲染数据库角标 https://github.com/siyuan-note/siyuan/issues/15057
				ial := parse.IAL2Map(n.KramdownIAL)
				delete(ial, av.NodeAttrNameAvs)

				// 重置 data-node-id 的值，避免触发前端绑定的事件 https://github.com/siyuan-note/siyuan/issues/15088
				newID := ast.NewNodeID()
				resetIDs[newID] = n.ID
				n.ID, ial["id"] = newID, newID
				n.KramdownIAL = parse.Map2IAL(ial)

				if ast.NodeIFrame == n.Type || ast.NodeAudio == n.Type || ast.NodeVideo == n.Type {
					// 禁止自动播放 Disable automatic video playback in database card view https://github.com/siyuan-note/siyuan/issues/15212
					dest := treenode.GetNodeSrcTokens(n)
					oldDest := dest
					if (strings.HasPrefix(dest, "http://") || strings.HasPrefix(dest, "https://")) && !strings.Contains(dest, "autoplay") {
						dest = html.UnescapeHTMLStr(dest)
						destURL, err := url.Parse(dest)
						if nil == err {
							q := destURL.Query()
							q.Set("autoplay", "0")
							destURL.RawQuery = q.Encode()
							dest = destURL.String()
							dest = html.EscapeHTMLStr(dest)
							n.Tokens = bytes.ReplaceAll(n.Tokens, []byte(oldDest), []byte(dest))
						} else {
							logging.LogWarnf("parse url [%s] failed: %v", dest, err)
						}
					}
				}
			}
		}
		rendererFunc := blockRenderer.RendererFuncs[n.Type]
		return rendererFunc(n, entering)
	})
	ret := strings.TrimSpace(blockRenderer.Writer.String())
	if strings.HasPrefix(ret, "<li") {
		ret = "<ul>" + ret + "</ul>"
	}
	ast.Walk(node, func(n *ast.Node, entering bool) ast.WalkStatus {
		if entering {
			if n.IsBlock() {
				// 还原上面重置 data-node-id 的值
				ial := parse.IAL2Map(n.KramdownIAL)
				oldID := resetIDs[n.ID]
				n.ID, ial["id"] = oldID, oldID
				n.KramdownIAL = parse.Map2IAL(ial)
			}
		}
		return ast.WalkContinue
	})
	return ret
}
