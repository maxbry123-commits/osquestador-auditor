module github.com/siyuan-note/siyuan/kernel

go 1.26.5

require (
	code.sajari.com/docconv v1.3.8
	github.com/88250/clipboard v0.1.5
	github.com/88250/epub v0.0.0-20230830085737-c19055cd1f48
	github.com/88250/go-humanize v0.0.0-20240424102817-4f78fac47ea7
	github.com/88250/gulu v1.2.3-0.20260609090754-168309361d92
	github.com/88250/vitess-sqlparser v0.0.0-20210205111146-56a2ded2aba1
	github.com/ClarkThan/ahocorasick v0.1.2
	github.com/ConradIrwin/font v0.2.2-0.20260202161408-44ae4cf5fb22
	github.com/Masterminds/sprig/v3 v3.3.0
	github.com/PuerkitoBio/goquery v1.12.0
	github.com/Xuanwo/go-locale v1.1.3
	github.com/araddon/dateparse v0.0.0-20210429162001-6b43995a97de
	github.com/asaskevich/EventBus v0.0.0-20200907212545-49d423059eef
	github.com/common-nighthawk/go-figure v0.0.0-20210622060536-734e95fb86be
	github.com/coreos/go-oidc/v3 v3.20.0
	github.com/denisbrodbeck/machineid v1.0.1
	github.com/dgraph-io/ristretto v0.2.0
	github.com/disintegration/imaging v1.6.2
	github.com/djherbis/times v1.6.0
	github.com/dop251/goja_nodejs v0.0.0-20260212111938-1f56ff5bcf14
	github.com/edsrzf/mmap-go v1.2.0
	github.com/emersion/go-ical v0.0.0-20250609112844-439c63cef608
	github.com/emersion/go-vcard v0.0.0-20260618161152-d854b7e0e2d3
	github.com/emersion/go-webdav v0.7.0
	github.com/emirpasic/gods v1.18.1
	github.com/facette/natsort v0.0.0-20181210072756-2cd4dd1e2dcb
	github.com/flopp/go-findfont v0.1.0
	github.com/fsnotify/fsnotify v1.10.1
	github.com/gabriel-vasile/mimetype v1.4.15
	github.com/gen2brain/h265 v0.1.1
	github.com/gin-contrib/gzip v1.2.3
	github.com/gin-contrib/sessions v1.1.0
	github.com/gin-contrib/sse v1.1.1
	github.com/gin-gonic/gin v1.12.0
	github.com/go-ole/go-ole v1.3.0
	github.com/gofrs/flock v0.13.0
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/gonutz/w32/v2 v2.12.1
	github.com/google/uuid v1.6.0
	github.com/gorilla/css v1.0.1
	github.com/gorilla/websocket v1.5.3
	github.com/imroc/req/v3 v3.61.0
	github.com/jaypipes/ghw v0.25.0
	github.com/jinzhu/copier v0.4.0
	github.com/json-iterator/go v1.1.12
	github.com/kballard/go-shellquote v0.0.0-20180428030007-95032a82bc51
	github.com/klippa-app/go-pdfium v1.19.8
	github.com/lxzan/gws v1.10.1
	github.com/mattn/go-sqlite3 v2.0.3+incompatible
	github.com/microcosm-cc/bluemonday v1.0.27
	github.com/mitchellh/go-ps v1.0.0
	github.com/modelcontextprotocol/go-sdk v1.7.0
	github.com/mssola/useragent v1.0.0
	github.com/olahol/melody v1.4.0
	github.com/open-spaced-repetition/go-fsrs/v3 v3.3.1
	github.com/panjf2000/ants/v2 v2.12.1
	github.com/patrickmn/go-cache v2.1.0+incompatible
	github.com/pdfcpu/pdfcpu v0.15.0
	github.com/pkoukk/tiktoken-go v0.1.8
	github.com/pkoukk/tiktoken-go-loader v0.0.2
	github.com/r3labs/sse/v2 v2.10.0
	github.com/radovskyb/watcher v1.0.7
	github.com/richardlehane/mscfb v1.0.7
	github.com/rqlite/sql v0.0.0-20260224021119-1b2524a41372
	github.com/sabhiram/go-gitignore v0.0.0-20210923224102-525f6e181f06
	github.com/samber/lo v1.53.0
	github.com/sashabaranov/go-openai v1.42.0
	github.com/shirou/gopsutil/v4 v4.26.7
	github.com/siyuan-note/dataparser v0.0.0-20260115084335-b57cb8bc7c17
	github.com/siyuan-note/dejavu v0.0.0-20260819021305-56b6bf7abb5b
	github.com/siyuan-note/encryption v0.0.0-20260715062728-9cb8e9548044
	github.com/siyuan-note/eventbus v0.0.0-20260530125927-d77c74260dce
	github.com/siyuan-note/filelock v0.0.0-20260411141728-bf44452627c0
	github.com/siyuan-note/httpclient v0.0.0-20260813083704-4643a83d05de
	github.com/siyuan-note/logging v0.0.0-20260513050044-06b8e04d5490
	github.com/siyuan-note/riff v0.0.0-20251022131846-228528e70754
	github.com/smallnest/chanx v1.2.0
	github.com/soheilhy/cmux v0.1.5
	github.com/spf13/cast v1.10.0
	github.com/spf13/cobra v1.10.2
	github.com/steambap/captcha v1.4.1
	github.com/studio-b12/gowebdav v0.13.0
	github.com/vanng822/css v1.0.1
	github.com/vmihailenco/msgpack/v5 v5.4.1
	github.com/xrash/smetrics v0.0.0-20250705151800-55b8f293f342
	github.com/xuri/excelize/v2 v2.11.0
	golang.org/x/mobile v0.0.0-20251209145715-2553ed8ce294
	golang.org/x/mod v0.40.0
	golang.org/x/net v0.58.0
	golang.org/x/sync v0.22.0
	golang.org/x/sys v0.47.0
	golang.org/x/text v0.41.0
	golang.org/x/time v0.15.0
	gopkg.in/yaml.v3 v3.0.1
)

require github.com/88250/lute v1.7.8-0.20260827055215-8928f1866da3

require (
	github.com/alecthomas/chroma/v2 v2.27.0 // indirect
	github.com/clipperhouse/displaywidth v0.11.0 // indirect
	github.com/dlclark/regexp2/v2 v2.6.0 // indirect
	github.com/fatih/color v1.19.0 // indirect
	github.com/mattn/go-colorable v0.1.15 // indirect
	github.com/olekukonko/cat v0.0.0-20250911104152-50322a0618f6 // indirect
	github.com/olekukonko/errors v1.3.0 // indirect
	github.com/olekukonko/ll v0.1.8 // indirect
	go.mongodb.org/mongo-driver/v2 v2.8.0 // indirect
)

require (
	dario.cat/mergo v1.0.2 // indirect
	dmitri.shuralyov.com/font/woff2 v0.0.0-20180220214647-957792cbbdab // indirect
	github.com/BurntSushi/toml v1.6.0 // indirect
	github.com/JalfResi/justext v0.0.0-20221106200834-be571e3e3052 // indirect
	github.com/Masterminds/goutils v1.1.1 // indirect
	github.com/Masterminds/semver/v3 v3.5.0 // indirect
	github.com/advancedlogic/GoOse v0.0.0-20231203033844-ae6b36caf275 // indirect
	github.com/alecthomas/chroma v0.10.0 // indirect
	github.com/alex-ant/gomath v0.0.0-20160516115720-89013a210a82 // indirect
	github.com/andybalholm/brotli v1.2.2 // indirect
	github.com/andybalholm/cascadia v1.3.4 // indirect
	github.com/aws/aws-sdk-go-v2 v1.43.5 // indirect
	github.com/aws/aws-sdk-go-v2/aws/protocol/eventstream v1.7.17 // indirect
	github.com/aws/aws-sdk-go-v2/config v1.32.36 // indirect
	github.com/aws/aws-sdk-go-v2/credentials v1.19.35 // indirect
	github.com/aws/aws-sdk-go-v2/feature/ec2/imds v1.18.36 // indirect
	github.com/aws/aws-sdk-go-v2/internal/configsources v1.4.36 // indirect
	github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 v2.7.36 // indirect
	github.com/aws/aws-sdk-go-v2/internal/v4a v1.4.37 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding v1.13.16 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/checksum v1.9.29 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/presigned-url v1.13.36 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/s3shared v1.19.37 // indirect
	github.com/aws/aws-sdk-go-v2/service/s3 v1.107.1 // indirect
	github.com/aws/aws-sdk-go-v2/service/signin v1.5.5 // indirect
	github.com/aws/aws-sdk-go-v2/service/sso v1.33.5 // indirect
	github.com/aws/aws-sdk-go-v2/service/ssooidc v1.38.5 // indirect
	github.com/aws/aws-sdk-go-v2/service/sts v1.45.5 // indirect
	github.com/aws/smithy-go v1.27.7 // indirect
	github.com/aymerick/douceur v0.2.0 // indirect
	github.com/bytedance/gopkg v0.1.4 // indirect
	github.com/bytedance/sonic v1.15.2 // indirect
	github.com/bytedance/sonic/loader v0.5.2 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/cloudwego/base64x v0.1.7 // indirect
	github.com/dlclark/regexp2 v1.12.0 // indirect
	github.com/dop251/base64dec v0.0.0-20231022112746-c6c9f9a96217 // indirect
	github.com/dop251/goja v0.0.0-20260806115107-493f22071ef6
	github.com/dsnet/compress v0.0.1 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/ebitengine/purego v0.10.2 // indirect
	github.com/fatih/set v0.2.1 // indirect
	github.com/gigawattio/window v0.0.0-20180317192513-0f5467e35573 // indirect
	github.com/go-jose/go-jose/v4 v4.1.4
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/go-playground/validator/v10 v10.30.3 // indirect
	github.com/go-resty/resty/v2 v2.17.2 // indirect
	github.com/go-sourcemap/sourcemap v2.1.4+incompatible // indirect
	github.com/go-sw/text-codec v0.0.1 // indirect
	github.com/goccy/go-json v0.10.6
	github.com/goccy/go-yaml v1.19.2 // indirect
	github.com/golang/freetype v0.0.0-20170609003504-e2365dfdc4a0 // indirect
	github.com/google/go-querystring v1.2.0 // indirect
	github.com/google/jsonschema-go v0.4.3
	github.com/google/pprof v0.0.0-20260802141513-ef3492d7dac3 // indirect
	github.com/gopherjs/gopherjs v1.21.0 // indirect
	github.com/gorilla/context v1.1.2 // indirect
	github.com/gorilla/securecookie v1.1.2 // indirect
	github.com/gorilla/sessions v1.4.0 // indirect
	github.com/hashicorp/mdns v1.0.7 // indirect
	github.com/hhrutter/lzw v1.0.1 // indirect
	github.com/hhrutter/tiff v1.0.6 // indirect
	github.com/huandu/xstrings v1.5.0 // indirect
	github.com/icholy/digest v1.2.0 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/jaypipes/pcidb v1.1.1 // indirect
	github.com/jaytaylor/html2text v0.0.0-20260303211410-1a4bdc82ecec // indirect
	github.com/jolestar/go-commons-pool/v2 v2.1.2 // indirect
	github.com/juju/errors v1.0.0 // indirect
	github.com/klauspost/compress v1.19.2 // indirect
	github.com/klauspost/cpuid/v2 v2.4.0 // indirect
	github.com/leodido/go-urn v1.5.0 // indirect
	github.com/levigross/exp-html v0.0.0-20120902181939-8df60c69a8f5 // indirect
	github.com/lufia/plan9stats v0.0.0-20260802145828-341c2f0c90b5 // indirect
	github.com/mattn/go-isatty v0.0.24 // indirect
	github.com/mattn/go-runewidth v0.0.27 // indirect
	github.com/miekg/dns v1.1.72 // indirect
	github.com/mitchellh/copystructure v1.2.0 // indirect
	github.com/mitchellh/reflectwalk v1.0.2 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/olekukonko/tablewriter v1.1.4 // indirect
	github.com/otiai10/gosseract/v2 v2.4.1 // indirect
	github.com/pelletier/go-toml/v2 v2.4.3 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/power-devops/perfstat v0.0.0-20260805114148-88456608a4f6 // indirect
	github.com/qiniu/go-sdk/v7 v7.27.0 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/quic-go/quic-go v0.61.0 // indirect
	github.com/refraction-networking/utls v1.8.2 // indirect
	github.com/restic/chunker v0.5.0 // indirect
	github.com/richardlehane/msoleps v1.0.6 // indirect
	github.com/segmentio/asm v1.2.1 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/shopspring/decimal v1.4.0 // indirect
	github.com/spf13/pflag v1.0.10 // indirect
	github.com/ssor/bom v0.0.0-20170718123548-6386211fdfcf // indirect
	github.com/teambition/rrule-go v1.8.2 // indirect
	github.com/tetratelabs/wazero v1.12.0 // indirect
	github.com/tiendc/go-deepcopy v1.7.2 // indirect
	github.com/tklauser/go-sysconf v0.4.0 // indirect
	github.com/tklauser/numcpus v0.12.0 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/ugorji/go/codec v1.3.2 // indirect
	github.com/vmihailenco/tagparser/v2 v2.0.0 // indirect
	github.com/wmentor/html v1.0.4 // indirect
	github.com/xuri/efp v0.0.1 // indirect
	github.com/xuri/nfp v0.0.2-0.20250530014748-2ddeb826f9a9 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	github.com/yusufpapurcu/wmi v1.2.4 // indirect
	golang.org/x/arch v0.30.0 // indirect
	golang.org/x/crypto v0.55.0
	golang.org/x/image v0.45.0
	golang.org/x/oauth2 v0.36.0
	golang.org/x/tools v0.49.0 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
	gopkg.in/cenkalti/backoff.v1 v1.1.0 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
	howett.net/plist v1.0.2-0.20250314012144-ee69052608d9 // indirect
	modernc.org/fileutil v1.4.0 // indirect
)

replace github.com/mattn/go-sqlite3 => github.com/88250/go-sqlite3 v1.14.13-0.20260704101239-6ddb6e555a1e

replace github.com/pdfcpu/pdfcpu => github.com/88250/pdfcpu v0.3.14-0.20250424122812-f10e8d9d8d46

//replace github.com/88250/lute => F:\golang\gopath\src\github.com\88250\lute
//replace github.com/siyuan-note/dejavu => D:\88250\dejavu
//replace github.com/siyuan-note/riff => D:\88250\riff
//replace github.com/siyuan-note/httpclient => D:\88250\httpclient
//replace github.com/siyuan-note/filelock => D:\88250\filelock
//replace github.com/pdfcpu/pdfcpu => D:\88250\pdfcpu
//replace github.com/88250/gulu => D:\88250\gulu
//replace github.com/mattn/go-sqlite3 => D:\88250\go-sqlite3
//replace github.com/88250/epub => D:\88250\epub
//replace github.com/siyuan-note/logging => D:\88250\logging
//replace github.com/siyuan-note/eventbus => D:\88250\eventbus
