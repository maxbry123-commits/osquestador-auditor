// SiYuan - From thought to insight, with agents
// Copyright (c) 2020-present, b3log.org
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package model

import (
	"image/color"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/88250/gulu"
	ginSessions "github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"github.com/siyuan-note/logging"
	"github.com/siyuan-note/siyuan/kernel/util"
	"github.com/steambap/captcha"
)

var (
	BasicAuthHeaderKey   = "WWW-Authenticate"
	BasicAuthHeaderValue = "Basic realm=\"SiYuan Authorization Require\", charset=\"UTF-8\""
)

func LogoutAuth(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	if !IsAccessAuthRequired() {
		ret.Code = -1
		ret.Msg = Conf.Language(86)
		ret.Data = map[string]any{"closeTimeout": 5000}
		return
	}

	session := util.GetSession(c)
	util.RemoveWorkspaceSession(session)
	if err := session.Save(c); err != nil {
		logging.LogError("saves session failed: " + err.Error())
		session.Clear(c)
		ret.Code = 1
		ret.Msg = Conf.Language(258)
		return
	}

	util.BroadcastByType("main", "logoutAuth", 0, "", nil)
}

func LoginAuth(c *gin.Context) {
	ret := gulu.Ret.NewResult()
	defer c.JSON(http.StatusOK, ret)

	arg, ok := util.JsonArg(c, ret)
	if !ok {
		return
	}

	var inputCaptcha string
	session := util.GetSession(c)
	workspaceSession := util.GetWorkspaceSession(session)
	if util.NeedCaptcha() {
		captchaArg := arg["captcha"]
		if nil == captchaArg {
			ret.Code = 1
			ret.Msg = Conf.Language(21)
			logging.LogWarnf("invalid captcha")
			return
		}
		inputCaptcha = captchaArg.(string)
		if "" == inputCaptcha {
			ret.Code = 1
			ret.Msg = Conf.Language(21)
			logging.LogWarnf("invalid captcha")
			return
		}

		if strings.ToLower(workspaceSession.Captcha) != strings.ToLower(inputCaptcha) {
			ret.Code = 1
			ret.Msg = Conf.Language(22)
			logging.LogWarnf("invalid captcha")

			workspaceSession.Captcha = gulu.Rand.String(7) // https://github.com/siyuan-note/siyuan/issues/13147
			if err := session.Save(c); err != nil {
				logging.LogError("save session failed: " + err.Error())
				session.Clear(c)
				ret.Code = 1
				ret.Msg = Conf.Language(258)
				return
			}
			return
		}
	}

	authCode := arg["authCode"].(string)
	authCode = util.RemoveInvalid(authCode)
	authCode = strings.TrimSpace(authCode)

	if Conf.AccessAuthCode == "" || !util.AuthCodeEquals(Conf.AccessAuthCode, authCode) {
		ret.Code = -1
		ret.Msg = Conf.Language(83)
		logging.LogWarnf("invalid auth code [ip=%s]", util.GetRemoteAddr(c.Request))

		util.WrongAuthCount++
		workspaceSession.Captcha = gulu.Rand.String(7)
		if util.NeedCaptcha() {
			ret.Code = 1 // 需要渲染验证码
		}

		if err := session.Save(c); err != nil {
			logging.LogError("save session failed: " + err.Error())
			session.Clear(c)
			ret.Code = 1
			ret.Msg = Conf.Language(258)
			return
		}
		return
	}

	workspaceSession.AccessAuthCode = authCode
	workspaceSession.OIDCSessionVersion = ""
	util.WrongAuthCount = 0
	util.AuthThrottleReset(c.ClientIP())
	workspaceSession.Captcha = gulu.Rand.String(7)

	maxAge := 0 // Default session expiration (browser session)
	if rememberMe, ok := arg["rememberMe"].(bool); ok && rememberMe {
		// Add a 'Remember me' checkbox when logging in to save a session https://github.com/siyuan-note/siyuan/pull/14964
		maxAge = 60 * 60 * 24 * 30 // 30 days
	}
	ginSessions.Default(c).Options(ginSessions.Options{
		Path:     "/",
		Secure:   util.SSL,
		MaxAge:   maxAge,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})

	logging.LogInfof("auth success [ip=%s, maxAge=%d]", util.GetRemoteAddr(c.Request), maxAge)
	if err := session.Save(c); err != nil {
		logging.LogError("save session failed: " + err.Error())
		session.Clear(c)
		ret.Code = 1
		ret.Msg = Conf.Language(258)
		return
	}

	util.BroadcastByType("auth", "loginAuth", 0, "", nil)
}

func GetCaptcha(c *gin.Context) {
	img, err := captcha.New(100, 26, func(options *captcha.Options) {
		options.CharPreset = "ABCDEFGHKLMNPQRSTUVWXYZ23456789"
		options.Noise = 0.5
		options.CurveNumber = 0
		options.BackgroundColor = color.White
	})
	if err != nil {
		logging.LogError("generates captcha failed: " + err.Error())
		c.Status(http.StatusInternalServerError)
		return
	}

	session := util.GetSession(c)
	workspaceSession := util.GetWorkspaceSession(session)
	workspaceSession.Captcha = img.Text
	if err = session.Save(c); err != nil {
		logging.LogError("save session failed: " + err.Error())
		c.Status(http.StatusInternalServerError)
		return
	}

	if err = img.WriteImage(c.Writer); err != nil {
		logging.LogError("writes captcha image failed: " + err.Error())
		c.Status(http.StatusInternalServerError)
		return
	}
	c.Status(http.StatusOK)
}

func CheckReadonly(c *gin.Context) {
	if util.ReadOnly || IsReadOnlyRoleContext(c) {
		result := util.NewResult()
		result.Code = -1
		result.Msg = Conf.Language(34)
		result.Data = map[string]any{"closeTimeout": 5000}
		c.JSON(http.StatusOK, result)
		c.Abort()
		return
	}
}

func CheckAuth(c *gin.Context) {
	// 已通过 JWT 认证
	if role := GetGinContextRole(c); IsValidRole(role, []Role{
		RoleAdministrator,
		RoleEditor,
		RoleReader,
	}) {
		c.Next()
		return
	}

	// 通过 API token (header: Authorization)
	if authHeader := c.GetHeader("Authorization"); "" != authHeader {
		var token string
		if after, ok := strings.CutPrefix(authHeader, "Token "); ok {
			token = after
		} else if after, ok := strings.CutPrefix(authHeader, "token "); ok {
			token = after
		} else if after, ok := strings.CutPrefix(authHeader, "Bearer "); ok {
			token = after
		} else if after, ok := strings.CutPrefix(authHeader, "bearer "); ok {
			token = after
		}

		if authByAPIToken(c, "header: Authorization", token) {
			return
		}
	}

	// 通过 API token (query-params: token)
	if authByAPIToken(c, "query: token", c.Query("token")) {
		return
	}

	//logging.LogInfof("check auth for [%s]", c.Request.RequestURI)
	localhost := IsLocalRequest(c)

	// 未设置锁屏密码
	if !IsAccessAuthRequired() {
		// Skip the empty access authorization code check https://github.com/siyuan-note/siyuan/issues/9709
		if util.SiYuanAccessAuthCodeBypass {
			c.Set(RoleContextKey, RoleAdministrator)
			c.Next()
			return
		}

		// Authenticate requests with the Origin header other than 127.0.0.1 https://github.com/siyuan-note/siyuan/issues/9180
		clientIP := c.ClientIP()
		host := c.Request.Host
		origin := c.GetHeader("Origin")
		forwardedHost := c.GetHeader("X-Forwarded-Host")
		if !localhost ||
			("" != clientIP && !util.IsLocalHostname(clientIP)) ||
			("" != host && !util.IsLocalHost(host)) ||
			("" != origin && !util.IsLocalOrigin(origin)) ||
			("" != forwardedHost && !util.IsLocalHost(forwardedHost)) {
			c.JSON(http.StatusUnauthorized, map[string]any{"code": -1, "msg": "Auth failed: for security reasons, please set [Lock screen password] when using non-127.0.0.1 access\n\n为安全起见，使用非 127.0.0.1 访问时请设置 [锁屏密码]"})
			c.Abort()
			return
		}

		c.Set(RoleContextKey, RoleAdministrator)
		c.Next()
		return
	}

	// 放过 /appearance/ 等（不要扩大到 /stage/ 否则鉴权会有问题）
	if strings.HasPrefix(c.Request.RequestURI, "/appearance/") ||
		strings.HasPrefix(c.Request.RequestURI, "/stage/build/export/") ||
		strings.HasPrefix(c.Request.RequestURI, "/stage/protyle/") {
		c.Next()
		return
	}

	// 放过来自本机的某些请求
	if localhost {
		if strings.HasPrefix(c.Request.RequestURI, "/assets/") || strings.HasPrefix(c.Request.RequestURI, "/export/") {
			c.Set(RoleContextKey, RoleAdministrator)
			c.Next()
			return
		}
		if strings.HasPrefix(c.Request.RequestURI, "/api/system/exit") ||
			strings.HasPrefix(c.Request.RequestURI, "/api/system/uiproc") {
			c.Set(RoleContextKey, RoleAdministrator)
			c.Next()
			return
		}
		if strings.HasPrefix(c.Request.RequestURI, "/api/system/getNetwork") || strings.HasPrefix(c.Request.RequestURI, "/api/system/getWorkspaceInfo") {
			c.Set(RoleContextKey, RoleAdministrator)
			c.Next()
			return
		}
		if strings.HasPrefix(c.Request.RequestURI, "/api/sync/performSync") {
			if util.IsMobileContainer() {
				c.Set(RoleContextKey, RoleAdministrator)
				c.Next()
				return
			}
		}
	}

	// 通过 Cookie
	session := util.GetSession(c)
	workspaceSession := util.GetWorkspaceSession(session)
	if IsWorkspaceSessionAuthenticated(workspaceSession) {
		// 校验 Origin 防止跨站请求伪造 https://github.com/siyuan-note/siyuan/security/advisories/GHSA-hhm2-g993-p656
		if !util.IsSessionOriginAllowed(c.GetHeader("Origin"), c.Request.Host) {
			logging.LogWarnf("invalid Origin [%s] for session auth [ip=%s]", c.GetHeader("Origin"), c.ClientIP())
			c.JSON(http.StatusUnauthorized, map[string]any{"code": -1, "msg": "Auth failed: invalid Origin"})
			c.Abort()
			return
		}
		c.Set(RoleContextKey, RoleAdministrator)
		c.Next()
		return
	}

	// 通过 BasicAuth (header: Authorization)
	if Conf.AccessAuthCode != "" {
		if username, password, ok := c.Request.BasicAuth(); ok {
			// 使用锁屏密码作为密码
			ip := c.ClientIP()
			if retryAfter := util.AuthThrottleCheck(ip); 0 < retryAfter {
				// 锁定期间持续记录失败，防止暴力破解 https://github.com/siyuan-note/siyuan/security/advisories/GHSA-w3xh-mmmh-r54v
				util.AuthThrottleFail(ip)
				c.Header("Retry-After", strconv.Itoa(retryAfter))
				c.JSON(http.StatusTooManyRequests, map[string]any{"code": -1, "msg": Conf.Language(354)})
				c.Abort()
				return
			}
			if util.WorkspaceName == username && util.AuthCodeEquals(Conf.AccessAuthCode, password) {
				util.AuthThrottleReset(ip)
				c.Set(RoleContextKey, RoleAdministrator)
				c.Next()
				return
			}
			logging.LogWarnf("invalid auth code [ip=%s]", ip)
			util.AuthThrottleFail(ip)
		}
	}

	// WebDAV BasicAuth Authenticate
	if strings.HasPrefix(c.Request.RequestURI, "/webdav") ||
		strings.HasPrefix(c.Request.RequestURI, "/caldav") ||
		strings.HasPrefix(c.Request.RequestURI, "/carddav") {
		c.Header(BasicAuthHeaderKey, BasicAuthHeaderValue)
		c.AbortWithStatus(http.StatusUnauthorized)
		return
	}

	// 跳过访问授权页
	if "/check-auth" == c.Request.URL.Path {
		c.Next()
		return
	}

	if !IsWorkspaceSessionAuthenticated(workspaceSession) {
		userAgentHeader := c.GetHeader("User-Agent")
		if strings.HasPrefix(userAgentHeader, "SiYuan/") || strings.HasPrefix(userAgentHeader, "Mozilla/") {
			if "GET" != c.Request.Method || c.IsWebsocket() {
				c.JSON(http.StatusUnauthorized, map[string]any{"code": -1, "msg": Conf.Language(156)})
				c.Abort()
				return
			}

			location := url.URL{}
			queryParams := url.Values{}
			queryParams.Set("to", c.Request.URL.String())
			location.RawQuery = queryParams.Encode()
			location.Path = "/check-auth"

			c.Redirect(http.StatusFound, location.String())
			c.Abort()
			return
		}

		c.JSON(http.StatusUnauthorized, map[string]any{"code": -1, "msg": "Auth failed [session]"})
		c.Abort()
		return
	}

	c.Set(RoleContextKey, RoleAdministrator)
	c.Next()
}

// authByAPIToken 校验 API token，成功时赋予管理员角色并返回 true；
// 校验失败或触发限流时直接结束请求并返回 true，token 为空时不处理并返回 false。
func authByAPIToken(c *gin.Context, source, token string) (handled bool) {
	if "" == token {
		return
	}

	ip := c.ClientIP()
	if retryAfter := util.AuthThrottleCheck(ip); 0 < retryAfter {
		// 锁定期间持续记录失败，防止暴力破解 https://github.com/siyuan-note/siyuan/security/advisories/GHSA-m6w6-p7pc-fpg2
		util.AuthThrottleFail(ip)
		c.Header("Retry-After", strconv.Itoa(retryAfter))
		c.JSON(http.StatusTooManyRequests, map[string]any{"code": -1, "msg": Conf.Language(354)})
		c.Abort()
		return true
	}
	if util.AuthCodeEquals(Conf.Api.Token, token) {
		util.AuthThrottleReset(ip)
		c.Set(RoleContextKey, RoleAdministrator)
		c.Next()
		return true
	}
	logging.LogWarnf("invalid api token [ip=%s]", ip)
	util.AuthThrottleFail(ip)
	c.JSON(http.StatusUnauthorized, map[string]any{"code": -1, "msg": "Auth failed [" + source + "]"})
	c.Abort()
	return true
}

// IsLocalRequest 判断请求是否由本机客户端直接发起或经可信本机代理转发。
func IsLocalRequest(c *gin.Context) bool {
	// 仅当直接连接和可信代理解析出的原始客户端均为环回地址时，才视为本机请求。
	return util.IsLocalHost(c.Request.RemoteAddr) && util.IsLocalHostname(c.ClientIP())
}

func CheckAdminRole(c *gin.Context) {
	if IsAdminRoleContext(c) {
		c.Next()
	} else {
		c.AbortWithStatus(http.StatusForbidden)
	}
}

func CheckEditRole(c *gin.Context) {
	if IsValidRole(GetGinContextRole(c), []Role{
		RoleAdministrator,
		RoleEditor,
	}) {
		c.Next()
	} else {
		c.AbortWithStatus(http.StatusForbidden)
	}
}

func CheckReadRole(c *gin.Context) {
	if IsValidRole(GetGinContextRole(c), []Role{
		RoleAdministrator,
		RoleEditor,
		RoleReader,
	}) {
		c.Next()
	} else {
		c.AbortWithStatus(http.StatusForbidden)
	}
}

var timingAPIs = map[string]int{
	"/api/search/fullTextSearchBlock": 200, // Monitor the search performance and suggest solutions https://github.com/siyuan-note/siyuan/issues/7873
}

func Timing(c *gin.Context) {
	p := c.Request.URL.Path
	tip, ok := timingAPIs[p]
	if !ok {
		c.Next()
		return
	}

	timing := 15 * 1000
	if timingEnv := os.Getenv("SIYUAN_PERFORMANCE_TIMING"); "" != timingEnv {
		val, err := strconv.Atoi(timingEnv)
		if err == nil {
			timing = val
		}
	}

	now := time.Now().UnixMilli()
	c.Next()
	elapsed := int(time.Now().UnixMilli() - now)
	if timing < elapsed {
		logging.LogWarnf("[%s] elapsed [%dms]", p, elapsed)
		util.PushMsg(Conf.Language(tip), 7000)
	}
}

func Recover(c *gin.Context) {
	defer logging.Recover()
	c.Next()
}

// Activity 记录用户写操作时间，用于 AutoFixIndex 的空闲判断。
// 只认会产生数据变更的事务类请求（/api/transactions*），因为只有写操作才会引入索引不一致；
// 读操作和前端定时轮询（如 /api/ai/embeddingStat）不计入，避免 SiYuan 开着却不操作时被判为活跃。
func Activity(c *gin.Context) {
	if strings.HasPrefix(c.Request.URL.Path, "/api/transactions") {
		util.RefreshActivity()
	}
	c.Next()
}

var (
	requestingLock = sync.Mutex{}
	requesting     = map[string]*sync.Mutex{}
)

func ControlConcurrency(c *gin.Context) {
	if websocket.IsWebSocketUpgrade(c.Request) {
		c.Next()
		return
	}

	reqPath := c.Request.URL.Path

	// Improve the concurrency of the kernel data reading interfaces https://github.com/siyuan-note/siyuan/issues/10149
	if strings.HasPrefix(reqPath, "/stage/") ||
		strings.HasPrefix(reqPath, "/assets/") ||
		strings.HasPrefix(reqPath, "/emojis/") ||
		strings.HasPrefix(reqPath, "/plugins/") ||
		strings.HasPrefix(reqPath, "/public/") ||
		strings.HasPrefix(reqPath, "/snippets/") ||
		strings.HasPrefix(reqPath, "/templates/") ||
		strings.HasPrefix(reqPath, "/widgets/") ||
		strings.HasPrefix(reqPath, "/appearance/") ||
		strings.HasPrefix(reqPath, "/export/") ||
		strings.HasPrefix(reqPath, "/history/") ||
		strings.HasPrefix(reqPath, "/api/query/") ||
		strings.HasPrefix(reqPath, "/api/search/") ||
		strings.HasPrefix(reqPath, "/api/network/") ||
		strings.HasPrefix(reqPath, "/api/broadcast/") ||
		strings.HasPrefix(reqPath, "/api/ai/") ||
		strings.HasPrefix(reqPath, "/es/") ||
		strings.HasPrefix(reqPath, "/mcp") {
		c.Next()
		return
	}

	parts := strings.Split(reqPath, "/")
	function := parts[len(parts)-1]
	if strings.HasPrefix(function, "get") ||
		strings.HasPrefix(function, "list") ||
		strings.HasPrefix(function, "search") ||
		strings.HasPrefix(function, "render") ||
		strings.HasPrefix(function, "ls") {
		c.Next()
		return
	}

	// 仅对已注册的静态 /api/ 路径做并发控制：路由表有限，requesting map 不会无界增长；
	// 未知路径与带参数通配路由直接放行 https://github.com/siyuan-note/siyuan/security/advisories/GHSA-p59v-3q54-qq55
	if !strings.HasPrefix(reqPath, "/api/") ||
		"" == c.FullPath() ||
		strings.ContainsAny(c.FullPath(), ":*") {
		c.Next()
		return
	}

	requestingLock.Lock()
	mutex := requesting[reqPath]
	if nil == mutex {
		mutex = &sync.Mutex{}
		requesting[reqPath] = mutex
	}
	requestingLock.Unlock()

	mutex.Lock()
	defer mutex.Unlock()
	c.Next()
}
