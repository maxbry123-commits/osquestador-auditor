import {Tab} from "../layout/Tab";
import {Editor} from "./index";
import {Wnd} from "../layout/Wnd";
import {getInstanceById, getWndByLayout, newModelByInitData, pdfIsLoading, setPanelFocus} from "../layout/util";
import {getDockByType} from "../layout/tabUtil";
import {getAllModels, getAllTabs} from "../layout/getAll";
import {highlightById, scrollCenter} from "../util/highlightById";
import {getAssetExtension, getDisplayName, getDocDisplayName, isEncryptedBox, useShell} from "../util/pathName";
import {Constants} from "../constants";
import {Files} from "../layout/dock/Files";
import {fetchPost, fetchSyncPost} from "../util/fetch";
import {focusBlock, focusByOffset, focusByRange} from "../protyle/util/selection";
import {onGet} from "../protyle/util/onGet";
/// #if !BROWSER
import {ipcRenderer} from "electron";
/// #endif
import {pushBack} from "../util/backForward";
import {Asset} from "../asset";
import {Layout} from "../layout";
import {
    hasClosestBlock,
    hasClosestByAttribute,
    hasClosestByClassName,
    isInEmbedBlock,
} from "../protyle/util/hasClosest";
import {zoomOut} from "../menus/protyle";
import {countBlockWord, countSelectWord} from "../layout/status";
import {showMessage} from "../dialog/message";
import {objEquals} from "../util/functions";
import {resize} from "../protyle/util/resize";
import {Search} from "../search";
import type {App} from "../index";
import {preventScroll} from "../protyle/scroll/preventScroll";
import {clearOBG} from "../layout/dock/util";
import {Model} from "../layout/Model";
import {hideElements} from "../protyle/ui/hideElements";
import {isBrowserRenderableImagePath} from "../util/imageURL";
import {forEachPluginSubscriber} from "../plugin/EventBusCore";

const isSameCustomTab = (type: string, data: any, options: IOpenFileOptions) => {
    if (!options.custom || (options.custom.id && options.custom.id !== type)) {
        return false;
    }
    if (type === "siyuan-database-row") {
        return data?.avID === options.custom.data?.avID && data?.itemID === options.custom.data?.itemID;
    }
    return objEquals(data, options.custom.data);
};

export const openFileById = async (options: {
    app: App,
    id: string,
    notebookId?: string,
    position?: string,
    mode?: TEditorMode,
    action?: TProtyleAction[]
    keepCursor?: boolean
    zoomIn?: boolean
    removeCurrentTab?: boolean
    openNewTab?: boolean
    keepAVPanel?: boolean
    afterOpen?: (model: Model) => void,
    scrollPosition?: ScrollLogicalPosition
    retryOnUnavailable?: number
}): Promise<Tab | void> => {
    const response = await fetchSyncPost("/api/block/getBlockInfo", {id: options.id, notebook: options.notebookId});
    if (response.code === -1) {
        const retryOnUnavailable = options.retryOnUnavailable || 0;
        if (retryOnUnavailable > 0) {
            await new Promise(resolve => window.setTimeout(resolve, Constants.TIMEOUT_TRANSITION));
            return openFileById({
                ...options,
                retryOnUnavailable: retryOnUnavailable - 1,
            });
        }
        return;
    }
    if (response.code === 3) {
        showMessage(response.msg);
        return;
    }
    const zoomIn = options.zoomIn === true && options.id !== response.data.rootID;

    return openFile({
        app: options.app,
        fileName: response.data.rootTitle,
        rootTitleEmpty: response.data.rootTitleEmpty,
        rootIcon: response.data.rootIcon,
        rootID: response.data.rootID,
        id: options.id,
        notebookId: options.notebookId,
        position: options.position,
        mode: options.mode,
        action: options.action,
        zoomIn,
        keepCursor: options.keepCursor,
        removeCurrentTab: options.removeCurrentTab,
        afterOpen: options.afterOpen,
        openNewTab: options.openNewTab,
        keepAVPanel: options.keepAVPanel,
        scrollPosition: options.scrollPosition,
    });
};

const openAssetWithOptions = (
    app: App,
    assetPath: string,
    page: number | string,
    options: {
        position?: string,
        keepCursor?: boolean,
    } = {},
) => {
    const suffix = getAssetExtension(assetPath).toLowerCase();
    if (!Constants.SIYUAN_ASSETS_EXTS.includes(suffix) || !isBrowserRenderableImagePath(assetPath)) {
        return;
    }
    openFile({
        app,
        assetPath,
        page,
        position: options.position,
        keepCursor: options.keepCursor,
        removeCurrentTab: true
    });
};

export const openAsset = (app: App, assetPath: string, page: number | string, position?: string) => {
    openAssetWithOptions(app, assetPath, page, {position});
};

export const openAssetInBackground = (app: App, assetPath: string, page: number | string) => {
    openAssetWithOptions(app, assetPath, page, {keepCursor: true});
};

export const openFile = async (options: IOpenFileOptions) => {
    if (typeof options.removeCurrentTab === "undefined") {
        options.removeCurrentTab = true;
    }
    // https://github.com/siyuan-note/siyuan/issues/10168
    if (!options.keepAVPanel) {
        document.querySelectorAll(".av__panel, .av__mask").forEach(item => {
            item.remove();
        });
    }
    // 打开 PDF 时移除文档光标
    if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
    }
    const allModels = getAllModels();
    // 文档已打开
    if (options.assetPath) {
        clearOBG();
        const asset = allModels.asset.find((item) => {
            if (item.path == options.assetPath) {
                if (!pdfIsLoading(item.parent.parent.element)) {
                    if (!options.keepCursor) {
                        item.parent.parent.switchTab(item.parent.headElement);
                        item.parent.parent.showHeading();
                    }
                    item.goToPage(options.page);
                }
                return true;
            }
        });
        if (asset) {
            if (options.afterOpen) {
                options.afterOpen(asset);
            }
            return asset.parent;
        }
    } else if (options.custom) {
        clearOBG();
        const custom = !options.openNewTab && allModels.custom.find((item) => {
            if (isSameCustomTab(item.type, item.data, options)) {
                if (!pdfIsLoading(item.parent.parent.element)) {
                    item.parent.parent.switchTab(item.parent.headElement);
                    item.parent.parent.showHeading();
                }
                return true;
            }
        });
        if (custom) {
            if (options.afterOpen) {
                options.afterOpen(custom);
            }
            return custom.parent;
        }
        const hasModel = !options.openNewTab && getUnInitTab(options);
        if (hasModel) {
            if (options.afterOpen) {
                options.afterOpen(hasModel.model);
            }
            return hasModel;
        }
    } else if (options.searchData) {
        clearOBG();
        const search = allModels.search.find((item) => {
            if (objEquals(item.config, options.searchData)) {
                if (!pdfIsLoading(item.parent.parent.element)) {
                    item.parent.parent.switchTab(item.parent.headElement);
                    item.parent.parent.showHeading();
                }
                return true;
            }
        });
        if (search) {
            return search.parent;
        }
    } else if (!options.position && !options.openNewTab) {
        let editor: Editor;
        let activeEditor: Editor;
        allModels.editor.find((item) => {
            if (item.editor.protyle.block.rootID === options.rootID) {
                if (hasClosestByClassName(item.element, "layout__wnd--active")) {
                    activeEditor = item;
                }
                if (!editor || item.headElement.getAttribute("data-activetime") > editor.headElement.getAttribute("data-activetime")) {
                    // https://github.com/siyuan-note/siyuan/issues/11981#issuecomment-2351939812
                    editor = item;
                }
            }
            if (activeEditor) {
                return true;
            }
        });
        if (activeEditor) {
            editor = activeEditor;
        }
        if (editor) {
            if (!pdfIsLoading(editor.parent.parent.element)) {
                switchEditor(editor, options, allModels);
            }
            if (options.afterOpen) {
                options.afterOpen(editor);
            }
            return editor.parent;
        }
        // 没有初始化的页签无法检测到
        const hasEditor = getUnInitTab(options);
        if (hasEditor) {
            if (options.afterOpen) {
                options.afterOpen(hasEditor.model);
            }
            return hasEditor;
        }
    }

    /// #if !BROWSER
    // https://github.com/siyuan-note/siyuan/issues/7491
    if (!options.position || (options.position === "right" && options.assetPath)) {
        let hasMatch = false;
        const optionsClone: IObject = {};
        Object.keys(options).forEach((key: keyof IOpenFileOptions) => {
            if (key !== "app" && options[key] && typeof options[key] !== "function") {
                optionsClone[key] = JSON.parse(JSON.stringify(options[key]));
            }
        });
        try {
            hasMatch = await ipcRenderer.invoke(Constants.SIYUAN_GET, {
                cmd: Constants.SIYUAN_OPEN_FILE,
                options: JSON.stringify(optionsClone),
                port: location.port,
            });
        } catch (e) {
            console.warn("Check opened file window error:", e);
        }
        if (hasMatch) {
            if (options.afterOpen) {
                options.afterOpen();
            }
            return;
        }
    }
    /// #endif

    let wnd: Wnd = undefined;
    // 获取光标所在 tab
    const element = document.querySelector(".layout__wnd--active");
    if (element) {
        wnd = getInstanceById(element.getAttribute("data-id")) as Wnd;
    }
    if (!wnd) {
        // 中心 tab
        wnd = getWndByLayout(window.siyuan.layout.centerLayout);
    }
    if (wnd) {
        let createdTab: Tab;
        if ((options.position === "right" || options.position === "bottom") && wnd.children[0].headElement) {
            const direction = options.position === "right" ? "lr" : "tb";
            let targetWnd: Wnd;
            if (wnd.parent.children.length > 1 && wnd.parent instanceof Layout && wnd.parent.direction === direction) {
                wnd.parent.children.find((item, index) => {
                    if (item.id === wnd.id) {
                        let nextWnd = wnd.parent.children[index + 1];
                        if (!nextWnd) {
                            // wnd 为右侧时，应设置其为目标
                            nextWnd = wnd;
                        }
                        while (nextWnd instanceof Layout) {
                            nextWnd = nextWnd.children[0];
                        }
                        targetWnd = nextWnd;
                        return true;
                    }
                });
            }
            if (targetWnd) {
                if (pdfIsLoading(targetWnd.element)) {
                    if (options.afterOpen) {
                        options.afterOpen();
                    }
                    return;
                }
                // 在右侧/下侧打开已有页签将进行页签切换 https://github.com/siyuan-note/siyuan/issues/5366
                let hasEditor = !options.openNewTab && targetWnd.children.find(item => {
                    if (item.model && item.model instanceof Editor && item.model.editor.protyle.block.rootID === options.rootID) {
                        switchEditor(item.model, options, allModels);
                        return true;
                    }
                });
                if (!hasEditor) {
                    hasEditor = !options.openNewTab && getUnInitTab(options);
                    createdTab = hasEditor;
                }
                if (!hasEditor) {
                    createdTab = newTab(options);
                    targetWnd.addTab(createdTab);
                }
            } else {
                createdTab = newTab(options);
                wnd.split(direction).addTab(createdTab);
            }
            wnd.showHeading();
            if (options.afterOpen) {
                options.afterOpen(createdTab ? createdTab.model : undefined);
            }
            return createdTab;
        }
        if (pdfIsLoading(wnd.element)) {
            if (options.afterOpen) {
                options.afterOpen();
            }
            return;
        }
        if (options.keepCursor && wnd.children[0].headElement) {
            createdTab = newTab(options);
            if (options.id) {
                createdTab.headElement.setAttribute("keep-cursor", options.id);
            }
            wnd.addTab(createdTab, options.keepCursor);
        } else if (window.siyuan.config.fileTree.openFilesUseCurrentTab) {
            let unUpdateTab: Tab;
            // 不能 reverse, 找到也不能提前退出循环，否则 https://github.com/siyuan-note/siyuan/issues/3271
            wnd.children.find((item) => {
                if (item.headElement && item.headElement.classList.contains("item--unupdate") && !item.headElement.classList.contains("item--pin")) {
                    unUpdateTab = item;
                    if (item.headElement.classList.contains("item--focus")) {
                        // https://ld246.com/article/1658979494658
                        return true;
                    }
                }
            });
            createdTab = newTab(options);
            wnd.addTab(createdTab);
            if (unUpdateTab && options.removeCurrentTab) {
                wnd.removeTab(unUpdateTab.id, false, false);
            }
        } else {
            createdTab = newTab(options);
            wnd.addTab(createdTab);
        }
        wnd.showHeading();
        if (options.afterOpen) {
            options.afterOpen(createdTab.model);
        }
        return createdTab;
    }
};

// 没有初始化的页签无法检测到
const getUnInitTab = (options: IOpenFileOptions) => {
    return getAllTabs().find(item => {
        const initData = item.headElement?.getAttribute("data-initdata");
        if (initData) {
            const initObj = JSON.parse(initData);
            if (initObj.instance === "Editor" &&
                (initObj.rootId === options.rootID || initObj.blockId === options.rootID)) {
                initObj.blockId = options.id;
                initObj.notebookId = options.notebookId;
                initObj.mode = options.mode;
                if (options.zoomIn) {
                    initObj.action = [Constants.CB_GET_ALL, Constants.CB_GET_FOCUS];
                } else {
                    initObj.action = options.action;
                }
                initObj.scrollPosition = options.scrollPosition;
                item.headElement.setAttribute("data-initdata", JSON.stringify(initObj));
                item.parent.switchTab(item.headElement);
                return true;
            } else if (initObj.instance === "Custom" && isSameCustomTab(initObj.customModelType, initObj.customModelData, options)) {
                item.parent.switchTab(item.headElement);
                return true;
            }
        }
    });
};

const switchEditor = (editor: Editor, options: IOpenFileOptions, allModels: IModels) => {
    if (options.keepCursor) {
        editor.parent.headElement.setAttribute("keep-cursor", options.id);
        return true;
    }
    editor.parent.parent.switchTab(editor.parent.headElement);
    editor.parent.parent.showHeading();
    if (options.mode !== "preview" && !editor.editor.protyle.preview.element.classList.contains("fn__none")) {
        return true;
    }
    if (options.zoomIn) {
        zoomOut({protyle: editor.editor.protyle, id: options.id});
        return true;
    }
    let nodeElement: Element;
    Array.from(editor.editor.protyle.wysiwyg.element.querySelectorAll(`[data-node-id="${options.id}"]`)).find(item => {
        if (!isInEmbedBlock(item)) {
            nodeElement = item;
            return true;
        }
    });
    if ((!nodeElement || nodeElement?.clientHeight === 0) && options.id !== options.rootID) {
        const getDocParam: IObject = {
            id: options.id,
            mode: (options.action && options.action.includes(Constants.CB_GET_CONTEXT)) ? 3 : 0,
            size: window.siyuan.config.editor.dynamicLoadBlocks,
        };
        if (isEncryptedBox(editor.editor.protyle.notebookId)) {
            getDocParam.notebook = editor.editor.protyle.notebookId;
        }
        fetchPost("/api/filetree/getDoc", getDocParam, getResponse => {
            onGet({
                data: getResponse,
                protyle: editor.editor.protyle,
                action: options.action,
                scrollPosition: options.scrollPosition
            });
            // 大纲点击折叠标题下的内容时，需更新反链面板
            updateBacklinkGraph(allModels, editor.editor.protyle);
        });
    } else {
        // 点击大纲产生滚动时会动态加载内容，最终导致定位不准确
        preventScroll(editor.editor.protyle);
        editor.editor.protyle.observerLoad?.disconnect();
        if (options.action?.includes(Constants.CB_GET_HL)) {
            highlightById(editor.editor.protyle, options.id, "start");
        }
        if (options.action?.includes(Constants.CB_GET_FOCUS)) {
            if (nodeElement) {
                let scrollTop: number;
                if (options.action.includes(Constants.CB_GET_SEARCH)) {
                    const scrollAttr = window.siyuan.storage[Constants.LOCAL_FILEPOSITION][editor.editor.protyle.block.rootID];
                    focusByOffset(nodeElement, scrollAttr.focusStart, scrollAttr.focusEnd);
                    scrollTop = scrollAttr.scrollTop;
                } else {
                    const newRange = focusBlock(nodeElement, undefined, !options.action?.includes(Constants.CB_GET_OUTLINE));
                    if (newRange) {
                        editor.editor.protyle.toolbar.range = newRange;
                    }
                }
                if (typeof scrollTop === "number") {
                    editor.editor.protyle.contentElement.scrollTop = scrollTop;
                } else {
                    scrollCenter(editor.editor.protyle, (editor.editor.protyle.disabled || options.scrollPosition) ? nodeElement : null, options.scrollPosition);
                }
                const userScrollAbort = new AbortController();
                const observerLoad = new ResizeObserver(() => {
                    if (document.contains(nodeElement)) {
                        if (typeof scrollTop === "number") {
                            editor.editor.protyle.contentElement.scrollTop = scrollTop;
                        } else {
                            scrollCenter(editor.editor.protyle, (editor.editor.protyle.disabled || options.scrollPosition) ? nodeElement : null, options.scrollPosition);
                        }
                    }
                });
                const stopObserve = () => {
                    userScrollAbort.abort();
                    observerLoad.disconnect();
                };
                const onUserScroll = () => stopObserve();
                editor.editor.protyle.contentElement.addEventListener("wheel", onUserScroll, {
                    capture: true,
                    passive: true,
                    signal: userScrollAbort.signal
                });
                editor.editor.protyle.contentElement.addEventListener("touchstart", onUserScroll, {
                    capture: true,
                    passive: true,
                    signal: userScrollAbort.signal
                });
                editor.editor.protyle.contentElement.addEventListener("touchmove", onUserScroll, {
                    capture: true,
                    passive: true,
                    signal: userScrollAbort.signal
                });
                editor.editor.protyle.contentElement.addEventListener("keydown", (event: KeyboardEvent) => {
                    if (["PageUp", "PageDown", "Home", "End", "ArrowUp", "ArrowDown", " "].includes(event.key)) {
                        stopObserve();
                    }
                }, {capture: true, signal: userScrollAbort.signal});
                editor.editor.protyle.observerLoad = observerLoad;
                setTimeout(() => {
                    stopObserve();
                }, 1000 * 3);
                observerLoad.observe(editor.editor.protyle.wysiwyg.element);
            } else if (editor.editor.protyle.block.rootID === options.id) {
                // 由于 https://github.com/siyuan-note/siyuan/issues/5420，移除定位
            } else if (editor.editor.protyle.toolbar.range) {
                nodeElement = hasClosestBlock(editor.editor.protyle.toolbar.range.startContainer) as Element;
                focusByRange(editor.editor.protyle.toolbar.range);
                scrollCenter(editor.editor.protyle, undefined, options.scrollPosition);
            }
        }
        pushBack(editor.editor.protyle, editor.editor.protyle.toolbar.range);
    }
    // https://github.com/siyuan-note/siyuan/issues/16445
    if (options.action?.includes(Constants.CB_GET_OUTLINE)) {
        hideElements(["select"], editor.editor.protyle);
    }
};

const newTab = (options: IOpenFileOptions) => {
    let tab: Tab;
    if (options.assetPath) {
        const suffix = getAssetExtension(options.assetPath).toLowerCase();
        if (Constants.SIYUAN_ASSETS_EXTS.includes(suffix) &&
            isBrowserRenderableImagePath(options.assetPath)) {
            let icon = "iconPDF";
            if (Constants.SIYUAN_ASSETS_IMAGE.includes(suffix)) {
                icon = "iconImage";
            } else if (Constants.SIYUAN_ASSETS_AUDIO.includes(suffix)) {
                icon = "iconRecord";
            } else if (Constants.SIYUAN_ASSETS_VIDEO.includes(suffix)) {
                icon = "iconVideo";
            }
            tab = new Tab({
                icon,
                title: getDisplayName(options.assetPath),
                callback(tab) {
                    tab.addModel(new Asset({
                        app: options.app,
                        tab,
                        path: options.assetPath,
                        page: options.page,
                    }));
                    if (!options.keepCursor) {
                        setPanelFocus(tab.panelElement.parentElement.parentElement);
                    }
                }
            });
        }
    } else if (options.custom) {
        tab = new Tab({
            icon: options.custom.icon,
            title: options.custom.title,
            callback(tab) {
                if (options.custom.id) {
                    const model = newModelByInitData(options.app, tab, {
                        instance: "Custom",
                        customModelType: options.custom.id,
                        customModelData: options.custom.data,
                    });
                    if (model) {
                        tab.addModel(model);
                    }
                } else {
                    // plugin 0.8.3 历史兼容
                    console.warn("0.8.3 将移除 custom.fn 参数，请参照 https://github.com/siyuan-note/plugin-sample/blob/91a716358941791b4269241f21db25fd22ae5ff5/src/index.ts 将其修改为 custom.id");
                    tab.addModel(options.custom.fn({
                        tab,
                        data: options.custom.data
                    }));
                }
                setPanelFocus(tab.panelElement.parentElement.parentElement);
            }
        });
    } else if (options.searchData) {
        tab = new Tab({
            icon: "iconSearch",
            title: window.siyuan.languages.search,
            callback(tab) {
                tab.addModel(new Search({
                    app: options.app,
                    tab,
                    config: options.searchData
                }));
                setPanelFocus(tab.panelElement.parentElement.parentElement);
            }
        });
    } else {
        tab = new Tab({
            title: getDocDisplayName(options.fileName, options.rootTitleEmpty),
            docIcon: options.rootIcon,
            callback(tab) {
                let editor;
                if (options.zoomIn) {
                    editor = new Editor({
                        app: options.app,
                        tab,
                        blockId: options.id,
                        rootId: options.rootID,
                        notebookId: options.notebookId,
                        action: [Constants.CB_GET_ALL, Constants.CB_GET_FOCUS],
                        scrollPosition: options.scrollPosition,
                    });
                } else {
                    editor = new Editor({
                        app: options.app,
                        tab,
                        blockId: options.id,
                        rootId: options.rootID,
                        notebookId: options.notebookId,
                        mode: options.mode,
                        action: options.action,
                        scrollPosition: options.scrollPosition,
                    });
                }
                tab.addModel(editor);
            }
        });
    }
    return tab;
};

export const updatePanelByEditor = (options: {
    protyle?: IProtyle,
    focus: boolean,
    pushBackStack: boolean,
    reload: boolean,
    resize: boolean
}) => {
    if (options.protyle && options.protyle.path) {
        // https://ld246.com/article/1637636106054/comment/1641485541929#comments
        if (options.protyle.element.classList.contains("fn__none") ||
            (!hasClosestByClassName(options.protyle.element, "layout__wnd--active") &&
                document.querySelector(".layout__wnd--active")  // https://github.com/siyuan-note/siyuan/issues/4414
            )
        ) {
            return;
        }
        if (options.resize) {
            resize(options.protyle);
        }
        if (options.focus) {
            if (options.protyle.toolbar.range) {
                focusByRange(options.protyle.toolbar.range);
                countSelectWord(options.protyle.toolbar.range, options.protyle.block.rootID);
                if (options.pushBackStack && options.protyle.preview.element.classList.contains("fn__none")) {
                    pushBack(options.protyle, options.protyle.toolbar.range);
                }
            } else {
                focusBlock(options.protyle.wysiwyg.element.firstElementChild);
                if (options.pushBackStack && options.protyle.preview.element.classList.contains("fn__none")) {
                    pushBack(options.protyle, undefined, options.protyle.wysiwyg.element.firstElementChild);
                }
                countBlockWord([], options.protyle.block.rootID);
            }
        }
        if (window.siyuan.config.fileTree.alwaysSelectOpenedFile && options.protyle) {
            const fileModel = getDockByType("file")?.data.file;
            if (fileModel instanceof Files) {
                const target = fileModel.element.querySelector(`li[data-path="${options.protyle.path}"]`);
                if (!target || (target && !target.classList.contains("b3-list-item--focus"))) {
                    fileModel.selectItem(options.protyle.notebookId, options.protyle.path);
                }
            }
        }
        forEachPluginSubscriber("switch-protyle", eventBus => {
            eventBus.emit("switch-protyle", {protyle: options.protyle});
        });
    }
    // 切换页签或关闭所有页签时，需更新对应的面板
    const models = getAllModels();
    updateOutline(models, options.protyle, options.reload);
    updateBacklinkGraph(models, options.protyle);
};

export const isCurrentEditor = (blockId: string) => {
    const activeElement = document.querySelector(".layout__wnd--active > .fn__flex > .layout-tab-bar > .item--focus");
    if (activeElement) {
        const tab = getInstanceById(activeElement.getAttribute("data-id"));
        if (tab instanceof Tab && tab.model instanceof Editor) {
            if (tab.model.editor.protyle.block.rootID === blockId ||
                tab.model.editor.protyle.block.parentID === blockId ||  // updateBacklinkGraph 时会传入 parentID
                tab.model.editor.protyle.block.id === blockId) {
                return true;
            }
        }
    }
    return false;
};

export const updateOutline = (models: IModels, protyle: IProtyle, reload = false) => {
    models.outline.find(item => {
        if (reload ||
            (item.type === "pin" &&
                (!protyle || item.blockId !== protyle.block?.rootID ||
                    item.isPreview === protyle.preview.element.classList.contains("fn__none"))
            )
        ) {
            let blockId = "";
            if (protyle && protyle.block) {
                blockId = protyle.block.rootID;
                if (!blockId && reload && item.type === "local") {
                    blockId = item.blockId;
                }
            }
            if (blockId === item.blockId && !reload && item.isPreview !== protyle.preview.element.classList.contains("fn__none")) {
                return;
            }

            const outlineParam: IObject = {
                id: blockId,
                preview: !protyle.preview.element.classList.contains("fn__none")
            };
            if (protyle && isEncryptedBox(protyle.notebookId)) {
                outlineParam.notebook = protyle.notebookId;
            }
            fetchPost("/api/outline/getDocOutline", outlineParam, response => {
                if (!reload && (!isCurrentEditor(blockId) || item.blockId === blockId) &&
                    item.isPreview !== protyle.preview.element.classList.contains("fn__none")) {
                    return;
                }
                item.isPreview = !protyle.preview.element.classList.contains("fn__none");
                item.update(response, blockId, protyle?.notebookId || "");
                if (protyle) {
                    item.updateDocTitle(protyle.background.ial, response.data?.length || 0);
                    if (getSelection().rangeCount > 0) {
                        const startContainer = getSelection().getRangeAt(0).startContainer;
                        if (protyle.wysiwyg.element.contains(startContainer)) {
                            const currentElement = hasClosestByAttribute(startContainer, "data-node-id", null);
                            if (currentElement) {
                                item.setCurrent(currentElement);
                            }
                        }
                    }
                } else {
                    item.updateDocTitle();
                }
            });
        }
    });
};

export const updateBacklinkGraph = (models: IModels, protyle: IProtyle) => {
    // https://ld246.com/article/1637636106054/comment/1641485541929#comments
    if (protyle && protyle.element.classList.contains("fn__none") ||
        (protyle && !hasClosestByClassName(protyle.element, "layout__wnd--active") &&
            document.querySelector(".layout__wnd--active")  // https://github.com/siyuan-note/siyuan/issues/4414
        )
    ) {
        return;
    }
    models.graph.forEach(item => {
        if (item.type !== "global" && (!protyle || item.blockId !== protyle.block?.id)) {
            if (item.type === "local" && item.rootId !== protyle?.block?.rootID) {
                return;
            }
            let blockId = "";
            if (protyle && protyle.block) {
                blockId = protyle.block.showAll ? protyle.block.id : protyle.block.parentID;
            }
            const notebookId = protyle?.notebookId || "";
            if (blockId === item.blockId && notebookId === item.notebookId) {
                return;
            }
            item.notebookId = notebookId;
            item.searchGraph({id: blockId});
        }
    });
    models.backlink.forEach(item => {
        if (item.type === "bottom") {
            if (!protyle || item.ownerProtyle !== protyle) {
                return;
            }
            const blockId = protyle.block.showAll ? protyle.block.id : (protyle.block.parentID || protyle.block.rootID);
            if (blockId === item.blockId) {
                return;
            }
            const backlinkKeyword = item.inputsElement[0].value;
            const backmentionKeyword = item.inputsElement[1].value;
            item.prepareForBlock(blockId, protyle.block.rootID);
            item.inputsElement[0].value = backlinkKeyword;
            item.inputsElement[1].value = backmentionKeyword;
            item.markDirty();
            item.refreshIfVisible(true);
            return;
        }
        if (item.type === "local" && item.rootId !== protyle?.block?.rootID) {
            return;
        }
        let blockId = "";
        if (protyle && protyle.block) {
            blockId = protyle.block.showAll ? protyle.block.id : protyle.block.parentID;
        }
        if (blockId === item.blockId) {
            return;
        }
        item.switchBlock(blockId, protyle?.block?.rootID || "", protyle?.notebookId || "");
    });
};

export const openBy = (url: string, type: "folder" | "app") => {
    /// #if !BROWSER
    if (url.startsWith("assets/")) {
        fetchPost("/api/asset/resolveAssetPath", {path: url.replace(/\.pdf\?page=\d{1,}$/, ".pdf")}, (response) => {
            if (type === "app") {
                useShell("openPath", response.data);
            } else if (type === "folder") {
                useShell("showItemInFolder", response.data);
            }
        });
        return;
    }
    let address = "";
    if ("windows" === window.siyuan.config.system.os) {
        // `file://` 协议兼容 Window 平台使用 `/` 作为目录分割线 https://github.com/siyuan-note/siyuan/issues/5681
        address = url.replace("file:///", "").replace("file://\\", "").replace("file://", "").replace(/\//g, "\\");
    } else {
        address = url.replace("file://", "");
    }

    // 拖入文件名包含 `)` 、`(` 的文件以 `file://` 插入后链接解析错误 https://github.com/siyuan-note/siyuan/issues/5786
    address = address.replace(/\\\)/g, ")").replace(/\\\(/g, "(");
    if (type === "app") {
        useShell("openPath", address);
    } else if (type === "folder") {
        if ("windows" === window.siyuan.config.system.os) {
            if (!address.startsWith("\\\\")) { // \\ 开头的路径是 Windows 网络共享路径 https://github.com/siyuan-note/siyuan/issues/5980
                // Windows 端打开本地文件所在位置失效 https://github.com/siyuan-note/siyuan/issues/5808
                address = address.replace(/\\\\/g, "\\");
            }
        }
        useShell("showItemInFolder", address);
    }
    /// #endif
};
