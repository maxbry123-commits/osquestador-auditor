import {Menu} from "../../../plugin/Menu";
import {transaction} from "../../wysiwyg/transaction";
import {updateAttrViewCellAnimation} from "./action";
import {isMobile} from "../../../util/functions";
import {Constants} from "../../../constants";
import {uploadFiles, uploadLocalFiles} from "../../upload";
import {getAssetExtension} from "../../../util/pathName";
import {openMenu} from "../../../menus/commonMenuItem";
import {MenuItem} from "../../../menus/Menu";
import {copyPNGByLink, exportAsset, writeAssetToClipboard} from "../../../menus/util";
import {setPosition} from "../../../util/setPosition";
import {getAVBatchEditMode, getAVBatchSourceValue} from "./batchValue";
import {previewAttrViewImages} from "../../preview/image";
import {genAVValueHTML} from "./attributeValue";
import {showMessage} from "../../../dialog/message";
import {hasClosestBlock} from "../../util/hasClosest";
import {genCellValueByElement, getTypeByCellElement, updateAttrViewCellInOtherElements} from "./cell";
import {writeText} from "../../util/compatibility";
import {escapeAriaLabel, escapeAttr, escapeHtml} from "../../../util/escape";
import {renameAsset} from "../../../editor/rename";
import * as dayjs from "dayjs";
import {getColId} from "./col";
import {getFieldIdByCellElement} from "./row";
import {getCompressURL, removeCompressURL} from "../../../util/image";
import {base64ToURL, showBase64ImageSizeLimit} from "../../upload/base64";
import {isBrowserRenderableImagePath} from "../../../util/imageURL";
import {genNetworkImageAssetValue} from "./assetValue";
import {getAssetUploadSuccesses} from "../../upload/uploadResult";

export const bindAssetEvent = (options: {
    protyle: IProtyle,
    menuElement: HTMLElement,
    cellElements: HTMLElement[],
    blockElement: Element
}) => {
    options.menuElement.querySelector("input").addEventListener("change", (event: InputEvent & {
        target: HTMLInputElement
    }) => {
        if (event.target.files.length === 0) {
            return;
        }
        uploadFiles(options.protyle, event.target.files, event.target, (res) => {
            const resData = JSON.parse(res);
            const value: IAVCellAssetValue[] = [];
            getAssetUploadSuccesses(resData.data).forEach((success) => {
                value.push({
                    name: success.name,
                    content: success.path,
                    type: Constants.SIYUAN_ASSETS_IMAGE.includes(getAssetExtension(success.path).toLowerCase()) ? "image" : "file"
                });
            });
            updateAssetCell({
                protyle: options.protyle,
                cellElements: options.cellElements,
                addValue: value,
                blockElement: options.blockElement
            });
        }, undefined, {source: "file-picker", target: "av-cell"});
    });
};

const getVisibleAssetValues = (cellElements: HTMLElement[]) => {
    const batchMode = getAVBatchEditMode(cellElements[0]);
    if (batchMode === "add") {
        return [];
    }
    if (batchMode === "remove") {
        const assets = new Map<string, IAVCellAssetValue>();
        cellElements.forEach(item => {
            const renderedValue = genCellValueByElement("mAsset", item);
            getAVBatchSourceValue(item, renderedValue).mAsset?.forEach(asset => {
                assets.set(`${asset.type}:${asset.content}:${asset.name}`, asset);
            });
        });
        return Array.from(assets.values());
    }
    return genCellValueByElement("mAsset", cellElements[0]).mAsset || [];
};

export const getAssetHTML = (cellElements: HTMLElement[]) => {
    let html = "";
    const batchMode = getAVBatchEditMode(cellElements[0]);
    getVisibleAssetValues(cellElements).forEach((item, index) => {
        let contentHTML;
        if (item.type === "image" && isBrowserRenderableImagePath(item.content)) {
            contentHTML = `<span data-type="openAssetItem" class="fn__flex-1 ariaLabel" aria-label="${escapeAriaLabel(item.content)}">
    <img style="max-height: 180px;max-width: 360px;border-radius: var(--b3-border-radius);margin: 4px 0;" src="${getCompressURL(encodeURI(item.content))}"/>
</span>`;
        } else {
            contentHTML = `<span data-type="openAssetItem" class="fn__ellipsis b3-menu__label ariaLabel" aria-label="${escapeAriaLabel(item.content)}" style="max-width: 360px">${escapeHtml(item.name || item.content)}</span>`;
        }

        html += `<button class="b3-menu__item" draggable="true" data-index="${index}" data-name="${escapeAttr(item.name)}" data-type="${item.type}" data-content="${escapeAttr(item.content)}">
<svg class="b3-menu__icon fn__grab"><use xlink:href="#iconDrag"></use></svg>
${contentHTML}
${batchMode === "replace" ? '<svg class="b3-menu__action" data-type="editAssetItem"><use xlink:href="#iconEdit"></use></svg>' : ""}
</button>`;
    });
    const ids: string[] = [];
    cellElements.forEach(item => {
        ids.push(item.dataset.id);
    });
    return `<div class="b3-menu__items" data-ids="${ids}">
    ${html}
    <button data-type="addAssetExist" class="b3-menu__item b3-menu__item--current">
        <svg class="b3-menu__icon"><use xlink:href="#iconImage"></use></svg>
        <span class="b3-menu__label">${window.siyuan.languages.assets}</span>
    </button>
    <button class="b3-menu__item">
        <svg class="b3-menu__icon"><use xlink:href="#iconDownload"></use></svg>
        <span class="b3-menu__label">${window.siyuan.languages.insertAsset}</span> 
        <input multiple class="b3-form__upload" type="file">
    </button>
    <button data-type="addAssetLink" data-asset-type="image" class="b3-menu__item">
        <svg class="b3-menu__icon"><use xlink:href="#iconImage"></use></svg>
        <span class="b3-menu__label">${window.siyuan.languages.insertImgURL}</span>
    </button>
    <button data-type="addAssetLink" data-asset-type="file" class="b3-menu__item">
        <svg class="b3-menu__icon"><use xlink:href="#iconLink"></use></svg>
        <span class="b3-menu__label">${window.siyuan.languages.link}</span>
    </button>
</div>`;
};

export const updateAssetCell = (options: {
    protyle: IProtyle,
    cellElements: HTMLElement[],
    replaceValue?: IAVCellAssetValue[],
    addValue?: IAVCellAssetValue[],
    updateValue?: { index: number, value: IAVCellAssetValue }
    removeIndex?: number,
    blockElement: Element
}) => {
    const viewType = options.blockElement.getAttribute("data-av-type") as TAVView;
    const colId = getColId(options.cellElements[0], viewType);
    const cellDoOperations: IOperation[] = [];
    const cellUndoOperations: IOperation[] = [];
    let mAssetValue: IAVCellAssetValue[];
    const batchMode = getAVBatchEditMode(options.cellElements[0]);
    const batchTarget = typeof options.removeIndex === "number" ?
        getVisibleAssetValues(options.cellElements)[options.removeIndex] : undefined;
    options.cellElements.forEach((item, elementIndex) => {
        const rowID = getFieldIdByCellElement(item, viewType);
        if (!options.blockElement.contains(item)) {
            if (viewType === "table") {
                item = options.cellElements[elementIndex] = (options.blockElement.querySelector(`.av__row[data-id="${rowID}"] .av__cell[data-col-id="${item.dataset.colId}"]`) ||
                    options.blockElement.querySelector(`.fn__flex-1[data-col-id="${item.dataset.colId}"]`)) as HTMLElement;
            } else {
                item = options.cellElements[elementIndex] = (options.blockElement.querySelector(`.av__gallery-item[data-id="${rowID}"] .av__cell[data-field-id="${item.dataset.fieldId}"]`)) as HTMLElement;
            }
        }
        const renderedValue = genCellValueByElement(getTypeByCellElement(item) || item.dataset.type as TAVCol, item);
        const cellValue = batchMode === "replace" ? renderedValue : getAVBatchSourceValue(item, renderedValue);
        const oldValue = JSON.parse(JSON.stringify(cellValue));
        if (batchMode === "add" && options.addValue?.length > 0) {
            const existing = new Set((cellValue.mAsset || []).map(asset =>
                `${asset.type}:${asset.content}:${asset.name}`));
            cellValue.mAsset = (cellValue.mAsset || []).concat(options.addValue.filter(asset =>
                !existing.has(`${asset.type}:${asset.content}:${asset.name}`)));
        } else if (batchMode === "remove" && batchTarget) {
            cellValue.mAsset = (cellValue.mAsset || []).filter(asset =>
                asset.type !== batchTarget.type || asset.content !== batchTarget.content ||
                asset.name !== batchTarget.name);
        } else if (elementIndex === 0) {
            if (typeof options.removeIndex === "number") {
                cellValue.mAsset.splice(options.removeIndex, 1);
            } else if (options.addValue?.length > 0) {
                cellValue.mAsset = cellValue.mAsset.concat(options.addValue);
            } else if (options.updateValue) {
                cellValue.mAsset.find((assetItem, index) => {
                    if (index === options.updateValue.index) {
                        assetItem.content = options.updateValue.value.content;
                        assetItem.type = options.updateValue.value.type;
                        assetItem.name = options.updateValue.value.name;
                        return true;
                    }
                });
            } else if (options.replaceValue?.length > 0) {
                cellValue.mAsset = options.replaceValue;
            }
            mAssetValue = cellValue.mAsset;
        } else {
            cellValue.mAsset = mAssetValue;
        }
        const avID = options.blockElement.getAttribute("data-av-id");
        cellDoOperations.push({
            action: "updateAttrViewCell",
            id: cellValue.id,
            keyID: colId,
            rowID,
            avID,
            data: cellValue
        });
        cellUndoOperations.push({
            action: "updateAttrViewCell",
            id: cellValue.id,
            keyID: colId,
            rowID,
            avID,
            data: oldValue
        });
        if (item.classList.contains("custom-attr__avvalue")) {
            item.innerHTML = genAVValueHTML(cellValue);
        } else {
            updateAttrViewCellAnimation(item, cellValue);
        }
        updateAttrViewCellInOtherElements(options.protyle, avID, rowID, colId, cellValue, item);
    });
    cellDoOperations.push({
        action: "doUpdateUpdated",
        id: options.blockElement.getAttribute("data-node-id"),
        data: dayjs().format("YYYYMMDDHHmmss"),
    });
    transaction(options.protyle, cellDoOperations, cellUndoOperations);
    const menuElement = document.querySelector(".av__panel > .b3-menu") as HTMLElement;
    if (menuElement) {
        menuElement.innerHTML = getAssetHTML(options.cellElements);
        bindAssetEvent({
            protyle: options.protyle,
            menuElement,
            cellElements: options.cellElements,
            blockElement: options.blockElement
        });
        const cellRect = (options.cellElements[0].classList.contains("custom-attr__avvalue") ? options.cellElements[0] : options.protyle.wysiwyg.element.querySelector(`.av__cell[data-id="${options.cellElements[0].dataset.id}"]`)).getBoundingClientRect();
        setTimeout(() => {
            setPosition(menuElement, cellRect.left, cellRect.bottom, cellRect.height, 0, true);
        }, Constants.TIMEOUT_LOAD);  // 等待图片加载
    }
};

export const editAssetItem = (options: {
    protyle: IProtyle,
    cellElements: HTMLElement[],
    blockElement: Element,
    content: string,
    type: "image" | "file",
    name: string,
    index: number,
    rect: DOMRect,
    keepMenuOpen?: boolean,
}) => {
    const linkAddress = removeCompressURL(options.content);
    const type = options.type as "image" | "file";
    const menu = new Menu(Constants.MENU_AV_ASSET_EDIT, async () => {
        let currentLink = textElements[0].value;
        if ((!textElements[1] && currentLink === decodeURI(linkAddress)) ||
            (textElements[1] && currentLink === decodeURI(linkAddress) && textElements[1].value === options.name)) {
            return;
        }
        if (type === "image" && currentLink.startsWith("data:image/")) {
            let base64Src: Array<string | undefined>;
            try {
                base64Src = await base64ToURL([currentLink], options.protyle, {
                    source: "programmatic",
                    target: "av-cell",
                });
            } catch (error) {
                if (showBase64ImageSizeLimit(error)) {
                    return;
                }
                throw error;
            }
            currentLink = base64Src[0] || currentLink;
        }

        updateAssetCell({
            protyle: options.protyle,
            cellElements: options.cellElements,
            blockElement: options.blockElement,
            updateValue: {
                index: options.index,
                value: {
                    content: currentLink,
                    name: textElements[1] ? textElements[1].value : "",
                    type
                }
            }
        });
    }, options.keepMenuOpen);
    if (menu.isOpen) {
        return;
    }
    if (type === "file") {
        menu.addItem({
            id: "linkAndTitle",
            iconHTML: "",
            type: "readonly",
            label: `<div class="fn__flex">
    <span class="fn__flex-center">${window.siyuan.languages.link}</span>
    <span class="fn__space"></span>
    <span data-action="copy" class="block__icon block__icon--show b3-tooltips b3-tooltips__e fn__flex-center" aria-label="${window.siyuan.languages.copy}">
        <svg><use xlink:href="#iconCopy"></use></svg>
    </span>   
</div><textarea rows="1" style="margin:4px 0;width: ${isMobile() ? "100%" : "360px"};resize: vertical;" class="b3-text-field"></textarea><div class="fn__hr"></div><div class="fn__flex">
    <span class="fn__flex-center">${window.siyuan.languages.title}</span>
    <span class="fn__space"></span>
    <span data-action="copy" class="block__icon block__icon--show b3-tooltips b3-tooltips__e fn__flex-center" aria-label="${window.siyuan.languages.copy}">
        <svg><use xlink:href="#iconCopy"></use></svg>
    </span>   
</div><textarea style="width: ${isMobile() ? "100%" : "360px"};margin: 4px 0;resize: vertical;" rows="1" class="b3-text-field"></textarea>`,
            bind(element) {
                element.addEventListener("click", (event) => {
                    let target = event.target as HTMLElement;
                    while (target) {
                        if (target.dataset.action === "copy") {
                            writeText((target.parentElement.nextElementSibling as HTMLTextAreaElement).value);
                            showMessage(window.siyuan.languages.copied);
                            break;
                        }
                        target = target.parentElement;
                    }
                });
            }
        });
        menu.addSeparator({id: "separator_1"});
        menu.addItem({
            id: "copy",
            label: window.siyuan.languages.copy,
            icon: "iconCopy",
            click() {
                writeText(`[${textElements[1].value || textElements[0].value}](${textElements[0].value})`);
            }
        });
    } else {
        menu.addItem({
            id: "link",
            iconHTML: "",
            type: "readonly",
            label: `<div class="fn__flex">
    <span class="fn__flex-center">${window.siyuan.languages.link}</span>
    <span class="fn__space"></span>
    <span data-action="copy" class="block__icon block__icon--show b3-tooltips b3-tooltips__e fn__flex-center" aria-label="${window.siyuan.languages.copy}">
        <svg><use xlink:href="#iconCopy"></use></svg>
    </span>   
</div><textarea rows="1" style="margin:4px 0;width: ${isMobile() ? "100%" : "360px"};resize: vertical;" class="b3-text-field"></textarea>`,
            bind(element) {
                element.addEventListener("click", (event) => {
                    let target = event.target as HTMLElement;
                    while (target) {
                        if (target.dataset.action === "copy") {
                            writeText((target.parentElement.nextElementSibling as HTMLTextAreaElement).value);
                            showMessage(window.siyuan.languages.copied);
                            break;
                        }
                        target = target.parentElement;
                    }
                });
            }
        });
        menu.addSeparator({id: "separator_1"});
        menu.addItem({
            id: "copy",
            label: window.siyuan.languages.copy,
            icon: "iconCopy",
            click() {
                writeText(`![](${textElements[0].value})`);
            }
        });
        menu.addItem({
            id: "copyAsPNG",
            label: window.siyuan.languages.copyAsPNG,
            icon: "iconImage",
            click() {
                copyPNGByLink(textElements[0].value);
            }
        });
    }
    menu.addItem({
        id: "delete",
        icon: "iconTrashcan",
        label: window.siyuan.languages.delete,
        click() {
            updateAssetCell({
                protyle: options.protyle,
                cellElements: options.cellElements,
                blockElement: options.blockElement,
                removeIndex: options.index
            });
        }
    });
    if (linkAddress?.startsWith("assets/")) {
        menu.addItem({
            id: "rename",
            label: window.siyuan.languages.rename,
            icon: "iconEdit",
            click() {
                renameAsset(decodeURI(linkAddress));
                document.querySelector(".av__panel")?.remove();
            }
        });
    }
    const openSubMenu = openMenu(options.protyle ? options.protyle.app : window.siyuan.ws.app, linkAddress, true, false);
    if (type !== "file" || openSubMenu.length > 0) {
        menu.addSeparator({id: "separator_2"});
    }
    if (type !== "file" && isBrowserRenderableImagePath(linkAddress)) {
        menu.addItem({
            id: "cardPreview",
            icon: "iconPreview",
            label: window.siyuan.languages.cardPreview,
            click() {
                previewAttrViewImages(
                    linkAddress,
                    options.blockElement.getAttribute("data-av-id"),
                    options.blockElement.getAttribute(Constants.CUSTOM_SY_AV_VIEW),
                    options.blockElement.querySelector('[data-type="av-search"]')?.textContent.trim() || ""
                );
            }
        });
    }
    if (openSubMenu.length > 0) {
        window.siyuan.menus.menu.append(new MenuItem({
            id: "openBy",
            label: window.siyuan.languages.openBy,
            icon: "iconOpen",
            submenu: openSubMenu
        }).element);
    }
    if (linkAddress?.startsWith("assets/")) {
        window.siyuan.menus.menu.append(new MenuItem(exportAsset(decodeURI(linkAddress))).element);
        window.siyuan.menus.menu.append(new MenuItem(writeAssetToClipboard(decodeURI(linkAddress))).element);
    }
    const rect = options.rect;
    /// #if MOBILE
    menu.fullscreen();
    /// #else
    menu.open({
        x: rect.right,
        y: rect.top,
        w: rect.width,
        h: rect.height,
    });
    /// #endif
    const textElements = menu.element.querySelectorAll("textarea");
    textElements[0].value = decodeURI(linkAddress);
    textElements[0].focus();
    textElements[0].select();
    if (textElements.length > 1) {
        textElements[1].value = options.name;
    }
};

export const addAssetLink = (protyle: IProtyle, cellElements: HTMLElement[], target: HTMLElement, blockElement: Element,
                             assetType: "image" | "file", keepMenuOpen = false) => {
    const menu = new Menu(Constants.MENU_AV_ASSET_EDIT, () => {
        const textElements = menu.element.querySelectorAll("textarea");
        if (assetType === "image") {
            const value = genNetworkImageAssetValue(textElements[0].value);
            if (!value) {
                if (textElements[0].value) {
                    showMessage(window.siyuan.languages.invalid);
                }
                return;
            }
            updateAssetCell({
                protyle,
                cellElements,
                blockElement,
                addValue: [value]
            });
            return;
        }
        if (!textElements[0].value && !textElements[1].value) {
            return;
        }
        updateAssetCell({
            protyle,
            cellElements,
            blockElement,
            addValue: [{
                type: "file",
                name: textElements[1].value,
                content: textElements[0].value,
            }]
        });
    }, keepMenuOpen);
    if (menu.isOpen) {
        return;
    }
    menu.addItem({
        iconHTML: "",
        type: "readonly",
        label: assetType === "image" ? `${window.siyuan.languages.insertImgURL}
<textarea rows="1" style="margin:4px 0;width: ${isMobile() ? "100%" : "360px"};resize: vertical;" class="b3-text-field"></textarea>` : `${window.siyuan.languages.link}
<textarea rows="1" style="margin:4px 0;width: ${isMobile() ? "100%" : "360px"};resize: vertical;" class="b3-text-field"></textarea>
<div class="fn__hr"></div>
${window.siyuan.languages.title}
<textarea style="width: ${isMobile() ? "100%" : "360px"};margin: 4px 0;resize: vertical;" rows="1" class="b3-text-field"></textarea>`,
    });
    /// #if MOBILE
    menu.fullscreen();
    /// #else
    const rect = target.getBoundingClientRect();
    menu.open({
        x: rect.right,
        y: rect.bottom,
        w: target.parentElement.clientWidth + 8,
        h: rect.height,
    });
    /// #endif
    menu.element.querySelector("textarea").focus();
};

const updateCellWithUploadedAssets = (result: Omit<IAssetUploadResult, "requestId" | "input">,
                                      protyle: IProtyle, cellElement: HTMLElement) => {
    const blockElement = hasClosestBlock(cellElement);
    if (!blockElement) {
        return;
    }
    const addValue: IAVCellAssetValue[] = [];
    getAssetUploadSuccesses(result).forEach(success => {
        const type = getAssetExtension(success.name).toLowerCase();
        const name = success.name.substring(0, success.name.length - type.length);
        if (Constants.SIYUAN_ASSETS_IMAGE.includes(type)) {
            addValue.push({
                type: "image",
                name,
                content: success.path,
            });
        } else {
            addValue.push({
                type: "file",
                name,
                content: success.path,
            });
        }
    });
    updateAssetCell({
        protyle,
        blockElement,
        cellElements: [cellElement],
        addValue
    });
};

export const dragUpload = (files: ILocalFiles[], protyle: IProtyle, cellElement: HTMLElement,
                           position?: IAssetUploadPosition) => {
    uploadLocalFiles(files, protyle, true, {source: "drop", target: "av-cell", position}, (_response, result) => {
        updateCellWithUploadedAssets(result, protyle, cellElement);
    });
};

export const dragUploadFiles = (files: FileList | File[], protyle: IProtyle, cellElement: HTMLElement,
                                position?: IAssetUploadPosition) => {
    uploadFiles(protyle, files, undefined, (_response, result) => {
        updateCellWithUploadedAssets(result, protyle, cellElement);
    }, undefined, {source: "drop", target: "av-cell", position});
};
