import {fetchPost, fetchSyncPost} from "../../util/fetch";
import {MenuItem} from "../../menus/Menu";
import {copySubMenu, exportMd, movePathToMenu, openFileAttr, openFileWechatNotify,} from "../../menus/commonMenuItem";
import {deleteFile} from "../../editor/deleteFile";
import {updateHotkeyTip, writeClipboardData} from "../util/compatibility";
/// #if !MOBILE
import {openBacklink, openGraph, openOutline} from "../../layout/dock/util";
import * as path from "path";
/// #else
import {openMobileFileById} from "../../mobile/editor";
/// #endif
import {Constants} from "../../constants";
import {openCardByData} from "../../card/openCard";
import {viewCards} from "../../card/viewCards";
import {getDisplayName, getNotebookName, isEncryptedBox, pathPosix, useShell} from "../../util/pathName";
import {makeCard, quickMakeCard} from "../../card/makeCard";
import {emitOpenMenu} from "../../plugin/EventBus";
import * as dayjs from "dayjs";
import {hideTooltip} from "../../dialog/tooltip";
import {popSearch} from "../../mobile/menu/search";
import {openSearch} from "../../search/spread";
import {openDocHistory} from "../../history/doc";
import {openNewWindowById} from "../../window/openNewWindow";
import {transferBlockRef} from "../../menus/block";
import {addEditorToDatabase} from "../render/av/addToDatabase";
import {openFileById} from "../../editor/util";
import {hasTopClosestByClassName} from "../util/hasClosest";
import {showMessage} from "../../dialog/message";
import {buildBlockDOMClipboardRichData} from "../util/blockDOMClipboard";
import {buildWebClipboardHTML} from "../util/clipboardData";
import {exportImage} from "../export/util";

export const openTitleMenu = (protyle: IProtyle, position: IPosition, from: string) => {
    hideTooltip();
    if (!window.siyuan.menus.menu.element.classList.contains("fn__none") &&
        window.siyuan.menus.menu.element.getAttribute("data-name") === Constants.MENU_TITLE) {
        window.siyuan.menus.menu.remove();
        return;
    }
    const docInfoParam: IObject = {
        id: protyle.block.rootID
    };
    if (isEncryptedBox(protyle.notebookId)) {
        docInfoParam.notebook = protyle.notebookId;
    }
    fetchPost("/api/block/getDocInfo", docInfoParam, (response) => {
        window.siyuan.menus.menu.remove();
        window.siyuan.menus.menu.element.setAttribute("data-name", Constants.MENU_TITLE);
        const isBoxDoc = protyle.notebookId === protyle.block.rootID;
        const popoverElement = hasTopClosestByClassName(protyle.element, "block__popover", true);
        window.siyuan.menus.menu.element.setAttribute("data-from", popoverElement ? popoverElement.dataset.level + "popover-" + from : "app-" + from);
        const submenu = copySubMenu([protyle.block.rootID], true, undefined, protyle.block.showAll ? protyle.block.id : protyle.block.rootID);
        submenu.push({
            id: "copyAsPNG",
            iconHTML: "",
            label: window.siyuan.languages.copyAsPNG,
            click() {
                exportImage(protyle.block.showAll ? protyle.block.id : protyle.block.rootID, true);
            }
        });
        submenu.push({
            id: "copyDoc",
            iconHTML: "",
            label: window.siyuan.languages.copyDoc,
            accelerator: undefined,
            click: async () => {
                const [responseHTML, responseText] = await Promise.all([
                    fetchSyncPost("/api/block/getBlockDOM", {
                        id: protyle.block.rootID,
                        notebook: protyle.notebookId,
                    }),
                    fetchSyncPost("/api/export/exportMdContent", {
                        id: protyle.block.rootID,
                        refMode: 3,
                        embedMode: 1,
                        yfm: false,
                        fillCSSVar: false,
                        adjustHeadingLevel: false
                    })
                ]);

                const {textHTML, textSiyuan} = buildBlockDOMClipboardRichData(protyle.lute, responseHTML.data.dom);
                const result = await writeClipboardData({
                    textPlain: responseText.data.content,
                    textHTML: buildWebClipboardHTML(textHTML, textSiyuan),
                });
                if (result.error) {
                    console.log("Write document clipboard error:", result.error);
                }
                if (result.status === "failed") {
                    showMessage(window.siyuan.languages.clipboardPermissionDenied, 7000, "error");
                    return;
                }

                showMessage(window.siyuan.languages.copied);
            }
        });
        window.siyuan.menus.menu.append(new MenuItem({
            id: "copy",
            label: window.siyuan.languages.copy,
            icon: "iconCopy",
            type: "submenu",
            submenu,
        }).element);
        if (!protyle.disabled) {
            if (!isBoxDoc) {
                window.siyuan.menus.menu.append(movePathToMenu([protyle.path]));
            }
            const range = getSelection().rangeCount > 0 ? getSelection().getRangeAt(0) : undefined;
            window.siyuan.menus.menu.append(new MenuItem({
                id: "addToDatabase",
                label: window.siyuan.languages.addToDatabase,
                accelerator: window.siyuan.config.keymap.general.addToDatabase.custom,
                icon: "iconDatabase",
                click: () => {
                    addEditorToDatabase(protyle, range, "title");
                }
            }).element);
            if (!isBoxDoc) {
                window.siyuan.menus.menu.append(new MenuItem({
                    id: "delete",
                    icon: "iconTrashcan",
                    label: window.siyuan.languages.delete,
                    click: () => {
                        deleteFile(protyle.notebookId, protyle.path);
                    }
                }).element);
            }
        }
        /// #if !MOBILE
        window.siyuan.menus.menu.append(new MenuItem({id: "separator_1", type: "separator"}).element);
        window.siyuan.menus.menu.append(new MenuItem({
            id: "outline",
            icon: "iconOutline",
            label: window.siyuan.languages.outline,
            accelerator: window.siyuan.config.keymap.editor.general.outline.custom,
            click: () => {
                openOutline({
                    app: protyle.app,
                    rootId: protyle.block.rootID,
                    notebookId: protyle.notebookId,
                    title: protyle.options.render.title ? (protyle.title.editElement.textContent || window.siyuan.languages.untitled) : "",
                    isPreview: !protyle.preview.element.classList.contains("fn__none")
                });
            }
        }).element);
        window.siyuan.menus.menu.append(new MenuItem({
            id: "backlinks",
            icon: "iconLink",
            label: window.siyuan.languages.backlinks,
            accelerator: window.siyuan.config.keymap.editor.general.backlinks.custom,
            click: () => {
                openBacklink({
                    app: protyle.app,
                    blockId: protyle.block.id,
                    rootId: protyle.block.rootID,
                    notebookId: protyle.notebookId,
                    useBlockId: protyle.block.showAll,
                    title: protyle.title ? (protyle.title.editElement.textContent || window.siyuan.languages.untitled) : null
                });
            }
        }).element);
        window.siyuan.menus.menu.append(new MenuItem({
            id: "graphView",
            icon: "iconGraph",
            label: window.siyuan.languages.graphView,
            accelerator: window.siyuan.config.keymap.editor.general.graphView.custom,
            click: () => {
                openGraph({
                    app: protyle.app,
                    blockId: protyle.block.id,
                    rootId: protyle.block.rootID,
                    notebookId: protyle.notebookId,
                    useBlockId: protyle.block.showAll,
                    title: protyle.title ? (protyle.title.editElement.textContent || window.siyuan.languages.untitled) : null
                });
            }
        }).element);
        /// #endif
        window.siyuan.menus.menu.append(new MenuItem({id: "separator_2", type: "separator"}).element);
        window.siyuan.menus.menu.append(new MenuItem({
            id: "attr",
            label: window.siyuan.languages.attr,
            icon: "iconAttr",
            accelerator: window.siyuan.config.keymap.editor.general.attr.custom + "/" + updateHotkeyTip("⇧" + window.siyuan.languages.click),
            click() {
                openFileAttr(response.data.ial, "bookmark", protyle);
            }
        }).element);
        if (!window.siyuan.config.readonly) {
            if (window.siyuan.config.cloudRegion === 0) {
                window.siyuan.menus.menu.append(new MenuItem({
                    id: "wechatReminder",
                    label: window.siyuan.languages.wechatReminder,
                    icon: "iconMp",
                    click() {
                        openFileWechatNotify(protyle);
                    }
                }).element);
            }
            const isCardMade = !!response.data.ial[Constants.CUSTOM_RIFF_DECKS];
            if (!isEncryptedBox(protyle.notebookId)) {
            const riffCardMenu: IMenu[] = [{
                id: "spaceRepetition",
                iconHTML: "",
                label: window.siyuan.languages.spaceRepetition,
                accelerator: window.siyuan.config.keymap.editor.general.spaceRepetition.custom,
                click: () => {
                    fetchPost("/api/riff/getTreeRiffDueCards", {rootID: protyle.block.rootID}, (response) => {
                        openCardByData(protyle.app, response.data, "doc", protyle.block.rootID, response.data.name);
                    });
                }
            }, {
                id: "manage",
                iconHTML: "",
                label: window.siyuan.languages.manage,
                click: () => {
                    fetchPost("/api/filetree/getHPathByID", {
                        id: protyle.block.rootID
                    }, (response) => {
                        viewCards(protyle.app, protyle.block.rootID, pathPosix().join(getNotebookName(protyle.notebookId), (response.data)), "Tree");
                    });
                }
            }, {
                id: isCardMade ? "removeCard" : "quickMakeCard",
                iconHTML: "",
                label: isCardMade ? window.siyuan.languages.removeCard : window.siyuan.languages.quickMakeCard,
                accelerator: window.siyuan.config.keymap.editor.general.quickMakeCard.custom,
                click: () => {
                    let titleElement = protyle.title?.element;
                    if (!titleElement) {
                        titleElement = document.createElement("div");
                        titleElement.setAttribute("data-node-id", protyle.block.rootID);
                        titleElement.setAttribute(Constants.CUSTOM_RIFF_DECKS, response.data.ial[Constants.CUSTOM_RIFF_DECKS]);
                    }
                    quickMakeCard(protyle, [titleElement]);
                }
            }];
            if (window.siyuan.config.flashcard.deck) {
                riffCardMenu.push({
                    id: "addToDeck",
                    iconHTML: "",
                    label: window.siyuan.languages.addToDeck,
                    click: () => {
                        makeCard(protyle.app, [protyle.block.rootID]);
                    }
                });
            }
            window.siyuan.menus.menu.append(new MenuItem({
                id: "riffCard",
                label: window.siyuan.languages.riffCard,
                type: "submenu",
                icon: "iconRiffCard",
                submenu: riffCardMenu,
            }).element);
            }
        }
        window.siyuan.menus.menu.append(new MenuItem({
            id: "search",
            label: window.siyuan.languages.search,
            icon: "iconSearch",
            accelerator: window.siyuan.config.keymap.general.search.custom,
            async click() {
                const searchPath = isBoxDoc ? "" : getDisplayName(protyle.path, false, true);
                /// #if MOBILE
                const pathResponse = isBoxDoc ? undefined : await fetchSyncPost("/api/filetree/getHPathByPath", {
                        notebook: protyle.notebookId,
                        path: searchPath + ".sy"
                    });
                if (!isBoxDoc && (pathResponse?.code !== 0 || typeof pathResponse?.data !== "string")) {
                    return;
                }
                popSearch(protyle.app, {
                    hasReplace: false,
                    hPath: isBoxDoc ? getNotebookName(protyle.notebookId) : pathPosix().join(getNotebookName(protyle.notebookId), pathResponse.data),
                    idPath: [isBoxDoc ? protyle.notebookId : pathPosix().join(protyle.notebookId, searchPath)],
                    page: 1,
                });
                /// #else
                openSearch({
                    app: protyle.app,
                    hotkey: Constants.DIALOG_SEARCH,
                    notebookId: protyle.notebookId,
                    searchPath
                });
                /// #endif
            }
        }).element);
        if (!protyle.disabled) {
            transferBlockRef(protyle.block.rootID);
        }
        window.siyuan.menus.menu.append(new MenuItem({id: "separator_3", type: "separator"}).element);
        if (!protyle.model) {
            window.siyuan.menus.menu.append(new MenuItem({
                id: "openBy",
                label: window.siyuan.languages.openBy,
                icon: "iconOpen",
                click() {
                    /// #if !MOBILE
                    openFileById({
                        app: protyle.app,
                        id: protyle.block.id,
                        action: protyle.block.rootID !== protyle.block.id ? [Constants.CB_GET_ALL, Constants.CB_GET_FOCUS] : [Constants.CB_GET_CONTEXT],
                    });
                    /// #else
                    openMobileFileById(protyle.app, protyle.block.id, protyle.block.rootID !== protyle.block.id ? [Constants.CB_GET_ALL] : [Constants.CB_GET_CONTEXT]);
                    /// #endif
                }
            }).element);
        }
        /// #if !BROWSER
        window.siyuan.menus.menu.append(new MenuItem({
            id: "openByNewWindow",
            label: window.siyuan.languages.openByNewWindow,
            icon: "iconOpenWindow",
            click() {
                openNewWindowById(protyle.block.rootID);
            }
        }).element);
        window.siyuan.menus.menu.append(new MenuItem({
            id: "showInFolder",
            icon: "iconFolder",
            label: window.siyuan.languages.showInFolder,
            click: () => {
                useShell("showItemInFolder", path.join(window.siyuan.config.system.dataDir, protyle.notebookId, protyle.path));
            }
        }).element);
        /// #endif
        if (!protyle.disabled) {
            window.siyuan.menus.menu.append(new MenuItem({
                id: "fileHistory",
                label: window.siyuan.languages.dataHistory,
                icon: "iconHistory",
                click() {
                    openDocHistory({
                        app: protyle.app,
                        id: protyle.block.rootID,
                        notebookId: protyle.notebookId,
                        pathString: response.data.name
                    });
                }
            }).element);
        }
        window.siyuan.menus.menu.append(exportMd(protyle.block.showAll ? protyle.block.id : protyle.block.rootID));

        window.siyuan.menus.menu.append(new MenuItem({id: "separator_4", type: "separator"}).element);
        if (protyle) {
            emitOpenMenu({
                type: "click-editortitleicon",
                detail: {
                    protyle,
                    data: response.data,
                },
                separatorPosition: "bottom",
            });
        }
        window.siyuan.menus.menu.append(new MenuItem({
            id: "updateAndCreatedAt",
            iconHTML: "",
            type: "readonly",
            // 不能换行，否则移动端间距过大
            label: `${window.siyuan.languages.modifiedAt} ${dayjs(response.data.ial.updated).format("YYYY-MM-DD HH:mm:ss")}<br>${window.siyuan.languages.createdAt} ${dayjs(response.data.ial.id.substr(0, 14)).format("YYYY-MM-DD HH:mm:ss")}`
        }).element);
        /// #if MOBILE
        window.siyuan.menus.menu.fullscreen();
        /// #else
        window.siyuan.menus.menu.popup(position);
        /// #endif
    });
};
