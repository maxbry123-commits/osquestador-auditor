import {Constants} from "../constants";
import {addScript} from "../protyle/util/addScript";
import {addStyle} from "../protyle/util/addStyle";
import {getAllEditor, getAllModels} from "../layout/getAll";
import {invalidateHeadingNumberMeasurements} from "../protyle/util/headingNumberCore";
import {renderHeadingNumbers} from "../protyle/util/headingNumber";
/// #if !MOBILE
import {exportLayout} from "../layout/util";
/// #endif
import {fetchPost} from "./fetch";
import {
    isInAndroid,
    isInHarmony,
    isInIOS,
    isInMobileApp,
    isIPad,
    isIPhone,
    isMac,
    isWin11
} from "../protyle/util/compatibility";
import {setCodeTheme} from "../protyle/render/util";
import {getBackend, getFrontend} from "./functions";
import {getWorkspaceName} from "./processTitle";
import {ensureSelectedCustomFonts} from "./customFont";
import {isCurrentThemeSupported, shouldUnloadThemeScript} from "./themeCompatibility";
import {
    getInlineStylesCSS,
    loadInlineStyles
} from "../protyle/toolbar/inlineStyle";
import {refreshChartTheme} from "../protyle/render/chartRender";

let headingNumberMeasurementRefreshTimer: number;
const DEJAVU_EMOJI_PRESENTATION_UNICODE_RANGE = "U+25fd-25fe, U+2614-2615, U+2648-2653, U+267f, U+2693, U+26a1, " +
    "U+26aa-26ab, U+1f0cf, U+1f311-1f318, U+1f42d-1f42e, U+1f431, U+1f435, U+1f600-1f64f";

export const refreshHeadingNumberMeasurements = () => {
    invalidateHeadingNumberMeasurements();
    getAllEditor().forEach(item => renderHeadingNumbers(item.protyle));
};

const scheduleHeadingNumberMeasurementRefresh = (styleElements: HTMLLinkElement[]) => {
    const schedule = (delay = 0) => {
        window.clearTimeout(headingNumberMeasurementRefreshTimer);
        headingNumberMeasurementRefreshTimer = window.setTimeout(refreshHeadingNumberMeasurements, delay);
    };
    styleElements.forEach(item => {
        item.addEventListener("load", () => schedule(), {once: true});
        item.addEventListener("error", () => schedule(), {once: true});
    });
    schedule(styleElements.length > 0 ? Constants.TIMEOUT_LOAD : 0);
};

const getThemeScriptElements = () => Array.from(document.querySelectorAll<HTMLScriptElement>(
    "script[src*='/appearance/themes/'][src*='/theme.js']"
));

const removeThemeScriptElements = () => {
    getThemeScriptElements().forEach((item) => item.remove());
};

export const unloadThemeScript = async () => {
    const themeScriptElement = document.getElementById("themeScript");
    const themeScriptElements = getThemeScriptElements();
    if (!themeScriptElement && !window.destroyTheme) {
        themeScriptElements.forEach((item) => item.remove());
        return true;
    }
    if (!window.destroyTheme) {
        return false;
    }
    try {
        await window.destroyTheme();
        window.destroyTheme = undefined;
        themeScriptElement?.remove();
        removeThemeScriptElements();
        return true;
    } catch (error) {
        console.error("destroyTheme error: " + error);
        return false;
    }
};

export const refreshThemeStyle = (themeAddress: string) => {
    const appearance = window.siyuan.config.appearance;
    if (!isCurrentThemeSupported(appearance, getFrontend())) {
        return;
    }
    const isCustomTheme = (appearance.mode === 1 && appearance.themeDark !== "midnight") ||
        (appearance.mode === 0 && appearance.themeLight !== "daylight");
    const styleElement = document.getElementById(isCustomTheme ? "themeStyle" : "themeDefaultStyle") as HTMLLinkElement;
    if (styleElement) {
        styleElement.href = themeAddress;
    }
};

export const loadAssets = (data: Config.IAppearance) => {
    const changedThemeStyleElements: HTMLLinkElement[] = [];
    let themeStylesChanged = false;
    const htmlElement = document.getElementsByTagName("html")[0];
    const previousThemeMode = htmlElement.getAttribute("data-theme-mode");
    const themeMode = getThemeMode();
    htmlElement.setAttribute("lang", window.siyuan.config.appearance.lang);
    htmlElement.setAttribute("data-frontend", getFrontend()); // https://github.com/siyuan-note/siyuan/issues/12549
    htmlElement.setAttribute("data-backend", getBackend());
    htmlElement.setAttribute("data-theme-mode", themeMode);
    htmlElement.setAttribute("data-light-theme", window.siyuan.config.appearance.themeLight);
    htmlElement.setAttribute("data-dark-theme", window.siyuan.config.appearance.themeDark);
    const OSTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    if (window.siyuan.config.appearance.modeOS && (
        (window.siyuan.config.appearance.mode === 1 && OSTheme === "light") ||
        (window.siyuan.config.appearance.mode === 0 && OSTheme === "dark")
    )) {
        fetchPost("/api/system/setAppearanceMode", {mode: OSTheme === "light" ? 0 : 1});
        window.siyuan.config.appearance.mode = (OSTheme === "light" ? 0 : 1);
    }
    if (previousThemeMode && previousThemeMode !== themeMode) {
        refreshChartTheme(document.body);
    }
    const defaultStyleElement = document.getElementById("themeDefaultStyle");
    const defaultThemeAddress = `/appearance/themes/${data.mode === 1 ? "midnight" : "daylight"}/theme.css?v=${Constants.SIYUAN_VERSION}`;
    if (defaultStyleElement) {
        if (!defaultStyleElement.getAttribute("href").startsWith(defaultThemeAddress)) {
            const newStyleElement = document.createElement("link");
            changedThemeStyleElements.push(newStyleElement);
            themeStylesChanged = true;
            // 等待新样式表加载完成再移除旧样式表
            new Promise((resolve) => {
                newStyleElement.rel = "stylesheet";
                newStyleElement.href = defaultThemeAddress;
                newStyleElement.onload = resolve;
                defaultStyleElement.parentNode.insertBefore(newStyleElement, defaultStyleElement);
            }).then(() => {
                defaultStyleElement.remove();
                newStyleElement.id = "themeDefaultStyle";
            });
        }
    } else {
        addStyle(defaultThemeAddress, "themeDefaultStyle");
        changedThemeStyleElements.push(document.getElementById("themeDefaultStyle") as HTMLLinkElement);
        themeStylesChanged = true;
    }
    const styleElement = document.getElementById("themeStyle");
    const themeSupported = isCurrentThemeSupported(data, getFrontend());
    if (themeSupported && ((data.mode === 1 && data.themeDark !== "midnight") ||
        (data.mode === 0 && data.themeLight !== "daylight"))) {
        const themeAddress = `/appearance/themes/${data.mode === 1 ? data.themeDark : data.themeLight}/theme.css?v=${data.themeVer}`;
        if (styleElement) {
            if (!styleElement.getAttribute("href").startsWith(themeAddress)) {
                changedThemeStyleElements.push(styleElement as HTMLLinkElement);
                themeStylesChanged = true;
                styleElement.setAttribute("href", themeAddress);
            }
        } else {
            addStyle(themeAddress, "themeStyle");
            changedThemeStyleElements.push(document.getElementById("themeStyle") as HTMLLinkElement);
            themeStylesChanged = true;
        }
    } else if (styleElement) {
        styleElement.remove();
        themeStylesChanged = true;
    }
    if (themeStylesChanged) {
        scheduleHeadingNumberMeasurementRefresh(changedThemeStyleElements);
    }
    /// #if !MOBILE
    getAllModels().graph.forEach(item => {
        item.searchGraph();
    });
    const pdfTheme = window.siyuan.config.appearance.mode === 0 ? window.siyuan.storage[Constants.LOCAL_PDFTHEME].light :
        window.siyuan.storage[Constants.LOCAL_PDFTHEME].dark;
    document.querySelectorAll(".pdf__outer").forEach(item => {
        const darkElement = item.querySelector("#pdfDark");
        const lightElement = item.querySelector("#pdfLight");
        if (pdfTheme === "dark") {
            item.classList.add("pdf__outer--dark");
            lightElement.classList.remove("toggled");
            darkElement.classList.add("toggled");
        } else {
            item.classList.remove("pdf__outer--dark");
            lightElement.classList.add("toggled");
            darkElement.classList.remove("toggled");
        }
    });
    /// #endif

    /// #if BROWSER
    if (!window.webkit?.messageHandlers && !window.JSAndroid && !window.JSHarmony &&
        ("serviceWorker" in window.navigator) && ("caches" in window) && ("fetch" in window) && navigator.serviceWorker) {
        document.head.insertAdjacentHTML("afterbegin", `<meta name="theme-color" content="${getComputedStyle(document.body).getPropertyValue("--b3-body-background").trim()}">`);
    }
    /// #endif
    setCodeTheme();

    const themeScriptAddress = `/appearance/themes/${data.mode === 1 ? data.themeDark : data.themeLight}/theme.js?v=${data.themeVer}`;
    const themeScriptURL = new URL(themeScriptAddress, window.location.href).href;
    const themeScriptElements = getThemeScriptElements();
    if (!data.themeJS || !themeSupported) {
        removeThemeScriptElements();
    } else if (!themeScriptElements.some((item) => item.src === themeScriptURL)) {
        removeThemeScriptElements();
        addScript(themeScriptAddress, "themeScript");
    }

    // load icons
    const isBuiltInIcon = data.icon === "litheness";
    const iconScriptElement = document.getElementById("iconScript");
    const iconDefaultScriptElement = document.getElementById("iconDefaultScript");
    // 不能使用 data.iconVer，因为其他主题也需要加载默认图标，此时 data.iconVer 为其他图标的版本号
    const iconDefaultURL = `/appearance/icons/litheness/icon.js?v=${Constants.SIYUAN_VERSION}`;
    const iconThirdURL = `/appearance/icons/${data.icon}/icon.js?v=${data.iconVer}`;

    if ((isBuiltInIcon && iconDefaultScriptElement && iconDefaultScriptElement.getAttribute("src").startsWith(iconDefaultURL)) ||
        (!isBuiltInIcon && iconScriptElement && iconScriptElement.getAttribute("src").startsWith(iconThirdURL))) {
        // 第三方图标切换到默认 litheness
        if (isBuiltInIcon) {
            iconScriptElement?.remove();
            Array.from(document.body.children).forEach((item) => {
                if (item.tagName === "svg" && !item.getAttribute("data-name") && "iconsLitheness" !== item.id) {
                    item.remove();
                }
            });
        }
        return;
    }
    addScript(iconDefaultURL, "iconDefaultScript").then(() => {
        iconScriptElement?.remove();
        if (!isBuiltInIcon) {
            addScript(iconThirdURL, "iconScript").then(() => {
                Array.from(document.body.children).forEach((item, index) => {
                    if (item.tagName === "svg" &&
                        index !== 0 && !item.getAttribute("data-name") && "iconsLitheness" !== item.id) {
                        item.remove();
                    }
                });
            });
        }
    });
};

export const initAssets = () => {
    const loadingElement = document.getElementById("loading");
    if (loadingElement) {
        setTimeout(() => {
            loadingElement.remove();
        }, 160);
    }
    updateMobileTheme(window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", event => {
        const OSTheme = event.matches ? "dark" : "light";
        updateMobileTheme(OSTheme);
        if (!window.siyuan.config.appearance.modeOS) {
            return;
        }
        if ((window.siyuan.config.appearance.mode === 0 && OSTheme === "light") ||
            (window.siyuan.config.appearance.mode === 1 && OSTheme === "dark")) {
            return;
        }
        fetchPost("/api/system/setAppearanceMode", {
            mode: OSTheme === "light" ? 0 : 1
        }, async response => {
            const nextAppearance = response.data.appearance as Config.IAppearance;
            if (shouldUnloadThemeScript(window.siyuan.config.appearance, nextAppearance, getFrontend()) &&
                !await unloadThemeScript()) {
                /// #if !MOBILE
                exportLayout({
                    cb() {
                        window.location.reload();
                    },
                    errorExit: false,
                });
                /// #else
                window.location.reload();
                /// #endif
                return;
            }
            window.siyuan.config.appearance = nextAppearance;
            loadAssets(nextAppearance);
        });
    });
};

export const setInlineStyle = async (set = true, servePath = "../../../") => {
    const editorFonts = window.siyuan.config.editor.fontFamilies || [];
    const codeFonts = window.siyuan.config.editor.codeFontFamilies || [];
    let inlineStylesCSS = "";
    try {
        const inlineStyles = await loadInlineStyles();
        inlineStylesCSS = getInlineStylesCSS(inlineStyles);
    } catch (error) {
        console.error("load inline styles error: " + error);
        inlineStylesCSS = getInlineStylesCSS();
    }
    if (set) {
        await ensureSelectedCustomFonts([...editorFonts, ...codeFonts]);
    }
    let style;
    // Emojis Reset: 字体中包含了 emoji，需重置
    // Emojis Additional： 苹果/win11 字体中没有的 emoji
    if (isMac() || isIPad() || isIPhone()) {
        style = `@font-face {
  font-family: "Emojis Additional";
  src: url(${servePath}appearance/fonts/Noto-COLRv1-2.047/Noto-COLRv1.woff2) format("woff2");
  unicode-range: U+1fae9, U+1fac6, U+1fabe, U+1fadc, U+e50a, U+1fa89, U+1fadf, U+1f1e6-1f1ff, U+1fa8f;
}
@font-face {
  font-family: "Emojis Reset";
  src: local("Apple Color Emoji"),
  local("Segoe UI Emoji"),
  local("Segoe UI Symbol");
  unicode-range: U+21a9, U+21aa, U+2122, U+2194-2199, U+23cf, U+25b6, U+25c0, U+25fb, U+25fc, U+25aa, U+25ab, U+2600-2603,
  U+260e, U+2611, U+261d, U+2639, U+263a, U+2640, U+2642, U+2660, U+2663, U+2665, U+2666, U+2668, U+267b, U+26aa, U+26ab, 
  U+2702, U+2708, U+2934, U+2935, U+1f170, U+1f171, U+1f17e, U+1f17f, U+1f202, U+1f21a, U+1f22f, U+1f232-1f23a, U+1f250, 
  U+1f251, U+1fae4, U+2049, U+203c, U+3030, U+303d, U+24c2, U+26a0, U+26a1, U+26be, U+27a1, U+2b05-2b07, U+3297, U+3299, U+a9, U+ae,
  ${DEJAVU_EMOJI_PRESENTATION_UNICODE_RANGE};
  size-adjust: 115%;
}
@font-face {
  font-family: "Emojis";
  src: local("Apple Color Emoji"),
  local("Segoe UI Emoji"),
  local("Segoe UI Symbol");
  size-adjust: 115%;
}`;
    } else if (await isWin11()) {
        // Win11 Browser
        style = `@font-face {
  font-family: "Emojis Additional";
  src: url(${servePath}appearance/fonts/Noto-COLRv1-2.047/Noto-COLRv1.woff2) format("woff2");
  unicode-range: U+1fae9, U+1fac6, U+1fabe, U+1fadc, U+e50a, U+1fa89, U+1fadf, U+1f1e6-1f1ff, U+1f3f4, U+e0067, U+e0062,
  U+e0065, U+e006e, U+e007f, U+e0073, U+e0063, U+e0074, U+e0077, U+e006c;
  size-adjust: 85%;
}
@font-face {
  font-family: "Emojis Reset";
  src: local("Segoe UI Emoji"),
  local("Segoe UI Symbol");
  unicode-range: U+263a, U+21a9, U+2642, U+303d, U+2197, U+2198, U+2199, U+2196, U+2195, U+2194, U+2660, U+2665, U+2666,
  U+2663, U+3030, U+21aa, U+25b6, U+25c0, U+2640, U+203c, U+a9, U+ae, U+2122, ${DEJAVU_EMOJI_PRESENTATION_UNICODE_RANGE};
  size-adjust: 85%;
}
@font-face {
  font-family: "Emojis";
  src: local("Segoe UI Emoji"),
  local("Segoe UI Symbol");
  size-adjust: 85%;
}`;
    } else {
        style = `@font-face {
  font-family: "Emojis Reset";
  src: url(${servePath}appearance/fonts/Noto-COLRv1-2.047/Noto-COLRv1.woff2) format("woff2");
  unicode-range: U+1f170-1f171, U+1f17e, U+1f17f, U+1f21a, U+1f22f, U+1f232-1f23a, U+1f250, U+1f251, U+1f32b, U+1f3bc,
  U+1f411, U+1f42d, U+1f42e, U+1f431, U+1f435, U+1f441, U+1f4a8, U+1f4ab, U+1f525, ${DEJAVU_EMOJI_PRESENTATION_UNICODE_RANGE},
  U+1f79, U+1f8f, U+1fa79, U+1fae4, U+1fae9, U+1fac6, U+1fabe, U+1fadf,
  U+200d, U+203c, U+2049, U+2122, U+2139, U+2194-2199, U+21a9, U+21aa, U+23cf, U+25aa, U+25ab, U+25b6, U+25c0, U+25fb-25fe,
  U+2611, U+2615, U+2618, U+261d, U+2620, U+2622, U+2623, U+2626, U+262a, U+262e, U+2638-263a, U+2640, U+2642, U+2648-2653,
  U+265f, U+2660, U+2663, U+2665, U+2666, U+267b, U+267e, U+267f, U+2692-2697, U+2699, U+269b, U+269c, U+26a0, U+26a1,
  U+26a7, U+26aa, U+26ab, U+26b0, U+26b1, U+2702, U+2708, U+2709, U+270c, U+270d, U+2712, U+2714, U+2716, U+271d, U+2733,
  U+2734, U+2744, U+2747, U+2763, U+2764, U+2934-2935, U+3030, U+303d, U+3297, U+3299, U+fe0f, U+e50a, U+a9, U+ae;
  size-adjust: 92%;
}
@font-face {
  font-family: "Emojis";
  src: url(${servePath}appearance/fonts/Noto-COLRv1-2.047/Noto-COLRv1.woff2) format("woff2"),
  local("Segoe UI Emoji"),
  local("Segoe UI Symbol"),
  local("Apple Color Emoji"),
  local("Twemoji Mozilla"),
  local("Noto Color Emoji"),
  local("Android Emoji"),
  local("EmojiSymbols");
  size-adjust: 92%;
}`;
    }
    const editorFontFamilies = editorFonts.map((font) => CSS.escape(font.family)).join(", ");
    const editorFontWeight = editorFonts[0]?.weight;
    const codeFontFamilies = codeFonts.map((font) => CSS.escape(font.family)).join(", ");
    const codeFontFamily = codeFontFamilies ?
        `"Emojis Additional", "Emojis Reset", ${codeFontFamilies}, var(--b3-font-family-code)` :
        "var(--b3-font-family-code)";
    const codeFontWeight = codeFonts[0]?.weight || 400;
    style += `\n:root { --b3-font-size-editor: ${window.siyuan.config.editor.fontSize}px; --b3-font-family-editor: ${editorFontFamilies || "var(--b3-font-family-protyle)"}; --b3-font-family-editor-code: ${codeFontFamily}; --b3-font-weight-editor-code: ${codeFontWeight} }
.b3-typography code:not(.hljs), .protyle-wysiwyg span[data-type~=code] { font-variant-ligatures: ${window.siyuan.config.editor.codeLigatures ? "normal" : "none"} }
.b3-typography:not(.b3-typography--default) code:not(.hljs), .protyle-wysiwyg span[data-type~=code] { font-family: var(--b3-font-family-editor-code); font-weight: var(--b3-font-weight-editor-code) }${window.siyuan.config.editor.justify ? "\n.protyle-wysiwyg [data-node-id] { text-align: justify }" : ""}`;
    if (editorFontFamilies) {
        style += `\n.b3-typography:not(.b3-typography--default), .protyle-wysiwyg, .protyle-title {${editorFontWeight ? `font-weight: ${editorFontWeight};` : ""}font-family: "Emojis Additional", "Emojis Reset", var(--b3-font-family-editor), var(--b3-font-family)}`;
    }
    // pad 端菜单移除显示，如工作空间
    if ("ontouchend" in document) {
        style += "\n.b3-menu .b3-menu__action {opacity: 0.68;}";
    }
    style += inlineStylesCSS ? "\n" + inlineStylesCSS : "";
    if (set) {
        const siyuanStyle = document.getElementById("siyuanStyle");
        if (siyuanStyle) {
            siyuanStyle.innerHTML = style;
        } else {
            const pluginsStyle = document.getElementById("pluginsStyle");
            if (pluginsStyle) {
                pluginsStyle.insertAdjacentHTML("beforebegin", `<style id="siyuanStyle">${style}</style>`);
            } else {
                document.head.insertAdjacentHTML("beforeend", `<style id="siyuanStyle">${style}</style>`);
            }
        }
    }
    return style;
};

export const reloadInlineStyles = async () => {
    try {
        await loadInlineStyles(true);
    } catch (error) {
        console.error("reload inline styles error: " + error);
    }
    await setInlineStyle();
};

export const setMode = (modeElementValue: number) => {
    /// #if !MOBILE
    let mode = modeElementValue;
    if (modeElementValue === 2) {
        if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
            mode = 1;
        } else {
            mode = 0;
        }
    }
    fetchPost("/api/setting/setAppearance", {
        ...window.siyuan.config.appearance,
        mode,
        modeOS: modeElementValue === 2,
    });
    /// #endif
};

const padHex = (n: number) => (n | 256).toString(16).slice(1);

const rgbaToHex = (rgba: string) => {
    const rgb = rgba.replace(/\s/g, "").match(/^rgba?\((\d+),(\d+),(\d+)(?:,([^)]+))?\)$/i);
    if (!rgb) {
        return "";
    }
    const alpha = rgb[4] !== undefined ? parseFloat(rgb[4]) : 1;
    if (alpha === 0) {
        return "";
    }
    return "#" +
        padHex(parseInt(rgb[1], 10)) +
        padHex(parseInt(rgb[2], 10)) +
        padHex(parseInt(rgb[3], 10)) +
        padHex(Math.round(alpha * 255));
};

const cssVarToRgba = (varName: string) => {
    const probe = document.createElement("div");
    probe.style.display = "none";
    probe.style.backgroundColor = `var(${varName})`;
    document.documentElement.appendChild(probe);
    const rgba = getComputedStyle(probe).backgroundColor;
    probe.remove();
    return rgba;
};

const updateMobileTheme = (OSTheme: string) => {
    if (isInMobileApp()) {
        setTimeout(() => {
            let mode = window.siyuan.config.appearance.mode;
            if (window.siyuan.config.appearance.modeOS) {
                if (OSTheme === "dark") {
                    mode = 1;
                } else {
                    mode = 0;
                }
            }
            const fallback = mode === 0 ? "#ffffffff" : "#1e1e1eff";
            const backgroundColor = rgbaToHex(cssVarToRgba("--b3-theme-background")) || fallback;
            // 统一传 #RRGGBBAA：iOS 按 #RRGGBBAA 解析，Android / Harmony 将 #RRGGBBAA 转为 #AARRGGBB
            if (isInIOS()) {
                window.webkit.messageHandlers.changeStatusBar.postMessage(backgroundColor + " " + mode);
            } else if (isInAndroid()) {
                window.JSAndroid.changeStatusBarColor(backgroundColor, mode);
            } else if (isInHarmony()) {
                window.JSHarmony.changeStatusBarColor(backgroundColor, mode);
            }
        }, 500); // 移动端需要加载完才可以获取到颜色
    }
};

export const getThemeMode = () => {
    const OSTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    if (window.siyuan.config.appearance.modeOS) {
        return OSTheme;
    } else {
        return window.siyuan.config.appearance.mode === 0 ? "light" : "dark";
    }
};

export const setBodyHighlight = () => {
    const name = getWorkspaceName();
    if (!name) {
        return;
    }

    // 预定义颜色：赤橙黄绿青蓝紫（提高饱和度和亮度）
    const colors = [
        {h: 0, s: 85, l: 50},    // 赤 - 鲜艳红
        {h: 30, s: 90, l: 52},   // 橙 - 亮橙色
        {h: 50, s: 88, l: 50},   // 黄 - 金黄色
        {h: 140, s: 80, l: 48},  // 绿 - 翠绿色
        {h: 185, s: 85, l: 50},  // 青 - 亮青色
        {h: 230, s: 82, l: 52},  // 蓝 - 宝蓝色
        {h: 280, s: 85, l: 50},  // 紫 - 亮紫色
    ];

    let hue, saturation, lightness;

    if (name === "SiYuan") {
        // SiYuan 专用：更艳丽的紫色
        hue = 280;
        saturation = 85;
        lightness = 48;
    } else {
        // 根据工作空间名生成稳定的索引
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = (hash << 5) - hash + name.charCodeAt(i);
            hash |= 0;
        }

        const index = Math.abs(hash) % colors.length;
        const color = colors[index];
        hue = color.h;
        saturation = color.s;
        lightness = color.l;
    }

    document.documentElement.style.setProperty(
        "--b3-body-background-hl",
        `${hue}, ${saturation}%, ${lightness}%`
    );
};
