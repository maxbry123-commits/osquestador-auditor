import {hasClosestByAttribute} from "../util/hasClosest";
import {fetchPost, fetchSyncPost} from "../../util/fetch";
import {processRender} from "../util/processCode";
import {highlightRender} from "./highlightRender";
import {genBreadcrumb, improveBreadcrumbAppearance} from "../wysiwyg/renderBacklink";
import {avRender} from "./av/render";
import {genRenderFrame} from "./util";
import {isEncryptedBox} from "../../util/pathName";
import {disabledWYSIWYG} from "../util/disabledWYSIWYG";
import {normalizeHTMLAssetIFrameBlockDOM} from "../../asset/html";
import {finishCustomEmbedRender, finishEmptyEmbedRender, IEmbedRenderLoadingState} from "./embedRenderState";

/**
 * 渲染嵌入块
 * onEmbedRender 在每个异步查询结果写入 DOM 后调用。
 */
export const blockRender = (protyle: IProtyle, element: Element, top?: number, onEmbedRender?: () => void) => {
    let blockElements: Element[] = [];
    if (element.getAttribute("data-type") === "NodeBlockQueryEmbed" && element.getAttribute("data-render") !== "true") {
        blockElements = [element];
    } else {
        blockElements = Array.from(element.querySelectorAll('[data-type="NodeBlockQueryEmbed"]:not([data-render="true"])'));
    }
    if (blockElements.length === 0) {
        return;
    }
    blockElements.forEach((item: HTMLElement) => {
        const content = Lute.UnEscapeHTMLStr(item.getAttribute("data-content"));
        if (!content.trim()) {
            genRenderFrame(item);
            finishEmptyEmbedRender(item, onEmbedRender);
            return;
        }
        // 需置于请求返回前，否则快速滚动会导致重复加载 https://ld246.com/article/1666857862494?r=88250
        item.setAttribute("data-render", "true");
        genRenderFrame(item);
        const loadingState: IEmbedRenderLoadingState = {
            rotateElement: item.querySelector(":scope > .protyle-icons .protyle-action__reload .fn__rotate"),
        };
        if (item.childElementCount > 3) {
            loadingState.height = (item.clientHeight - 4) + "px";
            item.style.height = loadingState.height; // 减少抖动 https://ld246.com/article/1668669380171
            for (let i = 1; i < item.children.length - 1; i++) {
                if (!item.children[i].classList.contains("protyle-cursor")) {
                    item.children[i].remove();
                    i--;
                }
            }
        }
        let breadcrumb: boolean | string = item.getAttribute("breadcrumb");
        if (breadcrumb) {
            breadcrumb = breadcrumb === "true";
        } else {
            breadcrumb = window.siyuan.config.editor.embedBlockBreadcrumb;
        }

        if (content.startsWith("//!js")) {
            // 安全模式下禁用 JS 查询嵌入块，与代码片段（CSS/JS snippet）的处理保持一致
            if (window.siyuan.config.system.safeMode) {
                renderEmbed([], protyle, item, top, window.siyuan.languages.safeModeJSTip, onEmbedRender);
                return;
            }
            const renderError = (error: unknown) => {
                console.error(error);
                renderEmbed([], protyle, item, top, String(error), onEmbedRender);
            };
            try {
                const includeIDsPromise = new Function(
                    "fetchSyncPost",
                    "item",
                    "protyle",
                    "top",
                    `return (async () => {
${content}
})();`)(fetchSyncPost, item, protyle, top);
                includeIDsPromise.then((includeIDs: unknown) => {
                    if (!Array.isArray(includeIDs)) {
                        finishCustomEmbedRender(item, loadingState, onEmbedRender);
                        return;
                    }
                    fetchPost("/api/search/getEmbedBlock", {
                        embedBlockID: item.getAttribute("data-node-id"),
                        includeIDs,
                        headingMode: ["0", "1", "2"].includes(item.getAttribute("custom-heading-mode")) ? parseInt(item.getAttribute("custom-heading-mode")) : window.siyuan.config.editor.headingEmbedMode,
                        breadcrumb,
                        notebook: isEncryptedBox(protyle.notebookId) ? protyle.notebookId : ""
                    }, (response) => {
                        renderEmbed(response.data.blocks || [], protyle, item, top, undefined, onEmbedRender);
                    });
                }).catch(renderError);
            } catch (e) {
                renderError(e);
            }
        } else {
            fetchPost("/api/search/searchEmbedBlock", {
                embedBlockID: item.getAttribute("data-node-id"),
                stmt: content,
                headingMode: ["0", "1", "2"].includes(item.getAttribute("custom-heading-mode")) ? parseInt(item.getAttribute("custom-heading-mode")) : window.siyuan.config.editor.headingEmbedMode,
                excludeIDs: [item.getAttribute("data-node-id"), protyle.block.rootID],
                breadcrumb,
                notebook: isEncryptedBox(protyle.notebookId) ? protyle.notebookId : ""
            }, (response) => {
                renderEmbed(response.data.blocks, protyle, item, top, undefined, onEmbedRender);
            });
        }
    });
};

const renderEmbed = (blocks: {
    block: IBlock,
    blockPaths: IBreadcrumb[],
    allowChildOperation: boolean
}[], protyle: IProtyle, item: HTMLElement, top?: number, errorTip?: string, onEmbedRender?: () => void) => {
    const rotateElement = item.querySelector(".fn__rotate");
    if (rotateElement) {
        rotateElement.classList.remove("fn__rotate");
    }
    let html = "";
    blocks.forEach((blocksItem, index) => {
        let breadcrumbHTML = "";
        if (blocksItem.blockPaths.length !== 0) {
            breadcrumbHTML = genBreadcrumb(blocksItem.blockPaths, true);
        }
        let popover = "";
        if (index !== 0) {
            popover = `<div class="protyle-icons"><span data-id="${blocksItem.block.id}" data-action="openFloat" aria-label="${window.siyuan.languages.refPopover}" data-position="4north" class="ariaLabel protyle-icon protyle-icon--last protyle-icon--first"><svg><use xlink:href="#iconPictureInPicture"></use></svg></span></div>`;
        } else {
            const popoverElement = item.querySelectorAll(".protyle-icon")[2];
            if (popoverElement) {
                popoverElement.setAttribute("data-id", blocksItem.block.id);
            }
        }
        const childOperationAttr = blocksItem.allowChildOperation ? " data-allow-child-operation=\"true\"" : "";
        const rootIDAttr = blocksItem.block.rootID ? ` data-root-id="${blocksItem.block.rootID}"` : "";
        html += `<div class="protyle-wysiwyg__embed" data-id="${blocksItem.block.id}"${rootIDAttr}${childOperationAttr}>
${popover}${breadcrumbHTML}${blocksItem.block.content}
</div>`;
    });
    if (blocks.length > 0) {
        item.firstElementChild.insertAdjacentHTML("afterend", normalizeHTMLAssetIFrameBlockDOM(html));
        improveBreadcrumbAppearance(item.querySelector(".protyle-wysiwyg__embed"));
    } else {
        item.firstElementChild.insertAdjacentHTML("afterend", `<div class="protyle-wysiwyg__embed ft__smaller ft__secondary b3-form__space--small" contenteditable="false">${errorTip || window.siyuan.languages.refExpired}</div>`);
    }

    processRender(item);
    highlightRender(item);
    avRender(item, protyle);
    if (protyle.disabled) {
        // 嵌入块异步渲染可能晚于只读状态设置，需同步禁用新插入的可编辑节点
        disabledWYSIWYG(item);
    }
    if (top) {
        // 前进后退定位 https://ld246.com/article/1667652729995
        protyle.contentElement.scrollTop = top;
    }
    let maxDeep = 0;
    let deepEmbedElement: false | HTMLElement = item;
    while (maxDeep < 4 && deepEmbedElement) {
        deepEmbedElement = hasClosestByAttribute(deepEmbedElement.parentElement, "data-type", "NodeBlockQueryEmbed");
        maxDeep++;
    }
    if (maxDeep < 4) {
        item.querySelectorAll('[data-type="NodeBlockQueryEmbed"]').forEach(embedElement => {
            blockRender(protyle, embedElement, undefined, onEmbedRender);
        });
    }
    item.style.height = "";
    onEmbedRender?.();
};
