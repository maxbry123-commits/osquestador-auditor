import {newDailyNote} from "../../../util/mount";
import {openHistory} from "../../../history/history";
import type {Editor} from "../../../editor";
/// #if MOBILE
import {openDock} from "../../../mobile/dock/util";
import {popMenu} from "../../../mobile/menu";
import {popSearch} from "../../../mobile/menu/search";
import {getRecentDocs} from "../../../mobile/menu/getRecentDocs";
/// #else
import {openNewWindow} from "../../../window/openNewWindow";
import {openBacklink, openGraph, openOutline, selectOpenTab, toggleDockBar} from "../../../layout/dock/util";
import {openGlobalSearch} from "../../../search/util";
import {workspaceMenu} from "../../../menus/workspace";
import {isWindow} from "../../../util/functions";
import {openRecentDocs} from "../../../business/openRecentDocs";
import {openSearch} from "../../../search/spread";
import {goBack, goForward} from "../../../util/backForward";
import {getAllTabs} from "../../../layout/getAll";
import {getInstanceById} from "../../../layout/util";
import {
    closeTabByType,
    copyTab,
    getActiveTab,
    getDockByType,
    resizeTabs,
    switchTabByIndex
} from "../../../layout/tabUtil";
import {openSetting} from "../../../config";
import {Tab} from "../../../layout/Tab";
/// #endif
/// #if !BROWSER
import {ipcRenderer} from "electron";
/// #endif
import type {App} from "../../../index";
import {Constants} from "../../../constants";
import {editorConfigApi} from "../../../config/tabs/editorRuntime";
import {lockScreen} from "../../../dialog/processSystem";
import {newFile} from "../../../util/newFile";
import {openCard} from "../../../card/openCard";
import {syncGuide} from "../../../sync/syncGuide";
import {unsplitCurrentWnd, unsplitWnd} from "../../../menus/tab";
import {openFile} from "../../../editor/util";
import {fetchPost} from "../../../util/fetch";
import {sanitizeClosedTabs, setStorageVal} from "../../../protyle/util/compatibility";

export const globalCommand = (command: string, app: App) => {
    /// #if MOBILE
    switch (command) {
        case "fileTree":
            openDock("file");
            return true;
        case "outline":
        case "bookmark":
        case "tag":
        case "inbox":
            openDock(command);
            return true;
        case "backlinks":
            openDock("backlink");
            return true;
        case "mainMenu":
            popMenu();
            return true;
        case "globalSearch":
            popSearch(app);
            return true;
        case "recentDocs":
            getRecentDocs(app);
            return true;
    }
    /// #else
    switch (command) {
        case "fileTree":
            getDockByType("file").toggleModel("file");
            return true;
        case "outline":
            getDockByType("outline").toggleModel("outline");
            return true;
        case "bookmark":
        case "tag":
        case "inbox":
            getDockByType(command).toggleModel(command);
            return true;
        case "backlinks":
            getDockByType("backlink").toggleModel("backlink");
            return true;
        case "graphView":
            getDockByType("graph").toggleModel("graph");
            return true;
        case "globalGraph":
            getDockByType("globalGraph").toggleModel("globalGraph");
            return true;
        case "config":
            openSetting(app);
            return true;
        case "globalSearch":
            openSearch({
                app,
                hotkey: Constants.DIALOG_GLOBALSEARCH,
                key: (getSelection().rangeCount > 0 ? getSelection().getRangeAt(0) : document.createRange()).toString()
            });
            return true;
        case "stickSearch":
            openGlobalSearch(app, (getSelection().rangeCount > 0 ? getSelection().getRangeAt(0) : document.createRange()).toString(), true);
            return true;
        case "goBack":
            goBack(app);
            return true;
        case "goForward":
            goForward(app);
            return true;
        case "goToTab1":
            switchTabByIndex(0);
            return true;
        case "goToTab2":
            switchTabByIndex(1);
            return true;
        case "goToTab3":
            switchTabByIndex(2);
            return true;
        case "goToTab4":
            switchTabByIndex(3);
            return true;
        case "goToTab5":
            switchTabByIndex(4);
            return true;
        case "goToTab6":
            switchTabByIndex(5);
            return true;
        case "goToTab7":
            switchTabByIndex(6);
            return true;
        case "goToTab8":
            switchTabByIndex(7);
            return true;
        case "goToTab9":
            switchTabByIndex(-1);
            return true;
        case "goToTabNext":
            switchTabByIndex(-3);
            return true;
        case "goToTabPrev":
            switchTabByIndex(-2);
            return true;
        case "mainMenu":
            if (!isWindow()) {
                workspaceMenu(app, document.querySelector("#barWorkspace").getBoundingClientRect());
            }
            return true;
        case "recentDocs":
            openRecentDocs();
            return true;
        case "recentClosed": {
            const closedTabsLength = window.siyuan.storage[Constants.LOCAL_CLOSED_TABS].length;
            window.siyuan.storage[Constants.LOCAL_CLOSED_TABS] =
                sanitizeClosedTabs(window.siyuan.storage[Constants.LOCAL_CLOSED_TABS]);
            if (closedTabsLength !== window.siyuan.storage[Constants.LOCAL_CLOSED_TABS].length) {
                setStorageVal(Constants.LOCAL_CLOSED_TABS, window.siyuan.storage[Constants.LOCAL_CLOSED_TABS]);
            }
            if (window.siyuan.storage[Constants.LOCAL_CLOSED_TABS].length > 0) {
                const closeData = window.siyuan.storage[Constants.LOCAL_CLOSED_TABS].pop();
                setStorageVal(Constants.LOCAL_CLOSED_TABS, window.siyuan.storage[Constants.LOCAL_CLOSED_TABS]);
                const childData = closeData.children as ILayoutJSON;
                if (childData.instance === "Search") {
                    openFile({
                        app,
                        searchData: childData.config,
                    });
                    return true;
                }
                if (childData.instance === "Asset") {
                    fetchPost("/api/asset/statAsset", {path: childData.path}, (response) => {
                        if (response.code !== 1) {
                            openFile({
                                app,
                                assetPath: childData.path,
                                page: childData.page,
                            });
                        }
                    });
                    return true;
                }
                if (childData.instance === "Custom") {
                    let exit = childData.customModelType === "siyuan-card";
                    if (!exit) {
                        app.plugins.find(p => {
                            if (p.models[childData.customModelType]) {
                                exit = true;
                                return true;
                            }
                        });
                    }
                    if (exit) {
                        openFile({
                            app,
                            custom: {
                                icon: closeData.icon,
                                title: closeData.title,
                                data: childData.customModelData,
                                id: childData.customModelType
                            },
                        });
                    }
                    return true;
                }
                fetchPost("/api/block/getBlockInfo", {id: childData.rootId || childData.blockId}, (infoResponse) => {
                    if (infoResponse.data.rootID === (childData.rootId || childData.blockId)) {
                        if (childData.instance === "Editor") {
                            openFile({
                                app,
                                fileName: closeData.title,
                                id: childData.blockId,
                                rootID: childData.rootId,
                                mode: childData.mode,
                                rootIcon: closeData.docIcon,
                                action: [childData.action]
                            });
                        } else if (childData.instance === "Backlink") {
                            openBacklink({
                                app,
                                blockId: childData.blockId,
                                rootId: childData.rootId,
                                notebookId: childData.notebookId,
                                title: closeData.title,
                            });
                        } else if (childData.instance === "Graph") {
                            openGraph({
                                app,
                                blockId: childData.blockId,
                                rootId: childData.rootId,
                                notebookId: childData.notebookId,
                                title: closeData.title
                            });
                        } else if (childData.instance === "Outline") {
                            openOutline({
                                app,
                                rootId: childData.blockId,
                                notebookId: childData.notebookId,
                                title: closeData.title,
                                isPreview: childData.isPreview
                            });
                        }
                    }
                });
            }
            return true;
        }
        case "toggleDock":
            toggleDockBar(document.querySelector("#barDock use"));
            return true;
        case "switchLeftDock":
            window.siyuan.layout.leftDock.togglePin();
            return true;
        case "switchRightDock":
            window.siyuan.layout.rightDock.togglePin();
            return true;
        case "switchBottomDock":
            window.siyuan.layout.bottomDock.togglePin();
            return true;
        case "toggleWin":
            /// #if !BROWSER
            ipcRenderer.send(Constants.SIYUAN_CMD, "hide");
            ipcRenderer.send(Constants.SIYUAN_CMD, "minimize");
            /// #endif
            return true;
    }
    if (command === "goToEditTabNext" || command === "goToEditTabPrev") {
        let currentTabElement = document.querySelector(".layout__wnd--active ul.layout-tab-bar > .item--focus");
        if (!currentTabElement) {
            currentTabElement = document.querySelector("ul.layout-tab-bar > .item--focus");
        }
        if (!currentTabElement) {
            return true;
        }
        const tabs = getAllTabs().sort((itemA, itemB) => {
            return itemA.headElement.getAttribute("data-activetime") > itemB.headElement.getAttribute("data-activetime") ? -1 : 1;
        });
        const currentId = currentTabElement.getAttribute("data-id");
        tabs.find((item, index) => {
            if (currentId === item.id) {
                let newItem: Tab;
                if (command === "goToEditTabPrev") {
                    if (index === 0) {
                        newItem = tabs[tabs.length - 1];
                    } else {
                        newItem = tabs[index - 1];
                    }
                } else {
                    if (index === tabs.length - 1) {
                        newItem = tabs[0];
                    } else {
                        newItem = tabs[index + 1];
                    }
                }
                const tab = getInstanceById(newItem.id) as Tab;
                tab.parent.switchTab(newItem.headElement);
                tab.parent.showHeading();
            }
        });
        return true;
    }
    if (command === "closeUnmodified") {
        const tab = getActiveTab(false);
        if (tab) {
            const unmodifiedTabs: Tab[] = [];
            tab.parent.children.forEach((item: Tab) => {
                const editor = item.model as Editor;
                if (!editor || (editor.editor?.protyle && !editor.editor?.protyle.updated)) {
                    unmodifiedTabs.push(item);
                }
            });
            if (unmodifiedTabs.length > 0) {
                closeTabByType(tab, "other", unmodifiedTabs);
            }
        }
        return true;
    }
    if (command === "unsplitAll") {
        unsplitWnd(window.siyuan.layout.centerLayout, window.siyuan.layout.centerLayout);
        return true;
    }
    if (command === "unsplit") {
        const tab = getActiveTab(false);
        if (tab) {
            unsplitCurrentWnd(tab.parent);
            resizeTabs();
        }
        return true;
    }
    if (command === "closeTab") {
        const activeTabElement = document.querySelector(".layout__tab--active");
        if (activeTabElement && activeTabElement.getBoundingClientRect().width > 0) {
            let type: TDock;
            Array.from(activeTabElement.classList).find(item => {
                if (item.startsWith("sy__")) {
                    type = item.replace("sy__", "") as TDock;
                    return true;
                }
            });
            if (type) {
                getDockByType(type)?.toggleModel(type, false, true);
            }
            return true;
        }

        const tab = getActiveTab();
        if (tab) {
            tab.parent.removeTab(tab.id);
            return true;
        }
        // https://github.com/siyuan-note/siyuan/issues/14729
        if (window.siyuan.blockPanels.length > 0) {
            window.siyuan.blockPanels[window.siyuan.blockPanels.length - 1]?.destroy();
            return true;
        }
        const noFocusTab = getActiveTab(false);
        if (noFocusTab) {
            noFocusTab.parent.removeTab(noFocusTab.id);
            return true;
        }
    }
    if (command === "closeOthers" || command === "closeAll") {
        const tab = getActiveTab(false);
        if (tab) {
            closeTabByType(tab, command);
        }
        return true;
    }
    if (command === "closeLeft" || command === "closeRight") {
        const tab = getActiveTab(false);
        if (tab) {
            const leftTabs: Tab[] = [];
            const rightTabs: Tab[] = [];
            let midIndex = -1;
            tab.parent.children.forEach((item: Tab, index: number) => {
                if (item.id === tab.id) {
                    midIndex = index;
                }
                if (midIndex === -1) {
                    leftTabs.push(item);
                } else if (index > midIndex) {
                    rightTabs.push(item);
                }
            });
            if (command === "closeLeft") {
                if (leftTabs.length > 0) {
                    closeTabByType(tab, "other", leftTabs);
                }
            } else {
                if (rightTabs.length > 0) {
                    closeTabByType(tab, "other", rightTabs);
                }
            }
        }
        return true;
    }
    if (command === "splitLR") {
        const tab = getActiveTab(false);
        if (tab) {
            tab.parent.split("lr").addTab(copyTab(app, tab));
        }
        return true;
    }
    if (command === "splitTB") {
        const tab = getActiveTab(false);
        if (tab) {
            tab.parent.split("tb").addTab(copyTab(app, tab));
        }
        return true;
    }
    if (command === "splitMoveB" || command === "splitMoveR") {
        const tab = getActiveTab(false);
        if (tab && tab.parent.children.length > 1) {
            const newWnd = tab.parent.split(command === "splitMoveB" ? "tb" : "lr");
            newWnd.headersElement.append(tab.headElement);
            newWnd.headersElement.parentElement.classList.remove("fn__none");
            newWnd.moveTab(tab);
            resizeTabs();
        }
        return true;
    }
    if (command === "tabToWindow") {
        const tab = getActiveTab(false);
        if (tab) {
            openNewWindow(tab);
        }
        return true;
    }
    /// #endif

    switch (command) {
        case "dailyNote":
            newDailyNote(app);
            return true;
        case "dataHistory":
            openHistory(app);
            return true;
        case "editReadonly":
            editorConfigApi.patch("editor.readOnly", !window.siyuan.config.editor.readOnly);
            return true;
        case "lockScreen":
            lockScreen(app);
            return true;
        case "newFile":
            newFile(app);
            return true;
        case "riffCard":
            openCard(app);
            return true;
        case "selectOpen1":
            selectOpenTab();
            return true;
        case "syncNow":
            syncGuide(app);
            return true;
    }

    return false;
};
