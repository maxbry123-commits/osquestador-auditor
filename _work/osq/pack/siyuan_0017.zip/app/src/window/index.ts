import {Constants} from "../constants";
import {Menus} from "../menus";
import {Model} from "../layout/Model";
import "../assets/scss/base.scss";
import {initBlockPopover} from "../block/popover";
import {addScript, addScriptSync} from "../protyle/util/addScript";
import {genUUID} from "../util/genID";
import {fetchGet, fetchPost} from "../util/fetch";
import {addBaseURL, getDocDisplayName, redirectToCheckAuth, setNoteBook} from "../util/pathName";
import {openFileById} from "../editor/util";
import {
    processSync,
    progressBackgroundTask,
    progressLoading,
    progressStatus,
    processBacklinkIndexCommit,
    setDefRefCount,
    setRefDynamicText,
    transactionError
} from "../dialog/processSystem";
import {initMessage} from "../dialog/message";
import {getAllTabs} from "../layout/getAll";
import {getLocalStorage} from "../protyle/util/compatibility";
import {init} from "./init";
import {loadPlugins, reloadPlugin} from "../plugin/loader";
import {hideAllElements} from "../protyle/ui/hideElements";
import {reloadEmoji} from "../emoji";
import {appearanceConfigApi} from "../config/tabs/appearanceRuntime";
import {renderSnippet} from "../config/util/snippets";
import {refreshThemeStyle, setBodyHighlight} from "../util/assets";
import {reloadSync} from "../util/reloadSync";
import {setTitle} from "../util/processTitle";
import {ensureUILayout} from "../util/ensureUILayout";
import {applyEntryVisibility} from "../config/entryVisibility/runtime";
import {removeBlockPanelEditors} from "../block/panelRemoval";

class App {
    public plugins: import("../plugin").Plugin[] = [];
    public appId: string;

    constructor() {
        addBaseURL();
        this.appId = Constants.SIYUAN_APPID;

        const mainWs = new Model({app: this});
        mainWs.connect({
            id: genUUID(),
            type: "main",
            msgCallback: (data) => {
                    this.plugins.forEach((plugin) => {
                        plugin.eventBus.emit("ws-main", data);
                    });
                    if (data) {
                        switch (data.cmd) {
                            case "logoutAuth":
                                redirectToCheckAuth();
                                break;
                            case "setAppearance":
                                appearanceConfigApi.apply(data.data);
                                break;
                            case "setEntryVisibility":
                                applyEntryVisibility(data.data);
                                break;
                            case "setSnippet":
                                window.siyuan.config.snippet = data.data;
                                renderSnippet();
                                break;
                            case "setDefRefCount":
                                setDefRefCount(data.data);
                                break;
                            case "databaseIndexCommit":
                                processBacklinkIndexCommit(data.data);
                                break;
                            case "setRefDynamicText":
                                setRefDynamicText(data.data);
                                break;
                            case "reloadPlugin":
                                reloadPlugin(this, data.data);
                                break;
                            case "reloadEmojiConf":
                                reloadEmoji();
                                break;
                            case "reloaddoc":
                                reloadSync(this, {upsertRootIDs: [data.data], removeRootIDs: []}, false, false, true);
                                break;
                            case "syncMergeResult":
                                reloadSync(this, data.data);
                                break;
                            case "readonly":
                                window.siyuan.config.editor.readOnly = data.data;
                                hideAllElements(["util"]);
                                break;
                            case "setConf":
                                window.siyuan.config = data.data;
                                break;
                            case "progress":
                                progressLoading(data);
                                break;
                            case "setLocalStorageVal":
                                if (window.siyuan.storage) {
                                    window.siyuan.storage[data.data.key] = data.data.val;
                                }
                                break;
                            case "setLocalStorageVals":
                                Object.keys(data.data.keyVals).forEach((k) => {
                                    window.siyuan.storage[k] = data.data.keyVals[k];
                                });
                                break;
                            case "removeLocalStorageVal":
                                delete window.siyuan.storage[data.data.key];
                                break;
                            case "removeLocalStorageVals":
                                data.data.keys.forEach((k: string) => {
                                    delete window.siyuan.storage[k];
                                });
                                break;
                            case "rename":
                                getAllTabs().forEach((tab) => {
                                    if (tab.headElement) {
                                        const initTab = tab.headElement.getAttribute("data-initdata");
                                        if (initTab) {
                                            const initTabData = JSON.parse(initTab);
                                            if (initTabData.instance === "Editor" && initTabData.rootId === data.data.id) {
                                                tab.updateTitle(getDocDisplayName(data.data.title, data.data.empty));
                                            }
                                        }
                                    }
                                });
                                break;
                            case "closeBox":
                            case "removeBox":
                                removeBlockPanelEditors({notebookId: data.data.box});
                                getAllTabs().forEach((tab) => {
                                    if (tab.headElement) {
                                        const initTab = tab.headElement.getAttribute("data-initdata");
                                        if (initTab) {
                                            const initTabData = JSON.parse(initTab);
                                            if (initTabData.instance === "Editor" && data.data.box === initTabData.notebookId) {
                                                tab.parent.removeTab(tab.id);
                                            }
                                        }
                                    }
                                });
                                break;
                            case "removeDoc":
                                removeBlockPanelEditors({rootIDs: data.data.ids});
                                getAllTabs().forEach((tab) => {
                                    if (tab.headElement) {
                                        const initTab = tab.headElement.getAttribute("data-initdata");
                                        if (initTab) {
                                            const initTabData = JSON.parse(initTab);
                                            if (initTabData.instance === "Editor" && data.data.ids.includes(initTabData.rootId)) {
                                                tab.parent.removeTab(tab.id);
                                            }
                                        }
                                    }
                                });
                                break;
                            case "statusbar":
                                progressStatus(data);
                                break;
                            case "txerr":
                                transactionError(data.msg);
                                break;
                            case "syncing":
                                processSync(data, this.plugins);
                                break;
                            case "backgroundtask":
                                progressBackgroundTask(data.data.tasks);
                                break;
                            case "refreshtheme":
                                refreshThemeStyle(data.data.theme);
                                break;
                            case "openFileById":
                                openFileById({app: this, id: data.data.id, action: [Constants.CB_GET_FOCUS]});
                                break;
                        }
                    }
                }
        });

        window.siyuan = {
            zIndex: 10,
            isReady: false,
            notebooks: [],
            reqIds: {},
            backStack: [],
            layout: {},
            dialogs: [],
            blockPanels: [],
            closedTabs: [],
            ctrlIsPressed: false,
            altIsPressed: false,
            ws: mainWs,
        };
        const notebookPromise = setNoteBook();
        fetchPost("/api/system/getConf", {}, async (response) => {
            addScriptSync(`${Constants.PROTYLE_CDN}/js/lute/lute.min.js?v=${Constants.SIYUAN_VERSION}`, "protyleLuteScript");
            addScript(`${Constants.PROTYLE_CDN}/js/protyle-html.js?v=${Constants.SIYUAN_VERSION}`, "protyleWcHtmlScript");
            window.siyuan.config = response.data.conf;
            ensureUILayout();
            setBodyHighlight();
            window.siyuan.isPublish = response.data.isPublish;
            await notebookPromise;
            await loadPlugins(this);
            getLocalStorage(() => {
                fetchGet(`/appearance/langs/${window.siyuan.config.appearance.lang}.json?v=${Constants.SIYUAN_VERSION}`, (lauguages: IObject) => {
                    window.siyuan.languages = lauguages;
                    window.siyuan.menus = new Menus(this);
                    fetchPost("/api/setting/getCloudUser", {}, async userResponse => {
                        window.siyuan.user = userResponse.data;
                        await init(this);
                        setTitle("", true);
                        initMessage();
                        window.siyuan.isReady = true;
                        mainWs.flushMainMessages();
                    });
                });
            });
        });
        initBlockPopover(this);
    }
}

new App();
