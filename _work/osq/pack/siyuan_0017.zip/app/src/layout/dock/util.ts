import {getAllDocks, getAllModels} from "../getAll";
import {Tab} from "../Tab";
import {Graph} from "./Graph";
import {Outline} from "./Outline";
import {fixWndFlex1, getInstanceById, getWndByLayout} from "../util";
import {getDockByType, resizeTabs, setTabPosition} from "../tabUtil";
import {Backlink} from "./Backlink";
import type {App} from "../../index";
import {Wnd} from "../Wnd";
import {fetchSyncPost} from "../../util/fetch";
import {Files} from "./Files";
import {Editor} from "../../editor";
import {Constants} from "../../constants";
import {getDocDisplayName, isEncryptedBox} from "../../util/pathName";
import {showMessage} from "../../dialog/message";
import {updateHotkeyTip} from "../../protyle/util/compatibility";
import {getDockHotkey} from "./hotkey";

export const openBacklink = async (options: {
    app: App,
    blockId: string,
    rootId?: string,
    notebookId?: string,
    title?: string,
    useBlockId?: boolean,
}) => {
    const backlink = getAllModels().backlink.find(item => {
        if (item.blockId === options.blockId && item.type === "local") {
            item.parent.parent.removeTab(item.parent.id);
            return true;
        }
    });
    if (backlink) {
        return;
    }
    let wnd: Wnd = undefined;
    const element = document.querySelector(".layout__wnd--active");
    if (element) {
        wnd = getInstanceById(element.getAttribute("data-id")) as Wnd;
    }
    if (!wnd) {
        wnd = getWndByLayout(window.siyuan.layout.centerLayout);
    }
    if (!options.rootId) {
        const response = await fetchSyncPost("/api/block/getDocInfo", {
            id: options.blockId,
            notebook: isEncryptedBox(options.notebookId) ? options.notebookId : undefined,
        });
        if (response.code === -1) {
            return;
        }
        options.rootId = response.data.rootID;
        options.useBlockId = response.data.rootID !== response.data.id;
        options.title = getDocDisplayName(response.data.name, response.data.ial[Constants.CUSTOM_SY_TITLE_EMPTY] === "true");
    } else if (!options.title) {
        const response = await fetchSyncPost("/api/block/getDocInfo", {
            id: options.blockId,
            notebook: isEncryptedBox(options.notebookId) ? options.notebookId : undefined,
        });
        if (response.code === -1) {
            return;
        }
        options.title = getDocDisplayName(response.data.name, response.data.ial[Constants.CUSTOM_SY_TITLE_EMPTY] === "true");
    }
    const newWnd = wnd.split("lr");
    newWnd.addTab(new Tab({
        icon: "iconLink",
        title: options.title,
        callback(tab: Tab) {
            tab.addModel(new Backlink({
                app: options.app,
                type: "local",
                tab,
                // 通过搜索打开的包含上下文，但不是缩放，因此需要传 rootID https://ld246.com/article/1666786639708
                blockId: options.useBlockId ? options.blockId : options.rootId,
                rootId: options.rootId,
                notebookId: options.notebookId,
            }));
        }
    }));
};

export const openGraph = async (options: {
    app: App,
    blockId: string,
    rootId?: string,
    notebookId?: string,
    title?: string,
    useBlockId?: boolean,
}) => {
    if (isEncryptedBox(options.notebookId)) {
        showMessage(window.siyuan.languages._kernel[313]);
        return;
    }
    const graph = getAllModels().graph.find(item => {
        if (item.blockId === options.blockId && item.type === "local") {
            item.parent.parent.removeTab(item.parent.id);
            return true;
        }
    });
    if (graph) {
        return;
    }
    let wnd: Wnd = undefined;
    const element = document.querySelector(".layout__wnd--active");
    if (element) {
        wnd = getInstanceById(element.getAttribute("data-id")) as Wnd;
    }
    if (!wnd) {
        wnd = getWndByLayout(window.siyuan.layout.centerLayout);
    }
    if (!options.rootId) {
        const response = await fetchSyncPost("/api/block/getDocInfo", {id: options.blockId});
        if (response.code === -1) {
            return;
        }
        options.rootId = response.data.rootID;
        options.useBlockId = response.data.rootID !== response.data.id;
        options.title = getDocDisplayName(response.data.name, response.data.ial[Constants.CUSTOM_SY_TITLE_EMPTY] === "true");
    } else if (!options.title) {
        const response = await fetchSyncPost("/api/block/getDocInfo", {id: options.blockId});
        if (response.code === -1) {
            return;
        }
        options.title = getDocDisplayName(response.data.name, response.data.ial[Constants.CUSTOM_SY_TITLE_EMPTY] === "true");
    }
    const newWnd = wnd.split("lr");
    newWnd.addTab(new Tab({
        icon: "iconGraph",
        title: options.title,
        callback(tab: Tab) {
            tab.addModel(new Graph({
                app: options.app,
                type: "local",
                tab,
                blockId: options.blockId,
                rootId: options.rootId,
                notebookId: options.notebookId,
            }));
        }
    }));
};

export const openOutline = async (options: {
    app: App,
    rootId: string,
    notebookId?: string,
    isPreview: boolean,
    title: string
}) => {
    const outlinePanel = getAllModels().outline.find(item => {
        if (item.blockId === options.rootId && item.type === "local") {
            item.parent.parent.removeTab(item.parent.id);
            return true;
        }
    });
    if (outlinePanel) {
        return;
    }
    let wnd: Wnd = undefined;
    const element = document.querySelector(".layout__wnd--active");
    if (element) {
        wnd = getInstanceById(element.getAttribute("data-id")) as Wnd;
    }
    if (!wnd) {
        wnd = getWndByLayout(window.siyuan.layout.centerLayout);
    }
    const newWnd = wnd.split("lr", false);

    if (!options.title) {
        const response = await fetchSyncPost("/api/block/getDocInfo", {
            id: options.rootId,
            notebook: isEncryptedBox(options.notebookId) ? options.notebookId : undefined,
        });
        options.title = getDocDisplayName(response.data.name, response.data.ial[Constants.CUSTOM_SY_TITLE_EMPTY] === "true");
    }
    newWnd.element.style.width = "200px";
    newWnd.element.classList.remove("fn__flex-1");
    fixWndFlex1(newWnd.parent);
    newWnd.addTab(new Tab({
        icon: "iconOutline",
        title: options.title,
        callback(tab: Tab) {
            tab.addModel(new Outline({
                app: options.app,
                type: "local",
                tab,
                blockId: options.rootId,
                notebookId: options.notebookId,
                isPreview: options.isPreview,
            }));
        }
    }), false, true);
};

export const resetFloatDockSize = () => {
    if (!window.siyuan.layout.leftDock.pin && window.siyuan.layout.leftDock.layout.element.style.opacity === "1") {
        window.siyuan.layout.leftDock.showDock(true);
    }
    if (!window.siyuan.layout.rightDock.pin && window.siyuan.layout.rightDock.layout.element.style.opacity === "1") {
        window.siyuan.layout.rightDock.showDock(true);
    }
    if (!window.siyuan.layout.bottomDock.pin && window.siyuan.layout.bottomDock.layout.element.style.opacity === "1") {
        window.siyuan.layout.bottomDock.showDock(true);
    }
};

export const updateDockHotkeys = () => {
    const docks = getAllDocks();
    docks.forEach((item) => {
        const hotkey = getDockHotkey(item);
        document.querySelectorAll<HTMLElement>(`.dock__item[data-type="${CSS.escape(item.type)}"]`).forEach((element) => {
            element.setAttribute("aria-label", `<span style='white-space:pre'>${element.dataset.title || ""} ${
                hotkey ? updateHotkeyTip(hotkey) : ""
            }${window.siyuan.languages.dockTip}</span>`);
        });
    });
};

export const toggleDockBar = (useElement: Element) => {
    const dockIsShow = useElement.getAttribute("xlink:href") === "#iconHideDock";
    if (dockIsShow) {
        useElement.setAttribute("xlink:href", "#iconDock");
    } else {
        useElement.setAttribute("xlink:href", "#iconHideDock");
    }
    window.siyuan.config.uiLayout.hideDock = dockIsShow;
    document.querySelectorAll(".dock").forEach(item => {
        if (dockIsShow) {
            item.classList.add("fn__none");
        } else if (item.querySelectorAll(".dock__item").length > 1) {
            item.classList.remove("fn__none");
        }
    });
    resizeTabs();
    resetFloatDockSize();
    adjustDockPadding();
    setTabPosition();
};

export const clearOBG = () => {
    const models = getAllModels();
    models.outline.find(item => {
        if (item.type === "pin") {
            if ("" === item.blockId) {
                return;
            }
            item.isPreview = false;
            item.update({data: [], msg: "", code: 0}, "");
            item.updateDocTitle();
        }
    });
    models.graph.forEach(item => {
        if (item.type !== "global") {
            if (item.type === "local") {
                return;
            }
            if ("" === item.blockId) {
                return;
            }
            item.blockId = "";
            item.graphData = undefined;
            item.onGraph(false);
        }
    });
    models.backlink.forEach(item => {
        if (item.type !== "pin") {
            return;
        }
        if ("" === item.blockId) {
            return;
        }
        item.saveStatus();
        item.blockId = "";
        item.render(undefined);
    });
};

export const selectOpenTab = async () => {
    const dockFile = getDockByType("file");
    if (!dockFile) {
        return false;
    }
    const files = dockFile.data.file as Files;
    const element = document.querySelector(".layout__wnd--active > .fn__flex > .layout-tab-bar > .item--focus") ||
        document.querySelector("ul.layout-tab-bar > .item--focus");
    if (element) {
        const tab = getInstanceById(element.getAttribute("data-id")) as Tab;
        if (tab && tab.model instanceof Editor) {
            tab.model.editor.protyle.wysiwyg.element.blur();
            tab.model.editor.protyle.title.editElement.blur();
            await files.selectItem(tab.model.editor.protyle.notebookId, tab.model.editor.protyle.path);
            files.lastSelectedElement = files.element.querySelector(".b3-list-item--focus");
        }
    }
    dockFile.toggleModel("file", true);
};

export const adjustDockPadding = () => {
    const layoutElement = window.siyuan.layout.layout.children[0].element;
    if (window.siyuan.layout.leftDock.elements[0].parentElement.classList.contains("fn__none")) {
        layoutElement.style.marginLeft = "var(--b3-layout-space)";
    } else {
        layoutElement.style.marginLeft = "";
    }
    if (window.siyuan.layout.rightDock.elements[0].parentElement.classList.contains("fn__none")) {
        layoutElement.style.marginRight = "var(--b3-layout-space)";
    } else {
        layoutElement.style.marginRight = "";
    }
    if (window.siyuan.config.appearance.hideStatusBar) {
        layoutElement.style.marginBottom = "var(--b3-layout-space)";
    } else {
        layoutElement.style.marginBottom = "";
    }
};
