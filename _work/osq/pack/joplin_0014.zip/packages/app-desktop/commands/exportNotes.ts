import { CommandRuntime, CommandDeclaration, CommandContext } from '@joplin/lib/services/CommandService';
import InteropService from '@joplin/lib/services/interop/InteropService';
import { ExportModuleOutputFormat, ExportOptions, FileSystemItem } from '@joplin/lib/services/interop/types';

export const declaration: CommandDeclaration = {
	name: 'exportNotes',
};

export const runtime = (): CommandRuntime => {
	return {
		execute: async (_context: CommandContext, noteIds: string[], format: ExportModuleOutputFormat, targetDirectoryPath: string) => {
			const exportOptions: ExportOptions = {
				path: targetDirectoryPath,
				format: format,
				target: FileSystemItem.Directory,
				sourceNoteIds: noteIds,
			};

			return InteropService.instance().export(exportOptions);
		},
	};
};
