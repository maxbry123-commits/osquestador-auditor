import { CommandRuntime, CommandDeclaration } from '@joplin/lib/services/CommandService';
import { _ } from '@joplin/lib/locale';
import shim, { MessageBoxType } from '@joplin/lib/shim';
import { app } from '@electron/remote';
import { clipboard } from 'electron';

export const declaration: CommandDeclaration = {
	name: 'copyDevCommand',
	label: () => _('Copy dev mode command to clipboard'),
};

export const runtime = (): CommandRuntime => {
	return {
		execute: async () => {
			const appPath = app.getPath('exe');
			// Quote the path so it works when it contains spaces (e.g. "C:\Program Files\Joplin\Joplin.exe" on Windows)
			const cmd = `"${appPath}" --env dev`;
			clipboard.writeText(cmd);
			await shim.showMessageBox(`The dev mode command has been copied to clipboard:\n\n${cmd}`, { type: MessageBoxType.Info });
		},
	};
};
