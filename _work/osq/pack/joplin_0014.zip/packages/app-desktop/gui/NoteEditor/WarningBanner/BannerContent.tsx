import * as React from 'react';
import { _ } from '@joplin/lib/locale';

interface Props {
	children: React.ReactNode;
	acceptMessage: string;
	onAccept: ()=> void;
	onDismiss?: ()=> void;
	dismissMessage?: string;
	visible: boolean;
}

const BannerContent: React.FC<Props> = props => {
	if (!props.visible) {
		return null;
	}

	return <div className='warning-banner'>
		{props.children}
		&nbsp;&nbsp;<a onClick={props.onAccept} className='warning-banner-link' href="#">[ {props.acceptMessage} ]</a>
		&nbsp;&nbsp;{ props.onDismiss ? <a onClick={props.onDismiss} className='warning-banner-link' href="#">[ {props.dismissMessage ?? _('Dismiss')} ]</a> : null }
	</div>;
};

export default BannerContent;
