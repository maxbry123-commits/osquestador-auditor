# Email to Note

You can save your emails in Joplin Cloud by forwarding your emails to your Joplin Cloud email address. The subject of the email will become the note title, and the email body will become the note content. The note will be created inside a notebook called Inbox.

All notes created this way will use, like any other note, your Joplin Cloud storage capacity.

This feature is available for Pro and Teams members.

## How to get your email address

### Desktop

To copy your Joplin Cloud email address you will need to navigate to the [Configuration screen](https://github.com/laurent22/joplin/blob/dev/readme/apps/config_screen.md) and locate to the Joplin Cloud tab. You will need to have your [synchronisation set to Joplin Cloud](https://github.com/laurent22/joplin/blob/dev/readme/apps/sync/joplin_cloud.md)

<img src="https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/email_to_note/desktop.png" width="80%"/>

### Mobile

To copy your Joplin Cloud email address you will need to navigate to the [Configuration screen](https://github.com/laurent22/joplin/blob/dev/readme/apps/config_screen.md) and find the Joplin Cloud section. You will need to have your [synchronisation set to Joplin Cloud](https://github.com/laurent22/joplin/blob/dev/readme/apps/sync/joplin_cloud.md)


<img src="https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/email_to_note/mobile.png" width="50%"/>

### Website

Your Joplin Cloud email address is available in the dashboard of the Joplin Cloud website.

<img src="https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/email_to_note/website.png" width="50%"/>

### Video tutorial

Watch this short video to learn how to set up email to note on desktop:

[![Watch the video](https://img.youtube.com/vi/8r8gS7grFDQ/hqdefault.jpg)](https://www.youtube.com/watch?v=8r8gS7grFDQ)
