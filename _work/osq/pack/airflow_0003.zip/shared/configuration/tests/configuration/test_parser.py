#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Tests for shared AirflowConfigParser."""

from __future__ import annotations

import datetime
import json
import os
import re
import textwrap
from configparser import ConfigParser
from enum import Enum
from io import StringIO
from unittest.mock import patch

import pytest

from airflow_shared.configuration.exceptions import AirflowConfigException
from airflow_shared.configuration.parser import (
    AirflowConfigParser as _SharedAirflowConfigParser,
    base_section_name,
    configure_parser_from_configuration_description,
)


class _NoOpProvidersManager:
    """Stub providers manager for tests — no providers, no side effects."""

    @property
    def provider_configs(self):
        return []


def _create_empty_config_parser(desc: dict) -> ConfigParser:
    return ConfigParser()


def _create_default_config_parser(desc: dict) -> ConfigParser:
    parser = ConfigParser()
    configure_parser_from_configuration_description(parser, desc, {})
    return parser


class AirflowConfigParser(_SharedAirflowConfigParser):
    """Test parser that extends shared parser for testing."""

    def __init__(
        self,
        default_config: str | None = None,
        provider_manager_type=_NoOpProvidersManager,
        create_default_config_parser_callable=_create_empty_config_parser,
        *args,
        **kwargs,
    ):
        configuration_description = {
            "test": {
                "options": {
                    "key1": {"default": "default_value"},
                    "key2": {"default": 123},
                }
            }
        }
        _default_values = ConfigParser()
        _default_values.add_section("test")
        _default_values.set("test", "key1", "default_value")
        _default_values.set("test", "key2", "123")
        super().__init__(
            configuration_description,
            _default_values,
            provider_manager_type,
            create_default_config_parser_callable,
            "",
            *args,
            **kwargs,
        )
        self._configuration_description = configuration_description
        self._default_values = _default_values
        self._suppress_future_warnings = False

        if default_config is not None:
            self._update_defaults_from_string(default_config)


class TestAirflowConfigParser:
    """Test the shared AirflowConfigParser parser methods."""

    def test_getboolean(self):
        """Test AirflowConfigParser.getboolean"""
        test_config = """
[type_validation]
key1 = non_bool_value

[true]
key2 = t
key3 = true
key4 = 1

[false]
key5 = f
key6 = false
key7 = 0

[inline-comment]
key8 = true #123
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to bool. Please check "key1" key in "type_validation" section. '
                'Current value: "non_bool_value".'
            ),
        ):
            test_conf.getboolean("type_validation", "key1")
        assert isinstance(test_conf.getboolean("true", "key3"), bool)
        assert test_conf.getboolean("true", "key2") is True
        assert test_conf.getboolean("true", "key3") is True
        assert test_conf.getboolean("true", "key4") is True
        assert test_conf.getboolean("false", "key5") is False
        assert test_conf.getboolean("false", "key6") is False
        assert test_conf.getboolean("false", "key7") is False
        assert test_conf.getboolean("inline-comment", "key8") is True

    def test_getint(self):
        """Test AirflowConfigParser.getint"""
        test_config = """
[invalid]
key1 = str

[valid]
key2 = 1

[float]
key3 = 4.096e+07

[decimal]
key4 = 12.34
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to int. Please check "key1" key in "invalid" section. '
                'Current value: "str".'
            ),
        ):
            test_conf.getint("invalid", "key1")
        assert isinstance(test_conf.getint("valid", "key2"), int)
        assert test_conf.getint("valid", "key2") == 1

        assert isinstance(test_conf.getint("float", "key3"), int)
        assert test_conf.getint("float", "key3") == 40960000

        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to int. Please check "key4" key in "decimal" section. '
                'Current value: "12.34".'
            ),
        ):
            test_conf.getint("decimal", "key4")

    def test_getfloat(self):
        """Test AirflowConfigParser.getfloat"""
        test_config = """
[invalid]
key1 = str

[valid]
key2 = 1.23
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to float. Please check "key1" key in "invalid" section. '
                'Current value: "str".'
            ),
        ):
            test_conf.getfloat("invalid", "key1")
        assert isinstance(test_conf.getfloat("valid", "key2"), float)
        assert test_conf.getfloat("valid", "key2") == 1.23

    def test_getlist(self):
        """Test AirflowConfigParser.getlist"""
        test_config = """
[single]
key1 = str
empty =

[many]
key2 = one,two,three

[diffdelimiter]
key3 = one;two;three
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        single = test_conf.getlist("single", "key1")
        assert single == ["str"]

        empty = test_conf.getlist("single", "empty")
        assert empty == []

        many = test_conf.getlist("many", "key2")
        assert many == ["one", "two", "three"]

        semicolon = test_conf.getlist("diffdelimiter", "key3", delimiter=";")
        assert semicolon == ["one", "two", "three"]

        assert test_conf.getlist("empty", "key0", fallback=None) is None
        assert test_conf.getlist("empty", "key0", fallback=[]) == []

    @pytest.mark.parametrize(
        ("config_str", "expected"),
        [
            pytest.param('{"a": 123}', {"a": 123}, id="dict"),
            pytest.param("[1,2,3]", [1, 2, 3], id="list"),
            pytest.param('"abc"', "abc", id="str"),
            pytest.param("2.1", 2.1, id="num"),
            pytest.param("", None, id="empty"),
        ],
    )
    def test_getjson(self, config_str, expected):
        """Test AirflowConfigParser.getjson"""
        config = textwrap.dedent(
            f"""
            [test]
            json = {config_str}
        """
        )
        test_conf = AirflowConfigParser()
        test_conf.read_string(config)

        assert test_conf.getjson("test", "json") == expected

    def test_getenum(self):
        """Test AirflowConfigParser.getenum"""

        class TestEnum(Enum):
            option1 = 1
            option2 = 2
            option3 = 3
            fallback = 4

        config = """
            [test1]
            option = option1
            [test2]
            option = option2
            [test3]cmd
            option = option3
            [test4]
            option = option4
            """
        test_conf = AirflowConfigParser()
        test_conf.read_string(config)

        assert test_conf.getenum("test1", "option", TestEnum) == TestEnum.option1
        assert test_conf.getenum("test2", "option", TestEnum) == TestEnum.option2
        assert test_conf.getenum("test3", "option", TestEnum) == TestEnum.option3
        assert test_conf.getenum("test4", "option", TestEnum, fallback="fallback") == TestEnum.fallback
        with pytest.raises(AirflowConfigException, match=re.escape("option1, option2, option3, fallback")):
            test_conf.getenum("test4", "option", TestEnum)

    def test_getenumlist(self):
        """Test AirflowConfigParser.getenumlist"""

        class TestEnum(Enum):
            option1 = 1
            option2 = 2
            option3 = 3
            fallback = 4

        config = """
            [test1]
            option = option1,option2,option3
            [test2]
            option = option1,option3
            [test3]
            option = option1,option4
            [test4]
            option =
            """
        test_conf = AirflowConfigParser()
        test_conf.read_string(config)

        assert test_conf.getenumlist("test1", "option", TestEnum) == [
            TestEnum.option1,
            TestEnum.option2,
            TestEnum.option3,
        ]
        assert test_conf.getenumlist("test2", "option", TestEnum) == [TestEnum.option1, TestEnum.option3]
        assert test_conf.getenumlist("test3", "option", TestEnum) == [TestEnum.option1]
        assert test_conf.getenumlist("test4", "option", TestEnum) == []

    def test_getjson_empty_with_fallback(self):
        """Test AirflowConfigParser.getjson with empty value and fallback"""
        config = textwrap.dedent(
            """
            [test]
            json =
            """
        )
        test_conf = AirflowConfigParser()
        test_conf.read_string(config)

        assert test_conf.getjson("test", "json", fallback={}) == {}
        assert test_conf.getjson("test", "json") is None

    @pytest.mark.parametrize(
        ("fallback"),
        [
            pytest.param({"a": "b"}, id="dict"),
            # fallback is _NOT_ json parsed, but used verbatim
            pytest.param('{"a": "b"}', id="str"),
            pytest.param(None, id="None"),
        ],
    )
    def test_getjson_fallback(self, fallback):
        """Test AirflowConfigParser.getjson with fallback"""
        test_conf = AirflowConfigParser()

        assert test_conf.getjson("test", "json", fallback=fallback) == fallback

    def test_has_option(self):
        """Test AirflowConfigParser.has_option"""
        test_config = """[test]
key1 = value1
"""
        test_conf = AirflowConfigParser()
        test_conf.read_string(test_config)
        assert test_conf.has_option("test", "key1")
        assert not test_conf.has_option("test", "key_not_exists")
        assert not test_conf.has_option("section_not_exists", "key1")

    def test_remove_option(self):
        """Test AirflowConfigParser.remove_option"""
        test_config = """[test]
key1 = hello
key2 = airflow
"""
        test_config_default = """[test]
key1 = awesome
key2 = airflow
"""

        test_conf = AirflowConfigParser(default_config=test_config_default)
        test_conf.read_string(test_config)

        assert test_conf.get("test", "key1") == "hello"
        test_conf.remove_option("test", "key1", remove_default=False)
        assert test_conf.get("test", "key1") == "awesome"

        test_conf.remove_option("test", "key2")
        assert not test_conf.has_option("test", "key2")

    def test_get_with_defaults(self):
        """Test AirflowConfigParser.get() with defaults"""
        test_config_default = """[test]
key1 = default_value
"""
        test_conf = AirflowConfigParser(default_config=test_config_default)
        assert test_conf.get("test", "key1") == "default_value"

    def test_get_mandatory_value(self):
        """Test AirflowConfigParser.get_mandatory_value()"""
        test_conf = AirflowConfigParser()
        test_conf.add_section("test")
        test_conf.set("test", "key1", "value1")

        assert test_conf.get_mandatory_value("test", "key1") == "value1"

        with pytest.raises(
            AirflowConfigException, match=re.escape("section/key [test/missing_key] not found in config")
        ):
            test_conf.get_mandatory_value("test", "missing_key")

    def test_sensitive_config_values(self):
        """Test AirflowConfigParser.sensitive_config_values property"""
        test_conf = AirflowConfigParser()
        test_conf.configuration_description = {
            "test": {
                "options": {
                    "password": {"sensitive": True, "default": "secret"},
                    "api_key": {"sensitive": True, "default": "key123"},
                    "username": {"sensitive": False, "default": "user"},
                    "normal_value": {"default": "value"},
                }
            },
            "database": {
                "options": {
                    "connection": {"sensitive": True, "default": "sqlite://"},
                }
            },
        }
        if "inversed_deprecated_options" in test_conf.__dict__:
            delattr(test_conf, "inversed_deprecated_options")
        if "sensitive_config_values" in test_conf.__dict__:
            delattr(test_conf, "sensitive_config_values")
        sensitive = test_conf.sensitive_config_values
        assert isinstance(sensitive, set)
        assert ("test", "password") in sensitive
        assert ("test", "api_key") in sensitive
        assert ("database", "connection") in sensitive
        assert ("test", "username") not in sensitive
        assert ("test", "normal_value") not in sensitive

    def test_deprecated_options(self):
        """Test AirflowConfigParser handles deprecated options"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = {
                ("new_section", "new_key"): ("old_section", "old_key", "2.0.0"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("old_section")
        test_conf.set("old_section", "old_key", "old_value")

        with pytest.warns(DeprecationWarning, match="old_key"):
            assert test_conf.get("new_section", "new_key", suppress_warnings=True) == "old_value"

        with pytest.raises(AirflowConfigException):
            test_conf.get("new_section", "new_key", lookup_from_deprecated=False, suppress_warnings=True)

    def test_deprecated_options_same_section(self):
        """Test deprecated options in the same section"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = {
                ("test", "new_key"): ("test", "old_key", "2.0.0"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("test")
        test_conf.set("test", "old_key", "old_value")

        with pytest.warns(DeprecationWarning, match="old_key"):
            assert test_conf.get("test", "new_key", suppress_warnings=True) == "old_value"

    def test_deprecated_options_lookup_disabled(self):
        """Test deprecated options with lookup_from_deprecated=False"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = {
                ("new_section", "new_key"): ("old_section", "old_key", "2.0.0"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("old_section")
        test_conf.set("old_section", "old_key", "old_value")

        with pytest.raises(AirflowConfigException):
            test_conf.get("new_section", "new_key", lookup_from_deprecated=False)

    def test_deprecated_options_precedence(self):
        """Test that new option takes precedence over deprecated option"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = {
                ("test", "new_key"): ("test", "old_key", "2.0.0"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("test")
        test_conf.set("test", "old_key", "old_value")
        test_conf.set("test", "new_key", "new_value")
        value = test_conf.get("test", "new_key")
        assert value == "new_value"

    @pytest.mark.parametrize(
        ("deprecated_options_dict", "kwargs", "new_section_expected_value", "old_section_expected_value"),
        [
            pytest.param(
                {("old_section", "old_key"): ("new_section", "new_key", "2.0.0")},
                {"fallback": None},
                None,
                "value",
                id="deprecated_in_different_section_lookup_enabled",
            ),
            pytest.param(
                {("old_section", "old_key"): ("new_section", "new_key", "2.0.0")},
                {"fallback": None, "lookup_from_deprecated": False},
                None,
                None,
                id="deprecated_in_different_section_lookup_disabled",
            ),
            pytest.param(
                {("new_section", "old_key"): ("new_section", "new_key", "2.0.0")},
                {"fallback": None},
                "value",
                None,
                id="deprecated_in_same_section_lookup_enabled",
            ),
            pytest.param(
                {("new_section", "old_key"): ("new_section", "new_key", "2.0.0")},
                {"fallback": None, "lookup_from_deprecated": False},
                None,
                None,
                id="deprecated_in_same_section_lookup_disabled",
            ),
        ],
    )
    def test_deprecated_options_with_lookup_from_deprecated(
        self, deprecated_options_dict, kwargs, new_section_expected_value, old_section_expected_value
    ):
        """Test deprecated options with lookup_from_deprecated parameter"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = deprecated_options_dict.copy()

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("new_section")
        test_conf.set("new_section", "new_key", "value")

        if ("new_section", "old_key") in deprecated_options_dict:
            pass

        if ("old_section", "old_key") in deprecated_options_dict:
            test_conf.add_section("old_section")
            test_conf.set("old_section", "old_key", "value")

        result = test_conf.get("new_section", "old_key", **kwargs)
        assert result == new_section_expected_value

        if old_section_expected_value is not None:
            result = test_conf.get("old_section", "old_key", **kwargs)
            assert result == old_section_expected_value

    def test_deprecated_options_cmd(self):
        """Test deprecated options with _cmd suffix"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_options = {
                ("test", "new_key"): ("test", "old_key", "2.0.0"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False
                self.sensitive_config_values = {("test", "old_key")}

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("test")
        test_conf.set("test", "old_key_cmd", 'echo -n "cmd_value"')

        with pytest.warns(DeprecationWarning, match="old_key"):
            assert test_conf.get("test", "new_key", suppress_warnings=False) == "cmd_value"

    def test_cmd_from_env_var(self):
        test_config = textwrap.dedent(
            """\
            [testcmdenv]
            itsacommand=NOT OK
            notacommand=OK
        """
        )
        test_conf = AirflowConfigParser(default_config=test_config)
        test_conf.sensitive_config_values.add(("testcmdenv", "itsacommand"))

        with patch.dict(os.environ, {"AIRFLOW__TESTCMDENV__ITSACOMMAND_CMD": 'echo -n "OK"'}):
            assert test_conf.get("testcmdenv", "itsacommand") == "OK"
            assert test_conf.get("testcmdenv", "notacommand") == "OK"

    def test_cmd_from_config_file(self):
        test_config = textwrap.dedent(
            """\
            [test]
            sensitive_key_cmd=echo -n cmd_value
            non_sensitive_key=config_value
            non_sensitive_key_cmd=echo -n cmd_value
        """
        )
        test_conf = AirflowConfigParser()
        test_conf.read_string(test_config)
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))
        assert test_conf.get("test", "sensitive_key") == "cmd_value"
        assert test_conf.get("test", "non_sensitive_key") == "config_value"

    def test_secret_from_config_file(self):
        class TestParserWithSecretBackend(AirflowConfigParser):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

            def _get_config_value_from_secret_backend(self, config_key: str) -> str | None:
                """Mock secrets backend - return a test value"""
                return "secret_value_from_backend"

        test_config = textwrap.dedent(
            """\
            [test]
            sensitive_key_secret=test/secret/path
            non_sensitive_key=config_value
            non_sensitive_key_secret=test/secret/path
        """
        )
        test_conf = TestParserWithSecretBackend()
        test_conf.read_string(test_config)
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))
        assert test_conf.get("test", "sensitive_key") == "secret_value_from_backend"
        assert test_conf.get("test", "non_sensitive_key") == "config_value"

    def test_secret_from_env_var(self):
        class TestParserWithSecretBackend(AirflowConfigParser):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

            def _get_config_value_from_secret_backend(self, config_key: str) -> str | None:
                """Mock secrets backend - return a test value"""
                return "secret_value_from_backend"

        test_config = textwrap.dedent(
            """\
            [test]
            sensitive_key=config_value
            non_sensitive_key=config_value
        """
        )
        test_conf = TestParserWithSecretBackend()
        test_conf.read_string(test_config)
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))
        with patch.dict(os.environ, {"AIRFLOW__TEST__SENSITIVE_KEY_SECRET": "test/secret/path"}):
            assert test_conf.get("test", "sensitive_key") == "secret_value_from_backend"
        with patch.dict(os.environ, {"AIRFLOW__TEST__NON_SENSITIVE_KEY_SECRET": "test/secret/path"}):
            assert test_conf.get("test", "non_sensitive_key") == "config_value"

    def test_deprecated_sections(self):
        """Test deprecated sections"""

        class TestParserWithDeprecated(AirflowConfigParser):
            deprecated_sections = {
                "new_section": ("old_section", "2.1"),
            }

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._default_values.add_section("new_section")
                self._default_values.set("new_section", "val", "new")
                self._suppress_future_warnings = False

        test_conf = TestParserWithDeprecated()
        test_conf.add_section("old_section")
        test_conf.set("old_section", "val", "old_val")
        with pytest.warns(DeprecationWarning, match="old_section"):
            assert test_conf.get("new_section", "val", suppress_warnings=True) == "old_val"
        with pytest.warns(FutureWarning, match="old_section"):
            assert test_conf.get("old_section", "val", suppress_warnings=True) == "old_val"

    def test_gettimedelta(self):
        test_config = """
[invalid]
# non-integer value
key1 = str

# fractional value
key2 = 300.99

# too large value for C int
key3 = 999999999999999

[valid]
# negative value
key4 = -1

# zero
key5 = 0

# positive value
key6 = 300

[default]
# Equals to None
key7 =
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to int. Please check "key1" key in "invalid" section. '
                'Current value: "str".'
            ),
        ):
            test_conf.gettimedelta("invalid", "key1")

        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'Failed to convert value to int. Please check "key2" key in "invalid" section. '
                'Current value: "300.99".'
            ),
        ):
            test_conf.gettimedelta("invalid", "key2")

        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                "Failed to convert value to timedelta in `seconds`. "
                "Python int too large to convert to C int. "
                'Please check "key3" key in "invalid" section. Current value: "999999999999999".'
            ),
        ):
            test_conf.gettimedelta("invalid", "key3")

        assert isinstance(test_conf.gettimedelta("valid", "key4"), datetime.timedelta)
        assert test_conf.gettimedelta("valid", "key4") == datetime.timedelta(seconds=-1)
        assert isinstance(test_conf.gettimedelta("valid", "key5"), datetime.timedelta)
        assert test_conf.gettimedelta("valid", "key5") == datetime.timedelta(seconds=0)
        assert isinstance(test_conf.gettimedelta("valid", "key6"), datetime.timedelta)
        assert test_conf.gettimedelta("valid", "key6") == datetime.timedelta(seconds=300)
        assert isinstance(test_conf.gettimedelta("default", "key7"), type(None))
        assert test_conf.gettimedelta("default", "key7") is None

    def test_getimport(self):
        test_config = """
[test]
valid_module = json.JSONDecoder
empty_module =
invalid_module = non.existent.module.path
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        result = test_conf.getimport("test", "valid_module")
        assert result is not None
        assert result == json.JSONDecoder

        assert test_conf.getimport("test", "empty_module") is None

        with pytest.raises(
            AirflowConfigException,
            match=re.escape(
                'The object could not be loaded. Please check "invalid_module" key in "test" section. '
                'Current value: "non.existent.module.path".'
            ),
        ):
            test_conf.getimport("test", "invalid_module")

        with pytest.raises(AirflowConfigException):
            test_conf.getimport("test", "missing_module")

    def test_get_mandatory_list_value(self):
        test_config = """
[test]
existing_list = one,two,three
"""
        test_conf = AirflowConfigParser(default_config=test_config)
        result = test_conf.get_mandatory_list_value("test", "existing_list")
        assert result == ["one", "two", "three"]

        with pytest.raises(AirflowConfigException):
            test_conf.get_mandatory_list_value("test", "missing_key")

        with pytest.raises(ValueError, match=r"The value test/missing_key should be set!"):
            test_conf.get_mandatory_list_value("test", "missing_key", fallback=None)

    def test_write_materializes_provider_sources_in_requested_context(self):
        test_conf = AirflowConfigParser()

        test_conf.write(StringIO(), include_sources=True, include_providers=False)
        assert "_provider_metadata_config_fallback_default_values" not in test_conf.__dict__

        test_conf.write(StringIO(), include_sources=True, include_providers=True)
        assert "_provider_metadata_config_fallback_default_values" in test_conf.__dict__

        # we will not clear the cached _provider_metadata_config_fallback_default_values after the first call
        test_conf.write(StringIO(), include_sources=True, include_providers=False)
        assert "_provider_metadata_config_fallback_default_values" in test_conf.__dict__

    def test_get_resolves_provider_metadata_fallback(self):
        """conf.get returns values from provider metadata for provider-only sections."""
        provider_configs = [
            (
                "apache-airflow-providers-test",
                {
                    "test_provider": {
                        "options": {
                            "test_option": {
                                "default": "provider-default",
                            }
                        }
                    }
                },
            )
        ]

        class ProvidersManagerWithConfig:
            @property
            def provider_configs(self):
                return provider_configs

        test_conf = AirflowConfigParser(
            provider_manager_type=ProvidersManagerWithConfig,
            create_default_config_parser_callable=_create_default_config_parser,
        )

        assert test_conf._use_providers_configuration is True
        assert test_conf.get("test_provider", "test_option") == "provider-default"
        # Provider metadata is merged into configuration_description
        assert test_conf.configuration_description.get("test_provider") is not None
        # Base configuration is not mutated
        assert "test_provider" not in test_conf._configuration_description

    def test_has_option_uses_provider_metadata_fallback(self):
        """has_option must reach provider-metadata fallback for provider-only sections.

        Regression test: has_option passes ``fallback=None`` to get(), which leaked
        into _get_option_from_defaults via **kwargs.  The ``"fallback" in kwargs``
        guard caused _get_option_from_defaults to return None (the fallback) instead
        of VALUE_NOT_FOUND_SENTINEL, short-circuiting the lookup before the provider
        metadata fallback was consulted.
        """
        provider_configs = [
            (
                "apache-airflow-providers-test",
                {
                    "test_provider": {
                        "options": {
                            "test_option": {
                                "default": "provider-default",
                            }
                        }
                    }
                },
            )
        ]

        class ProvidersManagerWithConfig:
            @property
            def provider_configs(self):
                return provider_configs

        test_conf = AirflowConfigParser(
            provider_manager_type=ProvidersManagerWithConfig,
            create_default_config_parser_callable=_create_default_config_parser,
        )

        assert test_conf.has_option("test_provider", "test_option") is True
        assert test_conf.has_option("test_provider", "nonexistent_option") is False
        assert test_conf.has_option("nonexistent_section", "nonexistent_option") is False

    def test_set_case_insensitive(self):
        # both get and set should be case insensitive
        test_conf = AirflowConfigParser()
        test_conf.add_section("test")
        test_conf.set("test", "key1", "value1")
        test_conf.set("TEST", "KEY1", "value2")
        assert test_conf.get("test", "key1") == "value2"
        assert test_conf.get("TEST", "KEY1") == "value2"
        test_conf.set("Test", "NewKey", "new_value")
        assert test_conf.get("test", "newkey") == "new_value"
        assert test_conf.get("TEST", "NEWKEY") == "new_value"

    def test_configure_parser_from_configuration_description_with_deprecated_options(self):
        """
        Test that configure_parser_from_configuration_description respects deprecated options.
        """
        configuration_description = {
            "test_section": {
                "options": {
                    "non_deprecated_key": {"default": "non_deprecated_value"},
                    "deprecated_key_version": {
                        "default": "deprecated_value_version",
                        "version_deprecated": "3.0.0",
                    },
                    "deprecated_key_reason": {
                        "default": "deprecated_value_reason",
                        "deprecation_reason": "Some reason",
                    },
                    "none_default_deprecated": {"default": None, "deprecation_reason": "No default"},
                }
            }
        }
        parser = ConfigParser()
        all_vars = {}

        configure_parser_from_configuration_description(parser, configuration_description, all_vars)

        # Assert that the non-deprecated key is present
        assert parser.has_option("test_section", "non_deprecated_key")
        assert parser.get("test_section", "non_deprecated_key") == "non_deprecated_value"

        # Assert that the deprecated keys are NOT present
        assert not parser.has_option("test_section", "deprecated_key_version")
        assert not parser.has_option("test_section", "deprecated_key_reason")

        # Assert that options with default None are still not set
        assert not parser.has_option("test_section", "none_default_deprecated")

    def test_get_default_value_deprecated(self):
        """Test 'conf.get' for deprecated options and should not return default value."""

        class TestConfigParser(AirflowConfigParser):
            def __init__(self):
                configuration_description = {
                    "test_section": {
                        "options": {
                            "deprecated_key": {
                                "default": "some_value",
                                "deprecation_reason": "deprecated",
                            },
                            "deprecated_key2": {
                                "default": "some_value",
                                "version_deprecated": "2.0.0",
                            },
                            "deprecated_key3": {
                                "default": None,
                                "version_deprecated": "2.0.0",
                            },
                            "active_key": {
                                "default": "active_value",
                            },
                        }
                    }
                }
                _default_values = ConfigParser()
                # verify configure_parser_from_configuration_description logic of skipping
                configure_parser_from_configuration_description(
                    _default_values, configuration_description, {}
                )
                _SharedAirflowConfigParser.__init__(
                    self,
                    configuration_description,
                    _default_values,
                    _NoOpProvidersManager,
                    _create_empty_config_parser,
                    "",
                )

        test_conf = TestConfigParser()
        deprecated_conf_list = [
            ("test_section", "deprecated_key"),
            ("test_section", "deprecated_key2"),
            ("test_section", "deprecated_key3"),
        ]

        # case 1: using `get` with fallback
        # should return fallback if not found
        expected_sentinel = object()
        for section, key in deprecated_conf_list:
            assert test_conf.get(section, key, fallback=expected_sentinel) is expected_sentinel

        # case 2: using `get` without fallback
        # should raise AirflowConfigException
        for section, key in deprecated_conf_list:
            with pytest.raises(
                AirflowConfigException,
                match=re.escape(f"section/key [{section}/{key}] not found in config"),
            ):
                test_conf.get(section, key)

        # case 3: active (non-deprecated) key
        # Active key should be present
        assert test_conf.get("test_section", "active_key") == "active_value"

    def test_team_env_var_takes_priority(self):
        """Test that team-specific env var is returned when team_name is provided."""
        test_config = textwrap.dedent(
            """\
            [celery]
            broker_url = redis://global:6379/0
        """
        )
        test_conf = AirflowConfigParser(default_config=test_config)
        with patch.dict(
            os.environ,
            {"AIRFLOW__TEAM_A___CELERY__BROKER_URL": "redis://team-a:6379/0"},
        ):
            assert test_conf.get("celery", "broker_url", team_name="team_a") == "redis://team-a:6379/0"

    def test_team_config_file_section(self):
        """Test that [team_name=section] in config file is used when team_name is provided."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [celery]
                broker_url = redis://global:6379/0

                [team_a=celery]
                broker_url = redis://team-a:6379/0
            """
            )
        )
        assert test_conf.get("celery", "broker_url", team_name="team_a") == "redis://team-a:6379/0"

    def test_team_does_not_fallback_to_global_config(self):
        """Test that team lookup does NOT fall back to global config section or env var."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [celery]
                broker_url = redis://global:6379/0
            """
            )
        )
        # team_a has no config set, should NOT get global value; should fall through to defaults
        with pytest.raises(AirflowConfigException):
            test_conf.get("celery", "broker_url", team_name="team_a")

    def test_team_does_not_fallback_to_global_env_var(self):
        """Test that team lookup does NOT fall back to global env var."""
        test_conf = AirflowConfigParser()
        with patch.dict(os.environ, {"AIRFLOW__CELERY__BROKER_URL": "redis://global-env:6379/0"}):
            with pytest.raises(AirflowConfigException):
                test_conf.get("celery", "broker_url", team_name="team_a")

    def test_team_skips_cmd_lookup(self):
        """Test that _cmd config values are skipped when team_name is provided."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [test]
                sensitive_key_cmd = echo -n cmd_value
            """
            )
        )
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        # Without team_name, cmd works
        assert test_conf.get("test", "sensitive_key") == "cmd_value"

        # With team_name, cmd is skipped
        with pytest.raises(AirflowConfigException):
            test_conf.get("test", "sensitive_key", team_name="team_a")

    def test_team_skips_secret_lookup(self):
        """Test that _secret config values are skipped when team_name is provided."""

        class TestParserWithSecretBackend(AirflowConfigParser):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.configuration_description = {}
                self._default_values = ConfigParser()
                self._suppress_future_warnings = False

            def _get_config_value_from_secret_backend(self, config_key: str) -> str | None:
                return "secret_value_from_backend"

        test_conf = TestParserWithSecretBackend()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [test]
                sensitive_key_secret = test/secret/path
            """
            )
        )
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        # Without team_name, secret backend works
        assert test_conf.get("test", "sensitive_key") == "secret_value_from_backend"

        # With team_name, secret backend is skipped
        with pytest.raises(AirflowConfigException):
            test_conf.get("test", "sensitive_key", team_name="team_a")

    def test_team_falls_through_to_defaults(self):
        """Test that team lookup falls through to defaults when no team-specific value is set."""
        test_conf = AirflowConfigParser()
        # "test" section with "key1" having default "default_value" is set in the AirflowConfigParser fixture
        assert test_conf.get("test", "key1", team_name="team_a") == "default_value"

    def test_team_env_var_format(self):
        """Test the triple-underscore env var format: AIRFLOW__{TEAM}___{SECTION}__{KEY}."""
        test_conf = AirflowConfigParser()
        with patch.dict(
            os.environ,
            {"AIRFLOW__MY_TEAM___MY_SECTION__MY_KEY": "team_value"},
        ):
            assert test_conf.get("my_section", "my_key", team_name="my_team") == "team_value"

    @pytest.mark.parametrize(
        ("section", "expected"),
        [
            pytest.param("celery", "celery", id="base_section"),
            pytest.param("team_a=celery", "celery", id="team_scoped_section"),
            pytest.param("team-a=celery", "celery", id="team_name_with_dash"),
            pytest.param("a=team=celery", "celery", id="separator_inside_team_name"),
        ],
    )
    def test_base_section_name(self, section, expected):
        """The base section name is recovered from a team scoped section name."""
        assert base_section_name(section) == expected

    def test_is_sensitive_option_resolves_team_scoped_names(self):
        """A team scoped spelling of a registered sensitive option is recognised as sensitive."""
        test_conf = AirflowConfigParser()
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        assert test_conf.is_sensitive_option("test", "sensitive_key")
        assert test_conf.is_sensitive_option("team_a=test", "sensitive_key")
        assert test_conf.is_sensitive_option("team-a=test", "sensitive_key")
        assert test_conf.is_sensitive_option("a=team=test", "sensitive_key")
        # The section and key an AIRFLOW__<TEAM>___<SECTION>__<KEY> variable name splits into.
        assert test_conf.is_sensitive_option("team_a", "_test__sensitive_key")

        # An option that is not registered as sensitive stays readable under any spelling.
        assert not test_conf.is_sensitive_option("test", "key1")
        assert not test_conf.is_sensitive_option("team_a=test", "key1")
        assert not test_conf.is_sensitive_option("team_a", "_test__key1")
        # A team name matching a registered option does not make the section sensitive either.
        assert not test_conf.is_sensitive_option("sensitive_key=test", "key1")

    def test_team_scoped_sensitive_value_is_hidden_in_as_dict(self):
        """A sensitive option set in a [team=section] section is hidden like the base option is."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [test]
                sensitive_key = global_value

                [team_a=test]
                sensitive_key = team_a_value
                key1 = team_a_key1_value
            """
            )
        )
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        as_dict = test_conf.as_dict(display_sensitive=False)

        assert as_dict["team_a=test"]["sensitive_key"] == "< hidden >"
        # The base option keeps being hidden, and an option that is not registered as sensitive
        # keeps being readable.
        assert as_dict["test"]["sensitive_key"] == "< hidden >"
        assert as_dict["team_a=test"]["key1"] == "team_a_key1_value"

        # display_source keeps reporting where the value came from
        as_dict_with_source = test_conf.as_dict(display_sensitive=False, display_source=True)
        assert as_dict_with_source["team_a=test"]["sensitive_key"] == ("< hidden >", "airflow.cfg")

        # display_sensitive=True still returns the real values
        as_dict_sensitive = test_conf.as_dict(display_sensitive=True)
        assert as_dict_sensitive["team_a=test"]["sensitive_key"] == "team_a_value"
        assert as_dict_sensitive["test"]["sensitive_key"] == "global_value"

    def test_team_scoped_sensitive_cmd_and_secret_fallbacks_are_hidden_in_as_dict(self):
        """The _cmd / _secret fallbacks of a team scoped option are not resolved, so they are hidden."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [team_a=test]
                sensitive_key_cmd = echo -n team_a_value
                sensitive_key_secret = team_a/secret/path
            """
            )
        )
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        as_dict = test_conf.as_dict(display_sensitive=False)

        assert as_dict["team_a=test"]["sensitive_key_cmd"] == "< hidden >"
        assert as_dict["team_a=test"]["sensitive_key_secret"] == "< hidden >"

    def test_team_scoped_sensitive_env_var_is_hidden_in_as_dict(self):
        """A sensitive option set by a team scoped env var is hidden like the base option is."""
        test_conf = AirflowConfigParser()
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        with patch.dict(
            os.environ,
            {
                "AIRFLOW__TEAM_A___TEST__SENSITIVE_KEY": "team_a_value",
                "AIRFLOW__TEAM_A___TEST__SENSITIVE_KEY_CMD": "echo -n team_a_cmd_value",
                "AIRFLOW__TEAM_A___TEST__KEY1": "team_a_key1_value",
            },
        ):
            hidden_values = self._collected_values(test_conf.as_dict(display_sensitive=False))
            sensitive_values = self._collected_values(test_conf.as_dict(display_sensitive=True))

        assert "team_a_value" not in hidden_values
        assert "echo -n team_a_cmd_value" not in hidden_values
        assert "< hidden >" in hidden_values
        assert "team_a_key1_value" in hidden_values
        # display_sensitive=True still returns the real value.
        assert "team_a_value" in sensitive_values

    def test_team_scoped_sensitive_value_is_hidden_by_write(self):
        """A sensitive option set in a [team=section] section is hidden when writing the config out."""
        test_conf = AirflowConfigParser()
        test_conf.read_string(
            textwrap.dedent(
                """\
                [team_a=test]
                sensitive_key = team_a_value
                key1 = team_a_key1_value
            """
            )
        )
        test_conf.sensitive_config_values.add(("test", "sensitive_key"))

        file = StringIO()
        test_conf.write(
            file,
            include_descriptions=False,
            include_examples=False,
            include_sources=False,
            show_values=True,
            hide_sensitive=True,
        )
        written = file.getvalue()

        assert "team_a_value" not in written
        assert "sensitive_key = < hidden >" in written
        assert "key1 = team_a_key1_value" in written

    @staticmethod
    def _collected_values(as_dict):
        """Flatten the values of an ``as_dict`` result, whatever section they were reported under."""
        return {value for options in as_dict.values() for value in options.values()}

    @pytest.mark.parametrize(
        "populate_caches",
        [
            pytest.param(set(), id="neither_cached"),
            pytest.param({"configuration_description"}, id="only_configuration_description"),
            pytest.param({"sensitive_config_values"}, id="only_sensitive_config_values"),
            pytest.param({"configuration_description", "sensitive_config_values"}, id="both_cached"),
        ],
    )
    def test_invalidate_provider_flag_caches(self, populate_caches):
        """Test that _invalidate_provider_flag_caches clears cached properties without error."""
        test_conf = AirflowConfigParser()
        if "configuration_description" in populate_caches:
            _ = test_conf.configuration_description
        if "sensitive_config_values" in populate_caches:
            _ = test_conf.sensitive_config_values

        test_conf._invalidate_provider_flag_caches()

        assert "configuration_description" not in test_conf.__dict__
        assert "sensitive_config_values" not in test_conf.__dict__

    def test_invalidate_provider_flag_caches_allows_recomputation(self):
        """Test that cached properties are recomputed after invalidation."""
        test_conf = AirflowConfigParser()
        desc_before = test_conf.configuration_description
        sensitive_before = test_conf.sensitive_config_values

        test_conf._invalidate_provider_flag_caches()

        # Access again — should recompute, not error
        desc_after = test_conf.configuration_description
        sensitive_after = test_conf.sensitive_config_values
        assert desc_after == desc_before
        assert sensitive_after == sensitive_before

    def test_load_providers_configuration_emits_deprecation_warning(self):
        """Test that load_providers_configuration emits a DeprecationWarning."""
        test_conf = AirflowConfigParser()
        with pytest.warns(DeprecationWarning, match="load_providers_configuration.*deprecated"):
            test_conf.load_providers_configuration()
        assert test_conf._use_providers_configuration is True

    def test_restore_core_default_configuration_emits_deprecation_warning(self):
        """Test that restore_core_default_configuration emits a DeprecationWarning."""
        test_conf = AirflowConfigParser()
        with pytest.warns(DeprecationWarning, match="restore_core_default_configuration.*deprecated"):
            test_conf.restore_core_default_configuration()
        assert test_conf._use_providers_configuration is False

    def test_deprecated_load_restore_round_trip(self):
        """Test that the deprecated methods toggle _use_providers_configuration correctly."""
        test_conf = AirflowConfigParser()
        assert test_conf._use_providers_configuration is True

        with pytest.warns(DeprecationWarning, match="restore_core_default_configuration"):
            test_conf.restore_core_default_configuration()
        assert test_conf._use_providers_configuration is False
        assert "configuration_description" not in test_conf.__dict__

        with pytest.warns(DeprecationWarning, match="load_providers_configuration"):
            test_conf.load_providers_configuration()
        assert test_conf._use_providers_configuration is True
        assert "configuration_description" not in test_conf.__dict__
