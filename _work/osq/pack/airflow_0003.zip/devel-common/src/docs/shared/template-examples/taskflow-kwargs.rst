 .. Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

 ..   http://www.apache.org/licenses/LICENSE-2.0

 .. Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.

 .. code-block:: python

    from airflow.sdk import TaskInstance
    from airflow.sdk.types import DagRunProtocol


    @task
    def print_ti_info(**kwargs):
        ti: TaskInstance = kwargs["task_instance"]
        print(f"Run ID: {ti.run_id}")  # Run ID: scheduled__2023-08-09T00:00:00+00:00
        print(f"Task start date: {ti.start_date}")  # 2023-08-10 00:00:01+00:00

        dr: DagRunProtocol = kwargs["dag_run"]
        print(f"Dag Run logical date: {dr.logical_date}")  # 2023-08-09 00:00:00+00:00
