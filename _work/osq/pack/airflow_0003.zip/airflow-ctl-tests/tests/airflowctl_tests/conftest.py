# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import os
import re
import subprocess
import sys
import time
from collections.abc import Callable, Iterator
from subprocess import PIPE, STDOUT, Popen

import pytest
import requests
from python_on_whales import DockerClient, docker

from airflowctl_tests import console
from airflowctl_tests.constants import (
    AIRFLOW_ROOT_PATH,
    API_PASSWORD,
    API_USERNAME,
    DAG_RUN_WAIT_TIMEOUT,
    DAG_RUN_WAIT_TIMEOUT_ENV,
    DOCKER_COMPOSE_FILE_PATH,
    DOCKER_COMPOSE_HOST_PORT,
    DOCKER_IMAGE,
    LOGIN_COMMAND,
    LOGIN_OUTPUT,
)

from tests_common.test_utils.api_client_helpers import generate_access_token
from tests_common.test_utils.fernet import generate_fernet_key_string

# XCom add/edit/delete race against task execution: when the target task transitions to
# RUNNING, the execution API tells the worker to clear every XCom key currently stored
# for that task instance (see `xcom_keys_to_clear` in
# airflow-core/src/airflow/api_fastapi/execution_api/routes/task_instances.py). Any
# XCom the test just added through airflowctl is wiped, and the next xcom edit/delete
# command then fails with "XCom doesn't exist". Waiting for the Dag run to reach a
# terminal state means the task has already run (and won't run again), so user-added
# XComs survive the rest of the xcom commands.
_XCOM_TARGET_PATTERN = re.compile(r'^xcom\s+(?:add|get|list|edit|delete)\s+(\S+)\s+"(manual__[^"]+)"')
_DAG_RUN_TERMINAL_STATES = frozenset({"success", "failed"})
_API_REQUEST_TIMEOUT = 30
_POLL_INITIAL_DELAY = 0.5
_POLL_MAX_DELAY = 10.0


class _CtlTestState:
    docker_client: DockerClient | None = None
    access_token: str | None = None


def _get_access_token() -> str:
    """Log in once per pytest session; every REST call below reuses the token."""
    if _CtlTestState.access_token is None:
        _CtlTestState.access_token = generate_access_token(
            API_USERNAME, API_PASSWORD, DOCKER_COMPOSE_HOST_PORT
        )
    return _CtlTestState.access_token


def _request_api(path: str) -> dict:
    """GET a public API path on the compose stack, e.g. ``dags/my_dag/dagRuns/run_id``."""
    response = requests.get(
        f"http://{DOCKER_COMPOSE_HOST_PORT}/api/v2/{path}",
        headers={"Authorization": f"Bearer {_get_access_token()}"},
        timeout=_API_REQUEST_TIMEOUT,
    )
    response.raise_for_status()
    return response.json()


def _find_dag_run_state(dag_id: str, dag_run_id: str) -> str | None:
    """Return the current state of a Dag run, or None while the API cannot answer."""
    try:
        return _request_api(f"dags/{dag_id}/dagRuns/{dag_run_id}").get("state")
    except requests.exceptions.HTTPError as exc:
        # A rejected request means a wrong run id or wrong credentials; polling on until
        # the budget runs out would bury that behind a timeout.
        if exc.response is not None and exc.response.status_code >= 500:
            return None
        raise
    except requests.exceptions.RequestException:
        return None


def _describe_task_instances(dag_id: str, dag_run_id: str) -> str:
    """Render the Dag run's ``task_id=state`` pairs for timeout diagnostics."""
    try:
        task_instances = _request_api(f"dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances")["task_instances"]
    except (requests.exceptions.RequestException, KeyError) as exc:
        return f"unavailable ({exc})"
    return ", ".join(f"{ti['task_id']}={ti['state']}" for ti in task_instances) or "none"


def _compute_poll_delays() -> Iterator[float]:
    """Sample often while the run is likely to finish soon, then ease off."""
    delay = _POLL_INITIAL_DELAY
    while True:
        yield delay
        delay = min(delay * 2, _POLL_MAX_DELAY)


def _wait_for_dag_run_terminal_state(
    dag_id: str,
    dag_run_id: str,
    timeout: float = DAG_RUN_WAIT_TIMEOUT,
) -> None:
    """Block until the Dag run reaches success/failed, or raise TimeoutError."""
    deadline = time.monotonic() + timeout
    delays = _compute_poll_delays()
    while True:
        state = _find_dag_run_state(dag_id, dag_run_id)
        if state in _DAG_RUN_TERMINAL_STATES:
            return
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(
                f"Dag run {dag_id}/{dag_run_id} did not reach a terminal state in {timeout}s "
                f"(Dag run state: {state}; task instances: {_describe_task_instances(dag_id, dag_run_id)}). "
                f"Set {DAG_RUN_WAIT_TIMEOUT_ENV} to give a slow machine a longer budget."
            )
        time.sleep(min(next(delays), remaining))


def _build_dag_run_waiter() -> Callable[[str, str], None]:
    """Spend the timeout budget once per Dag run and replay that outcome to later commands."""
    outcomes: dict[tuple[str, str], str | None] = {}

    def _wait(dag_id: str, dag_run_id: str) -> None:
        key = (dag_id, dag_run_id)
        if key not in outcomes:
            try:
                _wait_for_dag_run_terminal_state(dag_id, dag_run_id)
            except TimeoutError as exc:
                outcomes[key] = str(exc)
                raise
            outcomes[key] = None
        elif outcomes[key] is not None:
            # The budget is spent, but one cheap look keeps a run that finished late from
            # skipping the rest of the xcom commands.
            if _find_dag_run_state(dag_id, dag_run_id) not in _DAG_RUN_TERMINAL_STATES:
                pytest.skip(f"Dag run {dag_id}/{dag_run_id} is unusable: {outcomes[key]}")
            outcomes[key] = None

    return _wait


@pytest.fixture(scope="session")
def wait_for_dag_run():
    """Fixture that provides a helper to wait for a Dag run to become terminal."""
    return _build_dag_run_waiter()


@pytest.fixture(scope="session")
def api_token():
    """Fixture that provides the API token shared by the whole test session."""
    return _get_access_token()


@pytest.fixture
def run_command(wait_for_dag_run):
    """Fixture that provides a helper to run airflowctl commands."""

    def _run_command(command: str, env_vars: dict, skip_login: bool = False) -> str:
        host_envs = os.environ.copy()
        host_envs.update(env_vars)

        command_from_config = f"airflowctl {command}"

        # We need to run auth login first for all commands except login itself (unless skipped)
        if not skip_login and command != LOGIN_COMMAND:
            run_cmd = f"airflowctl {LOGIN_COMMAND} && {command_from_config}"
        else:
            run_cmd = command_from_config

        # See `_XCOM_TARGET_PATTERN` above for why xcom commands have to wait for the
        # Dag run to be terminal before running.
        xcom_match = _XCOM_TARGET_PATTERN.match(command)
        if xcom_match:
            wait_for_dag_run(xcom_match.group(1), xcom_match.group(2))

        console.print(f"[yellow]Running command: {command}")

        # Give some time for the command to execute and output to be ready
        proc = Popen(run_cmd.encode(), stdout=PIPE, stderr=STDOUT, stdin=PIPE, shell=True, env=host_envs)
        stdout_bytes, stderr_result = proc.communicate(timeout=60)

        # CLI command gave errors
        assert not stderr_result, (
            f"Errors while executing command '{command_from_config}':\n{stderr_result.decode()}"
        )

        # Decode the output
        stdout_result = stdout_bytes.decode()

        # We need to trim auth login output if the command is not login itself and clean backspaces
        if not skip_login and command != LOGIN_COMMAND:
            assert LOGIN_OUTPUT in stdout_result, (
                f"❌ Login output not found before command output for '{command_from_config}'\nFull output:\n{stdout_result}"
            )
            stdout_result = stdout_result.split(f"{LOGIN_OUTPUT}\n")[1].strip()
        else:
            stdout_result = stdout_result.strip()

        # Check for non-zero exit code
        assert proc.returncode == 0, (
            f"❌ Command '{command_from_config}' exited with code {proc.returncode}\nOutput:\n{stdout_result}"
        )

        # Error patterns to detect failures that might otherwise slip through
        # Please ensure it is aligning with airflowctl.api.client.get_json_error
        error_patterns = [
            "Server error",
            "command error",
            "unrecognized arguments",
            "invalid choice",
            "Traceback (most recent call last):",
        ]
        matched_error = next((error for error in error_patterns if error in stdout_result), None)
        assert not matched_error, (
            f"❌ Output contained unexpected text for command '{command_from_config}'\n"
            f"Matched error pattern: {matched_error}\n"
            f"Output:\n{stdout_result}"
        )

        console.print(f"[green]✅ Output did not contain unexpected text for command '{command_from_config}'")
        console.print(f"[cyan]Result:\n{stdout_result}\n")
        proc.kill()

        return stdout_result

    return _run_command


# Pytest hook to run at the start of the session
def pytest_sessionstart(session):
    """Install airflowctl at the very start of the pytest session."""
    airflow_ctl_version = os.environ.get("AIRFLOW_CTL_VERSION", "0.1.0")
    console.print(f"[yellow]Installing apache-airflow-ctl=={airflow_ctl_version} via pytest_sessionstart...")

    airflow_ctl_path = AIRFLOW_ROOT_PATH / "airflow-ctl"
    console.print(f"[blue]Installing from: {airflow_ctl_path}")

    # Install directly to current UV environment
    console.print("[blue]Installing to current UV environment...")
    console.print(f"[blue]Current Python: {sys.executable}")

    try:
        cmd = ["uv", "pip", "install", str(airflow_ctl_path)]
        console.print(f"[cyan]Running command: {' '.join(cmd)}")
        subprocess.check_call(cmd)
        console.print("[green]airflowctl installed successfully to UV environment via pytest_sessionstart!")
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        console.print(f"[yellow]UV installation failed: {e}")
        raise

    console.print("[yellow]Verifying airflowctl installation via pytest_sessionstart...")
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                "import airflowctl.api.client; print('✅ airflowctl import successful via pytest_sessionstart')",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        console.print(f"[green]{result.stdout.strip()}")
    except subprocess.CalledProcessError as e:
        console.print("[red]❌ airflowctl import verification failed via pytest_sessionstart:")
        console.print(f"[red]Return code: {e.returncode}")
        console.print(f"[red]Stdout: {e.stdout}")
        console.print(f"[red]Stderr: {e.stderr}")
        raise

    docker_compose_up(session.config._tmp_path_factory)


def print_diagnostics(compose, compose_version, docker_version):
    """Print diagnostic information when test fails."""
    console.print("[red]=== DIAGNOSTIC INFORMATION ===[/]")
    console.print(f"Docker version: {docker_version}")
    console.print(f"Docker Compose version: {compose_version}")
    console.print("\n[yellow]Container Status:[/]")
    try:
        containers = compose.compose.ps()
        for container in containers:
            console.print(f"  {container.name}: {container.state}")
    except Exception as e:
        console.print(f"  Error getting container status: {e}")

    console.print("\n[yellow]Container Logs:[/]")
    try:
        logs = compose.compose.logs()
        console.print(logs)
    except Exception as e:
        console.print(f"  Error getting logs: {e}")


def debug_environment():
    """Debug the Python environment setup in CI."""
    import os
    import subprocess
    import sys
    from pathlib import Path

    console.print("[yellow]===== CI ENVIRONMENT DEBUG =====")
    console.print(f"[blue]Python executable: {sys.executable}")
    console.print(f"[blue]Python version: {sys.version}")
    console.print(f"[blue]Working directory: {os.getcwd()}")
    console.print(f"[blue]VIRTUAL_ENV: {os.environ.get('VIRTUAL_ENV', 'Not set')}")
    console.print(f"[blue]PYTHONPATH: {os.environ.get('PYTHONPATH', 'Not set')}")

    console.print(f"[blue]Python executable exists: {Path(sys.executable).exists()}")
    if Path(sys.executable).is_symlink():
        console.print(f"[blue]Python executable is symlink to: {Path(sys.executable).readlink()}")

    try:
        uv_python = subprocess.check_output(["uv", "python", "find"], text=True).strip()
        console.print(f"[cyan]UV Python: {uv_python}")
        console.print(f"[green]Match: {uv_python == sys.executable}")

        console.print(f"[cyan]UV Python exists: {Path(uv_python).exists()}")
        if Path(uv_python).is_symlink():
            console.print(f"[cyan]UV Python is symlink to: {Path(uv_python).readlink()}")
    except Exception as e:
        console.print(f"[red]UV Python error: {e}")

    # Check what's installed in current environment
    try:
        import airflowctl

        console.print(f"[green]✅ airflow already available: {airflowctl.__file__}")
    except ImportError:
        console.print("[red]❌ airflowctl not available in current environment")

    console.print("[yellow]================================")


def docker_compose_up(tmp_path_factory):
    """Fixture to spin up Docker Compose environment for the test session."""
    from shutil import copyfile

    tmp_dir = tmp_path_factory.mktemp("airflow-ctl-test")
    console.print(f"[yellow]Tests are run in {tmp_dir}")

    # Copy docker-compose.yaml to temp directory
    tmp_docker_compose_file = tmp_dir / "docker-compose.yaml"
    copyfile(DOCKER_COMPOSE_FILE_PATH, tmp_docker_compose_file)

    dot_env_file = tmp_dir / ".env"
    dot_env_file.write_text(
        f"AIRFLOW_UID={os.getuid()}\n"
        # To enable config operations to work
        "AIRFLOW__API__EXPOSE_CONFIG=true\n"
    )

    # Set environment variables for the test
    os.environ["AIRFLOW_IMAGE_NAME"] = DOCKER_IMAGE
    os.environ["AIRFLOW_CTL_VERSION"] = os.environ.get("AIRFLOW_CTL_VERSION", "1.0.0")
    os.environ["ENV_FILE_PATH"] = str(tmp_dir / ".env")
    #
    # Please Do not use this Fernet key in any deployments! Please generate your own key.
    # This is specifically generated for integration tests and not as default.
    #
    os.environ["FERNET_KEY"] = generate_fernet_key_string()

    # Initialize Docker client
    _CtlTestState.docker_client = DockerClient(
        compose_files=[str(tmp_docker_compose_file)],
        compose_project_name="breeze-airflowctl-test",
    )

    try:
        console.print(f"[blue]Spinning up airflow environment using {DOCKER_IMAGE}")
        _CtlTestState.docker_client.compose.up(detach=True, wait=True)
        console.print("[green]Docker compose started for airflowctl test\n")
    except Exception:
        print_diagnostics(
            _CtlTestState.docker_client.compose,
            _CtlTestState.docker_client.compose.version(),
            docker.version(),
        )
        debug_environment()
        docker_compose_down()
        raise


def docker_compose_down():
    """Tear down Docker Compose environment."""
    if _CtlTestState.docker_client:
        _CtlTestState.docker_client.compose.down(remove_orphans=True, volumes=True, quiet=True)


def pytest_sessionfinish(session, exitstatus):
    """Tear down test environment at the end of the pytest session."""
    if not os.environ.get("SKIP_DOCKER_COMPOSE_DELETION"):
        docker_compose_down()
