# pyright: reportMissingImports=false

# start
import dagster as dg

from .resources import MyAssetConfig  # ty: ignore[unresolved-import]


@dg.asset
def greeting(config: MyAssetConfig) -> str:
    return f"hello {config.person_name}"


asset_result = dg.materialize(
    [greeting],
    run_config=dg.RunConfig({"greeting": MyAssetConfig(nonexistent_config_value=1)}),
)
# end
