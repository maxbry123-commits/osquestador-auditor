import os
import tempfile
from unittest import mock

from dagster import SensorResult, build_sensor_context
from dagster._core.test_utils import instance_for_test
from docs_snippets.guides.build.partitions_backfills.dynamic_partitioned_asset import (
    image_sensor,
)

DIR = "images"


def test():
    with tempfile.TemporaryDirectory() as tmpdir_path:
        partition_key = "strawberry"
        os.mkdir(os.path.join(tmpdir_path, DIR))
        open(
            os.path.join(tmpdir_path, DIR, partition_key), "a", encoding="utf-8"
        ).close()

        mockenv = mock.patch.dict(
            os.environ, {"MY_DIRECTORY": os.path.join(os.path.join(tmpdir_path, DIR))}
        )
        try:
            mockenv.start()
            with instance_for_test() as instance:
                with build_sensor_context(instance=instance) as context:
                    result = image_sensor(context)
                    assert isinstance(result, SensorResult)
                    assert len(result.run_requests) == 1  # ty: ignore[invalid-argument-type]
                    assert result.run_requests[0].partition_key == partition_key  # ty: ignore[not-subscriptable]
                    assert len(result.dynamic_partitions_requests) == 1  # ty: ignore[invalid-argument-type]
                    assert result.dynamic_partitions_requests[0].partition_keys == [  # ty: ignore[not-subscriptable]
                        partition_key
                    ]

        finally:
            mockenv.stop()
