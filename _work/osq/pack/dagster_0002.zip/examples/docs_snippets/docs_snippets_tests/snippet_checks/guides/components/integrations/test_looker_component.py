import shutil
import textwrap
from contextlib import ExitStack
from pathlib import Path

from dagster_dg_core.utils import activate_venv

from dagster._utils.env import environ
from docs_snippets_tests.snippet_checks.guides.components.utils import (
    DAGSTER_ROOT,
    EDITABLE_DIR,
)
from docs_snippets_tests.snippet_checks.utils import (
    compare_tree_output,
    isolated_snippet_generation_environment,
)

MASK_MY_PROJECT = (r" \/.*?\/my-project", " /.../my-project")
MASK_VENV = (r"Using.*\.venv.*", "")
MASK_USING_LOG_MESSAGE = (r"Using.*\n", "")

SNIPPETS_DIR = (
    DAGSTER_ROOT
    / "examples"
    / "docs_snippets"
    / "docs_snippets"
    / "guides"
    / "components"
    / "integrations"
    / "looker-component"
)


def _swap_to_mock_looker_component(path: Path) -> None:
    path.write_text(
        path.read_text(encoding="utf-8").replace(
            "dagster_looker.LookerComponent",
            "my_project.defs.looker_ingest.test_looker_utils.MockLookerComponent",
        ),
        encoding="utf-8",
    )


def test_components_docs_looker_instance(
    update_snippets: bool,
    update_screenshots: bool,
    get_selenium_driver,
) -> None:
    with ExitStack() as stack:
        context = stack.enter_context(
            isolated_snippet_generation_environment(
                should_update_snippets=update_snippets,
                snapshot_base_dir=SNIPPETS_DIR,
                global_snippet_replace_regexes=[
                    MASK_VENV,
                    MASK_USING_LOG_MESSAGE,
                    MASK_MY_PROJECT,
                ],
            )
        )
        stack.enter_context(
            environ(
                {
                    "LOOKER_BASE_URL": "https://your-company.looker.com",
                    "LOOKER_CLIENT_ID": "XX",
                    "LOOKER_CLIENT_SECRET": "XX",
                }
            )
        )
        # Scaffold code location
        context.run_command_and_snippet_output(
            cmd="create-dagster project my-project --uv-sync --use-editable-dagster && cd my-project/src",
            snippet_path=f"{context.get_next_snip_number()}-scaffold-project.txt",
            snippet_replace_regex=[
                ("--uv-sync --use-editable-dagster ", ""),
                ("--editable.*dagster-looker", "dagster-looker"),
                ("create-dagster", "uvx create-dagster"),
            ],
            ignore_output=True,
        )

        context.run_command_and_snippet_output(
            cmd=f"uv add --editable {EDITABLE_DIR / 'dagster-looker'}",
            snippet_path=f"{context.get_next_snip_number()}-add-looker.txt",
            print_cmd="uv add dagster-looker",
            ignore_output=True,
        )

        stack.enter_context(activate_venv("../.venv"))

        # scaffold looker component
        context.run_command_and_snippet_output(
            cmd="dg scaffold defs dagster_looker.LookerComponent looker_ingest",
            snippet_path=SNIPPETS_DIR
            / f"{context.get_next_snip_number()}-scaffold-looker-component.txt",
        )

        # Tree the project
        context.run_command_and_snippet_output(
            cmd="tree my_project/defs",
            snippet_path=f"{context.get_next_snip_number()}-tree.txt",
            custom_comparison_fn=compare_tree_output,
        )

        context.check_file(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml",
            snippet_path=f"{context.get_next_snip_number()}-component.yaml",
        )

        # Populate the scaffolded component with proper configuration
        context.create_file(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml",
            contents=textwrap.dedent(
                """\
                type: dagster_looker.LookerComponent

                attributes:
                  looker_resource:
                    base_url: "{{ env.LOOKER_BASE_URL }}"
                    client_id: "{{ env.LOOKER_CLIENT_ID }}"
                    client_secret: "{{ env.LOOKER_CLIENT_SECRET }}"
                """
            ),
            snippet_path=f"{context.get_next_snip_number()}-populated-component.yaml",
        )

        # copy test_utils.py to my-project
        shutil.copy(
            Path(__file__).parent / "test_looker_utils.py",
            Path("my_project") / "defs" / "looker_ingest" / "test_looker_utils.py",
        )

        _swap_to_mock_looker_component(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml"
        )
        context.run_command_and_snippet_output(
            cmd="dg list defs",
            snippet_path=f"{context.get_next_snip_number()}-list-defs.txt",
        )

        # Update component.yaml with looker_filter
        context.create_file(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml",
            contents=textwrap.dedent(
                """\
                type: dagster_looker.LookerComponent

                attributes:
                  looker_resource:
                    base_url: "{{ env.LOOKER_BASE_URL }}"
                    client_id: "{{ env.LOOKER_CLIENT_ID }}"
                    client_secret: "{{ env.LOOKER_CLIENT_SECRET }}"
                  looker_filter:
                    dashboard_folders:
                      - ["Shared"]
                    only_fetch_explores_used_in_dashboards: true
                """
            ),
            snippet_path=f"{context.get_next_snip_number()}-customized-component.yaml",
        )

        # Update component.yaml with translation
        context.create_file(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml",
            contents=textwrap.dedent(
                """\
                type: dagster_looker.LookerComponent

                attributes:
                  looker_resource:
                    base_url: "{{ env.LOOKER_BASE_URL }}"
                    client_id: "{{ env.LOOKER_CLIENT_ID }}"
                    client_secret: "{{ env.LOOKER_CLIENT_SECRET }}"
                  translation:
                    group_name: looker_data
                    description: "Looker {{ data.structure_type.value }}"
                """
            ),
            snippet_path=f"{context.get_next_snip_number()}-customized-component.yaml",
        )

        _swap_to_mock_looker_component(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml"
        )
        context.run_command_and_snippet_output(
            cmd="dg list defs",
            snippet_path=f"{context.get_next_snip_number()}-list-defs.txt",
        )

        # Update component.yaml with translation for a specific data type (dashboard)
        context.create_file(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml",
            contents=textwrap.dedent(
                """\
                type: dagster_looker.LookerComponent

                attributes:
                  looker_resource:
                    base_url: "{{ env.LOOKER_BASE_URL }}"
                    client_id: "{{ env.LOOKER_CLIENT_ID }}"
                    client_secret: "{{ env.LOOKER_CLIENT_SECRET }}"
                  translation:
                    for_dashboard:
                      tags:
                        is_dashboard: "true"
                """
            ),
            snippet_path=f"{context.get_next_snip_number()}-customized-dashboard-translation.yaml",
        )

        _swap_to_mock_looker_component(
            Path("my_project") / "defs" / "looker_ingest" / "defs.yaml"
        )
        context.run_command_and_snippet_output(
            cmd="dg list defs --columns name,kinds,tags",
            snippet_path=f"{context.get_next_snip_number()}-list-defs.txt",
        )
