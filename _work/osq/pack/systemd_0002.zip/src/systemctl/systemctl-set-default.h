/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

#include "forward.h"

int verb_get_default(int argc, char *argv[], uintptr_t _data, void *userdata);
int verb_set_default(int argc, char *argv[], uintptr_t _data, void *userdata);
