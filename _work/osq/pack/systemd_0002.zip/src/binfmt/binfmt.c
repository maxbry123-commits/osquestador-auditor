/* SPDX-License-Identifier: LGPL-2.1-or-later */

#include <stdio.h>
#include <sys/stat.h>

#include "sd-json.h"

#include "alloc-util.h"
#include "binfmt-util.h"
#include "build.h"
#include "conf-files.h"
#include "constants.h"
#include "errno-util.h"
#include "fd-util.h"
#include "fileio.h"
#include "log.h"
#include "main-func.h"
#include "pager.h"
#include "path-util.h"
#include "pretty-print.h"
#include "string-util.h"
#include "strv.h"
#include "verbs.h"

static CatFlags arg_cat_flags = CAT_CONFIG_OFF;
static PagerFlags arg_pager_flags = 0;
static bool arg_unregister = false;

COMMAND(
        "systemd-binfmt\0",
        "Register binary formats with the kernel.",
        .argspec = "[CONFIGURATION FILE…]\0",
        .man_pages = "systemd-binfmt.service(8)\0",
        .pager_flags = &arg_pager_flags,
);

static int delete_rule(const char *rulename) {
        const char *fn = strjoina("/proc/sys/fs/binfmt_misc/", rulename);
        return write_string_file(fn, "-1", WRITE_STRING_FILE_DISABLE_BUFFER);
}

static int apply_rule(const char *filename, unsigned line, const char *rule) {
        assert(filename);
        assert(line > 0);
        assert(rule);
        assert(rule[0]);

        _cleanup_free_ char *rulename = NULL;
        int r;

        rulename = strdupcspn(rule + 1, CHAR_TO_STR(rule[0]));
        if (!rulename)
                return log_oom();

        if (!filename_is_valid(rulename) ||
            STR_IN_SET(rulename, "register", "status"))
                return log_error_errno(SYNTHETIC_ERRNO(EINVAL),
                                       "%s:%u: Rule name '%s' is not valid, refusing.",
                                       filename, line, rulename);
        r = delete_rule(rulename);
        if (r < 0 && r != -ENOENT)
                log_warning_errno(r, "%s:%u: Failed to delete rule '%s', ignoring: %m",
                                  filename, line, rulename);
        if (r >= 0)
                log_debug("%s:%u: Rule '%s' deleted.", filename, line, rulename);

        r = write_string_file("/proc/sys/fs/binfmt_misc/register", rule, WRITE_STRING_FILE_DISABLE_BUFFER);
        if (r < 0)
                return log_error_errno(r, "%s:%u: Failed to add binary format '%s': %m",
                                       filename, line, rulename);

        log_debug("%s:%u: Binary format '%s' registered.", filename, line, rulename);
        return 0;
}

static int apply_file(const char *filename, bool ignore_enoent) {
        _cleanup_fclose_ FILE *f = NULL;
        _cleanup_free_ char *pp = NULL;
        int r;

        assert(filename);

        r = search_and_fopen(filename, "re", NULL, (const char**) CONF_PATHS_STRV("binfmt.d"), &f, &pp);
        if (r < 0) {
                if (ignore_enoent && r == -ENOENT)
                        return 0;

                return log_error_errno(r, "Failed to open file '%s': %m", filename);
        }

        log_debug("Applying %s%s", pp, glyph(GLYPH_ELLIPSIS));
        for (unsigned line = 1;; line++) {
                _cleanup_free_ char *text = NULL;
                int k;

                k = read_stripped_line(f, LONG_LINE_MAX, &text);
                if (k < 0)
                        return log_error_errno(k, "Failed to read file '%s': %m", pp);
                if (k == 0)
                        break;

                if (isempty(text))
                        continue;
                if (strchr(COMMENTS, text[0]))
                        continue;

                RET_GATHER(r, apply_rule(filename, line, text));
        }

        return r;
}

static int cat_config(char **files) {
        pager_open(arg_pager_flags);

        return cat_files(NULL, files, arg_cat_flags);
}

static int parse_argv(int argc, char *argv[], char ***ret_args) {
        assert(argc >= 0);
        assert(argv);
        assert(ret_args);

        OptionParser opts = { argc, argv };

        FOREACH_OPTION_OR_RETURN(c, &opts)
                switch (c) {
                OPTION_COMMON_HELP:
                        return command_print_help();

                OPTION_COMMON_VERSION:
                        return version();

                OPTION_COMMON_CAT_CONFIG:
                        arg_cat_flags = CAT_CONFIG_ON;
                        break;

                OPTION_COMMON_TLDR:
                        arg_cat_flags = CAT_TLDR;
                        break;

                OPTION_COMMON_NO_PAGER:
                        arg_pager_flags |= PAGER_DISABLE;
                        break;

                OPTION_LONG("unregister", NULL, "Unregister all existing entries"):
                        arg_unregister = true;
                        break;

                OPTION_COMMON_INTROSPECT_CLI:
                        return introspect_cli(SD_JSON_FORMAT_OFF);
                }

        char **args = option_parser_get_args(&opts);

        if ((arg_unregister || arg_cat_flags != CAT_CONFIG_OFF) && !strv_isempty(args))
                return log_error_errno(SYNTHETIC_ERRNO(EINVAL),
                                       "Positional arguments are not allowed with --cat-config/--tldr or --unregister.");

        *ret_args = args;
        return 1;
}

static int binfmt_mounted_and_writable_warn(void) {
        int r;

        r = binfmt_mounted_and_writable();
        if (r < 0)
                return log_error_errno(r, "Failed to check if /proc/sys/fs/binfmt_misc is mounted: %m");
        if (r == 0)
                log_debug("/proc/sys/fs/binfmt_misc is not mounted in read-write mode, skipping.");

        return r;
}

static int run(int argc, char *argv[]) {
        int r;

        char **args = NULL;
        r = parse_argv(argc, argv, &args);
        if (r <= 0)
                return r;

        log_setup();

        umask(0022);

        r = 0;

        if (arg_unregister)
                return disable_binfmt();

        if (!strv_isempty(args)) {
                r = binfmt_mounted_and_writable_warn();
                if (r <= 0)
                        return r;

                STRV_FOREACH(f, args)
                        RET_GATHER(r, apply_file(*f, false));

        } else {
                _cleanup_strv_free_ char **files = NULL;

                r = conf_files_list_strv(&files, ".conf", /* root= */ NULL, CONF_FILES_WARN, (const char**) CONF_PATHS_STRV("binfmt.d"));
                if (r < 0)
                        return log_error_errno(r, "Failed to enumerate binfmt.d files: %m");

                if (arg_cat_flags != CAT_CONFIG_OFF)
                        return cat_config(files);

                r = binfmt_mounted_and_writable_warn();
                if (r <= 0)
                        return r;

                /* Flush out all rules */
                r = write_string_file("/proc/sys/fs/binfmt_misc/status", "-1", WRITE_STRING_FILE_DISABLE_BUFFER);
                if (r < 0)
                        log_warning_errno(r, "Failed to flush binfmt_misc rules, ignoring: %m");
                else
                        log_debug("Flushed all binfmt_misc rules.");

                STRV_FOREACH(f, files)
                        RET_GATHER(r, apply_file(*f, true));
        }

        return r;
}

DEFINE_MAIN_FUNCTION(run);
