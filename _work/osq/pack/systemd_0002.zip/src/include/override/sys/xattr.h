/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

/* To make struct xattr_args defined, which is used by setxattrat(). Note, the kernel header must be
 * included before the glibc header, otherwise the struct will not be defined. */
#include <linux/xattr.h>        /* IWYU pragma: export */

#include_next <sys/xattr.h>     /* IWYU pragma: export */

/* Supported since kernel v6.13 (6140be90ec70c39fa844741ca3cc807dd0866394). */
int setxattrat_shim(int fd, const char *path, int at_flags, const char *name, const struct xattr_args *args, size_t size);
#define setxattrat setxattrat_shim

/* Supported since kernel v6.13 (6140be90ec70c39fa844741ca3cc807dd0866394). */
int removexattrat_shim(int fd, const char *path, int at_flags, const char *name);
#define removexattrat removexattrat_shim
