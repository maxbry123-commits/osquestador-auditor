/* SPDX-License-Identifier: LGPL-2.1-or-later */

#include "sd-bus.h"

#include "alloc-util.h"
#include "bus-object.h"
#include "dhcp-server-internal.h"
#include "dhcp-server-lease-internal.h"
#include "hashmap.h"
#include "networkd-dhcp-server-bus.h"
#include "networkd-link-bus.h"
#include "networkd-link.h"
#include "networkd-manager.h"

static int property_get_leases(
                sd_bus *bus,
                const char *path,
                const char *interface,
                const char *property,
                sd_bus_message *reply,
                void *userdata,
                sd_bus_error *error) {
        Link *l = ASSERT_PTR(userdata);
        sd_dhcp_server *s;
        sd_dhcp_server_lease *lease;
        int r;

        assert(reply);

        s = l->dhcp_server;
        if (!s)
                return sd_bus_error_setf(error, SD_BUS_ERROR_NOT_SUPPORTED, "Link %s has no DHCP server.", l->ifname);

        r = sd_bus_message_open_container(reply, 'a', "(uayayayayt)");
        if (r < 0)
                return r;

        HASHMAP_FOREACH(lease, s->bound_leases_by_client_id) {
                r = sd_bus_message_open_container(reply, 'r', "uayayayayt");
                if (r < 0)
                        return r;

                r = sd_bus_message_append(reply, "u", (uint32_t)AF_INET);
                if (r < 0)
                        return r;

                r = sd_bus_message_append_array(reply, 'y', lease->client_id.raw, lease->client_id.size);
                if (r < 0)
                        return r;

                r = sd_bus_message_append_array(reply, 'y', &lease->address, sizeof(lease->address));
                if (r < 0)
                        return r;

                r = sd_bus_message_append_array(reply, 'y', &lease->gateway, sizeof(lease->gateway));
                if (r < 0)
                        return r;

                r = sd_bus_message_append_array(reply, 'y', &lease->hw_addr.bytes, lease->hw_addr.length);
                if (r < 0)
                        return r;

                r = sd_bus_message_append_basic(reply, 't', &lease->expiration);
                if (r < 0)
                        return r;

                r = sd_bus_message_close_container(reply);
                if (r < 0)
                        return r;
        }

        return sd_bus_message_close_container(reply);
}

static int property_get_pool_size(
                sd_bus *bus,
                const char *path,
                const char *interface,
                const char *property,
                sd_bus_message *reply,
                void *userdata,
                sd_bus_error *error) {

        Link *l = ASSERT_PTR(userdata);

        assert(reply);

        uint32_t v = l->dhcp_server ? l->dhcp_server->pool_size : UINT32_MAX;
        return sd_bus_message_append_basic(reply, 'u', &v);
}

static int property_get_pool_offset(
                sd_bus *bus,
                const char *path,
                const char *interface,
                const char *property,
                sd_bus_message *reply,
                void *userdata,
                sd_bus_error *error) {

        Link *l = ASSERT_PTR(userdata);

        assert(reply);

        uint32_t v = l->dhcp_server ? l->dhcp_server->pool_offset : UINT32_MAX;
        return sd_bus_message_append_basic(reply, 'u', &v);
}

static int dhcp_server_emit_changed_strv(Link *link, char **properties) {
        _cleanup_free_ char *path = NULL;

        assert(link);

        if (sd_bus_is_ready(link->manager->bus) <= 0)
                return 0;

        path = link_bus_path(link);
        if (!path)
                return log_oom();

        return sd_bus_emit_properties_changed_strv(
                        link->manager->bus,
                        path,
                        "org.freedesktop.network1.DHCPServer",
                        properties);
}

void dhcp_server_callback(sd_dhcp_server *s, uint64_t event, void *data) {
        Link *l = ASSERT_PTR(data);

        if (event & SD_DHCP_SERVER_EVENT_LEASE_CHANGED)
                (void) dhcp_server_emit_changed_strv(l, STRV_MAKE("Leases"));
}

static const sd_bus_vtable dhcp_server_vtable[] = {
        SD_BUS_VTABLE_START(0),

        SD_BUS_PROPERTY("Leases", "a(uayayayayt)", property_get_leases, 0, SD_BUS_VTABLE_PROPERTY_EMITS_CHANGE),
        SD_BUS_PROPERTY("PoolSize", "u", property_get_pool_size, 0, SD_BUS_VTABLE_PROPERTY_CONST),
        SD_BUS_PROPERTY("PoolOffset", "u", property_get_pool_offset, 0, SD_BUS_VTABLE_PROPERTY_CONST),

        SD_BUS_VTABLE_END
};

const BusObjectImplementation dhcp_server_object = {
        "/org/freedesktop/network1/link",
        "org.freedesktop.network1.DHCPServer",
        .fallback_vtables = BUS_FALLBACK_VTABLES({dhcp_server_vtable, link_object_find}),
        .node_enumerator = link_node_enumerator,
};
