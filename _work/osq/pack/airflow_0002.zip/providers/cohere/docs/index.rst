
 .. Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

 ..   http://www.apache.org/licenses/LICENSE-2.0

 .. Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.

``apache-airflow-providers-cohere``
======================================

The ``cohere`` provider gives Dags direct access to Cohere's own Embed API — this page
compares that choice against ``common.ai``.

When to use this provider
--------------------------

Use ``cohere`` when a Dag needs Cohere's native embedding models specifically:

* ``CohereEmbeddingOperator`` — call Cohere's
  `Embed API <https://docs.cohere.com/docs/embeddings>`__ directly via ``CohereHook``.

Use :doc:`apache-airflow-providers-common-ai:index` instead when the embedding step should
stay vendor-neutral:

* Document-to-vector-store pipelines with its document loader, embedding, and retrieval
  operators (see :doc:`apache-airflow-providers-common-ai:operators/index`), which are not
  tied to Cohere's embedding models.

.. toctree::
    :hidden:
    :maxdepth: 1
    :caption: Basics

    Home <self>
    Changelog <changelog>
    Security <security>

.. toctree::
    :hidden:
    :maxdepth: 1
    :caption: Guides

    Connection types <connections>
    Operators <operators/embedding>

.. toctree::
    :hidden:
    :maxdepth: 1
    :caption: Resources

    Python API <_api/airflow/providers/cohere/index>
    PyPI Repository <https://pypi.org/project/apache-airflow-providers-cohere/>
    Installing from sources <installing-providers-from-sources>

.. toctree::
    :hidden:
    :maxdepth: 1
    :caption: System tests

    System Tests <_api/tests/system/cohere/index>


.. THE REMAINDER OF THE FILE IS AUTOMATICALLY GENERATED. IT WILL BE OVERWRITTEN AT RELEASE TIME!


.. toctree::
    :hidden:
    :maxdepth: 1
    :caption: Commits

    Detailed list of commits <commits>


apache-airflow-providers-cohere package
------------------------------------------------------

`Cohere <https://docs.cohere.com/docs>`__


Release: 1.6.7

Provider package
----------------

This package is for the ``cohere`` provider.
All classes for this package are included in the ``airflow.providers.cohere`` python package.

Installation
------------

You can install this package on top of an existing Airflow installation via
``pip install apache-airflow-providers-cohere``.
For the minimum Airflow version supported, see ``Requirements`` below.

Requirements
------------

The minimum Apache Airflow version supported by this provider distribution is ``2.11.0``.

==========================================  ==================================================================
PIP package                                 Version required
==========================================  ==================================================================
``apache-airflow``                          ``>=2.11.0``
``apache-airflow-providers-common-compat``  ``>=1.8.0``
``cohere``                                  ``>=5.13.4``
``fastavro``                                ``>=1.10.0; python_version >= "3.13" and python_version < "3.14"``
``fastavro``                                ``>=1.12.1; python_version >= "3.14"``
==========================================  ==================================================================

Downloading official packages
-----------------------------

You can download officially released packages and verify their checksums and signatures from the
`Official Apache Download site <https://downloads.apache.org/airflow/providers/>`_

* `The apache-airflow-providers-cohere 1.6.7 sdist package <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7.tar.gz>`_ (`asc <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7.tar.gz.asc>`__, `sha512 <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7.tar.gz.sha512>`__)
* `The apache-airflow-providers-cohere 1.6.7 wheel package <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7-py3-none-any.whl>`_ (`asc <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7-py3-none-any.whl.asc>`__, `sha512 <https://downloads.apache.org/airflow/providers/apache_airflow_providers_cohere-1.6.7-py3-none-any.whl.sha512>`__)
