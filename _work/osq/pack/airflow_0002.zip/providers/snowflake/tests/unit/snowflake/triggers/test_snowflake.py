# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import asyncio
from datetime import timedelta
from unittest import mock

import pytest

from airflow.providers.snowflake.triggers.snowflake_trigger import SnowflakeSqlApiTrigger
from airflow.triggers.base import TriggerEvent

TASK_ID = "snowflake_check"
POLL_INTERVAL = 1.0
LIFETIME = timedelta(minutes=59)
RENEWAL_DELTA = timedelta(minutes=54)
MODULE = "airflow.providers.snowflake"
QUERY_IDS = ["uuid"]


class TestSnowflakeSqlApiTrigger:
    TRIGGER = SnowflakeSqlApiTrigger(
        poll_interval=POLL_INTERVAL,
        query_ids=QUERY_IDS,
        snowflake_conn_id="test_conn",
        token_life_time=LIFETIME,
        token_renewal_delta=RENEWAL_DELTA,
    )

    def test_snowflake_sql_trigger_serialization(self):
        """
        Asserts that the SnowflakeSqlApiTrigger correctly serializes its arguments
        and classpath.
        """
        classpath, kwargs = self.TRIGGER.serialize()
        assert classpath == "airflow.providers.snowflake.triggers.snowflake_trigger.SnowflakeSqlApiTrigger"
        assert kwargs == {
            "poll_interval": POLL_INTERVAL,
            "query_ids": ["uuid"],
            "snowflake_conn_id": "test_conn",
            "token_life_time": LIFETIME,
            "token_renewal_delta": RENEWAL_DELTA,
            "cancel_on_kill": True,
        }

    def test_snowflake_sql_trigger_serialization_cancel_on_kill_false(self):
        """cancel_on_kill=False round-trips through serialization."""
        trigger = SnowflakeSqlApiTrigger(
            poll_interval=POLL_INTERVAL,
            query_ids=QUERY_IDS,
            snowflake_conn_id="test_conn",
            token_life_time=LIFETIME,
            token_renewal_delta=RENEWAL_DELTA,
            cancel_on_kill=False,
        )
        _, kwargs = trigger.serialize()
        assert kwargs["cancel_on_kill"] is False

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiHook")
    async def test_on_kill_cancels_the_queries(self, mock_hook):
        """on_kill() cancels the running queries when enabled and query_ids are set."""
        await self.TRIGGER.on_kill()
        mock_hook.assert_called_once_with("test_conn", LIFETIME, RENEWAL_DELTA)
        mock_hook.return_value.cancel_queries.assert_called_once_with(QUERY_IDS)

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        ("cancel_on_kill", "query_ids"),
        [
            pytest.param(False, QUERY_IDS, id="disabled"),
            pytest.param(True, [], id="no-query-ids"),
        ],
    )
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiHook")
    async def test_on_kill_does_not_cancel(self, mock_hook, cancel_on_kill, query_ids):
        """on_kill() is a no-op (no hook built) when disabled or without query_ids."""
        trigger = SnowflakeSqlApiTrigger(
            poll_interval=POLL_INTERVAL,
            query_ids=query_ids,
            snowflake_conn_id="test_conn",
            token_life_time=LIFETIME,
            token_renewal_delta=RENEWAL_DELTA,
            cancel_on_kill=cancel_on_kill,
        )
        await trigger.on_kill()
        mock_hook.assert_not_called()

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiHook")
    async def test_on_kill_swallows_cancel_errors(self, mock_hook):
        """on_kill() logs and swallows exceptions raised while cancelling."""
        mock_hook.return_value.cancel_queries.side_effect = Exception("Snowflake API error")
        await self.TRIGGER.on_kill()
        mock_hook.return_value.cancel_queries.assert_called_once_with(QUERY_IDS)

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiHook")
    async def test_on_kill_cancels_remaining_after_one_fails(self, mock_hook):
        """A failure cancelling one query id does not abort cancelling the remaining ids."""
        trigger = SnowflakeSqlApiTrigger(
            poll_interval=POLL_INTERVAL,
            query_ids=["q1", "q2", "q3"],
            snowflake_conn_id="test_conn",
            token_life_time=LIFETIME,
            token_renewal_delta=RENEWAL_DELTA,
        )
        mock_hook.return_value.cancel_queries.side_effect = [RuntimeError("404 not found"), None, None]
        await trigger.on_kill()
        assert mock_hook.return_value.cancel_queries.call_args_list == [
            mock.call(["q1"]),
            mock.call(["q2"]),
            mock.call(["q3"]),
        ]

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiTrigger.get_query_status")
    @mock.patch(f"{MODULE}.hooks.snowflake_sql_api.SnowflakeSqlApiHook.get_sql_api_query_status_async")
    async def test_snowflake_sql_trigger_running(
        self, mock_get_sql_api_query_status_async, mock_get_query_status
    ):
        """Tests that the SnowflakeSqlApiTrigger in running by mocking get_query_status to true"""
        mock_get_query_status.return_value = {"status": "running"}

        task = asyncio.create_task(self.TRIGGER.run().__anext__())
        await asyncio.sleep(0.5)

        # TriggerEvent was not returned
        assert task.done() is False
        asyncio.get_event_loop().stop()

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.triggers.snowflake_trigger.SnowflakeSqlApiTrigger.get_query_status")
    @mock.patch(f"{MODULE}.hooks.snowflake_sql_api.SnowflakeSqlApiHook.get_sql_api_query_status_async")
    async def test_snowflake_sql_trigger_completed(
        self, mock_get_sql_api_query_status_async, mock_get_query_status
    ):
        """
        Test SnowflakeSqlApiTrigger run method with success status and mock the get_sql_api_query_status
         result and  get_query_status to False.
        """
        statement_query_ids = ["uuid", "uuid1"]
        mock_get_query_status.return_value = {"status": "success", "statement_handles": statement_query_ids}
        mock_get_sql_api_query_status_async.return_value = {
            "message": "Statement executed successfully.",
            "status": "success",
            "statement_handles": statement_query_ids,
        }

        generator = self.TRIGGER.run()
        actual = await generator.asend(None)
        assert TriggerEvent({"status": "success", "statement_query_ids": QUERY_IDS}) == actual

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.hooks.snowflake_sql_api.SnowflakeSqlApiHook.get_sql_api_query_status_async")
    async def test_snowflake_sql_trigger_failure_status(self, mock_get_sql_api_query_status_async):
        """Test SnowflakeSqlApiTrigger task is executed and triggered with failure status."""
        mock_response = {
            "status": "error",
            "message": "An error occurred when executing the statement. Check "
            "the error code and error message for details",
        }
        mock_get_sql_api_query_status_async.return_value = mock_response

        generator = self.TRIGGER.run()
        actual = await generator.asend(None)
        assert TriggerEvent(mock_response) == actual

    @pytest.mark.asyncio
    @mock.patch(f"{MODULE}.hooks.snowflake_sql_api.SnowflakeSqlApiHook.get_sql_api_query_status_async")
    async def test_snowflake_sql_trigger_exception(self, mock_get_sql_api_query_status_async):
        """Tests the SnowflakeSqlApiTrigger does not fire if there is an exception."""
        mock_get_sql_api_query_status_async.side_effect = Exception("Test exception")

        task = [i async for i in self.TRIGGER.run()]
        assert len(task) == 1
        assert TriggerEvent({"status": "error", "message": "Test exception"}) in task
