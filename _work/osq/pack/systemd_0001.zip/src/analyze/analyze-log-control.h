/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

#include "forward.h"

int verb_log_control(int argc, char *argv[], uintptr_t _data, void *userdata);
