/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

#include "forward.h"

int verb_unit_gdb(int argc, char *argv[], uintptr_t _data, void *userdata);
