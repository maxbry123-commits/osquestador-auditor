/* SPDX-License-Identifier: LGPL-2.1-or-later */
#pragma once

#include "efi.h"

#include "../fundamental/edid.h" /* IWYU pragma: export */

EFI_STATUS edid_get_discovered_panel_id(char16_t **ret_panel);
