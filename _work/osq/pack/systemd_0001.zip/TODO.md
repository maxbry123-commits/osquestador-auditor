---
title: TODO
category: Contributing
layout: default
SPDX-License-Identifier: LGPL-2.1-or-later
---

# TODO

## Bugfixes

- Many manager configuration settings that are only applicable to user
  manager or system manager can be always set. It would be better to reject
  them when parsing config.

- Jun 01 09:43:02 krowka systemd[1]: Unit user@1000.service has alias user@.service.
  Jun 01 09:43:02 krowka systemd[1]: Unit user@6.service has alias user@.service.
  Jun 01 09:43:02 krowka systemd[1]: Unit user-runtime-dir@6.service has alias user-runtime-dir@.service.

## External

- Fedora: add an rpmlint check that verifies that all unit files in the RPM are listed in %systemd_post macros.

- **dbus:**
  - natively watch for dbus-*.service symlinks (PENDING)
  - teach dbus to activate all services it finds in /etc/systemd/services/org-*.service

- fedora: suggest auto-restart on failure, but not on success and not on coredump. also, ask people to think about changing the start limit logic. Also point people to RestartPreventExitStatus=, SuccessExitStatus=

- neither pkexec nor sudo initialize environ[] from the PAM environment?

- fedora: update policy to declare access mode and ownership of unit files to root:root 0644, and add an rpmlint check for it

- **missing shell completions:**
  - **zsh:**
    - `<command> <verb> -<TAB>` should complete options, but currently does not
    - systemctl add-wants,add-requires
    - systemctl reboot --boot-loader-entry=

- systemctl status should know about 'systemd-analyze calendar ... --iterations='
- If timer has just OnInactiveSec=..., it should fire after a specified time
  after being started.

- **write blog stories about:**
  - hwdb: what belongs into it, lsusb
  - enabling dbus services
  - how to make changes to sysctl and sysfs attributes
  - remote access
  - how to pass throw-away units to systemd, or dynamically change properties of existing units
  - auto-restart
  - how to develop against journal browsing APIs
  - the journal HTTP iface
  - non-cgroup resource management
  - dynamic resource management with cgroups
  - refreshed, longer missions statement
  - calendar time events
  - init=/bin/sh vs. "emergency" mode, vs. "rescue" mode, vs. "multi-user" mode, vs. "graphical" mode, and the debug shell
  - how to create your own target
  - instantiated apache, dovecot and so on
  - hooking a script into various stages of shutdown/early boot

## Regularly

- look for close() vs. close_nointr() vs. close_nointr_nofail()

- check for strerror(r) instead of strerror(-r)

- pahole

- set_put(), hashmap_put() return values check. i.e. == 0 does not free()!

- link up selected blog stories from man pages and unit files Documentation= fields

## Janitorial Cleanups

- machined: make remaining machine bus calls compatible with unpriv machined +
  unpriv npsawn: GetAddresses(), GetSSHInfo(), GetOSRelease(), OpenPTY(),
  OpenLogin(), OpenShell(), BindMount(), CopyFrom(), CopyTo(),
  OpenRootDirectory(). Similar for images: GetHostname(), GetMachineID(),
  GetMachineInfo(), GetOSRelease().

- rework mount.c and swap.c to follow proper state enumeration/deserialization
  semantics, like we do for device.c now

- Replace our fstype_is_network() with a call to libmount's mnt_fstype_is_netfs()?
  Having two lists is not nice, but maybe it's now worth making a dependency on
  libmount for something so trivial.

- drop set_free_free() and switch things over from string_hash_ops to
  string_hash_ops_free everywhere, so that destruction is implicit rather than
  explicit. Similar, for other special hashmap/set/ordered_hashmap destructors.

- generators sometimes apply C escaping and sometimes specifier escaping to
  paths and similar strings they write out. Sometimes both. We should clean
  this up, and should probably always apply both, i.e. introduce
  unit_file_escape() or so, which applies both.

- xopenat() should pin the parent dir of the inode it creates before doing its
  thing, so that it can create, open, label somewhat atomically.

- use CHASE_MUST_BE_DIRECTORY and CHASE_MUST_BE_REGULAR at more places (the
  majority of places that currently employ chase() probably should use this)

## Deprecations and Removals

- Remove any support for booting without /usr pre-mounted in the initrd entirely.
  Update INITRD_INTERFACE.md accordingly.

- remove cgroups v1 support (overdue since EOY 2023). As per
  https://lists.freedesktop.org/archives/systemd-devel/2022-July/048120.html
  and then rework cgroupsv2 support around fds, i.e. keep one fd per active
  unit around, and always operate on that, instead of cgroup fs paths.

- drop support for LOOP_CONFIGURE-less loopback block devices, once kernel
  baseline is 5.8.

- Remove /dev/mem ACPI FPDT parsing when /sys/firmware/acpi/fpdt is ubiquitous.
  That requires distros to enable CONFIG_ACPI_FPDT, and have kernels v5.12 for
  x86 and v6.2 for arm.

- Consider removing root=gpt-auto, and push people to use root=dissect instead.

- remove any trace of "cpuacct" cgroup controller, it's a cgroupv1 thing.
  similar "devices"

- drop socket_xattr_supported() once our baseline is kernel 7.0

## Features

- sysupdate: run things in a loop always, to deal with stepping stones, and
  adding new transfer files. finish, when stable.

- sysupdate: add flag field for features and components, to require a restart
  of the update loop once they have been updated.

- confext/sysext: add policy file concept: json files that encode for rleevant
  confext/sysext ddis rules when to enable them, i.e. version checks. also use
  it for the garbage collector

- confext/sysext: mark system as refusing refreshes until reboot if
  confext/sysext says it require a reboot

- cryptsetup: add a new switch which makes it wait for the keyfile to
  appear. use inotify/mount watching for that. usecase: system waits at boot
  for some key to be supplied, possibly delivered via confext or so. This could
  be useful in particular in CoCo scenarios where a disk encryption key is only
  handed out once an attestation run completed, and might be delivered to the
  node asynchronously.

- acquire a TSA from time stamping server, include it in report

- **report:**
  - implement signer for TPM2 that adds a quote + event log excerpt as signing
    object. should include a TPM timestamp, and some "generation ID" provided
    by an orchestrator to guarantee freshness.
  - implement metrics provider in logind: report number of active
    sessions, and number of sessions since boot.
  - implement metrics provider in journald that reports number of log messages
    received since boot, by log priority
  - allow to compile statically (together with the basic and cgroup
    backends)
  - make sure backends can also be invoked via forking off
  - allow metrics providers to indicate which reported values mean
    "nothing"/"invalid"/"zero"/"please-suppress". Then use that to reduce noise
    in systemd-report output.
  - teach cgroup metrics provider to expose PSI information
  - implement metrics provider that reports local IP addresses, and bound open
    IP ports
  - metrics from pid1: suppress metrics form units that are inactive and have nothing to report
  - pass filtering hints to services, so that they can also be applied server-side, not just client side
  - add "hint-suppress-zero" flag (which suppresses all metrics which are zero)
  - add "hint-object" parameter (which only queries info about certain object)
  - make systemd-report a varlink service

- bootctl set-tries for setting retry counters on boot entries

- implement enough of PCP in a new sd-pcp-client library that networkd can use
  to punch holes for wireguard into common NAT routers. use that in networkd. alternatively: just use libjuice

- measure an uapi16 manifest of /etc/ during early boot (so that
  pre-initialized /etc/ can be detected when systems are enrolled into some
  subsystem)

- optionally turn off import of imds on non-firstboot creds (so that IMDS can
  be considered an attack vector, except for TOFU)

- store workload identity OIDC server contact info in cloud imds hwdb.

- systemd-analyze unit-shell-me-harder that has both host and unit trees around
  but mostly lives in unit namespces

- os-release consumption at boot: version validation, and maybe in os-release

- ed25519 authentication for sd-boot upgrades for the dm-verity key logic

- in sysupdate resolve %C or so as specifier in transfer fields to the value of
  a specific machine tag channel= or so.

- make vmspawn parse UKIs for direct kernel boot

- portabled driving by system credential

- sysinstall: add fully automatic mode that automatically picks target disk,
  non-interactively. Should wait to ensure system is up for a certain amount of
  minimal time (alternatively: certain amount of time since the last disk
  showed up), to ensure disks have shown up before making the decision. Usecase
  for this: redfish style server provisioning.

- nspawn: optionally provide a /dev/tpm0 + /dev/tpmrm0 that is backed by swtpm,
  much like we do in vmspawn. let's us minimize differences between
  environments systemd runs in.

- nspawn/vmspawn: add a concept how we can hand into the payload some proof
  that it is running on a certain host, which it can then include in the report,
  and which allows us to put together a map about which node runs as payload of
  which other note. in particular useful for transient nodes, as it gives them
  a better location

- add a small varlink service that wraps the raw sftp logic (without ssh) after a
  varlink protocol upgrade, which enables varlink clients to do file transfers,
  which is in particular useful when accessing a system via http varlink proxy

- add a small varlink service that allocates a pty and then does ptyfwd stuff
  after a protocol upgrade on the incoming connection. Then spawn a shell/getty
  on it. This enables varlink clients to acquire a fully featured ssh-like
  interactive tty/shell via varlink, which is again useful via http varlink
  proxy.

- add something like podman's conmon as a native systemd subsystem:
  i.e. allocate ptys, that can be bound to stdio/console of containers and VMs,
  that maintain a bit of a scrollback buffer, and one can reconnect to
  later. fun idea: might even make /dev/tty1 and friends accessible via
  /dev/vcsa1 under the same protocol. this subsystem should potentially be the
  same as the varlink ssh-like thing listed above.

- maybe introduce a new ansi sequence that allows propagate SIGWINCH
  inline. Idea would be: to enable inline notification of window sizes client
  sends a new, to be defined ANSI sequence with its current assumption of
  terminal size. Server compares it with current state. If the same it sends
  nothing immediately, but does send exactly one update if it changes, and
  disables the logic. If not the same sends correction immediately, and
  disables the logic. Client has to reissue sequence immediately after getting
  notification to get live updates. Benefit of all of this: better terminal
  experience if we just forward terminal bytes through a serial link/stream
  connection, as terminal sizes will be properly propagated. Write a UAPI spec
  for all this. ptyfwd could translate turn upstream SIGWINCH into upstream
  sequences of this type, so that every step of the way we get the right
  behaviour.

- implement "varlinkctl trace" or so, that watches socket traffic on a group of
  processes (select by pid, select by cgroup, select by all machine), and shows
  traffic of all sockets marked via the new varlink socket xattrs. Use BPF for
  all of that of course.

- add tooling for generating dictionary-based hostnames

- do not pull dbus daemon/broker anymore, instead lazy activate it. Given how
  the Varlinkifcation has progressed various non-desktop usescase might not
  need D-Bus running at all anymore.

- format-table: introduce the concept of a "title" for a table, which remains
  closely associated with the table. in most cases where want to output
  multiple tables from the same tool we want to separate things with a title,
  hence we might as well associate the title with the table itself, and
  streamline a few things.

- sysupdate: offer reading transfer files/components/features optionally from
  some JSON fragment rather than transfer files, so that we can update it
  independently from any DDI, and it needs no activation cycle. Why? so that
  making additional transfers/components/features available can be done without
  reloading confext/sysext, and out-band with other configuration changes.

- sysupdate: go through all components, and update them all, one by one.

- pcrextend: we probably should measure /etc/machine-info during boot somehow

- pcrextend: we should measure something when we enter developer mode, by some
  definition of developer mode.

- firstboot: optionally accept credentials at firstboot without authentication

- firstboot/sysinstall: add simple interface for prompting users to enable
  "features" exposed by of sysupdate.

- a tool that can prep credentials, put them in the ESP, for provisioning
  systems for SBC or UEFI/HTTP boot. Should be doing what sysinstall does with
  the credentials, and maybe even *be* sysinstall.

- make sure we always pass O_NOFOLLOW on O_CREAT

- xopenat(): maybe imply O_NOFOLLOW on O_CREAT

- StorageProvider interface + storagectl
  - hook-up in systemd-nspawn
  - hook-up in service manager (BindVolume=)
  - introduce a locking concept: right now all access to volumes is fully
    shared. Let's add a basic locking concept: supporting backends can take an
    additional locking flag (which has to be combined with Varlink's "more"),
    in which case access would only be handed out to one client at a time, with
    the lock's lifetime synced up with the Varlink connection lifetime.
  - introduce a volume lifecycle concept: optionally support volumes whose
    whole lifecycle is associated with the varlink connections they are tied
    to: when the last varlink connection that acquired them goes away, the
    volume is auto-destroyed. Would be exposed via a new flag on the Acquire
    call, similar to the locking logic above.

- clean up credential naming a bit: let's say encrypted creds always should
  carry .cred suffix, and unencrypted should not.

- clean up naming of sidecar files in sd-stub: let's put global ones strictly
  into /loader/extras/

- a small tool that can do basic btrfs raid policy mgmt. i.e. gets started as
  part of the initial transaction for some btrfs raid fs, waits for some time,
  then puts message on screen (plymouth, console) that some devices apparently
  are not showing up, then counts down, eventually set a flag somewhere, and
  retriggers the fs is was invoked for, which causes the udev rules to rerun
  that assemble the btrfs raid, but this time force degraded assembly.

- a way for container managers to turn off getty starting via $container_headless= or so...

- add "conditions" for bls type 1 and type 2 profiles that allow suppressing
  them under various conditions: 1. if tpm2 is available or not available;
  2. if sb is on or off; 3. if we are netbooted or not; …

- add "homectl export" and "homectl import" that gets you an "atomic" snapshot
  of your homedir, i.e. either a tarball or a snapshot of the underlying disk
  (use FREEZE/THAW to make it consistent, btrfs snapshots)

- Add "purpose" flag to partition flags in discoverable partition spec that
  indicate if partition is intended for sysext, for portable service, for
  booting and so on. Then, when dissecting DDI allow specifying a purpose to
  use as additional search condition. Use case: images that combined a sysext
  partition with a portable service partition in one.

- **systemd-sysinstall:**
  - make systemd-sysinstall itself a varlink service
  - read installation definition from json file
  - polkit support in sysinstall
  - sysinstall: permit driving installer via credentials
  - add --offline=no mode where we talk to socket based services rather than forking off
  - if a user doesn't pick a locale during boot into installer, don't ask again after install, because we suppressed credential propagation

- repart: add MatchLabel= which matches against partition label, so that we
  truly can install different images in parallel

- add "systemctl wait" or so, which does what "systemd-run --wait" does, but
  for all units. It should be both a way to pin units into memory as well as a
  wait to retrieve their exit data.

- add "systemd-analyze debug" + AttachDebugger= in unit files: The former
  specifies a command to execute; the latter specifies that an already running
  "systemd-analyze debug" instance shall be contacted and execution paused
  until it gives an OK. That way, tools like gdb or strace can be safely be
  invoked on processes forked off PID 1.

- add "systemd-sysext identify" verb, that you can point on any file in /usr/
  and that determines from which overlayfs layer it originates, which image, and with
  what it was signed.

- add --vacuum-xyz options to coredumpctl, matching those journalctl already has.

- sysupdate: in .transfer files have a 2nd url that is used if we
  auto-rollbacked the OS before.

- sysupdate: optionally enrich URL with countme=1 once a week

- sysupdate: have an explicit concept of update policies: i.e. a choice of at least
  - download list + report updates in motd – but do not auto update
  - download list + download new version – but do not apply it
  - download list + download new version + apply it – but do not reboot
  - download list + download new version + apply it + reboot
  Other things the policy should contain is when to place the reboot.
  This would all decouple the updating of the package list from the application
  of it. Which is great for "countme" style stuff.

- Add a "systemctl list-units --by-slice" mode or so, which rearranges the
  output of "systemctl list-units" slightly by showing the tree structure of
  the slices, and the units attached to them.

- Add a concept of ListenStream=anonymous to socket units: listen on a socket
  that is deleted in the fs. Use case would be with ConnectSocket= above.

- add a ConnectSocket= setting to service unit files, that may reference a
  socket unit, and which will connect to the socket defined therein, and pass
  the resulting fd to the service program via socket activation proto.

- add a dbus call to generate target from current state

- add a dependency on standard-conf.xml and other included files to man pages

- add a job mode that will fail if a transaction would mean stopping
  running units. Use this in timedated to manage the NTP service
  state.
  https://lists.freedesktop.org/archives/systemd-devel/2015-April/030229.html

- add a kernel cmdline switch (and cred?) for marking a system to be
  "headless", in which case we never open /dev/console for reading, only for
  writing. This would then mean: systemd-firstboot would process creds but not
  ask interactively, getty would not be started and so on.

- add a Load= setting which takes literal data in text or base64 format, and
  puts it into a memfd, and passes that. This enables some fun stuff, such as
  embedding bash scripts in unit files, by combining Load= with
  ExecStart=/bin/bash /proc/self/fd/3

- add a mechanism we can drop capabilities from pid1 *before* transitioning
  from initrd to host. i.e. before we transition into the slightly lower trust
  domain that is the host systems we might want to get rid of some caps.
  Example: CAP_SYS_BPF in the signed bpf loading logic above. (We already have
  CapabilityBoundingSet= in system.conf, but that is enforced when pid 1
  initializes, rather then when it transitions to the next.)

- add a new "debug" job mode, that is propagated to unit_start() and for
  services results in two things: we raise SIGSTOP right before invoking
  execve() and turn off watchdog support. Then, use that to implement
  "systemd-gdb" for attaching to the start-up of any system service in its
  natural habitat.

- add a new flag to chase() that stops chasing once the first missing
  component is found and then allows the caller to create the rest.

- add a new PE binary section ".mokkeys" or so which sd-stub will insert into
  Mok keyring, by overriding/extending whatever shim sets in the EFI
  var. Benefit: we can extend the kernel module keyring at ukify time,
  i.e. without recompiling the kernel, taking an upstream OS' kernel and adding
  a local key to it.

- add a new specifier to unit files that figures out the DDI the unit file is
  from, tracing through overlayfs, DM, loopback block device.

- add a new switch --auto-definitions=yes/no or so to systemd-repart. If
  specified, synthesize a definition automatically if we can: enlarge last
  partition on disk, but only if it is marked for growing and not read-only.

- add a new syscall group "@esoteric" for more esoteric stuff such as bpf() and
  usefaultd() and make systemd-analyze check for it.

- Add a new verb "systemctl top"

- add a pam module that on password changes updates any LUKS slot where the password matches

- add a percentage syntax for TimeoutStopSec=, e.g. TimeoutStopSec=150%, and
  then use that for the setting used in user@.service. It should be understood
  relative to the configured default value.

- add a plugin for factory reset logic that erases certain parts of the ESP,
  but leaves others in place.

- add a proper concept of a "developer" mode, i.e. where cryptographic
  protections of the root OS are weakened after interactive confirmation, to
  allow hackers to allow their own stuff. idea: allow entering developer mode
  only via explicit choice in boot menu: i.e. add explicit boot menu item for
  it. When developer mode is entered, generate a key pair in the TPM2, and add
  the public part of it automatically to keychain of valid code signature keys
  on subsequent boots. Then provide a tool to sign code with the key in the
  TPM2. Ensure that boot menu item is the only way to enter developer mode, by
  binding it to locality/PCRs so that keys cannot be generated otherwise.

- add a system-wide seccomp filter list for syscalls, kill "acct()" "@obsolete"
  and a few other legacy syscalls that way.

- add a test if all entries in the catalog are properly formatted.
  (Adding dashes in a catalog entry currently results in the catalog entry
  being silently skipped. journalctl --update-catalog must warn about this,
  and we should also have a unit test to check that all our message are OK.)

- add a utility that can be used with the kernel's
  CONFIG_STATIC_USERMODEHELPER_PATH and then handles them within pid1 so that
  security, resource management and cgroup settings can be enforced properly
  for all umh processes.

- add a way to lock down cgroup migration: a boolean, which when set for a unit
  makes sure the processes in it can never migrate out of it

- add ability to path_is_valid() to classify paths that refer to a dir from
  those which may refer to anything, and use that in various places to filter
  early. i.e. stuff ending in "/", "/." and "/.." definitely refers to a
  directory, and paths ending that way can be refused early in many contexts.

- Add ACL-based access management to .socket units. i.e. add AllowPeerUser= +
  AllowPeerGroup= that installs additional user/group ACL entries on AF_UNIX
  sockets.

- Add AddUser= setting to unit files, similar to DynamicUser=1 which however
  creates a static, persistent user rather than a dynamic, transient user. We
  can leverage code from sysusers.d for this.

- add an explicit parser for LimitRTPRIO= that verifies
  the specified range and generates sane error messages for incorrect
  specifications.

- Add and pickup tpm2 metadata for creds structure.

- add another PE section ".fname" or so that encodes the intended filename for
  PE file, and validate that when loading add-ons and similar before using
  it. This is particularly relevant when we load multiple add-ons and want to
  sort them to apply them in a define order. The order should not be under
  control of the attacker.

- add bus API for creating unit files in /etc, reusing the code for transient units

- add bus api to query unit file's X fields.

- add bus API to remove unit files from /etc

- add bus API to retrieve current unit file contents (i.e. implement "systemctl cat" on the bus only)

- Add ConditionDirectoryNotEmpty= handle non-absolute paths as a search path or add
  ConditionConfigSearchPathNotEmpty= or different syntax? See the discussion starting at
  https://github.com/systemd/systemd/pull/15109#issuecomment-607740136.

- add CopyFile= or so as unit file setting that may be used to copy files or
  directory trees from the host to the services RootImage= and RootDirectory=
  environment. Which we can use for /etc/machine-id and in particular
  /etc/resolv.conf. Should be smart and do something useful on read-only
  images, for example fall back to read-only bind mounting the file instead.

- Add ELF section to make systemd main binary recognizable cleanly, the same
  way as we make sd-boot recognizable via PE section.

- Add ExecMonitor= setting. May be used multiple times. Forks off a process in
  the service cgroup, which is supposed to monitor the service, and when it
  exits the service is considered failed by its monitor.

- add field to bls type 1 and type 2 profiles that ensures an item is never
  considered for automatic selection

- add generator that pulls in systemd-network from containers when
  CAP_NET_ADMIN is set, more than the loopback device is defined, even
  when it is otherwise off

- add growvol and makevol options for /etc/crypttab, similar to
  x-systemd.growfs and x-systemd-makefs.

- Add knob to cryptsetup, to trigger automatic reboot on failure to unlock
  disk. Enable this by default for rootfs, also in gpt-auto-generator

- add linker script that implicitly adds symbol for build ID and new coredump
  json package metadata, and use that when logging

- add new gpt type for btrfs volumes

- add new tool that can be used in debug mode runs in very early boot,
  generates a random password, passes it as credential to sysusers for the root
  user, then displays it on screen. people can use this to remotely log in.

- add option to sockets to avoid activation. Instead just drop packets/connections, see http://cyberelk.net/tim/2012/02/15/portreserve-systemd-solution/

- add PR_SET_DUMPABLE service setting

- add proper .osrel matching for PE addons. i.e. refuse applying an addon
  intended for a different OS. Take inspiration from how confext/sysext are
  matched against OS.

- add proper dbus APIs for the various sd_notify() commands, such as MAINPID=1
  and so on, which would mean we could report errors and such.

- add service file setting to force the fwmark (a la SO_MARK) to some value, so
  that we can allowlist certain services for imds this way.

- Add service unit setting ConnectStream= which takes IP addresses and connects to them.

- add some optional flag to ReadWritePaths= and friends, that has the effect
  that we create the dir in question when the service is started. Example:

  ReadWritePaths=:/var/lib/foobar

- add some service that makes an atomic snapshot of PCR state and event log up
  to that point available, possibly even with quote by the TPM.

- add some special mode to LogsDirectory=/StateDirectory=… that allows
  declaring these directories without necessarily pulling in deps for them, or
  creating them when starting up. That way, we could declare that
  systemd-journald writes to /var/log/journal, which could be useful when we
  doing disk usage calculations and so on.

- add support for "portablectl attach http://foobar.com/waaa.raw (i.e. importd integration)

- add support for activating nvme-oF devices at boot automatically via kernel
  cmdline, and maybe even support a syntax such as
  root=nvme:\<trtype>:\<traddr>:\<trsvcid>:\<nqn>:\<partition> to boot directly from
  nvme-oF

- add support for asymmetric LUKS2 TPM based encryption. i.e. allow preparing
  an encrypted image on some host given a public key belonging to a specific
  other host, so that only hosts possessing the private key in the TPM2 chip
  can decrypt the volume key and activate the volume. Use case: systemd-confext
  for a central orchestrator to generate confext images securely that can only
  be activated on one specific host (which can be used for installing a bunch
  of creds in /etc/credstore/ for example). Extending on this: allow binding
  LUKS2 TPM based encryption also to the TPM2 internal clock. Net result:
  prepare a confext image that can only be activated on a specific host that
  runs a specific software in a specific time window. confext would be
  automatically invalidated outside of it.

- Add support for extra verity configuration options to systemd-repart (FEC,
  hash type, etc)

- Add SUPPORT_END_URL= field to os-release with more *actionable* information
  what to do if support ended

- Add systemd-analyze security checks for RestrictFileSystems= and
  RestrictNetworkInterfaces=

- Add systemd-mount@.service which is instantiated for a block device and
  invokes systemd-mount and exits. This is then useful to use in
  ENV{SYSTEMD_WANTS} in udev rules, and a bit prettier than using RUN+=

- Add systemd-sysupdate-initrd.service or so that runs systemd-sysupdate in the
  initrd to bootstrap the initrd to populate the initial partitions. Some things
  to figure out:
  - Should it run on firstboot or on every boot?
  - If run on every boot, should it use the sysupdate config from the host on
    subsequent boots?

- add systemd.abort_on_kill or some other such flag to send SIGABRT instead of SIGKILL
  (throughout the codebase, not only PID1)

- Add UKI profile conditioning so that profiles are only available if secure
  boot is turned off, or only on. similar, add conditions on TPM availability,
  network boot, and other conditions.

- Allocate UIDs/GIDs automatically in userdbctl load-credentials if none are
  included in the user/group record credentials

- allow dynamic modifications of ConcurrencyHardMax= and ConcurrencySoftMax=
  via DBus (and with that also by daemon-reload). Similar for portabled.

- also include packaging metadata (á la
  https://systemd.io/PACKAGE_METADATA_FOR_EXECUTABLE_FILES/) in our UEFI PE
  binaries, using the same JSON format.

- also parse out primary GPT disk label uuid from gpt partition device path at
  boot and pass it as efi var to OS.

- as soon as we have sender timestamps, revisit coalescing multiple parallel daemon reloads:
  https://lists.freedesktop.org/archives/systemd-devel/2014-December/025862.html

- augment CODE_FILE=, CODE_LINE= with something like CODE_BASE= or so which
  contains some identifier for the project, which allows us to include
  clickable links to source files generating these log messages. The identifier
  could be some abbreviated URL prefix or so (taking inspiration from Go
  imports). For example, for systemd we could use
  CODE_BASE=github.com/systemd/systemd/blob/98b0b1123cc or so which is
  sufficient to build a link by prefixing "http://" and suffixing the
  CODE_FILE.

- Augment MESSAGE_ID with MESSAGE_BASE, in a similar fashion so that we can
  make clickable links from log messages carrying a MESSAGE_ID, that lead to
  some explanatory text online.

- automatic boot assessment: add one more default success check that just waits
  for a bit after boot, and blesses the boot if the system stayed up that long.

- automatically ignore threaded cgroups in cg_xyz().

- automatically mount one virtiofs during early boot phase to /run/host/,
  similar to how we do that for nspawn, based on some clear tag.

- automatically propagate LUKS password credential into cryptsetup from host
  (i.e. SMBIOS type #11, …), so that one can unlock LUKS via VM hypervisor
  supplied password.

- automatically reset specific EFI vars on factory reset (make this generic
  enough so that infra can be used to erase shim's mok vars?)

- be able to specify a forced restart of service A where service B depends on, in case B
  needs to be auto-respawned?

- be more careful what we export on the bus as (usec_t) 0 and (usec_t) -1

- beef up log.c with support for stripping ANSI sequences from strings, so that
  it is OK to include them in log strings. This would be particularly useful so
  that our log messages could contain clickable links for example for unit
  files and suchlike we operate on.

- beef up pam_systemd to take unit file settings such as cgroups properties as
  parameters

- blog about fd store and restartable services

- **bootctl:**
  - recognize the case when not booted on EFI
  - add tool for registering BootXXX entry that boots from some http
    server of your choice (i.e. like kernel-bootcfg --add-uri=)
  - add reboot-to-disk which takes a block device name, and
    automatically sets things up so that system reboots into that device next.
  - show whether UEFI audit mode is available
  - teach it to prepare an ESP wholesale, i.e. with mkfs.vfat invocation
  - teach it to copy in unified kernel images and maybe type #1 boot loader spec entries from host

- BootLoaderSpec: define a way how an installer can figure out whether a BLS
  compliant boot loader is installed.

- BootLoaderSpec: document @saved pseudo-entry, update mention in BLI

- bootspec: permit graceful "update" from type #2 to type #1. If both a type #1
  and a type #2 entry exist under otherwise the exact same name, then use the
  type #1 entry, and ignore the type #2 entry. This way, people can "upgrade"
  from the UKI with all parameters baked in to a Type #1 .conf file with manual
  parametrization, if needed. This matches our usual rule that admin config
  should win over vendor defaults.

- bpf: see if we can address opportunistic inode sharing of immutable fs images
  with BPF. i.e. if bpf gives us power to hook into openat() and return a
  different inode than is requested for which we however it has same contents
  then we can use that to implement opportunistic inode sharing among DDIs:
  make all DDIs ship xattr on all reg files with a SHA256 hash. Then, also
  dictate that DDIs should come with a top-level subdir where all reg files are
  linked into by their SHA256 sum. Then, whenever an inode is opened with the
  xattr set, check bpf table to find dirs with hashes for other prior DDIs and
  try to use inode from there.

- bpf: see if we can use BPF to solve the syslog message cgroup source problem:
  one idea would be to patch source sockaddr of all AF_UNIX/SOCK_DGRAM to
  implicitly contain the source cgroup id. Another idea would be to patch
  sendto()/connect()/sendmsg() sockaddr on-the-fly to use a different target
  sockaddr.

- bsod: add target "bsod.target" or so, which invokes systemd-bsod.target and
  waits and then reboots. Then use OnFailure=bsod.target from various jobs that
  should result in system reboots, such as TPM tamper detection cases.

- bsod: maybe use graphical mode. Use DRM APIs directly, see
  https://github.com/dvdhrm/docs/blob/master/drm-howto/modeset.c for an example
  for doing that.

- build short web pages out of each catalog entry, build them along with man
  pages, and include hyperlinks to them in the journal output

- busctl: maybe expose a verb "ping" for pinging a dbus service to see if it
  exists and responds.

- bypass SIGTERM state in unit files if KillSignal is SIGKILL

- cache sd_event_now() result from before the first iteration...

- calenderspec: add support for week numbers and day numbers within a
  year. This would allow us to define "bi-weekly" triggers safely.

- cgroups: use inotify to get notified when somebody else modifies cgroups
  owned by us, then log a friendly warning.

- **cgroups:**
  - implement per-slice CPUFairScheduling=1 switch
  - introduce high-level settings for RT budget, swappiness
  - how to reset dynamically changed unit cgroup attributes sanely?
  - when reloading configuration, apply new cgroup configuration
  - when recursively showing the cgroup hierarchy, optionally also show
    the hierarchies of child processes
  - add settings for cgroup.max.descendants and cgroup.max.depth,
    maybe use them for user@.service

- chase(): take inspiration from path_extract_filename() and return
  O_DIRECTORY if input path contains trailing slash.

- Check that users of inotify's IN_DELETE_SELF flag are using it properly, as
  usually IN_ATTRIB is the right way to watch deleted files, as the former only
  fires when a file is actually removed from disk, i.e. the link count drops to
  zero and is not open anymore, while the latter happens when a file is
  unlinked from any dir.

- Clean up "reboot argument" handling, i.e. set it through some IPC service
  instead of directly via /run/, so that it can be sensible set remotely.

- clean up date formatting and parsing so that all absolute/relative timestamps we format can also be parsed

- **complete varlink introspection comments:**
  - io.systemd.ManagedOOM
  - io.systemd.Network
  - io.systemd.PCRLock
  - io.systemd.Resolve.Monitor
  - io.systemd.Resolve
  - io.systemd.oom
  - io.systemd.sysext

- confext/sysext: instead of mounting the overlayfs directly on /etc/ + /usr/,
  insert an intermediary bind mount on itself there. This has the benefit that
  services where mount propagation from the root fs is off, an still have
  confext/sysext propagated in.

- consider adding a new partition type, just for /opt/ for usage in system
  extensions

- coredump: maybe when coredumping read a new xattr from /proc/$PID/exe that
  may be used to mark a whole binary as non-coredumpable. Would fix:
  https://bugs.freedesktop.org/show_bug.cgi?id=69447

- **coredump:**
  - save coredump in Windows/Mozilla minidump format
  - when truncating coredumps, also log the full size that the process had, and make a metadata field so we can report truncated coredumps
  - add examples for other distros in PACKAGE_METADATA_FOR_EXECUTABLE_FILES

- **credentials system:**
  - acquire from EFI variable?
  - acquire via ask-password?
  - acquire creds via keyring?
  - pass creds via keyring?
  - pass creds via memfd?
  - acquire + decrypt creds from pkcs11?
  - make macsec code in networkd read key via creds logic (copy logic from
    wireguard)
  - make gatewayd/remote read key via creds logic
  - add sd_notify() command for flushing out creds not needed anymore
  - if we ever acquire a secure way to derive cgroup id of socket
    peers (i.e. SO_PEERCGROUPID), then extend the "scoped" credential logic to
    allow cgroup-scoped (i.e. app or service scoped) credentials. Then, as next
    step use this to implement per-app/per-service encrypted directories, where
    we set up fscrypt on the StateDirectory= with a randomized key which is
    stored as xattr on the directory, encrypted as a credential.
  - optionally include a per-user secret in scoped user-credential
    encryption keys. should come from homed in some way, derived from the luks
    volume key or fscrypt directory key.
  - add a flag to the scoped credentials that if set require PK
    reauthentication when unlocking a secret.
  - rework docs. The list in
    https://systemd.io/CREDENTIALS/#well-known-credentials is very stale.
    Document credentials in individual man pages, generate list as in
    systemd.directives.

- creds: add a new cred format that reused the JSON structures we use in the
  LUKS header, so that we get the various newer policies for free.

- cryptenroll/cryptsetup/homed: add unlock mechanism that combines tpm2 and
  fido2, as well as tpm2 + ssh-agent, inspired by ChromeOS' logic: encrypt the
  volume key with the TPM, with a policy that insists that a nonce is signed by
  the fido2 device's key or ssh-agent key. Thus, add unlock/login time the TPM
  generates a nonce, which is sent as a challenge to the fido2/ssh-agent, which
  returns a signature which is handed to the tpm, which then reveals the volume
  key to the PC.

- cryptenroll/cryptsetup/homed: similar to this, implement TOTP backed by TPM.

- cryptsetup/homed: implement TOTP authentication backed by TPM2 and its
  internal clock.

- **cryptsetup:**
  - cryptsetup-generator: allow specification of passwords in crypttab itself
  - support rd.luks.allow-discards= kernel cmdline params in cryptsetup generator
  - add boolean for disabling use of any password/recovery key slots.
    (i.e. that we can operate in a tpm-only mode, and thus protect us from rogue
    root disks)
  - new crypttab option to auto-grow a luks device to its backing
    partition size. new crypttab option to reencrypt a luks device with a new
    volume key.
  - a mechanism that allows signing a volume key with some key that
    has to be present in the kernel keyring, or similar, to ensure that confext
    DDIs can be encrypted against the local SRK but signed with the admin's key
    and thus can authenticated locally before they are decrypted.
  - add option for automatically removing empty password slot on boot
  - optionally, when run during boot-up and password is never
    entered, and we are on battery power (or so), power off machine again
  - when waiting for FIDO2/PKCS#11 token, tell plymouth that, and
    allow plymouth to abort the waiting and enter pw instead
  - allow encoding key directly in /etc/crypttab, maybe with a
    "base64:" prefix. Useful in particular for pkcs11 mode.
  - reimplement the mkswap/mke2fs in cryptsetup-generator to use
    systemd-makefs.service instead.

- sysext: make systemd-{sys,conf}ext-sysroot.service work in the split `/var`
  configuration.

- sd-varlink: add fully async modes of the protocol upgrade stuff

- repart: maybe remove iso9660/eltorito superblock from disk when booting via
  gpt, if there is one.

- crypttab/gpt-auto-generator: allow explicit control over which unlock mechs
  to permit, and maybe have a global headless kernel cmdline option

- currently x-systemd.timeout is lost in the initrd, since crypttab is copied into dracut, but fstab is not

- dbus: when a unit failed to load (i.e. is in UNIT_ERROR state), we
  should be able to safely try another attempt when the bus call LoadUnit() is invoked.

- ddi must be listed as block device fstype

- define a JSON format for units, separating out unit definitions from unit
  runtime state. Then, expose it:

  1. Add Describe() method to Unit D-Bus object that returns a JSON object
     about the unit.
  2. Expose this natively via Varlink, in similar style
  3. Use it when invoking binaries (i.e. make PID 1 fork off systemd-executor
     binary which reads the JSON definition and runs it), to address the cow
     trap issue and the fact that NSS is actually forbidden in
     forked-but-not-exec'ed children
  4. Add varlink API to run transient units based on provided JSON definitions

- define gpt header bits to select volatility mode

- delay activation of logind until somebody logs in, or when /dev/tty0 pulls it
  in or lingering is on (so that containers don't bother with it until PAM is used). also exit-on-idle

- deprecate RootDirectoryStartOnly= in favour of a new ExecStart= prefix char

- **dhcp6:**
  - add functions to set previously stored IPv6 addresses on startup and get
    them at shutdown; store them in client->ia_na
  - write more test cases
  - implement reconfigure support, see 5.3., 15.11. and 22.20.
  - implement support for temporary addresses (IA_TA)
  - implement dhcpv6 authentication
  - investigate the usefulness of Confirm messages; i.e. are there any
    situations where the link changes without any loss in carrier detection
    or interface down
  - some servers don't do rapid commit without a filled in IA_NA, verify
    this behavior
  - RouteTable= ?

- **dhcp:**
  - figure out how much we can increase Maximum Message Size

- dissection policy should enforce that unlocking can only take place by
  certain means, i.e. only via pw, only via tpm2, or only via fido, or a
  combination thereof.

- do a console daemon that takes stdio fds for services and allows to reconnect
  to them later

- doc: prep a document explaining PID 1's internal logic, i.e. transactions,
  jobs, units

- doc: prep a document explaining resolved's internal objects, i.e. Query
  vs. Question vs. Transaction vs. Stream and so on.

- docs: bring https://systemd.io/MY_SERVICE_CANT_GET_REALTIME up to date

- document Environment=SYSTEMD_LOG_LEVEL=debug drop-in in debugging document

- document org.freedesktop.MemoryAllocation1

- **document:**
  - document that deps in [Unit] sections ignore Alias= fields in
    [Install] units of other units, unless those units are disabled
  - document that service reload may be implemented as service reexec
  - add a man page containing packaging guidelines and recommending usage of things like Documentation=, PrivateTmp=, PrivateNetwork= and ReadOnlyDirectories=/etc /usr.
  - document systemd-journal-flush.service properly
  - documentation: recommend to connect the timer units of a service to the service via Also= in [Install]
  - man: document the very specific env the shutdown drop-in tools live in
  - man: add more examples to man pages,
  -      in particular an example how to do the equivalent of switching runlevels
  - man: maybe sort directives in man pages, and take sections from --help and apply them to man too
  - document root=gpt-auto properly

- dot output for --test showing the 'initial transaction'

- drop nss-myhostname in favour of nss-resolve?

- **EFI:**
  - honor timezone efi variables for default timezone selection (if there are any?)

- enable LockMLOCK to take a percentage value relative to physical memory

- Enable RestrictFileSystems= for all our long-running services (similar:
  RestrictNetworkInterfaces=)

- encode type1 entries in some UKI section to add additional entries to the
  menu.

- enumerate virtiofs devices during boot-up in a generator, and synthesize
  mounts for rootfs, /usr/, /home/, /srv/ and some others from it, depending on
  the "tag". (waits for: https://gitlab.com/virtio-fs/virtiofsd/-/issues/128)

- /etc/veritytab: allow that the roothash column can be specified as fs path
  including a path to an AF_UNIX path, similar to how we do things with the
  keys of /etc/crypttab. That way people can store/provide the roothash
  externally and provide to us on demand only.

- exponential backoff in timesyncd when we cannot reach a server

- expose MS_NOSYMFOLLOW in various places

- expose the handoff timestamp fully via the D-Bus properties that contain
  ExecStatus information

- extend the smbios11 logic for passing credentials so that instead of passing
  the credential data literally it can also just reference an AF_VSOCK CID/port
  to read them from. This way the data doesn't remain in the SMBIOS blob during
  runtime, but only in the credentials fs.

- extend the verity signature partition to permit multiple signatures for the
  same root hash, so that people can sign a single image with multiple keys.

- figure out a nice way how we can let the admin know what child/sibling unit causes cgroup membership for a specific unit

- Figure out how to do unittests of networkd's state serialization

- Figure out naming of verbs in systemd-analyze: we have (singular) capability,
  exit-status, but (plural) filesystems, architectures.

- figure out what to do about credentials sealed to PCRs in kexec + soft-reboot
  scenarios. Maybe insist sealing is done additionally against some keypair in
  the TPM to which access is updated on each boot, for the next, or so?

- figure out when we can use the coarse timers

- Find a solution for SMACK capabilities stuff:
  https://lists.freedesktop.org/archives/systemd-devel/2014-December/026188.html

- fix bug around run0 background color on ls in fresh terminal

- Fix DECIMAL_STR_MAX or DECIMAL_STR_WIDTH. One includes a trailing NUL, the
  other doesn't. What a disaster. Probably to exclude it.

- fix homed/homectl confusion around terminology, i.e. "home directory"
  vs. "home" vs. "home area". Stick to one term for the concept, and it
  probably shouldn't contain "area".

- fix our various hwdb lookup keys to end with ":" again. The original idea was
  that hwdb patterns can match arbitrary fields with expressions like
  "*:foobar:*", to wildcard match both the start and the end of the string.
  This only works safely for later extensions of the string if the strings
  always end in a colon. This requires updating our udev rules, as well as
  checking if the various hwdb files are fine with that.

- flush_accept() should look at sockdiag queued sockets count and exit once we
  flushed out the specified number of connections.

- flush_fd() should probably try to be smart and stop reading once we know that
  all further queued data was enqueued after flush_fd() was originally
  called. For that, try SIOCINQ if fd refers to stream socket, and look at
  timestamps for datagram sockets.

- for better compat with major clouds: implement simple PTP device support in
  timesyncd

- for better compat with major clouds: introduce imds mini client service that
  sets up primary netif in a private netns (ipvlan?) to query imds without
  affecting rest of the host. pick up literal credentials from there plus the
  fields the hwdb reports for the other fields and turn them into credentials.
  then write generator that used detected virtualization info and plugs this
  service into the early boot, waiting for the DMI and network device to show
  up.

- for better compat with major clouds: recognize clouds via hwdb on DMI device,
  and add udev properties to it that help with handling IMDS, i.e. entrypoint
  URL, which fields to find ip hostname, ssh key, …

- For timer units: add some mechanisms so that timer units that trigger immediately on boot do not have the services
  they run added to the initial transaction and thus confuse Type=idle.

- **for vendor-built signed initrds:**
  - kernel-install should be able to install encrypted creds automatically for
    machine id, root pw, rootfs uuid, resume partition uuid, and place next to
    EFI kernel, for sd-stub to pick them up. These creds should be locked to
    the TPM, and bind to the right PCR the kernel is measured to.
  - kernel-install should be able to pick up initrd sysexts automatically and
    place them next to EFI kernel, for sd-stub to pick them up.
  - systemd-fstab-generator should look for rootfs device to mount in creds
  - systemd-resume-generator should look for resume partition uuid in creds

- **foreign uid:**
  - add support to export-fs, import-fs
  - systemd-dissect should learn mappings, too, when doing mtree and such

- fstab-generator: default to tmpfs-as-root if only usr= is specified on the kernel cmdline

- generator that automatically discovers btrfs subvolumes, identifies their purpose based on some xattr on them.

- generic interface for varlink for setting log level and stuff that all our daemons can implement

- get rid of compat with libbpf.so.0 (retainly only for libbpf.so.1)

- Get rid of the symlinks in /run/systemd/units/* and exclusively use cgroupfs
  xattrs to convey info about invocation ids, logging settings and so on.
  support for cgroupfs xattrs in the "trusted." namespace was added in linux
  3.7, i.e. which we don't pretend to support anymore.

- go through all --help texts in our codebases, and make sure:
  1. the one sentence description of the tool is highlighted via ANSI how we
     usually do it
  2. If more than one or two commands are supported (as opposed to switches),
     separate commands + switches from each other, using underlined --help sections.
  3. If there are many switches, consider adding additional --help sections.

- go through all uses of table_new() in our codebase, and make sure we support
  all three of:
  1. --no-legend properly
  2. --json= properly
  3. --no-pager properly

- go through our codebase, and convert "vertical tables" (i.e. things such as
  "systemctl status") to use table_new_vertical() for output

- **gpt-auto-generator:**
  - Make /home automount rather than mount?

- have a signal that reloads every unit that supports reloading

- hibernate/s2h: if swap is on weird storage and refuse if so

- homed/pam_systemd: allow authentication by ssh-agent, so that run0/polkit can
  be allowed if caller comes with the right ssh-agent keys.

- homed/userdb: maybe define a "companion" dir for home directories where apps
  can safely put privileged stuff in. Would not be writable by the user, but
  still conceptually belong to the user. Would be included in user's quota if
  possible, even if files are not owned by UID of user. Use case: container
  images that owned by arbitrary UIDs, and are owned/managed by the users, but
  are not directly belonging to the user's UID. Goal: we shouldn't place more
  privileged dirs inside of unprivileged dirs, and thus containers really
  should not be placed inside of traditional UNIX home dirs (which are owned by
  users themselves) but somewhere else, that is separate, but still close
  by. Inform user code about path to this companion dir via env var, so that
  container managers find it. the ~/.identity file is also a candidate for a
  file to move there, since it is managed by privileged code (i.e. homed) and
  not unprivileged code.

- **homed:**
  - when user tries to log into record signed by unrecognized key, automatically add key to our chain after polkit auth
  - rollback when resize fails mid-operation
  - GNOME's side for forget key on suspend (requires rework so that lock screen runs outside of uid)
  - update LUKS password on login if we find there's a password that unlocks the JSON record but not the LUKS device.
  - create on activate?
  - properties: icon url?, administrator bool (which translates to 'wheel' membership)?, address?, telephone?, vcard?, samba stuff?, parental controls?
  - communicate clearly when usb stick is safe to remove. probably involves
    beefing up logind to make pam session close hook synchronous and wait until
    systemd --user is shut down.
  - logind: maybe keep a "busy fd" as long as there's a non-released session around or the user@.service
  - maybe make automatic, read-only, time-based reflink-copies of LUKS disk
    images (and btrfs snapshots of subvolumes) (think: time machine)
  - distinguish destroy / remove (i.e. currently we can unregister a user, unregister+remove their home directory, but not just remove their home directory)
  - fingerprint authentication, pattern authentication, …
  - make sure "classic" user records can also be managed by homed
  - make size of $XDG_RUNTIME_DIR configurable in user record
  - move acct mgmt stuff from pam_systemd_home to pam_systemd?
  - when "homectl --pkcs11-token-uri=" is used, synthesize ssh-authorized-keys records for all keys we have private keys on the stick for
  - make slice for users configurable (requires logind rework)
  - logind: populate auto-login list bus property from PKCS#11 token
  - when determining state of a LUKS home directory, check DM suspended sysfs file
  - when homed is in use, maybe start the user session manager in a mount namespace with MS_SLAVE,
    so that mounts propagate down but not up - eg, user A setting up a backup volume
    doesn't mean user B sees it
  - use credentials logic/TPM2 logic to store homed signing key
  - permit multiple user record signing keys to be used locally, and pick
    the right one for signing records automatically depending on a pre-existing
    signature
  - add a way to "take possession" of a home directory, i.e. strip foreign signatures
    and insert a local signature instead.
  - as an extension to the directory+subvolume backend: if located on
    especially marked fs, then sync down password into LUKS header of that fs,
    and always verify passwords against it too. Bootstrapping is a problem
    though: if no one is logged in (or no other user even exists yet), how do you
    unlock the volume in order to create the first user and add the first pw.
  - support new FS_IOC_ADD_ENCRYPTION_KEY ioctl for setting up fscrypt
  - maybe pre-create ~/.cache as subvol so that it can have separate quota
    easily?
  - store PKCS#11 + FIDO2 token info in LUKS2 header, compatible with
    systemd-cryptsetup, so that it can unlock homed volumes
  - maybe make all *.home files owned by `systemd-home` user or so, so that we
    can easily set overall quota for all users
  - on login, if we can't fallocate initially, but rebalance is on, then allow
    login in discard mode, then immediately rebalance, then turn off discard
  - add "homectl unbind" command to remove local user record of an inactive
    home dir
  - use systemd-storagetm to expose home dirs via nvme-tcp. Then,
    teach homed/pam_systemd_homed with a user name such as
    lennart%nvme_tcp_192.168.100.77_8787 to log in from any linux host with the
    same home dir. Similar maybe for nbd, iscsi? this should then first ask for
    the local root pw, to authenticate that logging in like this is ok, and would
    then be followed by another password prompt asking for the user's own
    password. Also, do something similar for CIFS: if you log in via
    lennart%cifs-someserver_someshare, then set up the homed dir for it
    automatically. The PAM module should update the user name used for login to
    the short version once it set up the user. Some care should be taken, so that
    the long version can be still be resolved via NSS afterwards, to deal with
    PAM clients that do not support PAM sessions where PAM_USER changes half-way.
  - add a basic form of secrets management to homed, that stores
    secrets in $HOME somewhere, is protected by the accounts own authentication
    mechanisms. Should implement something PKCS#11-like that can be used to
    implement emulated FIDO2 in unpriv userspace on top (which should happen
    outside of homed), emulated PKCS11, and libsecrets support. Operate with a
    2nd key derived from volume key of the user, with which to wrap all
    keys. maintain keys in kernel keyring if possible.
  - when resizing an fs don't sync identity beforehand there might simply
    not be enough disk space for that. try to be defensive and sync only after
    resize.
  - if for some reason the partition ended up being much smaller than
    whole disk, recover from that, and grow it again.
  - if the homed shell fallback thing has access to an SSH agent, try to
    use it to unlock home dir (if ssh-agent forwarding is enabled). We
    could implement SSH unlocking of a homedir with that: when enrolling a new
    ssh pubkey in a user record we'd ask the ssh-agent to sign some random value
    with the privkey, then use that as luks key to unlock the home dir. Will not
    work for ECDSA keys since their signatures contain a random component, but
    will work for RSA and Ed25519 keys.

- honour validatefs xattrs in dissect-image.c too

- hook up journald with TPMs? measure new journal records to the TPM in regular
  intervals, validate the journal against current TPM state with that. (taking
  inspiration from IMA log)

- Hook up journald's FSS logic with TPM2: seal the verification disk by
  time-based policy, so that the verification key can remain on host and ve
  validated via TPM.

- Hook up systemd-journal-upload with RESTART_RESET=1 logic (should probably
  be conditioned on the num of successfully uploaded entries?)

- hostnamectl: show root image uuid

- if /usr/bin/swapoff fails due to OOM, log a friendly explanatory message about it

- if we fork of a service with StandardOutput=journal, and it forks off a
  subprocess that quickly dies, we might not be able to identify the cgroup it
  comes from, but we can still derive that from the stdin socket its output
  came from. We apparently don't do that right now.

- If we try to find a unit via a dangling symlink, generate a clean
  error. Currently, we just ignore it and read the unit from the search
  path anyway.

- image policy should be extended to allow dictating *how* a disk is unlocked,
  i.e. root=encrypted-tpm2+encrypted-fido2 would mean "root fs must be
  encrypted and unlocked via fido2 or tpm2, but not otherwise"

- imds: maybe do smarter api version handling

- implement a varlink registry service, similar to the one of the reference
  implementation, backed by /run/varlink/registry/. Then, also implement
  connect-via-registry-resolution in sd-varlink and varlinkctl. Care needs to
  be taken to do the resolution asynchronousy. Also, note that the Varlink
  reference implementation uses a different address syntax, which needs to be
  taken into account.

- implement Distribute= in socket units to allow running multiple
  service instances processing the listening socket, and open this up
  for ReusePort=

- **importd/importctl:**
  - complete varlink interface
  - download images into .v/ dirs

- importd: support image signature verification with PKCS#7 + OpenBSD signify
  logic, as alternative to crummy gpg

- In .socket units, add ConnectStream=, ConnectDatagram=,
  ConnectSequentialPacket= that create a socket, and then *connect to* rather than
  listen on some socket. Then, add a new setting WriteData= that takes some
  base64 data that systemd will write into the socket early on. This can then
  be used to create connections to arbitrary services and issue requests into
  them, as long as the data is static. This can then be combined with the
  aforementioned journald subscription varlink service, to enable
  activation-by-message id and similar.

- In DynamicUser= mode: before selecting a UID, use disk quota APIs on relevant
  disks to see if the UID is already in use.

- in journald, write out a recognizable log record whenever the system clock is
  changed ("stepped"), and in timesyncd whenever we acquire an NTP fix
  ("slewing"). Then, in journalctl for each boot time we come across, find
  these records, and use the structured info they include to display
  "corrected" wallclock time, as calculated from the monotonic timestamp in the
  log record, adjusted by the delta declared in the structured log record.

- in journald: whenever we start a new journal file because the boot ID
  changed, let's generate a recognizable log record containing info about old
  and new ID. Then, when displaying log stream in journalctl look for these
  records, to be able to order them.

- in networkd, when matching device types, fix up DEVTYPE rubbish the kernel passes to us

- in nss-systemd, if we run inside of RootDirectory= with PrivateUsers= set,
  find a way to map the User=/Group= of the service to the right name. This way
  a user/group for a service only has to exist on the host for the right
  mapping to work.

- in os-release define a field that can be initialized at build time from
  SOURCE_DATE_EPOCH (maybe even under that name?). Would then be used to
  initialize the timestamp logic of ConditionNeedsUpdate=.

- in pid1: include ExecStart= cmdlines (and other Exec*= cmdlines) in polkit
  request, so that policies can match against command lines.

- in sd-stub: optionally add support for a new PE section .keyring or so that
  contains additional certificates to include in the Mok keyring, extending
  what shim might have placed there. why? let's say I use "ukify" to build +
  sign my own fedora-based UKIs, and only enroll my personal lennart key via
  shim.  Then, I want to include the fedora keyring in it, so that kmods work.
  But I might not want to enroll the fedora key in shim, because this would
  also mean that the key would be in effect whenever I boot an archlinux UKI
  built the same way, signed with the same lennart key.

- in the initrd, once the rootfs encryption key has been measured to PCR 15,
  derive default machine ID to use from it, and pass it to host PID 1.

- in the initrd: derive the default machine ID to pass to the host PID 1 via
  $machine_id from the same seed credential.

- in the long run: permit a system with /etc/machine-id linked to /dev/null, to
  make it lose its identity, i.e. be anonymous. For this we'd have to patch
  through the whole tree to make all code deal with the case where no machine
  ID is available.

- In vmspawn/nspawn/machined wait for X_SYSTEMD_UNIT_ACTIVE=ssh-active.target
  and X_SYSTEMD_SIGNALS_LEVEL=2 as indication whether/when SSH and the POSIX
  signals are available. Similar for D-Bus (but just use sockets.target for
  that). Report as property for the machine.

- initialize the hostname from the fs label of /, if /etc/hostname does not exist?

- initrd: when transitioning from initrd to host, validate that
  /lib/modules/`uname -r` exists, refuse otherwise

- instead of going directly for DefineSpace when initializing nvpcrs, check if
  they exist first. apparently DefineSpace is broken on some tpms, and also
  creates log spam if the nvindex already exists.

- introduce /etc/boottab or so which lists block devices that bootctl +
  kernel-install shall update the ESPs on (and register in EFI BootXYZ
  variables), in addition to whatever is currently the booted /usr/.
  systemd-sysupdate should also take it into consideration and update the
  /usr/ images on all listed devices.

- introduce a .acpitable section for early ACPI table override

- Introduce a CGroupRef structure, inspired by PidRef. Should contain cgroup
  path, cgroup id, and cgroup fd. Use it to continuously pin all v2 cgroups via
  a cgroup_ref field in the CGroupRuntime structure. Eventually switch things
  over to do all cgroupfs access only via that structure's fd.

- introduce a new group to own TPM devices

- introduce an option (or replacement) for "systemctl show" that outputs all
  properties as JSON, similar to busctl's new JSON output. In contrast to that
  it should skip the variant type string though.

- introduce DefaultSlice= or so in system.conf that allows changing where we
  place our units by default, i.e. change system.slice to something
  else. Similar, ManagerSlice= should exist so that PID1's own scope unit could
  be moved somewhere else too. Finally machined and logind should get similar
  options so that it is possible to move user session scopes and machines to a
  different slice too by default. Use case: people who want to put resources on
  the entire system, with the exception of one specific service. See:
  https://lists.freedesktop.org/archives/systemd-devel/2018-February/040369.html

- introduce mntid_t, and make it 64bit, as apparently the kernel switched to
  64bit mount ids

- introduce new ANSI sequence for communicating log level and structured error
  metadata to terminals.

- introduce new structure Tpm2CombinedPolicy, that combines the various TPm2
  policy bits into one structure, i.e. public key info, pcr masks, pcrlock
  stuff, pin and so on. Then pass that around in tpm2_seal() and tpm2_unseal().

- introduce per-unit (i.e. per-slice, per-service) journal log size limits.

- investigate whether the gnome pty helper should be moved into systemd, to provide cgroup support.

- **journal:**
  - consider introducing implicit _TTY= + _PPID= + _EUID= + _EGID= + _FSUID= + _FSGID= fields
  - journald: also get thread ID from client, plus thread name
  - journal: when waiting for journal additions in the client always sleep at least 1s or so, in order to minimize wakeups
  - add API to close/reopen/get fd for journal client fd in libsystemd-journal.
  - fall back to /dev/log based logging in libsystemd-journal, if we cannot log natively?
  - declare the local journal protocol stable in the wiki interface chart
  - sd-journal: speed up sd_journal_get_data() with transparent hash table in bg
  - journald: when dropping msgs due to ratelimit make sure to write
    "dropped %u messages" not only when we are about to print the next
    message that works, but already after a short timeout
  - check if we can make journalctl by default use --follow mode inside of less if called without args?
  - maybe add API to send pairs of iovecs via sd_journal_send
  - journal: add a setgid "systemd-journal" utility to invoke from libsystemd-journal, which passes fds via STDOUT and does PK access
  - journalctl: support negative filtering, i.e. FOOBAR!="waldo",
    and !FOOBAR for events without FOOBAR.
  - journal: store timestamp of journal_file_set_offline() in the header,
    so it is possible to display when the file was last synced.
  - journal-send.c, log.c: when the log socket is clogged, and we drop, count this and write a message about this when it gets unclogged again.
  - journal: find a way to allow dropping history early, based on priority, other rules
  - journal: When used on NFS, check payload hashes
  - journald: add kernel cmdline option to disable ratelimiting for debug purposes
  - refuse taking lower-case variable names in sd_journal_send() and friends.
  - journald: we currently rotate only after MaxUse+MaxFilesize has been reached.
  - journal: deal nicely with byte-by-byte copied files, especially regards header
  - journal: sanely deal with entries which are larger than the individual file size, but where the components would fit
  - Replace utmp, wtmp, btmp, and lastlog completely with journal
  - journalctl: instead --after-cursor= maybe have a --cursor=XYZ+1 syntax?
  - when a kernel driver logs in a tight loop, we should ratelimit that too.
  - journald: optionally, log debug messages to /run but everything else to /var
  - journald: when we drop syslog messages because the syslog socket is
    full, make sure to write how many messages are lost as first thing
    to syslog when it works again.
  - journald: allow per-priority and per-service retention times when rotating/vacuuming
  - journald: make use of uid-range.h to manage uid ranges to split
    journals in.
  - journalctl: add the ability to look for the most recent process of a binary.
                journalctl /usr/bin/X11 --invocation=-1
  - systemctl: change 'status' to show logs for the last invocation, not a fixed
    number of lines
  - improve journalctl performance by loading journal files
    lazily. Encode just enough information in the file name, so that we
    do not have to open it to know that it is not interesting for us, for
    the most common operations.
  - man: document that corrupted journal files is nothing to act on
  - rework journald sigbus stuff to use mutex
  - Set RLIMIT_NPROC for systemd-journal-xyz, and all other of our
    services that run under their own user ids, and use User= (but only
    in a world where userns is ubiquitous since otherwise we cannot
    invoke those daemons on the host AND in a container anymore). Also,
    if LimitNPROC= is used without User= we should warn and refuse
    operation.
  - journalctl --verify: don't show files that are currently being
    written to as FAIL, but instead show that they are being written to.
  - add journalctl -H that talks via ssh to a remote peer and passes through
    binary logs data
  - add a version of --merge which also merges /var/log/journal/remote
  - journalctl: -m should access container journals directly by enumerating
    them via machined, and also watch containers coming and going.
    Benefit: nspawn --ephemeral would start working nicely with the journal.
  - assign MESSAGE_ID to log messages about failed services
  - check if loop in decompress_blob_xz() is necessary
  - log pidfid as another field, i.e. _PIDFDID=
  - beef up ClientContext logic to store pidfd_id of peer, to validate
    we really use the right cache entry
  - log client's pidfd id as a new automatic field _PIDFDID= or so.
  - split up ClientContext cache in two: one cache keyed by pid/pidfdid
    with process information, and another one keyed by cgroup path/cgroupid with
    cgroup information. This way if a service consisting of many logging
    processes can take benefit of the cgroup caching.
  - support RFC3164 fully for the incoming syslog transport, see
    https://github.com/systemd/systemd/issues/19251#issuecomment-816601955
  - add varlink service that allows subscribing to certain log events,
    for example matching by message ID, or log level returns a list of journal
    cursors as they happen.
  - also collect CLOCK_BOOTTIME timestamps per log entry. Then, derive
    "corrected" CLOCK_REALTIME information on display from that and the timestamp
    info of the newest entry of the specific boot (as identified by the boot
    ID). This way, if a system comes up without a valid clock but acquires a
    better clock later, we can "fix" older entry timestamps on display, by
    calculating backwards. We cannot use CLOCK_MONOTONIC for this, since it does
    not account for suspend phases. This would then also enable us to correct the
    kmsg timestamping we consume (where we erroneously assume the clock was in
    CLOCK_MONOTONIC, but it actually is CLOCK_BOOTTIME as per kernel).
  - generate recognizable log events whenever we shutdown journald
    cleanly, and when we migrate run → var. This way tools can verify that a
    previous boot terminated cleanly, because either of these two messages must
    be safely written to disk, then.
  - do journal file writing out-of-process, with one writer process per
    client UID, so that synthetic hash table collisions can slow down a specific
    user's journal stream down but not the others.
  - make sure -f ends when the container indicated by -M terminates
  - sigbus API via a signal-handler safe function that people may call
    from the SIGBUS handler

- journalctl/timesyncd: whenever timesyncd acquires a synchronization from NTP,
  create a structured log entry that contains boot ID, monotonic clock and
  realtime clock (I mean, this requires no special work, as these three fields
  are implicit). Then in journalctl when attempting to display the realtime
  timestamp of a log entry, first search for the closest later log entry
  of this kinda that has a matching boot id, and convert the monotonic clock
  timestamp of the entry to the realtime clock using this info. This way we can
  retroactively correct the wallclock timestamps, in particular for systems
  without RTC, i.e. where initially wallclock timestamps carry rubbish, until
  an NTP sync is acquired.

- landlock: for unprivileged systemd (i.e. systemd --user), use landlock to
  implement ProtectSystem=, ProtectHome= and so on. Landlock does not require
  privs, and we can implement pretty similar behaviour. Also, maybe add a mode
  where ProtectSystem= combined with an explicit PrivateMounts=no could request
  similar behaviour for system services, too.

- landlock: lock down RuntimeDirectory= via landlock, so that services lose
  ability to write anywhere else below /run/. Similar for
  StateDirectory=. Benefit would be clear delegation via unit files: services
  get the directories they get, and nothing else even if they wanted to.

- Lennart: big blog story about "why systemd-boot"

- Lennart: big blog story about building initrds

- Lennart: big blog story about DDIs

- let's not GC a unit while its ratelimits are still pending

- libsystemd-journal, libsystemd-login, libudev: add calls to easily attach these objects to sd-event event loops

- lock down acceptable encrypted credentials at boot, via simple allowlist,
  maybe on kernel command line:
  systemd.import_encrypted_creds=foobar.waldo,tmpfiles.extra to protect locked
  down kernels from credentials generated on the host with a weak kernel

- lock down swtpm a bit to make it harder to extract keys from it as it is
  running. i.e. make ptracing + termination hard from the outside. also run
  swtpm as unpriv user (not trivial, probably requires patch swtpm, as it needs
  to allocate vtpm device), to lock it down from the inside.

- loginctl: show "service identifier" in tabular list-sessions output, to make
  run0 sessions easily visible.

- loginctl: show argv[] of "leader" process in tabular list-sessions output

- **logind:**
  - logind: optionally, ignore idle-hint logic for autosuspend, block suspend as long as a session is around
  - logind: wakelock/opportunistic suspend support
  - Add pretty name for seats in logind
  - logind: allow showing logout dialog from system?
  - add Suspend() bus calls which take timestamps to fix double suspend issues when somebody hits suspend and closes laptop quickly.
  - if pam_systemd is invoked by su from a process that is outside of a
    any session we should probably just become a NOP, since that's
    usually not a real user session but just some system code that just
    needs setuid().
  - logind: make the Suspend()/Hibernate() bus calls wait for the for
    the job to be completed. before returning, so that clients can wait
    for "systemctl suspend" to finish to know when the suspending is
    complete.
  - logind: when the power button is pressed short, just popup a
    logout dialog. If it is pressed for 1s, do the usual
    shutdown. Inspiration are Macs here.
  - expose "Locked" property on logind session objects
  - maybe allow configuration of the StopTimeout for session scopes
  - rename session scope so that it includes the UID. THat way
    the session scope can be arranged freely in slices and we don't have
    make assumptions about their slice anymore.
  - follow PropertiesChanged state more closely, to deal with quick logouts and
    relogins
  - (optionally?) spawn seat-manager@$SEAT.service whenever a seat shows up that as CanGraphical set
  - invoke a service manager for "area" logins too. i.e. instantiate
    user@.service also for logins where XDG_AREA is set, in per-area fashion, and
    ref count it properly. Benefit: graphical logins should start working with
    the area logic.
  - when logging in, always take an fd to the home dir, to keep the dir
    busy, so that autofs release can never happen. (this is generally a good
    idea, and specifically works around the fact the autofs ignores busy by mount
    namespaces)

- look at nsresourced, mountfsd, homed, importd, portabled, and try to come up
  with a way how the forked off worker processes can be moved into transient
  services with sandboxing, without breaking notify socket stuff and so on.

- **machined:**
  - add an API so that libvirt-lxc can inform us about network interfaces being
    removed or added to an existing machine
  - "machinectl migrate" or similar to copy a container from or to a
    difference host, via ssh
  - introduce systemd-nspawn-ephemeral@.service, and hook it into
    "machinectl start" with a new --ephemeral switch
  - "machinectl status" should also show internal logs of the container in
    question
  - "machinectl history"
  - "machinectl diff"
  - "machinectl commit" that takes a writable snapshot of a tree, invokes a
    shell in it, and marks it read-only after use
  - gc for OCI layers that are not referenced anymore by any .mstack/ links.
  - optionally track nspawn unix-export/ runtime for each machined, and
    then update systemd-ssh-proxy so that it can connect to that.

- make "bootctl install" + "bootctl update" useful for installing shim too. For
  that introduce new dir /usr/lib/systemd/efi/extra/ which we copy mostly 1:1
  into the ESP at install time. Then make the logic smart enough so that we
  don't overwrite bootx64.efi with our own if the extra tree already contains
  one. Also, follow symlinks when copying, so that shim rpm can symlink their
  stuff into our dir (which is safe since the target ESP is generally VFAT and
  thus does not have symlinks anyway). Later, teach the update logic to look at
  the ELF package metadata (which we also should include in all PE files, see
  above) for version info in all *.EFI files, and use it to only update if
  newer.

- make cryptsetup lower --iter-time

- Make it possible to set the keymap independently from the font on
  the kernel cmdline. Right now setting one resets also the other.

- make killing more debuggable: when we kill a service do so setting the
  .si_code field with a little bit of info. Specifically, we can set a
  recognizable value to first of all indicate that it's systemd that did the
  killing. Secondly, we can give a reason for the killing, i.e. OOM or so, and
  also the phase we are in, and which process we think we are killing (i.e.
  main vs control process, useful in case of sd_notify() MAINPID= debugging).
  Net result: people who try to debug why their process gets killed should have
  some minimal, nice metadata directly on the signal event.

- make MAINPID= message reception checks even stricter: if service uses User=,
  then check sending UID and ignore message if it doesn't match the user or
  root.

- make nspawn containers, portable services and vmspawn VMs optionally survive
  soft reboot wholesale.

- Make nspawn to a frontend for systemd-executor, so that we have to ways into
  the executor: via unit files/dbus/varlink through PID1 and via cmdline/OCI
  through nspawn.

- make persistent restarts easier by adding a new setting OpenPersistentFile=
  or so, which allows opening one or more files that is "persistent" across
  service restarts, hot reboot, cold reboots (depending on configuration): the
  files are created empty on first invocation, and on subsequent invocations
  the files are reboot. The files would be backed by tmpfs, pmem or /var
  depending on desired level of persistency.

- make repeated alt-ctrl-del presses printing a dump

- make rfkill uaccess controllable by default, i.e. steal rule from
  gnome-bluetooth and friends

- Make run0 forward various signals to the forked process so that sending
  signals to a child process works roughly the same regardless of whether the
  child process is spawned via run0 or not.

- make sure systemd-ask-password-wall does not shutdown systemd-ask-password-console too early

- make sure the ratelimit object can deal with USEC_INFINITY as way to turn off things

- make systemd work nicely without /bin/sh, logins and associated shell tools around
  - make sure debug shell service (sushell) has a nice failure mode, prints a message and reboots
  - varlink interface for "systemctl start" and friends
  - https://github.com/util-linux/util-linux/issues/4117

- make the systemd-repart "seed" value provisionable via credentials, so that
  confidential computing environments can set it and deterministically
  enforce the uuids for partitions created, so that they can calculate PCR 15
  ahead of time.

- make use of ethtool veth peer info in machined, for automatically finding out
  host-side interface pointing to the container.

- make use of new glibc 2.32 APIs sigabbrev_np().

- make vmspawn/nspawn/importd/machined a bit more usable in a WSL-like
  fashion. i.e. teach unpriv systemd-vmspawn/systemd-nspawn a reasonable
  --bind-user= behaviour that mounts the calling user through into the
  machine. Then, ship importd with a small database of well known distro images
  along with their pinned signature keys. Then add some minimal glue that binds
  this together: downloads a suitable image if not done so yet, starts it in
  the bg via vmspawn/nspawn if not done so yet and then requests a shell inside
  it for the invoking user.

- man: rework os-release(5), and clearly separate our extension-release.d/ and
  initrd-release parts, i.e. list explicitly which fields are about what.

- man: the documentation of Restart= currently is very misleading and suggests the tools from ExecStartPre= might get restarted.

- maybe add a new standard slice where process that are started in the initrd
  and stick around for the whole system runtime (i.e. root fs storage daemons,
  the bpf loader daemon discussed above, and such) are placed. maybe
  protected.slice or so? Then write docs that suggest that services like this
  set Slice=protected.slice, RefuseManualStart=yes, RefuseManualStop=yes and a
  couple of other things.

- maybe add call sd_journal_set_block_timeout() or so to set SO_SNDTIMEO for
  the sd-journal logging socket, and, if the timeout is set to 0, sets
  O_NONBLOCK on it. That way people can control if and when to block for
  logging.

- maybe add kernel cmdline params: to force random seed crediting

- maybe add new flags to gpt partition tables for rootfs and usrfs indicating
  purpose, i.e. whether something is supposed to be bootable in a VM, on
  baremetal, on an nspawn-style container, if it is a portable service image,
  or a sysext for initrd, for host os, or for portable container. Then hook
  portabled/… up to udev to watch block devices coming up with the flags set, and
  use it.

- maybe add support for binding and connecting AF_UNIX sockets in the file
  system outside of the 108ch limit. When connecting, open O_PATH fd to socket
  inode first, then connect to /proc/self/fd/XYZ. When binding, create symlink
  to target dir in /tmp, and bind through it.

- Maybe add SwitchRootEx() as new bus call that takes env vars to set for new
  PID 1 as argument. When adding SwitchRootEx() we should maybe also add a
  flags param that allows disabling and enabling whether serialization is
  requested during switch root.

- maybe allow timer units with an empty Units= setting, so that they
  can be used for resuming the system but nothing else.

- maybe beef up sd-event: optionally, allow sd-event to query the timestamp of
  next pending datagram inside a SOCK_DGRAM IO fd, and order event source
  dispatching by that. Enable this on the native + syslog sockets in journald,
  so that we add correct ordering between the two. Use MSG_PEEK + SCM_TIMESTAMP
  for this.

- maybe define a /etc/machine-info field for the ANSI color to associate with a
  hostname. Then use it for the shell prompt to highlight the hostname. If no
  color is explicitly set, hash a color automatically from the hostname as a
  fallback, in a reasonable way. Take inspiration from the ANSI_COLOR= field
  that already exists in /etc/os-release, i.e. use the same field name and
  syntax. When hashing the color, use the hsv_to_rgb() helper we already have,
  fixate S and V to something reasonable and constant, and derive the H from
  the hostname. Ultimate goal with this: give people a visual hint about the
  system they are on if the have many to deal with, by giving each a color
  identity. This code should be placed in hostnamed, so that clients can query
  the color via varlink or dbus.

- maybe do not install getty@tty1.service symlink in /etc but in /usr?

- maybe extend .path units to expose fanotify() per-mount change events

- maybe extend the capsule concept to the per-user instance too: invokes a
  systemd --user instance with a subdir of $HOME as $HOME, and a subdir of
  $XDG_RUNTIME_DIR as $XDG_RUNTIME_DIR.

- Maybe extend the service protocol to support handling of some specific SIGRT
  signal for setting service log level, that carries the level via the
  sigqueue() data parameter. Enable this via unit file setting.

- maybe implicitly attach monotonic+realtime timestamps to outgoing messages in
  log.c and sd-journal-send

- maybe introduce "@icky" as a seccomp filter group, which contains acct() and
  certain other syscalls that aren't quite obsolete, but certainly icky.

- Maybe introduce a helper safe_exec() or so, which is to execve() which
  safe_fork() is to fork(). And then make revert the RLIMIT_NOFILE soft limit
  to 1K implicitly, unless explicitly opted-out.

- maybe introduce a new partition that we can store debug logs and similar at
  the very last moment of shutdown. idea would be to store reference to block
  device (major + minor + partition id + diskseq?) in /run somewhere, than use
  that from systemd-shutdown, just write a raw JSON blob into the partition.
  Include timestamp, boot id and such, plus kmsg. on next boot immediately
  import into journal. maybe use timestamp for making clock more monotonic.
  also use this to detect unclean shutdowns, boot into special target if
  detected

- maybe introduce a new per-unit drop-in directory .confext.d/ that may contain
  symlinks to confext images to enable for the unit.

- Maybe introduce an InodeRef structure inspired by PidRef, which references a
  specific inode, and combines: a path, an O_PATH fd, and possibly a FID into
  one. Why? We often pass around path and fd separately in chaseat() and similar
  calls. Because passing around both separately is cumbersome we sometimes only
  one pass one, once the other and sometimes both. It would make the code a lot
  simpler if we could path both around at the same time in a simple way, via an
  InodeRef which *both* pins the inode via an fd, *and* gives us a friendly
  name for it.

- maybe introduce an OSC sequence that signals when we ask for a password, so
  that terminal emulators can maybe connect a password manager or so, and
  highlight things specially.

- maybe introduce container-shell@.service or so, to match
  container-getty.service but skips authentication, so you get a shell prompt
  directly. Usecase: wsl-like stuff (they have something pretty much like
  that). Question: how to pick user for this. Instance parameter? somehow from
  credential (would probably require some binary that converts credential to
  User= parameter?

- maybe introduce xattrs that can be set on the root dir of the root fs
  partition that declare the volatility mode to use the image in. Previously I
  thought marking this via GPT partition flags but that's not ideal since
  that's outside of the LUKS encryption/verity verification, and we probably
  shouldn't operate in a volatile mode unless we got told so from a trusted
  source.

- maybe prohibit setuid() to the nobody user, to lock things down, via seccomp.
  the nobody is not a user any code should run under, ever, as that user would
  possibly get a lot of access to resources it really shouldn't be getting
  access to due to the userns + nfs semantics of the user. Alternatively: use
  the seccomp log action, and allow it.

- maybe reconsider whether virtualization consoles (hvc1) are considered local
  or remote. i.e. are they more like an ssh login, or more like a /dev/tty1
  login? Lennart used to believe the former, but maybe the latter is more
  appropriate? This has effect on polkit interactivity, since it would mean
  questions via hvc0 would suddenly use the local polkit property. But this
  also raises the question whether such sessions shall be considered active or
  not

- Maybe rename pkcs7 and public verbs of systemd-keyutil to be more verb like.

- maybe rework systemd-modules-load to be a generator that just instantiates
  modprobe@.service a bunch of times

- maybe teach repart.d/ dropins a new setting MakeMountNodes= or so, which is
  just like MakeDirectories=, but uses an access mode of 0000 and sets the +i
  chattr bit. This is useful as protection against early uses of /var/ or /tmp/
  before their contents is mounted.

- maybe trigger a uevent "change" on a device if "systemctl reload xyz.device"
  is issued.

- maybe: in PID1, when we detect we run in an initrd, make superblock read-only
  early on, but provide opt-out via kernel cmdline.

- measure GPT and LUKS headers somewhere when we use them (i.e. in
  systemd-gpt-auto-generator/systemd-repart and in systemd-cryptsetup?)

- measure some string via pcrphase whenever we end up booting into emergency
  mode.

- measure some string via pcrphase whenever we resume from hibernate

- Merge systemd-creds options --uid= (which accepts user names) and --user.

- merge unit_kill_common() and unit_kill_context()

- mount /tmp/ and /var/tmp with a uidmap applied that blocks out "nobody" user
  among other things such as dynamic uid ranges for containers and so on. That
  way no one can create files there with these uids and we enforce they are only
  used transiently, never persistently.

- mount /var/ from initrd, so that we can apply sysext and stuff before the
  initrd transition. Specifically:
  1. There should be a var= kernel cmdline option, matching root= and usr=
  2. systemd-gpt-auto-generator should auto-mount /var if it finds it on disk
  3. mount.x-initrd mount option in fstab should be implied for /var

- mount most file systems with a restrictive uidmap. e.g. mount /usr/ with a
  uidmap that blocks out anything outside 0…1000 (i.e. system users) and similar.

- mount the root fs with MS_NOSUID by default, and then mount /usr/ without
  both so that suid executables can only be placed there. Do this already in
  the initrd. If /usr/ is not split out create a bind mount automatically.

- mount: turn dependency information from /proc/self/mountinfo into dependency information between systemd units.

- MountFlags=shared acts as MountFlags=slave right now.

- **mountfsd/nsresourced:**
  - userdb: maybe allow callers to map one uid to their own uid
  - bpflsm: allow writes if resulting UID on disk would be userns' owner UID
  - make encrypted DDIs work (password…)
  - add API for creating a new file system from scratch (together with some
    dm-integrity/HMAC key). Should probably work using systemd-repart (access
    via varlink).
  - add api to make an existing file "trusted" via dm-integry/HMAC key
  - port: portabled
  - port: tmpfiles, sysusers and similar
  - lets see if we can make runtime bind mounts into unpriv nspawn work

- move documentation about our common env vars (SYSTEMD_LOG_LEVEL,
  SYSTEMD_PAGER, …) into a man page of its own, and just link it from our
  various man pages that so far embed the whole list again and again, in an
  attempt to reduce clutter and noise a bid.

- move multiseat vid/pid matches from logind udev rule to hwdb

- Move RestrictAddressFamily= to the new cgroup create socket

- networkd's resolved hook: optionally map all lease IP addresses handed out to
  the same hostname which is configured on the .network file. Optionally, even
  derive this single name from the network interface name (i.e. probably
  altname or so). This way, when spawning a VM the host could pick the hostname
  for it and the client gets no say.

- networkd/machined: implement reverse name lookups in the resolved hook

- networkd: maintain a file in /run/ that can be symlinked into /run/issue.d/
  that always shows the current primary IP address

- **networkd:**
  - add more keys to [Route] and [Address] sections
  - add support for more DHCPv4 options (and, longer term, other kinds of dynamic config)
  - add reduced [Link] support to .network files
  - properly handle routerless dhcp leases
  - work with non-Ethernet devices
  - dhcp: do we allow configuring dhcp routes on interfaces that are not the one we got the dhcp info from?
  - the DHCP lease data (such as NTP/DNS) is still made available when
    a carrier is lost on a link. It should be removed instantly.
  - expose in the API the following bits:
        - option 15, domain name
        - option 12, hostname and/or option 81, fqdn
        - option 123, 144, geolocation
        - option 252, configure http proxy (PAC/wpad)
  - provide a way to define a per-network interface default metric value
    for all routes to it. possibly a second default for DHCP routes.
  - allow Name= to be specified repeatedly in the [Match] section. Maybe also
    support Name=foo*|bar*|baz ?
  - whenever uplink info changes, make DHCP server send out FORCERENEW

- nspawn/vmspawn/pid1: add ability to easily insert fully booted VMs/FOSC into
  shell pipelines, i.e. add easy to use switch that turns off console status
  output, and generates the right credentials for systemd-run-generator so that
  a program is invoked, and its output captured, with correct EOF handling and
  exit code propagation

- nspawn/vmspawn: define hotkey that one can hit on the primary interface to
  ask for a friendly, acpi style shutdown.

- **nspawn:**
  - emulate /dev/kmsg using CUSE and turn off the syslog syscall
    with seccomp. That should provide us with a useful log buffer that
    systemd can log to during early boot, and disconnect container logs
    from the kernel's logs.
  - as soon as networkd has a bus interface, hook up --network-interface=,
    --network-bridge= with networkd, to trigger netdev creation should an
    interface be missing
  - a nice way to boot up without machine id set, so that it is set at boot
    automatically for supporting --ephemeral. Maybe hash the host machine id
    together with the machine name to generate the machine id for the container
  - fix logic always print a final newline on output.
    https://github.com/systemd/systemd/pull/272#issuecomment-113153176
  - should optionally support receiving WATCHDOG=1 messages from its payload
    PID 1...
  - optionally automatically add FORWARD rules to iptables whenever nspawn is
    running, remove them when shut down.
  - add support for sysext extensions, too. i.e. a new --extension= switch that
    takes one or more arguments, and applies the extensions already during
    startup.
  - when main nspawn supervisor process gets suspended due to SIGSTOP/SIGTTOU
    or so, freeze the payload too.
  - support time namespaces
  - on cgroupsv1 issue cgroup empty handler process based on host events, so
    that we make cgroup agent logic safe
  - add API to invoke binary in container, then use that as fallback in
    "machinectl shell"
  - make nspawn suitable for shell pipelines: instead of triggering a hangup
    when input is finished, send ^D, which synthesizes an EOF. Then wait for
    hangup or ^D before passing on the EOF.
  - greater control over selinux label?
  - support that /proc, /sys/, /dev are pre-mounted
  - maybe allow TPM passthrough, backed by swtpm, and measure --image= hash
    into its PCR 11, so that nspawn instances can be TPM enabled, and partake
    in measurements/remote attestation and such. swtpm would run outside of
    control of container, and ideally would itself bind its encryption keys to
    host TPM.
  - make boot assessment do something sensible in a container. i.e send an
    sd_notify() from payload to container manager once boot-up is completed
    successfully, and use that in nspawn for dealing with boot counting,
    implemented in the partition table labels and directory names.
  - optionally set up nftables/iptables routes that forward UDP/TCP traffic on
    port 53 to resolved stub 127.0.0.54
  - maybe optionally insert .nspawn file as GPT partition into images, so that
    such container images are entirely stand-alone and can be updated as one.
  - The subreaper logic we currently have seems overly complex. We should
    investigate whether creating the inner child with CLONE_PARENT isn't better.
  - Reduce the number of sockets that are currently in use and just rely on one
    or two sockets.
  - map foreign UID range through 1:1
  - systemd-nspawn should get the same SSH key support that vmspawn now has.

- oci: add support for "importctl import-oci" which implements the "OCI layout"
  spec (i.e. acquiring via local fs access), as opposed to the current
  "importctl pull-oci" which focuses on the "OCI image spec", i.e. downloads
  from the web (i.e. acquiring via URLs).

- oci: add support for blake hashes for layers

- oci: support "data" in any OCI descriptor, not just manifest config.

- On boot, auto-generate an asymmetric key pair from the TPM,
  and use it for validating DDIs and credentials. Maybe upload it to the kernel
  keyring, so that the kernel does this validation for us for verity and kernel
  modules

- on shutdown: move utmp, wall, audit logic all into PID 1 (or logind?)

- once swtpm's sd_notify() support has landed in the distributions, remove the
  invocation in tpm2-swtpm.c and let swtpm handle it.

- Once the root fs LUKS volume key is measured into PCR 15, default to binding
  credentials to PCR 15 in "systemd-creds"

- optionally, also require WATCHDOG=1 notifications during service start-up and shutdown

- optionally, collect cgroup resource data, and store it in per-unit RRD files,
  suitable for processing with rrdtool. Add bus API to access this data, and
  possibly implement a CPULoad property based on it.

- optionally: turn on cgroup delegation for per-session scope units

- pam_systemd: on interactive logins, maybe show SUPPORT_END information at
  login time, à la motd

- pam_systemd_home: add module parameter to control whether to only accept
  only password or only pcks11/fido2 auth, and then use this to hook nicely
  into two of the three PAM stacks gdm provides.
  See discussion at https://github.com/authselect/authselect/pull/311

- paranoia: whenever we process passwords, call mlock() on the memory
  first. i.e. look for all places we use free_and_erasep() and
  augment them with mlock(). Also use MADV_DONTDUMP.
  Alternatively (preferably?) use memfd_secret().

- pcrextend/tpm2-util: add a concept of "rotation" to event log. i.e. allow
  trailing parts of the logs if time or disk space limit is hit. Protect the
  boot-time measurements however (i.e. up to some point where things are
  settled), since we need those for pcrlock measurements and similar. When
  deleting entries for rotation, place an event that declares how many items
  have been dropped, and what the hash before and after that.

- pcrextend: after measuring get an immediate quote from the TPM, and validate
  it. if it doesn't check out, i.e. the measurement we made doesn't appear in
  the PCR then also reboot.

- pcrextend: maybe add option to disable measurements entirely via kernel cmdline

- pcrextend: when we fail to measure, reboot the system (at least optionally).
  important because certain measurements are supposed to "destroy" tpm object
  access.

- pcrlock: add support for multi-profile UKIs

- **pcrlock:**
  - add kernel-install plugin that automatically creates UKI .pcrlock file when
    UKI is installed, and removes it when it is removed again
  - automatically install PE measurement of sd-boot on "bootctl install"
  - pre-calc sysext + kernel cmdline measurements
  - pre-calc cryptsetup root key measurement
  - maybe make systemd-repart generate .pcrlock for old and new GPT header in
    /run?
  - Add support for more than 8 branches per PCR OR
  - add "systemd-pcrlock lock-kernel-current" or so which synthesizes .pcrlock
    policy from currently booted kernel/event log, to close gap for first boot
    for pre-built images

- per-service sandboxing option: ProtectIds=. If used, will overmount
  /etc/machine-id and /proc/sys/kernel/random/boot_id with synthetic files, to
  make it harder for the service to identify the host. Depending on the user
  setting it should be fully randomized at invocation time, or a hash of the
  real thing, keyed by the unit name or so. Of course, there are other ways to
  get these IDs (e.g. journal) or similar ids (e.g. MAC addresses, DMI ids, CPU
  ids), so this knob would only be useful in combination with other lockdown
  options. Particularly useful for portable services, and anything else that
  uses RootDirectory= or RootImage=. (Might also over-mount
  /sys/class/dmi/id/*{uuid,serial} with /dev/null).

- Permit masking specific netlink APIs with RestrictAddressFamily=

- pick up creds from EFI vars

- PID 1 should send out sd_notify("WATCHDOG=1") messages (for usage in the --user mode, and when run via nspawn)

- **pid1:**
  - When logging about multiple units (stopping BoundTo units, conflicts, etc.),
    log both units as UNIT=, so that journalctl -u triggers on both.
  - generate better errors when people try to set transient properties
    that are not supported...
    https://lists.freedesktop.org/archives/systemd-devel/2015-February/028076.html
  - recreate systemd's D-Bus private socket file on SIGUSR2
  - when we automatically restart a service, ensure we restart its rdeps, too.
  - hide PAM options in fragment parser when compile time disabled
  - Support --test based on current system state
  - If we show an error about a unit (such as not showing up) and it has no Description string, then show a description string generated form the reverse of unit_name_mangle().
  - after deserializing sockets in socket.c we should reapply sockopts and things
  - drop PID 1 reloading, only do reexecing (difficult: Reload()
    currently is properly synchronous, Reexec() is weird, because we
    cannot delay the response properly until we are back, so instead of
    being properly synchronous we just keep open the fd and close it
    when done. That means clients do not get a successful method reply,
    but much rather a disconnect on success.
  - when breaking cycles drop services from /run first, then from /etc, then from /usr
  - when a bus name of a service disappears from the bus make sure to queue further activation requests
  - maybe introduce CoreScheduling=yes/no to optionally set a PR_SCHED_CORE cookie, so that all
    processes in a service's cgroup share the same cookie and are guaranteed not to share SMT cores
    with other units https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/Documentation/admin-guide/hw-vuln/core-scheduling.rst
  - ExtensionImages= deduplication for services is currently only applied to disk images without GPT envelope.
    This should be extended to work with proper DDIs too, as well as directory confext/sysext. Moreover,
    system-wide confext/sysext should support this too.
  - Pin the mount namespace via FD by sending it back from sd-exec to the manager, and use it
    for live mounting, instead of doing it via PID
  - also remove PID files of a service when the service starts, not just
    when it exits
  - activation by journal search expression
  - lock image configured with RootDirectory=/RootImage= using the usual nspawn semantics while the unit is up
  - find a way how we can reload unit file configuration for
    specific units only, without reloading the whole of systemd

- **PidRef conversion work:**
  - cg_pid_get_xyz()
  - pid_from_same_root_fs()
  - get_ctty_devnr()
  - actually wait for POLLIN on pidref's pidfd in service logic
  - openpt_allocate_in_namespace()
  - unit_attach_pid_to_cgroup_via_bus()
  - cg_attach() – requires new kernel feature
  - journald's process cache

- port copy.c over to use LabelOps for all labelling.

- portable services: attach not only unit files to host, but also simple
  binaries to a tmpfs path in $PATH.

- portabled: when extracting unit files and copying to system.attached, if a
  .p7s is available in the image, use it to protect the system.attached copy
  with fs-verity, so that it cannot be tampered with

- print a nicer explanation if people use variable/specifier expansion in ExecStart= for the first word

- **Process credentials in:**
  - crypttab-generator: allow defining additional crypttab-like volumes via
    credentials (similar: verity-generator, integrity-generator). Use
    fstab-generator logic as inspiration.
  - run-generator: allow defining additional commands to run via a credential
  - resolved: allow defining additional /etc/hosts entries via a credential (it
    might make sense to then synthesize a new combined /etc/hosts file in /run
    and bind mount it on /etc/hosts for other clients that want to read it.
  - repart: allow defining additional partitions via credential
  - timesyncd: pick NTP server info from credential
  - portabled: read a credential "portable.extra" or so, that takes a list of
    file system paths to enable on start.
  - make systemd-fstab-generator look for a system credential encoding root= or
    usr=
  - in gpt-auto-generator: check partition uuids against such uuids supplied via
    sd-stub credentials. That way, we can support parallel OS installations with
    pre-built kernels.

- properly handle loop back mounts via fstab, especially regards to fsck/passno

- properly serialize the ExecStatus data from all ExecCommand objects
  associated with services, sockets, mounts and swaps. Currently, the data is
  flushed out on reload, which is quite a limitation.

- ProtectClock= (drops CAP_SYS_TIMES, adds seccomp filters for settimeofday, adjtimex), sets DeviceAllow o /dev/rtc

- ProtectKeyRing= to take keyring calls away

- ProtectMount= (drop mount/umount/pivot_root from seccomp, disallow fuse via DeviceAllow, imply Mountflags=slave)

- ProtectReboot= that masks reboot() and kexec_load() syscalls, prohibits kill
  on PID 1 with the relevant signals, and makes relevant files in /sys and
  /proc (such as the sysrq stuff) unavailable

- ProtectTracing= (drops CAP_SYS_PTRACE, blocks ptrace syscall, makes /sys/kernel/tracing go away)

- ptyfwd: use osc context information in vmspawn/nspawn/… to optionally only
  listen to ^]]] key when no further vmspawn/nspawn context is allocated

- ptyfwd: usec osc context information to propagate status messages from
  vmspawn/nspawn to service manager's "status" string, reporting what is
  currently in the fg

- pull-oci: progress notification

- redefine /var/lib/extensions/ as the dir one can place all three of sysext,
  confext as well is multi-modal DDIs that qualify as both. Then introduce
  /var/lib/sysexts/ which can be used to place only DDIs that shall be used as
  sysext

- refcounting in sd-resolve is borked

- refuse boot if /usr/lib/os-release is missing or /etc/machine-id cannot be set up

- remove any syslog support from log.c — we probably cannot do this before split-off udev is gone for good

- remove tomoyo support, it's obsolete and unmaintained apparently

- RemoveKeyRing= to remove all keyring entries of the specified user

- repart + cryptsetup: support file systems that are encrypted and use verity
  on top. Usecase: confexts that shall be signed by the admin but also be
  confidential. Then, add a new --make-ddi=confext-encrypted for this.

- repart/gpt-auto/DDIs: maybe introduce a concept of "extension" partitions,
  that have a new type uuid and can "extend" earlier partitions, to work around
  the fact that systemd-repart can only grow the last partition defined. During
  activation we'd simply set up a dm-linear mapping to merge them again. A
  partition that is to be extended would just set a bit in the partition flags
  field to indicate that there's another extension partition to look for. The
  identifying UUID of the extension partition would be hashed in counter mode
  from the uuid of the original partition it extends. Inspiration for this is
  the "dynamic partitions" concept of new Android. This would be a minimalistic
  concept of a volume manager, with the extents it manages being exposes as GPT
  partitions. I a partition is extended multiple times they should probably
  grow exponentially in size to ensure O(log(n)) time for finding them on
  access.

- repart: introduce concept of "ghost" partitions, that we setup in almost all
  ways like other partitions, but do not actually register in the actual gpt
  table, but only tell the kernel about via BLKPG ioctl. These partitions are
  disk backed (hence can be large), but not persistent (as they are invisible
  on next boot). Could be used by live media and similar, to boot up as usual
  but automatically start at zero on each boot. There should also be a way to
  make ghost partitions properly persistent on request.

- repart: introduce MigrateFileSystem= or so which is a bit like
  CopyFiles=/CopyBlocks= but operates via btrfs device logic: adds target as
  new device then removes source from btrfs. Usecase: a live medium which uses
  "ghost" partitions as suggested above, which can become persistent on request
  on another device.

- replace all \x1b, \x1B, \033 C string escape sequences in our codebase with a
  more readable \e. It's a GNU extension, but a ton more readable than the
  others, and most importantly it doesn't result in confusing errors if you
  suffix the escape sequence with one more decimal digit, because compilers
  think you might actually specify a value outside the 8bit range with that.

- replace all uses of fopen_temporary() by fopen_tmpfile_linkable() +
  flink_tmpfile() and then get rid of fopen_temporary(). Benefit: use O_TMPFILE
  pervasively, and avoid rename() wherever we can.

- replace bootctl's PE version check to actually use APIs from pe-binary.[ch]
  to find binary version.

- replace symlink_label(), mknodat_label(), btrfs_subvol_make_label(),
  mkdir_label() and related calls by flags-based calls that use
  label_ops_pre()/label_ops_post().

- report: have something that requests cloud workload identity bearer tokens
  and includes it in the report

- Reset TPM2 DA bit on each successful boot

- **resolved:**
  - mDNS/DNS-SD
        - service registration
        - service/domain/types browsing
        - avahi compat
  - DNS-SD service registration from socket units
  - resolved should optionally register additional per-interface LLMNR
    names, so that for the container case we can establish the same name
    (maybe "host") for referencing the server, everywhere.
  - allow clients to request DNSSEC for a single lookup even if DNSSEC is off (?)
  - make resolved process DNR DHCP info
  - report ttl in resolution replies if we know it. This data is useful
    for tools such as wireguard which want to periodically re-resolve DNS names,
    and might want to use the TTL has hint for that.
  - take possession of some IPv6 ULA address (let's say
    fd00:5353:5353:5353:5353:5353:5353:5353), and listen on port 53 on it for the
    local stubs, so that we can make the stub available via ipv6 too.

- revisit how we pass fs images and initrd to the kernel. take uefi http boot
  ramdisks as inspiration: for any confext/sysext/initrd erofs/DDI image simply
  generate a fake pmem region in the UEFI memory tables, that Linux then turns
  into /dev/pmemX. Then turn of cpio-based initrd logic in linux kernel,
  instead let kernel boot directly into /dev/pmem0. In order to allow our usual
  cpio-based parameterization, teach PID 1 to just uncompress cpio ourselves
  early on, from another pmem device. (Related to this, maybe introduce a new
  PE section .ramdisk that just synthesizes pmem devices from arbitrary
  blobs. Could be particularly useful in add-ons)

- rework ExecOutput and ExecInput enums so that EXEC_OUTPUT_NULL loses its
  magic meaning and is no longer upgraded to something else if set explicitly.

- rework fopen_temporary() to make use of open_tmpfile_linkable() (problem: the
  kernel doesn't support linkat() that replaces existing files, currently)

- rework journalctl -M to be based on a machined method that generates a mount
  fd of the relevant journal dirs in the container with uidmapping applied to
  allow the host to read it, while making everything read-only.

- rework loopback support in fstab: when "loop" option is used, then
  instantiate a new systemd-loop@.service for the source path, set the
  lo_file_name field for it to something recognizable derived from the fstab
  line, and then generate a mount unit for it using a udev generated symlink
  based on lo_file_name.

- rework recursive read-only remount to use new mount API

- rework seccomp/nnp logic that even if User= is used in combination with
  a seccomp option we don't have to set NNP. For that, change uid first while
  keeping CAP_SYS_ADMIN, then apply seccomp, the drop cap.

- rewrite bpf-devices in libbpf/C code, rather than home-grown BPF assembly, to
  match bpf-restrict-fs, bpf-restrict-ifaces, bpf-socket-bind

- rewrite bpf-firewall in libbpf/C code

- rfkill,backlight: we probably should run the load tools inside of the udev rules so that the state is properly initialized by the time other software sees it

- rough proposed implementation design for remote attestation infra: add a tool
  that generates a quote of local PCRs and NvPCRs, along with synchronous log
  snapshot. use "audit session" logic for that, so that we get read-outs and
  signature in one step. Then turn this into a JSON object. Use the "TCG TSS 2.0
  JSON Data Types and Policy Language" format to encode the signature. And CEL
  for the measurement log.

- run0: maybe enable utmp for run0 sessions, so that they are easily visible.

- **sd-boot:**
  - do something useful if we find exactly zero entries (ignoring items
    such as reboot/poweroff/factory reset). Show a help text or so.
  - optionally ask for confirmation before executing certain operations
    (e.g. factory resets, storagetm with world access, and so on)
  - for each installed OS, grey out older entries (i.e. all but the
    newest), to indicate they are obsolete
  - we probably should include all BootXY EFI variable defined boot
    entries in our menu, and then suppress ourselves. Benefit: instant
    compatibility with all other OSes which register things there, in particular
    on other disks. Always boot into them via NextBoot EFI variable, to not
    affect PCR values.
  - should look for information what to boot in SMBIOS, too, so that VM
    managers can tell sd-boot what to boot into and suchlike
  - instead of unconditionally deriving the ESP to search boot loader
    spec entries in from the paths of sd-boot binary, let's optionally allow it
    to be configured on sd-boot cmdline + efi var. Use case: embed sd-boot in the
    UEFI firmware (for example, ovmf supports that via qemu cmdline option), and
    use it to load stuff from the ESP.
  - optionally, show boot menu when previous default boot item has
    non-zero "tries done" count

- **sd-bus:**
  - EBADSLT handling
  - GetAllProperties() on a non-existing object does not result in a failure currently
  - port to sd-resolve for connecting to TCP dbus servers
  - see if we can introduce a new sd_bus_get_owner_machine_id() call to retrieve the machine ID of the machine of the bus itself
  - see if we can drop more message validation on the sending side
  - add API to clone sd_bus_message objects
  - longer term: priority inheritance
  - dbus spec updates:
        - NameLost/NameAcquired obsolete
        - path escaping
  - update systemd.special(7) to mention that dbus.socket is only about the compatibility socket now
  - add vtable flag, that may be used to request client creds implicitly
    and asynchronously before dispatching the operation
  - parse addresses given in sd_bus_set_addresses immediately and not
    only when used. Add unit tests.

- **sd-device:**
  - add an API for acquiring list of child devices, given a device
    objects (i.e. all child dirents that dirs or symlinks to dirs)
  - maybe pin the sysfs dir with an fd, during the entire runtime of
    an sd_device, then always work based on that.
  - should return the devnum type (i.e. 'b' or 'c') via some API for an
    sd_device object, so that data passed into sd_device_new_from_devnum() can
    also be queried.

- **sd-event:**
  - allow multiple signal handlers per signal?
  - document chaining of signal handler for SIGCHLD and child handlers
  - define more intervals where we will shift wakeup intervals around in, 1h, 6h, 24h, ...
  - maybe support iouring as backend, so that we allow hooking read and write
    operations instead of IO ready events into event loops. See considerations
    here:
    http://blog.vmsplice.net/2020/07/rethinking-event-loop-integration-for.html
  - add ability to "chain" event sources. Specifically, add a call
    sd_event_source_chain(x, y), which will automatically enable event source y
    in oneshot mode once x is triggered. Use case: in src/core/mount.c implement
    the /proc/self/mountinfo rescan on SIGCHLD with this: whenever a SIGCHLD is
    seen, trigger the rescan defer event source automatically, and allow it to be
    dispatched *before* the SIGCHLD is handled (based on priorities). Benefit:
    dispatch order is strictly controlled by priorities again. (next step: chain
    event sources to the ratelimit being over)
  - compat wd reuse in inotify code: keep a set of removed watch
    descriptors, and clear this set piecemeal when we see the IN_IGNORED event
    for it, or when read() returns EAGAIN or on IN_Q_OVERFLOW. Then, whenever we
    see an inotify wd event check against this set, and if it is contained ignore
    the event. (to be fully correct this would have to count the occurrences, in
    case the same wd is reused multiple times before we start processing
    IN_IGNORED again)
  - optionally, if per-event source rate limit is hit, downgrade
    priority, but leave enabled, and once ratelimit window is over, upgrade
    priority again. That way we can combat event source starvation without
    stopping processing events from one source entirely.
  - similar to existing inotify support add fanotify support (given
    that apparently new features in this area are only going to be added to the
    latter).
  - add 1st class event source for clock changes
  - add 1st class event source for timezone changes
  - add native support for P_ALL waitid() watching, then move PID 1 to
    it for reaping assigned but unknown children. This needs to some special care
    to operate somewhat sensibly in light of priorities: P_ALL will return
    arbitrary processes, regardless of the priority we want to watch them with,
    hence on each event loop iteration check all processes which we shall watch
    with higher prio explicitly, and then watch the entire rest with P_ALL.

- sd-journal puts a limit on parallel journal files to view at once. journald
  should probably honour that same limit (JOURNAL_FILES_MAX) when vacuuming to
  ensure we never generate more files than we can actually view.

- sd-lldp: pick up 802.3 maximum frame size/mtu, to be able to detect jumbo
  frame capable networks

- **sd-rtnl:**
  - add support for more attribute types
  - inbuilt piping support (essentially degenerate async)? see loopback-setup.c and other places

- **sd-stub:**
  - detect if we are running with uefi console output on serial, and if so
    automatically add console= to kernel cmdline matching the same port.
  - add ".bootcfg" section for kernel bootconfig data (as per
    https://docs.kernel.org/admin-guide/bootconfig.html)

- sd_notify/vsock: maybe support binding to AF_VSOCK in Type=notify services,
  then passing $NOTIFY_SOCKET and $NOTIFY_GUESTCID with PID1's cid (typically
  fixed to "2", i.e. the official host cid) and the expected guest cid, for the
  two sides of the channel. The latter env var could then be used in an
  appropriate qemu cmdline. That way qemu payloads could talk sd_notify()
  directly to host service manager.

- **seccomp:**
  - maybe use seccomp_merge() to merge our filters per-arch if we can.
    Apparently kernel performance is much better with fewer larger seccomp
    filters than with more smaller seccomp filters.
  - by default mask x32 ABI system wide on x86-64. it's on its way out
  - don't install filters for ABIs that are masked anyway for the
    specific service

- seems that when we follow symlinks to units we prefer the symlink
  destination path over /etc and /usr. We should not do that. Instead
  /etc should always override /run+/usr and also any symlink
  destination.

- .service with invalid Sockets= starts successfully.

- services: add support for cryptographically unlocking per-service directories
  via TPM2. Specifically, for StateDirectory= (and related dirs) use fscrypt to
  set up the directory so that it can only be accessed if host and app are in
  order.

- shared/wall: Once more programs are taught to prefer sd-login over utmp,
  switch the default wall implementation to wall_logind
  (https://github.com/systemd/systemd/pull/29051#issuecomment-1704917074)

- show whether a service has out-of-date configuration in "systemctl status" by
  using mtime data of ConfigurationDirectory=.

- shutdown logging: store to EFI var, and store to USB stick?

- signed bpf loading: to address need for signature verification for bpf
  programs when they are loaded, and given the bpf folks don't think this is
  realistic in kernel space, maybe add small daemon that facilitates this
  loading on request of clients, validates signatures and then loads the
  programs. This daemon should be the only daemon with privs to do load BPF on
  the system. It might be a good idea to run this daemon already in the initrd,
  and leave it around during the initrd transition, to continue serve requests.
  Should then live in its own fs namespace that inherits from the initrd's
  fs tree, not from the host, to isolate it properly. Should set
  PR_SET_DUMPABLE so that it cannot be ptraced from the host. Should have
  CAP_SYS_BPF as only service around.

- SIGRTMIN+18 and memory pressure handling should still be added to: localed,
  oomd, timedated.

- socket units: allow creating a udev monitor socket with ListenDevices= or so,
  with matches, then activate app through that passing socket over

- special case some calls of chase() to use openat2() internally, so
  that the kernel does what we otherwise do.

- Split vconsole-setup in two, of which the second is started via udev (instead
  of the "restart" job it currently fires). That way, boot becomes purely
  positive again, and we can nicely order the two against each other.

- start making use of the new --graceful switch to util-linux' umount command

- start using STATX_SUBVOL in btrfs_is_subvol(). Also, make use of it
  generically, so that image discovery recognizes bcachefs subvols too.

- storagetm: maybe also serve the specified disk via HTTP? we have glue for
  microhttpd anyway already. Idea would also be serve currently booted UKI as
  separate HTTP resource, so that EFI http boot on another system could
  directly boot from our system, with full access to the hdd.

- **storagetm:**
  - add USB mass storage device logic, so that all local disks are also exposed
    as mass storage devices on systems that have a USB controller that can
    operate in device mode
  - add NVMe authentication

- **sigpwr.target** doesn't do anything useful. Consider hooking it up to
  poweroff.target.

- Provide a fallback in **rescue.service** that prints a fixed message
  if sulogin-shell could not be started.

- support boot into nvme-over-tcp: add generator that allows specifying nvme
  devices on kernel cmdline + credentials. Also maybe add interactive mode
  (where the user is prompted for nvme info), in order to boot from other
  system's HDD.

- support crash reporting operation modes (https://live.gnome.org/GnomeOS/Design/Whiteboards/ProblemReporting)

- support projid-based quota in machinectl for containers

- Support ReadWritePaths/ReadOnlyPaths/InaccessiblePaths in systemd --user instances
  via the new unprivileged Landlock LSM (https://landlock.io)

- support specifying download hash sum in systemd-import-generator expression
  to pin image/tarball.

- sync dynamic uids/gids between host+portable service (i.e. if DynamicUser=1 is set for a service, make sure that the
  selected user is resolvable in the service even if it ships its own /etc/passwd)

- synchronize console access with BSD locks:
  https://lists.freedesktop.org/archives/systemd-devel/2014-October/024582.html

- sysext: before applying a sysext, do a superficial validation run so that
  things are not rearranged to wildy. I.e. protect against accidental fuckups,
  such as masking out /usr/lib/ or so. We should probably refuse if existing
  inodes are replaced by other types of inodes or so.

- sysext: measure all activated sysext into a TPM PCR

- system BPF LSM policy that enforces that block device backed mounts may only
  be established on top of dm-crypt or dm-verity devices, or an allowlist of
  file systems (which should probably include vfat, for compat with the ESP)

- system BPF LSM policy that prohibits creating files owned by "nobody"
  system-wide

- system BPF LSM policy that prohibits creating or opening device nodes outside
  of devtmpfs/tmpfs, except if they are the pseudo-devices /dev/null,
  /dev/zero, /dev/urandom and so on.

- "systemctl preset-all" should probably order the unit files it
  operates on lexicographically before starting to work, in order to
  ensure deterministic behaviour if two unit files conflict (like DMs
  do, for example)

- systemctl, machinectl, loginctl: port "status" commands over to
  format-table.c's vertical output logic.

- **systemctl:**
  - add systemctl switch to dump transaction without executing it
  - Add a verbose mode to "systemctl start" and friends that explains what is being done or not done
  - print nice message from systemctl --failed if there are no entries shown, and hook that into ExecStartPre of rescue.service/emergency.service
  - add new command to systemctl: "systemctl system-reexec" which reexecs as many daemons as virtually possible
  - systemctl enable: fail if target to alias into does not exist? maybe show how many units are enabled afterwards?
  - systemctl: "Journal has been rotated since unit was started." message is misleading
  - if some operation fails, show log output?

- systemd-analyze inspect-elf should show other notes too, at least build-id.

- systemd-analyze netif that explains predictable interface (or networkctl)

- systemd-analyze: port "pcrs" verb to talk directly to TPM device, instead of
  using sysfs interface (well, or maybe not, as that would require privileges?)

- systemd-boot: maybe add support for collapsing menu entries of the same OS
  into one item that can be opened (like in a "tree view" UI element) or
  collapsed. If only a single OS is installed, disable this mode, but if
  multiple OSes are installed might make sense to default to it, so that user
  is not immediately bombarded with a multitude of Linux kernel versions but
  only one for each OS.

- systemd-creds: extend encryption logic to support asymmetric
  encryption/authentication. Idea: add new verb "systemd-creds public-key"
  which generates a priv/pub key pair on the TPM2 and stores the priv key
  locally in /var. It then outputs a certificate for the pub part to stdout.
  This can then be copied/taken elsewhere, and can be used for encrypting creds
  that only the host on its specific hw can decrypt. Then, support a drop-in
  dir with certificates that can be used to authenticate credentials. Flow of
  operations is then this: build image with owner certificate, then after
  boot up issue "systemd-creds public-key" to acquire pubkey of the machine.
  Then, when passing data to the machine, sign with privkey belonging to one of
  the dropped in certs and encrypted with machine pubkey, and pass to machine.
  Machine is then able to authenticate you, and confidentiality is guaranteed.

- systemd-dissect: add --cat switch for dumping files such as /etc/os-release

- systemd-dissect: show available versions inside of a disk image, i.e. if
  multiple versions are around of the same resource, show which ones. (in other
  words: show partition labels).

- systemd-firstboot: optionally install an ssh key for root for offline use.

- systemd-gpt-auto-generator: add kernel cmdline option to override block
  device to dissect. also support dissecting a regular file. useccase: include
  encrypted/verity root fs in UKI.

- systemd-inhibit: make taking delay locks useful: support sending SIGINT or SIGTERM on PrepareForSleep()

- **systemd-measure tool:**
  - pre-calculate PCR 12 (command line) + PCR 13 (sysext) the same way we can precalculate PCR 11
  - add --pcrpkey-auto as an alternative to --pcrpkey=, where it would just use
    the same public key specified with --public-key= (or the one automatically
    derived from --private-key=).
  - allow multiple --initrd=, --efifw=, --dtbauto=, etc., params and pad and
    concatenate the contents in the same way that ukify does, so we end up with
    the expected measurement.

- systemd-mount should only consider modern file systems when mounting, similar
  to systemd-dissect

- systemd-path: Add "private" runtime/state/cache dir enum, mapping to
  $RUNTIME_DIRECTORY, $STATE_DIRECTORY and such

- **systemd-pcrextend:**
  - once we have that start measuring every sysext we apply, every confext,
    every RootImage= we apply, every nspawn and so on. All in separate fake
    PCRs.

- **systemd-repart:**
  - implement Integrity=data/meta and Integrity=inline for non-LUKS
    case. Currently, only Integrity=inline combined with Encrypt= is implemented
    and uses libcryptsetup features. Add support for plain dm-integrity setups when
    integrity tags are stored by the device (inline), interleaved with data (data),
    and on a separate device (meta).
  - add --ghost, that creates file systems, updates the kernel's
    partition table but does *not* update partition table on disk. This way, we
    have disk backed file systems that go effectively disappear on reboot. This
    is useful when booting from a "live" usb stick that is writable, as it means
    we do not have to place everything in memory. Moreover, we could then migrate
    the file systems to disk later (using btrfs device replacement), if needed as
    part of an installer logic.
  - make useful to duplicate current OS onto a second disk, so
    that we can sanely copy ESP contents, /usr/ images, and then set up btrfs
    raid for the root fs to extend/mirror the existing install. This would be
    very similar to the concept of live-install-through-btrfs-migration.
  - should probably enable btrfs' "temp_fsid" feature for all file
    systems it creates, as we have no interest in RAID for repart, and it should
    make sure that we can mount them trivially everywhere.
  - add support for formatting dm-crypt + dm-integrity file
    systems.
  - also derive the volume key from the seed value, for the
    aforementioned purpose.
  - in addition to the existing "factory reset" mode (which
    simply empties existing partitions marked for that). add a mode where
    partitions marked for it are entirely removed. Use case: remove secondary OS
    copy, and redundant partitions entirely, and recreate them anew.
  - if the GPT *disk* UUID (i.e. the one global for the entire
    disk) is set to all FFFFF then use this as trigger for factory reset, in
    addition to the existing mechanisms via EFI variables and kernel command
    line. Benefit: works also on non-EFI systems, and can be requested on one
    boot, for the next.
  - read LUKS encryption key from $CREDENTIALS_DIRECTORY
  - support setting up dm-integrity with HMAC
  - maybe remove half-initialized image on failure. It fails
    if the output file exists, so a repeated invocation will usually fail if
    something goes wrong on the way.
  - by default generate minimized partition tables (i.e. tables
    that only cover the space actually used, excluding any free space at the
    end), in order to maximize dd'ability. Requires libfdisk work, see
    https://github.com/karelzak/util-linux/issues/907
  - MBR partition table support. Care needs to be taken regarding
    Type=, so that partition definitions can sanely apply to both the GPT and the
    MBR case. Idea: accept syntax "Type=gpt:home mbr:0x83" for setting the types
    for the two partition types explicitly. And provide an internal mapping so
    that "Type=linux-generic" maps to the right types for both partition tables
    automatically.
  - allow sizing partitions as factor of available RAM, so that
    we can reasonably size swap partitions for hibernation.
  - allow boolean option that ensures that if existing partition
    doesn't exist within the configured size bounds the whole command fails. This
    is useful to implement ESP vs. XBOOTLDR schemes in installers: have one set
    of repart files for the case where ESP is large enough and one where it isn't
    and XBOOTLDR is added in instead.  Then apply the former first, and if it
    fails to apply use the latter.
  - add per-partition option to never reuse existing partition
    and always create anew even if matching partition already exists.
  - add per-partition option to fail if partition already exist,
    i.e. is not added new. Similar, add option to fail if partition does not exist yet.
  - allow disabling growing of specific partitions, or making
    them (think ESP: we don't ever want to grow it, since we cannot resize vfat)
    Also add option to disable operation via kernel command line.
  - make it a static checker during early boot for existence and
    absence of other partitions for trusted boot environments
  - add support for SD_GPT_FLAG_GROWFS also on real systems, i.e.
    generate some unit to actually enlarge the fs after growing the partition
    during boot.
  - do not print "Successfully resized …" when no change was done.

- systemd-stub: maybe store a "boot counter" in the ESP, and pass it down to
  userspace to allow ordering boots (for example in journalctl). The counter
  would be monotonically increased on every boot.

- systemd-sysext: add "exec" command or so that is a bit like "refresh" but
  runs it in a new namespace and then just executes the selected binary within
  it. Could be useful to run one-off binaries inside a sysext as a CLI tool.

- systemd-tpm2-setup should support a mode where we refuse booting if the SRK
  changed. (Must be opt-in, to not break systems which are supposed to be
  migratable between PCs)

- systemd-tpm2-support: add a some logic that detects if system is in DA
  lockout mode, and queries the user for TPM recovery PIN then.

- add a networking provider API, inspired by the StorageProvider. Make networkd
  a provider that exposes interfaces for adding tap, tun, veth via the api,
  base this on .netdev logic somehow.

- $SYSTEMD_EXECPID that the service manager sets should
  be augmented with $SYSTEMD_EXECPIDFD (and similar for
  other env vars we might send).

- **sysupdate:**
  - add fuzzing to the pattern parser
  - support casync as download mechanism
  - "systemd-sysupdate update --all" support, that iterates through all components
    defined on the host, plus all images installed into /var/lib/machines/,
    /var/lib/portable/ and so on.
  - Allow invocation with a single transfer definition, i.e. with
    --definitions= pointing to a file rather than a dir.
  - add ability to disable implicit decompression of downloaded artifacts,
    i.e. a Compress=no option in the transfer definitions
  - download multiple arbitrary patterns from same source
  - SHA256SUMS format with bearer tokens for each resource to download
  - decrypt SHA256SUMS with key from tpm
  - turn http backend stuff int plugin via varlink
  - for each transfer support looking at multiple sources,
    pick source with newest entry. If multiple sources have the same entry, use
    first configured source. Usecase: "sideload" components from local dirs,
    without disabling remote sources.
  - support "revoked" items, which cause the client to
    downgrade/upgrade
  - introduce per-user version that can update per-user installed dDIs
  - make transport pluggable, so people can plug casync or
    similar behind it, instead of http.

- sysusers: allow specifying a path to an inode *and* a literal UID in the UID
  column, so that if the inode exists it is used, and if not the literal UID is
  used. Use this for services such as the imds one, which run under their own
  UID in the initrd, and whose data should survive to the host, properly owned.

- teach ConditionKernelCommandLine= globs or regexes (in order to match foobar={no,0,off})

- teach nspawn/machined a new bus call/verb that gets you a
  shell in containers that have no sensible pid1, via joining the container,
  and invoking a shell directly. Then provide another new bus call/vern that is
  somewhat automatic: if we detect that pid1 is running and fully booted up we
  provide a proper login shell, otherwise just a joined shell. Then expose that
  as primary way into the container.

- teach parse_timestamp() timezones like the calendar spec already knows it

- teach systemd-nspawn the boot assessment logic: hook up vpick's try counters
  with success notifications from nspawn payloads. When this is enabled,
  automatically support reverting back to older OS version images if newer ones
  fail to boot.

- The bind(AF_UNSPEC) construct (for resetting sockets to their initial state)
  should be blocked in many cases because it punches holes in many sandboxes.

- the pub/priv key pair generated on the TPM2 should probably also be one you
  can use to get a remote attestation quote.

- The udev blkid built-in should expose a property that reflects
  whether media was sensed in USB CF/SD card readers. This should then
  be used to control SYSTEMD_READY=1/0 so that USB card readers aren't
  picked up by systemd unless they contain a medium. This would mirror
  the behaviour we already have for CD drives.

- There's currently no way to cancel fsck (used to be possible via C-c or c on the console)

- there's probably something wrong with having user mounts below /sys,
  as we have for debugfs. for example, src/core/mount.c handles mounts
  prefixed with /sys generally special.
  https://lists.freedesktop.org/archives/systemd-devel/2015-June/032962.html

- think about requeuing jobs when daemon-reload is issued? use case:
  the initrd issues a reload after fstab from the host is accessible
  and we might want to requeue the mounts local-fs acquired through
  that automatically.

- **timer units:**
  - timer units should get the ability to trigger when DST changes
  - Modulate timer frequency based on battery state

- timesyncd: add ugly bus calls to set NTP servers per-interface, for usage by NM

- timesyncd: when saving/restoring clock try to take boot time into account.
  Specifically, along with the saved clock, store the current boot ID. When
  starting, check if the boot id matches. If so, don't do anything (we are on
  the same boot and clock just kept running anyway). If not, then read
  CLOCK_BOOTTIME (which started at boot), and add it to the saved clock
  timestamp, to compensate for the time we spent booting. If EFI timestamps are
  available, also include that in the calculation. With this we'll then only
  miss the time spent during shutdown after timesync stopped and before the
  system actually reset.

- tiny varlink service that takes a fd passed in and serves it via http. Then
  make use of that in networkd, and expose some EFI binary of choice for
  DHCP/HTTP base EFI boot.

- **tmpfiles:**
  - creating new directories/subvolumes/fifos/device nodes
    should not follow symlinks. None of the other adjustment or creation
    calls follow symlinks.
  - teach tmpfiles.d q/Q logic something sensible in the context of XFS/ext4
    project quota
  - teach tmpfiles.d m/M to move / atomic move + symlink old -> new
  - add new line type for setting btrfs subvolume attributes (i.e. rw/ro)
  - tmpfiles: add new line type for setting fcaps
  - add new line type for moving files from some source dir to some
    target dir. then use that to move sysexts/confexts and stuff from initrd
    tmpfs to /run/, so that host can pick things up.
  - allow conditionalizing on factory reset boot, or on first boot.
  - when cleaning up directories, take care of btrfs subvolumes too
    (ID 927 gen 217573 top level 256 path var/tmp/.#test-btrfs4e8ef947c1122031
     ID 928 gen 217573 top level 927 path var/tmp/.#test-btrfs4e8ef947c1122031/rec
     ID 929 gen 217574 top level 928 path var/tmp/.#test-btrfs4e8ef947c1122031/rec/sv2
     ID 930 gen 217575 top level 928 path var/tmp/.#test-btrfs4e8ef947c1122031/rec/sv3
     ID 931 gen 217576 top level 930 path var/tmp/.#test-btrfs4e8ef947c1122031/rec/sv3/sub
     ID 932 gen 217577 top level 928 path var/tmp/.#test-btrfs4e8ef947c1122031/rec/dir/sv4
     ID 933 gen 217578 top level 932 path var/tmp/.#test-btrfs4e8ef947c1122031/rec/dir/sv4/dir/sv5)

- To mimic the new tpm2-measure-pcr= crypttab option and tpm2-measure-nvpcr=
  veritytab option, add the same to integritytab (measuring the HMAC key if one
  is used)

- tpm2-setup: reboot if we detect SRK changed

- tpm2: add (optional) support for generating a local signing key from PCR 15
  state. use private key part to sign PCR 7+14 policies. stash signatures for
  expected PCR7+14 policies in EFI var. use public key part in disk encryption.
  generate new sigs whenever db/dbx/mok/mokx gets updated. that way we can
  securely bind against SecureBoot/shim state, without having to renroll
  everything on each update (but we still have to generate one sig on each
  update, but that should be robust/idempotent). needs rollback protection, as
  usual.

- TPM2: auto-reenroll in cryptsetup, as fallback for hosed firmware upgrades
  and such

- track the per-service PAM process properly (i.e. as an additional control
  process), so that it may be queried on the bus and everything.

- transient units: don't bother with actually setting unit properties, we
  reload the unit file anyway

- **transient units:**
  - add field to transient units that indicate whether systemd or somebody else saves/restores its settings, for integration with libvirt

- Turn systemd-networkd-wait-online into a small varlink service that people
  can talk to and specify exactly what to wait for via a method call, and get a
  response back once that level of "online" is reached.

- tweak journald context caching. In addition to caching per-process attributes
  keyed by PID, cache per-cgroup attributes (i.e. the various xattrs we read)
  keyed by cgroup path, and guarded by ctime changes. This should provide us
  with a nice speed-up on services that have many processes running in the same
  cgroup.

- tweak sd-event's child watching: keep a prioq of children to watch and use
  waitid() only on the children with the highest priority until one is waitable
  and ignore all lower-prio ones from that point on

- **udev-link-config:**
  - Make sure ID_PATH is always exported and complete for
    network devices where possible, so we can safely rely
    on Path= matching

- **udev:**
  - move to LGPL
  - kill scsi_id
  - add trigger --subsystem-match=usb/usb_device device
  - reimport udev db after MOVE events for devices without dev_t
  - re-enable ProtectClock= once only cgroupsv2 is supported.
    See f562abe2963bad241d34e0b308e48cf114672c84.

- udevd: extend memory pressure logic: also kill any idle worker processes

- unify how blockdev_get_root() and sysupdate find the default root block device

- **unify on openssl:**
  - figure out what to do about libmicrohttpd:
    - 1.x is stable and has a hard dependency on gnutls
    - 2.x is in development and has openssl support
    - Worth testing against 2.x in our CI?
  - port fsprg over to openssl

- **unit files:**
  - allow port=0 in .socket units
  - maybe introduce ExecRestartPre=
  - implement Register= switch in .socket units to enable registration
    in Avahi, RPC and other socket registration services.
  - allow Type=simple with PIDFile=
    https://bugzilla.redhat.com/show_bug.cgi?id=723942
  - allow writing multiple conditions in unit files on one line
  - add a concept of RemainAfterExit= to scope units
  - Allow multiple ExecStart= for all Type= settings, so that we can cover rescue.service nicely
  - add verification of [Install] section to systemd-analyze verify

- **unit install:**
  - "systemctl mask" should find all names by which a unit is accessible
    (i.e. by scanning for symlinks to it) and link them all to /dev/null

- update HACKING.md to suggest developing systemd with the ideas from:
  https://0pointer.net/blog/testing-my-system-code-in-usr-without-modifying-usr.html
  https://0pointer.net/blog/running-an-container-off-the-host-usr.html

- use name_to_handle_at() with AT_HANDLE_FID instead of .st_ino (inode
  number) for identifying inodes, for example in copy.c when finding hard
  links, or loop-util.c for tracking backing files, and other places.

- use sd-event ratelimit feature optionally for journal stream clients that log
  too much

- userdb: allow existence checks

- userdb: when synthesizing NSS records, pick "best" password from defined
  passwords, not just the first. i.e. if there are multiple defined, prefer
  unlocked over locked and prefer non-empty over empty.

- userdbd: implement an additional varlink service socket that provides the
  host user db in restricted form, then allow this to be bind mounted into
  sandboxed environments that want the host database in minimal form. All
  records would be stripped of all meta info, except the basic UID/name
  info. Then use this in portabled environments that do not use PrivateUsers=1.

- validatefs: validate more things: check if image id + os id of initrd match
  target mount, so that we refuse early any attempts to boot into different
  images with the wrong kernels. check min/max kernel version too. all encoded
  via xattrs in the target fs.

- Varlinkification of the following command line tools, to open them up to
  other programs via IPC:
  - coredumpctl
  - systemd-bless-boot
  - systemd-measure
  - systemd-dissect
  - systemd-sysupdate
  - systemd-analyze
  - kernel-install
  - systemd-mount (with PK so that desktop environments could use it to mount disks)

- verify that the AF_UNIX sockets of a service in the fs still exist
  when we start a service in order to avoid confusion when a user
  assumes starting a service is enough to make it accessible

- vmspawn switch default swtpm PCR bank to SHA384-only (away from SHA256), at
  least on 64bit archs, simply because SHA384 is typically double the hashing
  speed than SHA256 on 64bit archs (since based on 64bit words unlike SHA256
  which uses 32bit words).

- **vmspawn:**
  - --ephemeral support
  - --read-only support
  - automatically suspend/resume the VM if the host suspends. Use logind
    suspend inhibitor to implement this. request clean suspend by generating
    suspend key presses.
  - support for "real" networking via "-n" and --network-bridge=
  - translate SIGTERM to clean ACPI shutdown event
  - implement hotkeys ^]^]r and ^]^]p like nspawn

- **vmspawn disk hotplug:**
  - virtio-blk-pci — the simplest path. Each disk is an independent PCI
    device. QMP sequence (two steps):

        blockdev-add  {driver: "raw", node-name: "disk1",
                       file: {driver: "file", filename: "/path/to/img"}}
        device_add    {driver: "virtio-blk-pci", id: "disk1", drive: "disk1"}

    Removal (three steps):

        device_del    {id: "disk1"}
                      ... wait for DEVICE_DELETED event (guest acknowledges unplug) ...
        blockdev-del  {node-name: "disk1"}

    Works on both i440fx (legacy PCI) and q35 (PCIe) machine types. PCI
    address auto-assigned by QEMU — no topology pre-configuration needed.
    Each disk independently hotpluggable. Guest sees a virtio block
    device (/dev/vdX). Well-tested path — used by libvirt, Incus, and all
    major VM managers. No special boot-time setup required.

  - NVMe — two-level model: controller + namespace(s). The controller is
    a PCIe device; namespaces live on an internal NVMe bus attached to
    the controller. Key limitation: namespaces are NOT hotpluggable —
    TYPE_NVME_BUS has no HotplugHandler, so device_add of nvme-ns at
    runtime fails with "Bus does not support hotplugging". The only
    option is hotplugging the entire controller, which embeds one
    namespace via its "drive" property:

        blockdev-add  {driver: "raw", node-name: "disk1",
                       file: {driver: "file", filename: "/path/to/img"}}
        device_add    {driver: "nvme", id: "disk1", drive: "disk1", serial: "disk1"}

    Same two-step pattern as virtio-blk, with these limitations:

    1. PCIe-only (implements INTERFACE_PCIE_DEVICE). Does not work on
       i440fx. Requires q35 or virt (aarch64).
    2. Requires pre-configured PCIe root ports that exist at boot.
       Without them, device_add fails with "no slot/function available".
       vmspawn would need to create empty root ports at QEMU startup to
       reserve hotplug slots.
    3. No namespace-level granularity. Each hotplugged disk burns a full
       PCIe slot (controller + one namespace). Cannot add multiple
       namespaces to a single controller at runtime.
    4. Serial property required (up to 20 chars). virtio-blk does not
       require it.

  - virtio-scsi — shared virtio-scsi-pci controller with individual
    scsi-hd devices attached. Incus uses this as its default bus. The
    controller must exist at boot, but individual disks (LUNs) can be
    hotplugged onto it without burning PCI slots. Scales better than
    virtio-blk when many disks are needed, but adds complexity
    (controller management, LUN assignment).

- **vmspawn AcquireQMP():** implement as id-rewriting proxy with FD
  passing. vmspawn acts as a QMP multiplexer. When a client calls
  AcquireQMP():

  1. Create socketpair(AF_UNIX, SOCK_STREAM|SOCK_CLOEXEC, 0).
  2. Return one end to the client via sd_varlink_push_fd() +
     sd_varlink_reply().
  3. Add an sd-event I/O source on vmspawn's end for the client socket.
  4. Send a synthetic QMP greeting on the client socket, handle
     qmp_capabilities locally. Maybe we don't even need that and just
     document that it's a fully initialized connection.
  5. For client commands: read from the client socket, rewrite id to
     vmspawn's internal counter (store mapping internal_id ->
     (client_fd, original_id_json_variant)), forward to QEMU.
  6. For QEMU responses: match internal id, look up original client id,
     rewrite back, send to the correct client socket.
  7. Broadcast QMP events (no id) to all AcquireQMP clients AND to
     SubscribeEvents subscribers.
  8. On client EOF: remove the I/O source, clean up id mappings.

  This keeps vmspawn in full control of the QMP connection — VMControl
  handlers and multiple AcquireQMP clients can coexist without id
  collisions. The server needs SD_VARLINK_SERVER_ALLOW_FD_PASSING_OUTPUT
  (already set in machined's pattern).

  AcquireQMP() also requires server-side Varlink protocol upgrades.
  mvo's WIP branch:
  <https://github.com/systemd/systemd/compare/main...mvo5:varlink-protocol-upgrade-server-side?expand=1>

- we probably needs .pcrpkeyrd or so as additional PE section in UKIs,
  which contains a separate public key for PCR values that only apply in the
  initrd, i.e. in the boot phase "enter-initrd". Then, consumers in userspace
  can easily bind resources to just the initrd. Similar, maybe one more for
  "enter-initrd:leave-initrd" for resources that shall be accessible only
  before unprivileged user code is allowed. (we only need this for .pcrpkey,
  not for .pcrsig, since the latter is a list of signatures anyway). With that,
  when you enroll a LUKS volume or similar, pick either the .pcrkey (for
  coverage through all phases of the boot, but excluding shutdown), the
  .pcrpkeyrd (for coverage in the initrd only) and .pcrpkeybt (for coverage
  until users are allowed to log in).

- we probably should have some infrastructure to acquire sysexts with
  drivers/firmware for local hardware automatically. Idea: reuse the modalias
  logic of the kernel for this: make the main OS image install a hwdb file
  that matches against local modalias strings, and adds properties to relevant
  devices listing names of sysexts needed to support the hw. Then provide some
  tool that goes through all devices and tries to acquire/download the
  specified images.

- We should probably replace /etc/rc.d/README with a symlink to doc
  content. After all it is constant vendor data.

- We should start measuring all services, containers, and system extensions we
  activate. probably into PCR 13. i.e. add --tpm2-measure-pcr= or so to
  systemd-nspawn, and MeasurePCR= to unit files. Should contain a measurement
  of the activated configuration and the image that is being activated (in case
  verity is used, hash of the root hash).

- what to do about udev db binary stability for apps? (raw access is not an option)

- when importing an fs tree with machined, complain if image is not an OS

- when importing an fs tree with machined, optionally apply userns-rec-chown

- when isolating, try to figure out a way how we implicitly can order
  all units we stop before the isolating unit...

- when killing due to service watchdog timeout maybe detect whether target
  process is under ptracing and then log loudly and continue instead.

- when mounting disk images: if IMAGE_ID/IMAGE_VERSION is set in os-release
  data in the image, make sure the image filename actually matches this, so
  that images cannot be misused.

- when switching root from initrd to host, set the machine_id env var so that
  if the host has no machine ID set yet we continue to use the random one the
  initrd had set.

- when systemd-sysext learns mutable /usr/ (and systemd-confext mutable /etc/)
  then allow them to store the result in a .v/ versioned subdir, for some basic
  snapshot logic

- when we detect that there are waiting jobs but no running jobs, do something

- whenever we receive fds via SCM_RIGHTS make sure none got dropped due to the
  reception limit the kernel silently enforces.

- after option+verb introspection is added, add a test to verify that the
  list in proc-cmdline.c matches the actual option list in systemd and shutdown.

- write a document explaining how to write correct udev rules. Mention things
  such as:
  1. do not do lists of vid/pid matches, use hwdb for that
  2. add|change action matches are typically wrong, should be != remove
  3. use GOTO, make rules short
  4. people shouldn't try to make rules file non-world-readable
