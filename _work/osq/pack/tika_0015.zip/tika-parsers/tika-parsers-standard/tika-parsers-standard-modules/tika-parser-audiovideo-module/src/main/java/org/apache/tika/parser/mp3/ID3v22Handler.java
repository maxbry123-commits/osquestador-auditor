/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.mp3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.SAXException;

import org.apache.tika.exception.TikaException;
import org.apache.tika.parser.mp3.ID3v2Frame.RawTag;
import org.apache.tika.parser.mp3.ID3v2Frame.RawTagIterator;

/**
 * This is used to parse ID3 Version 2.2 Tag information from an MP3 file,
 * if available.
 *
 * @see <a href="http://id3lib.sourceforge.net/id3/id3v2-00.txt">MP3 ID3 Version 2.2 specification</a>
 */
public class ID3v22Handler implements ID3Tags {
    private String title;
    private String artist;
    private String album;
    private String year;
    private String composer;
    private String copyright;
    private String genre;
    private String trackNumber;
    private String albumArtist;
    private String disc;
    private List<ID3Comment> comments = new ArrayList<>();
    private List<ID3Picture> pictures = new ArrayList<>();

    public ID3v22Handler(ID3v2Frame frame) throws IOException, SAXException, TikaException {
        RawTagIterator tags = new RawV22TagIterator(frame);
        while (tags.hasNext()) {
            RawTag tag = tags.next();
            switch (tag.name) {
                case "TT2":
                    title = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TP1":
                    artist = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TP2":
                    albumArtist = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TAL":
                    album = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TYE":
                    year = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TCM":
                    composer = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TCR":
                    copyright = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "COM": {
                    ID3Comment comment = getComment(tag.data, 0, tag.data.length);
                    if (comment != null) {
                        comments.add(comment);
                    }
                    break;
                }
                case "PIC": {
                    ID3Picture picture = ID3v2Frame.getV22Picture(tag.data, 0, tag.data.length);
                    if (picture != null) {
                        pictures.add(picture);
                    }
                    break;
                }
                case "TRK":
                    trackNumber = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TPA":
                    disc = getTagString(tag.data, 0, tag.data.length);
                    break;
                case "TCO":
                    genre = extractGenre(getTagString(tag.data, 0, tag.data.length));
                    break;
            }
        }
    }

    protected static String extractGenre(String rawGenre) {
        int open = rawGenre.indexOf("(");
        int close = rawGenre.indexOf(")");
        if (open == -1 && close == -1) {
            return rawGenre;
        } else if (open < close) {
            String genreStr = rawGenre.substring(0, open).trim();
            try {
                int genreID = Integer.parseInt(rawGenre.substring(open + 1, close));
                return ID3Tags.GENRES[genreID];
            } catch (ArrayIndexOutOfBoundsException | NumberFormatException e) {
                return genreStr;
            }
        } else {
            return null;
        }
    }

    private String getTagString(byte[] data, int offset, int length) {
        return ID3v2Frame.getTagString(data, offset, length);
    }

    private ID3Comment getComment(byte[] data, int offset, int length) {
        return ID3v2Frame.getComment(data, offset, length);
    }

    public boolean getTagsPresent() {
        return true;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getAlbum() {
        return album;
    }

    public String getYear() {
        return year;
    }

    public String getComposer() {
        return composer;
    }

    public String getCopyright() {
        return copyright;
    }

    public List<ID3Comment> getComments() {
        return comments;
    }

    public List<ID3Picture> getPictures() {
        return pictures;
    }

    public String getGenre() {
        return genre;
    }

    public String getTrackNumber() {
        return trackNumber;
    }

    public String getAlbumArtist() {
        return albumArtist;
    }

    public String getDisc() {
        return disc;
    }

    /**
     * ID3v22 doesn't have compilations,
     * so returns null;
     */
    public String getCompilation() {
        return null;
    }

    private class RawV22TagIterator extends RawTagIterator {
        private RawV22TagIterator(ID3v2Frame frame) {
            frame.super(3, 3, 1, 0);
        }
    }
}
