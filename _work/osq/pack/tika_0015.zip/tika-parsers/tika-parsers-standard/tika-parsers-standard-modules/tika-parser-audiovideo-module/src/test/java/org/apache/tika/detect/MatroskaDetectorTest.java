/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.detect;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import org.apache.tika.TikaTest;
import org.apache.tika.detect.mkv.MatroskaDetector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;

public class MatroskaDetectorTest extends TikaTest {

    private final MatroskaDetector detector = new MatroskaDetector();

    public TikaInputStream getResourceAsStream(String resourcePath) {
        return TikaInputStream.get(this.getClass().getResourceAsStream(resourcePath));
    }

    @Test
    public void testDetectMKV() throws IOException {
        assertEquals(MediaType.application("x-matroska"),
                detector.detect(getResourceAsStream("/test-documents/sample-mkv.noext"),
                        new Metadata(), new ParseContext()));

        assertEquals(MediaType.application("x-matroska"),
                detector.detect(getResourceAsStream("/test-documents/testMKV.mkv"),
                        new Metadata(), new ParseContext()));


    }

    @Test
    public void testDetectWEBM() throws IOException {
        assertEquals(MediaType.video("webm"),
                detector.detect(getResourceAsStream("/test-documents/sample-webm.noext"),
                        new Metadata(), new ParseContext()));
    }

    @Test
    public void testNullAndShort() throws Exception {
        assertEquals(MediaType.OCTET_STREAM,
                detector.detect(null, new Metadata(), new ParseContext()));

        byte[] bytes = new byte[10];
        try (TikaInputStream tis = TikaInputStream.get(bytes)) {
            assertEquals(MediaType.OCTET_STREAM,
                    detector.detect(tis, new Metadata(), new ParseContext()));
        }

        bytes = new byte[0];
        try (TikaInputStream tis = TikaInputStream.get(bytes)) {
            assertEquals(MediaType.OCTET_STREAM,
                    detector.detect(tis, new Metadata(), new ParseContext()));
        }

    }
}
