/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.audio;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.ProxyInputStream;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import org.apache.tika.annotation.TikaComponent;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Audio;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.metadata.KeyPrefix;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.Property;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.metadata.XMPDM;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.XHTMLContentHandler;

@TikaComponent
public class AudioParser implements Parser {

    /**
     * Serial version UID
     */
    private static final long serialVersionUID = -6015684081240882695L;

    private static final String UNSUPPORTED_AUDIO_FILE_EXCEPTION = "An " +
            "UnsupportedAudioFileException was thrown.  This could mean that the underlying " +
            "parser hit an EndOfFileException or that the file is unsupported. ¯\\_(ツ)_/¯";

    // javax.sound SPI property names the stock JDK providers document (see Audio.SPI_*); any
    // other SPI property name is a third-party extension and falls through AUDIO_SPI below.
    private static final Map<String, Property> STOCK_SPI_PROPERTIES = Map.of(
            "duration", Audio.SPI_DURATION,
            "author", Audio.SPI_AUTHOR,
            "title", Audio.SPI_TITLE,
            "copyright", Audio.SPI_COPYRIGHT,
            "date", Audio.SPI_DATE,
            "comment", Audio.SPI_COMMENT,
            "bitrate", Audio.BITRATE,
            "vbr", Audio.IS_VARIABLE_BITRATE,
            "quality", Audio.SPI_QUALITY);

    private static final KeyPrefix AUDIO_SPI = KeyPrefix.file("audio:",
            "javax.sound SPI property names beyond the stock JDK-documented vocabulary");

    private static final Set<MediaType> SUPPORTED_TYPES = Collections.unmodifiableSet(
            new HashSet<>(
                    Arrays.asList(MediaType.audio("basic"), MediaType.audio("vnd.wave"),
                            // Official, fixed in Tika 1.16
                            MediaType.audio("x-wav"),    // Older, used until Tika 1.16
                            MediaType.audio("x-aiff"))));

    public Set<MediaType> getSupportedTypes(ParseContext context) {
        return SUPPORTED_TYPES;
    }

    public void parse(TikaInputStream tis, ContentHandler handler, Metadata metadata,
                      ParseContext context) throws IOException, SAXException, TikaException {
        // TikaInputStream always supports mark, wrap in SkipFullyInputStream for audio parsing
        InputStream audioStream = new SkipFullyInputStream(tis);
        try {
            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(audioStream);
            Type type = fileFormat.getType();
            if (type == Type.AIFC || type == Type.AIFF) {
                metadata.set(HttpHeaders.CONTENT_TYPE, "audio/x-aiff");
            } else if (type == Type.AU || type == Type.SND) {
                metadata.set(HttpHeaders.CONTENT_TYPE, "audio/basic");
            } else if (type == Type.WAVE) {
                metadata.set(HttpHeaders.CONTENT_TYPE, "audio/vnd.wave");
            }

            AudioFormat audioFormat = fileFormat.getFormat();
            int channels = audioFormat.getChannels();
            if (channels != AudioSystem.NOT_SPECIFIED) {
                metadata.set(Audio.CHANNELS, channels);
            }
            float rate = audioFormat.getSampleRate();
            if (rate != AudioSystem.NOT_SPECIFIED) {
                metadata.set(XMPDM.AUDIO_SAMPLE_RATE, Integer.toString((int) rate));
            }
            int bits = audioFormat.getSampleSizeInBits();
            if (bits != AudioSystem.NOT_SPECIFIED) {
                metadata.set(Audio.BITS_PER_SAMPLE, bits);
                if (bits == 8) {
                    metadata.set(XMPDM.AUDIO_SAMPLE_TYPE, "8Int");
                } else if (bits == 16) {
                    metadata.set(XMPDM.AUDIO_SAMPLE_TYPE, "16Int");
                } else if (bits == 32) {
                    metadata.set(XMPDM.AUDIO_SAMPLE_TYPE, "32Int");
                }
            }
            metadata.set(Audio.ENCODING, audioFormat.getEncoding().toString());

            // The Javadoc documents "duration"/"author"/"title"/"copyright"/"date"/"comment"
            // (AudioFileFormat) and "bitrate"/"vbr"/"quality" (AudioFormat) as available, but
            // Tika's built-in providers (WAV/AIFF/AU/basic) never populate them -- only a
            // third-party SPI would. See Audio.SPI_* / STOCK_SPI_PROPERTIES above.

            addMetadata(metadata, fileFormat.properties());
            addMetadata(metadata, audioFormat.properties());
        } catch (UnsupportedAudioFileException e) {
            // There is no way to know whether this exception was
            // caused by the document being corrupted or by the format
            // just being unsupported. So we do nothing.
            // In Java 8, the AIFFReader throws an EOF, but
            // in Java 11, that EOF is swallowed and an UAFE is thrown.
            metadata.add(TikaCoreProperties.TIKA_META_EXCEPTION_WARNING,
                    UNSUPPORTED_AUDIO_FILE_EXCEPTION);
        }

        XHTMLContentHandler xhtml = new XHTMLContentHandler(handler, metadata, context);
        xhtml.startDocument();
        xhtml.endDocument();
    }

    // package-private: unit-tested directly with a synthetic properties map.
    void addMetadata(Metadata metadata, Map<String, Object> properties) {
        if (properties != null) {
            for (Entry<String, Object> entry : properties.entrySet()) {
                Object value = entry.getValue();
                if (value == null) {
                    continue;
                }
                Property stock = STOCK_SPI_PROPERTIES.get(entry.getKey());
                if (stock != null) {
                    metadata.set(stock, value.toString());
                } else {
                    metadata.add(AUDIO_SPI, entry.getKey(), value.toString());
                }
            }
        }
    }

    private static class SkipFullyInputStream extends ProxyInputStream {

        public SkipFullyInputStream(InputStream proxy) {
            super(proxy);
        }

        @Override
        public long skip(long ln) throws IOException {
            IOUtils.skipFully(in, ln);
            return ln;
        }
    }

}
