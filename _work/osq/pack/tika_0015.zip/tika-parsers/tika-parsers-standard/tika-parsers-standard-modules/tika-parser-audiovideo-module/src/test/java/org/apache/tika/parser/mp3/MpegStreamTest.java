/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.mp3;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import org.apache.tika.io.TikaInputStream;

/**
 * Test class for {@code MpegStream}.
 */
public class MpegStreamTest {
    /**
     * The stream to be tested.
     */
    private MpegStream stream;

    /**
     * Writes the given byte the given number of times into an output stream.
     *
     * @param out   the output stream
     * @param value the value to write
     * @param count the number of bytes to write
     * @throws IOException if an error occurs
     */
    private static void writeBytes(OutputStream out, int value, int count) throws IOException {
        for (int i = 0; i < count; i++) {
            out.write(value);
        }
    }

    /**
     * Writes a frame header in the given output stream.
     *
     * @param out the output stream
     * @param b2  byte 2 of the header
     * @param b3  byte 3 of the header
     * @param b4  byte 4 of the header
     * @throws IOException if an error occurs
     */
    private static void writeFrame(OutputStream out, int b2, int b3, int b4) throws IOException {
        out.write(0xFF);
        out.write(b2);
        out.write(b3);
        out.write(b4);
    }

    @AfterEach
    public void tearDown() throws Exception {
        if (stream != null) {
            stream.close();
        }
    }

    /**
     * Tests whether the default test header can be found in a stream.
     *
     * @param bos the stream
     * @throws IOException if an error occurs
     */
    private void checkDefaultHeader(ByteArrayOutputStream bos) throws IOException {
        TikaInputStream tis = TikaInputStream.get(bos.toByteArray());
        stream = new MpegStream(tis);
        AudioFrame header = stream.nextFrame();
        assertNotNull(header, "No header found");
        assertEquals(AudioFrame.MPEG_V2, header.getVersionCode(), "Wrong MPEG version");
        assertEquals(AudioFrame.LAYER_3, header.getLayer(), "Wrong layer");
        assertEquals(80000, header.getBitRate(), "Wrong bit rate");
        assertEquals(24000, header.getSampleRate(), "Wrong sample rate");
    }

    /**
     * Tests whether an audio frame header can be found somewhere in a stream.
     */
    @Test
    public void testSearchNextFrame() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        writeBytes(bos, 0xFF, 32);
        writeBytes(bos, 0, 16);
        writeBytes(bos, 0xFF, 8);
        bos.write(0xF3);
        bos.write(0x96);
        bos.write(0);
        checkDefaultHeader(bos);
    }

    /**
     * Tests whether invalid frame headers are detected and skipped.
     */
    @Test
    public void testSearchNextFrameInvalid() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        writeFrame(bos, 0xEB, 0x96, 0);
        writeFrame(bos, 0xF9, 0x96, 0);
        writeFrame(bos, 0xF3, 0, 0);
        writeFrame(bos, 0xF3, 0xF0, 0);
        writeFrame(bos, 0xF3, 0x7C, 0);
        writeFrame(bos, 0xF3, 0x96, 0);
        checkDefaultHeader(bos);
    }

    /**
     * Tests a search for another frame which is interrupted because the stream
     * ends.
     */
    @Test
    public void testSeachNextFrameEOS() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bos.write(0xFF);
        bos.write(0xFF);
        bos.write(0xF3);
        bos.write(0x96);
        TikaInputStream tis = TikaInputStream.get(bos.toByteArray());
        stream = new MpegStream(tis);
        assertNull(stream.nextFrame(), "Got a frame");
    }

    /**
     * Parses a single frame header from the given three header bytes
     * following the initial 0xFF sync byte.
     */
    private AudioFrame parseHeader(int b2, int b3, int b4) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        writeFrame(bos, b2, b3, b4);
        TikaInputStream tis = TikaInputStream.get(bos.toByteArray());
        stream = new MpegStream(tis);
        AudioFrame header = stream.nextFrame();
        assertNotNull(header, "No header found");
        return header;
    }

    /**
     * An MPEG1 layer 3 frame carries 1152 samples: 128 kbps at 44100 Hz
     * gives 144 * 128000 / 44100 = 417 bytes and 26.12 ms.
     */
    @Test
    public void testFrameLengthAndDurationMpeg1Layer3() throws IOException {
        AudioFrame header = parseHeader(0xFB, 0x90, 0);
        assertEquals(AudioFrame.MPEG_V1, header.getVersionCode(), "Wrong MPEG version");
        assertEquals(AudioFrame.LAYER_3, header.getLayer(), "Wrong layer");
        assertEquals(417, header.getLength(), "Wrong frame length");
        assertEquals(1152000f / 44100, header.getDuration(), 0.01f, "Wrong duration");
    }

    /**
     * An MPEG2 layer 3 frame carries only 576 samples (LSF mode), so
     * 80 kbps at 24000 Hz with padding gives 72 * 80000 / 24000 + 1 = 241
     * bytes and 24 ms, half of what the MPEG1 formula would report.
     */
    @Test
    public void testFrameLengthAndDurationMpeg2Layer3() throws IOException {
        AudioFrame header = parseHeader(0xF3, 0x96, 0);
        assertEquals(AudioFrame.MPEG_V2, header.getVersionCode(), "Wrong MPEG version");
        assertEquals(AudioFrame.LAYER_3, header.getLayer(), "Wrong layer");
        assertEquals(241, header.getLength(), "Wrong frame length");
        assertEquals(24.0f, header.getDuration(), 0.01f, "Wrong duration");
    }

    /**
     * MPEG2.5 layer 3 also uses the halved LSF frame: 80 kbps at 12000 Hz
     * with padding gives 72 * 80000 / 12000 + 1 = 481 bytes and 48 ms.
     */
    @Test
    public void testFrameLengthAndDurationMpeg25Layer3() throws IOException {
        AudioFrame header = parseHeader(0xE3, 0x96, 0);
        assertEquals(AudioFrame.MPEG_V2_5, header.getVersionCode(), "Wrong MPEG version");
        assertEquals(AudioFrame.LAYER_3, header.getLayer(), "Wrong layer");
        assertEquals(481, header.getLength(), "Wrong frame length");
        assertEquals(48.0f, header.getDuration(), 0.01f, "Wrong duration");
    }

    /**
     * Layer 2 keeps 1152 samples in every MPEG version, so the MPEG2 frame
     * stays at the full length: 80 kbps at 24000 Hz with padding gives
     * 144 * 80000 / 24000 + 1 = 481 bytes and 48 ms.
     */
    @Test
    public void testFrameLengthAndDurationMpeg2Layer2() throws IOException {
        AudioFrame header = parseHeader(0xF5, 0x96, 0);
        assertEquals(AudioFrame.MPEG_V2, header.getVersionCode(), "Wrong MPEG version");
        assertEquals(AudioFrame.LAYER_2, header.getLayer(), "Wrong layer");
        assertEquals(481, header.getLength(), "Wrong frame length");
        assertEquals(48.0f, header.getDuration(), 0.01f, "Wrong duration");
    }

    /**
     * Tries to skip a frame if no current header is available.
     */
    @Test
    public void testSkipNoCurrentHeader() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bos.write("This is a test".getBytes(UTF_8));
        TikaInputStream tis = TikaInputStream.get(bos.toByteArray());
        stream = new MpegStream(tis);
        assertFalse(stream.skipFrame(), "Wrong result");
    }
}
