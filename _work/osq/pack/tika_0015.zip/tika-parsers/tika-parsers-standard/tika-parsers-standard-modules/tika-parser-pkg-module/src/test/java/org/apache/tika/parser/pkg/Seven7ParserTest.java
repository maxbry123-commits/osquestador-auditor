/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.pkg;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.xml.sax.ContentHandler;

import org.apache.tika.exception.TikaMemoryLimitException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;

/**
 * Test case for parsing 7z files.
 */
public class Seven7ParserTest extends AbstractPkgTest {

    /**
     * Tests that the ParseContext parser is correctly
     * fired for all the embedded entries.
     */
    @Test
    public void testEmbedded() throws Exception {
        ContentHandler handler = new BodyContentHandler();
        Metadata metadata = new Metadata();

        try (TikaInputStream tis = getResourceAsStream("/test-documents/test-documents.7z")) {
            AUTO_DETECT_PARSER.parse(tis, handler, metadata, trackingContext);
        }

        // Should have found all 9 documents, but not the directory
        assertEquals(9, tracker.filenames.size());
        assertEquals(9, tracker.mediatypes.size());
        assertEquals(9, tracker.modifiedAts.size());

        // Should have names but not content types, as 7z doesn't
        //  store the content types
        assertEquals("test-documents/testEXCEL.xls", tracker.filenames.get(0));
        assertEquals("test-documents/testHTML.html", tracker.filenames.get(1));
        assertEquals("test-documents/testOpenOffice2.odt", tracker.filenames.get(2));
        assertEquals("test-documents/testPDF.pdf", tracker.filenames.get(3));
        assertEquals("test-documents/testPPT.ppt", tracker.filenames.get(4));
        assertEquals("test-documents/testRTF.rtf", tracker.filenames.get(5));
        assertEquals("test-documents/testTXT.txt", tracker.filenames.get(6));
        assertEquals("test-documents/testWORD.doc", tracker.filenames.get(7));
        assertEquals("test-documents/testXML.xml", tracker.filenames.get(8));

        for (String type : tracker.mediatypes) {
            assertNull(type);
        }
        for (String mod : tracker.modifiedAts) {
            assertNotNull(mod);
            assertTrue(mod.startsWith("20"), "Modified at " + mod);
        }
    }

    /**
     * A 7z whose declared LZMA2 dictionary exceeds the configured limit must fail with a
     * {@link TikaMemoryLimitException} rather than eagerly allocating the dictionary (which a
     * tiny crafted 7z can drive to multiple GiB, OOMing the parser). The default-limit control
     * is {@link #testEmbedded()} above, which would fail if the limit were applied in the wrong
     * unit (e.g. via setMaxMemoryLimitKb, which divides the argument by 1024).
     */
    @Test
    public void testMemoryLimit() throws Exception {
        SevenZParser.Config config = new SevenZParser.Config();
        config.setMemoryLimitInKb(1); // 1 KiB, smaller than any real LZMA2 dictionary
        SevenZParser parser = new SevenZParser(config);

        try (TikaInputStream tis = getResourceAsStream("/test-documents/test-documents.7z")) {
            assertThrows(TikaMemoryLimitException.class, () -> parser.parse(tis,
                    new BodyContentHandler(), new Metadata(), new ParseContext()));
        }
    }
}
