/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.geo.topic;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import org.apache.tika.annotation.TikaComponent;
import org.apache.tika.config.ConfigDeserializer;
import org.apache.tika.config.JsonConfig;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.KeyPrefix;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.Property;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.geo.topic.gazetteer.GeoGazetteerClient;
import org.apache.tika.parser.geo.topic.gazetteer.Location;

/**
 * Locations here are inferred from the text (NER + gazetteer) and stored under {@code geotopic:}
 * (TOOL provenance) -- distinct from {@code Geographic}'s {@code geo:lat/long/alt/timestamp}
 * (W3C Geo Vocabulary; FILE provenance, coordinates the file asserts about itself).
 */
@TikaComponent
public class GeoParser implements Parser {
    private static final long serialVersionUID = -2241391757440215491L;
    private static final Logger LOG = LoggerFactory.getLogger(GeoParser.class);
    private static final MediaType MEDIA_TYPE = MediaType.application("geotopic");
    private static final Set<MediaType> SUPPORTED_TYPES = Collections.singleton(MEDIA_TYPE);

    // Fixed, bounded vocabulary: the best-match location's fields.
    private static final Property GEOGRAPHIC_NAME = Property.externalText("geotopic:name");
    private static final Property GEOGRAPHIC_LONGITUDE = Property.externalText("geotopic:longitude");
    private static final Property GEOGRAPHIC_LATITUDE = Property.externalText("geotopic:latitude");
    // Alternate-location fields are index-suffixed per alternative (unbounded count), so they
    // mint per call rather than as fixed constants; "geotopic:alt-" + text("name1") replaces the
    // pre-existing "Optional_NAME1" key shape (LegacyKeyMigrationFilter bridges the two -- see
    // its geotopicAlternateLocationRule).
    private static final KeyPrefix ALTERNATE =
            KeyPrefix.tool("geotopic:alt-", "GeoParser alternate-location index keys");

    private GeoParserConfig defaultConfig = new GeoParserConfig();
    private GeoGazetteerClient gazetteerClient;

    private boolean initialized;
    private URL modelUrl;
    private NameFinderME nameFinder;
    private boolean available;

    public GeoParser() {
        // Default constructor - uses default GeoParserConfig
    }

    public GeoParser(GeoParserConfig config) {
        this.defaultConfig = config;
    }

    public GeoParser(JsonConfig jsonConfig) {
        this(ConfigDeserializer.buildConfig(jsonConfig, GeoParserConfig.class));
    }

    @Override
    public Set<MediaType> getSupportedTypes(ParseContext parseContext) {
        return SUPPORTED_TYPES;
    }

    /**
     * Initializes this parser
     *
     * @param geoParserConfig config to load the url model from and set the gazetteer client
     */
    public void initialize(GeoParserConfig geoParserConfig) {
        try {
            if (this.modelUrl != null && this.modelUrl.toURI().equals(modelUrl.toURI())) {
                return;
            }
        } catch (URISyntaxException e1) {
            throw new RuntimeException(e1.getMessage());
        }

        this.modelUrl = geoParserConfig.getNerModelUrl();
        gazetteerClient = new GeoGazetteerClient(geoParserConfig);

        // Check if the NER model is available, and if the
        //  lucene-geo-gazetteer is available
        this.available = modelUrl != null && gazetteerClient.checkAvail();

        if (this.available) {
            try {
                TokenNameFinderModel model = new TokenNameFinderModel(modelUrl);
                this.nameFinder = new NameFinderME(model);
            } catch (Exception e) {
                LOG.warn("Named Entity Extractor setup failed: {}", e.getMessage(), e);
                this.available = false;
            }
        }
        initialized = true;
    }

    @Override
    public void parse(TikaInputStream tis, ContentHandler handler, Metadata metadata,
                      ParseContext context) throws IOException, SAXException, TikaException {

        /*----------------configure this parser by ParseContext Object---------------------*/

        GeoParserConfig geoParserConfig = context.get(GeoParserConfig.class, defaultConfig);
        initialize(geoParserConfig);
        if (!isAvailable(geoParserConfig)) {
            return;
        }
        NameEntityExtractor extractor = null;

        try {
            extractor = new NameEntityExtractor(nameFinder);
        } catch (Exception e) {
            LOG.warn("Named Entity Extractor setup failed: {}", e.getMessage(), e);
            return;
        }

        /*----------------get locationNameEntities and best nameEntity for the
        input stream---------------------*/
        extractor.getAllNameEntitiesfromInput(tis);
        extractor.getBestNameEntity();
        ArrayList<String> locationNameEntities = extractor.locationNameEntities;
        String bestner = extractor.bestNameEntity;

        /*------------------------resolve geonames for each ner,
        store results in a hashmap---------------------*/
        Map<String, List<Location>> resolvedGeonames = searchGeoNames(locationNameEntities);

        /*----------------store locationNameEntities and their geonames in a
        geotag, each input has one geotag---------------------*/
        GeoTag geotag = new GeoTag();
        geotag.toGeoTag(resolvedGeonames, bestner);

        /* add resolved entities in metadata */

        metadata.add(GEOGRAPHIC_NAME, geotag.location.getName());
        metadata.add(GEOGRAPHIC_LONGITUDE, geotag.location.getLongitude());
        metadata.add(GEOGRAPHIC_LATITUDE, geotag.location.getLatitude());
        for (int i = 0; i < geotag.alternatives.size(); ++i) {
            GeoTag alter = (GeoTag) geotag.alternatives.get(i);
            metadata.add(ALTERNATE, "name" + (i + 1), alter.location.getName());
            metadata.add(ALTERNATE, "longitude" + (i + 1), alter.location.getLongitude());
            metadata.add(ALTERNATE, "latitude" + (i + 1), alter.location.getLatitude());
        }
    }

    public Map<String, List<Location>> searchGeoNames(ArrayList<String> locationNameEntities) {
        return gazetteerClient.getLocations(locationNameEntities);
    }

    public boolean isAvailable(GeoParserConfig geoParserConfig) {
        if (!initialized) {
            initialize(geoParserConfig);
        }
        return this.available;
    }

    public GeoParserConfig getDefaultConfig() {
        return defaultConfig;
    }
}
