/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.parser.gdal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

import org.apache.tika.TikaTest;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.utils.ProcessUtils;

/**
 * Test harness for the GDAL parser.
 */
public class TestGDALParser extends TikaTest {

    private boolean canRun() {
        String[] checkCmd = {"gdalinfo"};
        // If GDAL is not on the path, do not run the test.
        return ProcessUtils.checkCommand(checkCmd);
    }

    @Test
    public void testParseBasicInfo() {
        assumeTrue(canRun());
        final String expectedDriver = "netCDF/Network Common Data Format";
        final String expectedUpperRight = "512.0,    0.0";
        final String expectedUpperLeft = "0.0,    0.0";
        final String expectedLowerLeft = "0.0,  512.0";
        final String expectedLowerRight = "512.0,  512.0";
        final String expectedCoordinateSystem = "`'";
        final String expectedSize = "512, 512";

        GDALParser parser = new GDALParser();
        TikaInputStream tis = TikaInputStream.get(TestGDALParser.class
                .getResourceAsStream("/test-documents/sresa1b_ncar_ccsm3_0_run1_200001.nc"));
        Metadata met = new Metadata();
        BodyContentHandler handler = new BodyContentHandler();
        try {
            parser.parse(tis, handler, met, new ParseContext());
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }

        assertNotNull(met);
        assertEquals(expectedDriver, met.get("gdal:driver"));
        assumeTrue(met.get("gdal:files") != null);
        //recent version of gdalinfo doesn't include "Coordinate System":
        // GDAL 3.7.1, released 2023/07/06
        //assertNotNull(met.get("gdal:coordinate-system"));
        //assertEquals(expectedCoordinateSystem, met.get("gdal:coordinate-system"));
        assertEquals(expectedSize, met.get("gdal:size"));
        assertEquals(expectedUpperRight, met.get("gdal:upper-right"));
        assertEquals(expectedUpperLeft, met.get("gdal:upper-left"));
        assertEquals(expectedLowerRight, met.get("gdal:lower-right"));
        assertEquals(expectedLowerLeft, met.get("gdal:lower-left"));

    }

    @Test
    public void testParseMetadata() {
        assumeTrue(canRun());
        final String expectedNcInst =
                "NCAR (National Center for Atmospheric Research, Boulder, CO, USA)";
        final String expectedModelNameEnglish = "NCAR CCSM";
        final String expectedProgramId = "Source file unknown Version unknown Date unknown";
        final String expectedProjectId = "IPCC Fourth Assessment";
        final String expectedRealization = "1";
        final String expectedTitle = "model output prepared for IPCC AR4";
        final String expectedSub8Name = "\":ua";
        final String expectedSub8Desc = "[1x17x128x256] eastward_wind (32-bit floating-point)";

        GDALParser parser = new GDALParser();
        TikaInputStream tis = TikaInputStream.get(TestGDALParser.class
                .getResourceAsStream("/test-documents/sresa1b_ncar_ccsm3_0_run1_200001.nc"));
        Metadata met = new Metadata();
        BodyContentHandler handler = new BodyContentHandler();
        try {
            parser.parse(tis, handler, met, new ParseContext());
            assertNotNull(met);
            // gdalinfo "key=value" output lines are doc-derived, so GDALParser routes them
            // through the gdal: KeyPrefix (TIKA-4816); the fixed-vocabulary "Driver"/"Size"/...
            // patterns tested in testParseBasicInfo are unaffected.
            assertEquals(expectedNcInst, met.get("gdal:NC_GLOBAL#institution"));
            assertEquals(expectedModelNameEnglish, met.get("gdal:NC_GLOBAL#model_name_english"));
            assertEquals(expectedProgramId, met.get("gdal:NC_GLOBAL#prg_ID"));
            assertEquals(expectedProjectId, met.get("gdal:NC_GLOBAL#project_id"));
            assertEquals(expectedRealization, met.get("gdal:NC_GLOBAL#realization"));
            assertEquals(expectedTitle, met.get("gdal:NC_GLOBAL#title"));
            assertNotNull(met.get("gdal:SUBDATASET_8_NAME"));
            assertTrue(met.get("gdal:SUBDATASET_8_NAME").endsWith(expectedSub8Name));
            assertEquals(expectedSub8Desc, met.get("gdal:SUBDATASET_8_DESC"));
        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

    @Test
    public void testParseFITS() {
        String fitsFilename = "/test-documents/WFPC2u5780205r_c0fx.fits";

        assumeTrue(canRun());
        // If the exit code is 1 (meaning FITS isn't supported by the installed version of
        // gdalinfo, don't run this test.
        String[] fitsCommand = {"gdalinfo", getResourceAsUrl(fitsFilename).getPath()};
        assumeTrue(ProcessUtils.checkCommand(fitsCommand, 1));

        String expectedAllgMin = "-7.319537E1";
        String expectedAtodcorr = "COMPLETE";
        String expectedAtodfile = "uref$dbu1405iu.r1h";
        String expectedCalVersion = "                        ";
        String expectedCalibDef = "1466";

        GDALParser parser = new GDALParser();
        TikaInputStream tis = getResourceAsStream(fitsFilename);
        Metadata met = new Metadata();
        BodyContentHandler handler = new BodyContentHandler();
        try {
            parser.parse(tis, handler, met, new ParseContext());
            assertNotNull(met);
            // gdal: KeyPrefix, see testParseMetadata above.
            assertEquals(expectedAllgMin, met.get("gdal:ALLG-MIN"));
            assertEquals(expectedAtodcorr, met.get("gdal:ATODCORR"));
            assertEquals(expectedAtodfile, met.get("gdal:ATODFILE"));
            assertEquals(expectedCalVersion, met.get("gdal:CAL_VER"));
            assertEquals(expectedCalibDef, met.get("gdal:CALIBDEF"));

        } catch (Exception e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
}
