/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.server.standard;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jakarta.ws.rs.core.Response;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;
import org.junit.jupiter.api.Test;

import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.metadata.PDF;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.serialization.JsonMetadataList;
import org.apache.tika.server.core.CXFTestBase;
import org.apache.tika.server.core.resource.RecursiveMetadataResource;
import org.apache.tika.server.core.writer.MetadataListMessageBodyWriter;

public class RecursiveMetadataResourceTest extends CXFTestBase {

    private static final String FORM_PATH = "/form";
    private static final String META_PATH = "/rmeta";
    private static final String TEXT_PATH = "/text";
    private static final String MD_PATH = "/md";
    private static final String IGNORE_PATH = "/ignore";
    private static final String XML_PATH = "/xml";
    private static final String UNPARSEABLE_PATH = "/somethingOrOther";
    private static final String SLASH = "/";

    private static final String TEST_RECURSIVE_DOC = "test-documents/test_recursive_embedded.docx";

    @Override
    protected boolean isAllowPerRequestConfig() {
        return true; // exercises per-request config injection
    }

    @Override
    protected void setUpResources(JAXRSServerFactoryBean sf) {
        sf.setResourceClasses(RecursiveMetadataResource.class);
        sf.setResourceProvider(RecursiveMetadataResource.class, new SingletonResourceProvider(new RecursiveMetadataResource(tikaResource)));
    }

    @Override
    protected void setUpProviders(JAXRSServerFactoryBean sf) {
        List<Object> providers = new ArrayList<>();
        providers.add(new MetadataListMessageBodyWriter());
        sf.setProviders(providers);
    }

    @Override
    protected InputStream getTikaConfigInputStream() {
        return getClass().getResourceAsStream("/configs/tika-config-for-server-tests.json");
    }

    @Override
    protected InputStream getPipesConfigInputStream() {
        return getClass().getResourceAsStream("/configs/tika-config-for-server-tests.json");
    }

    @Test
    public void testGZOut() throws Exception {
        Response response = WebClient
                .create(endPoint + META_PATH)
                .accept("application/json")
                .acceptEncoding("gzip")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));

        Reader reader = new InputStreamReader(new GzipCompressorInputStream((InputStream) response.getEntity()), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        assertEquals("Microsoft Office Word", metadataList
                .get(0)
                .get(OfficeOpenXMLExtended.APPLICATION));
        assertContains("plundered our seas", metadataList
                .get(6)
                .get("tk:content"));

        assertEquals("a38e6c7b38541af87148dee9634cb811", metadataList
                .get(10)
                .get("tk:digest:MD5"));
    }

    @Test
    public void testGZIn() throws Exception {

        Response response = WebClient
                .create(endPoint + META_PATH)
                .accept("application/json")
                .encoding("gzip")
                .put(gzip(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC)));

        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        String[] parsedBy = metadataList
                .get(0)
                .getValues(TikaCoreProperties.TIKA_PARSED_BY);
        //make sure the CompressorParser doesn't show up here
        // With pipes-based parsing, the parser chain may be shorter
        assertTrue(parsedBy.length >= 2, "Expected at least 2 parsers");
        // The OOXML parser should be in the chain
        boolean hasOOXML = false;
        for (String p : parsedBy) {
            if (p.contains("OOXMLParser")) {
                hasOOXML = true;
                break;
            }
        }
        assertTrue(hasOOXML, "Expected OOXMLParser in parsedBy chain");

        //test that the rest is as it should be
        assertEquals(12, metadataList.size());
        assertEquals("Microsoft Office Word", metadataList
                .get(0)
                .get(OfficeOpenXMLExtended.APPLICATION));
        assertContains("plundered our seas", metadataList
                .get(6)
                .get("tk:content"));

    }

    @Test
    public void testSimpleWord() throws Exception {
        Response response = WebClient
                .create(endPoint + META_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));

        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);

        assertEquals(12, metadataList.size());
        assertEquals("Microsoft Office Word", metadataList
                .get(0)
                .get(OfficeOpenXMLExtended.APPLICATION));
        assertContains("plundered our seas", metadataList
                .get(6)
                .get("tk:content"));

        assertEquals("a38e6c7b38541af87148dee9634cb811", metadataList
                .get(10)
                .get("tk:digest:MD5"));
    }

    @Test
    public void testPasswordProtected() throws Exception {
        // Test that encrypted document without password shows error
        Response response = WebClient
                .create(endPoint + META_PATH)
                .type("application/vnd.ms-excel")
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TikaResourceTest.TEST_PASSWORD_PROTECTED));

        assertEquals(200, response.getStatus());
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);

        assertNotNull(metadataList
                .get(0)
                .get(TikaCoreProperties.CREATOR));
        assertContains("org.apache.tika.exception.EncryptedDocumentException", metadataList
                .get(0)
                .get(TikaCoreProperties.CONTAINER_EXCEPTION));
    }

    @Test
    @org.junit.jupiter.api.Disabled("multipart config endpoint not yet fully supported with pipes-based parsing")
    public void testPasswordProtectedWithConfig() throws Exception {
        // Test with password via JSON config
        String configJson = """
                {
                  "simple-password-provider": {
                    "password": "password"
                  }
                }
                """;
        Attachment fileAtt = new Attachment("file", "application/vnd.ms-excel",
                ClassLoader.getSystemResourceAsStream(TikaResourceTest.TEST_PASSWORD_PROTECTED));

        Attachment configAtt = new Attachment("config", "application/json",
                new java.io.ByteArrayInputStream(configJson.getBytes(UTF_8)));

        Response response = WebClient
                .create(endPoint + META_PATH + "/config")
                .type("multipart/form-data")
                .accept("application/json")
                .post(new MultipartBody(Arrays.asList(fileAtt, configAtt)));

        assertEquals(200, response.getStatus());

        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        assertNotNull(metadataList
                .get(0)
                .get(TikaCoreProperties.CREATOR));
        assertEquals("pavel", metadataList
                .get(0)
                .get(TikaCoreProperties.CREATOR));
    }

    @Test
    public void testHandlerType() throws Exception {
        //default unspecified
        Response response = WebClient
                .create(endPoint + META_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));

        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        String content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertFalse(content.startsWith("<html"));
        assertContains("plundered our seas", content);

        //extra slash
        response = WebClient
                .create(endPoint + META_PATH + SLASH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertFalse(content.startsWith("<html"));
        assertContains("plundered our seas", content);

        //an unrecognized handler name is a caller typo: 400, not a silent fallback to the
        //default handler, which returned plausible output and looked like it had worked
        response = WebClient
                .create(endPoint + META_PATH + UNPARSEABLE_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        assertEquals(400, response.getStatus());

        //xml
        response = WebClient
                .create(endPoint + META_PATH + XML_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertTrue(content.startsWith("<html xmlns=\"http://www.w3.org/1999/xhtml\">"));

        //text
        response = WebClient
                .create(endPoint + META_PATH + TEXT_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertTrue(content.startsWith("embed_3"));

        //ignore
        response = WebClient
                .create(endPoint + META_PATH + IGNORE_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        assertNull(metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT));

        //markdown
        response = WebClient
                .create(endPoint + META_PATH + MD_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        // Markdown output should not contain HTML/XML tags
        assertFalse(content.startsWith("<html"));
        // Should contain the document text
        assertContains("plundered our seas", content);

    }

    @Test
    public void testHandlerTypeInMultipartXML() throws Exception {
        //default unspecified
        Attachment attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        WebClient webClient = WebClient.create(endPoint + META_PATH + FORM_PATH);

        Response response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .post(attachmentPart);
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        String content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertFalse(content.startsWith("<html"));
        assertContains("plundered our seas", content);

        //unrecognized handler name -> 400, same as the PUT family
        attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        webClient = WebClient.create(endPoint + META_PATH + FORM_PATH + UNPARSEABLE_PATH);

        response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .post(attachmentPart);
        assertEquals(400, response.getStatus());

        //xml
        attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        webClient = WebClient.create(endPoint + META_PATH + FORM_PATH + XML_PATH);

        response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .post(attachmentPart);
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertTrue(content.startsWith("<html xmlns=\"http://www.w3.org/1999/xhtml\">"));

        //text
        attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        webClient = WebClient.create(endPoint + META_PATH + FORM_PATH + TEXT_PATH);

        response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .post(attachmentPart);
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertTrue(content.startsWith("embed_3"));

        //ignore -- no content
        attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        webClient = WebClient.create(endPoint + META_PATH + FORM_PATH + IGNORE_PATH);

        response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .query("handler", "ignore")
                .post(attachmentPart);
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        assertNull(metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT));

        //markdown
        attachmentPart =
                new Attachment("myworddocx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        webClient = WebClient.create(endPoint + META_PATH + FORM_PATH + MD_PATH);

        response = webClient
                .type("multipart/form-data")
                .accept("application/json")
                .post(attachmentPart);
        reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(12, metadataList.size());
        content = metadataList
                .get(6)
                .get(TikaCoreProperties.TIKA_CONTENT)
                .trim();
        assertFalse(content.startsWith("<html"));
        assertContains("plundered our seas", content);
    }

    @Test
    public void testXFA() throws Exception {
        Response response = WebClient
                .create(endPoint + META_PATH)
                .accept("application/json")
                .put(ClassLoader.getSystemResourceAsStream(
                        "test-documents/testPDF_XFA_govdocs1_258578.pdf"));

        assertEquals(200, response.getStatus());
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        List<Metadata> metadataList = JsonMetadataList.fromJson(reader);
        assertEquals(1, metadataList.size());
        Metadata m = metadataList.get(0);
        assertEquals("true", m.get(PDF.HAS_XFA));
        assertTrue(m.get(TikaCoreProperties.TIKA_CONTENT).contains("Young Abraham Lincoln"));
    }

    /**
     * Write limits moved from the `writeLimit` HTTP header to output-limits in the
     * config. Truncation semantics themselves are covered by
     * BasicContentHandlerFactoryTest; what these two assert is that the server
     * actually plumbs a configured limit through to the response.
     */
    @Test
    public void testWriteLimitFromConfig() throws Exception {
        List<Metadata> metadataList = parseWithOutputLimits(
                "{\"output-limits\": {\"writeLimit\": 100, \"throwOnWriteLimit\": true}}");

        int total = 0;
        for (Metadata m : metadataList) {
            String content = m.get(TikaCoreProperties.TIKA_CONTENT);
            total += (content == null) ? 0 : content.length();
        }
        assertTrue(total <= 100, "content should be bounded by the configured writeLimit, was " + total);
    }

    @Test
    public void testNoThrowOnWriteLimitFromConfig() throws Exception {
        List<Metadata> metadataList = parseWithOutputLimits(
                "{\"output-limits\": {\"writeLimit\": 100, \"throwOnWriteLimit\": false}}");

        boolean limitReached = false;
        for (Metadata m : metadataList) {
            if ("true".equals(m.get(TikaCoreProperties.WRITE_LIMIT_REACHED))) {
                limitReached = true;
            }
        }
        assertTrue(limitReached, "write-limit-reached should be reported when throwOnWriteLimit is false");
    }

    private List<Metadata> parseWithOutputLimits(String configJson) throws Exception {
        Attachment fileAtt = new Attachment("file", "application/octet-stream",
                ClassLoader.getSystemResourceAsStream(TEST_RECURSIVE_DOC));
        Attachment configAtt = new Attachment("config", "application/json",
                new java.io.ByteArrayInputStream(configJson.getBytes(UTF_8)));

        Response response = WebClient
                .create(endPoint + META_PATH + "/config")
                .type("multipart/form-data")
                .accept("application/json")
                .post(new MultipartBody(Arrays.asList(fileAtt, configAtt)));

        assertEquals(200, response.getStatus());
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        return JsonMetadataList.fromJson(reader);
    }
}
