/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tika.server.core;


import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.ProcessingException;
import jakarta.ws.rs.core.Response;
import org.apache.cxf.jaxrs.client.WebClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.pipes.api.FetchEmitTuple;
import org.apache.tika.pipes.api.ParseMode;
import org.apache.tika.pipes.api.emitter.EmitKey;
import org.apache.tika.pipes.api.fetcher.FetchKey;
import org.apache.tika.pipes.core.serialization.JsonFetchEmitTuple;
import org.apache.tika.sax.BasicContentHandlerFactory;
import org.apache.tika.sax.ContentHandlerFactory;
import org.apache.tika.utils.ProcessUtils;

public class TikaServerPipesIntegrationTest extends IntegrationTestBase {

    // Own dedicated static @TempDir, not the inherited (instance, per-test-method)
    // TEMP_WORKING_DIR from IntegrationTestBase -- @BeforeAll needs a directory
    // available before any test method runs, and instance-field @TempDir isn't
    // populated until right before each @Test method regardless of test-instance
    // lifecycle.
    @TempDir
    private static Path SETUP_DIR;
    private static Path TEMP_OUTPUT_DIR;
    private static Path TIKA_CONFIG;
    private static Path TIKA_CONFIG_TIMEOUT;
    private static String[] FILES = new String[]{"hello_world.xml", "heavy_hang_30000.xml", "fake_oom.xml", "system_exit.xml", "null_pointer.xml"};

    @BeforeAll
    public static void setUpBeforeClass() throws Exception {
        Path inputDir = SETUP_DIR.resolve("input");
        TEMP_OUTPUT_DIR = SETUP_DIR.resolve("output");
        Files.createDirectories(inputDir);
        Files.createDirectories(TEMP_OUTPUT_DIR);

        for (String mockFile : FILES) {
            Files.copy(TikaPipesTest.class.getResourceAsStream("/test-documents/mock/" + mockFile), inputDir.resolve(mockFile));
        }
        TIKA_CONFIG = SETUP_DIR.resolve("tika-config.json");
        TIKA_CONFIG_TIMEOUT = SETUP_DIR.resolve("tika-config-timeout.json");
        CXFTestBase.createPluginsConfig(TIKA_CONFIG, inputDir, TEMP_OUTPUT_DIR, null, 5000L);
        CXFTestBase.createPluginsConfig(TIKA_CONFIG_TIMEOUT, inputDir, TEMP_OUTPUT_DIR, null, 500L);

    }

    @AfterEach
    public void tear() throws Exception {
        Thread.sleep(500);
    }

    @BeforeEach
    public void setUpEachTest() throws Exception {

        for (String problemFile : FILES) {
            Path targ = TEMP_OUTPUT_DIR.resolve(problemFile + ".json");

            if (Files.exists(targ)) {
                Files.delete(targ);
                assertFalse(Files.isRegularFile(targ));
            }
        }
    }

    @Test
    public void testBasic() throws Exception {
        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOne("hello_world.xml", true);
        assertEquals("EMIT_SUCCESS", node.get("status").asText());

    }

    @Test
    public void testNPEDefault() throws Exception {

        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOne("null_pointer.xml", true);
        assertEquals("EMIT_SUCCESS_PARSE_EXCEPTION", node.get("status").asText());
        assertContains("java.lang.NullPointerException", node.get("message").asText());
    }

    @Test
    public void testNPESkip() throws Exception {

        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOne("null_pointer.xml", false, FetchEmitTuple.ON_PARSE_EXCEPTION.SKIP);
        assertEquals("PARSE_EXCEPTION_NO_EMIT", node.get("status").asText());
        assertContains("java.lang.NullPointerException", node.get("message").asText());
    }

    @Test
    public void testSystemExit() throws Exception {
        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOne("system_exit.xml", false, FetchEmitTuple.ON_PARSE_EXCEPTION.EMIT, 503);
        assertEquals("UNSPECIFIED_CRASH", node.get("status").asText());
    }

    @Test
    public void testOOM() throws Exception {

        try {
            startProcess(new String[]{
                    "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                    .toAbsolutePath()
                    .toString())});
            JsonNode node = testOne("fake_oom.xml", false, FetchEmitTuple.ON_PARSE_EXCEPTION.EMIT, 503);
            assertEquals("OOM", node.get("status").asText());
        } catch (ProcessingException e) {
            //depending on timing, there may be a connection exception --
            // TODO add more of a delay to server shutdown to ensure message is sent
            // before shutdown.
        }
    }

    @Test
    public void testTimeout() throws Exception {
        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG_TIMEOUT
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOne("heavy_hang_30000.xml", false, FetchEmitTuple.ON_PARSE_EXCEPTION.EMIT, 503);
        assertEquals("TIMEOUT", node.get("status").asText());
    }

    @Test
    public void testPerRequestTimeout() throws Exception {
        // Start server with 5000ms timeout (TIKA_CONFIG)
        // but send a request with 100ms per-request timeout
        // This should timeout after 100ms, not 5000ms
        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        JsonNode node = testOneWithPerRequestTimeout("heavy_hang_30000.xml", 100, 503);
        assertEquals("TIMEOUT", node.get("status").asText());
    }

    private JsonNode testOneWithPerRequestTimeout(String fileName, long timeoutMillis, int expectedStatus) throws Exception {
        awaitServerStartup();
        Response response = WebClient
                .create(endPoint + "/pipes")
                .accept("application/json")
                .post(getJsonStringWithTimeout(fileName, timeoutMillis));
        assertEquals(expectedStatus, response.getStatus());
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        return new ObjectMapper().readTree(reader);
    }

    private String getJsonStringWithTimeout(String fileName, long timeoutMillis) throws IOException {
        ParseContext parseContext = new ParseContext();
        parseContext.set(ContentHandlerFactory.class,
                new BasicContentHandlerFactory(BasicContentHandlerFactory.HANDLER_TYPE.XML, -1));
        parseContext.set(ParseMode.class, ParseMode.RMETA);
        parseContext.setJsonConfig("timeout-limits", "{\"progressTimeoutMillis\":" + timeoutMillis + "}");

        FetchEmitTuple t = new FetchEmitTuple(fileName,
                new FetchKey(CXFTestBase.FETCHER_ID, fileName),
                new EmitKey(CXFTestBase.EMITTER_JSON_ID, ""),
                new Metadata(),
                parseContext,
                FetchEmitTuple.ON_PARSE_EXCEPTION.EMIT);
        return JsonFetchEmitTuple.toJson(t);
    }

    private JsonNode testOne(String fileName, boolean shouldFileExist) throws Exception {
        return testOne(fileName, shouldFileExist, FetchEmitTuple.ON_PARSE_EXCEPTION.EMIT, 200);
    }

    private JsonNode testOne(String fileName, boolean shouldFileExist, FetchEmitTuple.ON_PARSE_EXCEPTION onParseException) throws Exception {
        return testOne(fileName, shouldFileExist, onParseException, 200);
    }

    private JsonNode testOne(String fileName, boolean shouldFileExist,
                              FetchEmitTuple.ON_PARSE_EXCEPTION onParseException, int expectedStatus) throws Exception {

        awaitServerStartup();
        Response response = WebClient
                .create(endPoint + "/pipes")
                .accept("application/json")
                .post(getJsonString(fileName, onParseException));
        assertEquals(expectedStatus, response.getStatus());
        Path targFile = TEMP_OUTPUT_DIR.resolve(fileName + ".json");
        if (shouldFileExist) {
            assertTrue(Files.size(targFile) > 1);
        } else {
            assertFalse(Files.isRegularFile(targFile));
        }
        Reader reader = new InputStreamReader((InputStream) response.getEntity(), UTF_8);
        return new ObjectMapper().readTree(reader);
    }

    @Test
    public void testPipesRejectsParserInjection() throws Exception {
        startProcess(new String[]{
                "-config", ProcessUtils.escapeCommandLine(TIKA_CONFIG
                .toAbsolutePath()
                .toString())});
        awaitServerStartup();
        // A request whose parseContext binds a wire-blocked component must be refused at
        // deserialization, before any fork/parse -- so the request fails and nothing is emitted.
        String requestJson = "{\"id\":\"hello_world.xml\"," +
                "\"fetcher\":\"" + CXFTestBase.FETCHER_ID + "\"," +
                "\"fetchKey\":\"hello_world.xml\"," +
                "\"emitter\":\"" + CXFTestBase.EMITTER_JSON_ID + "\"," +
                "\"emitKey\":\"\"," +
                "\"onParseException\":\"emit\"," +
                "\"parse-context\":{\"typed\":{\"external-parser\":{\"config\":{" +
                "\"commandLine\":[\"/bin/sh\",\"-c\",\"echo x\"]," +
                "\"supportedTypes\":[\"text/plain\"]}}}}}";
        Response response = WebClient
                .create(endPoint + "/pipes")
                .accept("application/json")
                .post(requestJson);
        assertTrue(response.getStatus() != 200,
                "parser injection must be rejected, got HTTP " + response.getStatus());
        assertFalse(Files.isRegularFile(TEMP_OUTPUT_DIR.resolve("hello_world.xml.json")),
                "nothing should be emitted for a rejected request");
    }

    private String getJsonString(String fileName, FetchEmitTuple.ON_PARSE_EXCEPTION onParseException) throws IOException {
        ParseContext parseContext = new ParseContext();
        parseContext.set(ContentHandlerFactory.class,
                new BasicContentHandlerFactory(BasicContentHandlerFactory.HANDLER_TYPE.XML, -1));
        parseContext.set(ParseMode.class, ParseMode.RMETA);
        FetchEmitTuple t = new FetchEmitTuple(fileName, new FetchKey(CXFTestBase.FETCHER_ID, fileName),
                new EmitKey(CXFTestBase.EMITTER_JSON_ID, ""), new Metadata(), parseContext, onParseException);
        return JsonFetchEmitTuple.toJson(t);
    }
}
