import { truncateCenter } from '@/lib/experiments/chart';

type Props = {
  x?: number;
  y?: number;
  payload?: { value?: string };
  textAnchor?: 'end' | 'inherit' | 'middle' | 'start';
};

/**
 * Recharts YAxis tick that renders category labels with a center ellipsis for
 * long values. The full label is exposed via a native `<title>` tooltip so it
 * remains accessible.
 */
export function AxisTick({ x = 0, y = 0, payload, textAnchor = 'end' }: Props) {
  const full = payload?.value ?? '';
  const display = truncateCenter(full);
  return (
    <g transform={`translate(${x},${y})`}>
      <text dy={4} textAnchor={textAnchor} fontSize={12} className="fill-muted">
        <title>{full}</title>
        {display}
      </text>
    </g>
  );
}
