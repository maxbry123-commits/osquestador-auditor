import { useMemo } from 'react';
import type { RangeChangeProps } from '@inngest/components/DatePicker/RangePicker';
import { Error } from '@inngest/components/Error/Error';
import EntityFilter from '@inngest/components/Filter/EntityFilter';
import { TimeFilter } from '@inngest/components/Filter/TimeFilter';
import { Skeleton } from '@inngest/components/Skeleton/Skeleton';
import { InsightsIcon } from '@inngest/components/icons/sections/Insights';
import { resolveColor } from '@inngest/components/utils/colors';
import { isDark } from '@inngest/components/utils/theme';
import {
  useBatchedSearchParams,
  useSearchParam,
  useStringArraySearchParam,
} from '@inngest/components/hooks/useSearchParams';
import {
  durationToString,
  parseDuration,
  subtractDuration,
  toDate,
} from '@inngest/components/utils/date';
import { useRouterState } from '@tanstack/react-router';
import { useQuery } from 'urql';

import { useEnvironment } from '@/components/Environments/environment-context';
import { lineColors } from '@/components/Metrics/utils';
import { graphql } from '@/gql';
import { GetAccountEntitlementsDocument, ScoreKind } from '@/gql/graphql';
import { Legend } from './Legend';
import { ScoreCard } from './ScoreCard';
import { ScoresEmptyState } from './ScoresEmptyState';
import { ScoreNamesDocument, ScoreTimeSeriesDocument } from './queries';
import type { ScoreSeries } from './types';
import { getScoreColors } from './colors';

const DEFAULT_DURATION = { hours: 24 };
const SCORES_PANEL = 'Scores';

const ScoresLookupDocument = graphql(`
  query ScoresLookup($envSlug: String!, $page: Int, $pageSize: Int) {
    envBySlug(slug: $envSlug) {
      workflows @paginated(perPage: $pageSize, page: $page) {
        data {
          name
          id
          slug
        }
      }
    }
  }
`);


export const ScoresDashboard = ({ envSlug }: { envSlug: string }) => {
  const environment = useEnvironment();
  const workspaceID = environment.id;

  const [selectedFns, setFns, removeFns] = useStringArraySearchParam('fns');
  const [disabledParam, setDisabled, removeDisabled] =
    useStringArraySearchParam('disabled');
  const [start] = useSearchParam('start');
  const [end] = useSearchParam('end');
  const [duration] = useSearchParam('duration');
  const batchUpdate = useBatchedSearchParams();

  const parsedDuration = duration ? parseDuration(duration) : '';
  const parsedStart = toDate(start);
  const parsedEnd = toDate(end);

  // `loadedAt` bumps on router.invalidate(), so RefreshButton refires queries.
  const loadedAt = useRouterState({ select: (s) => s.loadedAt });

  // Stabilize range against the raw URL params so a fresh `now` doesn't
  // refire queries on every render.
  const range = useMemo(() => {
    if (parsedStart && parsedEnd) {
      return { from: parsedStart, to: parsedEnd };
    }
    const to = new Date();
    const dur = parsedDuration || DEFAULT_DURATION;
    return { from: subtractDuration(to, dur), to };
  }, [start, end, duration, loadedAt]);

  const timeRange = useMemo(
    () => ({ from: range.from.toISOString(), to: range.to.toISOString() }),
    [range],
  );

  const [{ data: lookupData, fetching: lookupFetching, error: lookupError }] =
    useQuery({
      query: ScoresLookupDocument,
      variables: { envSlug, page: 1, pageSize: 1000 },
    });

  const [{ data: accountData }] = useQuery({
    query: GetAccountEntitlementsDocument,
  });
  const daysAgoMax = accountData?.account.entitlements.history.limit ?? 7;

  const functions = lookupData?.envBySlug?.workflows.data ?? [];

  const [{ data: namesData, fetching: namesFetching, error: namesError }] =
    useQuery({
      query: ScoreNamesDocument,
      variables: {
        workspaceID,
        functionIDs: selectedFns,
        filter: { timeRange },
      },
    });

  const { availableScores, disabled, visibleScores, enabledNames } =
    useMemo(() => {
      const availableScores = namesData?.scoreNames ?? [];
      const disabled = new Set(disabledParam ?? []);
      const visibleScores = availableScores.filter(
        (s) => !disabled.has(s.name),
      );
      return {
        availableScores,
        disabled,
        visibleScores,
        enabledNames: visibleScores.map((s) => s.name),
      };
    }, [namesData, disabledParam]);

  const toggleScore = (key: string) => {
    const current = disabledParam ?? [];
    const next = disabled.has(key)
      ? current.filter((k) => k !== key)
      : [...current, key];
    next.length ? setDisabled(next) : removeDisabled();
  };

  const scoreColors = useMemo(
    () => getScoreColors(availableScores),
    [availableScores],
  );

  const [{ data: seriesData, fetching: seriesFetching, error: seriesError }] =
    useQuery({
      query: ScoreTimeSeriesDocument,
      variables: {
        workspaceID,
        functionIDs: selectedFns,
        filter: { timeRange },
        scoreNames: enabledNames,
      },
      pause: enabledNames.length === 0,
    });

  const seriesByName = useMemo(() => {
    const m = new Map<string, ScoreSeries>();
    for (const s of seriesData?.scoreTimeSeries ?? []) {
      m.set(s.scoreName, s);
    }
    return m;
  }, [seriesData]);

  // Toggle tint: numeric scores match their per-score line color; boolean
  // scores use the same green as their `true` bars (lineColors[1]) so every
  // boolean follows the shared green/red pattern. `kind` comes from the score
  // names query so the correct color is known on first paint (no flip once the
  // time series loads).
  const toggleColors = useMemo(() => {
    const dark = isDark();
    const booleanGreen = resolveColor(lineColors[1][0], dark, lineColors[1][1]);
    const m = new Map<string, string>();
    for (const s of availableScores) {
      const isBoolean = s.kind === ScoreKind.Boolean;
      m.set(
        s.name,
        isBoolean ? booleanGreen : scoreColors.get(s.name) ?? booleanGreen,
      );
    }
    return m;
  }, [availableScores, scoreColors]);

  const defaultRange =
    parsedStart && parsedEnd
      ? {
          type: 'absolute' as const,
          start: parsedStart,
          end: parsedEnd,
        }
      : {
          type: 'relative' as const,
          duration: parsedDuration || DEFAULT_DURATION,
        };

  const isLoading = namesFetching || seriesFetching;

  const filterError = lookupError ?? namesError;

  // Show the onboarding empty state only for a true first-run view: no scores
  // exist AND the user hasn't narrowed the view. When they're actively
  // filtering (function or custom time range) and get zero, the inline "No
  // scores…" message below covers it instead.
  const isDefaultView =
    (selectedFns?.length ?? 0) === 0 && !start && !end && !duration;
  const showEmptyState =
    isDefaultView && availableScores.length === 0 && !isLoading && !namesError;

  if (showEmptyState) {
    return <ScoresEmptyState />;
  }

  return (
    <div className="flex min-h-0 w-full flex-1 flex-row overflow-hidden">
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="bg-canvasBase flex flex-row items-center gap-1.5 px-3 py-[9px]">
          <TimeFilter
            daysAgoMax={daysAgoMax}
            defaultValue={defaultRange}
            onDaysChange={(r: RangeChangeProps) => {
              batchUpdate({
                duration:
                  r.type === 'relative' ? durationToString(r.duration) : null,
                start: r.type === 'absolute' ? r.start.toISOString() : null,
                end: r.type === 'absolute' ? r.end.toISOString() : null,
              });
            }}
          />
          {lookupFetching ? (
            <Skeleton className="block h-6 w-60" />
          ) : (
            <EntityFilter
              type="function"
              onFilterChange={(fns) => (fns.length ? setFns(fns) : removeFns())}
              selectedEntities={selectedFns || []}
              entities={functions}
            />
          )}
        </div>
        {filterError && (
          <Error message="There was an error fetching scores filter data." />
        )}
        <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-3 pb-6 [&::-webkit-scrollbar]:hidden">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {visibleScores.length === 0 && !isLoading && !namesError ? (
              <div className="text-muted col-span-full py-10 text-center text-sm">
                {availableScores.length === 0
                  ? 'No scores recorded in this range.'
                  : 'No scores selected.'}
              </div>
            ) : (
              visibleScores.map((s) => (
                <ScoreCard
                  key={s.name}
                  name={s.name}
                  series={seriesByName.get(s.name)}
                  color={scoreColors.get(s.name)}
                  isLoading={seriesFetching}
                  error={seriesError}
                />
              ))
            )}
          </div>
        </div>
      </div>
      {!filterError && (
        <aside className="border-subtle flex w-[300px] shrink-0 flex-col overflow-hidden border-l">
          <div className="border-subtle flex h-[49px] shrink-0 flex-row items-center gap-2 border-b px-3">
            <InsightsIcon className="h-5 w-5" />
            <div className="text-sm font-normal">{SCORES_PANEL}</div>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            <Legend
              scores={availableScores}
              disabled={disabled}
              colors={toggleColors}
              onToggle={toggleScore}
              isLoading={namesFetching}
            />
          </div>
        </aside>
      )}
    </div>
  );
};
