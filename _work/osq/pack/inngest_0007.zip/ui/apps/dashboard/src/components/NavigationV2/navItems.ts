import type { ComponentType } from 'react';
import { AIOverviewIcon } from '@inngest/components/icons/sections/AIOverview';
import { AppsIcon } from '@inngest/components/icons/sections/Apps';
import { EventLogsIcon } from '@inngest/components/icons/sections/EventLogs';
import { EventsIcon } from '@inngest/components/icons/sections/Events';
import { ExperimentsIcon } from '@inngest/components/icons/sections/Experiments';
import { FunctionsIcon } from '@inngest/components/icons/sections/Functions';
import { InsightsIcon } from '@inngest/components/icons/sections/Insights';
import { MetricsIcon } from '@inngest/components/icons/sections/Metrics';
import { OverviewIcon } from '@inngest/components/icons/sections/Overview';
import { RunsIcon } from '@inngest/components/icons/sections/Runs';
import { SandboxesIcon } from '@inngest/components/icons/sections/Sandboxes';
import { ScoresIcon } from '@inngest/components/icons/sections/Scores';
import { SessionsIcon } from '@inngest/components/icons/sections/Sessions';
import { WebhooksIcon } from '@inngest/components/icons/sections/Webhooks';

export type NavItemConfig = {
  label: string;
  // Relative path passed to getNavRoute (env slug is prepended there).
  route: string;
  Icon: ComponentType<{ className?: string }>;
  beta?: boolean;
  exact?: boolean;
};

export type NavGroupConfig = {
  heading: string;
  items: NavItemConfig[];
  beta?: boolean;
};

export const workflow: NavGroupConfig = {
  heading: 'Workflow',
  items: [
    { label: 'Overview', route: '', Icon: OverviewIcon, exact: true },
    { label: 'Apps', route: 'apps', Icon: AppsIcon },
    { label: 'Functions', route: 'functions', Icon: FunctionsIcon },
    { label: 'Runs', route: 'runs', Icon: RunsIcon },
    { label: 'Event Types', route: 'event-types', Icon: EventsIcon },
    { label: 'Events', route: 'events', Icon: EventLogsIcon },
    { label: 'Sessions', route: 'sessions', Icon: SessionsIcon, beta: true },
  ],
};

export const monitor: NavGroupConfig = {
  heading: 'Monitor',
  items: [
    { label: 'Metrics', route: 'metrics', Icon: MetricsIcon },
    { label: 'Insights', route: 'insights', Icon: InsightsIcon },
  ],
};

export const experimentsItem: NavItemConfig = {
  label: 'Experiments',
  route: 'experiments',
  Icon: ExperimentsIcon,
};

export const scoresItem: NavItemConfig = {
  label: 'Scores',
  route: 'scores',
  Icon: ScoresIcon,
};

export const aiOverviewItem: NavItemConfig = {
  label: 'AI Overview',
  route: 'ai-overview',
  Icon: AIOverviewIcon,
};

export const sandboxesItem: NavItemConfig = {
  label: 'Sandboxes',
  route: 'sandboxes',
  Icon: SandboxesIcon,
};

export const manage: NavGroupConfig = {
  heading: 'Manage',
  items: [{ label: 'Webhooks', route: 'manage/webhooks', Icon: WebhooksIcon }],
};
