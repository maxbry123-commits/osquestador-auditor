local keyCapacity = KEYS[1]
local keyIdempotency = KEYS[2]
local capacity = ARGV[1]
local idempotencyTTL = tonumber(ARGV[2])
local existing = redis.call("GET", keyIdempotency)
if existing ~= nil and existing ~= false then
	return {tonumber(existing), 0}
end
redis.call("SET", keyCapacity, capacity)
redis.call("SET", keyIdempotency, capacity, "EX", tostring(idempotencyTTL))
return {tonumber(capacity), 1}