local cjson = cjson
local function call(command, ...)
	return redis.call(command, ...)
end
local KEYS = KEYS
local ARGV = ARGV
local keyRequestState = KEYS[1]
local keyOperationIdempotency = KEYS[2]
local keyConstraintCheckIdempotency = KEYS[3]
local keyScavengerShard = KEYS[4]
local keyAccountLeases = KEYS[5]
local requestDetails = cjson.decode(ARGV[1])
local requestID = ARGV[2]
local accountID = ARGV[3]
local nowMS = tonumber(ARGV[4]) 
local nowNS = tonumber(ARGV[5]) 
local leaseExpiryMS = tonumber(ARGV[6])
local scopedKeyPrefix = ARGV[7]
local initialLeaseIDs = cjson.decode(ARGV[8])
if not initialLeaseIDs then
	return redis.error_reply("ERR initialLeaseIDs is nil after JSON decode")
end
local operationIdempotencyTTL = tonumber(ARGV[9])
local constraintCheckIdempotencyTTL = tonumber(ARGV[10])
local enableDebugLogs = tonumber(ARGV[11]) == 1
local cacheMinTTL = tonumber(ARGV[12]) or 0
local cacheMaxTTL = tonumber(ARGV[13]) or 0
local cacheKeyOffset = 14
if not requestDetails.lik then
	return redis.error_reply("ERR requestDetails.lik is nil during update")
end
if not initialLeaseIDs then
	return redis.error_reply("ERR initialLeaseIDs is nil during update")
end
local debugLogs = {}
local function debug(...)
	if enableDebugLogs then
		local args = { ... }
		table.insert(debugLogs, table.concat(args, " "))
	end
end
local function getConcurrencyCount(key)
	local count = call("ZCOUNT", key, tostring(nowMS), "+inf")
	if count == nil then
		return 0
	end
	return count
end
local function toInteger(value)
	return math.floor(value + 0.5) 
end
local function addConstraintUsage(target, index, limit, used)
	local usage = {}
	usage["i"] = index
	usage["l"] = toInteger(limit or 0)
	usage["u"] = toInteger(math.max(used or 0, 0))
	table.insert(target, usage)
end
local function rateLimit(key, now_ns, period_ns, limit, burst, quantity)
	limit = math.max(limit, 1)
	local result = {}
	result["remaining"] = 0
	result["limit"] = burst + 1
	local emission = period_ns / limit
	result["ei"] = emission
	result["retry_at"] = now_ns + emission
	local dvt = emission * (burst + 1)
	result["dvt"] = dvt
	local tat = redis.call("GET", key)
	if not tat then
		tat = now_ns
	else
		tat = tonumber(tat)
	end
	result["tat"] = tat
	local origQuantity = quantity
	if quantity == 0 then
		quantity = 1
	end
	local increment = quantity * emission
	result["inc"] = increment
	local new_tat = tat + increment
	if now_ns > tat then
		new_tat = now_ns + increment
	end
	result["ntat"] = new_tat
	local ttl = tat - now_ns
	result["reset_after"] = ttl
	local used_tokens = math.min(math.ceil(ttl / emission), limit)
	result["u"] = used_tokens
	local allow_at = new_tat - dvt
	result["aat"] = allow_at
	local diff = now_ns - allow_at
	result["diff"] = diff
	if diff < 0 then
		if increment <= dvt then
			result["retry_after"] = -diff
			result["retry_at"] = now_ns - diff
		end
		if origQuantity > 0 then
			local next = dvt - ttl
			result["next"] = next
			result["remaining"] = 0
			result["limited"] = true
			return result
		end
	end
	if origQuantity > 0 then
		ttl = new_tat - now_ns
		result["reset_after"] = ttl
		used_tokens = math.min(math.ceil(ttl / emission), limit)
		result["u"] = used_tokens
		local expiry = string.format("%d", math.max(ttl / 1000000000, 1))
		redis.call("SET", key, new_tat, "EX", expiry)
	end
	local next = dvt - ttl
	result["next"] = next
	if next > -emission then
		local remaining = math.floor(next / emission)
		result["remaining"] = remaining
	end
	return result
end
local function throttle(key, now_ms, period_ms, limit, burst, quantity)
	limit = math.max(limit, 1)
	local result = {}
	result["remaining"] = 0
	result["limit"] = burst + 1
	local emission = period_ms / limit
	result["ei"] = emission
	result["retry_at"] = now_ms + emission
	local dvt = emission * (burst + 1)
	result["dvt"] = dvt
	local tat = redis.call("GET", key)
	if not tat then
		tat = now_ms
	else
		tat = tonumber(tat)
	end
	result["tat"] = tat
	local origQuantity = quantity
	if quantity == 0 then
		quantity = 1
	end
	local increment = quantity * emission
	result["inc"] = increment
	local new_tat = tat + increment
	if now_ms > tat then
		new_tat = now_ms + increment
	end
	result["ntat"] = new_tat
	local ttl = tat - now_ms
	result["reset_after"] = ttl
	local used_tokens = math.min(math.ceil(ttl / emission), limit)
	result["u"] = used_tokens
	local allow_at = new_tat - dvt
	result["aat"] = allow_at
	local diff = now_ms - allow_at
	result["diff"] = diff
	if diff < 0 then
		if increment <= dvt then
			result["retry_after"] = -diff
			result["retry_at"] = now_ms - diff
		end
		if origQuantity > 0 then
			local next = dvt - ttl
			result["next"] = next
			result["remaining"] = 0
			result["limited"] = true
			return result
		end
	end
	if origQuantity > 0 then
		ttl = new_tat - now_ms
		result["reset_after"] = ttl
		used_tokens = math.min(math.ceil(ttl / emission), limit)
		result["u"] = used_tokens
		local expiry = string.format("%d", math.max(ttl / 1000, 1))
		redis.call("SET", key, new_tat, "EX", expiry)
	end
	local next = dvt - ttl
	result["next"] = next
	if next > -emission then
		local remaining = math.floor(next / emission)
		result["remaining"] = remaining
	end
	return result
end
local requested = requestDetails.r
local configVersion = requestDetails.cv
local constraints = requestDetails.s
if not constraints then
	return redis.error_reply("ERR constraints array is nil")
end
local results = call("MGET", keyOperationIdempotency, keyRequestState)
local opIdempotency = results[1]
local existingRequestState = results[2]
if opIdempotency ~= nil and opIdempotency ~= false then
	return { 1, opIdempotency }
end
if existingRequestState ~= nil and existingRequestState ~= false and existingRequestState ~= "" then
	local res = {}
	res["s"] = 4
	res["d"] = debugLogs
	return { 0, cjson.encode(res) }
end
local availableCapacity = requested
local limitingConstraints = {}
local exhaustedConstraints = {}
local exhaustedSet = {}
local retryAt = 0
local concurrencyUsageCache = {}
local constraintUsage = {}
local skipGCRA = call("EXISTS", keyConstraintCheckIdempotency) == 1
local cacheEnabled = cacheMaxTTL > 0
local constraintCacheKeys = {}
local cacheHit = false
if cacheEnabled then
	local mgetKeys = {}
	local mgetIndices = {}
	for i = 1, #constraints do
		local ck = ARGV[cacheKeyOffset + i - 1] or ""
		constraintCacheKeys[i] = ck
		if ck ~= "" then
			table.insert(mgetKeys, ck)
			table.insert(mgetIndices, i)
		end
	end
	if #mgetKeys > 0 then
		local cacheValues = call("MGET", unpack(mgetKeys))
		for j, val in ipairs(cacheValues) do
			if val ~= nil and val ~= false then
				cacheHit = true
				local idx = mgetIndices[j]
				local cachedRetryAt = tonumber(val) or 0
				if not exhaustedSet[idx] then
					table.insert(exhaustedConstraints, idx)
					exhaustedSet[idx] = true
				end
				table.insert(limitingConstraints, idx)
				if cachedRetryAt > retryAt then
					retryAt = cachedRetryAt
				end
				availableCapacity = 0
			end
		end
	end
	if cacheHit then
		local res = {}
		res["s"] = 2
		res["lc"] = limitingConstraints
		res["ec"] = exhaustedConstraints
		res["ra"] = retryAt
		res["d"] = debugLogs
		res["fr"] = 0
		res["ch"] = 1
		return { 0, cjson.encode(res) }
	end
end
for index, value in ipairs(constraints) do
	local constraintCapacity = 0
	local constraintRetryAt = 0
	if skipGCRA and (value.k == 1 or value.k == 3) then
		constraintCapacity = math.max(availableCapacity, 1)
	elseif value.k == 1 then
		local rlRes = rateLimit(value.r.k, nowNS, value.r.p, value.r.l, value.r.b, 0)
		constraintCapacity = rlRes["remaining"] or 0
		constraintRetryAt = toInteger(rlRes["retry_at"] / 1000000) 
		addConstraintUsage(constraintUsage, index, value.r.l, rlRes["u"])
	elseif value.k == 2 then
		local inProgressLeases = getConcurrencyCount(value.c.ilk)
		constraintCapacity = value.c.l - inProgressLeases
		constraintRetryAt = toInteger(nowMS + value.c.ra)
		addConstraintUsage(constraintUsage, index, value.c.l, inProgressLeases)
		concurrencyUsageCache[index] = inProgressLeases
	elseif value.k == 3 then
		local maxBurst = (value.t.l or 0) + (value.t.b or 0) - 1
		local throttleRes = throttle(value.t.k, nowMS, value.t.p, value.t.l, maxBurst, 0)
		constraintCapacity = throttleRes["remaining"] or 0
		constraintRetryAt = toInteger(throttleRes["retry_at"]) 
		addConstraintUsage(constraintUsage, index, value.t.l, throttleRes["u"])
	elseif value.k == 4 then
		local usage = tonumber(call("GET", value.sem.k)) or 0
		local capacity = tonumber(call("GET", value.sem.ck)) or 0
		local weight = toInteger(value.sem.w)
		if not weight or weight <= 0 then
			weight = 1
		end
		local remaining = capacity - usage
		if remaining < weight then
			constraintCapacity = 0
		else
			constraintCapacity = math.floor(remaining / weight)
		end
		addConstraintUsage(constraintUsage, index, capacity, usage)
	end
	if constraintCapacity <= 0 then
		if not exhaustedSet[index] then
			table.insert(exhaustedConstraints, index)
			exhaustedSet[index] = true
		end
		if constraintRetryAt > retryAt then
			retryAt = constraintRetryAt
		end
		if cacheEnabled then
			local ck = constraintCacheKeys[index]
			if ck ~= nil and ck ~= "" and constraintRetryAt > nowMS then
				local cacheTTLSec =
					math.max(math.min(math.ceil((constraintRetryAt - nowMS) / 1000), cacheMaxTTL), cacheMinTTL)
				if cacheTTLSec > 0 then
					call("SET", ck, tostring(constraintRetryAt), "EX", tostring(cacheTTLSec))
				end
			end
		end
	end
	if constraintCapacity < availableCapacity then
		availableCapacity = constraintCapacity
		table.insert(limitingConstraints, index)
	end
end
local fairnessReduction = 0
availableCapacity = availableCapacity - fairnessReduction
if availableCapacity <= 0 then
	local res = {}
	res["s"] = 2
	res["lc"] = limitingConstraints
	res["ec"] = exhaustedConstraints
	res["ra"] = retryAt
	res["d"] = debugLogs
	res["fr"] = fairnessReduction
	res["ch"] = 0
	res["cu"] = constraintUsage
	return { 0, cjson.encode(res) }
end
local granted = availableCapacity
local grantedLeases = {}
local accountLeasesArgs = {}
local keyPrefixLeaseDetails = scopedKeyPrefix .. ":ld:"
local keyPrefixConstraintCheck = scopedKeyPrefix .. ":ik:cc:"
retryAt = 0
constraintUsage = {}
for i, value in ipairs(constraints) do
	local constraintRetryAt = 0
	local constraintCapacity = 0
	if skipGCRA and (value.k == 1 or value.k == 3) then
		constraintCapacity = 1
	elseif value.k == 1 then
		local rlRes = rateLimit(value.r.k, nowNS, value.r.p, value.r.l, value.r.b, granted)
		constraintRetryAt = toInteger(rlRes["retry_at"] / 1000000)
		constraintCapacity = rlRes["remaining"] or 0
		addConstraintUsage(constraintUsage, i, value.r.l, rlRes["u"])
	elseif value.k == 2 then
		local updates = {}
		for j = 1, granted, 1 do
			local initialLeaseID = initialLeaseIDs[j]
			updates[(j - 1) * 2 + 1] = tostring(leaseExpiryMS)
			updates[(j - 1) * 2 + 2] = initialLeaseID
		end
		call("ZADD", value.c.ilk, unpack(updates))
		local inProgressLeases = (concurrencyUsageCache[i] or 0) + granted
		constraintCapacity = value.c.l - inProgressLeases
		constraintRetryAt = toInteger(nowMS + value.c.ra)
		addConstraintUsage(constraintUsage, i, value.c.l, inProgressLeases)
	elseif value.k == 3 then
		local maxBurst = (value.t.l or 0) + (value.t.b or 0) - 1
		local throttleRes = throttle(value.t.k, nowMS, value.t.p, value.t.l, maxBurst, granted)
		constraintRetryAt = toInteger(throttleRes["retry_at"])
		constraintCapacity = throttleRes["remaining"] or 0
		addConstraintUsage(constraintUsage, i, value.t.l, throttleRes["u"])
	elseif value.k == 4 then
		local weight = value.sem.w
		if not weight or weight <= 0 then
			weight = 1
		end
		local newUsage = call("INCRBY", value.sem.k, toInteger(weight * granted))
		local capacity = tonumber(call("GET", value.sem.ck)) or 0
		local remaining = capacity - newUsage
		if remaining < weight then
			constraintCapacity = 0
		else
			constraintCapacity = math.floor(remaining / weight)
		end
		addConstraintUsage(constraintUsage, i, capacity, newUsage)
	end
	if constraintCapacity <= 0 then
		if not exhaustedSet[i] then
			exhaustedSet[i] = true
			table.insert(exhaustedConstraints, i)
		end
		if constraintRetryAt > retryAt then
			retryAt = constraintRetryAt
		end
		if cacheEnabled then
			local ck = constraintCacheKeys[i]
			if ck ~= nil and ck ~= "" and constraintRetryAt > nowMS then
				local cacheTTLSec =
					math.max(math.min(math.ceil((constraintRetryAt - nowMS) / 1000), cacheMaxTTL), cacheMinTTL)
				if cacheTTLSec > 0 then
					call("SET", ck, tostring(constraintRetryAt), "EX", tostring(cacheTTLSec))
				end
			end
		end
	end
end
for i = 1, granted, 1 do
	local hashedLeaseIdempotencyKey = requestDetails.lik[i]
	local leaseRunID = (requestDetails.lri ~= nil and requestDetails.lri[hashedLeaseIdempotencyKey]) or ""
	local initialLeaseID = initialLeaseIDs[i]
	local keyLeaseDetails = keyPrefixLeaseDetails .. initialLeaseID
	call("HSET", keyLeaseDetails, "lik", hashedLeaseIdempotencyKey, "rid", leaseRunID, "req", requestID)
	accountLeasesArgs[(i - 1) * 2 + 1] = tostring(leaseExpiryMS)
	accountLeasesArgs[(i - 1) * 2 + 2] = initialLeaseID
	local keyLeaseConstraintCheckIdempotency = keyPrefixConstraintCheck .. hashedLeaseIdempotencyKey
	call("SET", keyLeaseConstraintCheckIdempotency, tostring(nowMS), "EX", tostring(constraintCheckIdempotencyTTL))
	local leaseObject = {}
	leaseObject["lid"] = initialLeaseID
	leaseObject["lik"] = hashedLeaseIdempotencyKey
	grantedLeases[i] = leaseObject
end
if #accountLeasesArgs > 0 then
	call("ZADD", keyAccountLeases, unpack(accountLeasesArgs))
end
call("SET", keyConstraintCheckIdempotency, tostring(nowMS), "EX", tostring(constraintCheckIdempotencyTTL))
requestDetails.g = availableCapacity
requestDetails.a = availableCapacity
call("SET", keyRequestState, cjson.encode(requestDetails))
local accountScore = call("ZSCORE", keyScavengerShard, accountID)
if accountScore == nil or accountScore == false or tonumber(accountScore) > leaseExpiryMS then
	call("ZADD", keyScavengerShard, tonumber(leaseExpiryMS), accountID)
end
local result = {}
result["s"] = 3
result["r"] = requested
result["g"] = granted
result["l"] = grantedLeases
result["lc"] = limitingConstraints
result["ec"] = exhaustedConstraints
result["ra"] = retryAt 
result["d"] = debugLogs
result["fr"] = fairnessReduction
result["ch"] = 0
result["cu"] = constraintUsage
local encoded = cjson.encode(result)
call("SET", keyOperationIdempotency, encoded, "EX", tostring(operationIdempotencyTTL))
return { 0, encoded }