/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.kernel.impl.transaction.log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.neo4j.kernel.impl.transaction.CommittedCommandBatchRepresentation;

public class GivenCommandBatchCursor implements CommandBatchCursor {
    private int index = -1;
    private final CommittedCommandBatchRepresentation[] commandBatches;

    private GivenCommandBatchCursor(CommittedCommandBatchRepresentation... commandBatches) {
        this.commandBatches = commandBatches;
    }

    @Override
    public CommittedCommandBatchRepresentation get() {
        return commandBatches[index];
    }

    @Override
    public boolean next() {
        if (index + 1 < commandBatches.length) {
            index++;
            return true;
        }
        return false;
    }

    @Override
    public void close() {}

    @Override
    public LogPosition position() {
        return null;
    }

    public static CommandBatchCursor given(CommittedCommandBatchRepresentation... commandBatches) {
        return new GivenCommandBatchCursor(commandBatches);
    }

    public static CommittedCommandBatchRepresentation[] exhaust(CommandBatchCursor cursor) throws IOException {
        List<CommittedCommandBatchRepresentation> list = new ArrayList<>();
        while (cursor.next()) {
            list.add(cursor.get());
        }
        return list.toArray(new CommittedCommandBatchRepresentation[0]);
    }
}
