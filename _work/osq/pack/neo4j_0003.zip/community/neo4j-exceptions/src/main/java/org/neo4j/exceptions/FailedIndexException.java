/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.exceptions;

import static java.lang.System.lineSeparator;

import org.neo4j.gqlstatus.ErrorGqlStatusObject;
import org.neo4j.gqlstatus.ErrorGqlStatusObjectImplementation;
import org.neo4j.gqlstatus.GqlParams;
import org.neo4j.gqlstatus.GqlStatusInfoCodes;
import org.neo4j.kernel.api.exceptions.Status;

public class FailedIndexException extends Neo4jException {
    private FailedIndexException(ErrorGqlStatusObject gqlStatusObject, String indexName, String failureMessage) {
        super(gqlStatusObject, msg(indexName, failureMessage), null);
    }

    // KNL-041 and KNL-042
    public static FailedIndexException failedIndex(String indexName, String failureMessage) {
        var gql = ErrorGqlStatusObjectImplementation.from(GqlStatusInfoCodes.STATUS_51N62)
                .withParam(GqlParams.StringParam.idx, indexName)
                .build();
        return new FailedIndexException(gql, indexName, failureMessage);
    }

    private static String msg(String indexName, String failureMessage) {
        String actualFailure = failureMessage != null
                ? String.format(
                        " Actual failure:%s==================%s%s%s==================",
                        lineSeparator(), lineSeparator(), failureMessage, lineSeparator())
                : "";
        return String.format(
                "Index `%s` has failed. Drop and recreate it to get it back online.%s", indexName, actualFailure);
    }

    @Override
    public Status status() {
        return Status.General.IndexCorruptionDetected;
    }
}
