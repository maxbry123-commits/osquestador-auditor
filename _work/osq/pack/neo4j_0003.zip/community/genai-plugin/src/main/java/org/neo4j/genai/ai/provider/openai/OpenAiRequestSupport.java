/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.genai.ai.provider.openai;

import static org.neo4j.genai.util.HttpService.jsonBody;

import java.net.URI;
import java.net.http.HttpRequest;
import java.nio.charset.StandardCharsets;
import java.util.function.Function;
import org.neo4j.genai.util.HttpService;

public interface OpenAiRequestSupport {

    URI endpoint();

    HttpService httpService();

    String[] authHeader();

    default HttpRequest.Builder customize(HttpRequest.Builder builder) {
        return builder;
    }

    default <T> T postJson(Object payload, Function<java.io.InputStream, T> transformer) {
        return httpService()
                .request(
                        endpoint(),
                        b -> {
                            var builder = b.headers(
                                            "Content-Type",
                                            "application/json; charset=" + StandardCharsets.UTF_8,
                                            "Accept",
                                            "application/json")
                                    .headers(authHeader())
                                    .POST(jsonBody(payload));
                            return customize(builder).build();
                        },
                        transformer);
    }
}
