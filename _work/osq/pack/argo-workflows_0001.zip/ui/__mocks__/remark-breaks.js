module.exports = function remarkBreaks() {};
