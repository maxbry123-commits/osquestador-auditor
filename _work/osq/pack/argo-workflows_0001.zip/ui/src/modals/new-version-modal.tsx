import * as React from 'react';

import {Modal} from '../shared/components/modal/modal';
import {SurveyButton} from '../shared/components/survey-button';

import './new-version-modal.scss';

/**
 * The intention of this modal is to encourage update of new features.
 */
export function NewVersionModal({version, dismiss}: {version: string; dismiss: () => void}) {
    return (
        <Modal dismiss={dismiss}>
            <div className='new-version-modal-banner'>
                <i className='fa fa-arrow-circle-up' />{' '}
            </div>
            <h4 className='new-version-modal-title'>
                It looks like <b>{version}</b> has just been installed!
            </h4>
            <h5>v4.1</h5>
            <ul className='new-version-modal-bullets'>
                <li>Workflow tracing with OpenTelemetry spans</li>
                <li>Faster pod startup with an opt-in initless pod layout</li>
                <li>Workflow-level executor plugin configuration</li>
                <li>Artifact uploads, faster S3 uploads, and S3 virtual-hosted-style addressing</li>
                <li>Database authentication via AWS RDS IAM and Azure PostgreSQL Entra ID</li>
                <li>
                    Pod-level{' '}
                    <a href='https://kubernetes.io/docs/tasks/configure-pod-container/assign-pod-level-resources/' target='_blank' rel='noreferrer'>
                        resource requests and limits
                    </a>{' '}
                    via <code>podResources</code>
                </li>
            </ul>
            <p>
                <a href='https://argo-workflows.readthedocs.io/en/release-4.1/new-features/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    See the list of changes
                </a>
            </p>
            <h5>v4.0</h5>
            <ul className='new-version-modal-bullets'>
                <li>Artifact drivers as plugins</li>
                <li>CLI improvements — including creating semaphores</li>
                <li>Full CRDs with validation</li>
                <li>Deprecated singular items (mutex, semaphore, schedule).</li>
            </ul>
            <p>
                <a href='https://medium.com/@joibel/argo-workflows-4-0-rc2-70def0d672ef' target='_blank' rel='noreferrer'>
                    Learn more
                </a>{' '}
                or{' '}
                <a href='https://argo-workflows.readthedocs.io/en/release-4.0/new-features/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    See the list of changes
                </a>
            </p>
            <h5>v3.7</h5>
            <ul className='new-version-modal-bullets'>
                <li>Enhanced retry strategies with daemon container support, backoff caps, and retry variables in expressions</li>
                <li>Multi-controller locks (semaphores and mutexes) and dynamic namespace parallelism</li>
                <li>UI improvements: visualize workflows before submitting, markdown support in templates, and pre-filled submit forms</li>
                <li>Cron workflow backfill support and non-root argoexec image for improved security</li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/argo-workflows-3-7-4eb9a2f0f918' target='_blank' rel='noreferrer'>
                    Learn more
                </a>{' '}
                or{' '}
                <a href='https://argo-workflows.readthedocs.io/en/release-3.7/new-features/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    See the list of changes
                </a>
            </p>
            <h5>v3.6</h5>
            <ul className='new-version-modal-bullets'>
                <li>
                    Metrics are available via the{' '}
                    <a href='https://opentelemetry.io/' target='_blank' rel='noreferrer'>
                        OpenTelemetry
                    </a>{' '}
                    protocol, and there are a number of new or changed metrics
                </li>
                <li>
                    <a href='https://argo-workflows.readthedocs.io/en/release-3.6/cron-workflows?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        CronWorkflows
                    </a>{' '}
                    have many more scheduling options including multiple schedules, a <code>when</code> expression, and a <code>stopStrategy</code> expression
                </li>
                <li>OSS artifacts are more versatile, supporting directories, deletion, and streaming</li>
                <li>Many UI updates including execution history of CronWorkflows</li>
                <li>A number of improvements to performance and memory management</li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/argo-workflows-3-6-aa037cd782be' target='_blank' rel='noreferrer'>
                    Learn more
                </a>{' '}
                or{' '}
                <a href='https://argo-workflows.readthedocs.io/en/release-3.6/new-features/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    see the list of changes
                </a>
            </p>
            <h5>v3.5</h5>
            <ul className='new-version-modal-bullets'>
                <li>Removed Archived Workflows page; Workflows List page now shows both</li>
                <li>Improvements to existing UI/UX and CLI</li>
                <li>Additional fields and parameters in workflow/template spec</li>
                <li>Controller performance optimizations</li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/whats-new-in-argo-workflows-v3-5-f260e8603ca6' target='_blank' rel='noreferrer'>
                    Learn more
                </a>
            </p>
            <h5>v3.4</h5>
            <ul className='new-version-modal-bullets'>
                <li>
                    <a href='https://argo-workflows.readthedocs.io/en/latest/artifact-visualization/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        Visualize artifact{' '}
                    </a>
                    in the UI
                </li>
                <li>
                    Automated{' '}
                    <a
                        href='https://argo-workflows.readthedocs.io/en/latest/walk-through/artifacts/#artifact-garbage-collection?utm_source=argo-ui'
                        target='_blank'
                        rel='noreferrer'>
                        artifact garbage collection
                    </a>
                </li>
                <li>
                    Provide{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/intermediate-inputs/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        parameter input{' '}
                    </a>
                    in the middle of the workflow
                </li>
                <li>Filter by date and time in the UI</li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/what-to-expect-in-argo-workflows-v3-4-711702ad88e9?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    Learn more
                </a>
            </p>
            <h5>v3.3</h5>
            <ul className='new-version-modal-bullets'>
                <li>
                    Write your own types of step with{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/plugins/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        plugin templates
                    </a>
                    .
                </li>
                <li>Connect with the workflow using lifecycle hooks.</li>
                <li>Pause steps in your workflow with Debug pause.</li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/whats-new-in-argo-workflows-v3-3-dd051d2f1c7?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    Learn more
                </a>
            </p>
            <h5>v3.2</h5>
            <ul className='new-version-modal-bullets'>
                <li>
                    Writing workflows <b>without YAML</b> using{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/client-libraries/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        Python and Java SDKs
                    </a>
                    .
                </li>
                <li>
                    Visualize and debug{' '}
                    <a href='https://github.com/argoproj-labs/argo-dataflow' target='_blank' rel='noreferrer'>
                        Dataflow pipelines
                    </a>
                    .
                </li>
                <li>
                    Interact with third-party systems using{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/http-template/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        HTTP template
                    </a>
                    .
                </li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/argo-workflows-v3-2-af780a99b362?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    Learn more
                </a>
            </p>
            <h5>v3.1</h5>
            <ul className='new-version-modal-bullets'>
                <li>
                    Run workflows <b>faster and cheaper</b>{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/container-set-template/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        using container set template and Emissary executor
                    </a>
                    .
                </li>
                <li>
                    Run fan-out workflows based on bucket contents using{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/data-sourcing-and-transformation/?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                        data templates
                    </a>
                    .
                </li>
                <li>
                    Complex and dynamic templating using{' '}
                    <a href='https://argo-workflows.readthedocs.io/en/latest/variables/?utm_source=argo-ui#expression' target='_blank' rel='noreferrer'>
                        expression tag templates
                    </a>
                    .
                </li>
            </ul>
            <p>
                <a href='https://blog.argoproj.io/argo-workflows-v3-1-is-coming-1fb1c1091324?utm_source=argo-ui' target='_blank' rel='noreferrer'>
                    Learn more
                </a>
            </p>
            <p className='new-version-modal-footer'>
                <SurveyButton />
            </p>
        </Modal>
    );
}
