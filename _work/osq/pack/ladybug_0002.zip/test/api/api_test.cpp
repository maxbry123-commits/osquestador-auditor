#include <memory>
#include <thread>

#include "main/connection.h"
#include "main/database.h"

#ifdef _WIN32
#include <windows.h>
#endif

#include <fstream>

#include "api_test/api_test.h"
#include "common/exception/io.h"

using namespace lbug::common;
using namespace lbug::main;
using namespace lbug::testing;

static void assertMatchPersonCountStar(Connection* conn) {
    auto result = conn->query("MATCH (a:person) RETURN COUNT(*)");
    ASSERT_TRUE(result->hasNext());
    auto tuple = result->getNext();
    ASSERT_EQ(tuple->getValue(0)->getValue<int64_t>(), 8);
    ASSERT_FALSE(result->hasNext());
}

TEST_F(ApiTest, BasicConnect) {
    assertMatchPersonCountStar(conn.get());
}

#ifndef __SINGLE_THREADED__
// The following two tests are disabled in single-threaded mode because they
// require multiple threads to run.
static void parallel_query(Connection* conn) {
    for (auto i = 0u; i < 100; ++i) {
        assertMatchPersonCountStar(conn);
    }
}

TEST_F(ApiTest, ParallelQuerySingleConnect) {
    const auto numThreads = 20u;
    std::thread threads[numThreads];
    for (auto i = 0u; i < numThreads; ++i) {
        threads[i] = std::thread(parallel_query, conn.get());
    }
    for (auto i = 0u; i < numThreads; ++i) {
        threads[i].join();
    }
}

static void parallel_connect(Database* database) {
    auto conn = std::make_unique<Connection>(database);
    assertMatchPersonCountStar(conn.get());
}

TEST_F(ApiTest, ParallelConnect) {
    const auto numThreads = 5u;
    std::thread threads[numThreads];
    for (auto i = 0u; i < numThreads; ++i) {
        threads[i] = std::thread(parallel_connect, database.get());
    }
    for (auto i = 0u; i < numThreads; ++i) {
        threads[i].join();
    }
}

static void executeLongRunningQuery(Connection* conn) {
    auto result = conn->query(
        "UNWIND RANGE(1,100000) AS x UNWIND RANGE(1, 100000) AS y RETURN COUNT(x + y);");
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->getErrorMessage(), "Interrupted.");
}

TEST_F(ApiTest, Interrupt) {
    std::thread longRunningQueryThread(executeLongRunningQuery, conn.get());
    std::atomic<bool> finished_executing{false};
    std::thread interruptingThread([&]() {
        while (!finished_executing) {
#ifdef _WIN32
            Sleep(1000);
#else
            sleep(1 /* sleep 1 second before interrupt the query */);
#endif
            conn->interrupt();
        }
    });
    longRunningQueryThread.join();
    finished_executing = true;
    interruptingThread.join();
}
#endif

TEST_F(ApiTest, CommitRollbackRemoveActiveTransaction) {
    ASSERT_TRUE(conn->query("BEGIN TRANSACTION;")->isSuccess());
    ASSERT_TRUE(conn->query("ROLLBACK;")->isSuccess());
    ASSERT_TRUE(conn->query("BEGIN TRANSACTION READ ONLY;")->isSuccess());
    ASSERT_TRUE(conn->query("COMMIT;")->isSuccess());
}

TEST_F(ApiTest, BeginningMultipleTransactionErrors) {
    ASSERT_TRUE(conn->query("BEGIN TRANSACTION;")->isSuccess());
    ASSERT_FALSE(conn->query("BEGIN TRANSACTION")->isSuccess());
    ASSERT_TRUE(conn->query("BEGIN TRANSACTION READ ONLY")->isSuccess());
    ASSERT_FALSE(conn->query("BEGIN TRANSACTION READ ONLY")->isSuccess());
}

// These two tests are designed to make sure that the explain and profile statements don't create a
// segmentation fault.
TEST_F(ApiTest, Explain) {
    auto result = conn->query("EXPLAIN MATCH (a:person)-[:knows]->(b:person), "
                              "(b)-[:knows]->(a) RETURN a.fName, b.fName ORDER BY a.ID");
    ASSERT_TRUE(result->isSuccess());
}

TEST_F(ApiTest, ExplainPrimaryKeyIndexChoice) {
    ASSERT_TRUE(conn->query("CALL enable_default_hash_index=false")->isSuccess());
    ASSERT_TRUE(conn->query("CREATE NODE TABLE ExplainNoIndex(id INT64, PRIMARY KEY(id));"
                            "CREATE (:ExplainNoIndex {id: 1});")
                    ->isSuccess());
    auto noIndexPlan =
        conn->query("EXPLAIN MATCH (n:ExplainNoIndex) WHERE n.id = 1 RETURN n.id")->toString();
    EXPECT_NE(noIndexPlan.find("FILTER"), std::string::npos);
    EXPECT_NE(noIndexPlan.find("SCAN_NODE_TABLE"), std::string::npos);
    EXPECT_EQ(noIndexPlan.find("PRIMARY_KEY_SCAN_NODE_TABLE"), std::string::npos);

    ASSERT_TRUE(conn->query("CREATE NODE TABLE ExplainHashIndex(id INT64, PRIMARY KEY(id));"
                            "CREATE (:ExplainHashIndex {id: 1});"
                            "CREATE HASH INDEX explain_hash_pk FOR (n:ExplainHashIndex) ON "
                            "(n.id);")
                    ->isSuccess());
    auto hashPlan =
        conn->query("EXPLAIN MATCH (n:ExplainHashIndex) WHERE n.id = 1 RETURN n.id")->toString();
    EXPECT_NE(hashPlan.find("PRIMARY_KEY_SCAN_NODE_TABLE"), std::string::npos);
    EXPECT_NE(hashPlan.find("Index: HASH"), std::string::npos);

    ASSERT_TRUE(conn->query("CREATE NODE TABLE ExplainArtIndex(id INT64, PRIMARY KEY(id));"
                            "CREATE (:ExplainArtIndex {id: 1});"
                            "CREATE ART INDEX explain_art_pk FOR (n:ExplainArtIndex) ON "
                            "(n.id);")
                    ->isSuccess());
    auto artPlan =
        conn->query("EXPLAIN MATCH (n:ExplainArtIndex) WHERE n.id = 1 RETURN n.id")->toString();
    EXPECT_NE(artPlan.find("PRIMARY_KEY_SCAN_NODE_TABLE"), std::string::npos);
    EXPECT_NE(artPlan.find("Index: ART"), std::string::npos);
}

TEST_F(ApiTest, UnwindQueryPrimaryKeyLookup) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE LookupEvent(id INT64, name STRING, PRIMARY KEY(id));"
                            "CREATE NODE TABLE LookupAuth(id INT64, PRIMARY KEY(id));"
                            "CREATE REL TABLE LookupRel(FROM LookupEvent TO LookupAuth);")
                    ->isSuccess());
    ASSERT_TRUE(conn->query("CREATE (:LookupEvent {id: 1, name: 'one'});"
                            "CREATE (:LookupEvent {id: 2, name: 'two'});"
                            "CREATE (:LookupAuth {id: 10});"
                            "CREATE (:LookupAuth {id: 20});")
                    ->isSuccess());

    auto explain = conn->query("EXPLAIN UNWIND [{event_id: 1, auth_id: 10}, "
                               "{event_id: 2, auth_id: 20}] AS row "
                               "MATCH (e:LookupEvent {id: row.event_id}) "
                               "MATCH (a:LookupAuth {id: row.auth_id}) "
                               "MERGE (e)-[:LookupRel]->(a)");
    ASSERT_TRUE(explain->isSuccess());
    const auto plan = explain->toString();
    EXPECT_NE(plan.find("QUERY_PRIMARY_KEY_LOOKUP"), std::string::npos);
    EXPECT_NE(plan.find("Table: LookupEvent"), std::string::npos);
    EXPECT_NE(plan.find("Table: LookupAuth"), std::string::npos);
    EXPECT_NE(plan.find("Key: STRUCT_EXTRACT(row)"), std::string::npos);

    auto merge = conn->query("UNWIND [{event_id: 1, auth_id: 10}, {event_id: 2, auth_id: 20}, "
                             "{event_id: 999, auth_id: 10}, {event_id: 1, auth_id: 999}] AS row "
                             "MATCH (e:LookupEvent {id: row.event_id}) "
                             "MATCH (a:LookupAuth {id: row.auth_id}) "
                             "MERGE (e)-[:LookupRel]->(a)");
    ASSERT_TRUE(merge->isSuccess());
    auto count = conn->query("MATCH (:LookupEvent)-[:LookupRel]->(:LookupAuth) RETURN COUNT(*)");
    ASSERT_TRUE(count->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*count), std::vector<std::string>{"2"});

    auto residual = conn->query("UNWIND [{id: 1, name: 'one'}, {id: 2, name: 'wrong'}] AS row "
                                "MATCH (e:LookupEvent {id: row.id}) "
                                "WHERE e.name = row.name RETURN e.id ORDER BY e.id");
    ASSERT_TRUE(residual->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*residual), std::vector<std::string>{"1"});

    auto batchMerge = conn->query("UNWIND RANGE(1, 1000) AS id "
                                  "CREATE (:LookupEvent {id: id + 100, name: 'batch'});"
                                  "UNWIND RANGE(1, 1000) AS id "
                                  "CREATE (:LookupAuth {id: id + 100});"
                                  "UNWIND RANGE(1, 1000) AS id "
                                  "MATCH (e:LookupEvent {id: id + 100}) "
                                  "MATCH (a:LookupAuth {id: id + 100}) "
                                  "MERGE (e)-[:LookupRel]->(a);");
    ASSERT_TRUE(batchMerge->isSuccess());
    auto batchCount =
        conn->query("MATCH (:LookupEvent)-[:LookupRel]->(:LookupAuth) RETURN COUNT(*)");
    ASSERT_TRUE(batchCount->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*batchCount), std::vector<std::string>{"1002"});
}

TEST_F(ApiTest, UnwindQueryPrimaryKeyLookupFallsBackWithoutIndex) {
    ASSERT_TRUE(conn->query("CALL enable_default_hash_index=false;")->isSuccess());
    ASSERT_TRUE(conn->query("CREATE NODE TABLE LookupNoIndex(id INT64, PRIMARY KEY(id));"
                            "CREATE (:LookupNoIndex {id: 1});")
                    ->isSuccess());
    auto explain = conn->query("EXPLAIN UNWIND [1] AS id "
                               "MATCH (n:LookupNoIndex {id: id}) RETURN n.id");
    ASSERT_TRUE(explain->isSuccess());
    const auto plan = explain->toString();
    EXPECT_EQ(plan.find("QUERY_PRIMARY_KEY_LOOKUP"), std::string::npos);
    EXPECT_NE(plan.find("SCAN_NODE_TABLE"), std::string::npos);

    auto result = conn->query("UNWIND [1, 999] AS id "
                              "MATCH (n:LookupNoIndex {id: id}) RETURN n.id");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*result), std::vector<std::string>{"1"});
}

// Regression: when the first row(s) of an UNWIND-driven MATCH miss the primary-key index, the
// row-driven lookup operator must not clobber the upstream selection vector (it had filtered the
// shared state to size 0, starving every subsequent tuple). What remains must be exactly the rows
// whose keys actually exist, in the same order as the UNWIND.
TEST_F(ApiTest, UnwindQueryPrimaryKeyLookupLeadingMissThenHits) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE LookupLeadingMiss(id INT64, v INT64, "
                            "PRIMARY KEY(id));")
                    ->isSuccess());
    ASSERT_TRUE(conn->query("CREATE (:LookupLeadingMiss {id: 2, v: 20});"
                            "CREATE (:LookupLeadingMiss {id: 3, v: 30});")
                    ->isSuccess());

    auto explain = conn->query("EXPLAIN UNWIND [0, 2, 3] AS x "
                               "MATCH (t:LookupLeadingMiss {id: x}) RETURN t.v");
    ASSERT_TRUE(explain->isSuccess());
    EXPECT_NE(explain->toString().find("QUERY_PRIMARY_KEY_LOOKUP"), std::string::npos);

    auto result = conn->query("UNWIND [0, 2, 3] AS x"
                              " MATCH (t:LookupLeadingMiss {id: x}) RETURN t.v");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*result), (std::vector<std::string>{"20", "30"}));
}

// Regression for issue #822: when the lookup key needs an implicit cast (SERIAL primary key vs
// INT64 UNWIND element), the key evaluator's result vector owns a DataChunkState pinned at
// position 0 instead of sharing the input chunk's state. The operator used to index the node-id
// vector and the output selection with that state, so with two sequential MATCH ... WHERE clauses
// every created relationship pointed at the first UNWIND row's node (row count was correct, the
// content was not). Each row must resolve to its own endpoints.
TEST_F(ApiTest, UnwindQueryPrimaryKeyLookupTwoMatchesWithCastKey) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE Item(id SERIAL, kind STRING, PRIMARY KEY(id));"
                            "CREATE REL TABLE Contains(FROM Item TO Item, label STRING);")
                    ->isSuccess());
    ASSERT_TRUE(conn->query("CREATE (:Item {kind: 'container'});"
                            "CREATE (:Item {kind: 'leaf1'});"
                            "CREATE (:Item {kind: 'leaf2'});"
                            "CREATE (:Item {kind: 'leaf3'});")
                    ->isSuccess());

    auto explain = conn->query("EXPLAIN UNWIND [{src: 0, tgt: 1}, {src: 0, tgt: 2}, "
                               "{src: 0, tgt: 3}] AS item "
                               "MATCH (s:Item) WHERE s.id = item.src "
                               "MATCH (t:Item) WHERE t.id = item.tgt "
                               "RETURN s.id, t.id");
    ASSERT_TRUE(explain->isSuccess());
    EXPECT_NE(explain->toString().find("QUERY_PRIMARY_KEY_LOOKUP"), std::string::npos);

    auto create =
        conn->query("UNWIND [{src: 0, tgt: 1}, {src: 0, tgt: 2}, {src: 0, tgt: 3}] AS item "
                    "MATCH (s:Item) WHERE s.id = item.src "
                    "MATCH (t:Item) WHERE t.id = item.tgt "
                    "CREATE (s)-[:Contains {label: 'contains'}]->(t)");
    ASSERT_TRUE(create->isSuccess());

    auto edges =
        conn->query("MATCH (a:Item)-[:Contains]->(b:Item) RETURN a.id, b.id ORDER BY b.id");
    ASSERT_TRUE(edges->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*edges),
        (std::vector<std::string>{"0|1", "0|2", "0|3"}));
}

// Regression for issue #822 (single lookup variant): reading an UNWIND variable after a MATCH
// whose primary-key equality needed an implicit cast used to return the first row's value on
// every row. The unwind variable must stay aligned with the looked-up node per row.
TEST_F(ApiTest, UnwindQueryPrimaryKeyLookupKeepsUnwindValuesAligned) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE AlignedItem(id SERIAL, v STRING, PRIMARY KEY(id));")
                    ->isSuccess());
    ASSERT_TRUE(conn->query("CREATE (:AlignedItem {v: 'v0'});"
                            "CREATE (:AlignedItem {v: 'v1'});"
                            "CREATE (:AlignedItem {v: 'v2'});")
                    ->isSuccess());

    auto result = conn->query("UNWIND [2, 0, 1] AS i "
                              "MATCH (t:AlignedItem) WHERE t.id = i "
                              "RETURN i, t.v ORDER BY i");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*result),
        (std::vector<std::string>{"0|v0", "1|v1", "2|v2"}));

    // Misses and NULL keys must still be skipped without disturbing later rows.
    auto sparse = conn->query("UNWIND [9, 2, NULL, 0] AS i "
                              "MATCH (t:AlignedItem) WHERE t.id = i "
                              "RETURN i, t.v ORDER BY i");
    ASSERT_TRUE(sparse->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*sparse),
        (std::vector<std::string>{"0|v0", "2|v2"}));

    // A batch larger than the vector capacity forces the upstream Flatten to refill mid-run;
    // alignment must survive the refill as well.
    ASSERT_TRUE(
        conn->query("CREATE NODE TABLE AlignedBatch(id SERIAL, PRIMARY KEY(id));")->isSuccess());
    ASSERT_TRUE(conn->query("CREATE (:AlignedBatch);CREATE (:AlignedBatch);CREATE (:AlignedBatch);")
                    ->isSuccess());
    auto capped = conn->query("UNWIND range(0, 2500) AS x MATCH (t:AlignedBatch) WHERE t.id = x "
                              "RETURN count(t)");
    ASSERT_TRUE(capped->isSuccess());
    ASSERT_EQ(TestHelper::convertResultToString(*capped), (std::vector<std::string>{"3"}));
}

TEST_F(ApiTest, Profile) {
    auto result =
        conn->query("EXPLAIN MATCH (a:person) WHERE EXISTS { MATCH (a)-[:knows]->(b:person) WHERE "
                    "b.fName='Farooq' } RETURN a.ID, min(a.age)");
    ASSERT_TRUE(result->isSuccess());
}

TEST_F(ApiTest, ProfileReportsWallClockTime) {
    auto result = conn->query("PROFILE MATCH (a:person) RETURN a.ID");
    ASSERT_TRUE(result->isSuccess());
    auto profile = result->toString();
    // WallClockTime (real wall clock) appears only on the PROFILE operator.
    EXPECT_NE(profile.find("WallClockTime:"), std::string::npos);
    // TotalTime (accumulated CPU across threads) appears on every operator.
    auto totalCount = 0u;
    for (auto pos = profile.find("TotalTime:"); pos != std::string::npos;
         pos = profile.find("TotalTime:", pos + 1)) {
        totalCount++;
    }
    EXPECT_GT(totalCount, 1);
}

TEST_F(ApiTest, TimeOut) {
    conn->setQueryTimeOut(1000 /* timeoutInMS */);
    auto result = conn->query(
        "UNWIND RANGE(1,100000) AS x UNWIND RANGE(1, 100000) AS y RETURN COUNT(x + y);");
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->getErrorMessage(), "Interrupted.");
}

TEST_F(ApiTest, MultipleQueryExplain) {
    auto result = conn->query("EXPLAIN MATCH (a:person)-[:knows]->(b:person), "
                              "(b)-[:knows]->(a) RETURN a.fName, b.fName ORDER BY a.ID; MATCH "
                              "(a:person) RETURN a.fName;");
    ASSERT_TRUE(result->isSuccess());
}

TEST_F(ApiTest, MultipleQuery) {
    auto result = conn->query("");
    ASSERT_EQ(result->getErrorMessage(), "Connection exception: Query is empty.");

    result = conn->query("MATCH (a:A)\n"
                         "            MATCH (a)-[:LIKES..]->(c)\n"
                         "            RETURN c.name;");
    ASSERT_FALSE(result->isSuccess());

    result = conn->query(
        "MATCH (a:person) RETURN a.fName; MATCH (a:person)-[:knows]->(b:person) RETURN count(*);");
    ASSERT_TRUE(result->isSuccess());

    result = conn->query("CREATE NODE TABLE Test(name STRING, age INT64, PRIMARY KEY(name));CREATE "
                         "(:Test {name: 'Alice', age: 25});"
                         "MATCH (a:Test) where a.name='Alice' return a.age;");
    ASSERT_TRUE(result->isSuccess());

    result = conn->query("return 1; return 2; return 3;");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(result->toString(), "1\n1\n");
    ASSERT_TRUE(result->hasNextQueryResult());
    ASSERT_EQ(result->getNextQueryResult()->toString(), "2\n2\n");
    ASSERT_TRUE(result->hasNextQueryResult());
    ASSERT_EQ(result->getNextQueryResult()->toString(), "3\n3\n");
}

TEST_F(ApiTest, SingleQueryHasNextQueryResult) {
    auto result = conn->query("MATCH (a:person) RETURN a.fName;");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_FALSE(result->hasNextQueryResult());
}

TEST_F(ApiTest, CopySkipDuplicatePKPreservesResultColumnNames) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE copy_user(ID STRING, name STRING, PRIMARY KEY(ID));")
                    ->isSuccess());
    auto result = conn->query(
        std::format("COPY copy_user FROM \"{}\" (IGNORE_ERRORS=true (DUPLICATE_PK_ONLY));",
            TestHelper::appendLbugRootPath("dataset/copy-fault-tests/duplicate-ids/vOrg.csv")));
    ASSERT_TRUE(result->isSuccess());

    // Contract: a node COPY always returns exactly one row with three columns
    // (result, skipped_duplicate_pk_count, skipped_duplicate_pks), regardless of ignore mode.
    ASSERT_EQ(result->getNumColumns(), 3);
    const auto columnNames = result->getColumnNames();
    EXPECT_EQ(columnNames.size(), 3);
    EXPECT_EQ(columnNames[0], "result");
    EXPECT_EQ(columnNames[1], "skipped_duplicate_pk_count");
    EXPECT_EQ(columnNames[2], "skipped_duplicate_pks");

    ASSERT_TRUE(result->hasNext());
    auto tuple = result->getNext();
    EXPECT_EQ(tuple->getValue(1)->getValue<int64_t>(), 1);
    EXPECT_EQ(tuple->getValue(2)->toString(), "[10]");
    // Exactly one row is returned.
    EXPECT_FALSE(result->hasNext());

    // The same 1-row / 3-column contract holds even when a second duplicate-PK csv is copied:
    // duplicate PKs accumulate into the skipped lists/errors instead of erroring out.
    ASSERT_TRUE(conn->query("CREATE NODE TABLE copy_user2(ID STRING, name STRING, PRIMARY "
                            "KEY(ID));")
                    ->isSuccess());
    auto result2 = conn->query(
        std::format("COPY copy_user2 FROM \"{}\" (IGNORE_ERRORS=true (DUPLICATE_PK_ONLY));",
            TestHelper::appendLbugRootPath("dataset/copy-fault-tests/duplicate-ids/vOrg.csv")));
    ASSERT_TRUE(result2->isSuccess());
    ASSERT_EQ(result2->getNumColumns(), 3);
    ASSERT_TRUE(result2->hasNext());
    auto tuple2 = result2->getNext();
    EXPECT_EQ(tuple2->getValue(0)->toString(),
        std::format("{} tuples have been copied to the copy_user2 table.", 3));
    EXPECT_EQ(tuple2->getValue(1)->getValue<int64_t>(), 1);
    EXPECT_EQ(tuple2->getValue(2)->toString(), "[10]");
    // Exactly one row is returned.
    EXPECT_FALSE(result2->hasNext());
}

TEST_F(ApiTest, Prepare) {
    auto result = conn->prepare("");
    ASSERT_EQ(result->getErrorMessage(), "Connection exception: Query is empty.");

    result =
        conn->prepare("CREATE NODE TABLE N(ID INT64, PRIMARY KEY(ID));CREATE REL TABLE E(FROM N TO "
                      "N, MANY_MANY);MATCH (a:N)-[:E]->(b:N) WHERE a.ID = 0 return b.ID;");
    ASSERT_EQ(result->getErrorMessage(),
        "Connection Exception: We do not support prepare multiple statements.");
}

TEST_F(ApiTest, PrepareWithLimit) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID limit $lm");
    auto result = conn->execute(prepared.get(), std::make_pair(std::string{"lm"}, 3));
    ASSERT_TRUE(result->isSuccess());
    std::vector<std::string> expectedResult = {"0", "2", "3"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"lm"}, 5));
    ASSERT_TRUE(result->isSuccess());
    expectedResult = {"0", "2", "3", "5", "7"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
}

TEST_F(ApiTest, PrepareWithSkip) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID skip $sp");
    auto result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 2));
    ASSERT_TRUE(result->isSuccess());
    std::vector<std::string> expectedResult = {"10", "3", "5", "7", "8", "9"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 4));
    ASSERT_TRUE(result->isSuccess());
    expectedResult = {"10", "7", "8", "9"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
}

TEST_F(ApiTest, PrepareWithSkipAndLimit) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID skip $sp limit $lm");
    auto result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 2),
        std::make_pair(std::string{"lm"}, 5));
    ASSERT_TRUE(result->isSuccess());
    std::vector<std::string> expectedResult = {"3", "5", "7", "8", "9"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 4),
        std::make_pair(std::string{"lm"}, 2));
    ASSERT_TRUE(result->isSuccess());
    expectedResult = {"7", "8"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
}

TEST_F(ApiTest, PrepareWithTopK1) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID ORDER BY p.ID skip $sp limit $lm");
    auto result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 2),
        std::make_pair(std::string{"lm"}, 5));
    ASSERT_TRUE(result->isSuccess());
    std::vector<std::string> expectedResult = {"3", "5", "7", "8", "9"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"sp"}, 4),
        std::make_pair(std::string{"lm"}, 2));
    ASSERT_TRUE(result->isSuccess());
    expectedResult = {"7", "8"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
}

TEST_F(ApiTest, PrepareWithTopK2) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID ORDER BY p.ID limit $lm");
    auto result = conn->execute(prepared.get(), std::make_pair(std::string{"lm"}, 5));
    ASSERT_TRUE(result->isSuccess());
    std::vector<std::string> expectedResult = {"0", "2", "3", "5", "7"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"lm"}, 2));
    ASSERT_TRUE(result->isSuccess());
    expectedResult = {"0", "2"};
    ASSERT_EQ(TestHelper::convertResultToString(*result), expectedResult);
    result = conn->execute(prepared.get(), std::make_pair(std::string{"lm"}, -2));
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(),
        "Runtime exception: The number of rows to skip/limit must be a non-negative integer.");
}

TEST_F(ApiTest, PrepareWithSkipLimitError) {
    auto prepared = conn->prepare("MATCH (p:person) RETURN p.ID skip $sp");
    auto result = conn->execute(prepared.get());
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(), "Parameter sp not found.");

    result = conn->execute(prepared.get(), std::make_pair(std::string("sp"), "abc"));
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(),
        "Runtime exception: The number of rows to skip/limit must be a non-negative integer.");

    prepared = conn->prepare("MATCH (p:person) RETURN p.ID limit $sp");
    result = conn->execute(prepared.get());
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(), "Parameter sp not found.");

    prepared = conn->prepare("MATCH (p:person) RETURN p.ID skip $s limit $sp");
    result = conn->execute(prepared.get(), std::make_pair(std::string("s"), 3));
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(), "Parameter sp not found.");

    prepared = conn->prepare("MATCH (p:person) RETURN p.ID skip $s");
    result = conn->execute(prepared.get(), std::make_pair(std::string("s"), 3.4));
    ASSERT_FALSE(result->isSuccess());
    ASSERT_EQ(result->toString(),
        "Runtime exception: The number of rows to skip/limit must be a non-negative integer.");
}

TEST_F(ApiTest, CreateTableAfterClosingDatabase) {
    database.reset();
    database = std::make_unique<Database>(databasePath, *systemConfig);
    conn = std::make_unique<Connection>(database.get());

    auto result = conn->query("CREATE NODE TABLE Test(name STRING, age INT64, PRIMARY KEY(name));");
    ASSERT_TRUE(result->isSuccess()) << result->toString();
    result = conn->query("CREATE (:Test {name: 'Alice', age: 25});"
                         "MATCH (a:Test) where a.name='Alice' return a.age;");
    ASSERT_TRUE(result->isSuccess()) << result->toString();
}

TEST_F(ApiTest, QueryWithHeadingNewline) {
    createDBAndConn();
    ASSERT_TRUE(conn->query("\n PROFILE RETURN 5; \n")->isSuccess());
}

TEST_F(ApiTest, LoadFromInvalidParam) {
    std::unordered_map<std::string, std::unique_ptr<Value>> params;
    params["val"] = std::make_unique<Value>(Value::createValue(3));
    auto prep = conn->prepareWithParams("LOAD FROM $val RETURN *", std::move(params));
    ASSERT_FALSE(prep->isSuccess());
    ASSERT_STREQ(
        "Binder exception: Trying to scan from unsupported data type INT32. The only parameter "
        "types that can be scanned from are pandas/polars dataframes and pyarrow tables.",
        prep->getErrorMessage().c_str());
}

TEST_F(ApiTest, CopyFromInvalidParam) {
    ASSERT_TRUE(conn->query("CREATE NODE TABLE test(id INT64 PRIMARY KEY);")->isSuccess());
    std::unordered_map<std::string, std::unique_ptr<Value>> params;
    params["val"] = std::make_unique<Value>(Value::createValue(3));
    auto prep = conn->prepareWithParams("COPY test FROM $val", std::move(params));
    ASSERT_FALSE(prep->isSuccess());
    ASSERT_STREQ(
        "Binder exception: Trying to scan from unsupported data type INT32. The only parameter "
        "types that can be scanned from are pandas/polars dataframes and pyarrow tables.",
        prep->getErrorMessage().c_str());
}

TEST_F(ApiTest, MissingParam) {
    std::unordered_map<std::string, std::unique_ptr<Value>> params;
    params["val1"] = std::make_unique<Value>(Value::createValue(3));
    auto prep = conn->prepareWithParams("RETURN $val1 + $val2", std::move(params));
    ASSERT_TRUE(prep->isSuccess());
    auto result = conn->execute(prep.get(), std::make_pair(std::string("s"), 3));
    ASSERT_FALSE(result->isSuccess());
    ASSERT_STREQ("Parameter val2 not found.", result->getErrorMessage().c_str());
    result = conn->execute(prep.get(), std::make_pair(std::string("val2"), 1.1));
    ASSERT_TRUE(result->isSuccess());
    ASSERT_STREQ("4.100000\n", result->getNext()->toString().c_str());
    result = conn->execute(prep.get(), std::make_pair(std::string("val2"), 1.1),
        std::make_pair(std::string("val1"), 1.1));
    ASSERT_TRUE(result->isSuccess());
    ASSERT_STREQ("2.200000\n", result->getNext()->toString().c_str());
}

TEST_F(ApiTest, CloseDatabaseBeforeQueryResultAndConnection) {
    auto systemConfig = SystemConfig();
    systemConfig.bufferPoolSize = 10 * 1024 * 1024; // 10MB
    systemConfig.maxNumThreads = 2;
    systemConfig.maxDBSize = 1 << 30; // 1GB

    auto inMemoryDatabase = std::make_unique<Database>(":memory:", systemConfig);
    auto conn = std::make_unique<Connection>(inMemoryDatabase.get());
    auto result = conn->query("RETURN 1+1 AS col;");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(result->getNext()->getValue(0)->getValue<int64_t>(), 2);
    result->resetIterator();
    // Close the database before the result and connection. It should not cause SEGFAULT.
    inMemoryDatabase.reset();
    // All public Connection methods that check for closed DB
    try {
        conn->setMaxNumThreadForExec(1);
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        conn->getMaxNumThreadForExec();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        conn->prepare("RETURN 1");
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        std::unordered_map<std::string, std::unique_ptr<Value>> params;
        conn->prepareWithParams("RETURN 1", std::move(params));
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        conn->query("RETURN 2+2;");
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        std::unordered_map<std::string, std::unique_ptr<Value>> params;
        conn->executeWithParams(nullptr, std::move(params));
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        conn->interrupt();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        conn->setQueryTimeOut(1000);
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    // All public QueryResult methods that check for closed DB
    ASSERT_TRUE(result->isSuccess());
    ASSERT_NO_THROW(result->getErrorMessage());
    ASSERT_NO_THROW(result->getNumColumns());
    ASSERT_NO_THROW(result->getColumnNames());
    ASSERT_NO_THROW(result->getColumnDataTypes());
    ASSERT_NO_THROW(result->getQuerySummary());
    try {
        (void)result->getNumTuples();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        result->resetIterator();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        (void)result->hasNext();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        (void)result->hasNextQueryResult();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        result->getNextQueryResult();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        result->getNext();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        (void)result->toString();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        (void)result->getArrowSchema();
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
    try {
        result->getNextArrowChunk(1);
        FAIL();
    } catch (Exception& e) {
        ASSERT_STREQ(e.what(), "Runtime exception: The current operation is not allowed because "
                               "the parent database is closed.");
    }
}

TEST_F(ApiTest, CloseDatabaseBeforeQueryResultWithMultipleStatements) {
    auto systemConfig = SystemConfig();
    systemConfig.bufferPoolSize = 10 * 1024 * 1024; // 10MB
    systemConfig.maxNumThreads = 2;
    systemConfig.maxDBSize = 1 << 30; // 1GB

    auto inMemoryDatabase = std::make_unique<Database>(":memory:", systemConfig);
    auto conn = std::make_unique<Connection>(inMemoryDatabase.get());
    auto result = conn->query("RETURN 1+1; RETURN 2+2; RETURN 3+3;");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_EQ(result->getNext()->getValue(0)->getValue<int64_t>(), 2);
    auto nextResult = result->getNextQueryResult();
    ASSERT_EQ(nextResult->getNext()->getValue(0)->getValue<int64_t>(), 4);
    nextResult = result->getNextQueryResult();
    ASSERT_EQ(nextResult->getNext()->getValue(0)->getValue<int64_t>(), 6);
    result->resetIterator();
    inMemoryDatabase.reset();
}

TEST_F(ApiTest, ToStringDoesNotModifyIterator) {
    auto result = conn->query("MATCH (p:person) RETURN p.ID ORDER BY p.ID");
    ASSERT_TRUE(result->isSuccess());
    ASSERT_TRUE(result->hasNext()); // Iterator should be at the beginning
    auto str = result->toString();  // This should not modify the iterator
    ASSERT_TRUE(result->hasNext()); // Iterator should still be at the beginning
    // Now iterate through the results
    std::vector<int64_t> ids;
    while (result->hasNext()) {
        auto tuple = result->getNext();
        ids.push_back(tuple->getValue(0)->getValue<int64_t>());
    }
    ASSERT_EQ(ids.size(), 8u); // Assuming 8 persons in the test data
    ASSERT_EQ(ids[0], 0);
    ASSERT_EQ(ids[1], 2);
    // etc., but just check the count for now
}

TEST_F(ApiTest, EmptyDBFile) {
    if (inMemMode) {
        GTEST_SKIP();
    }
    database.reset();
    std::filesystem::remove(databasePath);
    // Create a new database with an empty file.
    std::ofstream file(databasePath);
    file.close();
    ASSERT_TRUE(std::filesystem::exists(databasePath));
    ASSERT_TRUE(std::filesystem::file_size(databasePath) == 0);
    // Attempt to open the database with the empty file.
    ASSERT_NO_THROW(std::make_unique<Database>(databasePath, *systemConfig));
}

TEST_F(ApiTest, EmptyDBFileWithReadOnly) {
    if (inMemMode) {
        GTEST_SKIP();
    }
    database.reset();
    std::filesystem::remove(databasePath);
    // Create a new database with an empty file.
    std::ofstream file(databasePath);
    file.close();
    ASSERT_TRUE(std::filesystem::exists(databasePath));
    ASSERT_TRUE(std::filesystem::file_size(databasePath) == 0);
    systemConfig->readOnly = true;
    // Attempt to open the database with the empty file in read-only mode.
    ASSERT_NO_THROW(std::make_unique<Database>(databasePath, *systemConfig));
}

TEST_F(ApiTest, InvalidDBFile) {
    if (inMemMode) {
        GTEST_SKIP();
    }
    database.reset();
    std::filesystem::remove(databasePath);
    // Create a new database with an empty file.
    std::ofstream file(databasePath);
    file << "This is not a valid Lbug database file.";
    file.close();
    ASSERT_TRUE(std::filesystem::exists(databasePath));
    ASSERT_FALSE(std::filesystem::file_size(databasePath) == 0);
    // Attempt to open the database with the empty file.
    ASSERT_THROW(std::make_unique<Database>(databasePath, *systemConfig), Exception);
}

TEST_F(ApiTest, DBFileUnderNonExistingDir) {
    if (inMemMode) {
        GTEST_SKIP();
    }
    database.reset();
    std::filesystem::remove(databasePath);
    databasePath = databasePath + "/non_existing_dir/database.lbdb";
    ASSERT_FALSE(std::filesystem::exists(databasePath));
    // Attempt to open the database with the empty file.
    ASSERT_THROW(std::make_unique<Database>(databasePath, *systemConfig), IOException);
}
