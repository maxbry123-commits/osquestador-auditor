import React, { forwardRef, useRef, useState, useEffect, useCallback, MouseEvent } from 'react';
import { Footer, Header, Icon, Filter, Label } from 'Component';
import ArchiveListTree from './archiveListTree';
import ArchiveSuggested from './archiveSuggested';
import * as I from 'Interface';
import Storage from 'Lib/storage';

type ViewMode = 'compact' | 'detailed';
type Tab = 'bin' | 'suggested';

const PageMainArchive = forwardRef<I.PageRef, I.PageComponent>((props, ref) => {

	const { isPopup } = props;
	const filterRef = useRef(null);
	const [ selectedIds, setSelectedIds ] = useState<string[]>([]);
	const [ visibleIds, setVisibleIds ] = useState<string[]>([]);
	const [ filterText, setFilterText ] = useState('');
	const [ viewMode, setViewMode ] = useState<ViewMode>(() => {
		const saved = Storage.get('binViewMode');
		return (saved === 'compact' || saved === 'detailed') ? saved : 'compact';
	});
	const [ sortId, setSortId ] = useState('lastModifiedDate');
	const [ sortType, setSortType ] = useState(I.SortType.Desc);
	// Restore from this history entry's state (see onTab) — set only via back/forward, so a
	// fresh Bin open from the sidebar (a new entry with no tab) starts on Bin.
	const [ activeTab, setActiveTab ] = useState<Tab>(() => (U.Router.history?.location?.state?.tab == 'suggested' ? 'suggested' : 'bin'));
	// null = not loaded yet, so the auto-return effect can tell "no suggestions" from
	// "count unknown" and not bounce a restored Suggestions tab back to Bin on mount.
	const [ suggestionCount, setSuggestionCount ] = useState<number | null>(null);
	const [ suggestedSel, setSuggestedSel ] = useState<{ count: number; canDelete: boolean }>({ count: 0, canDelete: true });
	// Shown once ever, across every space (a plain, non-space Storage key).
	const [ isCleanupNoteClosed, setIsCleanupNoteClosed ] = useState(() => Storage.getOnboarding('binCleanup'));
	const suggestedRef = useRef(null);
	const filterTimeout = useRef(0);
	const subId = J.Constant.subId.archive;
	const spaceview = U.Space.getSpaceview();
	const isShared = spaceview.isShared;
	const canModerate = U.Space.canMyParticipantModerate();
	const participantId = U.Space.getCurrentParticipantId();
	const canWrite = U.Space.canMyParticipantWrite();
	const hasSelection = selectedIds.length > 0;

	const canDeleteSelection = (): boolean => {
		if (canModerate || !isShared) {
			return true;
		};

		return selectedIds.every(id => {
			const obj = S.Detail.get(subId, id, [ 'creator' ]);
			return obj.creator === participantId;
		});
	};

	const onSelectAll = () => {
		if (hasSelection) {
			setSelectedIds([]);
		} else {
			setSelectedIds(visibleIds);
		};
	};

	const onRestore = () => {
		if (!hasSelection) {
			return;
		};

		Action.restore(selectedIds, analytics.route.archive);
		setSelectedIds([]);
	};

	const onRemove = () => {
		if (!hasSelection || !canDeleteSelection()) {
			return;
		};

		Action.delete(selectedIds, analytics.route.archive, () => setSelectedIds([]));
	};

	const onSortChange = (id: string, type: I.SortType) => {
		setSortId(id);
		setSortType(type);
	};

	const nextViewMode: Record<ViewMode, ViewMode> = { compact: 'detailed', detailed: 'compact' };

	const onSwitchView = () => {
		const next = nextViewMode[viewMode];
		setViewMode(next);
		Storage.set('binViewMode', next);
	};

	// Record the tab on the current history entry rather than globally: back/forward
	// restores it (same pathname, so no page remount), while a fresh Bin open is a new
	// entry with no tab. Writing state before setActiveTab keeps them in agreement even
	// if the replace happened to remount and re-read the initial value.
	const onTab = (tab: Tab) => {
		setActiveTab(tab);

		const h = U.Router.history;
		if (h?.location) {
			h.replace({
				pathname: h.location.pathname,
				search: h.location.search,
				hash: h.location.hash,
				state: Object.assign({}, h.location.state, { tab }),
			});
		};
	};

	const onCleanupNoteClose = () => {
		Storage.setOnboarding('binCleanup');
		setIsCleanupNoteClosed(true);
	};

	// The route is reported here rather than passed through openSettings: that helper puts
	// it in _routeParam_.additional, which U.Router.build serialises as [it.key, it.value] —
	// both undefined for a bare { route }, so it never reaches the page.
	const onDeletionAudit = () => {
		analytics.event('ClickDeletionAudit', { route: analytics.route.archive });
		Action.openSettings('spaceDeletionAudit', analytics.route.archive);
	};

	const onSelectTree = (ids: string[], e: MouseEvent) => {
		e.stopPropagation();
		let next = [ ...selectedIds ];
		const allPresent = ids.every(id => next.includes(id));
		if (allPresent) {
			next = next.filter(id => !ids.includes(id));
		} else {
			next = [ ...new Set([ ...next, ...ids ]) ];
		};
		setSelectedIds(next);
	};

	const filterMouseDownHandler = useRef<((e: any) => void) | null>(null);
	const filterKeydownHandler = useRef<((e: any) => void) | null>(null);

	const onFilterShow = () => {
		if (!filterRef.current) {
			return;
		};

		filterRef.current.setActive(true);
		filterRef.current.focus();

		const container = U.Dom.getPageFlexContainer(isPopup);

		if (filterMouseDownHandler.current && container) {
			U.Dom.removeEvent(container, 'mousedown', filterMouseDownHandler.current);
		};
		if (filterKeydownHandler.current) {
			U.Dom.removeEvent(window, 'keydown', filterKeydownHandler.current);
		};

		filterMouseDownHandler.current = (e: any) => {
			const value = filterRef.current?.getValue();

			if (!value && !(e.target as HTMLElement)?.closest('.filter')) {
				onFilterHide();
				if (container) {
					U.Dom.removeEvent(container, 'mousedown', filterMouseDownHandler.current);
				};
			};
		};

		filterKeydownHandler.current = (e: any) => {
			keyboard.shortcut('escape', e, () => {
				onFilterHide();
				U.Dom.removeEvent(window, 'keydown', filterKeydownHandler.current);
			});
		};

		if (container) {
			U.Dom.addEvent(container, 'mousedown', filterMouseDownHandler.current);
		};
		U.Dom.addEvent(window, 'keydown', filterKeydownHandler.current);
	};

	const onFilterHide = () => {
		if (!filterRef.current) {
			return;
		};

		filterRef.current.setActive(false);
		filterRef.current.setValue('');
		filterRef.current.blur();
		setFilterText('');
	};

	const onFilterChange = () => {
		window.clearTimeout(filterTimeout.current);
		filterTimeout.current = window.setTimeout(() => {
			setFilterText(String(filterRef.current?.getValue() || ''));
		}, J.Constant.delay.keyboard);
	};

	const getDeleteTooltip = (): string => {
		if (!canDeleteSelection()) {
			return translate('binDeleteDisabledTooltip');
		};
		return translate('commonDeleteImmediately');
	};

	const onKeyDown = useCallback((e: KeyboardEvent) => {
		keyboard.shortcut('searchText', e, () => {
			e.preventDefault();
			onFilterShow();
		});
	}, []);

	const archiveKeydownHandler = useRef<((e: any) => void) | null>(null);

	useEffect(() => {
		analytics.event('ScreenBin');
		sidebar.rightPanelClose(isPopup, false);

		return () => {
			window.clearTimeout(filterTimeout.current);
			const cleanupEl = U.Dom.getPageFlexContainer(isPopup);
			
			if (filterMouseDownHandler.current && cleanupEl) {
				U.Dom.removeEvent(cleanupEl, 'mousedown', filterMouseDownHandler.current);
				filterMouseDownHandler.current = null;
			};

			if (filterKeydownHandler.current) {
				U.Dom.removeEvent(window, 'keydown', filterKeydownHandler.current);
				filterKeydownHandler.current = null;
			};
		};
	}, []);

	useEffect(() => {
		archiveKeydownHandler.current = (e: any) => onKeyDown(e);
		U.Dom.addEvent(window, 'keydown', archiveKeydownHandler.current);
		return () => {
			if (archiveKeydownHandler.current) {
				U.Dom.removeEvent(window, 'keydown', archiveKeydownHandler.current);
			};
		};
	}, []);

	// The Suggestions tab disappears once its last item is cleared, so fall back to Bin
	// rather than leaving the user on an empty, hidden tab. Guard on an explicit 0 (not
	// the null "still loading" state) so a restored tab isn't bounced on mount.
	useEffect(() => {
		if ((activeTab === 'suggested') && (suggestionCount === 0)) {
			onTab('bin');
		};
	}, [ suggestionCount, activeTab ]);

	const isAllSelected = hasSelection && (visibleIds.length > 0) && (selectedIds.length >= visibleIds.length);
	const canDelete = canDeleteSelection();
	const isDetailed = viewMode === 'detailed';
	const switchIconMap = { compact: 'common/switchView', detailed: 'common/switchViewDetailed' };
	const switchTooltipMap = { compact: 'binSwitchToDetailed', detailed: 'binSwitchToCompact' };
	const cnWrapper = [ 'wrapper', ...(isDetailed ? [ 'isDetailed' ] : []) ];
	const isBin = activeTab === 'bin';
	const cnBinTab = [ 'tab', (isBin ? 'active' : '') ];
	const cnSuggestedTab = [ 'tab', (!isBin ? 'active' : '') ];

	return (
		<>
			<Header
				{...props}
				component="mainArchive"
			/>

			<div className={cnWrapper.join(' ')}>
				<div className="titleWrapper">
					<div className="side left">
						<Icon name="common/bin" size={32} color="default" />

						<div className="tabs">
							<div className={cnBinTab.join(' ')} onClick={() => onTab('bin')}>
								{translate('commonBin')}
							</div>

							{(suggestionCount || !isBin) ? (
								<div
									className={cnSuggestedTab.join(' ')}
									onClick={() => onTab('suggested')}
									onMouseEnter={e => Preview.tooltipShow({ text: translate('binCleanupDescription'), element: e.currentTarget as HTMLElement, typeY: I.MenuDirection.Bottom })}
									onMouseLeave={() => Preview.tooltipHide(false)}
								>
									{translate('binCleanupTab')}
									{suggestionCount ? <span className="cnt">{suggestionCount}</span> : ''}
								</div>
							) : ''}
						</div>
					</div>
					<div className="side right">
						{(isBin && canWrite) ? (
							<>
								{hasSelection ? (
									<>
										<Icon
											className="archiveAction"
											name="menu/action/restore"
											withBackground={true}
											tooltipParam={{ text: translate('commonRestore') }}
											onClick={onRestore}
										/>
										<Icon
											className={[ 'archiveAction', ((!canDelete || !hasSelection) ? 'isDisabled' : '') ].join(' ')}
											name="menu/action/remove"
											withBackground={true}
											tooltipParam={{ text: getDeleteTooltip() }}
											onClick={onRemove}
										/>
									</>
								) : ''}

								<Icon
									className="archiveAction"
									name={switchIconMap[viewMode]}
									withBackground={true}
									tooltipParam={{ text: translate(switchTooltipMap[viewMode]) }}
									onClick={onSwitchView}
								/>

								<Filter
									ref={filterRef}
									onChange={onFilterChange}
									placeholder={translate('commonSearchPlaceholder')}
									iconParam={{ name: 'common/search' }}
									tooltipParam={{ text: translate('commonSearch'), caption: keyboard.getCaption('searchText') }}
									onIconClick={onFilterShow}
									size={32}
								/>
							</>
						) : ''}

						{/* Same toolbar shape as the Bin, but its actions target the suggestions
							and live in ArchiveSuggested — reached through the ref. */}
						{(!isBin && canWrite && suggestedSel.count) ? (
							<>
								<Icon
									className="archiveAction"
									name="menu/action/minus"
									withBackground={true}
									tooltipParam={{ text: translate('binCleanupIgnore') }}
									onClick={() => suggestedRef.current?.onIgnore()}
								/>
								<Icon
									className={[ 'archiveAction', (!suggestedSel.canDelete ? 'isDisabled' : '') ].join(' ')}
									name="menu/action/remove"
									withBackground={true}
									tooltipParam={{ text: translate(suggestedSel.canDelete ? 'commonDeleteImmediately' : 'binDeleteDisabledTooltip') }}
									onClick={() => suggestedRef.current?.onDelete()}
								/>
							</>
						) : ''}

						{/* Navigates away rather than switching tabs, so it stays out of .tabs —
							sitting beside Bin/Cleanup would misrepresent it as a third tab.
							Gated on the same predicate as the page itself, so this button and
							the page it opens can never disagree about who may see it. */}
						{U.Space.canMyParticipantSeeDeletionAudit() ? (
							<Icon
								className="archiveAction"
								name="common/clock"
								withBackground={true}
								tooltipParam={{ text: translate('pageSettingsSpaceDeletionAudit') }}
								onClick={onDeletionAudit}
							/>
						) : ''}
					</div>
				</div>

				{(!isBin && !isCleanupNoteClosed) ? (
					<div className="cleanupNote">
						<Label text={translate('binCleanupDescription')} />
						<Icon name="common/close" className="close" onClick={onCleanupNoteClose} />
					</div>
				) : ''}

				{isBin ? (
					<ArchiveListTree
						subId={subId}
						canWrite={canWrite}
						isShared={isShared}
						isPopup={isPopup}
						isDetailed={isDetailed}
						selectedIds={selectedIds}
						filterText={filterText}
						sortId={sortId}
						sortType={sortType}
						onSort={onSortChange}
						onSelectChange={onSelectTree}
						onSelectAll={onSelectAll}
						isAllSelected={isAllSelected}
						onVisibleIdsChange={setVisibleIds}
					/>
				) : ''}

				<ArchiveSuggested
					ref={suggestedRef}
					canWrite={canWrite}
					isActive={!isBin}
					onCountChange={setSuggestionCount}
					onSelectionChange={(count, canDelete) => setSuggestedSel({ count, canDelete })}
				/>
			</div>

			<Footer {...props} component="mainObject" />
		</>
	);

});

export default PageMainArchive;
