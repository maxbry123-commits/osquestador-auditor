/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.server.queryapi.response.writer;

import com.fasterxml.jackson.core.JsonFactory;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import org.neo4j.logging.InternalLog;
import org.neo4j.server.http.cypher.format.DefaultJsonFactory;
import org.neo4j.server.queryapi.response.QueryResponseTxInfo;
import org.neo4j.server.queryapi.response.format.QueryAPICodec;
import org.neo4j.server.queryapi.response.format.QueryBodyFormatter;
import org.neo4j.server.queryapi.response.format.View;

abstract class AbstractJsonlTxInfoWriter implements MessageBodyWriter<QueryResponseTxInfo> {
    private final InternalLog log;
    private final JsonFactory factory;

    protected AbstractJsonlTxInfoWriter(InternalLog log, View view) {
        this.log = log;
        this.factory = DefaultJsonFactory.INSTANCE.get().copy().setCodec(new QueryAPICodec(view));
    }

    @Override
    public boolean isWriteable(Class<?> aClass, Type type, Annotation[] annotations, MediaType mediaType) {
        return QueryResponseTxInfo.class.isAssignableFrom(aClass);
    }

    @Override
    public void writeTo(
            QueryResponseTxInfo queryResponseTxInfo,
            Class<?> aClass,
            Type type,
            Annotation[] annotations,
            MediaType mediaType,
            MultivaluedMap<String, Object> httpHeaders,
            OutputStream outputStream)
            throws IOException, WebApplicationException {
        httpHeaders.add("Transfer-encoding", "chunked");
        var jsonGenerator = factory.createGenerator(outputStream);
        var formatter = new QueryBodyFormatter(jsonGenerator, outputStream);
        formatter.jsonl(jsonl -> {
            jsonl.header();
            jsonl.summary(
                    queryResponseTxInfo.transaction().id(),
                    queryResponseTxInfo.transaction().expires());
        });
    }
}
