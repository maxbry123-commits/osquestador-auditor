/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.server.queryapi.response.writer;

import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;
import org.neo4j.logging.InternalLog;
import org.neo4j.server.queryapi.QueryMimeTypes;
import org.neo4j.server.queryapi.response.format.View;
import org.neo4j.server.queryapi.tx.TransactionManager;

@Provider
@Produces({QueryMimeTypes.TYPED_JSONL_V1x2})
public class TypedJsonlTxManagingResultWriterV12 extends AbstractJsonlTxManagingResultWriter {
    public TypedJsonlTxManagingResultWriterV12(
            @Context InternalLog logger, @Context TransactionManager transactionManager) {
        super(logger, View.TYPED_JSON_V1x2, transactionManager);
    }
}
