exec("fortune");
