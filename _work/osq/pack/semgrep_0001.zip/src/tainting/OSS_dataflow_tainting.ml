(* Yoann Padioleau, Iago Abal
 *
 * Copyright (C) 2019-2025 Semgrep Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation, with the
 * special exception on linking described in file LICENSE.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the file
 * LICENSE for more details.
 *)
open Common
open Maps
open IL
module Log = Log_tainting.Log
module G = AST_generic
module F = IL
module D = Dataflow_core
module Var_env = Dataflow_var_env
module VarMap = Var_env.VarMap
module PM = Core_match
module R = Rule
module LV = IL_helpers
module T = Taint
module Lval_env = OSS_taint_lval_env
module Taints = T.Taint_set
module TM = Taint_spec_match
module TP = Taint_spec_preds
module TRI = Taint_rule_inst
module Shape = OSS_taint_shape
module Effect = OSS_taint_effects.Effect
module Effects = OSS_taint_effects.Effects

(* TODO: Rename things to make clear that there are "sub-matches" and there are
 * "best matches". *)

(*****************************************************************************)
(* Prelude *)
(*****************************************************************************)
(* Tainting dataflow analysis.
 *
 * - This is a rudimentary taint analysis in some ways, but rather complex in
 *   other ways... We don't do alias analysis, and inter-procedural support
 *   (for DeepSemgrep) still doesn't cover some common cases. On the other hand,
 *   almost _anything_ can be a source/sanitizer/sink, we have taint propagators,
 *   etc.
 * - It is a MAY analysis, it finds *potential* bugs (the tainted path could not
 *   be feasible in practice).
 * - Field sensitivity is limited to l-values of the form x.a.b.c, see module
 *   Taint_lval_env and check_tainted_lval for more details. Very coarse grained
 *   otherwise, e.g. `x[i] = tainted` will taint the whole array,
 *
 * old: This was originally in src/analyze, but it now depends on
 *      Pattern_match, so it was moved to src/engine.
 *)

module DataflowX = Dataflow_core.Make (struct
  type node = F.node
  type edge = F.edge
  type flow = (node, edge) CFG.t

  let short_string_of_node n = Display_IL.short_string_of_node n
end)

let transfer_tag = Log_tainting.transfer_tag

(*****************************************************************************)
(* Types *)
(*****************************************************************************)

type mapping = Lval_env.t D.mapping

type func = {
  taint_inst : OSS_taint_rule_inst.t;
  fname : IL.name option;
  best_matches : TM.Best_matches.t;
      (** Best matches for the taint sources/etc, see 'Taint_spec_match'. *)
}
(** Data about the top-level function definition under analysis, this does not
   vary when analyzing lambdas. *)

(* REFACTOR: Rename 'Taint_lval_env' as 'Taint_var_env' and create a new module
    for this 'env' type called 'Taint_env' or 'Taint_state' or sth, then we could
    e.g. move all lambda stuff to 'Taint_lambda'. *)
(* THINK: Separate read-only enviroment into a new a "cfg" type? *)
type env = {
  func : func;
  in_lambda : IL.name option;
  lambdas : Taint_lambdas.env;
  lval_env : Lval_env.t;
  effects_acc : Effects.t ref;
}

(*****************************************************************************)
(* Options *)
(*****************************************************************************)

let propagate_through_functions env =
  (not env.func.taint_inst.options.taint_assume_safe_functions)
  && not env.func.taint_inst.options.taint_only_propagate_through_assignments

let propagate_through_indexes env =
  (not env.func.taint_inst.options.taint_assume_safe_indexes)
  && not env.func.taint_inst.options.taint_only_propagate_through_assignments

(*****************************************************************************)
(* Helpers *)
(*****************************************************************************)

let record_timeout (taint_inst : OSS_taint_rule_inst.t) opt_name timeout =
  match timeout with
  | `Ok -> ()
  | `Timeout ->
      Taint_rule_inst.record_timeout ~timeouts:taint_inst.muts.timeouts
        ~rule:taint_inst.rule opt_name

let map_check_expr env check_expr xs =
  let rev_taints_and_shapes, lval_env =
    xs
    |> List.fold_left
         (fun (rev_taints_and_shapes, lval_env) x ->
           let taints, shape, lval_env = check_expr { env with lval_env } x in
           ((taints, shape) :: rev_taints_and_shapes, lval_env))
         ([], env.lval_env)
  in
  (List.rev rev_taints_and_shapes, lval_env)

let union_map_taints_and_vars env check xs =
  let taints, lval_env =
    xs
    |> List.fold_left
         (fun (taints_acc, lval_env) x ->
           let taints, shape, lval_env = check { env with lval_env } x in
           let taints_acc =
             taints_acc |> Taints.union taints
             |> Taints.union (Shape.gather_all_taints_in_shape shape)
           in
           (taints_acc, lval_env))
         (Taints.empty, env.lval_env)
  in
  let taints =
    if env.func.taint_inst.options.taint_only_propagate_through_assignments then
      Taints.empty
    else taints
  in
  (taints, lval_env)

let gather_all_taints_in_args_taints args_taints =
  args_taints
  |> List.fold_left
       (fun acc arg ->
         match arg with
         | Named (_, (_, shape))
         | Unnamed (_, shape) ->
             Shape.gather_all_taints_in_shape shape |> Taints.union acc)
       Taints.empty

let any_is_best_sanitizer env any =
  env.func.taint_inst.preds.is_sanitizer any
  |> List.filter (fun (m : R.taint_sanitizer TM.t) ->
      (not m.spec.sanitizer_exact) || TM.is_best_match env.func.best_matches m)

(* TODO: We could return source matches already split by `by-side-effect` here ? *)
let any_is_best_source ?(is_lval = false) env any =
  env.func.taint_inst.preds.is_source any
  |> List.filter (fun (m : R.taint_source TM.t) ->
      (* Remove sources that should match exactly but do not here. *)
      match m.spec.source_by_side_effect with
      | Only -> is_lval && TM.is_exact m
      (* 'Yes' should probably require an exact match like 'Only' but for
       *  backwards compatibility we keep it this way. *)
      | Yes
      | No ->
          (not m.spec.source_exact) || TM.is_best_match env.func.best_matches m)

let any_is_best_sink env any =
  env.func.taint_inst.preds.is_sink any
  |> List.filter (fun (tm : TP.sink TM.t) ->
      (* at-exit sinks are handled in 'check_tainted_at_exit_sinks' *)
      (not tm.spec.spec.sink_at_exit)
      && TM.is_best_match env.func.best_matches tm)

let orig_is_source (taint_inst : OSS_taint_rule_inst.t) orig =
  taint_inst.preds.is_source (any_of_orig orig)

let orig_is_best_source env orig : R.taint_source TM.t list =
  any_is_best_source env (any_of_orig orig)
[@@profiling]

let orig_is_sanitizer (taint_inst : OSS_taint_rule_inst.t) orig =
  taint_inst.preds.is_sanitizer (any_of_orig orig)

let orig_is_best_sanitizer env orig =
  any_is_best_sanitizer env (any_of_orig orig)
[@@profiling]

let orig_is_sink (taint_inst : OSS_taint_rule_inst.t) orig =
  taint_inst.preds.is_sink (any_of_orig orig)

let orig_is_best_sink env orig = any_is_best_sink env (any_of_orig orig)
[@@profiling]

let any_of_lval lval =
  match lval with
  | { rev_offset = { oorig; _ } :: _; _ } -> any_of_orig oorig
  | { base = Var var; rev_offset = [] } ->
      let _, tok = var.ident in
      G.Tk tok
  | { base = VarSpecial (_, tok); rev_offset = [] } -> G.Tk tok
  | { base = Mem e; rev_offset = [] } -> any_of_orig e.eorig

let lval_is_source env lval =
  any_is_best_source ~is_lval:true env (any_of_lval lval)

let lval_is_best_sanitizer env lval =
  any_is_best_sanitizer env (any_of_lval lval)

let lval_is_sink env lval =
  (* TODO: This should be = any_is_best_sink env (any_of_lval lval)
   *    but see tests/rules/TODO_taint_messy_sink. *)
  env.func.taint_inst.preds.is_sink (any_of_lval lval)
  |> List.filter (fun (tm : TP.sink TM.t) ->
      (* at-exit sinks are handled in 'check_tainted_at_exit_sinks' *)
      not tm.spec.spec.sink_at_exit)
[@@profiling]

let taints_of_matches env ~incoming sources =
  let control_sources, data_sources =
    sources
    |> List.partition (fun (m : R.taint_source TM.t) -> m.spec.source_control)
  in
  (* THINK: It could make sense to merge `incoming` with `control_incoming`, so
   * a control source could influence a data source and vice-versa. *)
  let data_taints =
    data_sources
    |> List.map (fun x -> (x.TM.spec_pm, x.spec))
    |> T.taints_of_pms ~incoming
  in
  let control_incoming = Lval_env.get_control_taints env.lval_env in
  let control_taints =
    control_sources
    |> List.map (fun x -> (x.TM.spec_pm, x.spec))
    |> T.taints_of_pms ~incoming:control_incoming
  in
  let lval_env = Lval_env.add_control_taints env.lval_env control_taints in
  (data_taints, lval_env)

let record_effects env new_effects =
  if not (List_.null new_effects) then
    env.effects_acc := Effects.add_list new_effects !(env.effects_acc)

let unify_mvars_sets options mvars1 mvars2 =
  let xs =
    List.fold_left
      (fun xs_opt (mvar, mval) ->
        let* xs = xs_opt in
        match List.assoc_opt mvar mvars2 with
        | None -> Some ((mvar, mval) :: xs)
        | Some mval' ->
            if Matching_generic.equal_ast_bound_code options mval mval' then
              Some ((mvar, mval) :: xs)
            else None)
      (Some []) mvars1
  in
  let ys =
    List.filter (fun (mvar, _) -> not @@ List.mem_assoc mvar mvars1) mvars2
  in
  Option.map (fun xs -> xs @ ys) xs

let sink_biased_union_mvars source_mvars sink_mvars =
  let source_mvars' =
    List.filter
      (fun (mvar, _) -> not @@ List.mem_assoc mvar sink_mvars)
      source_mvars
  in
  Some (source_mvars' @ sink_mvars)

(* Takes the bindings of multiple taint sources and filters the bindings ($MVAR, MVAL)
 * such that either $MVAR is bound by a single source, or all MVALs bounds to $MVAR
 * can be unified. *)
let merge_source_mvars (options : Rule_options.t) bindings =
  let flat_bindings = List_.flatten bindings in
  let bindings_tbl =
    flat_bindings
    |> List.map (fun (mvar, _) -> (mvar, None))
    |> List.to_seq |> Hashtbl.of_seq
  in
  flat_bindings
  |> List.iter (fun (mvar, mval) ->
      match Hashtbl.find_opt bindings_tbl mvar with
      | None ->
          (* This should only happen if we've previously found that
                there is a conflict between bound values at `mvar` in
                the sources.
             *)
          ()
      | Some None ->
          (* This is our first time seeing this value, let's just
                add it in.
             *)
          Hashtbl.replace bindings_tbl mvar (Some mval)
      | Some (Some mval') ->
          if not (Matching_generic.equal_ast_bound_code options mval mval') then
            Hashtbl.remove bindings_tbl mvar);
  (* After this, the only surviving bindings should be those where
     there was no conflict between bindings in different sources.
  *)
  bindings_tbl |> Hashtbl.to_seq |> List.of_seq
  |> List.filter_map (fun (mvar, mval_opt) ->
      match mval_opt with
      | None ->
          (* This actually shouldn't really be possible, every
                binding should either not exist, or contain a value
                if there's no conflict. But whatever. *)
          None
      | Some mval -> Some (mvar, mval))

(* Merge source's and sink's bound metavariables. *)
let merge_source_sink_mvars (options : Rule_options.t) source_mvars sink_mvars =
  if options.taint_unify_mvars then
    (* This used to be the default, but it turned out to be confusing even for
     * r2c's security team! Typically you think of `pattern-sources` and
     * `pattern-sinks` as independent. We keep this option mainly for
     * backwards compatibility, it may be removed later on if no real use
     * is found. *)
    unify_mvars_sets options source_mvars sink_mvars
  else
    (* The union of both sets, but taking the sink mvars in case of collision. *)
    sink_biased_union_mvars source_mvars sink_mvars

let partition_sources_by_side_effect sources_matches =
  sources_matches
  |> Either_.partition_either3 (fun (m : R.taint_source TM.t) ->
      match m.spec.source_by_side_effect with
      | R.Only -> Left3 m
      (* A 'Yes' should be a 'Yes' regardless of whether the match is exact...
       * Whether the match is exact or not is/should be taken into consideration
       * later on. Same as for 'Only'. But for backwards-compatibility we keep
       * it this way for now. *)
      | R.Yes when TM.is_exact m -> Middle3 m
      | R.Yes
      | R.No ->
          Right3 m)
  |> fun (only, yes, no) -> (`Only only, `Yes yes, `No no)

(*****************************************************************************)
(* Types *)
(*****************************************************************************)

let type_of_lval env lval =
  match lval with
  | { base = Var x; rev_offset = [] } ->
      Typing.resolved_type_of_id_info env.func.taint_inst.file.lang x.id_info
  | { base = _; rev_offset = { o = Dot fld; _ } :: _ } ->
      Typing.resolved_type_of_id_info env.func.taint_inst.file.lang fld.id_info
  | __else__ -> Type.NoType

let type_of_expr env e =
  match e.eorig with
  | SameAs eorig ->
      Typing.type_of_expr env.func.taint_inst.file.lang eorig |> fst
  | __else__ -> Type.NoType

(* We only check this at a few key places to avoid calling `type_of_expr` too
 * many times which could be bad for perf (but haven't properly benchmarked):
 * - assignments
 * - return's
 * - function calls and their actual arguments
 * TODO: Ideally we add an `e_type` field and have a type-inference pass to
 *  fill it in, so that every expression has its known type available without
 *  extra cost.
 *)
let must_drop_taints_if_bool_or_number (options : Rule_options.t) ty =
  match ty with
  | Type.(Builtin Bool) -> options.taint_assume_safe_booleans
  | Type.(Builtin (Int | Float | Number)) -> options.taint_assume_safe_numbers
  | __else__ -> false

(* Calls to 'type_of_expr' seem not to be cheap and even though we tried to limit the
 * number of these calls being made, doing them unconditionally caused a slowdown of
 * ~25% in a ~dozen repos in our stress-test-monorepo. We should just not call
 * 'type_of_expr' unless at least one of the taint_assume_safe_{booleans,numbers} has
 * been set, so rules that do not use these options remain unaffected. Long term we
 * should make type_of_expr less costly.
 *)
let check_type_and_drop_taints_if_bool_or_number env taints type_of_x x =
  if
    (env.func.taint_inst.options.taint_assume_safe_booleans
   || env.func.taint_inst.options.taint_assume_safe_numbers)
    && not (Taints.is_empty taints)
  then
    match type_of_x env x with
    | Type.Function (_, ty)
      when must_drop_taints_if_bool_or_number env.func.taint_inst.options ty ->
        Taints.empty
    | ty when must_drop_taints_if_bool_or_number env.func.taint_inst.options ty
      ->
        Taints.empty
    | __else__ -> taints
  else taints

(*****************************************************************************)
(* Labels *)
(*****************************************************************************)

(* This function is used to convert some taint thing we're holding
   to one which has been propagated to a new label.
   See [handle_taint_propagators] for more.
*)
let propagate_taint_to_label replace_labels label (taint : T.taint) =
  let new_orig =
    match (taint.orig, replace_labels) with
    (* if there are no replaced labels specified, we will replace
       indiscriminately
    *)
    | Src src, None -> T.Src { src with label }
    | Src src, Some replace_labels when List.mem src.T.label replace_labels ->
        T.Src { src with label }
    | ((Src _ | Var _) as orig), _ -> orig
  in
  { taint with orig = new_orig }

(*****************************************************************************)
(* Effects and signatures *)
(*****************************************************************************)

(* Potentially produces an effect from incoming taints + call traces to a sink.
   Note that, while this sink has a `requires` and incoming labels,
   we decline to solve this now!
   We will figure out how many actual Semgrep findings are generated
   when this information is used, later.
*)
let effects_of_tainted_sink (options : Rule_options.t) taints_with_traces
    (sink : Effect.sink) : Effect.t list =
  match taints_with_traces with
  | [] -> []
  | _ :: _ -> (
      (* We cannot check whether we satisfy the `requires` here.
         This is because this sink may be inside of a function, meaning that
         argument taint can reach it, which can only be instantiated at the
         point where we call the function.
         So we record the `requires` within the taint finding, and evaluate
         the formula later, when we extract the PMs
      *)
      let taints_and_bindings =
        taints_with_traces
        |> List.map (fun ({ Effect.taint; _ } as item) ->
            let bindings =
              match taint.T.orig with
              | T.Src source ->
                  let src_pm, _ = T.pm_of_trace source.call_trace in
                  src_pm.env
              | Var _ -> []
            in
            (item, bindings))
      in
      (* If `unify_mvars` is set, then we will just do the previous behavior,
         and emit a finding for every single source coming into the sink.
         This will mean we don't regress on `taint_unify_mvars: true` rules.

         This is problematic because there may be many sources, all of which do not
         unify with each other, but which unify with the sink.
         If we did as below and unified them all with each other, we would sometimes
         produce no findings when we should.
      *)
      (* The same will happen if our sink does not have an explicit `requires`.

         This is because our behavior in the second case will remove metavariables
         from the finding, if they conflict in the sources.

         This can lead to a loss of metavariable interpolation in the finding message,
         even for "vanilla" taint mode rules that don't use labels, for instance if
         we had two instances of the source

         foo($X)

         reaching a sink, where in both instances, `$X` is not the same. The current
         behavior is that one of the `$X` bindings is chosen arbitrarily. We will
         try to keep this behavior here.
      *)
      if
        options.taint_unify_mvars || Option.is_none sink.rule_sink.sink_requires
      then
        taints_and_bindings
        |> List.filter_map (fun (t, bindings) ->
            let* merged_env =
              merge_source_sink_mvars options sink.pm.env bindings
            in
            Some (Effect.ToSink { taints_with_trace = [ t ]; sink; merged_env }))
      else
        match
          (* TODO(iago): I'm not sure we should be computing the `merged_env` here
              because at this point we still don't know if all the taint sources in
              'taints_and_bindings' are actually feasible (due to the 'requires').
              Perhaps we should only generate this 'merged_env' at the very end, in
              'matches_of_effect'. See SAF-1812  *)
          taints_and_bindings |> List.map snd |> merge_source_mvars options
          |> merge_source_sink_mvars options sink.pm.env
        with
        | None -> []
        | Some merged_env ->
            [
              Effect.ToSink
                {
                  taints_with_trace = List.map fst taints_and_bindings;
                  sink;
                  merged_env;
                };
            ])

(* Produces a finding for every unifiable source-sink pair. *)
let effects_of_tainted_sinks env taints sinks : Effect.t list =
  let taints =
    let control_taints = Lval_env.get_control_taints env.lval_env in
    taints |> Taints.union control_taints
  in
  if Taints.is_empty taints then []
  else
    sinks
    |> List.concat_map (fun sink ->
        (* This is where all taint effects start. If it's interproc,
              the call trace will be later augmented into the Call variant,
              but it starts out here as just a PM variant.
            *)
        let taints_with_traces =
          taints |> Taints.elements
          |> List.map (fun t ->
              { Effect.taint = t; sink_trace = T.PM (sink.Effect.pm, ()) })
        in
        effects_of_tainted_sink env.func.taint_inst.options taints_with_traces
          sink)

(*****************************************************************************)
(* Miscellaneous *)
(*****************************************************************************)

let sink_of_match lval_env (tm : TP.sink TM.t) =
  let requires, ok, lval_env =
    match tm.spec.requires with
    | UniReq precond -> (Effect.UniReq precond, `Ok, lval_env)
    | MultiReq mvars_w_preconds ->
        let rev_taints_w_preconds, ok, lval_env =
          mvars_w_preconds
          |> List.fold_left
               (fun (extra_req_acc, ok, lval_env) (var, precondition) ->
                 (* This is the destination/"to" point of the taints associated with the
                    metavariables in a "multi-requires". *)
                 let taints, lval_env =
                   Lval_env.find_taint_to_be_propagated var lval_env
                 in
                 match
                   T.solve_precondition ~ignore_poly_taint:false ~taints
                     precondition
                 with
                 | Some false -> ([], `Failed, lval_env)
                 | Some true ->
                     (* trivially true, we can just ignore *)
                     (extra_req_acc, ok, lval_env)
                 | None ->
                     (* cannot solve now, we need to keep it *)
                     ((taints, precondition) :: extra_req_acc, ok, lval_env))
               ([], `Ok, lval_env)
        in
        (Effect.MultiReq (List.rev rev_taints_w_preconds), ok, lval_env)
  in
  let sink =
    match ok with
    | `Ok -> Some { Effect.pm = tm.spec_pm; requires; rule_sink = tm.spec.spec }
    | `Failed -> None
  in
  (sink, lval_env)

let sinks_of_matches lval_env sinks =
  let rev_sinks, lval_env =
    sinks
    |> List.fold_left
         (fun (acc, lval_env) sink ->
           let opt_sink, lval_env = sink_of_match lval_env sink in
           let acc =
             match opt_sink with
             | None -> acc
             | Some sink -> sink :: acc
           in
           (acc, lval_env))
         ([], lval_env)
  in
  (List.rev rev_sinks, lval_env)

let record_effects_of_tainted_sinks env taints sinks =
  let sinks, lval_env = sinks_of_matches env.lval_env sinks in
  (if not (List_.null sinks) then
     let effects =
       effects_of_tainted_sinks { env with lval_env } taints sinks
     in
     record_effects { env with lval_env } effects);
  lval_env

let check_orig_if_sink env ?filter_sinks orig taints shape =
  (* NOTE(gather-all-taints):
   * A sink is something opaque to us, e.g. consider sink(["ok", "tainted"]),
   * `sink` could potentially access "tainted". So we must take into account
   * all taints reachable through its shape.
   *)
  let taints =
    taints |> Taints.union (Shape.gather_all_taints_in_shape shape)
  in
  let sinks = orig_is_best_sink env orig in
  let sinks =
    match filter_sinks with
    | None -> sinks
    | Some sink_pred -> sinks |> List.filter sink_pred
  in
  record_effects_of_tainted_sinks env taints sinks

let fix_poly_taint_with_field lval xtaint =
  match xtaint with
  | `Sanitized
  | `Clean
  | `None ->
      xtaint
  | `Tainted taints -> (
      match lval.rev_offset with
      | o :: _ ->
          let o = T.offset_of_IL o in
          let taints = Shape.fix_poly_taint_with_offset [ o ] taints in
          `Tainted taints
      | [] -> xtaint)

(*****************************************************************************)
(* Tainted *)
(*****************************************************************************)

let sanitize_lval_by_side_effect lval_env sanitizer_pms lval =
  let lval_is_now_safe =
    (* If the l-value is an exact match (overlap > 0.99) for a sanitizer
     * annotation, then we infer that the l-value itself has been updated
     * (presumably by side-effect) and is no longer tainted. We will update
     * the environment (i.e., `lval_env') accordingly. *)
    List.exists
      (fun (m : R.taint_sanitizer TM.t) ->
        m.spec.sanitizer_by_side_effect && TM.is_exact m)
      sanitizer_pms
  in
  if lval_is_now_safe then Lval_env.clean lval_env lval else lval_env

(* Check if an expression is sanitized, if so returns `Some' and otherise `None'.
   If the expression is of the form `x.a.b.c` then we try to sanitize it by
   side-effect, in which case this function will return a new lval_env. *)
let exp_is_sanitized env exp =
  match orig_is_best_sanitizer env exp.eorig with
  (* See NOTE [is_sanitizer] *)
  | [] -> None
  | sanitizer_pms -> (
      match exp.e with
      | Fetch lval ->
          Some (sanitize_lval_by_side_effect env.lval_env sanitizer_pms lval)
      | __else__ -> Some env.lval_env)

(* Checks if `thing' is a propagator's `from' and if so propagates `taints' through it.
   Checks if `thing` is a propagator's `to' and if so fetches any taints that had been
   previously propagated. Returns *only* the newly propagated taint. *)
let handle_taint_propagators env thing taints shape =
  let taints =
    taints |> Taints.union (Shape.gather_all_taints_in_shape shape)
  in
  let lval_env = env.lval_env in
  let propagators =
    let any =
      match thing with
      | `Lval lval -> any_of_lval lval
      | `Exp exp -> any_of_orig exp.eorig
      | `Call call -> any_of_orig call.corig
      | `Ins ins -> any_of_orig ins.iorig
    in
    env.func.taint_inst.preds.is_propagator any
  in
  let propagate_froms, propagate_tos =
    List.partition (fun p -> p.TM.spec.TP.kind =*= `From) propagators
  in
  let ready_to_propagate, lval_env =
    (* `thing` is the source (the "from") of propagation, we add its taints to
     * the environment. *)
    List.fold_left
      (fun (ready, lval_env) prop ->
        (* Only propagate if the current set of taint labels can satisfy the
           propagator's requires precondition.
        *)
        (* TODO(brandon): Interprocedural propagator labels
           This is trickier than I thought. You have to augment the Arg taints
           with preconditions as well, and allow conjunction, because when you
           replace an Arg taint with a precondition, all the produced taints
           inherit the precondition. There's not an easy way to express this
           in the type right now.

           More concretely, the existence of labeled propagators means that
           preconditions can be attached to arbitrary taint. This is because
           if we have a taint that is being propagated with a `requires`, then
           that taint now has a precondition on that `requires` being true. This
           taint might also be an `Arg` taint, meaning that `Arg` taints can
           have preconditions.

           This is more than just a simple type-level change because when `Arg`s
           have preconditions, what happens for substitution? Say I want to
           replace an `Arg x` taint with [t], that is, a single taint. Well,
           that taint `t` might itself have a precondition. That means that we
           now have a taint which is `t`, substituted for `Arg x`, but also
           inheriting `Arg x`'s precondition. Our type for preconditions doesn't
           allow arbitrary conjunction of preconditions like that, so this is
           more pervasive of a change.

           I'll come back to this later.
        *)
        match
          T.solve_precondition ~ignore_poly_taint:false ~taints
            (TP.get_propagator_precondition prop.TM.spec)
        with
        | Some true ->
            (* If we have an output label, change the incoming taints to be
               of the new label.
               Otherwise, keep them the same.
            *)
            let new_taints =
              match prop.TM.spec.prop_label with
              | None -> taints
              | Some label ->
                  Taints.map
                    (propagate_taint_to_label prop.spec.prop_replace_labels
                       label)
                    taints
            in
            let lval_env, is_ready =
              Lval_env.check_if_can_propagate_to_dest prop.spec.var new_taints
                lval_env
            in
            let ready =
              match is_ready with
              | `Recorded -> ready
              | `Ready -> VarMap.add prop.spec.var new_taints ready
            in
            (ready, lval_env)
        | Some false
        | None (* THINK: Let the unsolvable pass ? *) ->
            (ready, lval_env))
      (VarMap.empty, lval_env) propagate_froms
  in
  let _PRO_only =
    (* In Pro: run_taint_propagations *)
    ready_to_propagate
  in
  let taints_propagated, lval_env =
    (* `thing` is the destination (the "to") of propagation. we collect all the
     * incoming taints by looking for the propagator ids in the environment. *)
    List.fold_left
      (fun (taints_in_acc, lval_env) prop ->
        let taints_from_prop, lval_env =
          Lval_env.find_taint_to_be_propagated prop.TM.spec.TP.var lval_env
        in
        let lval_env =
          if prop.spec.TP.prop_by_side_effect then
            match thing with
            | `Lval lval ->
                (* If `thing` is an l-value of the form `x.a.b.c`, then taint can be
                   propagated by side-effect. A pattern-propagator may use this to
                   e.g. propagate taint from `x` to `y` in `f(x,y)`, so that
                   subsequent uses of `y` are tainted if `x` was previously tainted. *)
                lval_env |> Lval_env.add_lval lval taints_from_prop
            | `Exp _
            | `Call _
            | `Ins _ ->
                lval_env
          else lval_env
        in
        (Taints.union taints_in_acc taints_from_prop, lval_env))
      (Taints.empty, lval_env) propagate_tos
  in
  (taints_propagated, lval_env)

let check_orig_sources_propagators_sinks env orig thing ~incoming_taints shape =
  let taint_sources, lval_env =
    orig_is_best_source env orig
    |> taints_of_matches
         { env with lval_env = env.lval_env }
         ~incoming:incoming_taints
  in
  let taints = Taints.union incoming_taints taint_sources in
  let taints_propagated, lval_env =
    handle_taint_propagators { env with lval_env } thing taints shape
  in
  let taints = Taints.union taints taints_propagated in
  let lval_env = check_orig_if_sink { env with lval_env } orig taints shape in
  (taints, lval_env)

let find_lval_taint_sources env incoming_taints lval =
  let taints_of_pms env = taints_of_matches env ~incoming:incoming_taints in
  let source_pms = lval_is_source env lval in
  (* Partition sources according to the value of `by-side-effect:`,
   * either `only`, `yes`, or `no`. *)
  let ( `Only by_side_effect_only_pms,
        `Yes by_side_effect_yes_pms,
        `No by_side_effect_no_pms ) =
    partition_sources_by_side_effect source_pms
  in
  let by_side_effect_only_taints, lval_env =
    by_side_effect_only_pms
    (* We require an exact match for `by-side-effect` to take effect. *)
    |> List.filter TM.is_exact
    |> taints_of_pms env
  in
  let by_side_effect_yes_taints, lval_env =
    by_side_effect_yes_pms
    (* We require an exact match for `by-side-effect` to take effect. *)
    |> List.filter TM.is_exact
    |> taints_of_pms { env with lval_env }
  in
  let by_side_effect_no_taints, lval_env =
    by_side_effect_no_pms |> taints_of_pms { env with lval_env }
  in
  let taints_to_add_to_env =
    by_side_effect_only_taints |> Taints.union by_side_effect_yes_taints
  in
  let lval_env = lval_env |> Lval_env.add_lval lval taints_to_add_to_env in
  let taints_to_return =
    Taints.union by_side_effect_no_taints by_side_effect_yes_taints
  in
  (taints_to_return, lval_env)

let rec check_tainted_lval env (lval : IL.lval) :
    Taints.t * Shape.shape * [ `Sub of Taints.t * Shape.shape ] * Lval_env.t =
  let new_taints, lval_in_env, lval_shape, sub, lval_env =
    check_tainted_lval_aux env lval
  in
  let taints_from_env = Xtaint.to_taints lval_in_env in
  let taints = Taints.union new_taints taints_from_env in
  let taints =
    check_type_and_drop_taints_if_bool_or_number env taints type_of_lval lval
  in
  let sinks =
    lval_is_sink env lval
    |> List.filter (TM.is_best_match env.func.best_matches)
  in

  let lval_env =
    record_effects_of_tainted_sinks { env with lval_env } taints sinks
  in
  (taints, lval_shape, sub, lval_env)

(* Java: Whenever we find a getter/setter without definition we end up here,
 * this happens if the getter/setters are being autogenerated at build time,
 * as when you use Lombok. This function will "resolve" the getter/setter to
 * the corresponding property, and propagate taint to/from that property.
 * So that `o.getX()` returns whatever taints `o.x` has, and so `o.setX(E)`
 * propagates any taints in `E` to `o.x`. *)
and propagate_taint_via_java_getters_and_setters_without_definition env e args
    all_args_taints =
  match e with
  | {
   e =
     Fetch
       ({
          base = Var _obj;
          rev_offset =
            [ { o = Dot { IL.ident = method_str, method_tok; sid; _ }; _ } ];
        } as lval);
   _;
  }
  (* We check for the "get"/"set" prefix below. *)
    when env.func.taint_inst.file.lang =*= Lang.Java
         && String.length method_str > 3 -> (
      let mk_prop_lval () =
        (* e.g. getFooBar/setFooBar -> fooBar *)
        let prop_str =
          String.uncapitalize_ascii (Str.string_after method_str 3)
        in
        let prop_name =
          match
            Hashtbl.find_opt env.func.taint_inst.muts.java_props_cache
              (prop_str, sid)
          with
          | Some prop_name -> prop_name
          | None ->
              let mk_default_prop_name () =
                let prop_name =
                  {
                    ident = (prop_str, method_tok);
                    sid = G.SId.unsafe_default;
                    id_info = G.empty_id_info ();
                  }
                in
                Hashtbl.add env.func.taint_inst.muts.java_props_cache
                  (prop_str, sid) prop_name;
                prop_name
              in
              mk_default_prop_name ()
        in
        { lval with rev_offset = [ { o = Dot prop_name; oorig = NoOrig } ] }
      in
      match args with
      | [] when String.(starts_with ~prefix:"get" method_str) ->
          let taints, shape, _sub, lval_env =
            check_tainted_lval env (mk_prop_lval ())
          in
          Some (taints, shape, lval_env)
      | [ _ ] when String.starts_with ~prefix:"set" method_str ->
          if not (Taints.is_empty all_args_taints) then
            Some
              ( Taints.empty,
                Bot,
                env.lval_env
                |> Lval_env.add_lval (mk_prop_lval ()) all_args_taints )
          else Some (Taints.empty, Bot, env.lval_env)
      | __else__ -> None)
  | __else__ -> None

and check_tainted_lval_aux env (lval : IL.lval) :
    Taints.t
    * Xtaint.t_or_sanitized
    * Shape.shape
    * [ `Sub of Taints.t * Shape.shape ]
    * Lval_env.t =
  (* Recursively checks an l-value bottom-up.
   *
   *  This check needs to combine matches from pattern-{sources,sanitizers,sinks}
   *  with the info we have stored in `env.lval_env`. This can be subtle, see
   *  comments below.
   *)
  match lval_is_best_sanitizer env lval with
  (* See NOTE [is_sanitizer] *)
  (* TODO: We should check that taint and sanitizer(s) are unifiable. *)
  | _ :: _ as sanitizer_pms ->
      (* NOTE [lval/sanitized]:
       *  If lval is sanitized, then we will "bubble up" the `Sanitized status, so
       *  any taint recorded in lval_env for any extension of lval will be discarded.
       *
       *  So, if we are checking `x.a.b.c` and `x.a` is sanitized then any extension
       *  of `x.a` is considered sanitized as well, and we do look for taint info in
       *  the environment.
       *
       *  *IF* sanitization is side-effectful then any taint info will be removed
       *  from lval_env by sanitize_lval, but that is not guaranteed.
       *)
      let lval_env =
        sanitize_lval_by_side_effect env.lval_env sanitizer_pms lval
      in
      (Taints.empty, `Sanitized, Bot, `Sub (Taints.empty, Bot), lval_env)
  | [] ->
      (* Recursive call, check sub-lvalues first.
       *
       * It needs to be done bottom-up because any sub-lvalue can be a source and a
       * sink by itself, even if an extension of lval is not. For example, given
       * `x.a.b`, this lvalue may be considered sanitized, but at the same time `x.a`
       * could be tainted and considered a sink in some context. We cannot just check
       * `x.a.b` and forget about the sub-lvalues.
       *)
      let sub_new_taints, sub_in_env, sub_shape, lval_env =
        match lval with
        | { base; rev_offset = [] } ->
            (* Base case, no offset. *)
            check_tainted_lval_base env base
        | { base = _; rev_offset = _ :: rev_offset' } ->
            (* Recursive case, given `x.a.b` we must first check `x.a`. *)
            let sub_new_taints, sub_in_env, sub_shape, _sub_sub, lval_env =
              check_tainted_lval_aux env { lval with rev_offset = rev_offset' }
            in
            (sub_new_taints, sub_in_env, sub_shape, lval_env)
      in
      let sub_new_taints, sub_in_env =
        if env.func.taint_inst.options.taint_only_propagate_through_assignments
        then
          match sub_in_env with
          | `Sanitized -> (Taints.empty, `Sanitized)
          | `Clean
          | `None
          | `Tainted _ ->
              (Taints.empty, `None)
        else (sub_new_taints, sub_in_env)
      in
      (* Check the status of lval in the environemnt. *)
      let lval_in_env, lval_shape =
        match sub_in_env with
        | `Sanitized ->
            (* See NOTE [lval/sanitized] *)
            (`Sanitized, Shape.Bot)
        | (`Clean | `None | `Tainted _) as sub_xtaint ->
            let xtaint', shape =
              (* THINK: Should we just use 'Sig.find_in_shape' directly here ?
                       We have the 'sub_shape' available. *)
              match Lval_env.find_lval lval_env lval with
              | None -> (`None, Shape.Bot)
              | Some (Cell (xtaint', shape)) -> (xtaint', shape)
            in
            let xtaint' =
              match xtaint' with
              | (`Clean | `Tainted _) as xtaint' -> xtaint'
              | `None ->
                  (* HACK(field-sensitivity): If we encounter `obj.x` and `obj` has
                   * polymorphic taint, and we know nothing specific about `obj.x`, then
                   * we add the same offset `.x` to the polymorphic taint coming from `obj`.
                   * (See also 'propagate_taint_via_unresolved_java_getters_and_setters'.)
                   *
                   * For example, given `function foo(o) { sink(o.x); }`, and being '0 the
                   * polymorphic taint of `o`, this allows us to record that what goes into
                   * the sink is '0.x (and not just '0). So if later we encounter `foo(obj)`
                   * where `obj.y` is tainted but `obj.x` is not tainted, we will not
                   * produce a finding.
                   *)
                  fix_poly_taint_with_field lval sub_xtaint
            in
            (xtaint', shape)
      in
      let taints_from_env = Xtaint.to_taints lval_in_env in
      (* Find taint sources matching lval. *)
      let current_taints = Taints.union sub_new_taints taints_from_env in
      let taints_from_sources, lval_env =
        find_lval_taint_sources { env with lval_env } current_taints lval
      in
      (* Check sub-expressions in the offset. *)
      let taints_from_offset, lval_env =
        match lval.rev_offset with
        | [] -> (Taints.empty, lval_env)
        | offset :: _ -> check_tainted_lval_offset { env with lval_env } offset
      in
      (* Check taint propagators. *)
      let taints_incoming (* TODO: find a better name *) =
        if env.func.taint_inst.options.taint_only_propagate_through_assignments
        then taints_from_sources
        else
          sub_new_taints
          |> Taints.union taints_from_sources
          |> Taints.union taints_from_offset
      in
      let taints_propagated, lval_env =
        handle_taint_propagators { env with lval_env } (`Lval lval)
          (taints_incoming |> Taints.union taints_from_env)
          lval_shape
      in
      let taints_incoming =
        check_type_and_drop_taints_if_bool_or_number env taints_incoming
          type_of_lval lval
      in
      let new_taints = taints_incoming |> Taints.union taints_propagated in
      let sinks =
        lval_is_sink env lval
        (* For sub-lvals we require sinks to be exact matches. Why? Let's say
         * we have `sink(x.a)` and `x' is tainted but `x.a` is clean...
         * with the normal subset semantics for sinks we would consider `x'
         * itself to be a sink, and we would report a finding!
         *)
        |> List.filter TM.is_exact
      in
      let all_taints = Taints.union taints_from_env new_taints in
      let lval_env =
        record_effects_of_tainted_sinks { env with lval_env } all_taints sinks
      in
      ( new_taints,
        lval_in_env,
        lval_shape,
        `Sub (Xtaint.to_taints sub_in_env, sub_shape),
        lval_env )

and check_tainted_lval_base env base =
  match base with
  | Var _
  | VarSpecial _ ->
      (Taints.empty, `None, Bot, env.lval_env)
  | Mem { e = Fetch lval; _ } ->
      (* i.e. `*ptr` *)
      let taints, lval_in_env, shape, _sub, lval_env =
        check_tainted_lval_aux env lval
      in
      (taints, lval_in_env, shape, lval_env)
  | Mem e ->
      let taints, shape, lval_env = check_tainted_expr env e in
      (taints, `None, shape, lval_env)

and check_tainted_lval_offset env offset =
  match offset.o with
  | Dot _n ->
      (* THINK: Allow fields to be taint sources, sanitizers, or sinks ??? *)
      (Taints.empty, env.lval_env)
  | Index e ->
      let taints, _shape, lval_env = check_tainted_expr env e in
      let taints =
        if propagate_through_indexes env then taints
        else (* Taints from the index should be ignored. *)
          Taints.empty
      in
      (taints, lval_env)

(* Test whether an expression is tainted, and if it is also a sink,
 * report the finding too (by side effect). *)
and check_tainted_expr env exp : Taints.t * Shape.shape * Lval_env.t =
  let check env = check_tainted_expr env in
  let check_subexpr exp =
    match exp.e with
    | Fetch _
    (* TODO: 'Fetch' is handled specially, this case should not never be taken.  *)
    | Literal _
    | FixmeExp (_, _, None) ->
        (Taints.empty, Shape.Bot, env.lval_env)
    | FixmeExp (_, _, Some e) ->
        let taints, shape, lval_env = check env e in
        let taints =
          taints |> Taints.union (Shape.gather_all_taints_in_shape shape)
        in
        (taints, Shape.Bot, lval_env)
    | Composite ((CTuple | CArray | CList), (_, es, _)) ->
        let taints_and_shapes, lval_env = map_check_expr env check es in
        let tuple_shape = Shape.tuple_like_obj taints_and_shapes in
        (Taints.empty, tuple_shape, lval_env)
    | Composite ((CSet | Constructor _ | Regexp), (_, es, _)) ->
        let taints, lval_env = union_map_taints_and_vars env check es in
        (taints, Shape.Bot, lval_env)
    | Operator ((op, _), es) ->
        let args_taints, all_args_taints, lval_env =
          check_function_call_arguments env es
        in
        let all_args_taints =
          all_args_taints
          |> Taints.union (gather_all_taints_in_args_taints args_taints)
        in
        let all_args_taints =
          if
            env.func.taint_inst.options.taint_only_propagate_through_assignments
          then Taints.empty
          else all_args_taints
        in
        let op_taints =
          match op with
          | G.Eq
          | G.NotEq
          | G.PhysEq
          | G.NotPhysEq
          | G.Lt
          | G.LtE
          | G.Gt
          | G.GtE
          | G.Cmp
          | G.RegexpMatch
          | G.NotMatch
          | G.In
          | G.NotIn
          | G.Is
          | G.NotIs ->
              if env.func.taint_inst.options.taint_assume_safe_comparisons then
                Taints.empty
              else all_args_taints
          | G.And
          | G.Or
          | G.Xor
          | G.Not
          | G.LSL
          | G.LSR
          | G.ASR
          | G.BitOr
          | G.BitXor
          | G.BitAnd
          | G.BitNot
          | G.BitClear
          | G.Plus
          | G.Minus
          | G.Mult
          | G.Div
          | G.Mod
          | G.Pow
          | G.FloorDiv
          | G.MatMult
          | G.Concat
          | G.Append
          | G.Range
          | G.RangeInclusive
          | G.NotNullPostfix
          | G.Length
          | G.Elvis
          | G.Nullish
          | G.Background
          | G.Pipe
          | G.LDA
          | G.RDA
          | G.LSA
          | G.RSA ->
              all_args_taints
        in
        (op_taints, Shape.Bot, lval_env)
    | RecordOrDict fields ->
        (* TODO: Construct a proper record/dict shape here. *)
        let (lval_env, taints), taints_and_shapes =
          fields
          |> List.fold_left_map
               (fun (lval_env, taints_acc) field ->
                 match field with
                 | Field (id, e) ->
                     (* TODO: Check 'id' for taint? *)
                     let e_taints, e_shape, lval_env =
                       check { env with lval_env } e
                     in
                     ((lval_env, taints_acc), `Field (id, e_taints, e_shape))
                 | Spread e ->
                     let e_taints, e_shape, lval_env =
                       check { env with lval_env } e
                     in
                     ((lval_env, e_taints), `Spread e_shape)
                 | Entry (ke, ve) ->
                     let ke_taints, ke_shape, lval_env =
                       check { env with lval_env } ke
                     in
                     let taints_acc =
                       taints_acc |> Taints.union ke_taints
                       |> Taints.union
                            (Shape.gather_all_taints_in_shape ke_shape)
                     in
                     let ve_taints, ve_shape, lval_env =
                       check { env with lval_env } ve
                     in
                     ((lval_env, taints_acc), `Entry (ke, ve_taints, ve_shape)))
               (env.lval_env, Taints.empty)
        in
        let record_shape = Shape.record_or_dict_like_obj taints_and_shapes in
        (taints, record_shape, lval_env)
    | Cast (_, e) -> check env e
  in
  match exp_is_sanitized env exp with
  (* THINK: Can we just skip checking the subexprs in 'exp'? There could be a
   * sanitizer by-side-effect that will not trigger, see CODE-6548. E.g.
   * if `x` in `foo(x)` is supposed to be sanitized by-side-effect, but `foo(x)`
   * itself is sanitized, the by-side-effect sanitization of `x` will not happen.
   * Problem is, we do not want sources or propagators by-side-effect to trigger
   * on `x` if `foo(x)` is sanitized, so we would need to check the subexprs while
   * disabling taint sources.
   *)
  | Some lval_env ->
      (* TODO: We should check that taint and sanitizer(s) are unifiable. *)
      (Taints.empty, Bot, lval_env)
  | None -> (
      match exp.e with
      | Fetch lval ->
          let taints, shape, _sub, lval_env = check_tainted_lval env lval in
          let lval_env =
            check_orig_if_sink { env with lval_env } exp.eorig taints shape
          in
          (taints, shape, lval_env)
      | __else__ ->
          let taints_exp, shape, lval_env = check_subexpr exp in
          let taints, lval_env =
            check_orig_sources_propagators_sinks { env with lval_env } exp.eorig
              (`Exp exp) ~incoming_taints:taints_exp shape
          in
          (taints, shape, lval_env))

(* Check the actual arguments of a function call. This also handles left-to-right
 * taint propagation by chaining the 'lval_env's returned when checking the arguments.
 * For example, given `foo(x.a)` we'll check whether `x.a` is tainted or whether the
 * argument is a sink. *)
and check_function_call_arguments env args =
  let (rev_taints, lval_env), args_taints =
    args
    |> List.fold_left_map
         (fun (rev_taints, lval_env) arg ->
           let e = IL_helpers.exp_of_arg arg in
           let taints, shape, lval_env =
             check_tainted_expr { env with lval_env } e
           in
           let taints =
             check_type_and_drop_taints_if_bool_or_number env taints
               type_of_expr e
           in
           let new_acc = (taints :: rev_taints, lval_env) in
           match arg with
           | Unnamed _ -> (new_acc, Unnamed (taints, shape))
           | Named (id, _) -> (new_acc, Named (id, (taints, shape))))
         ([], env.lval_env)
  in
  let all_args_taints = List.fold_left Taints.union Taints.empty rev_taints in
  (args_taints, all_args_taints, lval_env)

and check_tainted_var env (var : IL.name) : Taints.t * Shape.shape * Lval_env.t
    =
  let taints, shape, _sub, lval_env =
    check_tainted_lval env (LV.lval_of_var var)
  in
  (taints, shape, lval_env)

and check_args_and_prop_their_taints env args =
  let args_taints, all_args_taints, lval_env =
    check_function_call_arguments env args
  in
  let all_args_taints =
    all_args_taints
    |> Taints.union (gather_all_taints_in_args_taints args_taints)
  in
  let all_args_taints =
    if env.func.taint_inst.options.taint_only_propagate_through_assignments then
      Taints.empty
    else all_args_taints
  in
  (all_args_taints, Shape.Bot, lval_env)

let check_function_call_callee env e =
  match e.e with
  | Fetch ({ base = _; rev_offset = _ :: _ } as lval) ->
      (* Method call <object ...>.<method>, the 'sub_taints' and 'sub_shape'
       * correspond to <object ...>. *)
      let taints, shape, `Sub (sub_taints, sub_shape), lval_env =
        check_tainted_lval env lval
      in
      let obj_taints =
        sub_taints |> Taints.union (Shape.gather_all_taints_in_shape sub_shape)
      in
      (`Obj obj_taints, taints, shape, lval_env)
  | __else__ ->
      let taints, shape, lval_env = check_tainted_expr env e in
      (`Fun, taints, shape, lval_env)

(* TODO: Move to Taint_lambdas *)
let mk_lambda_input_env env (lcfg : Fun_CFG.t) =
  (* We do some processing of the lambda parameters but it's mainly
   * to enable taint propagation, e.g.
   *
   *     obj.do_something(lambda x: sink(x))
   *
   * so we can propagate taint from `obj` to `x`.
   *)
  lcfg.params
  |> Fold_IL_params.fold
       (fun lval_env id id_info _pdefault ->
         let var = AST_to_IL.var_of_id_info id id_info in
         (* This is a *new* variable, so we clean any taint that we may have
            attached to it previously. This can happen when a lambda is called
            inside a loop. *)
         let lval_env = Lval_env.clean lval_env (LV.lval_of_var var) in
         (* Now check if the parameter is itself a taint source. *)
         let taints, shape, lval_env =
           check_tainted_var { env with lval_env } var
         in
         lval_env |> Lval_env.add_lval_shape (LV.lval_of_var var) taints shape)
       env.lval_env

let check_tainted_call env corig e args =
  let args_taints, all_args_taints, lval_env =
    check_function_call_arguments env args
  in
  let all_args_taints =
    all_args_taints
    |> Taints.union (gather_all_taints_in_args_taints args_taints)
  in
  let e_obj, e_taints, _e_shape, lval_env =
    check_function_call_callee { env with lval_env } e
  in
  (* NOTE(sink_has_focus):
   * After we made sink specs "exact" by default, we need this trick to
   * be backwards compatible wrt to specifications like `sink(...)`. Even
   * if the sink is "exact", if it has NO focus, then we consider that all
   * of the parameters of the function are sinks. So, even if
   * `taint_assume_safe_functions: true`, if the spec is `sink(...)`, we
   * still report `sink(tainted)`.
   *)
  let lval_env =
    check_orig_if_sink { env with lval_env } corig all_args_taints Bot
      ~filter_sinks:(fun m ->
        not (m.spec.spec.sink_exact && m.spec.spec.sink_has_focus))
  in
  let call_taints, shape, lval_env =
    let call_taints =
      if not (propagate_through_functions env) then Taints.empty
      else
        (* Otherwise assume that the function will propagate
         * the taint of its arguments. *)
        all_args_taints
    in
    match
      propagate_taint_via_java_getters_and_setters_without_definition
        { env with lval_env } e args all_args_taints
    with
    | Some (getter_taints, _TODOshape, lval_env) ->
        (* HACK: Java: If we encounter `obj.setX(arg)` we interpret it as
         * `obj.x = arg`, if we encounter `obj.getX()` we interpret it as
         * `obj.x`. *)
        let call_taints = Taints.union call_taints getter_taints in
        (call_taints, Shape.Bot, lval_env)
    | None ->
        (* We have no taint signature and it's neither a get/set method. *)
        if not (propagate_through_functions env) then
          (Taints.empty, Shape.Bot, lval_env)
        else
          (* If this is a method call, `o.method(...)`, then we fetch the
           * taint of the callee object `o`. This is a conservative worst-case
           * asumption that any taint in `o` can be tainting the call's effect. *)
          let call_taints =
            match e_obj with
            | `Fun -> call_taints
            | `Obj obj_taints -> call_taints |> Taints.union obj_taints
          in
          (call_taints, Shape.Bot, lval_env)
  in
  (* We add the taint of the function itselt (i.e., 'e_taints') too. *)
  let all_call_taints =
    if env.func.taint_inst.options.taint_only_propagate_through_assignments then
      call_taints
    else Taints.union e_taints call_taints
  in
  let all_call_taints =
    check_type_and_drop_taints_if_bool_or_number env all_call_taints
      type_of_expr e
  in
  (all_call_taints, shape, lval_env)

(* Test whether an instruction is tainted, and if it is also a sink,
 * report the effect too (by side effect). *)
let check_tainted_instr env instr : Taints.t * Shape.shape * Lval_env.t =
  let check_instr = function
    | Assign (_, e) ->
        let taints, shape, lval_env = check_tainted_expr env e in
        let taints =
          check_type_and_drop_taints_if_bool_or_number env taints type_of_expr e
        in
        (taints, shape, lval_env)
    | AssignCall (_, { c = Call (e, args); corig }) ->
        check_tainted_call env corig e args
    | AssignCall (_, { c = CallSpecial (_, args); _ }) ->
        check_args_and_prop_their_taints env args
    | New (_lval, _ty, _constructor, args) ->
        check_args_and_prop_their_taints env args
    | FixmeInstr _ -> (Taints.empty, Bot, env.lval_env)
  in
  let sanitizer_pms = orig_is_best_sanitizer env instr.iorig in
  match sanitizer_pms with
  (* See NOTE [is_sanitizer] *)
  | _ :: _ ->
      (* TODO: We should check that taint and sanitizer(s) are unifiable. *)
      (Taints.empty, Bot, env.lval_env)
  | [] ->
      let taints_instr, rhs_shape, lval_env = check_instr instr.i in
      let taints, lval_env =
        (* Check calls inpdendently of the LHS. *)
        match instr.i with
        | AssignCall (_, call) ->
            check_orig_sources_propagators_sinks { env with lval_env }
              call.corig (`Call call) ~incoming_taints:taints_instr rhs_shape
        | __else__ -> (taints_instr, lval_env)
      in
      let taints, lval_env =
        (* Check the whole instruction, for assignments this includes the LHS. *)
        check_orig_sources_propagators_sinks { env with lval_env } instr.iorig
          (`Ins instr) ~incoming_taints:taints rhs_shape
      in
      let taints =
        match LV.lval_of_instr_opt instr with
        | None -> taints
        | Some lval ->
            check_type_and_drop_taints_if_bool_or_number env taints type_of_lval
              lval
      in
      (taints, rhs_shape, lval_env)
[@@profiling]

(* Test whether a `return' is tainted, and if it is also a sink,
 * report the effect too (by side effect). *)
let check_tainted_return env tok e : Taints.t * Shape.shape * Lval_env.t =
  let sinks =
    any_is_best_sink env (G.Tk tok) @ orig_is_best_sink env e.eorig
    |> List.filter (TM.is_best_match env.func.best_matches)
  in
  let taints, shape, lval_env = check_tainted_expr env e in
  let taints =
    (* TODO: Clean shape as well based on type ? *)
    check_type_and_drop_taints_if_bool_or_number { env with lval_env } taints
      type_of_expr e
  in
  let lval_env =
    record_effects_of_tainted_sinks { env with lval_env } taints sinks
  in
  (taints, shape, lval_env)

(* Check taint for a pattern case and bind pattern variables to the scrutinee's taint *)
let check_tainted_case env scrutinee pattern : Lval_env.t =
  (* Get taint from the scrutinee *)
  let taints, shape, _sub, lval_env =
    check_tainted_lval env (IL_helpers.lval_of_var scrutinee)
  in
  let taints =
    taints |> Taints.union (Shape.gather_all_taints_in_shape shape)
  in
  let bound_vars =
    match pattern with
    | PatLiteral _
    | PatWildcard ->
        (* Nothing to bind, so no taint to add. *)
        []
    | PatVariable var -> [ var ]
    | PatConstructor (_ctor, args) -> args
  in
  List.fold_left
    (fun env arg ->
      env |> Lval_env.add_lval { base = Var arg; rev_offset = [] } taints)
    lval_env bound_vars

(*****************************************************************************)
(* Transfer *)
(*****************************************************************************)

let input_env ~enter_env ~(flow : F.cfg) mapping ni =
  let node = Int_map.find ni flow.graph#nodes in
  match node.F.n with
  | Enter -> enter_env
  | _else -> (
      let pred_envs =
        CFG.predecessors flow ni
        |> List.map (fun (pi, _) -> mapping.(pi).D.out_env)
      in
      match pred_envs with
      | [] -> Lval_env.empty
      | [ penv ] -> penv
      | penv1 :: penvs -> List.fold_left Lval_env.union penv1 penvs)
[@@profiling]

let rec transfer : env -> fun_cfg:Fun_CFG.t -> Lval_env.t D.transfn =
 fun enter_env ~fun_cfg
     (* the transfer function to update the mapping at node index ni *)
       mapping ni ->
  let flow = fun_cfg.cfg in
  (* DataflowX.display_mapping flow mapping show_tainted; *)
  let in' : Lval_env.t =
    input_env ~enter_env:enter_env.lval_env ~flow mapping ni
  in
  let node = Int_map.find ni flow.graph#nodes in
  let env = { enter_env with lval_env = in' } in
  let out' : Lval_env.t =
    match node.F.n with
    | NInstr x -> transfer_instr env x
    | NCond (_tok, e)
    | NThrow (_tok, e) ->
        let _taints, _shape, lval_env' = check_tainted_expr env e in
        lval_env'
    | NReturn (tok, e) ->
        (* TODO: Move most of this to check_tainted_return. *)
        let _taints, _shape, lval_env' = check_tainted_return env tok e in
        lval_env'
    | NCase (scrutinee, pattern) -> check_tainted_case env scrutinee pattern
    (* Do nothing here - pattern bindings are handled in NCase *)
    | NMatch _
    | NNestedDef _
    | NGoto _
    | Enter
    | Exit
    | TrueNode _
    | FalseNode _
    | Join
    | NOther _
    | NTodo _ ->
        in'
  in
  let effects_lambdas, out' =
    check_for_lambdas { env with lval_env = out' } node
  in
  env.effects_acc := Effects.union effects_lambdas !(env.effects_acc);
  (* In Pro: check taints at exit *)
  Log.debug (fun m ->
      m ~tags:transfer_tag
        "(OSS) Taint transfer %s%s\n  %s:\n  IN:  %s\n  OUT: %s\n~~~~~"
        (Option.map IL.str_of_name env.func.fname ||| "<FUN>")
        (Option.map
           (fun lname -> spf "(in lambda %s)" (IL.str_of_name lname))
           env.in_lambda
        ||| "")
        (Display_IL.short_string_of_node node)
        (Lval_env.to_string in') (Lval_env.to_string out'));
  { D.in_env = in'; out_env = out' }

and transfer_instr env x =
  let opt_lval = LV.lval_of_instr_opt x in
  let var_was_touched = ref false in
  let var_was_touched_callback =
    match Option.bind opt_lval Lval_env.normalize_lval with
    | None -> Fun.const ()
    | Some (var, _offset) ->
        fun var' -> if IL.equal_name var' var then var_was_touched := true
  in
  let (taints, shape), lval_env =
    Lval_env.track_if_var_was_touched___do_not_nest env.lval_env
      ~callback:var_was_touched_callback (fun lval_env ->
        let taints, shape, lval_env =
          check_tainted_instr { env with lval_env } x
        in
        let lval_env =
          match opt_lval with
          | Some lval ->
              (* We call `check_tainted_lval` here because the assigned `lval`
                  itself could be annotated as a source of taint. *)
              let taints, lval_shape, _sub, lval_env =
                check_tainted_lval { env with lval_env } lval
              in
              let lval_env' =
                (* If the lval is a sink, we check if the whole instruction is
                   also a sink, and if so the taints from the `lval` could make
                   a finding. If not, we don't do to do anything, since
                   'check_tainted_instr' already checks the instruction without
                   the 'lval'. *)
                match lval_is_sink env lval with
                | [] -> lval_env
                | _ :: _ ->
                    check_orig_if_sink { env with lval_env } x.iorig taints
                      lval_shape
              in
              lval_env'
          | None -> lval_env
        in
        ((taints, shape), lval_env))
  in
  let lval_env =
    match opt_lval with
    | Some lval ->
        if Shape.taints_and_shape_are_relevant taints shape then
          (* Instruction returns tainted data, add taints to lval.
               See [Taint_lval_env] for details. *)
          lval_env |> Lval_env.add_lval_shape lval taints shape
        else if
          (* NOTE "auto-cleaning taint"

              If we have `x = E` and `E` has no taint, we want to clean
              `x`. However, taint could be propagating by side-effect even
              if `E` is "clean". So, we need to check whether the taints of
              `x` have been "touched" during taint inference (even if they
              did not really change). If they did, we cannot clean it. *)
          !var_was_touched
        then
          (* The taint of 'lval' was touched, so there was a source,
                  sanitizer, or propagator, acting by side-effect on this
                  instruction. Thus we do NOT do anything more here. *)
          lval_env
        else
          (* No side-effects on 'lval', and the instruction returns safe data,
                  so we assume that the assigment acts as a sanitizer and therefore
                  remove taints from lval. See [Taint_lval_env] for details. *)
          Lval_env.clean lval_env lval
    | None ->
        (* Instruction returns 'void' or its return value is ignored. *)
        lval_env
  in
  lval_env

(* In OSS, lambdas are mostly treated like statement blocks, that is, we
 * check the body of the lambda at the place where it is called, but we
 * do not "connect" actual arguments with formals, nor we track if the
 * lambda returns any taint.
 *
 * TODO: In Pro we should do inter-procedural analysis here. *)
and check_for_lambdas env node =
  let node_is_call =
    (* See 'out_env' below. *)
    match node.F.n with
    | NInstr i -> (
        match i.i with
        | AssignCall _
        | New _ ->
            true
        | Assign _
        | FixmeInstr _ ->
            false)
    | __else__ -> false
  in
  (* We visit lambdas at their "use" site (where they are fetched), so we can e.g.
   * propagate taint from an object receiving a method call, to a lambda being
   * passed to that method. *)
  let lambdas_to_analyze =
    Taint_lambdas.find_lambdas_to_analyze_in_node env.lambdas node
  in
  let num_lambdas = List.length lambdas_to_analyze in
  if num_lambdas > 0 then
    Log.debug (fun m ->
        m "There are %d lambda(s) occurring in: %s" num_lambdas
          (Display_IL.short_string_of_node node));
  let effects_lambdas, out_envs_lambdas =
    lambdas_to_analyze
    |> List.map (fun (lambda_name, lambda_cfg) ->
        do_lambda env ~is_call:node_is_call lambda_name lambda_cfg)
    |> List_.split
  in
  let effects = Effects.union_list effects_lambdas in
  let out_env = Lval_env.union_list ~default:env.lval_env out_envs_lambdas in
  (effects, out_env)

and do_lambda env ~is_call name cfg =
  let effects, out_env =
    let lambda_input_env = mk_lambda_input_env env cfg in
    fixpoint_lambda env.func env.lambdas name cfg lambda_input_env
  in
  let out_env =
    if is_call then
      (* We only take the side-effects of the lambda into consideration if the
       * node is a call, so the lambda is either the callee or one of its arguments.
       * E.g.
       *
       *     do_something([]() { taint(p) });
       *     sink(p) // finding wanted
       *
       * We assume that these lambdas are being evaluated and that their side-effects
       * should affect the subsequent statements.
       *)
      out_env |> Lval_env.union env.lval_env
    else
      (* If lambdas are not part of a call, we don't make their side-effects visible.
       * E.g.
       *
       *     void test(int *p) {
       *       auto f1 = [&p]() {
       *         source(p);
       *       };
       *       auto f2 = [&p]() {
       *         sink(p); // NO finding wanted
       *       };
       *     }
       *)
      env.lval_env
  in
  (effects, out_env)

and fixpoint_lambda func lambdas lambda_name lambda_cfg in_env :
    Effects.t * Lval_env.t =
  Log.debug (fun m ->
      m "Analyzing lambda %s (%s)"
        (IL.str_of_name lambda_name)
        (Lval_env.to_string in_env));
  let effects, mapping =
    fixpoint_aux func ~lambdas ~enter_lval_env:in_env
      ~in_lambda:(Some lambda_name) lambda_cfg
  in
  (* CE's only effect is 'ToSink', and a 'ToSink' found inside a
     lambda is still a real sink hit for the enclosing function. *)
  let out_env = mapping.(lambda_cfg.cfg.exit).Dataflow_core.out_env in
  let needed_vars = Taint_lambdas.live_vars_needed_for_taint lambdas in
  let out_env' =
    out_env
    |> Lval_env.filter_tainted (fun var -> IL.NameSet.mem var needed_vars)
  in
  Log.debug (fun m ->
      m ~tags:transfer_tag "Lambda out_env %s --FILTER(%s)--> %s"
        (Lval_env.to_string out_env)
        (IL.NameSet.show needed_vars)
        (Lval_env.to_string out_env'));
  (effects, out_env')

and fixpoint_aux func ~lambdas ~enter_lval_env ~in_lambda fun_cfg =
  let flow = fun_cfg.cfg in
  let init_mapping = DataflowX.new_node_array flow Lval_env.empty_inout in
  let env =
    {
      func;
      in_lambda;
      lambdas =
        (match in_lambda with
        | None -> lambdas
        | Some name -> Taint_lambdas.push lambdas name fun_cfg);
      lval_env = enter_lval_env;
      effects_acc = ref Effects.empty;
    }
  in
  (* THINK: Why I cannot just update mapping here ? if I do, the mapping gets overwritten later on! *)
  (* DataflowX.display_mapping flow init_mapping show_tainted; *)
  let end_mapping, timeout =
    let fp_timeout = Limits_semgrep.taint_FIXPOINT_TIMEOUT in
    DataflowX.fixpoint ~timeout:fp_timeout ~eq_env:Lval_env.equal
      ~init:init_mapping ~trans:(transfer env ~fun_cfg) ~forward:true ~flow
  in
  record_timeout env.func.taint_inst env.func.fname timeout;
  (* In Pro: check taints at exit *)
  (!(env.effects_acc), end_mapping)

(*****************************************************************************)
(* Entry point *)
(*****************************************************************************)

and (fixpoint :
      OSS_taint_rule_inst.t ->
      ?in_env:Lval_env.t ->
      ?name:IL.name ->
      Fun_CFG.t ->
      Effects.t * mapping) =
 fun taint_inst ?(in_env = Lval_env.empty) ?name:opt_name fun_cfg ->
  let best_matches =
    (* Here we compute the "canonical" or "best" source/sanitizer/sink matches,
     * for each source/sanitizer/sink we check whether there is a "best match"
     * among all the potential matches in the CFG.
     * See NOTE "Best matches" *)
    fun_cfg
    |> TM.best_matches_in_nodes ~sub_matches_of_orig:(fun orig ->
        let sources =
          orig_is_source taint_inst orig
          |> List.to_seq
          |> Seq.filter (fun (m : R.taint_source TM.t) -> m.spec.source_exact)
          |> Seq.map (fun m -> TM.Any m)
        in
        let sanitizers =
          orig_is_sanitizer taint_inst orig
          |> List.to_seq
          |> Seq.filter (fun (m : R.taint_sanitizer TM.t) ->
              m.spec.sanitizer_exact)
          |> Seq.map (fun m -> TM.Any m)
        in
        let sinks =
          orig_is_sink taint_inst orig
          |> List.to_seq
          |> Seq.filter (fun (m : TP.sink TM.t) -> m.spec.spec.sink_exact)
          |> Seq.map (fun m -> TM.Any m)
        in
        sources |> Seq.append sanitizers |> Seq.append sinks)
  in
  let func = { taint_inst; fname = opt_name; best_matches } in
  let lambdas = Taint_lambdas.new_env fun_cfg in
  fixpoint_aux func ~enter_lval_env:in_env ~lambdas ~in_lambda:None fun_cfg
[@@profiling]

let fixpoint taint_inst ?in_env ?name fun_cfg =
  fixpoint taint_inst ?in_env ?name fun_cfg
[@@profiling]
