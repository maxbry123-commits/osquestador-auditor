(* Iago Abal
 *
 * Copyright (C) 2022-2024 Semgrep Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation, with the
 * special exception on linking described in file LICENSE.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the file
 * LICENSE for more details.
 *)
open Common
module G = AST_generic
module H = AST_generic_helpers
module T = Taint
module Effects = OSS_taint_effects.Effects
module Log = Log_tainting.Log
module Lval_env = OSS_taint_lval_env

(** Analyze [stmts] (which should assign to [name]) under [env] to determine
    what taint flows into [name]. *)
let check_var_def (taint_inst : OSS_taint_rule_inst.t) env (name : IL.name)
    (stmts : IL.stmt list) =
  let lval : IL.lval = { base = Var name; rev_offset = [] } in
  let cfg, lambdas = CFG_build.cfg_of_stmts stmts in
  Log.debug (fun m ->
      m
        "Taint_input_env:\n\
         --------------------\n\
         Checking var def %s\n\
         --------------------"
        (fst name.ident));
  let effects, end_mapping =
    (* There could be taint effects indeed, e.g. if the stmts amount to `sink(taint)`. *)
    OSS_dataflow_tainting.fixpoint taint_inst ~in_env:env
      Fun_CFG.{ params = []; fdef = None; cfg; lambdas }
  in
  let out_env = end_mapping.(cfg.exit).Dataflow_core.out_env in
  let xtaint = Lval_env.find_lval_xtaint out_env lval in
  (xtaint, effects)

let mk_assign_stmt (name : IL.name) (exp : IL.exp) : IL.stmt =
  let lval : IL.lval = { base = Var name; rev_offset = [] } in
  { IL.s = IL.Instr { i = IL.Assign (lval, exp); iorig = IL.NoOrig } }

let stmts_of_param_default (name : IL.name) (pd : IL.param_default) :
    IL.stmt list =
  pd.dinit @ [ mk_assign_stmt name pd.dexp ]

let stmts_of_global_expr (taint_inst : OSS_taint_rule_inst.t) id ii
    (expr : G.expr) : IL.stmt list =
  let assign =
    G.Assign (G.N (G.Id (id, ii)) |> G.e, Tok.fake_tok (snd id) "=", expr)
    |> G.e |> G.exprstmt
  in
  AST_to_IL.stmt taint_inst.file.lang assign

let add_to_env_aux (taint_inst : OSS_taint_rule_inst.t) env id ii
    (opt_stmts : IL.stmt list option) =
  let var = AST_to_IL.var_of_id_info id ii in
  let var_type =
    Typing.resolved_type_of_id_info taint_inst.file.lang var.id_info
  in
  let id_taints =
    taint_inst.preds.is_source (G.Tk (snd id))
    |> List.map (fun (x : _ Taint_spec_match.t) -> (x.spec_pm, x.spec))
    (* These sources come from the parameters to a function,
        which are not within the normal control flow of a code.
        We can safely say there's no incoming taints to these sources.
    *)
    |> T.taints_of_pms ~incoming:T.Taint_set.empty
  in
  let expr_taints, expr_effects =
    match opt_stmts with
    | Some stmts ->
        let xtaint, effects = check_var_def taint_inst env var stmts in
        (Xtaint.to_taints xtaint, effects)
    | None -> (T.Taint_set.empty, Effects.empty)
  in
  let taints = id_taints |> T.Taint_set.union expr_taints in
  let env =
    if
      OSS_dataflow_tainting.must_drop_taints_if_bool_or_number
        taint_inst.options var_type
    then env
    else env |> Lval_env.add_lval (IL_helpers.lval_of_var var) taints
  in
  (env, expr_effects)

let add_to_env taint_inst (env, effects) id id_info opt_default =
  let var = AST_to_IL.var_of_id_info id id_info in
  let opt_stmts = Option.map (stmts_of_param_default var) opt_default in
  let env, new_effects = add_to_env_aux taint_inst env id id_info opt_stmts in
  (env, Effects.union new_effects effects)

let add_global_to_env taint_inst (env, effects) id id_info opt_expr =
  let opt_stmts =
    Option.map (stmts_of_global_expr taint_inst id id_info) opt_expr
  in
  let env, new_effects = add_to_env_aux taint_inst env id id_info opt_stmts in
  (env, Effects.union new_effects effects)

let mk_fun_input_env taint_inst ?(glob_env = Lval_env.empty)
    (fparams : IL.param list) =
  let add_to_env = add_to_env taint_inst in
  fparams
  (* For each argument, check if it's a source and, if so, add it to the input
   * environment. *)
  |> Fold_IL_params.fold add_to_env (glob_env, Effects.empty)

let is_global (id_info : G.id_info) =
  let* kind, _sid = !(id_info.id_resolved) in
  Some (H.name_is_global kind)

let mk_file_env =
  let visitor =
    object (_self : 'self)
      inherit [_] G.iter_no_id_info as super

      method! visit_definition ((taint_inst, env) as venv) (entity, def_kind) =
        match (entity, def_kind) with
        | { name = EN (Id (id, id_info)); _ }, VarDef { vinit; _ }
          when IdFlags.is_final !(id_info.id_flags)
               && is_global id_info =*= Some true ->
            env := add_global_to_env taint_inst !env id id_info vinit
        | __else__ -> super#visit_definition venv (entity, def_kind)

      method! visit_Assign ((taint_inst, env) as venv) lhs tok expr =
        match lhs with
        | {
         e =
           ( N (Id (id, id_info))
           | DotAccess
               ( { e = N (IdSpecial (((This | Self), _), _)); _ },
                 _,
                 FN (Id (id, id_info)) ) );
         _;
        }
          when IdFlags.is_final !(id_info.id_flags)
               && is_global id_info =*= Some true ->
            env := add_global_to_env taint_inst !env id id_info (Some expr)
        | __else__ -> super#visit_Assign venv lhs tok expr
    end
  in
  fun taint_inst ast ->
    (* TODO: false positive *)
    (* nosemgrep: no-ref-declarations-at-top-scope *)
    let env = ref (Lval_env.empty, Effects.empty) in
    visitor#visit_program (taint_inst, env) ast;
    !env
