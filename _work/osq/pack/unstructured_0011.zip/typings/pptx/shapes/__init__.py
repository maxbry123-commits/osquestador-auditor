class Subshape: ...  # fmt: skip
