package com.xxl.job.core.constant;

/**
 * Created by xuxueli on 17/5/10.
 */
public class Const {

    // ---------------------- for openapi ----------------------

    /**
     * access token
     */
    public static final String XXL_JOB_ACCESS_TOKEN = "XXL-JOB-ACCESS-TOKEN";

    /**
     * app name
     */
    public static final String XXL_JOB_APPNAME = "XXL-JOB-APPNAME";


    // ---------------------- for registry ----------------------

    /**
     * registry beat interval, default 30s
     */
    public static final int BEAT_TIMEOUT = 30;

    /**
     * registry dead timeout, default 90s
     */
    public static final int DEAD_TIMEOUT = BEAT_TIMEOUT * 3;


    // ---------------------- for executor ----------------------

    /*
     * elegant shutdown wait seconds
     */
    public static final long ELEGANT_SHUTDOWN_WAITING_SECONDS = 5;

}
