# Support Joplin development

Joplin is an open source project, and your donations support [the developer](https://github.com/laurent22/). Developing quality applications mostly takes time, but there are also expenses, such as digital certificates to sign the applications, app store fees, hosting, as well as the hardware to develop and test a cross-platform app.

Most of all, your donation will make it possible to keep up the current development standards, and will bring new features and improvements to the app.

## Donations

Platform | Link
--- | ---
PayPal | [![Donate on PayPal](https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/badges/Donate-PayPal-green.svg)](https://www.paypal.com/donate/?hosted_button_id=WQCERTSSLCC7U) | 
GitHub Sponsor | [![Sponsor on GitHub](https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/badges/GitHub-Badge.svg)](https://github.com/sponsors/laurent22/)
Patreon | [![Become a patron](https://raw.githubusercontent.com/laurent22/joplin/dev/Assets/WebsiteAssets/images/badges/Patreon-Badge.svg)](https://www.patreon.com/joplin)
Liberapay | [![Donate using Liberapay](https://liberapay.com/assets/widgets/donate.svg)](https://liberapay.com/laurent22/donate)
Bank Transfer | **IBAN:** GB41 REVO 2301 2058 6000 84 <br>**BIC/SWIFT:** REVOGB21

## Other ways to support the development

Finally, there are other ways to support the development of Joplin:

- Consider rating the app on [Google Play](https://play.google.com/store/apps/details?id=net.cozic.joplin&utm_source=GitHub&utm_campaign=README&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1) or [App Store](https://itunes.apple.com/us/app/joplin/id1315599797).

- Vote for or review the app on [alternativeTo](https://alternativeto.net/software/joplin/about/) or [Product Hunt](https://www.producthunt.com/posts/joplin).

- [Help us test pre-releases](https://joplinapp.org/help/about/prereleases/).

- [Improve the Wikipedia article](https://en.wikipedia.org/wiki/Joplin_(software)).
