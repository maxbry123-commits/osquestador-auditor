declare module "pwacompat";
