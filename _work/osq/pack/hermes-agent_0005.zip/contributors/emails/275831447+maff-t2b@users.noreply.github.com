maff-t2b
