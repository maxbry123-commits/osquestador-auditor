kuangmi-bit
