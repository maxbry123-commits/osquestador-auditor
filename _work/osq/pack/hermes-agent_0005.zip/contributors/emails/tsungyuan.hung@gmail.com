S-Claw
