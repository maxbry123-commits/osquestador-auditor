Trantor-develops
