Bruce-anle
