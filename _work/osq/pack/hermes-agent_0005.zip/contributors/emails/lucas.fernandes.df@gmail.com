isfttr
