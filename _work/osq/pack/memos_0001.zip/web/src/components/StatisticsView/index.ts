export { default } from "./StatisticsView";
