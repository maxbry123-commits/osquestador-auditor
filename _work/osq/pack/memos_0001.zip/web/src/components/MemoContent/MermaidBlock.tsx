import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import { getThemeWithFallback, resolveTheme, setupSystemThemeListener } from "@/utils/theme";
import { extractCodeContent } from "./utils";

interface MermaidBlockProps {
  children?: React.ReactNode;
  className?: string;
}

type MermaidTheme = "default" | "dark";

const toMermaidTheme = (appTheme: string): MermaidTheme => (appTheme === "default-dark" ? "dark" : "default");

const formatErrorMessage = (err: unknown): string => {
  const msg = err instanceof Error ? err.message : "Failed to render diagram";
  if (/no diagram type detected/i.test(msg)) {
    return `${msg} — check that the diagram type is valid (e.g. sequenceDiagram, classDiagram, erDiagram)`;
  }
  return msg;
};

export const MermaidBlock = ({ children, className }: MermaidBlockProps) => {
  const { userGeneralSetting } = useAuth();
  const [svg, setSvg] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [systemThemeChange, setSystemThemeChange] = useState(0);

  const codeContent = extractCodeContent(children);
  const themePreference = getThemeWithFallback(userGeneralSetting?.theme);
  const currentTheme = useMemo(() => resolveTheme(themePreference), [themePreference, systemThemeChange]);

  // Re-resolve theme when OS preference changes (only relevant when using "system" theme)
  useEffect(() => {
    if (themePreference !== "system") return;
    return setupSystemThemeListener(() => setSystemThemeChange((n) => n + 1));
  }, [themePreference]);

  // Render diagram when content or theme changes
  useEffect(() => {
    if (!codeContent) {
      setSvg("");
      setError("");
      return;
    }

    let cancelled = false;

    const renderDiagram = async () => {
      try {
        const { default: mermaid } = await import("mermaid");
        // Text is measured against the final glyphs, so webfonts must be loaded
        // first. The Font Loading API is absent in some environments (jsdom).
        await document.fonts?.ready;
        if (cancelled) return;

        mermaid.initialize({
          startOnLoad: false,
          theme: toMermaidTheme(currentTheme),
          securityLevel: "strict",
          // Mermaid measures labels in a detached element at body level, but the
          // rendered SVG lands inside a <pre> (monospace). "inherit" resolves to
          // different fonts in those two places, sizing boxes too small for the
          // final glyphs — pin the font so measurement and display agree.
          fontFamily: getComputedStyle(document.body).fontFamily || "sans-serif",
          suppressErrorRendering: true,
        });

        const id = `mermaid-${Math.random().toString(36).substring(7)}`;
        const { svg: renderedSvg } = await mermaid.render(id, codeContent);
        if (cancelled) return;

        setSvg(renderedSvg);
        setError("");
      } catch (err) {
        if (cancelled) return;
        console.error("Failed to render mermaid diagram:", err);
        setSvg("");
        setError(formatErrorMessage(err));
      }
    };

    renderDiagram();

    return () => {
      cancelled = true;
    };
  }, [codeContent, currentTheme]);

  if (error) {
    return (
      <div className="w-full">
        <div className="text-sm text-destructive mb-2 whitespace-normal break-words">Mermaid Error: {error}</div>
        <code className="block language-mermaid whitespace-pre text-sm">{codeContent}</code>
      </div>
    );
  }

  if (!svg) return null;

  return (
    <div
      className={cn("mermaid-diagram w-full flex justify-center items-center my-2 overflow-x-auto", className)}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
};
