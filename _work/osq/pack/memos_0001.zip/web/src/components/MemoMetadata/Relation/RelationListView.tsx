import { LinkIcon, MilestoneIcon } from "lucide-react";
import { useMemo, useState } from "react";
import MetadataSection from "@/components/MemoMetadata/MetadataSection";
import type { MemoOriginScope } from "@/components/MemoView/navigation";
import { useNearViewport } from "@/hooks/useNearViewport";
import type { MemoRelation } from "@/types/proto/api/v1/memo_service_pb";
import { useTranslate } from "@/utils/i18n";
import RelationCard from "./RelationCard";
import { getRelationBuckets, getRelationMemo, getRelationMemoName, type RelationDirection } from "./relationHelpers";
import { useResolvedRelationMemos } from "./useResolvedRelationMemos";

interface RelationListViewProps {
  relations: MemoRelation[];
  currentMemoName?: string;
  parentPage?: string;
  parentScope?: MemoOriginScope;
  className?: string;
}

function RelationListView({ relations, currentMemoName, parentPage, parentScope, className }: RelationListViewProps) {
  const t = useTranslate();
  const [activeTab, setActiveTab] = useState<"referencing" | "referenced">("referencing");
  const { ref: viewportRef, isNearViewport } = useNearViewport<HTMLDivElement>();

  const { referencing: referencingRelations, referenced: referencedRelations } = useMemo(
    () => getRelationBuckets(relations, currentMemoName),
    [relations, currentMemoName],
  );

  const hasBothTabs = referencingRelations.length > 0 && referencedRelations.length > 0;
  const direction: RelationDirection = hasBothTabs ? activeTab : referencingRelations.length > 0 ? "referencing" : "referenced";
  const isReferencing = direction === "referencing";
  const icon = isReferencing ? LinkIcon : MilestoneIcon;
  const activeRelations = isReferencing ? referencingRelations : referencedRelations;
  const activeMemoNames = useMemo(
    () =>
      activeRelations.flatMap((relation) => {
        const memo = getRelationMemo(relation, direction);
        return memo?.name && !memo.snippet ? [memo.name] : [];
      }),
    [activeRelations, direction],
  );
  const resolvedMemos = useResolvedRelationMemos(activeMemoNames, { enabled: isNearViewport });

  if (referencingRelations.length === 0 && referencedRelations.length === 0) {
    return null;
  }

  return (
    <MetadataSection
      rootRef={viewportRef}
      className={className}
      icon={icon}
      title={isReferencing ? t("common.referencing") : t("common.referenced-by")}
      count={activeRelations.length}
      tabs={
        hasBothTabs
          ? [
              {
                id: "referencing",
                label: t("common.referencing"),
                count: referencingRelations.length,
                active: isReferencing,
                onClick: () => setActiveTab("referencing"),
              },
              {
                id: "referenced",
                label: t("common.referenced-by"),
                count: referencedRelations.length,
                active: !isReferencing,
                onClick: () => setActiveTab("referenced"),
              },
            ]
          : undefined
      }
      contentClassName="flex flex-col gap-0 p-1.5"
    >
      {activeRelations.map((relation) => {
        const memo = getRelationMemo(relation, direction);
        if (!memo) {
          return null;
        }
        return (
          <RelationCard
            key={getRelationMemoName(relation, direction)}
            memo={resolvedMemos[memo.name] ?? memo}
            parentPage={parentPage}
            parentScope={parentScope}
          />
        );
      })}
    </MetadataSection>
  );
}

export default RelationListView;
