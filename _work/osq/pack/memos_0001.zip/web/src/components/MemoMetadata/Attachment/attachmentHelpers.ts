import type { Attachment } from "@/types/proto/api/v1/attachment_service_pb";
import { getAttachmentType } from "@/utils/attachment";
import { formatFileSize, getFileTypeLabel } from "@/utils/format";

export interface AttachmentGroups {
  visual: Attachment[];
  audio: Attachment[];
  docs: Attachment[];
}

export interface AttachmentMetadata {
  fileTypeLabel: string;
  fileSizeLabel?: string;
}

export const isImageAttachment = (attachment: Attachment): boolean => getAttachmentType(attachment) === "image/*";
export const isVideoAttachment = (attachment: Attachment): boolean => getAttachmentType(attachment) === "video/*";
export const isAudioAttachment = (attachment: Attachment): boolean => getAttachmentType(attachment) === "audio/*";

export const separateAttachments = (attachments: Attachment[]): AttachmentGroups => {
  return attachments.reduce<AttachmentGroups>(
    (groups, attachment) => {
      if (isImageAttachment(attachment) || isVideoAttachment(attachment)) {
        groups.visual.push(attachment);
      } else if (isAudioAttachment(attachment)) {
        groups.audio.push(attachment);
      } else {
        groups.docs.push(attachment);
      }

      return groups;
    },
    {
      visual: [],
      audio: [],
      docs: [],
    },
  );
};

export const getAttachmentMetadata = (attachment: Attachment): AttachmentMetadata => ({
  fileTypeLabel: getFileTypeLabel(attachment.type),
  fileSizeLabel: attachment.size ? formatFileSize(Number(attachment.size)) : undefined,
});

// Audio elements render with preload="none" and no src so the feed fetches nothing;
// the source is bound on first play. getAttribute is compared (not .src, which
// reflects an absolute URL) so an already-bound source is not re-assigned.
export const toggleAudioPlayback = async (audio: HTMLAudioElement, sourceUrl: string, onPlayFailure: () => void): Promise<void> => {
  if (!audio.paused) {
    audio.pause();
    return;
  }

  if (audio.getAttribute("src") !== sourceUrl) {
    audio.setAttribute("src", sourceUrl);
  }

  try {
    await audio.play();
  } catch {
    onPlayFailure();
  }
};

export const formatAudioTime = (seconds: number): string => {
  if (!Number.isFinite(seconds) || seconds < 0) {
    return "0:00";
  }

  const rounded = Math.floor(seconds);
  const hours = Math.floor(rounded / 3600);
  const minutes = Math.floor((rounded % 3600) / 60);
  const secs = rounded % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  }

  return `${minutes}:${secs.toString().padStart(2, "0")}`;
};
