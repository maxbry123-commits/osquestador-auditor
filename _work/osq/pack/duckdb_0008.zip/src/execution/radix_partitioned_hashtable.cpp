#include "duckdb/execution/radix_partitioned_hashtable.hpp"

#include "duckdb/common/radix_partitioning.hpp"
#include "duckdb/common/enums/debug_verification_mode.hpp"
#include "duckdb/common/vector/flat_vector.hpp"
#include "duckdb/common/row_operations/row_operations.hpp"
#include "duckdb/common/types/row/tuple_data_collection.hpp"
#include "duckdb/common/types/row/tuple_data_iterator.hpp"
#include "duckdb/execution/aggregate_hashtable.hpp"
#include "duckdb/execution/aggregate_state_spilling.hpp"
#include "duckdb/execution/executor.hpp"
#include "duckdb/execution/ht_entry.hpp"
#include "duckdb/execution/operator/aggregate/physical_hash_aggregate.hpp"
#include "duckdb/planner/expression/bound_reference_expression.hpp"
#include "duckdb/storage/temporary_memory_manager.hpp"

namespace duckdb {

RadixPartitionedHashTable::RadixPartitionedHashTable(GroupingSet &grouping_set_p, const GroupedAggregateData &op_p,
                                                     TupleDataValidityType group_validity_p)
    : grouping_set(grouping_set_p), op(op_p), group_validity(group_validity_p) {
	auto groups_count = op.GroupCount();
	for (auto group_idx : ProjectionIndex::GetIndexes(groups_count)) {
		if (grouping_set.find(group_idx) == grouping_set.end()) {
			null_groups.push_back(group_idx);
		}
	}
	if (grouping_set.empty()) {
		// Fake a single group with a constant value for aggregation without groups
		group_types.emplace_back(LogicalType::TINYINT);
	}
	for (auto &entry : grouping_set) {
		group_types.push_back(op.group_types[entry]);
	}
	SetGroupingValues();

	auto group_types_copy = group_types;
	group_types_copy.emplace_back(LogicalType::HASH);

	auto layout = make_shared_ptr<TupleDataLayout>();
	auto aggregate_objects = AggregateObject::CreateAggregateObjects(op.bindings);
	layout->Initialize(std::move(group_types_copy), std::move(aggregate_objects), group_validity);
	layout_ptr = std::move(layout);
}

void RadixPartitionedHashTable::SetGroupingValues() {
	// Compute the GROUPING values:
	// For each parameter to the GROUPING clause, we check if the hash table groups on this particular group
	// If it does, we return 0, otherwise we return 1
	// We then use bitshifts to combine these values
	auto &grouping_functions = op.GetGroupingFunctions();
	for (auto &grouping : grouping_functions) {
		int64_t grouping_value = 0;
		D_ASSERT(grouping.size() < sizeof(int64_t) * 8);
		for (idx_t i = 0; i < grouping.size(); i++) {
			if (grouping_set.find(grouping[i]) == grouping_set.end()) {
				// We don't group on this value!
				grouping_value += 1LL << (grouping.size() - (i + 1));
			}
		}
		grouping_values.push_back(Value::BIGINT(grouping_value));
	}
}

shared_ptr<TupleDataLayout> RadixPartitionedHashTable::GetLayoutPtr() const {
	return layout_ptr;
}

const TupleDataLayout &RadixPartitionedHashTable::GetLayout() const {
	return *layout_ptr;
}

unique_ptr<GroupedAggregateHashTable> RadixPartitionedHashTable::CreateHT(ClientContext &context, const idx_t capacity,
                                                                          const idx_t radix_bits) const {
	return make_uniq<GroupedAggregateHashTable>(context, BufferAllocator::Get(context), group_types, op.payload_types,
	                                            op.bindings, capacity, radix_bits, group_validity);
}

//===--------------------------------------------------------------------===//
// Sink
//===--------------------------------------------------------------------===//
enum class AggregatePartitionState : uint8_t {
	//! Can be finalized
	READY_TO_FINALIZE = 0,
	//! Finalize is in progress
	FINALIZE_IN_PROGRESS = 1,
	//! Finalized, ready to scan
	READY_TO_SCAN = 2
};

struct AggregatePartition : StateWithBlockableTasks {
	explicit AggregatePartition(unique_ptr<TupleDataCollection> data_p)
	    : state(AggregatePartitionState::READY_TO_FINALIZE), data(std::move(data_p)), progress(0) {
	}

	AggregatePartitionState state;

	unique_ptr<TupleDataCollection> data;
	//! Data of this partition whose aggregate states were exported to spillable storage
	unique_ptr<ColumnDataCollection> exported_data;
	//! When states spill, each partition holds its own arenas, released once the partition is scanned
	shared_ptr<ArenaAllocator> allocator;
	//! Arena holding the imported states (combining may steal from them, so it must live as long)
	shared_ptr<ArenaAllocator> import_allocator;
	atomic<double> progress;
};

class RadixHTGlobalSinkState;

//! How aggregate state spilling and native row combining are allowed to interleave
enum class SpillPhase {
	//! Rows may still be combined natively, and the exported width may still grow beyond it
	NATIVE_ALLOWED,
	//! The exported width grew beyond the native width: every combine must export its rows
	EXPORTED_ONLY,
	//! Rows were combined natively: the exported width can no longer grow beyond the native width
	NATIVE_COMBINE_STARTED
};

struct RadixHTConfig {
public:
	explicit RadixHTConfig(RadixHTGlobalSinkState &sink);

	void Reset();
	void SetRadixBits(const idx_t &radix_bits_p);
	bool SetRadixBitsToExternal();
	idx_t GetRadixBits() const;
	idx_t GetMaximumSinkRadixBits() const;

private:
	void SetRadixBitsInternal(idx_t radix_bits_p, bool external);
	idx_t InitialSinkRadixBits() const;
	idx_t ExternalRadixBits(bool dynamic) const;
	idx_t MaximumSinkRadixBits() const;
	idx_t SinkCapacity() const;

private:
	//! The global sink state
	RadixHTGlobalSinkState &sink;

public:
	//! Width of tuples
	const idx_t row_width;
	//! Capacity of HTs during the Sink
	const idx_t sink_capacity;

private:
	//! Sink radix bits to initialize with
	static constexpr idx_t MAXIMUM_INITIAL_SINK_RADIX_BITS = 4;

public:
	//! Maximum Sink radix bits (independent of threads)
	static constexpr idx_t MAXIMUM_FINAL_SINK_RADIX_BITS = 8;

private:
	//! Current thread-global sink radix bits
	atomic<idx_t> sink_radix_bits;
	//! Maximum Sink radix bits (set based on number of threads, if not external)
	const idx_t maximum_sink_radix_bits;

	//! Thresholds at which we reduce the sink radix bits
	//! This needed to reduce cache misses when we have very wide rows
	static constexpr idx_t ROW_WIDTH_THRESHOLD_ONE = 32;
	static constexpr idx_t ROW_WIDTH_THRESHOLD_TWO = 64;

public:
	//! If we have this many or less threads, we grow the HT, otherwise we abandon
	static constexpr idx_t GROW_STRATEGY_THREAD_THRESHOLD = 2;
	//! If we fill this many blocks per partition, we trigger a repartition
	static constexpr double BLOCK_FILL_FACTOR = 0.5;
	//! By how many bits to repartition if a repartition is triggered
	static constexpr idx_t REPARTITION_RADIX_BITS = 2;
	//! Thread-limit divisor for state export and exported partition sizing
	static constexpr idx_t AGGREGATE_STATE_SPILL_DIVISOR = 8;
	//! Arena-only pressure that forces external aggregation
	static constexpr idx_t AGGREGATE_STATE_PRESSURE_DIVISOR = 2;
	//! Estimated memory amplification when importing exported states
	static constexpr idx_t EXPORTED_STATE_MEMORY_MULTIPLIER = 2;
};

class RadixHTGlobalSinkState : public GlobalSinkState {
public:
	RadixHTGlobalSinkState(ClientContext &context, const RadixPartitionedHashTable &radix_ht);

	//! Destroys aggregate states (if multi-scan)
	~RadixHTGlobalSinkState() override;
	void Destroy();

public:
	idx_t GetThreadLimit() const {
		return temporary_memory_state->GetReservation() / number_of_threads / 10 * 8;
	}

public:
	ClientContext &context;
	//! Temporary memory state for managing this hash table's memory usage
	unique_ptr<TemporaryMemoryState> temporary_memory_state;
	atomic<idx_t> minimum_reservation;

	//! Whether we've called Finalize
	bool finalized;
	//! Whether we are doing an external aggregation
	atomic<bool> external;
	//! Threads that have called Sink
	atomic<idx_t> active_threads;
	//! Number of threads (from TaskScheduler)
	const idx_t number_of_threads;
	//! Memory limit (from BufferManager)
	const idx_t memory_limit;
	//! Block size (from BufferManager)
	const idx_t block_alloc_size;
	//! If any thread has called combine
	atomic<bool> any_combined;
	//! If any thread has called ht.Abandon() during Sink (meaning uncombined_data may have duplicates)
	atomic<bool> any_abandoned;

	//! The radix HT
	const RadixPartitionedHashTable &radix_ht;
	//! Config for partitioning
	RadixHTConfig config;

	//! Uncombined partitioned data that will be put into the AggregatePartitions
	unique_ptr<PartitionedTupleData> uncombined_data;
	//! The spill metadata of the aggregate layout, set if the states can spill
	unique_ptr<AggregateStateSpillPlan> spill_plan;
	//! Synchronizes the transition to exported-only aggregation with concurrent combines
	SpillPhase spill_phase DUCKDB_GUARDED_BY(lock);
	//! Uncombined exported data, aligned one-to-one with the partitions of uncombined_data
	vector<unique_ptr<ColumnDataCollection>> uncombined_exported_data;
	//! Allocators used during the Sink/Finalize
	vector<shared_ptr<ArenaAllocator>> stored_allocators;
	idx_t stored_allocators_size;

	//! Partitions that are finalized during GetData
	vector<unique_ptr<AggregatePartition>> partitions;
	//! For keeping track of progress
	atomic<idx_t> finalize_done;

	//! Pin properties when scanning
	TupleDataPinProperties scan_pin_properties;
	//! Total count before combining
	idx_t count_before_combining;
	//! Maximum partition size if all unique
	idx_t max_partition_size;
};

RadixHTGlobalSinkState::RadixHTGlobalSinkState(ClientContext &context_p, const RadixPartitionedHashTable &radix_ht_p)
    : context(context_p), temporary_memory_state(TemporaryMemoryManager::Get(context).Register(context)),
      finalized(false), external(false), active_threads(0),
      number_of_threads(TaskScheduler::GetScheduler(context).NumberOfThreads()),
      memory_limit(BufferManager::GetBufferManager(context).GetOperatorMemoryLimit()),
      block_alloc_size(BufferManager::GetBufferManager(context).GetBlockAllocSize()), any_combined(false),
      any_abandoned(false), radix_ht(radix_ht_p), config(*this), stored_allocators_size(0), finalize_done(0),
      scan_pin_properties(TupleDataPinProperties::DESTROY_AFTER_DONE), count_before_combining(0),
      max_partition_size(0) {
	spill_plan = AggregateStateSpilling::TryCreateSpillPlan(radix_ht.GetLayout());
	spill_phase = SpillPhase::NATIVE_ALLOWED;

	// Compute minimum reservation
	auto tuples_per_block = block_alloc_size / radix_ht.GetLayout().GetRowWidth();
	idx_t ht_count =
	    LossyNumericCast<idx_t>(static_cast<double>(config.sink_capacity) / GroupedAggregateHashTable::LOAD_FACTOR);
	auto num_partitions = RadixPartitioning::NumberOfPartitions(config.GetMaximumSinkRadixBits());
	auto count_per_partition = ht_count / num_partitions;
	auto blocks_per_partition = (count_per_partition + tuples_per_block) / tuples_per_block;
	if (!radix_ht.GetLayout().AllConstant()) {
		blocks_per_partition += 1;
	}
	auto ht_size = num_partitions * blocks_per_partition * block_alloc_size + config.sink_capacity * sizeof(ht_entry_t);

	// This really is the minimum reservation that we can do
	auto num_threads = TaskScheduler::GetScheduler(context).NumberOfThreads();
	minimum_reservation = num_threads * ht_size;

	temporary_memory_state->SetMinimumReservation(minimum_reservation);
	temporary_memory_state->SetRemainingSizeAndUpdateReservation(context, minimum_reservation);
}

RadixHTGlobalSinkState::~RadixHTGlobalSinkState() {
	Destroy();
}

// LCOV_EXCL_START
void RadixHTGlobalSinkState::Destroy() {
	if (scan_pin_properties == TupleDataPinProperties::DESTROY_AFTER_DONE || count_before_combining == 0 ||
	    partitions.empty()) {
		// Already destroyed / empty
		return;
	}

	TupleDataLayout layout = partitions[0]->data->GetLayout().Copy();
	if (!layout.HasDestructor()) {
		return; // No destructors, exit
	}

	// There are aggregates with destructors: Call the destructor for each of the aggregates
	const annotated_lock_guard<annotated_mutex> guard {lock};
	RowOperationsState row_state(*stored_allocators.back());
	for (auto &partition : partitions) {
		auto &data_collection = *partition->data;
		if (data_collection.Count() == 0) {
			continue;
		}
		TupleDataChunkIterator iterator(data_collection, TupleDataPinProperties::DESTROY_AFTER_DONE, false);
		auto &row_locations = iterator.GetChunkState().row_locations;
		do {
			RowOperations::DestroyStates(row_state, layout, row_locations);
		} while (iterator.Next());
		data_collection.Reset();
	}
}
// LCOV_EXCL_STOP

RadixHTConfig::RadixHTConfig(RadixHTGlobalSinkState &sink_p)
    : sink(sink_p), row_width(sink.radix_ht.GetLayout().GetRowWidth()), sink_capacity(SinkCapacity()),
      sink_radix_bits(InitialSinkRadixBits()), maximum_sink_radix_bits(MaximumSinkRadixBits()) {
}

void RadixHTConfig::Reset() {
	sink_radix_bits = InitialSinkRadixBits();
}

void RadixHTConfig::SetRadixBits(const idx_t &radix_bits_p) {
	const auto max_bits = MinValue(maximum_sink_radix_bits, ExternalRadixBits(true));
	SetRadixBitsInternal(MinValue(radix_bits_p, max_bits), false);
}

bool RadixHTConfig::SetRadixBitsToExternal() {
	SetRadixBitsInternal(ExternalRadixBits(true), true);
	return sink.external;
}

idx_t RadixHTConfig::GetRadixBits() const {
	return sink_radix_bits;
}

idx_t RadixHTConfig::GetMaximumSinkRadixBits() const {
	return maximum_sink_radix_bits;
}

void RadixHTConfig::SetRadixBitsInternal(const idx_t radix_bits_p, bool external) {
	if (sink_radix_bits > radix_bits_p || sink.any_combined) {
		return;
	}

	const annotated_lock_guard<annotated_mutex> guard {sink.lock};
	if (sink_radix_bits > radix_bits_p || sink.any_combined) {
		return;
	}

	if (external) {
		const auto partition_multiplier = RadixPartitioning::NumberOfPartitions(radix_bits_p) /
		                                  RadixPartitioning::NumberOfPartitions(sink_radix_bits);
		sink.minimum_reservation = sink.minimum_reservation * partition_multiplier;
		sink.external = true;
	}

	sink_radix_bits = radix_bits_p;
}

idx_t RadixHTConfig::InitialSinkRadixBits() const {
	return MinValue(RadixPartitioning::RadixBitsOfPowerOfTwo(NextPowerOfTwo(sink.number_of_threads)),
	                MAXIMUM_INITIAL_SINK_RADIX_BITS);
}

idx_t RadixHTConfig::ExternalRadixBits(const bool dynamic) const {
	// Going to many partitions is great for reducing memory usage during the GetData phase
	// However, we can't go to, e.g., 256 partitions when we have 8 threads and 200 MiB of memory
	// Because we'll have too many pages in memory to do the partitioning in the first place

	// Assume we can fill half of RAM with pages, and pessimistically assume 4 pages per partition
	const auto memory_limit = dynamic ? sink.temporary_memory_state->GetReservation() : sink.memory_limit / 2;
	const auto max_partitions = memory_limit / sink.number_of_threads / sink.block_alloc_size / 4;

	// Compute number of bits, rounded down, at least as much as initial bits
	const auto bits = MaxValue(RadixPartitioning::RadixBits(max_partitions) - 1, InitialSinkRadixBits());

	// Avoid returning 0 or underflowed bits
	if (max_partitions == 0 || bits == 0) {
		return 1;
	}

	// Capped by global maximum
	return MinValue(bits, MAXIMUM_FINAL_SINK_RADIX_BITS);
}

idx_t RadixHTConfig::MaximumSinkRadixBits() const {
	if (sink.number_of_threads <= GROW_STRATEGY_THREAD_THRESHOLD) {
		return InitialSinkRadixBits(); // Don't repartition unless we go external
	}
	// If rows are very wide we have to reduce the number of partitions, otherwise cache misses get out of hand
	idx_t bits = DConstants::INVALID_INDEX;
	if (row_width >= ROW_WIDTH_THRESHOLD_TWO) {
		bits = MAXIMUM_FINAL_SINK_RADIX_BITS - 2;
	} else if (row_width >= ROW_WIDTH_THRESHOLD_ONE) {
		bits = MAXIMUM_FINAL_SINK_RADIX_BITS - 1;
	} else {
		bits = MAXIMUM_FINAL_SINK_RADIX_BITS;
	}
	// Capped by external radix bits
	return MinValue(bits, ExternalRadixBits(false));
}

idx_t RadixHTConfig::SinkCapacity() const {
	if (sink.number_of_threads <= GROW_STRATEGY_THREAD_THRESHOLD) {
		// Grow strategy, start off a bit bigger
		return 262144;
	}
	// Start off tiny, we can adapt with DecideAdaptation later
	return 32768;
}

class RadixHTLocalSinkState : public LocalSinkState {
public:
	RadixHTLocalSinkState(ClientContext &context, const RadixPartitionedHashTable &radix_ht);
	void ResetForReuse(const RadixPartitionedHashTable &radix_ht, RadixHTGlobalSinkState &gstate);

public:
	//! Thread-local HT that is re-used after abandoning
	unique_ptr<GroupedAggregateHashTable> ht;
	//! Chunk with group columns
	DataChunk group_chunk;

	//! After seeing this many tuples, we decide whether to adapt our strategy
	//! This also serves as the maximum HT sink capacity
	static constexpr idx_t ADAPTIVITY_THRESHOLD = 1048576;
	//! Whether we have decided to adapt our strategy
	bool adapted;
	//! Whether this local state has already registered itself as active for the current iteration
	bool registered;
	//! Sink capacity for this thread
	idx_t local_sink_capacity;

	//! Data that is abandoned ends up here (only if we're doing external aggregation)
	unique_ptr<PartitionedTupleData> abandoned_data;
	//! Exported abandoned aggregate states, aligned one-to-one with the partitions of abandoned_data
	vector<unique_ptr<ColumnDataCollection>> abandoned_exported_data;
};

RadixHTLocalSinkState::RadixHTLocalSinkState(ClientContext &, const RadixPartitionedHashTable &radix_ht)
    : adapted(false), registered(false), local_sink_capacity(DConstants::INVALID_INDEX) {
	// If there are no groups we create a fake group so everything has the same group
	group_chunk.InitializeEmpty(radix_ht.group_types);
	if (radix_ht.grouping_set.empty()) {
		group_chunk.data[0].Reference(Value::TINYINT(42), count_t(STANDARD_VECTOR_SIZE));
	}
}

void RadixHTLocalSinkState::ResetForReuse(const RadixPartitionedHashTable &radix_ht, RadixHTGlobalSinkState &gstate) {
	group_chunk.Reset();
	if (radix_ht.grouping_set.empty()) {
		group_chunk.data[0].Reference(Value::TINYINT(42), count_t(STANDARD_VECTOR_SIZE));
	}
	registered = false;
	abandoned_data.reset();
	abandoned_exported_data.clear();
	if (!ht) {
		adapted = false;
		local_sink_capacity = DConstants::INVALID_INDEX;
		return;
	}

	local_sink_capacity = MaxValue(gstate.config.sink_capacity, ht->Capacity());
	ht->ResetForNewIteration(gstate.config.GetRadixBits());
	if (gstate.number_of_threads > RadixHTConfig::GROW_STRATEGY_THREAD_THRESHOLD) {
		ht->EnableHLL(true);
		adapted = false;
	} else {
		adapted = true;
	}
}

unique_ptr<GlobalSinkState> RadixPartitionedHashTable::GetGlobalSinkState(ClientContext &context) const {
	return make_uniq<RadixHTGlobalSinkState>(context, *this);
}

unique_ptr<LocalSinkState> RadixPartitionedHashTable::GetLocalSinkState(ExecutionContext &context) const {
	return make_uniq<RadixHTLocalSinkState>(context.client, *this);
}

void RadixPartitionedHashTable::ResetGlobalSinkState(ClientContext &context, GlobalSinkState &gstate_p) const {
	auto &gstate = gstate_p.Cast<RadixHTGlobalSinkState>();
	gstate.Destroy();
	gstate.temporary_memory_state->SetMinimumReservation(gstate.minimum_reservation);
	gstate.temporary_memory_state->SetRemainingSizeAndUpdateReservation(context, gstate.minimum_reservation);
	gstate.finalized = false;
	gstate.external = false;
	gstate.active_threads = 0;
	gstate.any_combined = false;
	gstate.any_abandoned = false;
	gstate.config.Reset();
	gstate.uncombined_data.reset();
	gstate.uncombined_exported_data.clear();
	{
		const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
		gstate.spill_phase = SpillPhase::NATIVE_ALLOWED;
	}
	gstate.stored_allocators.clear();
	gstate.stored_allocators_size = 0;
	gstate.partitions.clear();
	gstate.finalize_done = 0;
	gstate.scan_pin_properties = TupleDataPinProperties::DESTROY_AFTER_DONE;
	gstate.count_before_combining = 0;
	gstate.max_partition_size = 0;
}

void RadixPartitionedHashTable::ResetLocalSinkState(ExecutionContext &context, GlobalSinkState &gstate_p,
                                                    LocalSinkState &lstate_p) const {
	auto &gstate = gstate_p.Cast<RadixHTGlobalSinkState>();
	auto &lstate = lstate_p.Cast<RadixHTLocalSinkState>();
	lstate.ResetForReuse(*this, gstate);
}

void RadixPartitionedHashTable::PopulateGroupChunk(DataChunk &group_chunk, DataChunk &input_chunk) const {
	idx_t chunk_index = 0;
	// Populate the group_chunk
	for (auto &group_idx : grouping_set) {
		// Retrieve the expression containing the index in the input chunk
		auto &group = op.groups[group_idx];
		D_ASSERT(group->GetExpressionType() == ExpressionType::BOUND_REF);
		auto &bound_ref_expr = group->Cast<BoundReferenceExpression>();
		// Reference from input_chunk[group.index] -> group_chunk[chunk_index]
		group_chunk.data[chunk_index++].Reference(input_chunk.data[bound_ref_expr.Index()]);
	}
	group_chunk.SetChildCardinality(input_chunk.size());
	// the fake group for empty grouping_set was created with v_size=STANDARD_VECTOR_SIZE - resize to match
	if (grouping_set.empty()) {
		FlatVector::SetSize(group_chunk.data[0], count_t(input_chunk.size()));
	}
	group_chunk.Verify();
}

void DecideAdaptation(RadixHTGlobalSinkState &gstate, RadixHTLocalSinkState &lstate) {
	//! If the number of unique values is greater than this percentage, we skip lookups altogether
	static constexpr double SKIP_LOOKUP_UNIQUE_PERCENTAGE_THRESHOLD = 0.95;
	//! If the deduplication rate could be increased by this number, we increase our sink capacity
	static constexpr double CAPACITY_INCREASE_DEDUPLICATION_RATE_THRESHOLD = 2.0;

	if (gstate.external) {
		return; // Shouldn't adapt after this flag has been set
	}

	auto &ht = *lstate.ht;
	const auto sink_count = ht.GetSinkCount();
	D_ASSERT(sink_count >= RadixHTLocalSinkState::ADAPTIVITY_THRESHOLD);

	// Deduplicated count (affected by HT size)
	const auto deduplicated_count = ht.GetMaterializedCount();
	// Estimated unique count (unaffected by HT size)
	const auto hll_count = MinValue(ht.GetHLLUpperBound(), deduplicated_count);

	// Compute actual deduplicated percentage and potential deduplicated count (estimated by hll)
	const auto deduplicated_percentage = static_cast<double>(deduplicated_count) / static_cast<double>(sink_count);
	const auto hll_percentage = static_cast<double>(hll_count) / static_cast<double>(sink_count);
	if (hll_percentage > SKIP_LOOKUP_UNIQUE_PERCENTAGE_THRESHOLD) {
		// Almost everything is unique, skip lookups, just append, defer deduplication to GetData phase
		ht.SkipLookups();
		return;
	}

	const auto potential_increase_rate = deduplicated_percentage / hll_percentage;
	if (potential_increase_rate > CAPACITY_INCREASE_DEDUPLICATION_RATE_THRESHOLD) {
		// We could be deduplicating a lot better, increase HT capacity
		D_ASSERT(IsPowerOfTwo(RadixHTLocalSinkState::ADAPTIVITY_THRESHOLD));
		const auto new_capacity = MinValue(GroupedAggregateHashTable::GetCapacityForCount(hll_count),
		                                   RadixHTLocalSinkState::ADAPTIVITY_THRESHOLD);
		lstate.local_sink_capacity = MaxValue(gstate.config.sink_capacity, new_capacity);
		gstate.any_abandoned = true;
		ht.Abandon();
		ht.Resize(lstate.local_sink_capacity);
	}
}

// Grow abandoned_data (frozen at the radix bits of when we first went external) up to the current radix bits, so it
// never has fewer partitions than the data merged into it - Repartition/Combine only handle new >= old.
void GrowAbandonedDataToRadixBits(ClientContext &context, RadixHTGlobalSinkState &gstate, RadixHTLocalSinkState &lstate,
                                  const idx_t radix_bits) {
	if (!lstate.abandoned_data ||
	    lstate.abandoned_data->PartitionCount() >= RadixPartitioning::NumberOfPartitions(radix_bits)) {
		return;
	}
	auto new_abandoned_data = make_uniq<RadixPartitionedTupleData>(
	    BufferManager::GetBufferManager(context), gstate.radix_ht.GetLayoutPtr(), MemoryTag::HASH_TABLE, radix_bits,
	    gstate.radix_ht.GetLayout().ColumnCount() - 1, context);
	lstate.abandoned_data->Repartition(context, *new_abandoned_data);
	lstate.abandoned_data = std::move(new_abandoned_data);
}

// Grow a set of exported collections to a larger partition count by splitting each collection
// sequentially, so that only one source and its split targets are ever appended to at a time
void GrowExportedData(ClientContext &context, RadixHTGlobalSinkState &gstate,
                      vector<unique_ptr<ColumnDataCollection>> &exported, idx_t new_partition_count) {
	const auto old_partition_count = exported.size();
	D_ASSERT(new_partition_count > old_partition_count);
	D_ASSERT(new_partition_count % old_partition_count == 0);
	const auto fan_out = new_partition_count / old_partition_count;
	const auto radix_bits = RadixPartitioning::RadixBitsOfPowerOfTwo(new_partition_count);
	const auto hash_col_idx = gstate.radix_ht.GetLayout().ColumnCount() - 1;

	vector<unique_ptr<ColumnDataCollection>> grown(new_partition_count);
	DataChunk chunk;
	DataChunk target_chunk;
	for (idx_t old_idx = 0; old_idx < old_partition_count; old_idx++) {
		if (!exported[old_idx] || exported[old_idx]->Count() == 0) {
			continue;
		}
		auto &source = *exported[old_idx];
		if (chunk.data.empty()) {
			chunk.Initialize(Allocator::Get(context), source.Types());
			target_chunk.Initialize(Allocator::Get(context), source.Types());
		}
		ColumnDataScanState scan_state;
		source.InitializeScan(scan_state, ColumnDataScanProperties::DISALLOW_ZERO_COPY);
		SelectionVector sel(STANDARD_VECTOR_SIZE);
		while (source.Scan(scan_state, chunk)) {
			const auto count = chunk.size();
			const auto hashes = FlatVector::GetData<hash_t>(chunk.data[hash_col_idx]);
			for (idx_t target = 0; target < fan_out; target++) {
				const idx_t target_idx = old_idx * fan_out + target;
				idx_t sel_count = 0;
				for (idx_t i = 0; i < count; i++) {
					if (RadixPartitioning::ApplyMask(hashes[i], radix_bits) == target_idx) {
						sel.set_index(sel_count++, i);
					}
				}
				if (sel_count == 0) {
					continue;
				}
				if (!grown[target_idx]) {
					grown[target_idx] =
					    make_uniq<ColumnDataCollection>(BufferManager::GetBufferManager(context), source.Types());
				}
				target_chunk.Reset();
				target_chunk.Slice(chunk, sel, sel_count);
				grown[target_idx]->Append(target_chunk);
			}
		}
		exported[old_idx].reset();
	}
	exported = std::move(grown);
}

// Export the abandoned states to spillable storage, so that their arena can be freed.
// Every abandoned partition is exported sequentially into its own column collection, so
// only one collection is being appended to at any time.
void ExportAbandonedData(ClientContext &context, RadixHTGlobalSinkState &gstate, RadixHTLocalSinkState &lstate) {
	if (!lstate.abandoned_data || lstate.abandoned_data->Count() == 0) {
		return;
	}
	const auto partition_count = lstate.abandoned_data->PartitionCount();
	const auto radix_bits = RadixPartitioning::RadixBitsOfPowerOfTwo(partition_count);
	const auto hash_col_idx = gstate.radix_ht.GetLayout().ColumnCount() - 1;
	if (!lstate.abandoned_exported_data.empty() && lstate.abandoned_exported_data.size() < partition_count) {
		// The abandoned data has grown to more radix bits since we last exported, grow to match
		GrowExportedData(context, gstate, lstate.abandoned_exported_data, partition_count);
	}
	if (lstate.abandoned_exported_data.size() < partition_count) {
		lstate.abandoned_exported_data.resize(partition_count);
	}
	auto exported_radix_bits = RadixPartitioning::RadixBitsOfPowerOfTwo(lstate.abandoned_exported_data.size());
	ArenaAllocator scratch_allocator(Allocator::Get(context));
	auto &partitions = lstate.abandoned_data->GetPartitions();
	for (idx_t partition_idx = 0; partition_idx < partition_count; partition_idx++) {
		auto &partition = *partitions[partition_idx];
		if (partition.Count() == 0) {
			continue;
		}
		AggregateStateSpilling::ExportStates(context, gstate.radix_ht.GetLayout(), *gstate.spill_plan, partition,
		                                     lstate.abandoned_exported_data, exported_radix_bits, scratch_allocator);
	}
	// The finalize phase imports and combines one exported partition at a time, so their size
	// must stay well below the memory limit: grow the exported partitions when they get too big
	idx_t exported_bytes = 0;
	for (auto &exported : lstate.abandoned_exported_data) {
		exported_bytes += exported ? exported->SizeInBytes() : 0;
	}
	while (exported_bytes / lstate.abandoned_exported_data.size() >
	           gstate.GetThreadLimit() / RadixHTConfig::AGGREGATE_STATE_SPILL_DIVISOR &&
	       exported_radix_bits + RadixHTConfig::REPARTITION_RADIX_BITS <=
	           RadixHTConfig::MAXIMUM_FINAL_SINK_RADIX_BITS) {
		{
			// Widening beyond the native width forces every subsequent combine to export its
			// rows. Once rows were combined natively, the exported width must stay instead.
			const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
			if (gstate.spill_phase == SpillPhase::NATIVE_COMBINE_STARTED) {
				break;
			}
			gstate.spill_phase = SpillPhase::EXPORTED_ONLY;
		}
		exported_radix_bits += RadixHTConfig::REPARTITION_RADIX_BITS;
		GrowExportedData(context, gstate, lstate.abandoned_exported_data,
		                 RadixPartitioning::NumberOfPartitions(exported_radix_bits));
	}
	// The source rows were destroyed as they were exported, start over with an empty collection
	lstate.abandoned_data =
	    make_uniq<RadixPartitionedTupleData>(BufferManager::GetBufferManager(context), gstate.radix_ht.GetLayoutPtr(),
	                                         MemoryTag::HASH_TABLE, radix_bits, hash_col_idx, context);
}

// Whether the aggregate arena alone approaches the thread memory limit
bool StatePressureExceeded(RadixHTGlobalSinkState &gstate, GroupedAggregateHashTable &ht) {
	return ht.GetAggregateAllocator()->AllocationSize() >
	       gstate.GetThreadLimit() / RadixHTConfig::AGGREGATE_STATE_PRESSURE_DIVISOR;
}

// Whether this thread's aggregate states should be exported to spillable storage
bool ShouldExportStates(RadixHTGlobalSinkState &gstate, RadixHTLocalSinkState &lstate, GroupedAggregateHashTable &ht) {
	const auto arena_size = ht.GetAggregateAllocator()->AllocationSize();
	if (arena_size == 0) {
		// every current state is inline, and exporting would only cost
		return false;
	}
	if (StatePressureExceeded(gstate, ht) || !lstate.abandoned_exported_data.empty()) {
		return true;
	}
	if (!gstate.external) {
		return false;
	}
	return arena_size >= gstate.GetThreadLimit() / RadixHTConfig::AGGREGATE_STATE_SPILL_DIVISOR;
}

void MaybeRepartition(ClientContext &context, RadixHTGlobalSinkState &gstate, RadixHTLocalSinkState &lstate,
                      const bool combine) {
	auto &config = gstate.config;
	auto &ht = *lstate.ht;

	// Check if we're approaching the memory limit
	auto &temporary_memory_state = *gstate.temporary_memory_state;
	const auto aggregate_allocator_size = ht.GetAggregateAllocator()->AllocationSize();
	const auto total_size =
	    aggregate_allocator_size + ht.GetPartitionedData().SizeInBytes() + ht.Capacity() * sizeof(ht_entry_t);
	if (total_size > gstate.GetThreadLimit()) {
		// We're over the thread memory limit
		if (!gstate.external) {
			// We haven't yet triggered out-of-core behavior, but maybe we don't have to, grab the lock and check again
			const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
			if (total_size > gstate.GetThreadLimit()) {
				// Out-of-core would be triggered below, update minimum reservation and try to increase the reservation
				temporary_memory_state.SetMinimumReservation(aggregate_allocator_size * gstate.number_of_threads +
				                                             gstate.minimum_reservation);
				auto remaining_size =
				    MaxValue<idx_t>(gstate.number_of_threads * total_size, temporary_memory_state.GetRemainingSize());
				temporary_memory_state.SetRemainingSizeAndUpdateReservation(context, 2 * remaining_size);
			}
		}
	}

	if (total_size > gstate.GetThreadLimit()) {
		if (gstate.config.SetRadixBitsToExternal()) {
			// We're approaching the memory limit, unpin the data
			const auto external_radix_bits = config.GetRadixBits();
			if (!lstate.abandoned_data) {
				lstate.abandoned_data = make_uniq<RadixPartitionedTupleData>(
				    BufferManager::GetBufferManager(context), gstate.radix_ht.GetLayoutPtr(), MemoryTag::HASH_TABLE,
				    external_radix_bits, gstate.radix_ht.GetLayout().ColumnCount() - 1, context);
			} else {
				GrowAbandonedDataToRadixBits(context, gstate, lstate, external_radix_bits);
			}
			ht.SetRadixBits(external_radix_bits);
			ht.AcquirePartitionedData()->Repartition(context, *lstate.abandoned_data);
		}
	}

	// We can go external when there are few threads, but we shouldn't repartition here
	if (!combine && gstate.number_of_threads <= RadixHTConfig::GROW_STRATEGY_THREAD_THRESHOLD) {
		return;
	}

	const auto partition_count = ht.GetPartitionedData().PartitionCount();
	const auto current_radix_bits = RadixPartitioning::RadixBitsOfPowerOfTwo(partition_count);
	D_ASSERT(current_radix_bits <= config.GetRadixBits());

	const auto row_size_per_partition =
	    ht.GetMaterializedCount() * ht.GetPartitionedData().GetLayout().GetRowWidth() / partition_count;
	if (row_size_per_partition >
	    LossyNumericCast<idx_t>(config.BLOCK_FILL_FACTOR * static_cast<double>(gstate.block_alloc_size))) {
		// We crossed our block filling threshold, try to increment radix bits
		config.SetRadixBits(current_radix_bits + config.REPARTITION_RADIX_BITS);
	}

	const auto global_radix_bits = config.GetRadixBits();
	if (current_radix_bits == global_radix_bits) {
		return; // We're already on the right number of radix bits
	}

	// We're out-of-sync with the global radix bits, repartition
	ht.SetRadixBits(global_radix_bits);
	ht.Repartition();
}

void RadixPartitionedHashTable::Sink(ExecutionContext &context, DataChunk &chunk, OperatorSinkInput &input,
                                     DataChunk &payload_input, const unsafe_vector<idx_t> &filter) const {
	auto &gstate = input.global_state.Cast<RadixHTGlobalSinkState>();
	auto &lstate = input.local_state.Cast<RadixHTLocalSinkState>();
	if (!lstate.ht) {
		lstate.local_sink_capacity = gstate.config.sink_capacity;
		lstate.ht = CreateHT(context.client, lstate.local_sink_capacity, gstate.config.GetRadixBits());
		if (gstate.number_of_threads > RadixHTConfig::GROW_STRATEGY_THREAD_THRESHOLD) {
			// Not using grow strategy, so we enable the HLL to potentially adapt later
			lstate.ht->EnableHLL(true);
		} else {
			// Using grow strategy, so won't ever adapt
			lstate.adapted = true;
		}
	}
	if (!lstate.registered) {
		gstate.active_threads++;
		lstate.registered = true;
	}

	auto &group_chunk = lstate.group_chunk;
	PopulateGroupChunk(group_chunk, chunk);

	auto &ht = *lstate.ht;
	ht.AddChunk(group_chunk, payload_input, filter);

	// Decide whether we should adapt our strategy to the data
	if (!lstate.adapted && lstate.ht->GetSinkCount() >= RadixHTLocalSinkState::ADAPTIVITY_THRESHOLD) {
		DecideAdaptation(gstate, lstate);
		ht.EnableHLL(false); // Can be disabled now (costs 5-10% performance in worst case, single column distinct)
		lstate.adapted = true;
	}

	if (ht.Count() + STANDARD_VECTOR_SIZE < GroupedAggregateHashTable::ResizeThreshold(lstate.local_sink_capacity) &&
	    !(gstate.spill_plan && StatePressureExceeded(gstate, ht))) {
		// We can fit another chunk, and the aggregate states are not under memory pressure either.
		// The state check matters for few groups with large states: those never fill the hash
		// table, but their arena must still be flushed and exported before it exhausts the limit.
		return;
	}

	if (gstate.number_of_threads > RadixHTConfig::GROW_STRATEGY_THREAD_THRESHOLD || gstate.external) {
		// 'Reset' the HT without taking its data, we can just keep appending to the same collection
		// This only works because we never resize the HT
		// We don't do this when running with 1 or 2 threads, it only makes sense when there's many threads
		gstate.any_abandoned = true;
		ht.Abandon();
	}

	// Check if we need to repartition
	const auto radix_bits_before = ht.GetRadixBits();
	MaybeRepartition(context.client, gstate, lstate, false);
	const auto repartitioned = radix_bits_before != ht.GetRadixBits();

	if (repartitioned && ht.Count() != 0) {
		// We repartitioned, but we didn't clear the pointer table / reset the count because we're on 1 or 2 threads
		gstate.any_abandoned = true;
		ht.Abandon();
		if (gstate.external) {
			ht.Resize(lstate.local_sink_capacity);
		}
	}

	if (gstate.spill_plan && ShouldExportStates(gstate, lstate, ht)) {
		// Move everything the HT has abandoned out of it, export the states, and free the arena,
		// so that the state payloads can spill with the rest of the data
		if (!gstate.external) {
			// State pressure also makes the sink external: the finalize phase processes one
			// partition at a time, so the partitions must shrink to fit their states in memory
			gstate.config.SetRadixBitsToExternal();
			ht.SetRadixBits(gstate.config.GetRadixBits());
		}
		gstate.any_abandoned = true;
		ht.Abandon();
		if (!lstate.abandoned_data) {
			lstate.abandoned_data = make_uniq<RadixPartitionedTupleData>(
			    BufferManager::GetBufferManager(context.client), gstate.radix_ht.GetLayoutPtr(), MemoryTag::HASH_TABLE,
			    ht.GetRadixBits(), gstate.radix_ht.GetLayout().ColumnCount() - 1, context.client);
		} else {
			GrowAbandonedDataToRadixBits(context.client, gstate, lstate, ht.GetRadixBits());
		}
		ht.AcquirePartitionedData()->Repartition(context.client, *lstate.abandoned_data);
		ExportAbandonedData(context.client, gstate, lstate);
		ht.GetAggregateAllocator()->FreeAll();
	}

	// TODO: combine early and often
}

void RadixPartitionedHashTable::Combine(ExecutionContext &context, GlobalSinkState &gstate_p,
                                        LocalSinkState &lstate_p) const {
	auto &gstate = gstate_p.Cast<RadixHTGlobalSinkState>();
	auto &lstate = lstate_p.Cast<RadixHTLocalSinkState>();
	if (!lstate.ht) {
		return;
	}

	// Set any_combined, then check one last time whether we need to repartition
	gstate.any_combined = true;
	MaybeRepartition(context.client, gstate, lstate, true);

	auto &ht = *lstate.ht;
	auto lstate_data = ht.AcquirePartitionedData();
	if (lstate.abandoned_data) {
		// Data is abandoned when the sink goes external, and also when aggregate state pressure
		// forces the states to be exported without the sink being external
		D_ASSERT(gstate.external || gstate.spill_plan);
		// The global radix bits may have grown after we last sized abandoned_data - grow it to match before combining
		GrowAbandonedDataToRadixBits(context.client, gstate, lstate, gstate.config.GetRadixBits());
		D_ASSERT(lstate.abandoned_data->PartitionCount() == lstate.ht->GetPartitionedData().PartitionCount());
		D_ASSERT(lstate.abandoned_data->PartitionCount() ==
		         RadixPartitioning::NumberOfPartitions(gstate.config.GetRadixBits()));
		lstate.abandoned_data->Combine(*lstate_data);
	} else {
		lstate.abandoned_data = std::move(lstate_data);
	}

	bool must_export = false;
	if (gstate.spill_plan) {
		// The decision between combining rows natively and exporting them must be synchronized
		// with the exported width: after it grew beyond the native width, every combine must
		// export, and conversely a native combine pins the exported width for good
		const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
		if (gstate.spill_phase == SpillPhase::EXPORTED_ONLY) {
			must_export = true;
		} else {
			gstate.spill_phase = SpillPhase::NATIVE_COMBINE_STARTED;
		}
	}
	if (gstate.spill_plan && (must_export || ShouldExportStates(gstate, lstate, ht))) {
		// Everything this thread produced is in abandoned_data now, export it and free the arena
		ExportAbandonedData(context.client, gstate, lstate);
		ht.GetAggregateAllocator()->FreeAll();
	}

	auto aggregate_allocator = ht.GetAggregateAllocator();

	const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
	D_ASSERT(!gstate.finalized);
	if (gstate.uncombined_data) {
		gstate.uncombined_data->Combine(*lstate.abandoned_data);
	} else {
		gstate.uncombined_data = std::move(lstate.abandoned_data);
	}
	if (!lstate.abandoned_exported_data.empty()) {
		if (gstate.uncombined_exported_data.empty()) {
			gstate.uncombined_exported_data = std::move(lstate.abandoned_exported_data);
		} else {
			if (gstate.uncombined_exported_data.size() < lstate.abandoned_exported_data.size()) {
				GrowExportedData(context.client, gstate, gstate.uncombined_exported_data,
				                 lstate.abandoned_exported_data.size());
			} else if (lstate.abandoned_exported_data.size() < gstate.uncombined_exported_data.size()) {
				GrowExportedData(context.client, gstate, lstate.abandoned_exported_data,
				                 gstate.uncombined_exported_data.size());
			}
			for (idx_t i = 0; i < gstate.uncombined_exported_data.size(); i++) {
				if (!lstate.abandoned_exported_data[i]) {
					continue;
				}
				if (gstate.uncombined_exported_data[i]) {
					gstate.uncombined_exported_data[i]->Combine(*lstate.abandoned_exported_data[i]);
				} else {
					gstate.uncombined_exported_data[i] = std::move(lstate.abandoned_exported_data[i]);
				}
			}
			lstate.abandoned_exported_data.clear();
		}
	}
	if (aggregate_allocator->AllocationSize() != 0) {
		gstate.stored_allocators.emplace_back(std::move(aggregate_allocator));
		gstate.stored_allocators_size += gstate.stored_allocators.back()->AllocationSize();
	}
}

void RadixPartitionedHashTable::Finalize(ClientContext &context, GlobalSinkState &gstate_p) const {
	auto &gstate = gstate_p.Cast<RadixHTGlobalSinkState>();
	const annotated_lock_guard<annotated_mutex> guard {gstate.lock};
	D_ASSERT(!gstate.finalized);

	if (!gstate.uncombined_exported_data.empty() &&
	    (!gstate.uncombined_data ||
	     gstate.uncombined_exported_data.size() != gstate.uncombined_data->PartitionCount())) {
		// The exported side grew to more partitions than the native side, which only happens when
		// state pressure made every thread drain: all rows travel in the exported form
		D_ASSERT(gstate.spill_phase == SpillPhase::EXPORTED_ONLY);
		D_ASSERT(!gstate.uncombined_data || gstate.uncombined_data->Count() == 0);
		gstate.count_before_combining = 0;
		const auto n_partitions = gstate.uncombined_exported_data.size();
		gstate.partitions.reserve(n_partitions);
		for (idx_t i = 0; i < n_partitions; i++) {
			auto empty_data =
			    make_uniq<TupleDataCollection>(BufferManager::GetBufferManager(context), gstate.radix_ht.GetLayoutPtr(),
			                                   MemoryTag::HASH_TABLE, nullptr, context);
			gstate.partitions.emplace_back(make_uniq<AggregatePartition>(std::move(empty_data)));
			auto &partition = *gstate.partitions.back();
			partition.exported_data = std::move(gstate.uncombined_exported_data[i]);
			if (partition.exported_data) {
				gstate.count_before_combining += partition.exported_data->Count();
				gstate.max_partition_size =
				    MaxValue(gstate.max_partition_size,
				             RadixHTConfig::EXPORTED_STATE_MEMORY_MULTIPLIER * partition.exported_data->SizeInBytes());
			}
		}
		gstate.uncombined_exported_data.clear();
	} else if (gstate.uncombined_data) {
		auto &uncombined_data = *gstate.uncombined_data;
		gstate.count_before_combining = uncombined_data.Count();

		// If true there is no need to combine, it was all done by a single thread in a single HT.
		// This is the case when only one thread contributed data and the HT never overflowed its
		// capacity (which would have caused Abandon() to be called, creating duplicates).
		const auto single_ht = !gstate.external && gstate.active_threads == 1 && !gstate.any_abandoned;

		auto &uncombined_partition_data = uncombined_data.GetPartitions();
		const auto n_partitions = uncombined_partition_data.size();
		gstate.partitions.reserve(n_partitions);
		for (idx_t i = 0; i < n_partitions; i++) {
			auto &partition = uncombined_partition_data[i];
			auto partition_size =
			    partition->SizeInBytes() +
			    GroupedAggregateHashTable::GetCapacityForCount(partition->Count()) * sizeof(ht_entry_t);

			gstate.partitions.emplace_back(make_uniq<AggregatePartition>(std::move(partition)));
			if (!gstate.uncombined_exported_data.empty()) {
				D_ASSERT(gstate.uncombined_exported_data.size() == n_partitions);
				gstate.partitions.back()->exported_data = std::move(gstate.uncombined_exported_data[i]);
				if (gstate.partitions.back()->exported_data) {
					gstate.count_before_combining += gstate.partitions.back()->exported_data->Count();
					partition_size += RadixHTConfig::EXPORTED_STATE_MEMORY_MULTIPLIER *
					                  gstate.partitions.back()->exported_data->SizeInBytes();
				}
			}
			gstate.max_partition_size = MaxValue(gstate.max_partition_size, partition_size);
			if (single_ht) {
				gstate.finalize_done++;
				gstate.partitions.back()->progress = 1;
				gstate.partitions.back()->state = AggregatePartitionState::READY_TO_SCAN;
			}
		}
	} else {
		gstate.count_before_combining = 0;
	}

	// Minimum of combining one partition at a time
	gstate.temporary_memory_state->SetMinimumReservation(gstate.stored_allocators_size + gstate.max_partition_size);
	// Set size to 0 until the scan actually starts
	gstate.temporary_memory_state->SetZero();
	gstate.finalized = true;
}

//===--------------------------------------------------------------------===//
// Source
//===--------------------------------------------------------------------===//
idx_t RadixPartitionedHashTable::MaxThreads(GlobalSinkState &sink_p) const {
	auto &sink = sink_p.Cast<RadixHTGlobalSinkState>();
	if (sink.partitions.empty()) {
		return 0;
	}

	const auto max_threads =
	    MinValue<idx_t>(TaskScheduler::GetScheduler(sink.context).NumberOfThreads(), sink.partitions.size());
	sink.temporary_memory_state->SetRemainingSizeAndUpdateReservation(
	    sink.context, sink.stored_allocators_size + max_threads * sink.max_partition_size);

	// we cannot spill aggregate state memory
	const auto usable_memory = sink.temporary_memory_state->GetReservation() > sink.stored_allocators_size
	                               ? sink.temporary_memory_state->GetReservation() - sink.stored_allocators_size
	                               : 0;
	// This many partitions will fit given our reservation (at least 1))
	const auto partitions_fit = MaxValue<idx_t>(usable_memory / sink.max_partition_size, 1);

	// Minimum of the two
	return MinValue<idx_t>(partitions_fit, max_threads);
}

void RadixPartitionedHashTable::SetMultiScan(GlobalSinkState &sink_p) {
	auto &sink = sink_p.Cast<RadixHTGlobalSinkState>();
	sink.scan_pin_properties = TupleDataPinProperties::UNPIN_AFTER_DONE;
}

enum class RadixHTSourceTaskType : uint8_t { NO_TASK, FINALIZE, SCAN };

class RadixHTLocalSourceState;

class RadixHTGlobalSourceState : public GlobalSourceState {
public:
	RadixHTGlobalSourceState(ClientContext &context, const RadixPartitionedHashTable &radix_ht);

	//! Assigns a task to a local source state
	SourceResultType AssignTask(RadixHTGlobalSinkState &sink, RadixHTLocalSourceState &lstate,
	                            InterruptState &interrupt_state);

public:
	//! The client context
	ClientContext &context;
	//! For synchronizing the source phase
	atomic<bool> finished;

	//! Column ids for scanning
	vector<column_t> column_ids;

	//! For synchronizing tasks
	atomic<idx_t> task_idx;
	atomic<idx_t> task_done;
};

enum class RadixHTScanStatus : uint8_t { INIT, IN_PROGRESS, DONE };

class RadixHTLocalSourceState : public LocalSourceState {
public:
	explicit RadixHTLocalSourceState(ExecutionContext &context, const RadixPartitionedHashTable &radix_ht);
	void ResetForReuse();

public:
	//! Do the work this thread has been assigned
	void ExecuteTask(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate, DataChunk &chunk);
	//! Whether this thread has finished the work it has been assigned
	bool TaskFinished();

private:
	//! Execute the finalize or scan task
	void Finalize(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate);
	void Scan(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate, DataChunk &chunk);

public:
	//! Current task and index
	RadixHTSourceTaskType task;
	idx_t task_idx;

	//! Thread-local HT that is re-used to Finalize
	unique_ptr<GroupedAggregateHashTable> ht;
	//! Current status of a Scan
	RadixHTScanStatus scan_status;

private:
	//! Allocator and layout for finalizing state
	TupleDataLayout layout;
	ArenaAllocator aggregate_allocator;
	RowOperationsState row_state;

	//! State and chunk for scanning
	TupleDataScanState scan_state;
	DataChunk scan_chunk;
};

unique_ptr<GlobalSourceState> RadixPartitionedHashTable::GetGlobalSourceState(ClientContext &context) const {
	return make_uniq<RadixHTGlobalSourceState>(context, *this);
}

unique_ptr<LocalSourceState> RadixPartitionedHashTable::GetLocalSourceState(ExecutionContext &context) const {
	return make_uniq<RadixHTLocalSourceState>(context, *this);
}

void RadixPartitionedHashTable::ResetGlobalSourceState(ClientContext &context, GlobalSourceState &gstate_p) const {
	auto &gstate = gstate_p.Cast<RadixHTGlobalSourceState>();
	gstate.finished = false;
	gstate.task_idx = 0;
	gstate.task_done = 0;
}

RadixHTGlobalSourceState::RadixHTGlobalSourceState(ClientContext &context_p, const RadixPartitionedHashTable &radix_ht)
    : context(context_p), finished(false), task_idx(0), task_done(0) {
	for (column_t column_id = 0; column_id < radix_ht.group_types.size(); column_id++) {
		column_ids.push_back(column_id);
	}
}

SourceResultType RadixHTGlobalSourceState::AssignTask(RadixHTGlobalSinkState &sink, RadixHTLocalSourceState &lstate,
                                                      InterruptState &interrupt_state) {
	// First, try to get a partition index
	lstate.task_idx = task_idx++;
	if (finished || lstate.task_idx >= sink.partitions.size()) {
		lstate.ht.reset();
		return SourceResultType::FINISHED;
	}

	// We got a partition index
	auto &partition = *sink.partitions[lstate.task_idx];
	const annotated_lock_guard<annotated_mutex> partition_guard {partition.lock};
	switch (partition.state) {
	case AggregatePartitionState::READY_TO_FINALIZE:
		partition.state = AggregatePartitionState::FINALIZE_IN_PROGRESS;
		lstate.task = RadixHTSourceTaskType::FINALIZE;
		return SourceResultType::HAVE_MORE_OUTPUT;
	case AggregatePartitionState::FINALIZE_IN_PROGRESS:
		lstate.task = RadixHTSourceTaskType::SCAN;
		lstate.scan_status = RadixHTScanStatus::INIT;
		return partition.BlockSource(interrupt_state);
	case AggregatePartitionState::READY_TO_SCAN:
		lstate.task = RadixHTSourceTaskType::SCAN;
		lstate.scan_status = RadixHTScanStatus::INIT;
		return SourceResultType::HAVE_MORE_OUTPUT;
	default:
		throw InternalException("Unexpected AggregatePartitionState in RadixHTLocalSourceState::Finalize!");
	}
}

RadixHTLocalSourceState::RadixHTLocalSourceState(ExecutionContext &context, const RadixPartitionedHashTable &radix_ht)
    : layout(radix_ht.GetLayout().Copy()), aggregate_allocator(BufferAllocator::Get(context.client)),
      row_state(aggregate_allocator) {
	auto &allocator = BufferAllocator::Get(context.client);
	auto scan_chunk_types = radix_ht.group_types;
	for (auto &aggr_type : radix_ht.op.aggregate_return_types) {
		scan_chunk_types.push_back(aggr_type);
	}
	scan_chunk.Initialize(allocator, scan_chunk_types);
	ResetForReuse();
}

void RadixHTLocalSourceState::ResetForReuse() {
	task = RadixHTSourceTaskType::NO_TASK;
	task_idx = DConstants::INVALID_INDEX;
	ht.reset();
	scan_status = RadixHTScanStatus::DONE;
	aggregate_allocator.Reset();
	row_state.addresses.reset();
	scan_state.Reset();
	scan_chunk.Reset();
}

void RadixPartitionedHashTable::ResetLocalSourceState(ExecutionContext &context, LocalSourceState &lstate_p) const {
	auto &lstate = lstate_p.Cast<RadixHTLocalSourceState>();
	lstate.ResetForReuse();
}

void RadixHTLocalSourceState::ExecuteTask(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate,
                                          DataChunk &chunk) {
	D_ASSERT(task != RadixHTSourceTaskType::NO_TASK);
	switch (task) {
	case RadixHTSourceTaskType::FINALIZE:
		Finalize(sink, gstate);
		break;
	case RadixHTSourceTaskType::SCAN:
		Scan(sink, gstate, chunk);
		break;
	default:
		throw InternalException("Unexpected RadixHTSourceTaskType in ExecuteTask!");
	}
}

void RadixHTLocalSourceState::Finalize(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate) {
	D_ASSERT(task == RadixHTSourceTaskType::FINALIZE);
	D_ASSERT(scan_status != RadixHTScanStatus::IN_PROGRESS);
	auto &partition = *sink.partitions[task_idx];

	// When a partition holds exported states, it gets a fresh HT so that its arena can be
	// released as soon as the partition has been scanned
	const auto imports_states = partition.exported_data != nullptr;
	const auto fresh_ht = !ht || imports_states;
	if (fresh_ht) {
		// This capacity would always be sufficient for all data
		const auto exported_count = partition.exported_data ? partition.exported_data->Count() : 0;
		const auto capacity = GroupedAggregateHashTable::GetCapacityForCount(partition.data->Count() + exported_count);

		// However, we will limit the initial capacity so we don't do a huge over-allocation
		const auto n_threads = TaskScheduler::GetScheduler(gstate.context).NumberOfThreads();
		const auto memory_limit = BufferManager::GetBufferManager(gstate.context).GetMaxMemory();
		const idx_t thread_limit = LossyNumericCast<idx_t>(0.6 * double(memory_limit) / double(n_threads));

		const idx_t size_per_entry = partition.data->SizeInBytes() / MaxValue<idx_t>(partition.data->Count(), 1) +
		                             idx_t(GroupedAggregateHashTable::LOAD_FACTOR * sizeof(ht_entry_t));
		// but not lower than the initial capacity
		const auto capacity_limit =
		    MaxValue(NextPowerOfTwo(thread_limit / size_per_entry), GroupedAggregateHashTable::InitialCapacity());

		ht = sink.radix_ht.CreateHT(gstate.context, MinValue<idx_t>(capacity, capacity_limit), 0);
	} else {
		ht->Abandon();
	}

	// Now combine the uncombined data using this thread's HT
	ht->Combine(*partition.data, &partition.progress);
	if (partition.exported_data) {
		// Rebuild the exported states on an arena of their own, one chunk at a time, and combine
		// them like the rest. Combining may steal from the imported states, so the arena lives
		// until the scan is done.
		partition.import_allocator = make_shared_ptr<ArenaAllocator>(BufferAllocator::Get(gstate.context));
		AggregateStateSpilling::ImportStates(gstate.context, sink.radix_ht.GetLayoutPtr(), *sink.spill_plan,
		                                     *partition.exported_data, *partition.import_allocator,
		                                     [&](TupleDataCollection &imported) { ht->Combine(imported); });
		partition.exported_data.reset();
	}
	partition.progress = 1;

	// Move the combined data back to the partition
	partition.data =
	    make_uniq<TupleDataCollection>(BufferManager::GetBufferManager(gstate.context), sink.radix_ht.GetLayoutPtr(),
	                                   MemoryTag::HASH_TABLE, nullptr, gstate.context);
	partition.data->Combine(*ht->AcquirePartitionedData()->GetPartitions()[0]);

	// Update thread-global state
	const annotated_lock_guard<annotated_mutex> guard {sink.lock};
	if (imports_states) {
		// The arena only holds this partition's states, release it once the partition is scanned
		partition.allocator = ht->GetAggregateAllocator();
	} else {
		sink.stored_allocators.emplace_back(ht->GetAggregateAllocator());
	}
	if (task_idx == sink.partitions.size()) {
		ht.reset();
	}
	const auto finalizes_done = ++sink.finalize_done;
	D_ASSERT(finalizes_done <= sink.partitions.size());
	if (finalizes_done == sink.partitions.size()) {
		// All finalizes are done, set remaining size to 0
		sink.temporary_memory_state->SetZero();
	}

	// Update partition state
	const annotated_lock_guard<annotated_mutex> partition_guard {partition.lock};
	partition.state = AggregatePartitionState::READY_TO_SCAN;
	partition.UnblockTasks();

	// This thread will scan the partition
	task = RadixHTSourceTaskType::SCAN;
	scan_status = RadixHTScanStatus::INIT;
}

void RadixHTLocalSourceState::Scan(RadixHTGlobalSinkState &sink, RadixHTGlobalSourceState &gstate, DataChunk &chunk) {
	D_ASSERT(task == RadixHTSourceTaskType::SCAN);
	D_ASSERT(scan_status != RadixHTScanStatus::DONE);

	auto &partition = *sink.partitions[task_idx];
	D_ASSERT(partition.state == AggregatePartitionState::READY_TO_SCAN);
	auto &data_collection = *partition.data;

	if (scan_status == RadixHTScanStatus::INIT) {
		data_collection.InitializeScan(scan_state, gstate.column_ids, sink.scan_pin_properties);
		scan_status = RadixHTScanStatus::IN_PROGRESS;
	}

	if (!data_collection.Scan(scan_state, scan_chunk)) {
		if (sink.scan_pin_properties == TupleDataPinProperties::DESTROY_AFTER_DONE) {
			data_collection.Reset();
			partition.allocator.reset();
			partition.import_allocator.reset();
		}
		scan_status = RadixHTScanStatus::DONE;
		const annotated_lock_guard<annotated_mutex> guard {sink.lock};
		if (++gstate.task_done == sink.partitions.size()) {
			gstate.finished = true;
		}
		return;
	}

	const auto group_cols = layout.ColumnCount() - 1;
	RowOperations::FinalizeStates(row_state, layout, scan_state.chunk_state.row_locations, scan_chunk, group_cols);

	if (sink.scan_pin_properties == TupleDataPinProperties::DESTROY_AFTER_DONE && layout.HasDestructor()) {
		RowOperations::DestroyStates(row_state, layout, scan_state.chunk_state.row_locations);
	}

	auto &radix_ht = sink.radix_ht;
	idx_t chunk_index = 0;
	for (auto &entry : radix_ht.grouping_set) {
		chunk.data[entry].Reference(scan_chunk.data[chunk_index++]);
	}
	for (auto null_group : radix_ht.null_groups) {
		ConstantVector::SetNull(chunk.data[null_group], count_t(scan_chunk.size()));
	}
	D_ASSERT(radix_ht.grouping_set.size() + radix_ht.null_groups.size() == radix_ht.op.GroupCount());
	for (idx_t col_idx = 0; col_idx < radix_ht.op.aggregates.size(); col_idx++) {
		chunk.data[radix_ht.op.GroupCount() + col_idx].Reference(
		    scan_chunk.data[radix_ht.group_types.size() + col_idx]);
	}
	D_ASSERT(radix_ht.op.grouping_functions.size() == radix_ht.grouping_values.size());
	for (idx_t i = 0; i < radix_ht.op.grouping_functions.size(); i++) {
		chunk.data[radix_ht.op.GroupCount() + radix_ht.op.aggregates.size() + i].Reference(radix_ht.grouping_values[i],
		                                                                                   count_t(scan_chunk.size()));
	}
	D_ASSERT(chunk.size() != 0);
}

bool RadixHTLocalSourceState::TaskFinished() {
	switch (task) {
	case RadixHTSourceTaskType::FINALIZE:
		return true;
	case RadixHTSourceTaskType::SCAN:
		return scan_status == RadixHTScanStatus::DONE;
	default:
		D_ASSERT(task == RadixHTSourceTaskType::NO_TASK);
		return true;
	}
}

SourceResultType RadixPartitionedHashTable::GetData(ExecutionContext &context, DataChunk &chunk,
                                                    GlobalSinkState &sink_p, OperatorSourceInput &input) const {
	auto &sink = sink_p.Cast<RadixHTGlobalSinkState>();
	D_ASSERT(sink.finalized);

	auto &gstate = input.global_state.Cast<RadixHTGlobalSourceState>();
	auto &lstate = input.local_state.Cast<RadixHTLocalSourceState>();
	D_ASSERT(sink.scan_pin_properties == TupleDataPinProperties::UNPIN_AFTER_DONE ||
	         sink.scan_pin_properties == TupleDataPinProperties::DESTROY_AFTER_DONE);

	if (gstate.finished) {
		return SourceResultType::FINISHED;
	}

	if (sink.count_before_combining == 0) {
		if (grouping_set.empty()) {
			// Special case hack to sort out aggregating from empty intermediates for aggregations without groups
			D_ASSERT(chunk.ColumnCount() == null_groups.size() + op.aggregates.size() + op.grouping_functions.size());
			// For each column in the aggregates, set to initial state
			chunk.SetChildCardinality(1);
			for (auto null_group : null_groups) {
				ConstantVector::SetNull(chunk.data[null_group], count_t(1));
			}
			ArenaAllocator allocator(BufferAllocator::Get(context.client));
			for (idx_t i = 0; i < op.aggregates.size(); i++) {
				D_ASSERT(op.aggregates[i]->GetExpressionClass() == ExpressionClass::BOUND_AGGREGATE);
				auto &aggr = op.aggregates[i]->Cast<BoundAggregateExpression>();
				AggregateStateInput state_input(aggr.Function(), aggr.BindInfo().get());
				auto aggr_state =
				    make_unsafe_uniq_array_uninitialized<data_t>(aggr.Function().GetStateSizeCallback()(state_input));
				data_ptr_t state_ptr = aggr_state.get();
				aggr.Function().GetStateInitCallback()(state_input, &state_ptr, 1);

				AggregateFinalizeInputData aggr_input_data(aggr, allocator);
				Vector state_vector(Value::POINTER(CastPointerToValue(aggr_state.get())), count_t(1));
				auto &agg_result = chunk.data[null_groups.size() + i];
				aggr.Function().GetStateFinalizeCallback()(state_vector, aggr_input_data, agg_result, 1, 0);
				FlatVector::SetSize(agg_result, count_t(1));
				if (aggr.Function().HasStateDestructorCallback()) {
					aggr.Function().GetStateDestructorCallback()(state_vector, aggr_input_data, 1);
				}
			}
			// Place the grouping values (all the groups of the grouping_set condensed into a single value)
			// Behind the null groups + aggregates
			for (idx_t i = 0; i < op.grouping_functions.size(); i++) {
				chunk.data[null_groups.size() + op.aggregates.size() + i].Reference(grouping_values[i], count_t(1));
			}
		}
		gstate.finished = true;
		return SourceResultType::FINISHED;
	}

	while (!gstate.finished && chunk.size() == 0) {
		if (lstate.TaskFinished()) {
			const auto res = gstate.AssignTask(sink, lstate, input.interrupt_state);
			if (res != SourceResultType::HAVE_MORE_OUTPUT) {
				D_ASSERT(res == SourceResultType::FINISHED || res == SourceResultType::BLOCKED);
				return res;
			}
		}
		lstate.ExecuteTask(sink, gstate, chunk);
	}

	if (chunk.size() != 0) {
		return SourceResultType::HAVE_MORE_OUTPUT;
	} else {
		return SourceResultType::FINISHED;
	}
}

ProgressData RadixPartitionedHashTable::GetProgress(ClientContext &, GlobalSinkState &sink_p,
                                                    GlobalSourceState &gstate_p) const {
	auto &sink = sink_p.Cast<RadixHTGlobalSinkState>();
	auto &gstate = gstate_p.Cast<RadixHTGlobalSourceState>();

	// Get partition combine progress, weigh it 2x
	ProgressData progress;
	for (auto &partition : sink.partitions) {
		progress.done += 2.0 * partition->progress;
	}

	// Get scan progress, weigh it 1x
	progress.done += 1.0 * double(gstate.task_done);

	// Divide by 3x for the weights, and the number of partitions to get a value between 0 and 1 again
	progress.total += 3.0 * double(sink.partitions.size());

	return progress;
}

} // namespace duckdb
