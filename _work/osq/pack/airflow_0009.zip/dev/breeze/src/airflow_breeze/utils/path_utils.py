# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
Useful tools for various Paths used inside Airflow Sources.
"""

from __future__ import annotations

import hashlib
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from airflow_breeze import NAME
from airflow_breeze.utils.console import console_print
from airflow_breeze.utils.functools_cache import clearable_cache
from airflow_breeze.utils.reinstall import inform_about_self_upgrade, reinstall_breeze, warn_non_editable
from airflow_breeze.utils.shared_options import get_verbose, set_forced_answer

PYPROJECT_TOML_FILE = "pyproject.toml"

# Location and markers of the breeze shim installed by scripts/tools/setup_breeze
# (ADR 0017). Used to detect a stale installed shim and tell the user to re-run
# the setup script.
BREEZE_SHIM_PATH = Path.home() / ".local" / "bin" / "breeze"
BREEZE_SHIM_MARKER = "Apache Airflow breeze shim — managed by scripts/tools/setup_breeze"
BREEZE_SHIM_VERSION_PREFIX = "# breeze-shim-version:"
SETUP_BREEZE_SHIM_VERSION_PREFIX = "SHIM_VERSION="


def search_upwards_for_airflow_root_path(start_from: Path) -> Path | None:
    root = Path(start_from.root)
    directory = start_from
    while directory != root:
        airflow_candidate_init_py = directory / "airflow-core" / "src" / "airflow" / "__init__.py"
        if airflow_candidate_init_py.exists() and "airflow" in airflow_candidate_init_py.read_text().lower():
            return directory
        airflow_2_candidate_init_py = directory / "airflow" / "__init__.py"
        if (
            airflow_2_candidate_init_py.exists()
            and "airflow" in airflow_2_candidate_init_py.read_text().lower()
            and directory.parent.name != "src"
        ):
            return directory
        directory = directory.parent
    return None


def in_autocomplete() -> bool:
    return os.environ.get(f"_{NAME.upper()}_COMPLETE") is not None


def in_self_upgrade() -> bool:
    return "self-upgrade" in sys.argv


def in_help() -> bool:
    return "--help" in sys.argv or "-h" in sys.argv


def skip_breeze_self_upgrade_check():
    return (
        in_self_upgrade()
        or in_autocomplete()
        or in_help()
        or hasattr(sys, "_called_from_test")
        or os.environ.get("SKIP_BREEZE_SELF_UPGRADE_CHECK")
    )


def skip_group_output():
    return in_autocomplete() or in_help() or os.environ.get("SKIP_GROUP_OUTPUT") is not None


def get_pyproject_toml_hash(sources: Path) -> str:
    try:
        the_hash = hashlib.new("blake2b")
        the_hash.update((sources / "dev" / "breeze" / PYPROJECT_TOML_FILE).read_bytes())
        return the_hash.hexdigest()
    except FileNotFoundError as e:
        return f"Missing file {e.filename}"


def get_installation_sources_config_metadata_hash() -> str:
    """
    Retrieves hash of pyproject.toml from the source of installation of Breeze.

    This is used in order to determine if we need to upgrade Breeze, because some
    setup files changed. Blake2b algorithm will not be flagged by security checkers
    as insecure algorithm (in Python 3.9 and above we can use `usedforsecurity=False`
    to disable it, but for now it's better to use more secure algorithms.
    """
    installation_sources = get_installation_airflow_sources()
    if installation_sources is None:
        return "NOT FOUND"
    return get_pyproject_toml_hash(installation_sources)


def get_used_sources_setup_metadata_hash() -> str:
    """
    Retrieves hash of setup files from the currently used sources.
    """
    return get_pyproject_toml_hash(get_used_airflow_sources())


def set_forced_answer_for_upgrade_check():
    """When we run upgrade check --answer is not parsed yet, so we need to guess it."""
    if "--answer n" in " ".join(sys.argv).lower() or os.environ.get("ANSWER", "").lower().startswith("n"):
        set_forced_answer("no")
    if "--answer y" in " ".join(sys.argv).lower() or os.environ.get("ANSWER", "").lower().startswith("y"):
        set_forced_answer("yes")
    if "--answer q" in " ".join(sys.argv).lower() or os.environ.get("ANSWER", "").lower().startswith("q"):
        set_forced_answer("quit")


MY_BREEZE_ROOT_PATH = Path(__file__).resolve().parents[1]


def reinstall_if_setup_changed() -> bool:
    """
    Prints warning if detected airflow sources are not the ones that Breeze was installed with.
    :return: True if warning was printed.
    """
    try:
        res = subprocess.run(
            ["uv", "tool", "upgrade", "apache-airflow-breeze"],
            cwd=MY_BREEZE_ROOT_PATH,
            check=False,
            text=True,
            capture_output=True,
        )
        if res.returncode == 0 and "Modified" in res.stderr:
            inform_about_self_upgrade()
            return True
    except FileNotFoundError:
        pass
    return False


def reinstall_if_different_sources(airflow_sources: Path) -> bool:
    """
    Prints warning if detected airflow sources are not the ones that Breeze was installed with.
    :param airflow_sources: source for airflow code that we are operating on
    :return: True if warning was printed.
    """
    installation_airflow_sources = get_installation_airflow_sources()
    if installation_airflow_sources and airflow_sources != installation_airflow_sources:
        reinstall_breeze(airflow_sources / "dev" / "breeze")
        return True
    return False


def get_installation_airflow_sources() -> Path | None:
    """
    Retrieves the Root of the Airflow Sources where Breeze was installed from.
    :return: the Path for Airflow sources.
    """
    return search_upwards_for_airflow_root_path(Path(__file__).resolve().parent)


def get_used_airflow_sources() -> Path:
    """
    Retrieves the Root of used Airflow Sources which we operate on. Those are either Airflow sources found
    upwards in directory tree or sources where Breeze was installed from.
    :return: the Path for Airflow sources we use.
    """
    current_sources = search_upwards_for_airflow_root_path(Path.cwd())
    if current_sources is None:
        current_sources = get_installation_airflow_sources()
        if current_sources is None:
            warn_non_editable()
            sys.exit(1)
    return current_sources


def _parse_shim_version(shim_text: str) -> int | None:
    """Read the ``# breeze-shim-version: N`` marker from an installed shim, if present."""
    for line in shim_text.splitlines():
        stripped = line.strip()
        if stripped.startswith(BREEZE_SHIM_VERSION_PREFIX):
            value = stripped[len(BREEZE_SHIM_VERSION_PREFIX) :].strip()
            try:
                return int(value)
            except ValueError:
                return None
    return None


def get_expected_shim_version(airflow_sources: Path) -> int | None:
    """Read ``SHIM_VERSION`` that the current sources' ``setup_breeze`` would install."""
    setup_script = airflow_sources / "scripts" / "tools" / "setup_breeze"
    try:
        for line in setup_script.read_text().splitlines():
            stripped = line.strip()
            if stripped.startswith(SETUP_BREEZE_SHIM_VERSION_PREFIX):
                value = stripped[len(SETUP_BREEZE_SHIM_VERSION_PREFIX) :].strip().strip("\"'")
                try:
                    return int(value)
                except ValueError:
                    return None
    except OSError:
        return None
    return None


def warn_if_shim_outdated(airflow_sources: Path, shim_text: str | None = None) -> bool:
    """
    Warn if the installed breeze shim is older than the one the current sources would install.

    The shim at ``~/.local/bin/breeze`` (see ADR 0017) carries a ``# breeze-shim-version: N``
    marker. When the shim body changes, ``scripts/tools/setup_breeze`` bumps that version, so an
    installed shim with a lower (or missing) version means the user is running a stale shim and
    should re-run the setup script. Only our own managed shim is inspected — a ``uv tool`` / ``pipx``
    install or a user's own script at that path is left alone.

    :param airflow_sources: Airflow sources breeze is operating on.
    :param shim_text: contents of the installed shim, if already read by the caller.
    :return: True if a warning was printed.
    """
    if shim_text is None:
        try:
            shim_text = BREEZE_SHIM_PATH.read_text() if BREEZE_SHIM_PATH.is_file() else ""
        except OSError:
            return False
    if BREEZE_SHIM_MARKER not in shim_text:
        # Not our managed shim (uv tool / pipx install, or the user's own script).
        return False
    expected_version = get_expected_shim_version(airflow_sources)
    if expected_version is None:
        return False
    installed_version = _parse_shim_version(shim_text)
    if installed_version is not None and installed_version >= expected_version:
        return False
    setup_script = airflow_sources / "scripts" / "tools" / "setup_breeze"
    installed_text = installed_version if installed_version is not None else "unknown (pre-versioning)"
    console_print(
        f"\n[warning]Your breeze shim at {BREEZE_SHIM_PATH} is out of date "
        f"(installed: {installed_text}, current: {expected_version}).[/]\n"
        "[warning]Re-run the setup script to refresh it:[/]\n\n"
        f"     {setup_script}\n"
    )
    return True


def has_uv_breeze_tool_dir() -> bool:
    """Tell whether uv owns a tool directory for breeze."""
    try:
        result = subprocess.run(["uv", "tool", "dir"], text=True, capture_output=True, check=False)
    except FileNotFoundError:
        return False
    if result.returncode != 0:
        return False
    tool_dir = result.stdout.strip()
    return bool(tool_dir) and (Path(tool_dir) / "apache-airflow-breeze").is_dir()


def detect_legacy_global_breeze_install() -> str | None:
    """
    Detect a legacy global breeze install superseded by the shim (ADR 0017).

    :return: ``"uv"`` or ``"pipx"`` if breeze is installed as a global ``uv tool`` / ``pipx``
        install, otherwise ``None``.
    """
    try:
        result = subprocess.run(["uv", "tool", "list"], text=True, capture_output=True, check=False)
        if result.returncode == 0 and "apache-airflow-breeze" in result.stdout:
            return "uv"
    except FileNotFoundError:
        pass
    # `uv tool list` drops a tool whose environment is corrupted, so an install the listing above
    # cannot see may still be there, owning ~/.local/bin/breeze.
    if has_uv_breeze_tool_dir():
        return "uv"
    try:
        result = subprocess.run(["pipx", "list", "--short"], text=True, capture_output=True, check=False)
        if result.returncode == 0 and "apache-airflow-breeze" in result.stdout:
            return "pipx"
    except FileNotFoundError:
        pass
    return None


def warn_if_breeze_launcher_outdated(airflow_sources: Path) -> bool:
    """
    Warn when the breeze launcher in use is not the current recommended shim (ADR 0017).

    Covers both ways an installation can be out of date:

    * the managed shim at ``~/.local/bin/breeze`` exists but is older than the one the current
      sources would install (e.g. ``$AIRFLOW_REPO_ROOT`` support was added) — re-run the setup
      script to refresh it;
    * breeze is still installed as a legacy global ``uv tool`` / ``pipx`` install (no shim) — that
      install keeps working but is no longer recommended; point the user at migrating to the shim.

    :param airflow_sources: Airflow sources breeze is operating on.
    :return: True if a warning was printed.
    """
    try:
        shim_text = BREEZE_SHIM_PATH.read_text() if BREEZE_SHIM_PATH.is_file() else ""
    except OSError:
        shim_text = ""
    if BREEZE_SHIM_MARKER in shim_text:
        # Our managed shim is installed — only check that it is current.
        return warn_if_shim_outdated(airflow_sources, shim_text=shim_text)
    legacy = detect_legacy_global_breeze_install()
    if legacy is None:
        return False
    uninstall_cmd = (
        "uv tool uninstall apache-airflow-breeze"
        if legacy == "uv"
        else "pipx uninstall apache-airflow-breeze"
    )
    setup_script = airflow_sources / "scripts" / "tools" / "setup_breeze"
    console_print(
        f"\n[warning]Breeze is installed as a legacy global '{legacy}' install, which still works "
        "but is no longer the recommended setup (see ADR 0017).[/]\n"
        "[warning]Migrate to the per-worktree uvx shim by uninstalling the global install and "
        "running the setup script:[/]\n\n"
        f"     {uninstall_cmd}\n"
        f"     {setup_script}\n"
    )
    return True


@clearable_cache
def find_airflow_root_path_to_operate_on() -> Path:
    """
    Find the root of airflow sources we operate on. Handle the case when Breeze is installed via
    `pipx` or `uv tool` from a different source tree, so it searches upwards of the current directory
    to find the right root of airflow directory we are actually in. This **might** be different
    than the sources of Airflow Breeze was installed from.

    If not found, we operate on Airflow sources that we were installed it. This handles the case when
    we run Breeze from a "random" directory.

    This method also handles the following errors and warnings:

       * It fails (and exits hard) if Breeze is installed in non-editable mode (in which case it will
         not find the Airflow sources when walking upwards the directory where it is installed)
       * It warns (with 2 seconds timeout) if you are using Breeze from a different airflow sources than
         the one you operate on.
       * If we are running in the same source tree as where Breeze was installed from (so no warning above),
         it warns (with 2 seconds timeout) if there is a change in setup.* files of Breeze since installation
         time. In such case usesr is encouraged to re-install Breeze to update dependencies.

    :return: Path for the found sources.

    """
    sources_root_from_env = os.getenv("AIRFLOW_ROOT_PATH", None)
    if sources_root_from_env:
        # Set by the shim (ADR 0017) — the global self-upgrade checks below are skipped in this
        # path (the shim also exports SKIP_BREEZE_SELF_UPGRADE_CHECK), so check here that the
        # installed shim itself is not stale. Ignore SKIP here on purpose: the shim always sets it.
        airflow_sources_from_env = Path(sources_root_from_env)
        if not in_autocomplete() and not in_help() and not hasattr(sys, "_called_from_test"):
            warn_if_breeze_launcher_outdated(airflow_sources_from_env)
        return airflow_sources_from_env
    installation_airflow_sources = get_installation_airflow_sources()
    if installation_airflow_sources is None and not skip_breeze_self_upgrade_check():
        console_print(
            "\n[error]Breeze should only be installed with --editable flag[/]\n\n"
            "[warning]Please go to Airflow sources and run[/]\n\n"
            f"     {NAME} setup self-upgrade --use-current-airflow-sources\n"
            '[warning]If during installation you see warning starting "Ignoring --editable install",[/]\n'
            '[warning]make sure you first downgrade "packaging" package to <23.2, for example by:[/]\n\n'
            f'     pip install "packaging<23.2"\n\n'
        )
        sys.exit(1)
    airflow_sources = get_used_airflow_sources()
    if not skip_breeze_self_upgrade_check():
        # only print warning and sleep if not producing complete results
        reinstall_if_different_sources(airflow_sources)
        reinstall_if_setup_changed()
        # Not invoked via the shim (no AIRFLOW_ROOT_PATH). If breeze is still on a legacy global
        # uv tool / pipx install, nudge the user to migrate to the recommended shim (ADR 0017).
        warn_if_breeze_launcher_outdated(airflow_sources)
    os.chdir(airflow_sources.as_posix())
    airflow_home_dir = Path(os.environ.get("AIRFLOW_HOME", (Path.home() / "airflow").resolve().as_posix()))
    if airflow_sources.resolve() == airflow_home_dir.resolve():
        console_print(
            f"\n[error]Your Airflow sources are checked out in {airflow_home_dir} which "
            f"is your also your AIRFLOW_HOME where airflow writes logs and database. \n"
            f"This is a bad idea because Airflow might override and cleanup your checked out "
            f"sources and .git repository.[/]\n"
        )
        console_print("\nPlease check out your Airflow code elsewhere.\n")
        sys.exit(1)
    return airflow_sources


AIRFLOW_ROOT_PATH = find_airflow_root_path_to_operate_on().resolve()
AIRFLOW_PYPROJECT_TOML_FILE_PATH = AIRFLOW_ROOT_PATH / "pyproject.toml"
AIRFLOW_CORE_ROOT_PATH = AIRFLOW_ROOT_PATH / "airflow-core"
AIRFLOW_CORE_SOURCES_PATH = AIRFLOW_CORE_ROOT_PATH / "src"
AIRFLOW_TASK_SDK_ROOT_PATH = AIRFLOW_ROOT_PATH / "task-sdk"
AIRFLOW_TASK_SDK_SOURCES_PATH = AIRFLOW_TASK_SDK_ROOT_PATH / "src"
AIRFLOW_WWW_DIR = AIRFLOW_CORE_SOURCES_PATH / "airflow" / "www"
AIRFLOW_UI_DIR = AIRFLOW_CORE_SOURCES_PATH / "airflow" / "ui"
# Do not delete it - it is used for old commit retrieval from providers
AIRFLOW_ORIGINAL_PROVIDERS_DIR = AIRFLOW_ROOT_PATH / "airflow" / "providers"
AIRFLOW_PROVIDERS_ROOT_PATH = AIRFLOW_ROOT_PATH / "providers"
AIRFLOW_PROVIDERS_LAST_RELEASE_DATE_PATH = AIRFLOW_PROVIDERS_ROOT_PATH / ".last_release_date.txt"
AIRFLOW_DIST_PATH = AIRFLOW_ROOT_PATH / "dist"

TASK_SDK_ROOT_PATH = AIRFLOW_ROOT_PATH / "task-sdk"
TASK_SDK_DIST_PATH = TASK_SDK_ROOT_PATH / "dist"
TASK_SDK_SOURCES_PATH = TASK_SDK_ROOT_PATH / "src"

AIRFLOW_CTL_ROOT_PATH = AIRFLOW_ROOT_PATH / "airflow-ctl"
AIRFLOW_CTL_SOURCES_PATH = AIRFLOW_CTL_ROOT_PATH / "src"
AIRFLOW_CTL_DIST_PATH = AIRFLOW_CTL_ROOT_PATH / "dist"

MYPY_ROOT_PATH = AIRFLOW_ROOT_PATH / "dev" / "mypy"
MYPY_SOURCES_PATH = MYPY_ROOT_PATH / "src"
MYPY_DIST_PATH = MYPY_ROOT_PATH / "dist"

# Same here - do not remove those this is used for past commit retrieval
PREVIOUS_AIRFLOW_PROVIDERS_SOURCES_PATH = AIRFLOW_PROVIDERS_ROOT_PATH / "src"
PREVIOUS_AIRFLOW_PROVIDERS_NS_PACKAGE_PATH = PREVIOUS_AIRFLOW_PROVIDERS_SOURCES_PATH / "airflow" / "providers"
PREVIOUS_TESTS_PROVIDERS_ROOT = AIRFLOW_PROVIDERS_ROOT_PATH / "tests"
PREVIOUS_SYSTEM_TESTS_PROVIDERS_PATH = AIRFLOW_PROVIDERS_ROOT_PATH / "tests" / "system"

AIRFLOW_DEVEL_COMMON_PATH = AIRFLOW_ROOT_PATH / "devel-common"
DOCS_ROOT = AIRFLOW_ROOT_PATH / "docs"
BUILD_CACHE_PATH = AIRFLOW_ROOT_PATH / ".build"
GENERATED_PATH = AIRFLOW_ROOT_PATH / "generated"
CONSTRAINTS_CACHE_PATH = BUILD_CACHE_PATH / "constraints"
PROVIDER_DEPENDENCIES_JSON_PATH = GENERATED_PATH / "provider_dependencies.json"
PROVIDER_DEPENDENCIES_JSON_HASH_PATH = GENERATED_PATH / "provider_dependencies.json.sha256sum"
PROVIDER_METADATA_JSON_PATH = GENERATED_PATH / "provider_metadata.json"
UI_CACHE_PATH = BUILD_CACHE_PATH / "ui"
AIRFLOW_TMP_PATH = AIRFLOW_ROOT_PATH / "tmp"
UI_ASSET_COMPILE_LOCK = UI_CACHE_PATH / ".asset_compile.lock"
UI_ASSET_OUT_FILE = UI_CACHE_PATH / "asset_compile.out"
UI_ASSET_OUT_DEV_MODE_FILE = UI_CACHE_PATH / "asset_compile_dev_mode.out"
UI_ASSET_HASH_PATH = AIRFLOW_ROOT_PATH / ".build" / "ui" / "hash.txt"

UI_NODE_MODULES_PATH = AIRFLOW_CORE_SOURCES_PATH / "airflow" / "ui" / "node_modules"
UI_DIST_PATH = AIRFLOW_CORE_SOURCES_PATH / "airflow" / "ui" / "dist"
UI_VITE_MANIFEST_PATH = UI_DIST_PATH / ".vite" / "manifest.json"
FAST_API_SIMPLE_AUTH_MANAGER_PATH = (
    AIRFLOW_CORE_SOURCES_PATH / "airflow" / "api_fastapi" / "auth" / "managers" / "simple"
)
FAST_API_SIMPLE_AUTH_MANAGER_NODE_MODULES_PATH = FAST_API_SIMPLE_AUTH_MANAGER_PATH / "ui" / "node_modules"
FAST_API_SIMPLE_AUTH_MANAGER_DIST_PATH = FAST_API_SIMPLE_AUTH_MANAGER_PATH / "ui" / "dist"
FAST_API_SIMPLE_AUTH_MANAGER_VITE_MANIFEST_PATH = (
    FAST_API_SIMPLE_AUTH_MANAGER_DIST_PATH / ".vite" / "manifest.json"
)
EDGE_PLUGIN_PATH = (
    AIRFLOW_PROVIDERS_ROOT_PATH / "edge3" / "src" / "airflow" / "providers" / "edge3" / "plugins" / "www"
)
EDGE_PLUGIN_UI_NODE_MODULES_PATH = EDGE_PLUGIN_PATH / "node_modules"
EDGE_PLUGIN_UI_DIST_PATH = EDGE_PLUGIN_PATH / "dist"
EDGE_PLUGIN_PREK_HOOK = "compile-edge-assets"
FAB_AUTH_MANAGER_WWW_PATH = (
    AIRFLOW_PROVIDERS_ROOT_PATH / "fab" / "src" / "airflow" / "providers" / "fab" / "www"
)
FAB_AUTH_MANAGER_WWW_NODE_MODULES_PATH = FAB_AUTH_MANAGER_WWW_PATH / "node_modules"
FAB_AUTH_MANAGER_WWW_DIST_PATH = FAB_AUTH_MANAGER_WWW_PATH / "static" / "dist"
FAB_AUTH_MANAGER_WWW_PREK_HOOK = "compile-fab-assets"

COMMON_AI_PLUGIN_PATH = (
    AIRFLOW_PROVIDERS_ROOT_PATH
    / "common"
    / "ai"
    / "src"
    / "airflow"
    / "providers"
    / "common"
    / "ai"
    / "plugins"
    / "www"
)
COMMON_AI_UI_PLUGIN_NODE_MODULES_PATH = COMMON_AI_PLUGIN_PATH / "node_modules"
COMMON_AI_UI_PLUGIN_DIST_PATH = COMMON_AI_PLUGIN_PATH / "dist"
COMMON_AI_PLUGIN_PREK_HOOK = "compile-common-ai-provider-assets"


DAGS_PATH = AIRFLOW_ROOT_PATH / "dags"
FILES_PATH = AIRFLOW_ROOT_PATH / "files"
FILES_SBOM_PATH = FILES_PATH / "sbom"
KUBE_PATH = AIRFLOW_ROOT_PATH / ".kube"
LOGS_PATH = AIRFLOW_ROOT_PATH / "logs"
OUT_PATH = AIRFLOW_ROOT_PATH / "out"

REPRODUCIBLE_PATH = OUT_PATH / "reproducible"
DOCS_DIR = AIRFLOW_ROOT_PATH / "docs"
SCRIPTS_CI_PATH = AIRFLOW_ROOT_PATH / "scripts" / "ci"
SCRIPTS_DOCKER_PATH = AIRFLOW_ROOT_PATH / "scripts" / "docker"
SCRIPTS_CI_DOCKER_COMPOSE_PATH = SCRIPTS_CI_PATH / "docker-compose"
SCRIPTS_CI_DOCKER_COMPOSE_BASE_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "base.yml"
SCRIPTS_CI_DOCKER_COMPOSE_BASE_PORTS_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "base-ports.yml"
SCRIPTS_CI_DOCKER_COMPOSE_CI_TESTS_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "ci-tests.yml"
SCRIPTS_CI_DOCKER_COMPOSE_DEBUG_PORTS_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "debug-ports.yml"
SCRIPTS_CI_DOCKER_COMPOSE_DOCKER_SOCKET_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "docker-socket.yml"
SCRIPTS_CI_DOCKER_COMPOSE_ENABLE_TTY_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "enable-tty.yml"
SCRIPTS_CI_DOCKER_COMPOSE_FILES_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "files.yml"
SCRIPTS_CI_DOCKER_COMPOSE_FORWARD_CREDENTIALS_PATH = (
    SCRIPTS_CI_DOCKER_COMPOSE_PATH / "forward-credentials.yml"
)
SCRIPTS_CI_DOCKER_COMPOSE_INTEGRATION_CELERY_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "integration-celery.yml"
SCRIPTS_CI_DOCKER_COMPOSE_INTEGRATION_KERBEROS_PATH = (
    SCRIPTS_CI_DOCKER_COMPOSE_PATH / "integration-kerberos.yml"
)
SCRIPTS_CI_DOCKER_COMPOSE_LOCAL_ALL_SOURCES_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "local-all-sources.yml"
SCRIPTS_CI_DOCKER_COMPOSE_LOCAL_YAML_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "local.yml"
SCRIPTS_CI_DOCKER_COMPOSE_MOUNT_UI_DIST_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "mount-ui-dist.yml"
SCRIPTS_CI_DOCKER_COMPOSE_MYPY_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "local.yml"
SCRIPTS_CI_DOCKER_COMPOSE_PROVIDERS_AND_TESTS_SOURCES_PATH = (
    SCRIPTS_CI_DOCKER_COMPOSE_PATH / "providers-and-tests-sources.yml"
)
SCRIPTS_CI_DOCKER_COMPOSE_REMOVE_SOURCES_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "remove-sources.yml"
SCRIPTS_CI_DOCKER_COMPOSE_TESTS_SOURCES_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "tests-sources.yml"
GENERATED_DOCKER_COMPOSE_ENV_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "_generated_docker_compose.env"
GENERATED_DOCKER_ENV_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "_generated_docker.env"
GENERATED_DOCKER_LOCK_PATH = SCRIPTS_CI_DOCKER_COMPOSE_PATH / "_generated.lock"
DOCKER_CONTEXT_PATH = AIRFLOW_ROOT_PATH / "docker-context-files"
CACHE_TEMP_PATH = tempfile.TemporaryDirectory()
OUTPUT_LOG_PATH = Path(CACHE_TEMP_PATH.name, "out.log")
BREEZE_ROOT_PATH = AIRFLOW_ROOT_PATH / "dev" / "breeze"
BREEZE_SOURCES_PATH = BREEZE_ROOT_PATH / "src"
BREEZE_DOC_PATH = BREEZE_ROOT_PATH / "doc"
BREEZE_IMAGES_PATH = BREEZE_DOC_PATH / "images"
AIRFLOW_HOME_PATH = Path(os.environ.get("AIRFLOW_HOME", Path.home() / "airflow"))


def create_volume_if_missing(volume_name: str):
    from airflow_breeze.utils.run_utils import run_command

    res_inspect = run_command(
        cmd=["docker", "volume", "inspect", volume_name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if res_inspect.returncode != 0:
        result = run_command(
            cmd=["docker", "volume", "create", volume_name],
            check=False,
            capture_output=True,
        )
        if result.returncode != 0:
            console_print(
                "[warning]\nMypy Cache volume could not be created. Continuing, but you "
                "should make sure your docker works.\n\n"
                f"Error: {result.stdout}\n"
            )


def create_mypy_volume_if_needed():
    create_volume_if_missing("mypy-cache-volume")


def create_directories_and_files() -> None:
    """
    Creates all directories and files that are needed for Breeze to work via docker-compose.
    Checks if setup has been updates since last time and proposes to upgrade if so.
    """
    BUILD_CACHE_PATH.mkdir(parents=True, exist_ok=True)
    DAGS_PATH.mkdir(parents=True, exist_ok=True)
    FILES_PATH.mkdir(parents=True, exist_ok=True)
    KUBE_PATH.mkdir(parents=True, exist_ok=True)
    LOGS_PATH.mkdir(parents=True, exist_ok=True)
    AIRFLOW_DIST_PATH.mkdir(parents=True, exist_ok=True)
    OUTPUT_LOG_PATH.mkdir(parents=True, exist_ok=True)
    (AIRFLOW_ROOT_PATH / ".bash_aliases").touch()
    (AIRFLOW_ROOT_PATH / ".bash_history").touch()
    (AIRFLOW_ROOT_PATH / ".inputrc").touch()


def cleanup_python_generated_files():
    if get_verbose():
        console_print("[info]Cleaning .pyc and __pycache__")
    permission_errors = []
    for dirpath, dirnames, filenames in os.walk(AIRFLOW_ROOT_PATH):
        # Skip node_modules and hidden directories (.*) — modify in place to prune os.walk
        dirnames[:] = [d for d in dirnames if d != "node_modules" and not d.startswith(".")]
        for filename in filenames:
            if filename.endswith(".pyc"):
                path = Path(dirpath) / filename
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
                except PermissionError:
                    permission_errors.append(path)
        if Path(dirpath).name == "__pycache__":
            try:
                shutil.rmtree(dirpath)
            except FileNotFoundError:
                pass
            except PermissionError:
                permission_errors.append(Path(dirpath))
            dirnames.clear()
    if permission_errors:
        if platform.uname().system.lower() == "linux":
            console_print("[warning]There were files that you could not clean-up:\n")
            console_print(permission_errors)
            console_print(
                "Please run at earliest convenience:\n"
                "[warning]breeze ci fix-ownership[/]\n\n"
                "If you have sudo you can use:\n"
                "[warning]breeze ci fix-ownership --use-sudo[/]\n\n"
                "This will fix ownership of those.\n"
                "You can also remove those files manually using sudo."
            )
        else:
            console_print("[warnings]There were files that you could not clean-up:\n")
            console_print(permission_errors)
            console_print("You can also remove those files manually using sudo.")
    if get_verbose():
        console_print("[info]Cleaned")


def get_main_git_dir_for_worktree() -> Path | None:
    """
    Detect if we are in a git worktree and return the main repository's .git directory.

    Git worktrees store a ``.git`` *file* (not a directory) containing a ``gitdir:`` reference
    pointing to ``<main-repo>/.git/worktrees/<name>``.  This helper resolves that reference
    (handling both absolute and relative paths) and returns the main ``.git`` directory
    (i.e. the grandparent of the ``gitdir`` path).

    :return: Absolute path to the main repository's ``.git`` directory, or ``None``
             if the current checkout is not a worktree.
    """
    git_path = AIRFLOW_ROOT_PATH / ".git"
    if git_path.is_file():
        git_content = git_path.read_text().strip()
        if git_content.startswith("gitdir:"):
            gitdir = Path(git_content.removeprefix("gitdir:").strip())
            if not gitdir.is_absolute():
                gitdir = (AIRFLOW_ROOT_PATH / gitdir).resolve()
            # gitdir points to <main-repo>/.git/worktrees/<name>
            # .parent.parent gives us <main-repo>/.git
            main_git_dir = gitdir.parent.parent
            return main_git_dir if main_git_dir.is_dir() else None
    return None
