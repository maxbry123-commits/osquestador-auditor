# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import sys

import click
from rich.table import Table

from airflow_breeze.commands.common_options import (
    option_answer,
    option_dry_run,
    option_github_repository,
    option_github_token,
    option_verbose,
)
from airflow_breeze.utils.click_utils import BreezeGroup
from airflow_breeze.utils.confirm import Answer, user_confirm
from airflow_breeze.utils.console import console_print
from airflow_breeze.utils.github import format_github_token_scope_guidance, retrieve_github_token
from airflow_breeze.utils.shared_options import get_dry_run


@click.group(cls=BreezeGroup, name="issues", help="Tools for managing GitHub issues.")
def issues_group():
    pass


def _resolve_github_token(github_token: str | None) -> str | None:
    """Resolve GitHub token from option, environment, or gh CLI."""
    return retrieve_github_token(github_token, description="airflow-issues-unassign", scopes="public_repo")


def _get_collaborator_logins(repo) -> set[str]:
    """Fetch all collaborator logins for the repository."""
    console_print("[info]Fetching repository collaborators...[/]")
    collaborators = {c.login for c in repo.get_collaborators()}
    console_print(f"[info]Found {len(collaborators)} collaborators.[/]")
    return collaborators


def _issue_link(github_repository: str, number: int) -> str:
    """Return a Rich-formatted clickable link for a GitHub issue."""
    url = f"https://github.com/{github_repository}/issues/{number}"
    return f"[link={url}]#{number}[/link]"


def _user_link(login: str) -> str:
    """Return a Rich-formatted clickable link for a GitHub user."""
    url = f"https://github.com/{login}"
    return f"[link={url}]@{login}[/link]"


def _process_batch(
    batch: list[tuple],
    dry_run: bool,
    github_repository: str,
) -> int:
    """Display a batch of proposed unassignments and handle confirmation.

    Returns the number of issues actually unassigned.
    """
    if not batch:
        return 0

    table = Table(title="Proposed unassignments")
    table.add_column("Issue #", style="cyan", justify="right")
    table.add_column("Title", style="white")
    table.add_column("Non-collaborator assignees", style="red")
    for issue, non_collab_logins in batch:
        table.add_row(
            _issue_link(github_repository, issue.number),
            issue.title[:80],
            ", ".join(_user_link(login) for login in sorted(non_collab_logins)),
        )
    console_print(table)

    if dry_run:
        console_print("[warning]Dry run — skipping actual unassignment.[/]")
        return 0

    answer = user_confirm("Unassign the above non-collaborators?")
    if answer == Answer.QUIT:
        console_print("[warning]Quitting.[/]")
        sys.exit(0)
    if answer == Answer.NO:
        console_print("[info]Skipping this batch.[/]")
        return 0

    unassigned_count = 0
    for issue, non_collab_logins in batch:
        issue_ref = _issue_link(github_repository, issue.number)
        for login in non_collab_logins:
            user_ref = _user_link(login)
            console_print(f"  Removing [red]{user_ref}[/] from issue {issue_ref}")
            issue.remove_from_assignees(login)
            comment = (
                f"@{login} We are unassigning you from this issue as part of our "
                f"updated [assignment policy]"
                f"(https://github.com/apache/airflow/blob/main/"
                f"contributing-docs/04_how_to_contribute.rst"
                f"#contribute-code-changes).\n\n"
                f"This is not meant to discourage your contribution — quite the opposite! "
                f"You are still very welcome to work on this issue and submit a PR for it. "
                f"Simply comment that you are working on it and open a PR when ready.\n\n"
                f"We found that formal assignments were not working well, as they often "
                f"prevented others from contributing when the assignee was not actively "
                f"working on the issue."
            )
            console_print(f"  Commenting on issue {issue_ref} about {user_ref}")
            issue.create_comment(comment)
            unassigned_count += 1
    return unassigned_count


@issues_group.command(name="unassign", help="Unassign non-collaborators from open issues.")
@option_github_token
@option_github_repository
@click.option(
    "--batch-size",
    type=int,
    default=100,
    show_default=True,
    help="Number of flagged issues to accumulate before prompting.",
)
@click.option(
    "--max-num",
    type=int,
    default=0,
    show_default=True,
    help="Maximum number of issues to flag for unassignment. 0 means no limit.",
)
@option_dry_run
@option_verbose
@option_answer
def unassign(
    github_token: str | None,
    github_repository: str,
    batch_size: int,
    max_num: int,
):
    from github import Github

    token = _resolve_github_token(github_token)
    if not token:
        console_print(
            "[error]GitHub token not found. Provide --github-token, "
            "set GITHUB_TOKEN, or authenticate with `gh auth login`. "
            f"{format_github_token_scope_guidance(description='airflow-issues-unassign', scopes='public_repo')}[/]"
        )
        sys.exit(1)

    g = Github(token)
    repo = g.get_repo(github_repository)
    collaborators = _get_collaborator_logins(repo)

    dry_run = get_dry_run()

    batch: list[tuple] = []
    total_issues_scanned = 0
    total_flagged = 0
    total_unassigned = 0

    console_print(f"[info]Scanning open issues in {github_repository}...[/]")

    for issue in repo.get_issues(state="open"):
        total_issues_scanned += 1
        if not issue.assignees:
            continue
        non_collab = {a.login for a in issue.assignees if a.login not in collaborators}
        if not non_collab:
            continue

        batch.append((issue, non_collab))
        total_flagged += 1

        if max_num and total_flagged >= max_num:
            break

        if len(batch) >= batch_size:
            total_unassigned += _process_batch(batch, dry_run, github_repository)
            batch = []

    # Process remaining batch
    total_unassigned += _process_batch(batch, dry_run, github_repository)

    console_print()
    console_print("[success]Done![/]")
    console_print(f"  Issues scanned:    {total_issues_scanned}")
    console_print(f"  Issues flagged:    {total_flagged}")
    console_print(f"  Assignees removed: {total_unassigned}")
