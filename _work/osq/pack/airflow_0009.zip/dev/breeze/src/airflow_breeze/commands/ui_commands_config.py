# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

UI_COMMANDS: dict[str, str | list[str]] = {
    "name": "UI commands",
    "commands": [
        "check-translation-completeness",
        "compile-assets",
    ],
}

UI_PARAMETERS: dict[str, list[dict[str, str | list[str]]]] = {
    "breeze ui check-translation-completeness": [
        {
            "name": "Translation options",
            "options": [
                "--language",
                "--add-missing",
                "--remove-unused",
            ],
        },
    ],
    "breeze ui compile-assets": [
        {
            "name": "Compile ui assets flags",
            "options": [
                "--dev",
                "--force-clean",
            ],
        }
    ],
}
