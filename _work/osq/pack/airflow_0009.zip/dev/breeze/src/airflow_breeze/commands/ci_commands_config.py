# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

CI_COMMANDS: dict[str, str | list[str]] = {
    "name": "CI commands",
    "commands": [
        "fix-ownership",
        "free-space",
        "resource-check",
        "selective-check",
        "get-workflow-info",
        "upgrade",
        "set-milestone",
    ],
}
CI_PARAMETERS: dict[str, list[dict[str, str | list[str]]]] = {
    "breeze ci fix-ownership": [
        {
            "name": "Fix ownership flags",
            "options": [
                "--use-sudo",
            ],
        }
    ],
    "breeze ci free-space": [],
    "breeze ci selective-check": [
        {
            "name": "Selective check flags",
            "options": [
                "--commit-ref",
                "--pr-labels",
                "--default-branch",
                "--default-constraints-branch",
                "--platform",
            ],
        },
        {
            "name": "GitHub parameters",
            "options": [
                "--github-event-name",
                "--github-repository",
                "--github-actor",
                "--github-context",
                "--github-context-input",
            ],
        },
    ],
    "breeze ci get-workflow-info": [
        {
            "name": "Get workflow info flags",
            "options": [
                "--github-context",
                "--github-context-input",
            ],
        }
    ],
    "breeze ci resource-check": [],
    "breeze ci upgrade": [
        {
            "name": "Upgrade flags",
            "options": [
                "--target-branch",
                "--create-pr",
                "--draft",
                "--switch-to-base",
                "--airflow-site",
                "--force-k8s-schema-sync",
                "--github-token",
            ],
        },
        {
            "name": "Upgrade steps",
            "options": [
                "--autoupdate",
                "--update-chart-dependencies",
                "--upgrade-important-versions",
                "--update-uv-lock",
                "--k8s-schema-sync",
            ],
        },
    ],
    "breeze ci set-milestone": [
        {
            "name": "PR information",
            "options": [
                "--pr-number",
                "--pr-title",
                "--pr-labels",
                "--base-branch",
                "--merged-by",
            ],
        },
        {
            "name": "GitHub parameters",
            "options": [
                "--github-token",
                "--github-repository",
            ],
        },
    ],
}
