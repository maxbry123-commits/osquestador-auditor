# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import json
import os
import re
import sys

import click

from airflow_breeze.commands.common_options import argument_doc_packages
from airflow_breeze.utils.click_utils import BreezeGroup
from airflow_breeze.utils.console import console_print
from airflow_breeze.utils.custom_param_types import BetterChoice
from airflow_breeze.utils.gh_workflow_utils import trigger_workflow_and_monitor
from airflow_breeze.utils.github import run_gh_command

WORKFLOW_NAME_MAPS = {
    "publish-docs": "publish-docs-to-s3.yml",
    "airflow-refresh-site": "build.yml",
    "sync-s3-to-github": "s3-to-github.yml",
    "release-constraints": "release-constraints.yml",
}

# X.Y.Z or X.Y.ZrcN - the workflow derives the release stage from which of the two it is given,
# so there is no separate switch that could disagree with the version.
RELEASE_VERSION_PATTERN = re.compile(r"^\d+\.\d+\.\d+(rc\d+)?$")

APACHE_AIRFLOW_REPO = "apache/airflow"
APACHE_AIRFLOW_SITE_REPO = "apache/airflow-site"
APACHE_AIRFLOW_SITE_ARCHIVE_REPO = "apache/airflow-site-archive"


@click.group(cls=BreezeGroup, name="workflow-run", help="Tools to manage Airflow repository workflows ")
def workflow_run_group():
    pass


@workflow_run_group.command(name="publish-docs", help="Trigger publish docs to S3 workflow")
@click.option(
    "--ref",
    help="Git reference tag to checkout to build documentation.",
    required=True,
)
@click.option(
    "--skip-tag-validation",
    help="Skip validation of the tag. Allows to use `main` or commit hash. Use with caution.",
    is_flag=True,
)
@click.option(
    "--exclude-docs",
    help="Comma separated short name list of docs packages to exclude from the publish. (example: apache.druid,google)",
    default="no-docs-excluded",
)
@click.option(
    "--site-env",
    help="S3 bucket to which the documentation will be published.",
    default="auto",
    type=BetterChoice(["auto", "live", "staging"]),
)
@click.option(
    "--skip-write-to-stable-folder",
    help="Skip writing to stable folder.",
    is_flag=True,
)
@click.option(
    "--airflow-version",
    help="Override Airflow Version to use for the docs build. "
    "If not provided, it will be extracted from the ref. If only base version is provided, it will be "
    "set to the same as the base version.",
    default=None,
    type=str,
)
@click.option(
    "--airflow-base-version",
    help="Override Airflow Base Version to use for the docs build. "
    "If not provided, it will be extracted from the ref. If airflow-version is provided, the "
    "base version of the version provided (i.e. stripped pre-/post-/dev- suffixes).",
    default=None,
    type=str,
)
@click.option(
    "--apply-commits",
    help="Apply commits before building the docs - for example to patch fixes "
    "to the docs (comma separated list of commits). ",
    default=None,
    type=str,
)
@click.option(
    "--workflow-branch",
    help="Git ref the workflow DEFINITION runs from. Defaults to the value of --ref, so the "
    "workflow version matches the content being built (running main's workflow against an "
    "older tag breaks when inputs/jobs have since changed). Pass an explicit ref to override "
    "(e.g. 'main').",
    default=None,
    type=str,
)
@click.option(
    "--ignore-missing-inventories",
    help="Do not fail the build on missing third-party inventories.",
    is_flag=True,
)
@argument_doc_packages
def workflow_run_publish(
    ref: str,
    exclude_docs: str,
    site_env: str,
    skip_tag_validation: bool,
    doc_packages: tuple[str, ...],
    skip_write_to_stable_folder: bool = False,
    airflow_version: str | None = None,
    airflow_base_version: str | None = None,
    apply_commits: str | None = None,
    workflow_branch: str | None = None,
    ignore_missing_inventories: bool = False,
):
    # Default the workflow-definition ref to the ref being built, so the workflow version
    # matches the content. Running main's workflow against an older tag breaks when the
    # workflow's inputs/jobs have changed since that tag (e.g. a newly required input).
    if workflow_branch is None:
        workflow_branch = ref
    if len(doc_packages) == 0:
        console_print(
            "[red]Error: No doc packages provided. Please provide at least one doc package.[/red]",
        )
        sys.exit(1)
    if os.environ.get("GITHUB_TOKEN", ""):
        console_print(
            "\n[warning]GITHUB_TOKEN is set; Breeze will try your `gh auth login` first and only "
            "use this token as a fallback. The fallback token must have workflow-trigger scope."
        )
    console_print(
        f"[blue]Validating ref: {ref}[/blue]",
    )

    if not skip_tag_validation:
        tag_result = run_gh_command(
            ["gh", "api", f"repos/apache/airflow/git/refs/tags/{ref}"],
            capture_output=True,
        )

        stdout = tag_result.stdout.decode("utf-8")
        tag_respo = json.loads(stdout)

        if not tag_respo.get("ref"):
            # Check whether the ref exists as a branch (common case for -docs branches)
            branch_result = run_gh_command(
                ["gh", "api", f"repos/apache/airflow/git/refs/heads/{ref}"],
                capture_output=True,
                check=False,
            )
            branch_stdout = branch_result.stdout.decode("utf-8")
            branch_respo = json.loads(branch_stdout)

            if branch_respo.get("ref"):
                console_print(
                    f"[red]Error: Ref {ref} exists as a branch but not as a tag.[/red]",
                )
                console_print(
                    "\nTo publish docs from a branch (e.g. a `providers/YYYY-MM-DD-docs` "
                    "post-release fix branch), add [bold]--skip-tag-validation[/bold] to your command."
                )
            else:
                console_print(
                    f"[red]Error: Ref {ref} does not exist as a tag or branch in repo apache/airflow.[/red]",
                )
                console_print("\nYou can add --skip-tag-validation to skip this validation.")
            sys.exit(1)

    console_print(
        f"[blue]Triggering workflow {WORKFLOW_NAME_MAPS['publish-docs']}: at {APACHE_AIRFLOW_REPO}[/blue]",
    )
    from packaging.version import InvalidVersion, Version

    if airflow_version:
        try:
            Version(airflow_version)
        except InvalidVersion as e:
            f"[red]Invalid version passed as --airflow-version:  {airflow_version}[/red]: {e}"
            sys.exit(1)
        console_print(
            f"[blue]Using provided Airflow version: {airflow_version}[/blue]",
        )
    if airflow_base_version:
        try:
            Version(airflow_base_version)
        except InvalidVersion as e:
            f"[red]Invalid base version passed as --airflow-base-version:  {airflow_version}[/red]: {e}"
            sys.exit(1)
        console_print(
            f"[blue]Using provided Airflow base version: {airflow_base_version}[/blue]",
        )
    if not airflow_version and airflow_base_version:
        airflow_version = airflow_base_version
    if airflow_version and not airflow_base_version:
        airflow_base_version = Version(airflow_version).base_version

    joined_packages = " ".join(doc_packages)
    if "providers" in joined_packages and "apache-airflow-providers" not in joined_packages:
        joined_packages = joined_packages + " apache-airflow-providers"

    workflow_fields = {
        "ref": ref,
        "destination": site_env,
        "include-docs": joined_packages,
        "exclude-docs": exclude_docs,
        "skip-write-to-stable-folder": skip_write_to_stable_folder,
        "build-sboms": "true" if "apache-airflow" in doc_packages else "false",
        "apply-commits": apply_commits if apply_commits else "",
        "ignore-missing-inventories": str(ignore_missing_inventories).lower(),
    }

    if airflow_version:
        workflow_fields["airflow-version"] = airflow_version
    if airflow_base_version:
        workflow_fields["airflow-base-version"] = airflow_base_version

    trigger_workflow_and_monitor(
        workflow_name=WORKFLOW_NAME_MAPS["publish-docs"],
        repo=APACHE_AIRFLOW_REPO,
        branch=workflow_branch,
        **workflow_fields,
    )

    if site_env == "auto":
        pattern = re.compile(r"^.*[0-9]+\.[0-9]+\.[0-9]+$")
        if pattern.match(ref):
            site_env = "live"
        else:
            site_env = "staging"

    branch = "main" if site_env == "live" else "staging"

    console_print(
        f"[blue]Refreshing site at {APACHE_AIRFLOW_SITE_REPO}[/blue]",
    )
    wf_name = WORKFLOW_NAME_MAPS["airflow-refresh-site"]

    console_print(
        f"[blue]Triggering workflow {wf_name}: at {APACHE_AIRFLOW_SITE_REPO}[/blue]",
    )

    trigger_workflow_and_monitor(
        workflow_name=wf_name,
        repo=APACHE_AIRFLOW_SITE_REPO,
        branch=branch,
    )

    console_print(
        f"[blue]Refreshing completed workflow {wf_name}: at {APACHE_AIRFLOW_SITE_REPO}[/blue]",
    )

    workflow_fields = {"source": site_env}

    console_print(
        f"[blue]Syncing S3 docs to GitHub repository at {APACHE_AIRFLOW_SITE_ARCHIVE_REPO}[/blue]",
    )
    trigger_workflow_and_monitor(
        workflow_name=WORKFLOW_NAME_MAPS["sync-s3-to-github"],
        repo=APACHE_AIRFLOW_SITE_ARCHIVE_REPO,
        branch=branch,
        **workflow_fields,
        monitor=False,
    )


@workflow_run_group.command(
    name="release-constraints",
    help="Trigger the workflow that resolves, publishes and tags the constraints for a release.",
)
@click.option(
    "--version",
    help="Version the constraints belong to. A candidate (3.1.3rc1) resolves with pre-releases "
    "allowed and lands on a branch of its own; a final (3.1.3) resolves without them and commits "
    "onto constraints-X-Y. The stage is derived from this, so it cannot be set inconsistently.",
    required=True,
)
@click.option(
    "--ref",
    help="Git ref the constraints are resolved from, e.g. 'v3-1-stable' or the release tag.",
    required=True,
)
@click.option(
    "--workflow-branch",
    help="Git ref the workflow DEFINITION runs from. Defaults to 'main', which is normally what "
    "you want: unlike the docs build, the constraints do not have to be produced by the workflow "
    "as it stood at the ref being released.",
    default="main",
    show_default=True,
)
def workflow_run_release_constraints(version: str, ref: str, workflow_branch: str):
    if not RELEASE_VERSION_PATTERN.match(version):
        console_print(f"[red]Error: '{version}' is not a release version - expected X.Y.Z or X.Y.ZrcN.[/red]")
        sys.exit(1)
    stage = "candidate" if "rc" in version else "final"
    console_print(f"[blue]Triggering constraints generation for the {stage} {version} from {ref}[/blue]")
    trigger_workflow_and_monitor(
        workflow_name=WORKFLOW_NAME_MAPS["release-constraints"],
        repo=APACHE_AIRFLOW_REPO,
        branch=workflow_branch,
        version=version,
        ref=ref,
    )
