# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

REGISTRY_COMMANDS: dict[str, str | list[str]] = {
    "name": "Registry commands",
    "commands": [
        "extract-data",
        "backfill",
        "publish-versions",
    ],
}

REGISTRY_PARAMETERS: dict[str, list[dict[str, str | list[str]]]] = {
    "breeze registry extract-data": [
        {
            "name": "Extract data flags",
            "options": [
                "--python",
                "--provider",
                "--allow-unreleased",
            ],
        },
    ],
    "breeze registry backfill": [
        {
            "name": "Backfill flags",
            "options": [
                "--python",
                "--provider",
                "--version",
                "--use-docker",
            ],
        },
    ],
    "breeze registry publish-versions": [
        {
            "name": "Publish versions flags",
            "options": [
                "--s3-bucket",
                "--providers-json",
            ],
        },
    ],
}
