<!--- Hugo front matter used to generate the website version of this page:
linkTitle: Prometheus
--->

# Metrics Exporter - Prometheus

**Status**: [Mixed](../../document-status.md)

<details>
<summary>Table of Contents</summary>

<!-- START doctoc -->

- [Prometheus Exporter Model](#prometheus-exporter-model)
  * [Pull Metric Exporter](#pull-metric-exporter)
  * [Metric Conversion](#metric-conversion)
  * [Client Libraries](#client-libraries)
  * [Version and Format](#version-and-format)
- [SDK Metric Output](#sdk-metric-output)
  * [Target](#target)
  * [Temporality](#temporality)
- [Configuration](#configuration)
  * [Host](#host)
  * [Port](#port)
  * [Default Aggregation](#default-aggregation)
  * [Resource Attributes as Metric Labels](#resource-attributes-as-metric-labels)
  * [Translation Strategy](#translation-strategy)
  * [Scope Info](#scope-info)
  * [Target Info](#target-info)
- [Content Negotiation](#content-negotiation)
  * [Interaction with Translation Strategy](#interaction-with-translation-strategy)

<!-- END doctoc -->

</details>

## Prometheus Exporter Model

### Pull Metric Exporter

**Status**: [Development](../../document-status.md)

A Prometheus Exporter MUST be a [Pull Metric Exporter](../sdk.md#pull-metric-exporter)
which responds to HTTP requests with Prometheus metrics in the appropriate format.

### Metric Conversion

**Status**: [Development](../../document-status.md)

OpenTelemetry metrics MUST be converted to Prometheus metrics according to the
[Prometheus Compatibility specification](../../compatibility/prometheus_and_openmetrics.md).

### Client Libraries

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter SHOULD use an official [Prometheus client library](https://prometheus.io/docs/instrumenting/clientlibs/)
when one exists for the implementation language and it is practical to do so
(e.g., dependency concerns) for serving Prometheus metrics; it SHOULD NOT use an
unofficial Prometheus client library.
This allows the Prometheus client to negotiate
the [format](https://github.com/prometheus/docs/blob/main/docs/instrumenting/exposition_formats.md)
of the response using the `Content-Type` header. If a Prometheus client library
is used, the OpenTelemetry Prometheus Exporter SHOULD be modeled as a
[custom Collector](https://prometheus.io/docs/instrumenting/writing_clientlibs/#overall-structure)
so it can be used in conjunction with existing Prometheus instrumentation.

### Version and Format

**Status**: [Stable](../../document-status.md)

Regardless of whether a Prometheus client library is used, the Prometheus
Exporter MUST support version `0.0.4` of the
[Text-based format](https://github.com/prometheus/docs/blob/main/docs/instrumenting/exposition_formats.md#prometheus-text-format).
A Prometheus Exporter MAY support Exemplars and Exponential Histograms,
which are [not currently supported by the Prometheus text format](../../compatibility/prometheus_and_openmetrics.md#differences-between-prometheus-formats),
by supporting other Protocols, but is not required to implement them.

A Prometheus Exporter for an OpenTelemetry metrics SDK MUST NOT use
[Prometheus Remote Write format](https://github.com/prometheus/prometheus/blob/main/prompb/remote.proto)
or [OpenMetrics protobuf format](https://github.com/prometheus/OpenMetrics/blob/v1.0.0/specification/OpenMetrics.md#protobuf-format).

A Prometheus Exporter for an OpenTelemetry metrics SDK SHOULD NOT add
[explicit timestamps on Metric points](https://github.com/prometheus/OpenMetrics/blob/v1.0.0/specification/OpenMetrics.md#metric).

## SDK Metric Output

### Target

**Status**: [Stable](../../document-status.md)

There MUST be at most one `target` info metric exposed by an SDK
Prometheus exporter.

### Temporality

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter MUST set
the [MetricReader](../sdk.md#metricreader) `temporality` as a function of
instrument kind to be `cumulative` for all instrument kinds.

## Configuration

### Host

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter SHOULD support a configuration option to set the host
that metrics are served on. The option MAY be named `host`, and MUST be `localhost`
by default.

### Port

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter SHOULD support a configuration option to set the port
that metrics are served on. The option MAY be named `port`, and MUST be `9464` by
default.

### Default Aggregation

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter SHOULD support a configuration option to set
the [MetricReader](../sdk.md#metricreader) default `aggregation` as a function
of instrument kind. This option MAY be named `default_aggregation`, and MUST use
the [default aggregation](../sdk.md#default-aggregation) by default.

### Resource Attributes as Metric Labels

**Status**: [Development](../../document-status.md)

A Prometheus Exporter MAY offer configuration to add resource attributes as metric labels.
By default, it MUST NOT add any resource attributes as metric labels.
The configuration SHOULD allow the user to select resource attributes to include or exclude. Copied Resource attributes MUST NOT be
excluded from the `target_info` metric. The option SHOULD be named `resource_constant_labels`.

### Translation Strategy

**Status**: [Development](../../document-status.md)

A Prometheus Exporter MAY support a configuration option that controls the translation of metric names from OpenTelemetry Naming Conventions to [Prometheus Naming conventions](https://prometheus.io/docs/practices/naming/).
If the Prometheus exporter supports such configuration it MUST be named to something that resembles Prometheus configuration option `translation_strategy`, and the translation options MUST be:

- `UnderscoreEscapingWithSuffixes`, the default. This fully escapes metric names for classic Prometheus metric name compatibility, and includes appending type and unit suffixes.
- `UnderscoreEscapingWithoutSuffixes`, metric names will continue to escape special characters to `_`, but suffixes won't be attached.
- `NoUTF8EscapingWithSuffixes` will disable changing special characters to `_`. Special suffixes like units and `_total` for counters will be attached.
- `NoTranslation`. This strategy bypasses all metric and label name translation, passing them through unaltered.

### Scope Info

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter MAY support configuration to specify whether metrics include
[scope labels](../../compatibility/prometheus_and_openmetrics.md#instrumentation-scope-1).
The option MAY be named `scope_info_enabled`, and MUST be `true` by default.

### Target Info

**Status**: [Development](../../document-status.md)

A Prometheus Exporter MAY support a configuration to specify whether to produce a
[target info](../../compatibility/prometheus_and_openmetrics.md#resource-attributes-1) metric.
The option MAY be named `target_info_enabled`, and MUST be `true` by default.

## Content Negotiation

**Status**: [Stable](../../document-status.md)

A Prometheus Exporter MUST support content negotiation to allow clients to request
metrics in different formats based on the `Accept` header in HTTP requests. Content
negotiation MUST follow [Prometheus Content Negotiation guidelines](https://prometheus.io/docs/instrumenting/content_negotiation/).

If no `Accept` header is provided and no fallback protocol is configured, the
exporter MUST use Prometheus text format 0.0.4 (`text/plain; version=0.0.4`) and
apply `underscores` escaping.

### Interaction with Translation Strategy

**Status**: [Stable](../../document-status.md)

Regardless of the configured `translation_strategy`, the final output format and
character escaping MUST comply with the content negotiation's restrictions based
on the `Accept` header.

First, `translation_strategy` MUST be applied to construct metric names. Then,
the Prometheus Exporter MUST apply content negotiation, which may include a
second translation of metric names using the requested
[escaping scheme](https://prometheus.io/docs/instrumenting/escaping_schemes/).

For example, for a counter metric named `foo.bar` with unit `By`:

| `translation_strategy` | No `escaping` parameter or `escaping=underscores` | `escaping=allow-utf-8` |
| :--- | :--- | :--- |
| `UnderscoreEscapingWithSuffixes` | `foo_bar_bytes_total` | `foo_bar_bytes_total` |
| `UnderscoreEscapingWithoutSuffixes` | `foo_bar` | `foo_bar` |
| `NoUTF8EscapingWithSuffixes` | `foo_bar_bytes_total` | `foo.bar_bytes_total` |
| `NoTranslation` | `foo_bar` | `foo.bar` |
