export type Maybe<T> = T | null;
export type InputMaybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K];
};
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]?: Maybe<T[SubKey]>;
};
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]: Maybe<T[SubKey]>;
};
export type MakeEmpty<
  T extends { [key: string]: unknown },
  K extends keyof T,
> = { [_ in K]?: never };
export type Incremental<T> =
  | T
  | {
      [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never;
    };
/** All built-in and custom scalars, mapped to their actual values */
export interface Scalars {
  ID: { input: string; output: string };
  String: { input: string; output: string };
  Boolean: { input: boolean; output: boolean };
  Int: { input: number; output: number };
  Float: { input: number; output: number };
  /** A date-time string at UTC, such as 2019-12-03T09:54:33Z, compliant with the date-time format. */
  DateTime: { input: string; output: string };
  /** The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSON: { input: Record<string, string>; output: Record<string, string> };
  /** The `JSONObject` scalar type represents JSON objects as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSONObject: { input: any; output: any };
  /** The `SafeInt` scalar type represents non-fractional signed whole numeric values that are considered safe as defined by the ECMAScript specification. */
  SafeInt: { input: number; output: number };
  /** The `Upload` scalar type represents a file upload. */
  Upload: { input: File; output: File };
}

export interface AdminAllSharedLink {
  __typename?: 'AdminAllSharedLink';
  docId: Scalars['String']['output'];
  docUpdatedAt: Maybe<Scalars['DateTime']['output']>;
  guestViews: Maybe<Scalars['SafeInt']['output']>;
  lastAccessedAt: Maybe<Scalars['DateTime']['output']>;
  lastUpdaterId: Maybe<Scalars['String']['output']>;
  publishedAt: Maybe<Scalars['DateTime']['output']>;
  shareUrl: Scalars['String']['output'];
  title: Maybe<Scalars['String']['output']>;
  uniqueViews: Maybe<Scalars['SafeInt']['output']>;
  views: Maybe<Scalars['SafeInt']['output']>;
  workspaceId: Scalars['String']['output'];
  workspaceOwnerId: Maybe<Scalars['String']['output']>;
}

export interface AdminAllSharedLinkEdge {
  __typename?: 'AdminAllSharedLinkEdge';
  cursor: Scalars['String']['output'];
  node: AdminAllSharedLink;
}

export interface AdminAllSharedLinksFilterInput {
  analyticsWindowDays?: InputMaybe<Scalars['Int']['input']>;
  includeTotal?: InputMaybe<Scalars['Boolean']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  orderBy?: InputMaybe<AdminSharedLinksOrder>;
  updatedAfter?: InputMaybe<Scalars['DateTime']['input']>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface AdminDashboard {
  __typename?: 'AdminDashboard';
  blobStorageBytes: Scalars['SafeInt']['output'];
  blobStorageHistory: Array<AdminDashboardValueDayPoint>;
  copilotConversations: Scalars['SafeInt']['output'];
  copilotWindow: TimeWindow;
  generatedAt: Scalars['DateTime']['output'];
  storageWindow: TimeWindow;
  syncActiveUsers: Scalars['Int']['output'];
  syncActiveUsersTimeline: Array<AdminDashboardMinutePoint>;
  syncWindow: TimeWindow;
  topSharedLinks: Array<AdminSharedLinkTopItem>;
  topSharedLinksWindow: TimeWindow;
  workspaceStorageBytes: Scalars['SafeInt']['output'];
  workspaceStorageHistory: Array<AdminDashboardValueDayPoint>;
}

export interface AdminDashboardInput {
  copilotWindowDays?: InputMaybe<Scalars['Int']['input']>;
  sharedLinkWindowDays?: InputMaybe<Scalars['Int']['input']>;
  storageHistoryDays?: InputMaybe<Scalars['Int']['input']>;
  syncHistoryHours?: InputMaybe<Scalars['Int']['input']>;
  timezone?: InputMaybe<Scalars['String']['input']>;
}

export interface AdminDashboardMinutePoint {
  __typename?: 'AdminDashboardMinutePoint';
  activeUsers: Scalars['Int']['output'];
  minute: Scalars['DateTime']['output'];
}

export interface AdminDashboardValueDayPoint {
  __typename?: 'AdminDashboardValueDayPoint';
  date: Scalars['DateTime']['output'];
  value: Scalars['SafeInt']['output'];
}

export interface AdminLicensePreview {
  __typename?: 'AdminLicensePreview';
  endAt: Scalars['DateTime']['output'];
  entity: Scalars['String']['output'];
  expiresAt: Scalars['DateTime']['output'];
  id: Scalars['String']['output'];
  issuedAt: Scalars['DateTime']['output'];
  issuer: Scalars['String']['output'];
  plan: SubscriptionPlan;
  quantity: Scalars['Int']['output'];
  recurring: SubscriptionRecurring;
  valid: Scalars['Boolean']['output'];
  workspaceId: Scalars['String']['output'];
}

export interface AdminMailDeliveriesInput {
  hours?: Scalars['Int']['input'];
}

export interface AdminMailDeliveryAnalytics {
  __typename?: 'AdminMailDeliveryAnalytics';
  byOutcome: Array<AdminMailDeliverySeries>;
  byStatus: Array<AdminMailDeliverySeries>;
  byType: Array<AdminMailDeliverySeries>;
  summary: AdminMailDeliverySummary;
  window: TimeWindow;
}

export interface AdminMailDeliveryPoint {
  __typename?: 'AdminMailDeliveryPoint';
  bucket: Scalars['DateTime']['output'];
  count: Scalars['Int']['output'];
}

export interface AdminMailDeliverySeries {
  __typename?: 'AdminMailDeliverySeries';
  key: Scalars['String']['output'];
  label: Scalars['String']['output'];
  points: Array<AdminMailDeliveryPoint>;
  total: Scalars['Int']['output'];
}

export interface AdminMailDeliverySummary {
  __typename?: 'AdminMailDeliverySummary';
  canceled: Scalars['Int']['output'];
  failed: Scalars['Int']['output'];
  queued: Scalars['Int']['output'];
  retryWait: Scalars['Int']['output'];
  sending: Scalars['Int']['output'];
  sent: Scalars['Int']['output'];
  skipped: Scalars['Int']['output'];
  successRate: Scalars['Float']['output'];
  total: Scalars['Int']['output'];
}

export interface AdminSharedLinkTopItem {
  __typename?: 'AdminSharedLinkTopItem';
  docId: Scalars['String']['output'];
  guestViews: Scalars['SafeInt']['output'];
  lastAccessedAt: Maybe<Scalars['DateTime']['output']>;
  publishedAt: Maybe<Scalars['DateTime']['output']>;
  shareUrl: Scalars['String']['output'];
  title: Maybe<Scalars['String']['output']>;
  uniqueViews: Scalars['SafeInt']['output'];
  views: Scalars['SafeInt']['output'];
  workspaceId: Scalars['String']['output'];
}

export enum AdminSharedLinksOrder {
  PublishedAtDesc = 'PublishedAtDesc',
  UpdatedAtDesc = 'UpdatedAtDesc',
  ViewsDesc = 'ViewsDesc',
}

export interface AdminUpdateWorkspaceInput {
  avatarKey?: InputMaybe<Scalars['String']['input']>;
  enableAi?: InputMaybe<Scalars['Boolean']['input']>;
  enableDocEmbedding?: InputMaybe<Scalars['Boolean']['input']>;
  enableSharing?: InputMaybe<Scalars['Boolean']['input']>;
  enableUrlPreview?: InputMaybe<Scalars['Boolean']['input']>;
  id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
  public?: InputMaybe<Scalars['Boolean']['input']>;
}

export interface AdminWorkspace {
  __typename?: 'AdminWorkspace';
  avatarKey: Maybe<Scalars['String']['output']>;
  blobCount: Scalars['Int']['output'];
  blobSize: Scalars['SafeInt']['output'];
  createdAt: Scalars['DateTime']['output'];
  enableAi: Scalars['Boolean']['output'];
  enableDocEmbedding: Scalars['Boolean']['output'];
  enableSharing: Scalars['Boolean']['output'];
  enableUrlPreview: Scalars['Boolean']['output'];
  id: Scalars['String']['output'];
  memberCount: Scalars['Int']['output'];
  /** Members of workspace */
  members: Array<AdminWorkspaceMember>;
  name: Maybe<Scalars['String']['output']>;
  owner: Maybe<WorkspaceUserType>;
  public: Scalars['Boolean']['output'];
  publicPageCount: Scalars['Int']['output'];
  sharedLinks: Array<AdminWorkspaceSharedLink>;
  snapshotCount: Scalars['Int']['output'];
  snapshotSize: Scalars['SafeInt']['output'];
}

export interface AdminWorkspaceMembersArgs {
  query?: InputMaybe<Scalars['String']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
}

export interface AdminWorkspaceMember {
  __typename?: 'AdminWorkspaceMember';
  avatarUrl: Maybe<Scalars['String']['output']>;
  email: Scalars['String']['output'];
  id: Scalars['String']['output'];
  name: Scalars['String']['output'];
  role: AdminWorkspaceMemberRole;
  status: WorkspaceMemberStatus;
}

export enum AdminWorkspaceMemberRole {
  Admin = 'Admin',
  Collaborator = 'Collaborator',
  Owner = 'Owner',
}

export interface AdminWorkspaceSharedLink {
  __typename?: 'AdminWorkspaceSharedLink';
  docId: Scalars['String']['output'];
  publishedAt: Maybe<Scalars['DateTime']['output']>;
  title: Maybe<Scalars['String']['output']>;
}

export enum AdminWorkspaceSort {
  BlobCount = 'BlobCount',
  BlobSize = 'BlobSize',
  CreatedAt = 'CreatedAt',
  MemberCount = 'MemberCount',
  PublicPageCount = 'PublicPageCount',
  SnapshotCount = 'SnapshotCount',
  SnapshotSize = 'SnapshotSize',
}

export interface AggregateBucketHitsObjectType {
  __typename?: 'AggregateBucketHitsObjectType';
  nodes: Array<SearchNodeObjectType>;
}

export interface AggregateBucketObjectType {
  __typename?: 'AggregateBucketObjectType';
  /** Number of returned sample hits in this bucket */
  count: Scalars['Int']['output'];
  /** The hits object */
  hits: AggregateBucketHitsObjectType;
  key: Scalars['String']['output'];
}

export interface AggregateHitsOptions {
  fields: Array<Scalars['String']['input']>;
  highlights?: InputMaybe<Array<SearchHighlight>>;
  pagination?: InputMaybe<AggregateHitsPagination>;
}

export interface AggregateHitsPagination {
  limit?: InputMaybe<Scalars['Int']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
}

export interface AggregateInput {
  field: Scalars['String']['input'];
  options: AggregateOptions;
  query: SearchQuery;
  table: SearchTable;
}

export interface AggregateOptions {
  hits: AggregateHitsOptions;
  pagination?: InputMaybe<SearchPagination>;
}

export interface AggregateResultObjectType {
  __typename?: 'AggregateResultObjectType';
  buckets: Array<AggregateBucketObjectType>;
  pagination: SearchResultPagination;
}

export enum AiJobStatus {
  claimed = 'claimed',
  failed = 'failed',
  finished = 'finished',
  pending = 'pending',
  running = 'running',
}

export interface AlreadyInSpaceDataType {
  __typename?: 'AlreadyInSpaceDataType';
  spaceId: Scalars['String']['output'];
}

export interface AppConfigValidateResult {
  __typename?: 'AppConfigValidateResult';
  error: Maybe<Scalars['String']['output']>;
  key: Scalars['String']['output'];
  module: Scalars['String']['output'];
  valid: Scalars['Boolean']['output'];
  value: Scalars['JSON']['output'];
}

export interface AudioSliceManifestItemInput {
  byteSize?: InputMaybe<Scalars['Int']['input']>;
  durationSec: Scalars['Float']['input'];
  fileName: Scalars['String']['input'];
  index: Scalars['Int']['input'];
  mimeType: Scalars['String']['input'];
  startSec: Scalars['Float']['input'];
}

export interface AudioSliceManifestItemType {
  __typename?: 'AudioSliceManifestItemType';
  byteSize: Maybe<Scalars['Int']['output']>;
  durationSec: Scalars['Float']['output'];
  fileName: Scalars['String']['output'];
  index: Scalars['Int']['output'];
  mimeType: Scalars['String']['output'];
  startSec: Scalars['Float']['output'];
}

export interface AuthSigningKeyType {
  __typename?: 'AuthSigningKeyType';
  canDelete: Scalars['Boolean']['output'];
  createdAt: Maybe<Scalars['DateTime']['output']>;
  id: Scalars['String']['output'];
  retiredAt: Maybe<Scalars['DateTime']['output']>;
  source: Scalars['String']['output'];
  status: Scalars['String']['output'];
  verifyUntil: Maybe<Scalars['DateTime']['output']>;
}

export interface BlobNotFoundDataType {
  __typename?: 'BlobNotFoundDataType';
  blobId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface BlobUploadInit {
  __typename?: 'BlobUploadInit';
  alreadyUploaded: Maybe<Scalars['Boolean']['output']>;
  blobKey: Scalars['String']['output'];
  expiresAt: Maybe<Scalars['DateTime']['output']>;
  headers: Maybe<Scalars['JSONObject']['output']>;
  method: BlobUploadMethod;
  partSize: Maybe<Scalars['Int']['output']>;
  uploadId: Maybe<Scalars['String']['output']>;
  uploadUrl: Maybe<Scalars['String']['output']>;
  uploadedParts: Maybe<Array<BlobUploadedPart>>;
}

/** Blob upload method */
export enum BlobUploadMethod {
  GRAPHQL = 'GRAPHQL',
  MULTIPART = 'MULTIPART',
  PRESIGNED = 'PRESIGNED',
}

export interface BlobUploadPart {
  __typename?: 'BlobUploadPart';
  expiresAt: Maybe<Scalars['DateTime']['output']>;
  headers: Maybe<Scalars['JSONObject']['output']>;
  uploadUrl: Scalars['String']['output'];
}

export interface BlobUploadPartInput {
  etag: Scalars['String']['input'];
  partNumber: Scalars['Int']['input'];
}

export interface BlobUploadedPart {
  __typename?: 'BlobUploadedPart';
  etag: Scalars['String']['output'];
  partNumber: Scalars['Int']['output'];
}

export enum ByokAttachmentKind {
  audio = 'audio',
  file = 'file',
  image = 'image',
}

export enum ByokAttachmentSource {
  bytes = 'bytes',
  data = 'data',
  file_handle = 'file_handle',
  url = 'url',
}

export enum ByokCustomEndpointMode {
  disabled = 'disabled',
  enabled = 'enabled',
  unavailable = 'unavailable',
}

export enum ByokEndpointKind {
  openai_compatible = 'openai_compatible',
  provider_default = 'provider_default',
}

export enum ByokModelFeature {
  reasoning = 'reasoning',
  tool_calling = 'tool_calling',
  web_search = 'web_search',
}

export enum ByokModelInput {
  audio = 'audio',
  file = 'file',
  image = 'image',
  text = 'text',
}

export enum ByokModelOutput {
  embedding = 'embedding',
  image = 'image',
  object = 'object',
  rerank = 'rerank',
  structured = 'structured',
  text = 'text',
}

export enum ByokOpenAiDialect {
  chat_completions = 'chat_completions',
  responses = 'responses',
}

export enum ByokProbeOperation {
  chat = 'chat',
  embedding = 'embedding',
  image = 'image',
  rerank = 'rerank',
  structured = 'structured',
  tool_calling = 'tool_calling',
  transcript = 'transcript',
  vision = 'vision',
}

export enum ByokProbeStatusKind {
  failed = 'failed',
  not_tested = 'not_tested',
  verified = 'verified',
}

export enum ByokProvider {
  anthropic = 'anthropic',
  fal = 'fal',
  gemini = 'gemini',
  openai = 'openai',
}

export interface CalendarAccountObjectType {
  __typename?: 'CalendarAccountObjectType';
  calendars: Array<CalendarSubscriptionObjectType>;
  calendarsCount: Scalars['Int']['output'];
  createdAt: Scalars['DateTime']['output'];
  displayName: Maybe<Scalars['String']['output']>;
  email: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  lastError: Maybe<Scalars['String']['output']>;
  provider: CalendarProviderType;
  providerAccountId: Scalars['String']['output'];
  refreshIntervalMinutes: Scalars['Int']['output'];
  status: Scalars['String']['output'];
  updatedAt: Scalars['DateTime']['output'];
}

export interface CalendarCalDavProviderPresetObjectType {
  __typename?: 'CalendarCalDAVProviderPresetObjectType';
  docsUrl: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  label: Scalars['String']['output'];
  requiresAppPassword: Maybe<Scalars['Boolean']['output']>;
}

export interface CalendarEventObjectType {
  __typename?: 'CalendarEventObjectType';
  allDay: Scalars['Boolean']['output'];
  description: Maybe<Scalars['String']['output']>;
  endAtUtc: Scalars['DateTime']['output'];
  externalEventId: Scalars['String']['output'];
  id: Scalars['String']['output'];
  location: Maybe<Scalars['String']['output']>;
  originalTimezone: Maybe<Scalars['String']['output']>;
  recurrenceId: Maybe<Scalars['String']['output']>;
  startAtUtc: Scalars['DateTime']['output'];
  status: Maybe<Scalars['String']['output']>;
  subscriptionId: Scalars['String']['output'];
  title: Maybe<Scalars['String']['output']>;
}

export interface CalendarProviderRequestErrorDataType {
  __typename?: 'CalendarProviderRequestErrorDataType';
  message: Scalars['String']['output'];
  status: Scalars['Int']['output'];
}

export enum CalendarProviderType {
  CalDAV = 'CalDAV',
  Google = 'Google',
}

export interface CalendarSubscriptionObjectType {
  __typename?: 'CalendarSubscriptionObjectType';
  accountId: Scalars['String']['output'];
  color: Maybe<Scalars['String']['output']>;
  displayName: Maybe<Scalars['String']['output']>;
  enabled: Scalars['Boolean']['output'];
  externalCalendarId: Scalars['String']['output'];
  id: Scalars['String']['output'];
  lastSyncAt: Maybe<Scalars['DateTime']['output']>;
  provider: CalendarProviderType;
  timezone: Maybe<Scalars['String']['output']>;
}

export enum ChatHistoryOrder {
  asc = 'asc',
  desc = 'desc',
}

export interface ChatMessage {
  __typename?: 'ChatMessage';
  attachments: Maybe<Array<Scalars['String']['output']>>;
  content: Scalars['String']['output'];
  createdAt: Scalars['DateTime']['output'];
  id: Maybe<Scalars['ID']['output']>;
  params: Maybe<Scalars['JSON']['output']>;
  role: Scalars['String']['output'];
  scopeSnapshot: Maybe<Scalars['JSON']['output']>;
  streamObjects: Maybe<Array<StreamObject>>;
}

/** Comment change action */
export enum CommentChangeAction {
  delete = 'delete',
  update = 'update',
}

export interface CommentChangeObjectType {
  __typename?: 'CommentChangeObjectType';
  /** The action of the comment change */
  action: CommentChangeAction;
  commentId: Maybe<Scalars['ID']['output']>;
  id: Scalars['ID']['output'];
  /** The item of the comment or reply, different types have different fields, see UnionCommentObjectType */
  item: Scalars['JSONObject']['output'];
}

export interface CommentChangeObjectTypeEdge {
  __typename?: 'CommentChangeObjectTypeEdge';
  cursor: Scalars['String']['output'];
  node: CommentChangeObjectType;
}

export interface CommentCreateInput {
  content: Scalars['JSONObject']['input'];
  docId: Scalars['ID']['input'];
  docMode: DocMode;
  docTitle: Scalars['String']['input'];
  /** The mention user ids, if not provided, the comment will not be mentioned */
  mentions?: InputMaybe<Array<Scalars['String']['input']>>;
  workspaceId: Scalars['ID']['input'];
}

export interface CommentObjectType {
  __typename?: 'CommentObjectType';
  /** The content of the comment */
  content: Scalars['JSONObject']['output'];
  /** The created at time of the comment */
  createdAt: Scalars['DateTime']['output'];
  id: Scalars['ID']['output'];
  /** The replies of the comment */
  replies: Array<ReplyObjectType>;
  /** Whether the comment is resolved */
  resolved: Scalars['Boolean']['output'];
  /** The updated at time of the comment */
  updatedAt: Scalars['DateTime']['output'];
  /** The user who created the comment */
  user: PublicUserType;
}

export interface CommentObjectTypeEdge {
  __typename?: 'CommentObjectTypeEdge';
  cursor: Scalars['String']['output'];
  node: CommentObjectType;
}

export interface CommentResolveInput {
  id: Scalars['ID']['input'];
  /** Whether the comment is resolved */
  resolved: Scalars['Boolean']['input'];
}

export interface CommentUpdateInput {
  content: Scalars['JSONObject']['input'];
  id: Scalars['ID']['input'];
}

export interface Copilot {
  __typename?: 'Copilot';
  chats: PaginatedCopilotHistoriesType;
  /** @deprecated use `chats` instead */
  histories: Array<CopilotHistories>;
  /** Get the quota of the user in the workspace */
  quota: CopilotQuota;
  /** List native built-in route choices for a prompt */
  routeOptions: Maybe<CopilotRouteOptions>;
  /** Get the session by id */
  session: CopilotSessionType;
  /**
   * Get the session list in the workspace
   * @deprecated use `chats` instead
   */
  sessions: Array<CopilotSessionType>;
  /** @deprecated Use realtime subscription "copilot.transcript.task.changed" instead. */
  transcriptTask: Maybe<TranscriptionResultType>;
  workspaceId: Maybe<Scalars['ID']['output']>;
}

export interface CopilotChatsArgs {
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatHistoriesInput>;
  pagination: PaginationInput;
}

export interface CopilotHistoriesArgs {
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatHistoriesInput>;
}

export interface CopilotRouteOptionsArgs {
  promptName: Scalars['String']['input'];
}

export interface CopilotSessionArgs {
  sessionId: Scalars['String']['input'];
}

export interface CopilotSessionsArgs {
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatSessionsInput>;
}

export interface CopilotTranscriptTaskArgs {
  blobId?: InputMaybe<Scalars['String']['input']>;
  taskId?: InputMaybe<Scalars['String']['input']>;
}

export interface CopilotDocNotFoundDataType {
  __typename?: 'CopilotDocNotFoundDataType';
  docId: Scalars['String']['output'];
}

export interface CopilotFailedToAddWorkspaceArtifactDataType {
  __typename?: 'CopilotFailedToAddWorkspaceArtifactDataType';
  message: Scalars['String']['output'];
}

export interface CopilotFailedToGenerateEmbeddingDataType {
  __typename?: 'CopilotFailedToGenerateEmbeddingDataType';
  message: Scalars['String']['output'];
  provider: Scalars['String']['output'];
}

export interface CopilotHistories {
  __typename?: 'CopilotHistories';
  /** An mark identifying which view to use to display the session */
  action: Maybe<Scalars['String']['output']>;
  createdAt: Scalars['DateTime']['output'];
  docId: Maybe<Scalars['String']['output']>;
  messages: Array<ChatMessage>;
  parentSessionId: Maybe<Scalars['String']['output']>;
  pinned: Scalars['Boolean']['output'];
  promptName: Scalars['String']['output'];
  sessionId: Scalars['String']['output'];
  title: Maybe<Scalars['String']['output']>;
  updatedAt: Scalars['DateTime']['output'];
  workspaceId: Scalars['String']['output'];
}

export interface CopilotHistoriesTypeEdge {
  __typename?: 'CopilotHistoriesTypeEdge';
  cursor: Scalars['String']['output'];
  node: CopilotHistories;
}

export interface CopilotMessageNotFoundDataType {
  __typename?: 'CopilotMessageNotFoundDataType';
  messageId: Scalars['String']['output'];
}

export interface CopilotPromptNotFoundDataType {
  __typename?: 'CopilotPromptNotFoundDataType';
  name: Scalars['String']['output'];
}

export interface CopilotProviderNotSupportedDataType {
  __typename?: 'CopilotProviderNotSupportedDataType';
  kind: Scalars['String']['output'];
  provider: Scalars['String']['output'];
}

export interface CopilotProviderSideErrorDataType {
  __typename?: 'CopilotProviderSideErrorDataType';
  kind: Scalars['String']['output'];
  message: Scalars['String']['output'];
  provider: Scalars['String']['output'];
}

export interface CopilotQuota {
  __typename?: 'CopilotQuota';
  limit: Maybe<Scalars['SafeInt']['output']>;
  used: Scalars['SafeInt']['output'];
}

export interface CopilotRouteOptions {
  __typename?: 'CopilotRouteOptions';
  choices: Array<CopilotRouteTarget>;
  defaultTargetId: Maybe<Scalars['String']['output']>;
  routeId: Scalars['String']['output'];
}

export interface CopilotRouteTarget {
  __typename?: 'CopilotRouteTarget';
  available: Scalars['Boolean']['output'];
  displayName: Scalars['String']['output'];
  id: Scalars['String']['output'];
  minimumTier: Scalars['String']['output'];
}

export interface CopilotSessionType {
  __typename?: 'CopilotSessionType';
  docId: Maybe<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  parentSessionId: Maybe<Scalars['ID']['output']>;
  pinned: Scalars['Boolean']['output'];
  promptName: Scalars['String']['output'];
  title: Maybe<Scalars['String']['output']>;
}

export interface CopilotWorkspaceArtifact {
  __typename?: 'CopilotWorkspaceArtifact';
  artifactId: Scalars['String']['output'];
  contentHash: Scalars['String']['output'];
  createdAt: Scalars['DateTime']['output'];
  embeddingStatus: Scalars['String']['output'];
  fileName: Scalars['String']['output'];
  mediaType: Scalars['String']['output'];
  size: Scalars['SafeInt']['output'];
  workspaceId: Scalars['String']['output'];
}

export interface CopilotWorkspaceArtifactTypeEdge {
  __typename?: 'CopilotWorkspaceArtifactTypeEdge';
  cursor: Scalars['String']['output'];
  node: CopilotWorkspaceArtifact;
}

export interface CopilotWorkspaceConfig {
  __typename?: 'CopilotWorkspaceConfig';
  allIgnoredDocs: Array<CopilotWorkspaceIgnoredDoc>;
  artifacts: PaginatedCopilotWorkspaceArtifactType;
  ignoredDocs: PaginatedIgnoredDocsType;
  workspaceId: Scalars['String']['output'];
}

export interface CopilotWorkspaceConfigArtifactsArgs {
  pagination: PaginationInput;
}

export interface CopilotWorkspaceConfigIgnoredDocsArgs {
  pagination: PaginationInput;
}

export interface CopilotWorkspaceIgnoredDoc {
  __typename?: 'CopilotWorkspaceIgnoredDoc';
  createdAt: Scalars['DateTime']['output'];
  createdBy: Maybe<Scalars['String']['output']>;
  createdByAvatar: Maybe<Scalars['String']['output']>;
  docCreatedAt: Maybe<Scalars['DateTime']['output']>;
  docId: Scalars['String']['output'];
  docUpdatedAt: Maybe<Scalars['DateTime']['output']>;
  title: Maybe<Scalars['String']['output']>;
  updatedBy: Maybe<Scalars['String']['output']>;
}

export interface CopilotWorkspaceIgnoredDocTypeEdge {
  __typename?: 'CopilotWorkspaceIgnoredDocTypeEdge';
  cursor: Scalars['String']['output'];
  node: CopilotWorkspaceIgnoredDoc;
}

export interface CreateChatMessageInput {
  /** @deprecated use blobs */
  attachments?: InputMaybe<Array<Scalars['String']['input']>>;
  blob?: InputMaybe<Scalars['Upload']['input']>;
  blobs?: InputMaybe<Array<Scalars['Upload']['input']>>;
  content?: InputMaybe<Scalars['String']['input']>;
  params?: InputMaybe<Scalars['JSON']['input']>;
  sessionId: Scalars['String']['input'];
}

export interface CreateChatSessionInput {
  docId?: InputMaybe<Scalars['String']['input']>;
  pinned?: InputMaybe<Scalars['Boolean']['input']>;
  /** The prompt name to use for the session */
  promptName: Scalars['String']['input'];
  /** true by default, compliant for old version */
  reuseLatestChat?: InputMaybe<Scalars['Boolean']['input']>;
  workspaceId: Scalars['String']['input'];
}

export interface CreateCheckoutSessionInput {
  args?: InputMaybe<Scalars['JSONObject']['input']>;
  coupon?: InputMaybe<Scalars['String']['input']>;
  /** @deprecated not required anymore */
  idempotencyKey?: InputMaybe<Scalars['String']['input']>;
  plan?: InputMaybe<SubscriptionPlan>;
  recurring?: InputMaybe<SubscriptionRecurring>;
  successCallbackLink: Scalars['String']['input'];
  variant?: InputMaybe<SubscriptionVariant>;
}

export interface CreateMcpCredentialInput {
  accessMode?: McpAccessMode;
  expirationDays?: Scalars['Int']['input'];
  name: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface CreateUserInput {
  email: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
  password?: InputMaybe<Scalars['String']['input']>;
}

export interface CreateWorkspaceByokLocalLeaseInput {
  providers: Array<CreateWorkspaceByokLocalLeaseProviderInput>;
  workspaceId: Scalars['String']['input'];
}

export interface CreateWorkspaceByokLocalLeaseProviderInput {
  credential: Scalars['String']['input'];
  definition: WorkspaceByokProfileDefinitionInput;
  description?: InputMaybe<Scalars['String']['input']>;
  enabled: Scalars['Boolean']['input'];
  name: Scalars['String']['input'];
  provider: ByokProvider;
}

export interface CreateWorkspaceByokLocalLeaseResultType {
  __typename?: 'CreateWorkspaceByokLocalLeaseResultType';
  expiresAt: Scalars['DateTime']['output'];
  leaseId: Scalars['String']['output'];
}

export interface CreateWorkspaceByokProfileInput {
  credential: Scalars['String']['input'];
  definition: WorkspaceByokProfileDefinitionInput;
  description?: InputMaybe<Scalars['String']['input']>;
  enabled: Scalars['Boolean']['input'];
  name: Scalars['String']['input'];
  provider: ByokProvider;
  workspaceId: Scalars['String']['input'];
}

export interface CredentialsRequirementType {
  __typename?: 'CredentialsRequirementType';
  password: PasswordLimitsType;
}

export interface DeleteAccount {
  __typename?: 'DeleteAccount';
  success: Scalars['Boolean']['output'];
}

export interface DeleteSessionInput {
  docId?: InputMaybe<Scalars['String']['input']>;
  sessionIds: Array<Scalars['String']['input']>;
  workspaceId: Scalars['String']['input'];
}

export interface DocActionDeniedDataType {
  __typename?: 'DocActionDeniedDataType';
  action: Scalars['String']['output'];
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface DocHistoryNotFoundDataType {
  __typename?: 'DocHistoryNotFoundDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
  timestamp: Scalars['Int']['output'];
}

export interface DocHistoryType {
  __typename?: 'DocHistoryType';
  editor: Maybe<EditorType>;
  id: Scalars['String']['output'];
  timestamp: Scalars['DateTime']['output'];
  workspaceId: Scalars['String']['output'];
}

export interface DocMemberLastAccess {
  __typename?: 'DocMemberLastAccess';
  lastAccessedAt: Scalars['DateTime']['output'];
  lastDocId: Maybe<Scalars['String']['output']>;
  user: PublicUserType;
}

export interface DocMemberLastAccessEdge {
  __typename?: 'DocMemberLastAccessEdge';
  cursor: Scalars['String']['output'];
  node: DocMemberLastAccess;
}

/** Doc mode */
export enum DocMode {
  edgeless = 'edgeless',
  page = 'page',
}

export interface DocNotFoundDataType {
  __typename?: 'DocNotFoundDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface DocPageAnalytics {
  __typename?: 'DocPageAnalytics';
  generatedAt: Scalars['DateTime']['output'];
  series: Array<DocPageAnalyticsPoint>;
  summary: DocPageAnalyticsSummary;
  window: TimeWindow;
}

export interface DocPageAnalyticsInput {
  timezone?: InputMaybe<Scalars['String']['input']>;
  windowDays?: InputMaybe<Scalars['Int']['input']>;
}

export interface DocPageAnalyticsPoint {
  __typename?: 'DocPageAnalyticsPoint';
  date: Scalars['DateTime']['output'];
  guestViews: Scalars['SafeInt']['output'];
  totalViews: Scalars['SafeInt']['output'];
  uniqueViews: Scalars['SafeInt']['output'];
}

export interface DocPageAnalyticsSummary {
  __typename?: 'DocPageAnalyticsSummary';
  guestViews: Scalars['SafeInt']['output'];
  lastAccessedAt: Maybe<Scalars['DateTime']['output']>;
  totalViews: Scalars['SafeInt']['output'];
  uniqueViews: Scalars['SafeInt']['output'];
}

export interface DocPermissions {
  __typename?: 'DocPermissions';
  Doc_Comments_Create: Scalars['Boolean']['output'];
  Doc_Comments_Delete: Scalars['Boolean']['output'];
  Doc_Comments_Read: Scalars['Boolean']['output'];
  Doc_Comments_Resolve: Scalars['Boolean']['output'];
  Doc_Comments_Update: Scalars['Boolean']['output'];
  Doc_Copy: Scalars['Boolean']['output'];
  Doc_Delete: Scalars['Boolean']['output'];
  Doc_Duplicate: Scalars['Boolean']['output'];
  Doc_Properties_Read: Scalars['Boolean']['output'];
  Doc_Properties_Update: Scalars['Boolean']['output'];
  Doc_Publish: Scalars['Boolean']['output'];
  Doc_Read: Scalars['Boolean']['output'];
  Doc_Restore: Scalars['Boolean']['output'];
  Doc_TransferOwner: Scalars['Boolean']['output'];
  Doc_Trash: Scalars['Boolean']['output'];
  Doc_Update: Scalars['Boolean']['output'];
  Doc_Users_Manage: Scalars['Boolean']['output'];
  Doc_Users_Read: Scalars['Boolean']['output'];
}

/** User permission in doc */
export enum DocRole {
  Commenter = 'Commenter',
  Editor = 'Editor',
  External = 'External',
  Manager = 'Manager',
  None = 'None',
  Owner = 'Owner',
  Reader = 'Reader',
}

export interface DocType {
  __typename?: 'DocType';
  /** Doc page analytics in a time window */
  analytics: DocPageAnalytics;
  createdAt: Maybe<Scalars['DateTime']['output']>;
  /** Doc create user */
  createdBy: Maybe<PublicUserType>;
  creatorId: Maybe<Scalars['String']['output']>;
  defaultRole: DocRole;
  /** paginated doc granted users list */
  grantedUsersList: PaginatedGrantedDocUserType;
  id: Scalars['String']['output'];
  /** Paginated last accessed members of the current doc */
  lastAccessedMembers: PaginatedDocMemberLastAccess;
  /** Doc last updated user */
  lastUpdatedBy: Maybe<PublicUserType>;
  lastUpdaterId: Maybe<Scalars['String']['output']>;
  /** Doc metadata */
  meta: WorkspaceDocMeta;
  mode: PublicDocMode;
  permissions: DocPermissions;
  public: Scalars['Boolean']['output'];
  summary: Maybe<Scalars['String']['output']>;
  title: Maybe<Scalars['String']['output']>;
  updatedAt: Maybe<Scalars['DateTime']['output']>;
  workspaceId: Scalars['String']['output'];
}

export interface DocTypeAnalyticsArgs {
  input?: InputMaybe<DocPageAnalyticsInput>;
}

export interface DocTypeGrantedUsersListArgs {
  pagination: PaginationInput;
}

export interface DocTypeLastAccessedMembersArgs {
  includeTotal?: InputMaybe<Scalars['Boolean']['input']>;
  pagination: PaginationInput;
  query?: InputMaybe<Scalars['String']['input']>;
}

export interface DocTypeEdge {
  __typename?: 'DocTypeEdge';
  cursor: Scalars['String']['output'];
  node: DocType;
}

export interface DocUpdateBlockedDataType {
  __typename?: 'DocUpdateBlockedDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface EditorType {
  __typename?: 'EditorType';
  avatarUrl: Maybe<Scalars['String']['output']>;
  name: Scalars['String']['output'];
}

export type ErrorDataUnion =
  | AlreadyInSpaceDataType
  | BlobNotFoundDataType
  | CalendarProviderRequestErrorDataType
  | CopilotDocNotFoundDataType
  | CopilotFailedToAddWorkspaceArtifactDataType
  | CopilotFailedToGenerateEmbeddingDataType
  | CopilotMessageNotFoundDataType
  | CopilotPromptNotFoundDataType
  | CopilotProviderNotSupportedDataType
  | CopilotProviderSideErrorDataType
  | DocActionDeniedDataType
  | DocHistoryNotFoundDataType
  | DocNotFoundDataType
  | DocUpdateBlockedDataType
  | ExpectToGrantDocUserRolesDataType
  | ExpectToRevokeDocUserRolesDataType
  | ExpectToUpdateDocUserRoleDataType
  | GraphqlBadRequestDataType
  | HttpRequestErrorDataType
  | ImageFormatNotSupportedDataType
  | InvalidAppConfigDataType
  | InvalidAppConfigInputDataType
  | InvalidEmailDataType
  | InvalidHistoryTimestampDataType
  | InvalidIndexerInputDataType
  | InvalidLicenseToActivateDataType
  | InvalidLicenseUpdateParamsDataType
  | InvalidOauthCallbackCodeDataType
  | InvalidOauthResponseDataType
  | InvalidPasswordLengthDataType
  | InvalidRuntimeConfigTypeDataType
  | InvalidSearchProviderRequestDataType
  | MemberNotFoundInSpaceDataType
  | MentionUserDocAccessDeniedDataType
  | MissingOauthQueryParameterDataType
  | NoCopilotProviderAvailableDataType
  | NoMoreSeatDataType
  | NotInSpaceDataType
  | QueryTooLongDataType
  | ResponseTooLargeErrorDataType
  | RuntimeConfigNotFoundDataType
  | SameSubscriptionRecurringDataType
  | SearchIndexFailedDataType
  | SearchIndexNotReadyDataType
  | SpaceAccessDeniedDataType
  | SpaceNotFoundDataType
  | SpaceOwnerNotFoundDataType
  | SpaceShouldHaveOnlyOneOwnerDataType
  | SsrfBlockedErrorDataType
  | SubscriptionAlreadyExistsDataType
  | SubscriptionNotExistsDataType
  | SubscriptionPlanNotFoundDataType
  | UnknownOauthProviderDataType
  | UnsupportedClientVersionDataType
  | UnsupportedServerVersionDataType
  | UnsupportedSubscriptionPlanDataType
  | ValidationErrorDataType
  | VersionRejectedDataType
  | WorkspacePermissionNotFoundDataType
  | WrongSignInCredentialsDataType;

export enum ErrorNames {
  ACCESS_DENIED = 'ACCESS_DENIED',
  ACCESS_TOKEN_EXPIRED = 'ACCESS_TOKEN_EXPIRED',
  ACCESS_TOKEN_INVALID = 'ACCESS_TOKEN_INVALID',
  ACTION_FORBIDDEN = 'ACTION_FORBIDDEN',
  ACTION_FORBIDDEN_ON_NON_TEAM_WORKSPACE = 'ACTION_FORBIDDEN_ON_NON_TEAM_WORKSPACE',
  ALREADY_IN_SPACE = 'ALREADY_IN_SPACE',
  AUTHENTICATION_REQUIRED = 'AUTHENTICATION_REQUIRED',
  AUTH_SESSION_EXPIRED = 'AUTH_SESSION_EXPIRED',
  AUTH_SESSION_REVOKED = 'AUTH_SESSION_REVOKED',
  AUTH_SESSION_TEMPORARILY_UNAVAILABLE = 'AUTH_SESSION_TEMPORARILY_UNAVAILABLE',
  BAD_REQUEST = 'BAD_REQUEST',
  BLOB_INVALID = 'BLOB_INVALID',
  BLOB_NOT_FOUND = 'BLOB_NOT_FOUND',
  BLOB_QUOTA_EXCEEDED = 'BLOB_QUOTA_EXCEEDED',
  CALENDAR_PROVIDER_REQUEST_ERROR = 'CALENDAR_PROVIDER_REQUEST_ERROR',
  CANNOT_DELETE_ACCOUNT_WITH_OWNED_TEAM_WORKSPACE = 'CANNOT_DELETE_ACCOUNT_WITH_OWNED_TEAM_WORKSPACE',
  CANNOT_DELETE_ALL_ADMIN_ACCOUNT = 'CANNOT_DELETE_ALL_ADMIN_ACCOUNT',
  CANNOT_DELETE_OWN_ACCOUNT = 'CANNOT_DELETE_OWN_ACCOUNT',
  CANT_UPDATE_ONETIME_PAYMENT_SUBSCRIPTION = 'CANT_UPDATE_ONETIME_PAYMENT_SUBSCRIPTION',
  CAN_NOT_BATCH_GRANT_DOC_OWNER_PERMISSIONS = 'CAN_NOT_BATCH_GRANT_DOC_OWNER_PERMISSIONS',
  CAN_NOT_REVOKE_YOURSELF = 'CAN_NOT_REVOKE_YOURSELF',
  CAPTCHA_VERIFICATION_FAILED = 'CAPTCHA_VERIFICATION_FAILED',
  COMMENT_ATTACHMENT_NOT_FOUND = 'COMMENT_ATTACHMENT_NOT_FOUND',
  COMMENT_ATTACHMENT_QUOTA_EXCEEDED = 'COMMENT_ATTACHMENT_QUOTA_EXCEEDED',
  COMMENT_NOT_FOUND = 'COMMENT_NOT_FOUND',
  COPILOT_ACTION_TAKEN = 'COPILOT_ACTION_TAKEN',
  COPILOT_DOCS_NOT_FOUND = 'COPILOT_DOCS_NOT_FOUND',
  COPILOT_DOC_NOT_FOUND = 'COPILOT_DOC_NOT_FOUND',
  COPILOT_EMBEDDING_DISABLED = 'COPILOT_EMBEDDING_DISABLED',
  COPILOT_EMBEDDING_UNAVAILABLE = 'COPILOT_EMBEDDING_UNAVAILABLE',
  COPILOT_FAILED_TO_ADD_WORKSPACE_ARTIFACT = 'COPILOT_FAILED_TO_ADD_WORKSPACE_ARTIFACT',
  COPILOT_FAILED_TO_CREATE_MESSAGE = 'COPILOT_FAILED_TO_CREATE_MESSAGE',
  COPILOT_FAILED_TO_GENERATE_EMBEDDING = 'COPILOT_FAILED_TO_GENERATE_EMBEDDING',
  COPILOT_FAILED_TO_GENERATE_TEXT = 'COPILOT_FAILED_TO_GENERATE_TEXT',
  COPILOT_MESSAGE_NOT_FOUND = 'COPILOT_MESSAGE_NOT_FOUND',
  COPILOT_PROMPT_INVALID = 'COPILOT_PROMPT_INVALID',
  COPILOT_PROMPT_NOT_FOUND = 'COPILOT_PROMPT_NOT_FOUND',
  COPILOT_PROVIDER_NOT_SUPPORTED = 'COPILOT_PROVIDER_NOT_SUPPORTED',
  COPILOT_PROVIDER_SIDE_ERROR = 'COPILOT_PROVIDER_SIDE_ERROR',
  COPILOT_QUOTA_EXCEEDED = 'COPILOT_QUOTA_EXCEEDED',
  COPILOT_SELECTED_SOURCES_FAILED = 'COPILOT_SELECTED_SOURCES_FAILED',
  COPILOT_SELECTED_SOURCES_LIMIT_EXCEEDED = 'COPILOT_SELECTED_SOURCES_LIMIT_EXCEEDED',
  COPILOT_SELECTED_SOURCES_PROCESSING = 'COPILOT_SELECTED_SOURCES_PROCESSING',
  COPILOT_SELECTED_SOURCES_UNAVAILABLE = 'COPILOT_SELECTED_SOURCES_UNAVAILABLE',
  COPILOT_SESSION_DELETED = 'COPILOT_SESSION_DELETED',
  COPILOT_SESSION_INVALID_INPUT = 'COPILOT_SESSION_INVALID_INPUT',
  COPILOT_SESSION_NOT_FOUND = 'COPILOT_SESSION_NOT_FOUND',
  COPILOT_TRANSCRIPTION_AUDIO_NOT_PROVIDED = 'COPILOT_TRANSCRIPTION_AUDIO_NOT_PROVIDED',
  COPILOT_TRANSCRIPTION_JOB_EXISTS = 'COPILOT_TRANSCRIPTION_JOB_EXISTS',
  COPILOT_TRANSCRIPTION_JOB_NOT_FOUND = 'COPILOT_TRANSCRIPTION_JOB_NOT_FOUND',
  CUSTOMER_PORTAL_CREATE_FAILED = 'CUSTOMER_PORTAL_CREATE_FAILED',
  DOC_ACTION_DENIED = 'DOC_ACTION_DENIED',
  DOC_DEFAULT_ROLE_CAN_NOT_BE_OWNER = 'DOC_DEFAULT_ROLE_CAN_NOT_BE_OWNER',
  DOC_HISTORY_NOT_FOUND = 'DOC_HISTORY_NOT_FOUND',
  DOC_IS_NOT_PUBLIC = 'DOC_IS_NOT_PUBLIC',
  DOC_NOT_FOUND = 'DOC_NOT_FOUND',
  DOC_UPDATE_BLOCKED = 'DOC_UPDATE_BLOCKED',
  EMAIL_ALREADY_USED = 'EMAIL_ALREADY_USED',
  EMAIL_SERVICE_NOT_CONFIGURED = 'EMAIL_SERVICE_NOT_CONFIGURED',
  EMAIL_TOKEN_NOT_FOUND = 'EMAIL_TOKEN_NOT_FOUND',
  EMAIL_VERIFICATION_REQUIRED = 'EMAIL_VERIFICATION_REQUIRED',
  EXPECT_TO_GRANT_DOC_USER_ROLES = 'EXPECT_TO_GRANT_DOC_USER_ROLES',
  EXPECT_TO_PUBLISH_DOC = 'EXPECT_TO_PUBLISH_DOC',
  EXPECT_TO_REVOKE_DOC_USER_ROLES = 'EXPECT_TO_REVOKE_DOC_USER_ROLES',
  EXPECT_TO_REVOKE_PUBLIC_DOC = 'EXPECT_TO_REVOKE_PUBLIC_DOC',
  EXPECT_TO_UPDATE_DOC_USER_ROLE = 'EXPECT_TO_UPDATE_DOC_USER_ROLE',
  FAILED_TO_CHECKOUT = 'FAILED_TO_CHECKOUT',
  FAILED_TO_SAVE_UPDATES = 'FAILED_TO_SAVE_UPDATES',
  FAILED_TO_UPSERT_SNAPSHOT = 'FAILED_TO_UPSERT_SNAPSHOT',
  GRAPHQL_BAD_REQUEST = 'GRAPHQL_BAD_REQUEST',
  HTTP_REQUEST_ERROR = 'HTTP_REQUEST_ERROR',
  IMAGE_FORMAT_NOT_SUPPORTED = 'IMAGE_FORMAT_NOT_SUPPORTED',
  INTERNAL_SERVER_ERROR = 'INTERNAL_SERVER_ERROR',
  INVALID_APP_CONFIG = 'INVALID_APP_CONFIG',
  INVALID_APP_CONFIG_INPUT = 'INVALID_APP_CONFIG_INPUT',
  INVALID_AUTH_STATE = 'INVALID_AUTH_STATE',
  INVALID_CHECKOUT_PARAMETERS = 'INVALID_CHECKOUT_PARAMETERS',
  INVALID_EMAIL = 'INVALID_EMAIL',
  INVALID_EMAIL_TOKEN = 'INVALID_EMAIL_TOKEN',
  INVALID_HISTORY_TIMESTAMP = 'INVALID_HISTORY_TIMESTAMP',
  INVALID_INDEXER_INPUT = 'INVALID_INDEXER_INPUT',
  INVALID_INVITATION = 'INVALID_INVITATION',
  INVALID_LICENSE_SESSION_ID = 'INVALID_LICENSE_SESSION_ID',
  INVALID_LICENSE_TO_ACTIVATE = 'INVALID_LICENSE_TO_ACTIVATE',
  INVALID_LICENSE_UPDATE_PARAMS = 'INVALID_LICENSE_UPDATE_PARAMS',
  INVALID_OAUTH_CALLBACK_CODE = 'INVALID_OAUTH_CALLBACK_CODE',
  INVALID_OAUTH_CALLBACK_STATE = 'INVALID_OAUTH_CALLBACK_STATE',
  INVALID_OAUTH_RESPONSE = 'INVALID_OAUTH_RESPONSE',
  INVALID_PASSWORD_LENGTH = 'INVALID_PASSWORD_LENGTH',
  INVALID_RUNTIME_CONFIG_TYPE = 'INVALID_RUNTIME_CONFIG_TYPE',
  INVALID_SEARCH_PROVIDER_REQUEST = 'INVALID_SEARCH_PROVIDER_REQUEST',
  INVALID_SUBSCRIPTION_PARAMETERS = 'INVALID_SUBSCRIPTION_PARAMETERS',
  INVITATION_ACCOUNT_MISMATCH = 'INVITATION_ACCOUNT_MISMATCH',
  LICENSE_EXPIRED = 'LICENSE_EXPIRED',
  LICENSE_NOT_FOUND = 'LICENSE_NOT_FOUND',
  LICENSE_REVEALED = 'LICENSE_REVEALED',
  LINK_EXPIRED = 'LINK_EXPIRED',
  MAILER_SERVICE_IS_NOT_CONFIGURED = 'MAILER_SERVICE_IS_NOT_CONFIGURED',
  MANAGED_BY_APP_STORE_OR_PLAY = 'MANAGED_BY_APP_STORE_OR_PLAY',
  MEMBER_NOT_FOUND_IN_SPACE = 'MEMBER_NOT_FOUND_IN_SPACE',
  MEMBER_QUOTA_EXCEEDED = 'MEMBER_QUOTA_EXCEEDED',
  MENTION_USER_DOC_ACCESS_DENIED = 'MENTION_USER_DOC_ACCESS_DENIED',
  MENTION_USER_ONESELF_DENIED = 'MENTION_USER_ONESELF_DENIED',
  MISSING_OAUTH_QUERY_PARAMETER = 'MISSING_OAUTH_QUERY_PARAMETER',
  NETWORK_ERROR = 'NETWORK_ERROR',
  NEW_OWNER_IS_NOT_ACTIVE_MEMBER = 'NEW_OWNER_IS_NOT_ACTIVE_MEMBER',
  NOTIFICATION_NOT_FOUND = 'NOTIFICATION_NOT_FOUND',
  NOT_FOUND = 'NOT_FOUND',
  NOT_IN_SPACE = 'NOT_IN_SPACE',
  NO_COPILOT_PROVIDER_AVAILABLE = 'NO_COPILOT_PROVIDER_AVAILABLE',
  NO_MORE_SEAT = 'NO_MORE_SEAT',
  OAUTH_ACCOUNT_ALREADY_CONNECTED = 'OAUTH_ACCOUNT_ALREADY_CONNECTED',
  OAUTH_STATE_EXPIRED = 'OAUTH_STATE_EXPIRED',
  OWNER_CAN_NOT_LEAVE_WORKSPACE = 'OWNER_CAN_NOT_LEAVE_WORKSPACE',
  PASSWORD_REQUIRED = 'PASSWORD_REQUIRED',
  QUERY_TOO_LONG = 'QUERY_TOO_LONG',
  REFRESH_TOKEN_INVALID = 'REFRESH_TOKEN_INVALID',
  REFRESH_TOKEN_REUSED = 'REFRESH_TOKEN_REUSED',
  REPLY_NOT_FOUND = 'REPLY_NOT_FOUND',
  RESPONSE_TOO_LARGE_ERROR = 'RESPONSE_TOO_LARGE_ERROR',
  RUNTIME_CONFIG_NOT_FOUND = 'RUNTIME_CONFIG_NOT_FOUND',
  SAME_EMAIL_PROVIDED = 'SAME_EMAIL_PROVIDED',
  SAME_SUBSCRIPTION_RECURRING = 'SAME_SUBSCRIPTION_RECURRING',
  SEARCH_INDEX_FAILED = 'SEARCH_INDEX_FAILED',
  SEARCH_INDEX_NOT_READY = 'SEARCH_INDEX_NOT_READY',
  SEARCH_PERMISSION_SYNCING = 'SEARCH_PERMISSION_SYNCING',
  SEARCH_PROVIDER_NOT_FOUND = 'SEARCH_PROVIDER_NOT_FOUND',
  SEARCH_PROVIDER_UNAVAILABLE = 'SEARCH_PROVIDER_UNAVAILABLE',
  SIGN_UP_FORBIDDEN = 'SIGN_UP_FORBIDDEN',
  SPACE_ACCESS_DENIED = 'SPACE_ACCESS_DENIED',
  SPACE_NOT_FOUND = 'SPACE_NOT_FOUND',
  SPACE_OWNER_NOT_FOUND = 'SPACE_OWNER_NOT_FOUND',
  SPACE_SHOULD_HAVE_ONLY_ONE_OWNER = 'SPACE_SHOULD_HAVE_ONLY_ONE_OWNER',
  SSRF_BLOCKED_ERROR = 'SSRF_BLOCKED_ERROR',
  STORAGE_QUOTA_EXCEEDED = 'STORAGE_QUOTA_EXCEEDED',
  SUBSCRIPTION_ALREADY_EXISTS = 'SUBSCRIPTION_ALREADY_EXISTS',
  SUBSCRIPTION_EXPIRED = 'SUBSCRIPTION_EXPIRED',
  SUBSCRIPTION_HAS_BEEN_CANCELED = 'SUBSCRIPTION_HAS_BEEN_CANCELED',
  SUBSCRIPTION_HAS_NOT_BEEN_CANCELED = 'SUBSCRIPTION_HAS_NOT_BEEN_CANCELED',
  SUBSCRIPTION_NOT_EXISTS = 'SUBSCRIPTION_NOT_EXISTS',
  SUBSCRIPTION_PLAN_NOT_FOUND = 'SUBSCRIPTION_PLAN_NOT_FOUND',
  TOO_MANY_REQUEST = 'TOO_MANY_REQUEST',
  UNKNOWN_OAUTH_PROVIDER = 'UNKNOWN_OAUTH_PROVIDER',
  UNSPLASH_IS_NOT_CONFIGURED = 'UNSPLASH_IS_NOT_CONFIGURED',
  UNSUPPORTED_CLIENT_VERSION = 'UNSUPPORTED_CLIENT_VERSION',
  UNSUPPORTED_SERVER_VERSION = 'UNSUPPORTED_SERVER_VERSION',
  UNSUPPORTED_SUBSCRIPTION_PLAN = 'UNSUPPORTED_SUBSCRIPTION_PLAN',
  USER_AVATAR_NOT_FOUND = 'USER_AVATAR_NOT_FOUND',
  USER_NOT_FOUND = 'USER_NOT_FOUND',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  VERSION_REJECTED = 'VERSION_REJECTED',
  WORKSPACE_ID_REQUIRED_FOR_TEAM_SUBSCRIPTION = 'WORKSPACE_ID_REQUIRED_FOR_TEAM_SUBSCRIPTION',
  WORKSPACE_ID_REQUIRED_TO_UPDATE_TEAM_SUBSCRIPTION = 'WORKSPACE_ID_REQUIRED_TO_UPDATE_TEAM_SUBSCRIPTION',
  WORKSPACE_LICENSE_ALREADY_EXISTS = 'WORKSPACE_LICENSE_ALREADY_EXISTS',
  WORKSPACE_PERMISSION_NOT_FOUND = 'WORKSPACE_PERMISSION_NOT_FOUND',
  WRONG_SIGN_IN_CREDENTIALS = 'WRONG_SIGN_IN_CREDENTIALS',
  WRONG_SIGN_IN_METHOD = 'WRONG_SIGN_IN_METHOD',
}

export interface ExpectToGrantDocUserRolesDataType {
  __typename?: 'ExpectToGrantDocUserRolesDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface ExpectToRevokeDocUserRolesDataType {
  __typename?: 'ExpectToRevokeDocUserRolesDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export interface ExpectToUpdateDocUserRoleDataType {
  __typename?: 'ExpectToUpdateDocUserRoleDataType';
  docId: Scalars['String']['output'];
  spaceId: Scalars['String']['output'];
}

export enum FeatureType {
  Admin = 'Admin',
}

export interface ForkChatSessionInput {
  docId: Scalars['String']['input'];
  /** Identify a message in the array and keep it with all previous messages into a forked session. */
  latestMessageId?: InputMaybe<Scalars['String']['input']>;
  sessionId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface GrantDocUserRolesInput {
  docId: Scalars['String']['input'];
  role: DocRole;
  userIds: Array<Scalars['String']['input']>;
  workspaceId: Scalars['String']['input'];
}

export interface GrantedDocUserType {
  __typename?: 'GrantedDocUserType';
  role: DocRole;
  user: WorkspaceUserType;
}

export interface GrantedDocUserTypeEdge {
  __typename?: 'GrantedDocUserTypeEdge';
  cursor: Scalars['String']['output'];
  node: GrantedDocUserType;
}

export interface GraphqlBadRequestDataType {
  __typename?: 'GraphqlBadRequestDataType';
  code: Scalars['String']['output'];
  message: Scalars['String']['output'];
}

export interface HttpRequestErrorDataType {
  __typename?: 'HttpRequestErrorDataType';
  message: Scalars['String']['output'];
}

export interface ImageFormatNotSupportedDataType {
  __typename?: 'ImageFormatNotSupportedDataType';
  format: Scalars['String']['output'];
}

export interface ImportUsersInput {
  users: Array<CreateUserInput>;
}

export interface InvalidAppConfigDataType {
  __typename?: 'InvalidAppConfigDataType';
  hint: Scalars['String']['output'];
  key: Scalars['String']['output'];
  module: Scalars['String']['output'];
}

export interface InvalidAppConfigInputDataType {
  __typename?: 'InvalidAppConfigInputDataType';
  message: Scalars['String']['output'];
}

export interface InvalidEmailDataType {
  __typename?: 'InvalidEmailDataType';
  email: Scalars['String']['output'];
}

export interface InvalidHistoryTimestampDataType {
  __typename?: 'InvalidHistoryTimestampDataType';
  timestamp: Scalars['String']['output'];
}

export interface InvalidIndexerInputDataType {
  __typename?: 'InvalidIndexerInputDataType';
  reason: Scalars['String']['output'];
}

export interface InvalidLicenseToActivateDataType {
  __typename?: 'InvalidLicenseToActivateDataType';
  reason: Scalars['String']['output'];
}

export interface InvalidLicenseUpdateParamsDataType {
  __typename?: 'InvalidLicenseUpdateParamsDataType';
  reason: Scalars['String']['output'];
}

export interface InvalidOauthCallbackCodeDataType {
  __typename?: 'InvalidOauthCallbackCodeDataType';
  body: Scalars['String']['output'];
  status: Scalars['Int']['output'];
}

export interface InvalidOauthResponseDataType {
  __typename?: 'InvalidOauthResponseDataType';
  reason: Scalars['String']['output'];
}

export interface InvalidPasswordLengthDataType {
  __typename?: 'InvalidPasswordLengthDataType';
  max: Scalars['Int']['output'];
  min: Scalars['Int']['output'];
}

export interface InvalidRuntimeConfigTypeDataType {
  __typename?: 'InvalidRuntimeConfigTypeDataType';
  get: Scalars['String']['output'];
  key: Scalars['String']['output'];
  want: Scalars['String']['output'];
}

export interface InvalidSearchProviderRequestDataType {
  __typename?: 'InvalidSearchProviderRequestDataType';
  reason: Scalars['String']['output'];
  type: Scalars['String']['output'];
}

export interface InvitationAcceptedNotificationBodyType {
  __typename?: 'InvitationAcceptedNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  inviteId: Scalars['ID']['output'];
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationBlockedNotificationBodyType {
  __typename?: 'InvitationBlockedNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  inviteId: Scalars['ID']['output'];
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationNotificationBodyType {
  __typename?: 'InvitationNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  inviteId: Scalars['ID']['output'];
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationReviewApprovedNotificationBodyType {
  __typename?: 'InvitationReviewApprovedNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  inviteId: Scalars['ID']['output'];
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationReviewDeclinedNotificationBodyType {
  __typename?: 'InvitationReviewDeclinedNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationReviewRequestNotificationBodyType {
  __typename?: 'InvitationReviewRequestNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  inviteId: Scalars['ID']['output'];
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface InvitationType {
  __typename?: 'InvitationType';
  /** Invitee information */
  invitee: WorkspaceUserType;
  /** Invitation status in workspace */
  status: Maybe<WorkspaceMemberStatus>;
  /** User information */
  user: WorkspaceUserType;
  /** Workspace information */
  workspace: InvitationWorkspaceType;
}

export interface InvitationWorkspaceType {
  __typename?: 'InvitationWorkspaceType';
  /** Base64 encoded avatar */
  avatar: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** Workspace name */
  name: Scalars['String']['output'];
}

export interface InviteLink {
  __typename?: 'InviteLink';
  /** Invite link expire time */
  expireTime: Scalars['DateTime']['output'];
  /** Invite link */
  link: Scalars['String']['output'];
}

export interface InviteResult {
  __typename?: 'InviteResult';
  email: Scalars['String']['output'];
  /** Invite error */
  error: Maybe<Scalars['JSONObject']['output']>;
  /** Invite id, null if invite record create failed */
  inviteId: Maybe<Scalars['String']['output']>;
}

export interface InviteUserType {
  __typename?: 'InviteUserType';
  /** User avatar url */
  avatarUrl: Maybe<Scalars['String']['output']>;
  /**
   * User email verified
   * @deprecated useless
   */
  createdAt: Maybe<Scalars['DateTime']['output']>;
  /** User is disabled */
  disabled: Maybe<Scalars['Boolean']['output']>;
  /** User email */
  email: Maybe<Scalars['String']['output']>;
  /** User email verified */
  emailVerified: Maybe<Scalars['Boolean']['output']>;
  /** User password has been set */
  hasPassword: Maybe<Scalars['Boolean']['output']>;
  id: Scalars['ID']['output'];
  /** Invite id */
  inviteId: Scalars['String']['output'];
  /** User name */
  name: Maybe<Scalars['String']['output']>;
  /**
   * User permission in workspace
   * @deprecated Use role instead
   */
  permission: Permission;
  /** User role in workspace */
  role: Permission;
  /** Member invite status in workspace */
  status: WorkspaceMemberStatus;
}

export enum InvoiceStatus {
  Draft = 'Draft',
  Open = 'Open',
  Paid = 'Paid',
  Uncollectible = 'Uncollectible',
  Void = 'Void',
}

export interface InvoiceType {
  __typename?: 'InvoiceType';
  amount: Scalars['Int']['output'];
  createdAt: Scalars['DateTime']['output'];
  currency: Scalars['String']['output'];
  lastPaymentError: Maybe<Scalars['String']['output']>;
  link: Maybe<Scalars['String']['output']>;
  /** @deprecated removed */
  plan: Maybe<SubscriptionPlan>;
  reason: Scalars['String']['output'];
  /** @deprecated removed */
  recurring: Maybe<SubscriptionRecurring>;
  status: InvoiceStatus;
  updatedAt: Scalars['DateTime']['output'];
}

export interface License {
  __typename?: 'License';
  expiredAt: Maybe<Scalars['DateTime']['output']>;
  installedAt: Scalars['DateTime']['output'];
  quantity: Scalars['Int']['output'];
  recurring: SubscriptionRecurring;
  validatedAt: Scalars['DateTime']['output'];
  variant: Maybe<SubscriptionVariant>;
}

export interface LimitedUserType {
  __typename?: 'LimitedUserType';
  /** User email */
  email: Scalars['String']['output'];
  /** User password has been set */
  hasPassword: Maybe<Scalars['Boolean']['output']>;
}

export interface LinkCalDavAccountInput {
  displayName?: InputMaybe<Scalars['String']['input']>;
  password: Scalars['String']['input'];
  providerPresetId: Scalars['String']['input'];
  username: Scalars['String']['input'];
}

export interface LinkCalendarAccountInput {
  provider: CalendarProviderType;
  redirectUri?: InputMaybe<Scalars['String']['input']>;
}

export interface ListUserInput {
  features?: InputMaybe<Array<FeatureType>>;
  first?: InputMaybe<Scalars['Int']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
}

export interface ListWorkspaceInput {
  enableAi?: InputMaybe<Scalars['Boolean']['input']>;
  enableDocEmbedding?: InputMaybe<Scalars['Boolean']['input']>;
  enableSharing?: InputMaybe<Scalars['Boolean']['input']>;
  enableUrlPreview?: InputMaybe<Scalars['Boolean']['input']>;
  first?: Scalars['Int']['input'];
  keyword?: InputMaybe<Scalars['String']['input']>;
  orderBy?: InputMaybe<AdminWorkspaceSort>;
  public?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: Scalars['Int']['input'];
}

export interface ListedBlob {
  __typename?: 'ListedBlob';
  createdAt: Scalars['String']['output'];
  key: Scalars['String']['output'];
  mime: Scalars['String']['output'];
  size: Scalars['Int']['output'];
}

export interface ManageUserInput {
  /** User email */
  email?: InputMaybe<Scalars['String']['input']>;
  /** User name */
  name?: InputMaybe<Scalars['String']['input']>;
}

export enum McpAccessMode {
  READ_ONLY = 'READ_ONLY',
  READ_WRITE = 'READ_WRITE',
}

export enum McpCredentialStatus {
  ACTIVE = 'ACTIVE',
  EXPIRED = 'EXPIRED',
  EXPIRING = 'EXPIRING',
  REVOKED = 'REVOKED',
  ROTATING = 'ROTATING',
}

export interface McpCredentialType {
  __typename?: 'McpCredentialType';
  accessMode: McpAccessMode;
  createdAt: Scalars['DateTime']['output'];
  expiresAt: Scalars['DateTime']['output'];
  fingerprint: Scalars['String']['output'];
  graceEndsAt: Maybe<Scalars['DateTime']['output']>;
  id: Scalars['ID']['output'];
  lastUsedAt: Maybe<Scalars['DateTime']['output']>;
  name: Scalars['String']['output'];
  revokedAt: Maybe<Scalars['DateTime']['output']>;
  status: McpCredentialStatus;
  workspaceId: Scalars['String']['output'];
}

export interface MeetingActionItemType {
  __typename?: 'MeetingActionItemType';
  deadline: Maybe<Scalars['String']['output']>;
  description: Scalars['String']['output'];
  owner: Maybe<Scalars['String']['output']>;
}

export interface MeetingSummaryV2Type {
  __typename?: 'MeetingSummaryV2Type';
  actionItems: Array<MeetingActionItemType>;
  attendees: Array<Scalars['String']['output']>;
  blockers: Array<Scalars['String']['output']>;
  decisions: Array<Scalars['String']['output']>;
  durationMinutes: Scalars['Float']['output'];
  keyPoints: Array<Scalars['String']['output']>;
  openQuestions: Array<Scalars['String']['output']>;
  title: Scalars['String']['output'];
}

export interface MemberNotFoundInSpaceDataType {
  __typename?: 'MemberNotFoundInSpaceDataType';
  spaceId: Scalars['String']['output'];
}

export interface MentionDocInput {
  /** The block id in the doc */
  blockId?: InputMaybe<Scalars['String']['input']>;
  /** The element id in the doc */
  elementId?: InputMaybe<Scalars['String']['input']>;
  id: Scalars['String']['input'];
  mode: DocMode;
  title: Scalars['String']['input'];
}

export interface MentionDocType {
  __typename?: 'MentionDocType';
  blockId: Maybe<Scalars['String']['output']>;
  elementId: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  mode: DocMode;
  title: Scalars['String']['output'];
}

export interface MentionInput {
  doc: MentionDocInput;
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MentionNotificationBodyType {
  __typename?: 'MentionNotificationBodyType';
  /** The user who created the notification, maybe null when user is deleted or sent by system */
  createdByUser: Maybe<PublicUserType>;
  doc: MentionDocType;
  /** The type of the notification */
  type: NotificationType;
  workspace: Maybe<NotificationWorkspaceType>;
}

export interface MentionUserDocAccessDeniedDataType {
  __typename?: 'MentionUserDocAccessDeniedDataType';
  docId: Scalars['String']['output'];
}

export interface MissingOauthQueryParameterDataType {
  __typename?: 'MissingOauthQueryParameterDataType';
  name: Scalars['String']['output'];
}

export interface Mutation {
  __typename?: 'Mutation';
  abortBlobUpload: Scalars['Boolean']['output'];
  acceptInviteById: Scalars['Boolean']['output'];
  activateLicense: License;
  /** Add a workspace artifact */
  addWorkspaceArtifact: CopilotWorkspaceArtifact;
  /** Update workspace flags for admin */
  adminUpdateWorkspace: Maybe<AdminWorkspace>;
  approveMember: Scalars['Boolean']['output'];
  /** Ban an user */
  banUser: UserType;
  cancelSubscription: SubscriptionType;
  changeEmail: UserType;
  changePassword: Scalars['Boolean']['output'];
  /** Cleanup sessions */
  cleanupCopilotSession: Array<Scalars['String']['output']>;
  completeBlobUpload: Scalars['String']['output'];
  createBlobUpload: BlobUploadInit;
  /** Create change password url */
  createChangePasswordUrl: Scalars['String']['output'];
  /** Create a subscription checkout link of stripe */
  createCheckoutSession: Scalars['String']['output'];
  createComment: CommentObjectType;
  /** Create a chat message */
  createCopilotMessage: Scalars['String']['output'];
  /**
   * Create a chat session
   * @deprecated use `createCopilotSessionWithHistory` instead
   */
  createCopilotSession: Scalars['String']['output'];
  /** Create a chat session and return full session payload */
  createCopilotSessionWithHistory: CopilotHistories;
  /** Create a stripe customer portal to manage payment methods */
  createCustomerPortal: Scalars['String']['output'];
  createInviteLink: InviteLink;
  createMcpCredential: RevealedMcpCredentialType;
  createReply: ReplyObjectType;
  createSelfhostWorkspaceCustomerPortal: Scalars['String']['output'];
  /** Create a new user */
  createUser: UserType;
  /** Create a new workspace */
  createWorkspace: WorkspaceType;
  createWorkspaceByokLocalLease: CreateWorkspaceByokLocalLeaseResultType;
  createWorkspaceByokProfile: WorkspaceByokProfileType;
  deactivateLicense: Scalars['Boolean']['output'];
  deleteAccount: DeleteAccount;
  deleteAuthSigningKey: Array<AuthSigningKeyType>;
  deleteBlob: Scalars['Boolean']['output'];
  /** Delete a comment */
  deleteComment: Scalars['Boolean']['output'];
  /** Delete a reply */
  deleteReply: Scalars['Boolean']['output'];
  /** Delete a user account */
  deleteUser: DeleteAccount;
  deleteWorkspace: Scalars['Boolean']['output'];
  deleteWorkspaceByokProfile: Scalars['Boolean']['output'];
  /** Reenable an banned user */
  enableUser: UserType;
  /** Create a chat session */
  forkCopilotSession: Scalars['String']['output'];
  generateLicenseKey: Scalars['String']['output'];
  grantCommercialEntitlement: Scalars['Boolean']['output'];
  grantDocUserRoles: Scalars['Boolean']['output'];
  grantMember: Scalars['Boolean']['output'];
  /** import users */
  importUsers: Array<UserImportResultType>;
  installLicense: License;
  inviteMembers: Array<InviteResult>;
  leaveWorkspace: Scalars['Boolean']['output'];
  linkCalDAVAccount: CalendarAccountObjectType;
  linkCalendarAccount: Scalars['String']['output'];
  /** mention user in a doc */
  mentionUser: Scalars['ID']['output'];
  previewLicense: AdminLicensePreview;
  probeWorkspaceByokDraft: WorkspaceByokProbeResultType;
  probeWorkspaceByokProfile: WorkspaceByokProbeResultType;
  publishDoc: DocType;
  /** mark all notifications as read */
  readAllNotifications: Scalars['Boolean']['output'];
  /** mark notification as read */
  readNotification: Scalars['Boolean']['output'];
  recoverDoc: Scalars['DateTime']['output'];
  /** Refresh current user subscriptions and return latest. */
  refreshUserSubscriptions: Array<SubscriptionType>;
  releaseDeletedBlobs: Scalars['Boolean']['output'];
  /** Remove user avatar */
  removeAvatar: RemoveAvatar;
  /** Remove a workspace artifact */
  removeWorkspaceArtifact: Scalars['Boolean']['output'];
  reorderWorkspaceByokProfiles: Array<WorkspaceByokProfileType>;
  replaceWorkspaceByokProfile: WorkspaceByokProfileType;
  /** Request to apply the subscription in advance */
  requestApplySubscription: Array<SubscriptionType>;
  /** Resolve a comment or not */
  resolveComment: Scalars['Boolean']['output'];
  resumeSubscription: SubscriptionType;
  retryTranscriptTask: Maybe<TranscriptionResultType>;
  revokeCommercialEntitlement: Scalars['Boolean']['output'];
  revokeDocUserRoles: Scalars['Boolean']['output'];
  revokeInviteLink: Scalars['Boolean']['output'];
  revokeMcpCredential: Scalars['Boolean']['output'];
  revokeMember: Scalars['Boolean']['output'];
  revokePublicDoc: DocType;
  rotateAuthSigningKey: Array<AuthSigningKeyType>;
  rotateMcpCredential: RevealedMcpCredentialType;
  rotateWorkspaceByokCredential: WorkspaceByokProfileType;
  sendChangeEmail: Scalars['Boolean']['output'];
  sendChangePasswordEmail: Scalars['Boolean']['output'];
  sendSetPasswordEmail: Scalars['Boolean']['output'];
  sendTestEmail: Scalars['Boolean']['output'];
  sendVerifyChangeEmail: Scalars['Boolean']['output'];
  sendVerifyEmail: Scalars['Boolean']['output'];
  setBlob: Scalars['String']['output'];
  settleTranscriptTask: Maybe<TranscriptionResultType>;
  submitTranscriptTask: Maybe<TranscriptionResultType>;
  unlinkCalendarAccount: Scalars['Boolean']['output'];
  /** update app configuration */
  updateAppConfig: Scalars['JSONObject']['output'];
  updateCalendarAccount: Maybe<CalendarAccountObjectType>;
  /** Update a comment content */
  updateComment: Scalars['Boolean']['output'];
  /** Update a chat session */
  updateCopilotSession: Scalars['String']['output'];
  updateDocDefaultRole: Scalars['Boolean']['output'];
  updateDocUserRole: Scalars['Boolean']['output'];
  updateProfile: UserType;
  /** Update a reply content */
  updateReply: Scalars['Boolean']['output'];
  /** Update user settings */
  updateSettings: Scalars['Boolean']['output'];
  updateSubscriptionRecurring: SubscriptionType;
  /** Update an user */
  updateUser: UserType;
  /** update user enabled feature */
  updateUserFeatures: Array<FeatureType>;
  /** Update workspace */
  updateWorkspace: WorkspaceType;
  updateWorkspaceCalendars: WorkspaceCalendarObjectType;
  /** Update ignored docs */
  updateWorkspaceEmbeddingIgnoredDocs: Scalars['Int']['output'];
  /** Upload user avatar */
  uploadAvatar: UserType;
  /** Upload a comment attachment and return the access url */
  uploadCommentAttachment: Scalars['String']['output'];
  verifyEmail: Scalars['Boolean']['output'];
}

export interface MutationAbortBlobUploadArgs {
  key: Scalars['String']['input'];
  uploadId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationAcceptInviteByIdArgs {
  inviteId: Scalars['String']['input'];
  sendAcceptMail?: InputMaybe<Scalars['Boolean']['input']>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationActivateLicenseArgs {
  license: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationAddWorkspaceArtifactArgs {
  blob: Scalars['Upload']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationAdminUpdateWorkspaceArgs {
  input: AdminUpdateWorkspaceInput;
}

export interface MutationApproveMemberArgs {
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationBanUserArgs {
  id: Scalars['String']['input'];
}

export interface MutationCancelSubscriptionArgs {
  idempotencyKey?: InputMaybe<Scalars['String']['input']>;
  plan?: InputMaybe<SubscriptionPlan>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationChangeEmailArgs {
  email: Scalars['String']['input'];
  token: Scalars['String']['input'];
}

export interface MutationChangePasswordArgs {
  newPassword: Scalars['String']['input'];
  token: Scalars['String']['input'];
  userId?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationCleanupCopilotSessionArgs {
  options: DeleteSessionInput;
}

export interface MutationCompleteBlobUploadArgs {
  key: Scalars['String']['input'];
  parts?: InputMaybe<Array<BlobUploadPartInput>>;
  uploadId?: InputMaybe<Scalars['String']['input']>;
  workspaceId: Scalars['String']['input'];
}

export interface MutationCreateBlobUploadArgs {
  key: Scalars['String']['input'];
  mime: Scalars['String']['input'];
  size: Scalars['Int']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationCreateChangePasswordUrlArgs {
  callbackUrl: Scalars['String']['input'];
  userId: Scalars['String']['input'];
}

export interface MutationCreateCheckoutSessionArgs {
  input: CreateCheckoutSessionInput;
}

export interface MutationCreateCommentArgs {
  input: CommentCreateInput;
}

export interface MutationCreateCopilotMessageArgs {
  options: CreateChatMessageInput;
}

export interface MutationCreateCopilotSessionArgs {
  options: CreateChatSessionInput;
}

export interface MutationCreateCopilotSessionWithHistoryArgs {
  options: CreateChatSessionInput;
}

export interface MutationCreateInviteLinkArgs {
  expireTime: WorkspaceInviteLinkExpireTime;
  workspaceId: Scalars['String']['input'];
}

export interface MutationCreateMcpCredentialArgs {
  input: CreateMcpCredentialInput;
}

export interface MutationCreateReplyArgs {
  input: ReplyCreateInput;
}

export interface MutationCreateSelfhostWorkspaceCustomerPortalArgs {
  workspaceId: Scalars['String']['input'];
}

export interface MutationCreateUserArgs {
  input: CreateUserInput;
}

export interface MutationCreateWorkspaceArgs {
  init?: InputMaybe<Scalars['Upload']['input']>;
}

export interface MutationCreateWorkspaceByokLocalLeaseArgs {
  input: CreateWorkspaceByokLocalLeaseInput;
}

export interface MutationCreateWorkspaceByokProfileArgs {
  input: CreateWorkspaceByokProfileInput;
}

export interface MutationDeactivateLicenseArgs {
  workspaceId: Scalars['String']['input'];
}

export interface MutationDeleteAuthSigningKeyArgs {
  id: Scalars['String']['input'];
}

export interface MutationDeleteBlobArgs {
  hash?: InputMaybe<Scalars['String']['input']>;
  key?: InputMaybe<Scalars['String']['input']>;
  permanently?: Scalars['Boolean']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationDeleteCommentArgs {
  id: Scalars['String']['input'];
}

export interface MutationDeleteReplyArgs {
  id: Scalars['String']['input'];
}

export interface MutationDeleteUserArgs {
  id: Scalars['String']['input'];
}

export interface MutationDeleteWorkspaceArgs {
  id: Scalars['String']['input'];
}

export interface MutationDeleteWorkspaceByokProfileArgs {
  profileId: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationEnableUserArgs {
  id: Scalars['String']['input'];
}

export interface MutationForkCopilotSessionArgs {
  options: ForkChatSessionInput;
}

export interface MutationGenerateLicenseKeyArgs {
  sessionId: Scalars['String']['input'];
}

export interface MutationGrantCommercialEntitlementArgs {
  plan: Scalars['String']['input'];
  quantity?: InputMaybe<Scalars['Int']['input']>;
  targetId: Scalars['String']['input'];
  targetType: Scalars['String']['input'];
}

export interface MutationGrantDocUserRolesArgs {
  input: GrantDocUserRolesInput;
}

export interface MutationGrantMemberArgs {
  permission: Permission;
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationImportUsersArgs {
  input: ImportUsersInput;
}

export interface MutationInstallLicenseArgs {
  license: Scalars['Upload']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationInviteMembersArgs {
  emails: Array<Scalars['String']['input']>;
  workspaceId: Scalars['String']['input'];
}

export interface MutationLeaveWorkspaceArgs {
  sendLeaveMail?: InputMaybe<Scalars['Boolean']['input']>;
  workspaceId: Scalars['String']['input'];
  workspaceName?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationLinkCalDavAccountArgs {
  input: LinkCalDavAccountInput;
}

export interface MutationLinkCalendarAccountArgs {
  input: LinkCalendarAccountInput;
}

export interface MutationMentionUserArgs {
  input: MentionInput;
}

export interface MutationPreviewLicenseArgs {
  license: Scalars['Upload']['input'];
}

export interface MutationProbeWorkspaceByokDraftArgs {
  input: ProbeWorkspaceByokDraftInput;
}

export interface MutationProbeWorkspaceByokProfileArgs {
  input: ProbeWorkspaceByokProfileInput;
}

export interface MutationPublishDocArgs {
  docId: Scalars['String']['input'];
  mode?: InputMaybe<PublicDocMode>;
  workspaceId: Scalars['String']['input'];
}

export interface MutationReadNotificationArgs {
  id: Scalars['String']['input'];
}

export interface MutationRecoverDocArgs {
  guid: Scalars['String']['input'];
  timestamp: Scalars['DateTime']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationReleaseDeletedBlobsArgs {
  workspaceId: Scalars['String']['input'];
}

export interface MutationRemoveWorkspaceArtifactArgs {
  artifactId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationReorderWorkspaceByokProfilesArgs {
  input: ReorderWorkspaceByokProfilesInput;
}

export interface MutationReplaceWorkspaceByokProfileArgs {
  input: ReplaceWorkspaceByokProfileInput;
}

export interface MutationRequestApplySubscriptionArgs {
  transactionId: Scalars['String']['input'];
}

export interface MutationResolveCommentArgs {
  input: CommentResolveInput;
}

export interface MutationResumeSubscriptionArgs {
  idempotencyKey?: InputMaybe<Scalars['String']['input']>;
  plan?: InputMaybe<SubscriptionPlan>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationRetryTranscriptTaskArgs {
  taskId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationRevokeCommercialEntitlementArgs {
  targetId: Scalars['String']['input'];
  targetType: Scalars['String']['input'];
}

export interface MutationRevokeDocUserRolesArgs {
  input: RevokeDocUserRoleInput;
}

export interface MutationRevokeInviteLinkArgs {
  workspaceId: Scalars['String']['input'];
}

export interface MutationRevokeMcpCredentialArgs {
  id: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationRevokeMemberArgs {
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationRevokePublicDocArgs {
  docId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationRotateAuthSigningKeyArgs {
  expectedActiveKeyId: Scalars['String']['input'];
}

export interface MutationRotateMcpCredentialArgs {
  expirationDays?: Scalars['Int']['input'];
  id: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationRotateWorkspaceByokCredentialArgs {
  input: RotateWorkspaceByokCredentialInput;
}

export interface MutationSendChangeEmailArgs {
  callbackUrl: Scalars['String']['input'];
}

export interface MutationSendChangePasswordEmailArgs {
  callbackUrl: Scalars['String']['input'];
  email?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationSendSetPasswordEmailArgs {
  callbackUrl: Scalars['String']['input'];
  email?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationSendTestEmailArgs {
  config: Scalars['JSONObject']['input'];
}

export interface MutationSendVerifyChangeEmailArgs {
  callbackUrl: Scalars['String']['input'];
  email: Scalars['String']['input'];
  token: Scalars['String']['input'];
}

export interface MutationSendVerifyEmailArgs {
  callbackUrl: Scalars['String']['input'];
}

export interface MutationSetBlobArgs {
  blob: Scalars['Upload']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationSettleTranscriptTaskArgs {
  taskId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationSubmitTranscriptTaskArgs {
  blob?: InputMaybe<Scalars['Upload']['input']>;
  blobId: Scalars['String']['input'];
  blobs?: InputMaybe<Array<Scalars['Upload']['input']>>;
  input?: InputMaybe<SubmitAudioTranscriptionInput>;
  workspaceId: Scalars['String']['input'];
}

export interface MutationUnlinkCalendarAccountArgs {
  accountId: Scalars['String']['input'];
}

export interface MutationUpdateAppConfigArgs {
  updates: Array<UpdateAppConfigInput>;
}

export interface MutationUpdateCalendarAccountArgs {
  accountId: Scalars['String']['input'];
  refreshIntervalMinutes: Scalars['Int']['input'];
}

export interface MutationUpdateCommentArgs {
  input: CommentUpdateInput;
}

export interface MutationUpdateCopilotSessionArgs {
  options: UpdateChatSessionInput;
}

export interface MutationUpdateDocDefaultRoleArgs {
  input: UpdateDocDefaultRoleInput;
}

export interface MutationUpdateDocUserRoleArgs {
  input: UpdateDocUserRoleInput;
}

export interface MutationUpdateProfileArgs {
  input: UpdateUserInput;
}

export interface MutationUpdateReplyArgs {
  input: ReplyUpdateInput;
}

export interface MutationUpdateSettingsArgs {
  input: UpdateUserSettingsInput;
}

export interface MutationUpdateSubscriptionRecurringArgs {
  idempotencyKey?: InputMaybe<Scalars['String']['input']>;
  plan?: InputMaybe<SubscriptionPlan>;
  recurring: SubscriptionRecurring;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface MutationUpdateUserArgs {
  id: Scalars['String']['input'];
  input: ManageUserInput;
}

export interface MutationUpdateUserFeaturesArgs {
  features: Array<FeatureType>;
  id: Scalars['String']['input'];
}

export interface MutationUpdateWorkspaceArgs {
  input: UpdateWorkspaceInput;
}

export interface MutationUpdateWorkspaceCalendarsArgs {
  input: UpdateWorkspaceCalendarsInput;
}

export interface MutationUpdateWorkspaceEmbeddingIgnoredDocsArgs {
  add?: InputMaybe<Array<Scalars['String']['input']>>;
  remove?: InputMaybe<Array<Scalars['String']['input']>>;
  workspaceId: Scalars['String']['input'];
}

export interface MutationUploadAvatarArgs {
  avatar: Scalars['Upload']['input'];
}

export interface MutationUploadCommentAttachmentArgs {
  attachment: Scalars['Upload']['input'];
  docId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface MutationVerifyEmailArgs {
  token: Scalars['String']['input'];
}

export interface NoCopilotProviderAvailableDataType {
  __typename?: 'NoCopilotProviderAvailableDataType';
  modelId: Scalars['String']['output'];
}

export interface NoMoreSeatDataType {
  __typename?: 'NoMoreSeatDataType';
  spaceId: Scalars['String']['output'];
}

export interface NormalizedTranscriptSegmentType {
  __typename?: 'NormalizedTranscriptSegmentType';
  end: Scalars['String']['output'];
  endSec: Scalars['Float']['output'];
  speaker: Scalars['String']['output'];
  start: Scalars['String']['output'];
  startSec: Scalars['Float']['output'];
  text: Scalars['String']['output'];
}

export interface NotInSpaceDataType {
  __typename?: 'NotInSpaceDataType';
  spaceId: Scalars['String']['output'];
}

/** Notification level */
export enum NotificationLevel {
  Default = 'Default',
  High = 'High',
  Low = 'Low',
  Min = 'Min',
  None = 'None',
}

export interface NotificationObjectType {
  __typename?: 'NotificationObjectType';
  /** Just a placeholder to export UnionNotificationBodyType, don't use it */
  _placeholderForUnionNotificationBodyType: UnionNotificationBodyType;
  /** The body of the notification, different types have different fields, see UnionNotificationBodyType */
  body: Scalars['JSONObject']['output'];
  /** The created at time of the notification */
  createdAt: Scalars['DateTime']['output'];
  id: Scalars['ID']['output'];
  /** The level of the notification */
  level: NotificationLevel;
  /** Whether the notification has been read */
  read: Scalars['Boolean']['output'];
  /** The type of the notification */
  type: NotificationType;
  /** The updated at time of the notification */
  updatedAt: Scalars['DateTime']['output'];
}

export interface NotificationObjectTypeEdge {
  __typename?: 'NotificationObjectTypeEdge';
  cursor: Scalars['String']['output'];
  node: NotificationObjectType;
}

/** Notification type */
export enum NotificationType {
  Comment = 'Comment',
  CommentMention = 'CommentMention',
  Invitation = 'Invitation',
  InvitationAccepted = 'InvitationAccepted',
  InvitationBlocked = 'InvitationBlocked',
  InvitationRejected = 'InvitationRejected',
  InvitationReviewApproved = 'InvitationReviewApproved',
  InvitationReviewDeclined = 'InvitationReviewDeclined',
  InvitationReviewRequest = 'InvitationReviewRequest',
  Mention = 'Mention',
}

export interface NotificationWorkspaceType {
  __typename?: 'NotificationWorkspaceType';
  /** Workspace avatar url */
  avatarUrl: Maybe<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  /** Workspace name */
  name: Scalars['String']['output'];
}

export enum OAuthProviderType {
  Apple = 'Apple',
  GitHub = 'GitHub',
  Google = 'Google',
  OIDC = 'OIDC',
}

export interface PageInfo {
  __typename?: 'PageInfo';
  endCursor: Maybe<Scalars['String']['output']>;
  hasNextPage: Scalars['Boolean']['output'];
  hasPreviousPage: Scalars['Boolean']['output'];
  startCursor: Maybe<Scalars['String']['output']>;
}

export interface PaginatedAdminAllSharedLink {
  __typename?: 'PaginatedAdminAllSharedLink';
  analyticsWindow: TimeWindow;
  edges: Array<AdminAllSharedLinkEdge>;
  pageInfo: PageInfo;
  totalCount: Maybe<Scalars['Int']['output']>;
}

export interface PaginatedCommentChangeObjectType {
  __typename?: 'PaginatedCommentChangeObjectType';
  edges: Array<CommentChangeObjectTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedCommentObjectType {
  __typename?: 'PaginatedCommentObjectType';
  edges: Array<CommentObjectTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedCopilotHistoriesType {
  __typename?: 'PaginatedCopilotHistoriesType';
  edges: Array<CopilotHistoriesTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedCopilotWorkspaceArtifactType {
  __typename?: 'PaginatedCopilotWorkspaceArtifactType';
  edges: Array<CopilotWorkspaceArtifactTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedDocMemberLastAccess {
  __typename?: 'PaginatedDocMemberLastAccess';
  edges: Array<DocMemberLastAccessEdge>;
  pageInfo: PageInfo;
  totalCount: Maybe<Scalars['Int']['output']>;
}

export interface PaginatedDocType {
  __typename?: 'PaginatedDocType';
  edges: Array<DocTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedGrantedDocUserType {
  __typename?: 'PaginatedGrantedDocUserType';
  edges: Array<GrantedDocUserTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedIgnoredDocsType {
  __typename?: 'PaginatedIgnoredDocsType';
  edges: Array<CopilotWorkspaceIgnoredDocTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginatedNotificationObjectType {
  __typename?: 'PaginatedNotificationObjectType';
  edges: Array<NotificationObjectTypeEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
}

export interface PaginationInput {
  /** returns the elements in the list that come after the specified cursor. */
  after?: InputMaybe<Scalars['String']['input']>;
  /** returns the first n elements from the list. */
  first?: InputMaybe<Scalars['Int']['input']>;
  /** ignore the first n elements from the list. */
  offset?: InputMaybe<Scalars['Int']['input']>;
}

export interface PasswordLimitsType {
  __typename?: 'PasswordLimitsType';
  maxLength: Scalars['Int']['output'];
  minLength: Scalars['Int']['output'];
}

/** User permission in workspace */
export enum Permission {
  Admin = 'Admin',
  Collaborator = 'Collaborator',
  External = 'External',
  Owner = 'Owner',
}

export interface ProbeWorkspaceByokDraftInput {
  checks: Array<WorkspaceByokProbeCheckInput>;
  credential?: InputMaybe<Scalars['String']['input']>;
  definition: WorkspaceByokProfileDefinitionInput;
  expectedRevision?: InputMaybe<Scalars['SafeInt']['input']>;
  profileId?: InputMaybe<Scalars['ID']['input']>;
  provider: ByokProvider;
  workspaceId: Scalars['String']['input'];
}

export interface ProbeWorkspaceByokProfileInput {
  checks: Array<WorkspaceByokProbeCheckInput>;
  profileId: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

/** The mode which the public doc default in */
export enum PublicDocMode {
  Edgeless = 'Edgeless',
  Page = 'Page',
}

export interface PublicUserType {
  __typename?: 'PublicUserType';
  avatarUrl: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  name: Scalars['String']['output'];
}

export interface Query {
  __typename?: 'Query';
  /** List all shared links across workspaces for admin panel */
  adminAllSharedLinks: PaginatedAdminAllSharedLink;
  /** Get aggregated dashboard metrics for admin panel */
  adminDashboard: AdminDashboard;
  /** Aggregate mail delivery timeline facts for admin panel */
  adminMailDeliveries: AdminMailDeliveryAnalytics;
  /** Get workspace detail for admin */
  adminWorkspace: Maybe<AdminWorkspace>;
  /** List workspaces for admin */
  adminWorkspaces: Array<AdminWorkspace>;
  /** Workspaces count for admin */
  adminWorkspacesCount: Scalars['Int']['output'];
  /** get the whole app configuration */
  appConfig: Scalars['JSONObject']['output'];
  authSigningKeys: Array<AuthSigningKeyType>;
  /** Get current user */
  currentUser: Maybe<UserType>;
  error: ErrorDataUnion;
  /** get workspace invitation info */
  getInviteInfo: InvitationType;
  mcpCredentialReadWriteAvailable: Scalars['Boolean']['output'];
  mcpCredentials: Array<McpCredentialType>;
  prices: Array<SubscriptionPrice>;
  /** Get public user by id */
  publicUserById: Maybe<PublicUserType>;
  /** server config */
  serverConfig: ServerConfigType;
  /** Get user by email */
  user: Maybe<UserOrLimitedUser>;
  /** Get user by email for admin */
  userByEmail: Maybe<UserType>;
  /** Get user by id */
  userById: UserType;
  /** List registered users */
  users: Array<UserType>;
  /** Get users count */
  usersCount: Scalars['Int']['output'];
  /** validate app configuration */
  validateAppConfig: Array<AppConfigValidateResult>;
  /** Get workspace by id */
  workspace: WorkspaceType;
  /**
   * Get workspace role permissions
   * @deprecated use WorkspaceType[permissions] instead
   */
  workspaceRolePermissions: WorkspaceRolePermissions;
  /** Get all accessible workspaces for current user */
  workspaces: Array<WorkspaceType>;
}

export interface QueryAdminAllSharedLinksArgs {
  filter?: InputMaybe<AdminAllSharedLinksFilterInput>;
  pagination: PaginationInput;
}

export interface QueryAdminDashboardArgs {
  input?: InputMaybe<AdminDashboardInput>;
}

export interface QueryAdminMailDeliveriesArgs {
  input?: InputMaybe<AdminMailDeliveriesInput>;
}

export interface QueryAdminWorkspaceArgs {
  id: Scalars['String']['input'];
}

export interface QueryAdminWorkspacesArgs {
  filter: ListWorkspaceInput;
}

export interface QueryAdminWorkspacesCountArgs {
  filter: ListWorkspaceInput;
}

export interface QueryErrorArgs {
  name: ErrorNames;
}

export interface QueryGetInviteInfoArgs {
  inviteId: Scalars['String']['input'];
}

export interface QueryMcpCredentialsArgs {
  workspaceId: Scalars['String']['input'];
}

export interface QueryPublicUserByIdArgs {
  id: Scalars['String']['input'];
}

export interface QueryUserArgs {
  email: Scalars['String']['input'];
}

export interface QueryUserByEmailArgs {
  email: Scalars['String']['input'];
}

export interface QueryUserByIdArgs {
  id: Scalars['String']['input'];
}

export interface QueryUsersArgs {
  filter: ListUserInput;
}

export interface QueryUsersCountArgs {
  filter?: InputMaybe<ListUserInput>;
}

export interface QueryValidateAppConfigArgs {
  updates: Array<UpdateAppConfigInput>;
}

export interface QueryWorkspaceArgs {
  id: Scalars['String']['input'];
}

export interface QueryWorkspaceRolePermissionsArgs {
  id: Scalars['String']['input'];
}

export interface QueryChatHistoriesInput {
  action?: InputMaybe<Scalars['Boolean']['input']>;
  fork?: InputMaybe<Scalars['Boolean']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  messageOrder?: InputMaybe<ChatHistoryOrder>;
  pinned?: InputMaybe<Scalars['Boolean']['input']>;
  sessionId?: InputMaybe<Scalars['String']['input']>;
  sessionOrder?: InputMaybe<ChatHistoryOrder>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  withMessages?: InputMaybe<Scalars['Boolean']['input']>;
  withPrompt?: InputMaybe<Scalars['Boolean']['input']>;
}

export interface QueryChatSessionsInput {
  action?: InputMaybe<Scalars['Boolean']['input']>;
  fork?: InputMaybe<Scalars['Boolean']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  pinned?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
}

export interface QueryTooLongDataType {
  __typename?: 'QueryTooLongDataType';
  max: Scalars['Int']['output'];
}

export interface ReleaseVersionType {
  __typename?: 'ReleaseVersionType';
  changelog: Scalars['String']['output'];
  publishedAt: Scalars['DateTime']['output'];
  url: Scalars['String']['output'];
  version: Scalars['String']['output'];
}

export interface RemoveAvatar {
  __typename?: 'RemoveAvatar';
  success: Scalars['Boolean']['output'];
}

export interface ReorderWorkspaceByokProfilesInput {
  profiles: Array<WorkspaceByokProfileOrderInput>;
  workspaceId: Scalars['String']['input'];
}

export interface ReplaceWorkspaceByokProfileInput {
  credential?: InputMaybe<Scalars['String']['input']>;
  definition: WorkspaceByokProfileDefinitionInput;
  description?: InputMaybe<Scalars['String']['input']>;
  enabled: Scalars['Boolean']['input'];
  expectedRevision: Scalars['SafeInt']['input'];
  name: Scalars['String']['input'];
  profileId: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface ReplyCreateInput {
  commentId: Scalars['ID']['input'];
  content: Scalars['JSONObject']['input'];
  docMode: DocMode;
  docTitle: Scalars['String']['input'];
  /** The mention user ids, if not provided, the comment reply will not be mentioned */
  mentions?: InputMaybe<Array<Scalars['String']['input']>>;
}

export interface ReplyObjectType {
  __typename?: 'ReplyObjectType';
  commentId: Scalars['ID']['output'];
  /** The content of the reply */
  content: Scalars['JSONObject']['output'];
  /** The created at time of the reply */
  createdAt: Scalars['DateTime']['output'];
  id: Scalars['ID']['output'];
  /** The updated at time of the reply */
  updatedAt: Scalars['DateTime']['output'];
  /** The user who created the reply */
  user: PublicUserType;
}

export interface ReplyUpdateInput {
  content: Scalars['JSONObject']['input'];
  id: Scalars['ID']['input'];
}

export interface ResponseTooLargeErrorDataType {
  __typename?: 'ResponseTooLargeErrorDataType';
  limitBytes: Scalars['Int']['output'];
  receivedBytes: Scalars['Int']['output'];
}

export interface RevealedMcpCredentialType {
  __typename?: 'RevealedMcpCredentialType';
  credential: McpCredentialType;
  token: Scalars['String']['output'];
}

export interface RevokeDocUserRoleInput {
  docId: Scalars['String']['input'];
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface RotateWorkspaceByokCredentialInput {
  credential: Scalars['String']['input'];
  expectedRevision: Scalars['SafeInt']['input'];
  profileId: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface RuntimeConfigNotFoundDataType {
  __typename?: 'RuntimeConfigNotFoundDataType';
  key: Scalars['String']['output'];
}

export interface SameSubscriptionRecurringDataType {
  __typename?: 'SameSubscriptionRecurringDataType';
  recurring: Scalars['String']['output'];
}

export interface SearchDocObjectType {
  __typename?: 'SearchDocObjectType';
  blockId: Scalars['String']['output'];
  createdAt: Scalars['DateTime']['output'];
  createdByUser: Maybe<PublicUserType>;
  docId: Scalars['String']['output'];
  highlight: Scalars['String']['output'];
  title: Scalars['String']['output'];
  updatedAt: Scalars['DateTime']['output'];
  updatedByUser: Maybe<PublicUserType>;
}

export interface SearchDocsInput {
  keyword: Scalars['String']['input'];
  /** Limit the number of docs to return, default is 20 */
  limit?: InputMaybe<Scalars['Int']['input']>;
}

export interface SearchHighlight {
  before: Scalars['String']['input'];
  end: Scalars['String']['input'];
  field: Scalars['String']['input'];
}

export interface SearchIndexFailedDataType {
  __typename?: 'SearchIndexFailedDataType';
  diagnosticId: Scalars['String']['output'];
}

export interface SearchIndexNotReadyDataType {
  __typename?: 'SearchIndexNotReadyDataType';
  spaceId: Scalars['String']['output'];
}

export interface SearchInput {
  options: SearchOptions;
  query: SearchQuery;
  table: SearchTable;
}

export interface SearchNodeObjectType {
  __typename?: 'SearchNodeObjectType';
  /** The search result fields, see UnionSearchItemObjectType */
  fields: Scalars['JSONObject']['output'];
  /** The search result fields, see UnionSearchItemObjectType */
  highlights: Maybe<Scalars['JSONObject']['output']>;
}

export interface SearchOptions {
  fields: Array<Scalars['String']['input']>;
  highlights?: InputMaybe<Array<SearchHighlight>>;
  pagination?: InputMaybe<SearchPagination>;
}

export interface SearchPagination {
  cursor?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
}

export interface SearchQuery {
  boost?: InputMaybe<Scalars['Float']['input']>;
  field?: InputMaybe<Scalars['String']['input']>;
  match?: InputMaybe<Scalars['String']['input']>;
  occur?: InputMaybe<SearchQueryOccur>;
  queries?: InputMaybe<Array<SearchQuery>>;
  query?: InputMaybe<SearchQuery>;
  type: SearchQueryType;
}

/** Search query occur */
export enum SearchQueryOccur {
  must = 'must',
  must_not = 'must_not',
  should = 'should',
}

/** Search query type */
export enum SearchQueryType {
  all = 'all',
  boolean = 'boolean',
  boost = 'boost',
  exists = 'exists',
  match = 'match',
}

export interface SearchResultObjectType {
  __typename?: 'SearchResultObjectType';
  nodes: Array<SearchNodeObjectType>;
  pagination: SearchResultPagination;
}

export interface SearchResultPagination {
  __typename?: 'SearchResultPagination';
  /** Number of results returned in this response, not a global total */
  count: Scalars['Int']['output'];
  /** Whether the provider has more candidates; remaining visible results are not guaranteed */
  hasMore: Scalars['Boolean']['output'];
  /** Opaque provider candidate cursor; it does not guarantee complete visible-result pagination */
  nextCursor: Maybe<Scalars['String']['output']>;
}

/** Search table */
export enum SearchTable {
  block = 'block',
  doc = 'doc',
}

export interface ServerConfigType {
  __typename?: 'ServerConfigType';
  /** fetch latest available upgradable release of server */
  availableUpgrade: Maybe<ReleaseVersionType>;
  /** Features for user that can be configured */
  availableUserFeatures: Array<FeatureType>;
  /** server base url */
  baseUrl: Scalars['String']['output'];
  calendarCalDAVProviders: Array<CalendarCalDavProviderPresetObjectType>;
  calendarProviders: Array<CalendarProviderType>;
  /** credentials requirement */
  credentialsRequirement: CredentialsRequirementType;
  /** enabled server features */
  features: Array<ServerFeature>;
  /** whether server has been initialized */
  initialized: Scalars['Boolean']['output'];
  /** server identical name could be shown as badge on user interface */
  name: Scalars['String']['output'];
  oauthProviders: Array<OAuthProviderType>;
  /** server type */
  type: ServerDeploymentType;
  /** server version */
  version: Scalars['String']['output'];
}

export enum ServerDeploymentType {
  Affine = 'Affine',
  Selfhosted = 'Selfhosted',
}

export enum ServerFeature {
  Captcha = 'Captcha',
  Comment = 'Comment',
  Copilot = 'Copilot',
  CopilotEmbedding = 'CopilotEmbedding',
  Indexer = 'Indexer',
  LocalWorkspace = 'LocalWorkspace',
  OAuth = 'OAuth',
  Payment = 'Payment',
}

export interface SpaceAccessDeniedDataType {
  __typename?: 'SpaceAccessDeniedDataType';
  spaceId: Scalars['String']['output'];
}

export interface SpaceNotFoundDataType {
  __typename?: 'SpaceNotFoundDataType';
  spaceId: Scalars['String']['output'];
}

export interface SpaceOwnerNotFoundDataType {
  __typename?: 'SpaceOwnerNotFoundDataType';
  spaceId: Scalars['String']['output'];
}

export interface SpaceShouldHaveOnlyOneOwnerDataType {
  __typename?: 'SpaceShouldHaveOnlyOneOwnerDataType';
  spaceId: Scalars['String']['output'];
}

export interface SsrfBlockedErrorDataType {
  __typename?: 'SsrfBlockedErrorDataType';
  reason: Scalars['String']['output'];
}

export interface StreamObject {
  __typename?: 'StreamObject';
  args: Maybe<Scalars['JSON']['output']>;
  result: Maybe<Scalars['JSON']['output']>;
  textDelta: Maybe<Scalars['String']['output']>;
  toolCallId: Maybe<Scalars['String']['output']>;
  toolName: Maybe<Scalars['String']['output']>;
  type: Scalars['String']['output'];
}

export interface SubmitAudioTranscriptionInput {
  quality?: InputMaybe<TranscriptionQualityInput>;
  sliceManifest?: InputMaybe<Array<AudioSliceManifestItemInput>>;
  sourceAudio?: InputMaybe<TranscriptionSourceAudioInput>;
}

export interface SubscriptionAlreadyExistsDataType {
  __typename?: 'SubscriptionAlreadyExistsDataType';
  plan: Scalars['String']['output'];
}

export interface SubscriptionNotExistsDataType {
  __typename?: 'SubscriptionNotExistsDataType';
  plan: Scalars['String']['output'];
}

export enum SubscriptionPlan {
  AI = 'AI',
  Enterprise = 'Enterprise',
  Free = 'Free',
  Pro = 'Pro',
  SelfHosted = 'SelfHosted',
  SelfHostedTeam = 'SelfHostedTeam',
  Team = 'Team',
}

export interface SubscriptionPlanNotFoundDataType {
  __typename?: 'SubscriptionPlanNotFoundDataType';
  plan: Scalars['String']['output'];
  recurring: Scalars['String']['output'];
}

export interface SubscriptionPrice {
  __typename?: 'SubscriptionPrice';
  amount: Maybe<Scalars['Int']['output']>;
  currency: Scalars['String']['output'];
  lifetimeAmount: Maybe<Scalars['Int']['output']>;
  plan: SubscriptionPlan;
  type: Scalars['String']['output'];
  yearlyAmount: Maybe<Scalars['Int']['output']>;
}

export enum SubscriptionRecurring {
  Lifetime = 'Lifetime',
  Monthly = 'Monthly',
  Yearly = 'Yearly',
}

export enum SubscriptionStatus {
  Active = 'Active',
  Canceled = 'Canceled',
  Incomplete = 'Incomplete',
  IncompleteExpired = 'IncompleteExpired',
  PastDue = 'PastDue',
  Paused = 'Paused',
  Trialing = 'Trialing',
  Unpaid = 'Unpaid',
}

export interface SubscriptionType {
  __typename?: 'SubscriptionType';
  canceledAt: Maybe<Scalars['DateTime']['output']>;
  createdAt: Scalars['DateTime']['output'];
  end: Maybe<Scalars['DateTime']['output']>;
  /** If provider is revenuecat, indicates underlying store. Read-only. One of: app_store | play_store */
  iapStore: Maybe<Scalars['String']['output']>;
  /** @deprecated removed */
  id: Maybe<Scalars['String']['output']>;
  nextBillAt: Maybe<Scalars['DateTime']['output']>;
  /**
   * The 'Free' plan just exists to be a placeholder and for the type convenience of frontend.
   * There won't actually be a subscription with plan 'Free'
   */
  plan: SubscriptionPlan;
  /** Payment provider of this subscription. Read-only. One of: stripe | revenuecat */
  provider: Maybe<Scalars['String']['output']>;
  recurring: SubscriptionRecurring;
  start: Scalars['DateTime']['output'];
  status: SubscriptionStatus;
  trialEnd: Maybe<Scalars['DateTime']['output']>;
  trialStart: Maybe<Scalars['DateTime']['output']>;
  updatedAt: Scalars['DateTime']['output'];
  variant: Maybe<SubscriptionVariant>;
}

export enum SubscriptionVariant {
  Onetime = 'Onetime',
}

export enum TimeBucket {
  Day = 'Day',
  Hour = 'Hour',
  Minute = 'Minute',
}

export interface TimeWindow {
  __typename?: 'TimeWindow';
  bucket: TimeBucket;
  effectiveSize: Scalars['Int']['output'];
  from: Scalars['DateTime']['output'];
  requestedSize: Scalars['Int']['output'];
  timezone: Scalars['String']['output'];
  to: Scalars['DateTime']['output'];
}

export interface TranscriptionItemType {
  __typename?: 'TranscriptionItemType';
  end: Scalars['String']['output'];
  speaker: Scalars['String']['output'];
  start: Scalars['String']['output'];
  transcription: Scalars['String']['output'];
}

export interface TranscriptionQualityInput {
  degraded?: InputMaybe<Scalars['Boolean']['input']>;
  overflowCount?: InputMaybe<Scalars['Int']['input']>;
}

export interface TranscriptionQualityType {
  __typename?: 'TranscriptionQualityType';
  degraded: Maybe<Scalars['Boolean']['output']>;
  overflowCount: Maybe<Scalars['Int']['output']>;
}

export interface TranscriptionResultType {
  __typename?: 'TranscriptionResultType';
  actions: Maybe<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  normalizedSegments: Maybe<Array<NormalizedTranscriptSegmentType>>;
  normalizedTranscript: Maybe<Scalars['String']['output']>;
  quality: Maybe<TranscriptionQualityType>;
  sliceManifest: Maybe<Array<AudioSliceManifestItemType>>;
  sourceAudio: Maybe<TranscriptionSourceAudioType>;
  status: AiJobStatus;
  summary: Maybe<Scalars['String']['output']>;
  summaryJson: Maybe<MeetingSummaryV2Type>;
  title: Maybe<Scalars['String']['output']>;
  transcription: Maybe<Array<TranscriptionItemType>>;
  version: Maybe<Scalars['String']['output']>;
}

export interface TranscriptionSourceAudioInput {
  channels?: InputMaybe<Scalars['Int']['input']>;
  durationMs?: InputMaybe<Scalars['Int']['input']>;
  mimeType?: InputMaybe<Scalars['String']['input']>;
  sampleRate?: InputMaybe<Scalars['Int']['input']>;
}

export interface TranscriptionSourceAudioType {
  __typename?: 'TranscriptionSourceAudioType';
  blobId: Maybe<Scalars['String']['output']>;
  channels: Maybe<Scalars['Int']['output']>;
  durationMs: Maybe<Scalars['Int']['output']>;
  mimeType: Maybe<Scalars['String']['output']>;
  sampleRate: Maybe<Scalars['Int']['output']>;
}

export type UnionNotificationBodyType =
  | InvitationAcceptedNotificationBodyType
  | InvitationBlockedNotificationBodyType
  | InvitationNotificationBodyType
  | InvitationReviewApprovedNotificationBodyType
  | InvitationReviewDeclinedNotificationBodyType
  | InvitationReviewRequestNotificationBodyType
  | MentionNotificationBodyType;

export interface UnknownOauthProviderDataType {
  __typename?: 'UnknownOauthProviderDataType';
  name: Scalars['String']['output'];
}

export interface UnsupportedClientVersionDataType {
  __typename?: 'UnsupportedClientVersionDataType';
  clientVersion: Scalars['String']['output'];
  requiredVersion: Scalars['String']['output'];
}

export interface UnsupportedServerVersionDataType {
  __typename?: 'UnsupportedServerVersionDataType';
  requiredVersion: Scalars['String']['output'];
}

export interface UnsupportedSubscriptionPlanDataType {
  __typename?: 'UnsupportedSubscriptionPlanDataType';
  plan: Scalars['String']['output'];
}

export interface UpdateAppConfigInput {
  key: Scalars['String']['input'];
  module: Scalars['String']['input'];
  value: Scalars['JSON']['input'];
}

export interface UpdateChatSessionInput {
  /** The workspace id of the session */
  docId?: InputMaybe<Scalars['String']['input']>;
  /** Whether to pin the session */
  pinned?: InputMaybe<Scalars['Boolean']['input']>;
  /** The prompt name to use for the session */
  promptName?: InputMaybe<Scalars['String']['input']>;
  sessionId: Scalars['String']['input'];
}

export interface UpdateDocDefaultRoleInput {
  docId: Scalars['String']['input'];
  role: DocRole;
  workspaceId: Scalars['String']['input'];
}

export interface UpdateDocUserRoleInput {
  docId: Scalars['String']['input'];
  role: DocRole;
  userId: Scalars['String']['input'];
  workspaceId: Scalars['String']['input'];
}

export interface UpdateUserInput {
  /** User name */
  name?: InputMaybe<Scalars['String']['input']>;
}

export interface UpdateUserSettingsInput {
  /** Receive comment email */
  receiveCommentEmail?: InputMaybe<Scalars['Boolean']['input']>;
  /** Receive invitation email */
  receiveInvitationEmail?: InputMaybe<Scalars['Boolean']['input']>;
  /** Receive mention email */
  receiveMentionEmail?: InputMaybe<Scalars['Boolean']['input']>;
}

export interface UpdateWorkspaceCalendarsInput {
  items: Array<WorkspaceCalendarItemInput>;
  workspaceId: Scalars['String']['input'];
}

export interface UpdateWorkspaceInput {
  /** Enable AI */
  enableAi?: InputMaybe<Scalars['Boolean']['input']>;
  /** Enable doc embedding */
  enableDocEmbedding?: InputMaybe<Scalars['Boolean']['input']>;
  /** Enable workspace sharing */
  enableSharing?: InputMaybe<Scalars['Boolean']['input']>;
  /** Enable url previous when sharing */
  enableUrlPreview?: InputMaybe<Scalars['Boolean']['input']>;
  id: Scalars['ID']['input'];
  /** is Public workspace */
  public?: InputMaybe<Scalars['Boolean']['input']>;
}

export interface UserImportFailedType {
  __typename?: 'UserImportFailedType';
  email: Scalars['String']['output'];
  error: Scalars['String']['output'];
}

export type UserImportResultType = UserImportFailedType | UserType;

export type UserOrLimitedUser = LimitedUserType | UserType;

export interface UserQuotaHumanReadableType {
  __typename?: 'UserQuotaHumanReadableType';
  blobLimit: Scalars['String']['output'];
  copilotActionLimit: Scalars['String']['output'];
  historyPeriod: Scalars['String']['output'];
  memberLimit: Scalars['String']['output'];
  name: Scalars['String']['output'];
  storageQuota: Scalars['String']['output'];
  usedStorageQuota: Scalars['String']['output'];
}

export interface UserQuotaType {
  __typename?: 'UserQuotaType';
  blobLimit: Scalars['SafeInt']['output'];
  copilotActionLimit: Maybe<Scalars['Int']['output']>;
  historyPeriod: Scalars['SafeInt']['output'];
  humanReadable: UserQuotaHumanReadableType;
  memberLimit: Scalars['Int']['output'];
  name: Scalars['String']['output'];
  storageQuota: Scalars['SafeInt']['output'];
  usedStorageQuota: Scalars['SafeInt']['output'];
}

export interface UserQuotaUsageType {
  __typename?: 'UserQuotaUsageType';
  /** @deprecated use `UserQuotaType['usedStorageQuota']` instead */
  storageQuota: Scalars['SafeInt']['output'];
}

export interface UserSettingsType {
  __typename?: 'UserSettingsType';
  /** Receive comment email */
  receiveCommentEmail: Scalars['Boolean']['output'];
  /** Receive invitation email */
  receiveInvitationEmail: Scalars['Boolean']['output'];
  /** Receive mention email */
  receiveMentionEmail: Scalars['Boolean']['output'];
}

export interface UserType {
  __typename?: 'UserType';
  /** User avatar url */
  avatarUrl: Maybe<Scalars['String']['output']>;
  calendarAccounts: Array<CalendarAccountObjectType>;
  copilot: Copilot;
  /**
   * User email verified
   * @deprecated useless
   */
  createdAt: Maybe<Scalars['DateTime']['output']>;
  /** User is disabled */
  disabled: Scalars['Boolean']['output'];
  /** User email */
  email: Scalars['String']['output'];
  /** User email verified */
  emailVerified: Scalars['Boolean']['output'];
  /** Enabled features of a user */
  features: Array<FeatureType>;
  /** User password has been set */
  hasPassword: Maybe<Scalars['Boolean']['output']>;
  id: Scalars['ID']['output'];
  /** Get user invoice count */
  invoiceCount: Scalars['Int']['output'];
  invoices: Array<InvoiceType>;
  /** User name */
  name: Scalars['String']['output'];
  /** Get current user notifications */
  notifications: PaginatedNotificationObjectType;
  quota: UserQuotaType;
  quotaUsage: UserQuotaUsageType;
  /** Get user settings */
  settings: UserSettingsType;
  subscriptions: Array<SubscriptionType>;
  /** @deprecated use auth session exchange instead */
  token: TokenType;
}

export interface UserTypeCopilotArgs {
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}

export interface UserTypeInvoicesArgs {
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
}

export interface UserTypeNotificationsArgs {
  pagination: PaginationInput;
}

export interface ValidationErrorDataType {
  __typename?: 'ValidationErrorDataType';
  errors: Scalars['String']['output'];
}

export interface VersionRejectedDataType {
  __typename?: 'VersionRejectedDataType';
  serverVersion: Scalars['String']['output'];
  version: Scalars['String']['output'];
}

export interface WorkspaceByokCapabilityInput {
  attachmentKinds: Array<ByokAttachmentKind>;
  attachmentSources: Array<ByokAttachmentSource>;
  features: Array<ByokModelFeature>;
  input: Array<ByokModelInput>;
  output: Array<ByokModelOutput>;
}

export interface WorkspaceByokCapabilityType {
  __typename?: 'WorkspaceByokCapabilityType';
  attachmentKinds: Array<ByokAttachmentKind>;
  attachmentSources: Array<ByokAttachmentSource>;
  features: Array<ByokModelFeature>;
  input: Array<ByokModelInput>;
  output: Array<ByokModelOutput>;
}

export interface WorkspaceByokCatalogModelType {
  __typename?: 'WorkspaceByokCatalogModelType';
  capabilities: Array<WorkspaceByokCapabilityType>;
  displayName: Scalars['String']['output'];
  modelId: Scalars['String']['output'];
  recommended: Scalars['Boolean']['output'];
}

export interface WorkspaceByokCatalogProviderType {
  __typename?: 'WorkspaceByokCatalogProviderType';
  models: Array<WorkspaceByokCatalogModelType>;
  provider: ByokProvider;
}

export interface WorkspaceByokCatalogType {
  __typename?: 'WorkspaceByokCatalogType';
  providers: Array<WorkspaceByokCatalogProviderType>;
  version: Scalars['String']['output'];
}

export interface WorkspaceByokEndpointInput {
  dialect?: InputMaybe<ByokOpenAiDialect>;
  kind: ByokEndpointKind;
  url?: InputMaybe<Scalars['String']['input']>;
}

export interface WorkspaceByokEndpointType {
  __typename?: 'WorkspaceByokEndpointType';
  dialect: Maybe<ByokOpenAiDialect>;
  kind: ByokEndpointKind;
  url: Maybe<Scalars['String']['output']>;
}

export interface WorkspaceByokModelDeclarationInput {
  capabilities: Array<WorkspaceByokCapabilityInput>;
  enabled: Scalars['Boolean']['input'];
  modelId: Scalars['String']['input'];
}

export interface WorkspaceByokModelDeclarationType {
  __typename?: 'WorkspaceByokModelDeclarationType';
  capabilities: Array<WorkspaceByokCapabilityType>;
  enabled: Scalars['Boolean']['output'];
  modelId: Scalars['String']['output'];
}

export interface WorkspaceByokModelProbeCheckType {
  __typename?: 'WorkspaceByokModelProbeCheckType';
  operation: ByokProbeOperation;
  status: WorkspaceByokProbeStatusType;
}

export interface WorkspaceByokModelProbeType {
  __typename?: 'WorkspaceByokModelProbeType';
  checks: Array<WorkspaceByokModelProbeCheckType>;
  modelId: Scalars['String']['output'];
}

export interface WorkspaceByokPolicyType {
  __typename?: 'WorkspaceByokPolicyType';
  allowedProviders: Array<ByokProvider>;
  customEndpointMode: ByokCustomEndpointMode;
  enabled: Scalars['Boolean']['output'];
  privateEndpointSupported: Scalars['Boolean']['output'];
}

export interface WorkspaceByokProbeCheckInput {
  modelId: Scalars['String']['input'];
  operation: ByokProbeOperation;
}

export interface WorkspaceByokProbeResultType {
  __typename?: 'WorkspaceByokProbeResultType';
  connection: WorkspaceByokProbeStatusType;
  definitionFingerprint: Scalars['String']['output'];
  models: Array<WorkspaceByokModelProbeType>;
  stale: Scalars['Boolean']['output'];
}

export interface WorkspaceByokProbeStatusType {
  __typename?: 'WorkspaceByokProbeStatusType';
  errorKind: Maybe<Scalars['String']['output']>;
  kind: ByokProbeStatusKind;
  testedAt: Maybe<Scalars['DateTime']['output']>;
}

export interface WorkspaceByokProfileDefinitionInput {
  endpoint: WorkspaceByokEndpointInput;
  models: Array<WorkspaceByokModelDeclarationInput>;
}

export interface WorkspaceByokProfileDefinitionType {
  __typename?: 'WorkspaceByokProfileDefinitionType';
  endpoint: WorkspaceByokEndpointType;
  models: Array<WorkspaceByokModelDeclarationType>;
}

export interface WorkspaceByokProfileOrderInput {
  expectedRevision: Scalars['SafeInt']['input'];
  profileId: Scalars['ID']['input'];
}

export interface WorkspaceByokProfileType {
  __typename?: 'WorkspaceByokProfileType';
  definition: WorkspaceByokProfileDefinitionType;
  description: Maybe<Scalars['String']['output']>;
  enabled: Scalars['Boolean']['output'];
  name: Scalars['String']['output'];
  profileId: Scalars['ID']['output'];
  provider: ByokProvider;
  revision: Scalars['SafeInt']['output'];
  sortOrder: Scalars['SafeInt']['output'];
  validation: Maybe<WorkspaceByokValidationType>;
  workspaceId: Scalars['String']['output'];
}

export interface WorkspaceByokSettingsType {
  __typename?: 'WorkspaceByokSettingsType';
  catalog: WorkspaceByokCatalogType;
  entitled: Scalars['Boolean']['output'];
  localEntitled: Scalars['Boolean']['output'];
  policy: WorkspaceByokPolicyType;
  profiles: Array<WorkspaceByokProfileType>;
  serverEntitled: Scalars['Boolean']['output'];
  workspaceId: Scalars['String']['output'];
}

export interface WorkspaceByokUsagePointType {
  __typename?: 'WorkspaceByokUsagePointType';
  date: Scalars['DateTime']['output'];
  featureKind: Scalars['String']['output'];
  totalTokens: Scalars['SafeInt']['output'];
}

export interface WorkspaceByokValidationType {
  __typename?: 'WorkspaceByokValidationType';
  connection: WorkspaceByokProbeStatusType;
  credentialGeneration: Scalars['SafeInt']['output'];
  definitionFingerprint: Scalars['String']['output'];
  models: Array<WorkspaceByokModelProbeType>;
}

export interface WorkspaceCalendarItemInput {
  colorOverride?: InputMaybe<Scalars['String']['input']>;
  sortOrder?: InputMaybe<Scalars['Int']['input']>;
  subscriptionId: Scalars['String']['input'];
}

export interface WorkspaceCalendarItemObjectType {
  __typename?: 'WorkspaceCalendarItemObjectType';
  colorOverride: Maybe<Scalars['String']['output']>;
  enabled: Scalars['Boolean']['output'];
  id: Scalars['String']['output'];
  sortOrder: Maybe<Scalars['Int']['output']>;
  subscriptionId: Scalars['String']['output'];
}

export interface WorkspaceCalendarObjectType {
  __typename?: 'WorkspaceCalendarObjectType';
  colorOverride: Maybe<Scalars['String']['output']>;
  createdByUserId: Scalars['String']['output'];
  displayNameOverride: Maybe<Scalars['String']['output']>;
  enabled: Scalars['Boolean']['output'];
  events: Array<CalendarEventObjectType>;
  id: Scalars['String']['output'];
  items: Array<WorkspaceCalendarItemObjectType>;
  workspaceId: Scalars['String']['output'];
}

export interface WorkspaceCalendarObjectTypeEventsArgs {
  from: Scalars['DateTime']['input'];
  to: Scalars['DateTime']['input'];
}

export interface WorkspaceDocMeta {
  __typename?: 'WorkspaceDocMeta';
  createdAt: Scalars['DateTime']['output'];
  createdBy: Maybe<EditorType>;
  updatedAt: Scalars['DateTime']['output'];
  updatedBy: Maybe<EditorType>;
}

/** Workspace invite link expire time */
export enum WorkspaceInviteLinkExpireTime {
  OneDay = 'OneDay',
  OneMonth = 'OneMonth',
  OneWeek = 'OneWeek',
  ThreeDays = 'ThreeDays',
}

/** Member invite status in workspace */
export enum WorkspaceMemberStatus {
  Accepted = 'Accepted',
  AllocatingSeat = 'AllocatingSeat',
  NeedMoreSeat = 'NeedMoreSeat',
  NeedMoreSeatAndReview = 'NeedMoreSeatAndReview',
  Pending = 'Pending',
  UnderReview = 'UnderReview',
}

export interface WorkspacePermissionNotFoundDataType {
  __typename?: 'WorkspacePermissionNotFoundDataType';
  spaceId: Scalars['String']['output'];
}

export interface WorkspacePermissions {
  __typename?: 'WorkspacePermissions';
  Workspace_Administrators_Manage: Scalars['Boolean']['output'];
  Workspace_Blobs_List: Scalars['Boolean']['output'];
  Workspace_Blobs_Read: Scalars['Boolean']['output'];
  Workspace_Blobs_Write: Scalars['Boolean']['output'];
  Workspace_Copilot: Scalars['Boolean']['output'];
  Workspace_CreateDoc: Scalars['Boolean']['output'];
  Workspace_Delete: Scalars['Boolean']['output'];
  Workspace_Organize_Read: Scalars['Boolean']['output'];
  Workspace_Payment_Manage: Scalars['Boolean']['output'];
  Workspace_Properties_Create: Scalars['Boolean']['output'];
  Workspace_Properties_Delete: Scalars['Boolean']['output'];
  Workspace_Properties_Read: Scalars['Boolean']['output'];
  Workspace_Properties_Update: Scalars['Boolean']['output'];
  Workspace_Read: Scalars['Boolean']['output'];
  Workspace_Settings_Read: Scalars['Boolean']['output'];
  Workspace_Settings_Update: Scalars['Boolean']['output'];
  Workspace_Sync: Scalars['Boolean']['output'];
  Workspace_TransferOwner: Scalars['Boolean']['output'];
  Workspace_Users_Manage: Scalars['Boolean']['output'];
  Workspace_Users_Read: Scalars['Boolean']['output'];
}

export interface WorkspaceQuotaHumanReadableType {
  __typename?: 'WorkspaceQuotaHumanReadableType';
  blobLimit: Scalars['String']['output'];
  historyPeriod: Scalars['String']['output'];
  memberCount: Scalars['String']['output'];
  memberLimit: Scalars['String']['output'];
  name: Scalars['String']['output'];
  overcapacityMemberCount: Scalars['String']['output'];
  storageQuota: Scalars['String']['output'];
  storageQuotaUsed: Scalars['String']['output'];
}

export interface WorkspaceQuotaType {
  __typename?: 'WorkspaceQuotaType';
  blobLimit: Scalars['SafeInt']['output'];
  historyPeriod: Scalars['SafeInt']['output'];
  humanReadable: WorkspaceQuotaHumanReadableType;
  memberCount: Scalars['Int']['output'];
  memberLimit: Scalars['Int']['output'];
  name: Scalars['String']['output'];
  overcapacityMemberCount: Scalars['Int']['output'];
  storageQuota: Scalars['SafeInt']['output'];
  usedStorageQuota: Scalars['SafeInt']['output'];
}

export interface WorkspaceRolePermissions {
  __typename?: 'WorkspaceRolePermissions';
  permissions: WorkspacePermissions;
  role: Permission;
}

export interface WorkspaceType {
  __typename?: 'WorkspaceType';
  /** Search a specific table with aggregate */
  aggregate: AggregateResultObjectType;
  /** Get blob upload part url */
  blobUploadPartUrl: BlobUploadPart;
  /** List blobs of workspace */
  blobs: Array<ListedBlob>;
  /** Blobs size of workspace */
  blobsSize: Scalars['Int']['output'];
  byokSettings: WorkspaceByokSettingsType;
  byokUsage: Array<WorkspaceByokUsagePointType>;
  calendars: Array<WorkspaceCalendarObjectType>;
  /** Get comment changes of a doc */
  commentChanges: PaginatedCommentChangeObjectType;
  /** Get comments of a doc */
  comments: PaginatedCommentObjectType;
  /** Workspace created date */
  createdAt: Scalars['DateTime']['output'];
  /** Get get with given id */
  doc: DocType;
  docs: PaginatedDocType;
  embedding: CopilotWorkspaceConfig;
  /** Enable AI */
  enableAi: Scalars['Boolean']['output'];
  /** Enable doc embedding */
  enableDocEmbedding: Scalars['Boolean']['output'];
  /** Enable workspace sharing */
  enableSharing: Scalars['Boolean']['output'];
  /** Enable url previous when sharing */
  enableUrlPreview: Scalars['Boolean']['output'];
  histories: Array<DocHistoryType>;
  id: Scalars['ID']['output'];
  /** is current workspace initialized */
  initialized: Scalars['Boolean']['output'];
  /** invite link for workspace */
  inviteLink: Maybe<InviteLink>;
  /** Get user invoice count */
  invoiceCount: Scalars['Int']['output'];
  invoices: Array<InvoiceType>;
  /** The selfhost license of the workspace */
  license: Maybe<License>;
  /** member count of workspace */
  memberCount: Scalars['Int']['output'];
  /** Members of workspace */
  members: Array<InviteUserType>;
  /** Owner of workspace */
  owner: UserType;
  /**
   * Cloud page metadata of workspace
   * @deprecated use [WorkspaceType.doc] instead
   */
  pageMeta: WorkspaceDocMeta;
  /** map of action permissions */
  permissions: WorkspacePermissions;
  /** is Public workspace */
  public: Scalars['Boolean']['output'];
  /** Get public docs of a workspace */
  publicDocs: Array<DocType>;
  /** quota of workspace */
  quota: WorkspaceQuotaType;
  /** Get recently updated docs of a workspace */
  recentlyUpdatedDocs: PaginatedDocType;
  /** Role of current signed in user in workspace */
  role: Permission;
  /** Search a specific table */
  search: SearchResultObjectType;
  /** Search docs by keyword */
  searchDocs: Array<SearchDocObjectType>;
  /** The team subscription of the workspace, if exists. */
  subscription: Maybe<SubscriptionType>;
  /** if workspace is team workspace */
  team: Scalars['Boolean']['output'];
}

export interface WorkspaceTypeAggregateArgs {
  input: AggregateInput;
}

export interface WorkspaceTypeBlobUploadPartUrlArgs {
  key: Scalars['String']['input'];
  partNumber: Scalars['Int']['input'];
  uploadId: Scalars['String']['input'];
}

export interface WorkspaceTypeByokUsageArgs {
  from: Scalars['DateTime']['input'];
  to: Scalars['DateTime']['input'];
}

export interface WorkspaceTypeCommentChangesArgs {
  docId: Scalars['String']['input'];
  pagination: PaginationInput;
}

export interface WorkspaceTypeCommentsArgs {
  docId: Scalars['String']['input'];
  pagination?: InputMaybe<PaginationInput>;
}

export interface WorkspaceTypeDocArgs {
  docId: Scalars['String']['input'];
}

export interface WorkspaceTypeDocsArgs {
  pagination: PaginationInput;
}

export interface WorkspaceTypeHistoriesArgs {
  before?: InputMaybe<Scalars['DateTime']['input']>;
  guid: Scalars['String']['input'];
  take?: InputMaybe<Scalars['Int']['input']>;
}

export interface WorkspaceTypeInvoicesArgs {
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
}

export interface WorkspaceTypeMembersArgs {
  query?: InputMaybe<Scalars['String']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
}

export interface WorkspaceTypePageMetaArgs {
  pageId: Scalars['String']['input'];
}

export interface WorkspaceTypeRecentlyUpdatedDocsArgs {
  pagination: PaginationInput;
}

export interface WorkspaceTypeSearchArgs {
  input: SearchInput;
}

export interface WorkspaceTypeSearchDocsArgs {
  input: SearchDocsInput;
}

export interface WorkspaceUserType {
  __typename?: 'WorkspaceUserType';
  avatarUrl: Maybe<Scalars['String']['output']>;
  email: Scalars['String']['output'];
  id: Scalars['String']['output'];
  name: Scalars['String']['output'];
}

export interface WrongSignInCredentialsDataType {
  __typename?: 'WrongSignInCredentialsDataType';
  email: Scalars['String']['output'];
}

export interface TokenType {
  __typename?: 'tokenType';
  refresh: Scalars['String']['output'];
  sessionToken: Maybe<Scalars['String']['output']>;
  token: Scalars['String']['output'];
}

export type AdminAllSharedLinksQueryVariables = Exact<{
  pagination: PaginationInput;
  filter?: InputMaybe<AdminAllSharedLinksFilterInput>;
}>;

export type AdminAllSharedLinksQuery = {
  __typename?: 'Query';
  adminAllSharedLinks: {
    __typename?: 'PaginatedAdminAllSharedLink';
    totalCount: number | null;
    analyticsWindow: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
    pageInfo: {
      __typename?: 'PageInfo';
      hasNextPage: boolean;
      hasPreviousPage: boolean;
      startCursor: string | null;
      endCursor: string | null;
    };
    edges: Array<{
      __typename?: 'AdminAllSharedLinkEdge';
      cursor: string;
      node: {
        __typename?: 'AdminAllSharedLink';
        workspaceId: string;
        docId: string;
        title: string | null;
        publishedAt: string | null;
        docUpdatedAt: string | null;
        workspaceOwnerId: string | null;
        lastUpdaterId: string | null;
        shareUrl: string;
        views: number | null;
        uniqueViews: number | null;
        guestViews: number | null;
        lastAccessedAt: string | null;
      };
    }>;
  };
};

export type AdminDashboardQueryVariables = Exact<{
  input?: InputMaybe<AdminDashboardInput>;
}>;

export type AdminDashboardQuery = {
  __typename?: 'Query';
  adminDashboard: {
    __typename?: 'AdminDashboard';
    syncActiveUsers: number;
    copilotConversations: number;
    workspaceStorageBytes: number;
    blobStorageBytes: number;
    generatedAt: string;
    syncActiveUsersTimeline: Array<{
      __typename?: 'AdminDashboardMinutePoint';
      minute: string;
      activeUsers: number;
    }>;
    syncWindow: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
    copilotWindow: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
    workspaceStorageHistory: Array<{
      __typename?: 'AdminDashboardValueDayPoint';
      date: string;
      value: number;
    }>;
    blobStorageHistory: Array<{
      __typename?: 'AdminDashboardValueDayPoint';
      date: string;
      value: number;
    }>;
    storageWindow: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
    topSharedLinks: Array<{
      __typename?: 'AdminSharedLinkTopItem';
      workspaceId: string;
      docId: string;
      title: string | null;
      shareUrl: string;
      publishedAt: string | null;
      views: number;
      uniqueViews: number;
      guestViews: number;
      lastAccessedAt: string | null;
    }>;
    topSharedLinksWindow: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
  };
};

export type AdminMailDeliveriesQueryVariables = Exact<{
  input?: InputMaybe<AdminMailDeliveriesInput>;
}>;

export type AdminMailDeliveriesQuery = {
  __typename?: 'Query';
  adminMailDeliveries: {
    __typename?: 'AdminMailDeliveryAnalytics';
    window: {
      __typename?: 'TimeWindow';
      from: string;
      to: string;
      timezone: string;
      bucket: TimeBucket;
      requestedSize: number;
      effectiveSize: number;
    };
    summary: {
      __typename?: 'AdminMailDeliverySummary';
      total: number;
      sent: number;
      failed: number;
      skipped: number;
      canceled: number;
      queued: number;
      sending: number;
      retryWait: number;
      successRate: number;
    };
    byStatus: Array<{
      __typename?: 'AdminMailDeliverySeries';
      key: string;
      label: string;
      total: number;
      points: Array<{
        __typename?: 'AdminMailDeliveryPoint';
        bucket: string;
        count: number;
      }>;
    }>;
    byType: Array<{
      __typename?: 'AdminMailDeliverySeries';
      key: string;
      label: string;
      total: number;
      points: Array<{
        __typename?: 'AdminMailDeliveryPoint';
        bucket: string;
        count: number;
      }>;
    }>;
    byOutcome: Array<{
      __typename?: 'AdminMailDeliverySeries';
      key: string;
      label: string;
      total: number;
      points: Array<{
        __typename?: 'AdminMailDeliveryPoint';
        bucket: string;
        count: number;
      }>;
    }>;
  };
};

export type AdminServerConfigQueryVariables = Exact<{ [key: string]: never }>;

export type AdminServerConfigQuery = {
  __typename?: 'Query';
  serverConfig: {
    __typename?: 'ServerConfigType';
    version: string;
    baseUrl: string;
    name: string;
    features: Array<ServerFeature>;
    type: ServerDeploymentType;
    initialized: boolean;
    availableUserFeatures: Array<FeatureType>;
    credentialsRequirement: {
      __typename?: 'CredentialsRequirementType';
      password: {
        __typename?: 'PasswordLimitsType';
        minLength: number;
        maxLength: number;
      };
    };
    availableUpgrade: {
      __typename?: 'ReleaseVersionType';
      changelog: string;
      version: string;
      publishedAt: string;
      url: string;
    } | null;
  };
};

export type AdminUpdateWorkspaceMutationVariables = Exact<{
  input: AdminUpdateWorkspaceInput;
}>;

export type AdminUpdateWorkspaceMutation = {
  __typename?: 'Mutation';
  adminUpdateWorkspace: {
    __typename?: 'AdminWorkspace';
    id: string;
    public: boolean;
    createdAt: string;
    name: string | null;
    avatarKey: string | null;
    enableAi: boolean;
    enableSharing: boolean;
    enableUrlPreview: boolean;
    enableDocEmbedding: boolean;
    memberCount: number;
    publicPageCount: number;
    snapshotCount: number;
    snapshotSize: number;
    blobCount: number;
    blobSize: number;
    owner: {
      __typename?: 'WorkspaceUserType';
      id: string;
      name: string;
      email: string;
      avatarUrl: string | null;
    } | null;
  } | null;
};

export type AdminWorkspaceQueryVariables = Exact<{
  id: Scalars['String']['input'];
  memberSkip?: InputMaybe<Scalars['Int']['input']>;
  memberTake?: InputMaybe<Scalars['Int']['input']>;
  memberQuery?: InputMaybe<Scalars['String']['input']>;
}>;

export type AdminWorkspaceQuery = {
  __typename?: 'Query';
  adminWorkspace: {
    __typename?: 'AdminWorkspace';
    id: string;
    public: boolean;
    createdAt: string;
    name: string | null;
    avatarKey: string | null;
    enableAi: boolean;
    enableSharing: boolean;
    enableUrlPreview: boolean;
    enableDocEmbedding: boolean;
    memberCount: number;
    publicPageCount: number;
    snapshotCount: number;
    snapshotSize: number;
    blobCount: number;
    blobSize: number;
    owner: {
      __typename?: 'WorkspaceUserType';
      id: string;
      name: string;
      email: string;
      avatarUrl: string | null;
    } | null;
    sharedLinks: Array<{
      __typename?: 'AdminWorkspaceSharedLink';
      docId: string;
      title: string | null;
      publishedAt: string | null;
    }>;
    members: Array<{
      __typename?: 'AdminWorkspaceMember';
      id: string;
      name: string;
      email: string;
      avatarUrl: string | null;
      role: AdminWorkspaceMemberRole;
      status: WorkspaceMemberStatus;
    }>;
  } | null;
};

export type AdminWorkspacesQueryVariables = Exact<{
  filter: ListWorkspaceInput;
}>;

export type AdminWorkspacesQuery = {
  __typename?: 'Query';
  adminWorkspaces: Array<{
    __typename?: 'AdminWorkspace';
    id: string;
    public: boolean;
    createdAt: string;
    name: string | null;
    avatarKey: string | null;
    enableAi: boolean;
    enableSharing: boolean;
    enableUrlPreview: boolean;
    enableDocEmbedding: boolean;
    memberCount: number;
    publicPageCount: number;
    snapshotCount: number;
    snapshotSize: number;
    blobCount: number;
    blobSize: number;
    owner: {
      __typename?: 'WorkspaceUserType';
      id: string;
      name: string;
      email: string;
      avatarUrl: string | null;
    } | null;
  }>;
};

export type AdminWorkspacesCountQueryVariables = Exact<{
  filter: ListWorkspaceInput;
}>;

export type AdminWorkspacesCountQuery = {
  __typename?: 'Query';
  adminWorkspacesCount: number;
};

export type AuthSigningKeysQueryVariables = Exact<{ [key: string]: never }>;

export type AuthSigningKeysQuery = {
  __typename?: 'Query';
  authSigningKeys: Array<{
    __typename?: 'AuthSigningKeyType';
    id: string;
    status: string;
    source: string;
    createdAt: string | null;
    retiredAt: string | null;
    verifyUntil: string | null;
    canDelete: boolean;
  }>;
};

export type CreateChangePasswordUrlMutationVariables = Exact<{
  callbackUrl: Scalars['String']['input'];
  userId: Scalars['String']['input'];
}>;

export type CreateChangePasswordUrlMutation = {
  __typename?: 'Mutation';
  createChangePasswordUrl: string;
};

export type AppConfigQueryVariables = Exact<{ [key: string]: never }>;

export type AppConfigQuery = { __typename?: 'Query'; appConfig: any };

export type CreateUserMutationVariables = Exact<{
  input: CreateUserInput;
}>;

export type CreateUserMutation = {
  __typename?: 'Mutation';
  createUser: { __typename?: 'UserType'; id: string };
};

export type DeleteAuthSigningKeyMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteAuthSigningKeyMutation = {
  __typename?: 'Mutation';
  deleteAuthSigningKey: Array<{
    __typename?: 'AuthSigningKeyType';
    id: string;
    status: string;
    source: string;
    createdAt: string | null;
    retiredAt: string | null;
    verifyUntil: string | null;
    canDelete: boolean;
  }>;
};

export type DeleteUserMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteUserMutation = {
  __typename?: 'Mutation';
  deleteUser: { __typename?: 'DeleteAccount'; success: boolean };
};

export type DisableUserMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DisableUserMutation = {
  __typename?: 'Mutation';
  banUser: { __typename?: 'UserType'; email: string; disabled: boolean };
};

export type EnableUserMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type EnableUserMutation = {
  __typename?: 'Mutation';
  enableUser: { __typename?: 'UserType'; email: string; disabled: boolean };
};

export type GetUserByEmailQueryVariables = Exact<{
  email: Scalars['String']['input'];
}>;

export type GetUserByEmailQuery = {
  __typename?: 'Query';
  userByEmail: {
    __typename?: 'UserType';
    id: string;
    name: string;
    email: string;
    features: Array<FeatureType>;
    hasPassword: boolean | null;
    emailVerified: boolean;
    avatarUrl: string | null;
    disabled: boolean;
  } | null;
};

export type ImportUsersMutationVariables = Exact<{
  input: ImportUsersInput;
}>;

export type ImportUsersMutation = {
  __typename?: 'Mutation';
  importUsers: Array<
    | { __typename: 'UserImportFailedType'; email: string; error: string }
    | { __typename: 'UserType'; id: string; name: string; email: string }
  >;
};

export type ListUsersQueryVariables = Exact<{
  filter: ListUserInput;
}>;

export type ListUsersQuery = {
  __typename?: 'Query';
  usersCount: number;
  users: Array<{
    __typename?: 'UserType';
    id: string;
    name: string;
    email: string;
    disabled: boolean;
    features: Array<FeatureType>;
    hasPassword: boolean | null;
    emailVerified: boolean;
    avatarUrl: string | null;
  }>;
};

export type RotateAuthSigningKeyMutationVariables = Exact<{
  expectedActiveKeyId: Scalars['String']['input'];
}>;

export type RotateAuthSigningKeyMutation = {
  __typename?: 'Mutation';
  rotateAuthSigningKey: Array<{
    __typename?: 'AuthSigningKeyType';
    id: string;
    status: string;
    source: string;
    createdAt: string | null;
    retiredAt: string | null;
    verifyUntil: string | null;
    canDelete: boolean;
  }>;
};

export type SendTestEmailMutationVariables = Exact<{
  name: Scalars['String']['input'];
  host: Scalars['String']['input'];
  port: Scalars['Int']['input'];
  sender: Scalars['String']['input'];
  username: Scalars['String']['input'];
  password: Scalars['String']['input'];
  ignoreTLS: Scalars['Boolean']['input'];
}>;

export type SendTestEmailMutation = {
  __typename?: 'Mutation';
  sendTestEmail: boolean;
};

export type UpdateAccountFeaturesMutationVariables = Exact<{
  userId: Scalars['String']['input'];
  features: Array<FeatureType> | FeatureType;
}>;

export type UpdateAccountFeaturesMutation = {
  __typename?: 'Mutation';
  updateUserFeatures: Array<FeatureType>;
};

export type UpdateAccountMutationVariables = Exact<{
  id: Scalars['String']['input'];
  input: ManageUserInput;
}>;

export type UpdateAccountMutation = {
  __typename?: 'Mutation';
  updateUser: {
    __typename?: 'UserType';
    id: string;
    name: string;
    email: string;
  };
};

export type UpdateAppConfigMutationVariables = Exact<{
  updates: Array<UpdateAppConfigInput> | UpdateAppConfigInput;
}>;

export type UpdateAppConfigMutation = {
  __typename?: 'Mutation';
  updateAppConfig: any;
};

export type ValidateConfigQueryVariables = Exact<{
  updates: Array<UpdateAppConfigInput> | UpdateAppConfigInput;
}>;

export type ValidateConfigQuery = {
  __typename?: 'Query';
  validateAppConfig: Array<{
    __typename?: 'AppConfigValidateResult';
    module: string;
    key: string;
    value: Record<string, string>;
    valid: boolean;
    error: string | null;
  }>;
};

export type DeleteBlobMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  key: Scalars['String']['input'];
  permanently?: InputMaybe<Scalars['Boolean']['input']>;
}>;

export type DeleteBlobMutation = {
  __typename?: 'Mutation';
  deleteBlob: boolean;
};

export type ListBlobsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type ListBlobsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    blobs: Array<{
      __typename?: 'ListedBlob';
      key: string;
      size: number;
      mime: string;
      createdAt: string;
    }>;
  };
};

export type ReleaseDeletedBlobsMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type ReleaseDeletedBlobsMutation = {
  __typename?: 'Mutation';
  releaseDeletedBlobs: boolean;
};

export type SetBlobMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  blob: Scalars['Upload']['input'];
}>;

export type SetBlobMutation = { __typename?: 'Mutation'; setBlob: string };

export type AbortBlobUploadMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  key: Scalars['String']['input'];
  uploadId: Scalars['String']['input'];
}>;

export type AbortBlobUploadMutation = {
  __typename?: 'Mutation';
  abortBlobUpload: boolean;
};

export type CompleteBlobUploadMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  key: Scalars['String']['input'];
  uploadId?: InputMaybe<Scalars['String']['input']>;
  parts?: InputMaybe<Array<BlobUploadPartInput> | BlobUploadPartInput>;
}>;

export type CompleteBlobUploadMutation = {
  __typename?: 'Mutation';
  completeBlobUpload: string;
};

export type CreateBlobUploadMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  key: Scalars['String']['input'];
  size: Scalars['Int']['input'];
  mime: Scalars['String']['input'];
}>;

export type CreateBlobUploadMutation = {
  __typename?: 'Mutation';
  createBlobUpload: {
    __typename?: 'BlobUploadInit';
    method: BlobUploadMethod;
    blobKey: string;
    alreadyUploaded: boolean | null;
    uploadUrl: string | null;
    headers: any | null;
    expiresAt: string | null;
    uploadId: string | null;
    partSize: number | null;
    uploadedParts: Array<{
      __typename?: 'BlobUploadedPart';
      partNumber: number;
      etag: string;
    }> | null;
  };
};

export type GetBlobUploadPartUrlQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  key: Scalars['String']['input'];
  uploadId: Scalars['String']['input'];
  partNumber: Scalars['Int']['input'];
}>;

export type GetBlobUploadPartUrlQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    blobUploadPartUrl: {
      __typename?: 'BlobUploadPart';
      uploadUrl: string;
      headers: any | null;
      expiresAt: string | null;
    };
  };
};

export type CalendarAccountsQueryVariables = Exact<{ [key: string]: never }>;

export type CalendarAccountsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    calendarAccounts: Array<{
      __typename?: 'CalendarAccountObjectType';
      id: string;
      provider: CalendarProviderType;
      providerAccountId: string;
      displayName: string | null;
      email: string | null;
      status: string;
      lastError: string | null;
      refreshIntervalMinutes: number;
      calendarsCount: number;
      createdAt: string;
      updatedAt: string;
      calendars: Array<{
        __typename?: 'CalendarSubscriptionObjectType';
        id: string;
        accountId: string;
        provider: CalendarProviderType;
        externalCalendarId: string;
        displayName: string | null;
        timezone: string | null;
        color: string | null;
        enabled: boolean;
        lastSyncAt: string | null;
      }>;
    }>;
  } | null;
};

export type CalendarEventsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  from: Scalars['DateTime']['input'];
  to: Scalars['DateTime']['input'];
}>;

export type CalendarEventsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    calendars: Array<{
      __typename?: 'WorkspaceCalendarObjectType';
      id: string;
      events: Array<{
        __typename?: 'CalendarEventObjectType';
        id: string;
        subscriptionId: string;
        externalEventId: string;
        recurrenceId: string | null;
        status: string | null;
        title: string | null;
        description: string | null;
        location: string | null;
        startAtUtc: string;
        endAtUtc: string;
        originalTimezone: string | null;
        allDay: boolean;
      }>;
    }>;
  };
};

export type CalendarProvidersQueryVariables = Exact<{ [key: string]: never }>;

export type CalendarProvidersQuery = {
  __typename?: 'Query';
  serverConfig: {
    __typename?: 'ServerConfigType';
    calendarProviders: Array<CalendarProviderType>;
    calendarCalDAVProviders: Array<{
      __typename?: 'CalendarCalDAVProviderPresetObjectType';
      id: string;
      label: string;
      requiresAppPassword: boolean | null;
      docsUrl: string | null;
    }>;
  };
};

export type LinkCalDavAccountMutationVariables = Exact<{
  input: LinkCalDavAccountInput;
}>;

export type LinkCalDavAccountMutation = {
  __typename?: 'Mutation';
  linkCalDAVAccount: {
    __typename?: 'CalendarAccountObjectType';
    id: string;
    provider: CalendarProviderType;
    providerAccountId: string;
    displayName: string | null;
    email: string | null;
    status: string;
    lastError: string | null;
    refreshIntervalMinutes: number;
    calendarsCount: number;
    createdAt: string;
    updatedAt: string;
  };
};

export type LinkCalendarAccountMutationVariables = Exact<{
  input: LinkCalendarAccountInput;
}>;

export type LinkCalendarAccountMutation = {
  __typename?: 'Mutation';
  linkCalendarAccount: string;
};

export type UnlinkCalendarAccountMutationVariables = Exact<{
  accountId: Scalars['String']['input'];
}>;

export type UnlinkCalendarAccountMutation = {
  __typename?: 'Mutation';
  unlinkCalendarAccount: boolean;
};

export type UpdateCalendarAccountMutationVariables = Exact<{
  accountId: Scalars['String']['input'];
  refreshIntervalMinutes: Scalars['Int']['input'];
}>;

export type UpdateCalendarAccountMutation = {
  __typename?: 'Mutation';
  updateCalendarAccount: {
    __typename?: 'CalendarAccountObjectType';
    id: string;
    provider: CalendarProviderType;
    providerAccountId: string;
    displayName: string | null;
    email: string | null;
    status: string;
    lastError: string | null;
    refreshIntervalMinutes: number;
    calendarsCount: number;
    createdAt: string;
    updatedAt: string;
  } | null;
};

export type UpdateWorkspaceCalendarsMutationVariables = Exact<{
  input: UpdateWorkspaceCalendarsInput;
}>;

export type UpdateWorkspaceCalendarsMutation = {
  __typename?: 'Mutation';
  updateWorkspaceCalendars: {
    __typename?: 'WorkspaceCalendarObjectType';
    id: string;
    workspaceId: string;
    createdByUserId: string;
    displayNameOverride: string | null;
    colorOverride: string | null;
    enabled: boolean;
    items: Array<{
      __typename?: 'WorkspaceCalendarItemObjectType';
      id: string;
      subscriptionId: string;
      sortOrder: number | null;
      colorOverride: string | null;
      enabled: boolean;
    }>;
  };
};

export type WorkspaceCalendarsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type WorkspaceCalendarsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    calendars: Array<{
      __typename?: 'WorkspaceCalendarObjectType';
      id: string;
      workspaceId: string;
      createdByUserId: string;
      displayNameOverride: string | null;
      colorOverride: string | null;
      enabled: boolean;
      items: Array<{
        __typename?: 'WorkspaceCalendarItemObjectType';
        id: string;
        subscriptionId: string;
        sortOrder: number | null;
        colorOverride: string | null;
        enabled: boolean;
      }>;
    }>;
  };
};

export type CancelSubscriptionMutationVariables = Exact<{
  plan?: InputMaybe<SubscriptionPlan>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}>;

export type CancelSubscriptionMutation = {
  __typename?: 'Mutation';
  cancelSubscription: {
    __typename?: 'SubscriptionType';
    id: string | null;
    status: SubscriptionStatus;
    nextBillAt: string | null;
    canceledAt: string | null;
  };
};

export type ChangeEmailMutationVariables = Exact<{
  token: Scalars['String']['input'];
  email: Scalars['String']['input'];
}>;

export type ChangeEmailMutation = {
  __typename?: 'Mutation';
  changeEmail: { __typename?: 'UserType'; id: string; email: string };
};

export type ChangePasswordMutationVariables = Exact<{
  token: Scalars['String']['input'];
  userId: Scalars['String']['input'];
  newPassword: Scalars['String']['input'];
}>;

export type ChangePasswordMutation = {
  __typename?: 'Mutation';
  changePassword: boolean;
};

export type ListCommentChangesQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  pagination: PaginationInput;
}>;

export type ListCommentChangesQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    commentChanges: {
      __typename?: 'PaginatedCommentChangeObjectType';
      totalCount: number;
      edges: Array<{
        __typename?: 'CommentChangeObjectTypeEdge';
        cursor: string;
        node: {
          __typename?: 'CommentChangeObjectType';
          action: CommentChangeAction;
          id: string;
          commentId: string | null;
          item: any;
        };
      }>;
      pageInfo: {
        __typename?: 'PageInfo';
        startCursor: string | null;
        endCursor: string | null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
      };
    };
  };
};

export type CreateCommentMutationVariables = Exact<{
  input: CommentCreateInput;
}>;

export type CreateCommentMutation = {
  __typename?: 'Mutation';
  createComment: {
    __typename?: 'CommentObjectType';
    id: string;
    content: any;
    resolved: boolean;
    createdAt: string;
    updatedAt: string;
    user: {
      __typename?: 'PublicUserType';
      id: string;
      name: string;
      avatarUrl: string | null;
    };
    replies: Array<{
      __typename?: 'ReplyObjectType';
      commentId: string;
      id: string;
      content: any;
      createdAt: string;
      updatedAt: string;
      user: {
        __typename?: 'PublicUserType';
        id: string;
        name: string;
        avatarUrl: string | null;
      };
    }>;
  };
};

export type DeleteCommentMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteCommentMutation = {
  __typename?: 'Mutation';
  deleteComment: boolean;
};

export type ListCommentsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  pagination?: InputMaybe<PaginationInput>;
}>;

export type ListCommentsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    comments: {
      __typename?: 'PaginatedCommentObjectType';
      totalCount: number;
      edges: Array<{
        __typename?: 'CommentObjectTypeEdge';
        cursor: string;
        node: {
          __typename?: 'CommentObjectType';
          id: string;
          content: any;
          resolved: boolean;
          createdAt: string;
          updatedAt: string;
          user: {
            __typename?: 'PublicUserType';
            id: string;
            name: string;
            avatarUrl: string | null;
          };
          replies: Array<{
            __typename?: 'ReplyObjectType';
            commentId: string;
            id: string;
            content: any;
            createdAt: string;
            updatedAt: string;
            user: {
              __typename?: 'PublicUserType';
              id: string;
              name: string;
              avatarUrl: string | null;
            };
          }>;
        };
      }>;
      pageInfo: {
        __typename?: 'PageInfo';
        startCursor: string | null;
        endCursor: string | null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
      };
    };
  };
};

export type CreateReplyMutationVariables = Exact<{
  input: ReplyCreateInput;
}>;

export type CreateReplyMutation = {
  __typename?: 'Mutation';
  createReply: {
    __typename?: 'ReplyObjectType';
    commentId: string;
    id: string;
    content: any;
    createdAt: string;
    updatedAt: string;
    user: {
      __typename?: 'PublicUserType';
      id: string;
      name: string;
      avatarUrl: string | null;
    };
  };
};

export type DeleteReplyMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteReplyMutation = {
  __typename?: 'Mutation';
  deleteReply: boolean;
};

export type UpdateReplyMutationVariables = Exact<{
  input: ReplyUpdateInput;
}>;

export type UpdateReplyMutation = {
  __typename?: 'Mutation';
  updateReply: boolean;
};

export type ResolveCommentMutationVariables = Exact<{
  input: CommentResolveInput;
}>;

export type ResolveCommentMutation = {
  __typename?: 'Mutation';
  resolveComment: boolean;
};

export type UpdateCommentMutationVariables = Exact<{
  input: CommentUpdateInput;
}>;

export type UpdateCommentMutation = {
  __typename?: 'Mutation';
  updateComment: boolean;
};

export type UploadCommentAttachmentMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  attachment: Scalars['Upload']['input'];
}>;

export type UploadCommentAttachmentMutation = {
  __typename?: 'Mutation';
  uploadCommentAttachment: string;
};

export type GetCopilotHistoryIdsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatHistoriesInput>;
}>;

export type GetCopilotHistoryIdsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            pinned: boolean;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              createdAt: string;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotDocSessionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  pagination: PaginationInput;
  options?: InputMaybe<QueryChatHistoriesInput>;
}>;

export type GetCopilotDocSessionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotPinnedSessionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId?: InputMaybe<Scalars['String']['input']>;
  messageOrder?: InputMaybe<ChatHistoryOrder>;
  withPrompt?: InputMaybe<Scalars['Boolean']['input']>;
}>;

export type GetCopilotPinnedSessionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotWorkspaceSessionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
  options?: InputMaybe<QueryChatHistoriesInput>;
}>;

export type GetCopilotWorkspaceSessionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotHistoriesQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatHistoriesInput>;
}>;

export type GetCopilotHistoriesQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type CreateCopilotMessageMutationVariables = Exact<{
  options: CreateChatMessageInput;
}>;

export type CreateCopilotMessageMutation = {
  __typename?: 'Mutation';
  createCopilotMessage: string;
};

export type CopilotQuotaQueryVariables = Exact<{ [key: string]: never }>;

export type CopilotQuotaQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      quota: {
        __typename?: 'CopilotQuota';
        limit: number | null;
        used: number;
      };
    };
  } | null;
};

export type GetCopilotRouteOptionsQueryVariables = Exact<{
  promptName: Scalars['String']['input'];
}>;

export type GetCopilotRouteOptionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      routeOptions: {
        __typename?: 'CopilotRouteOptions';
        routeId: string;
        defaultTargetId: string | null;
        choices: Array<{
          __typename?: 'CopilotRouteTarget';
          id: string;
          displayName: string;
          minimumTier: string;
          available: boolean;
        }>;
      } | null;
    };
  } | null;
};

export type CleanupCopilotSessionMutationVariables = Exact<{
  input: DeleteSessionInput;
}>;

export type CleanupCopilotSessionMutation = {
  __typename?: 'Mutation';
  cleanupCopilotSession: Array<string>;
};

export type CreateCopilotSessionWithHistoryMutationVariables = Exact<{
  options: CreateChatSessionInput;
}>;

export type CreateCopilotSessionWithHistoryMutation = {
  __typename?: 'Mutation';
  createCopilotSessionWithHistory: {
    __typename?: 'CopilotHistories';
    sessionId: string;
    workspaceId: string;
    docId: string | null;
    parentSessionId: string | null;
    promptName: string;
    action: string | null;
    pinned: boolean;
    title: string | null;
    createdAt: string;
    updatedAt: string;
    messages: Array<{
      __typename?: 'ChatMessage';
      id: string | null;
      role: string;
      content: string;
      attachments: Array<string> | null;
      scopeSnapshot: Record<string, string> | null;
      createdAt: string;
      streamObjects: Array<{
        __typename?: 'StreamObject';
        type: string;
        textDelta: string | null;
        toolCallId: string | null;
        toolName: string | null;
        args: Record<string, string> | null;
        result: Record<string, string> | null;
      }> | null;
    }>;
  };
};

export type CreateCopilotSessionMutationVariables = Exact<{
  options: CreateChatSessionInput;
}>;

export type CreateCopilotSessionMutation = {
  __typename?: 'Mutation';
  createCopilotSession: string;
};

export type ForkCopilotSessionMutationVariables = Exact<{
  options: ForkChatSessionInput;
}>;

export type ForkCopilotSessionMutation = {
  __typename?: 'Mutation';
  forkCopilotSession: string;
};

export type GetCopilotLatestDocSessionQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
}>;

export type GetCopilotLatestDocSessionQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotSessionQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  sessionId: Scalars['String']['input'];
}>;

export type GetCopilotSessionQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetCopilotRecentSessionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  limit?: InputMaybe<Scalars['Int']['input']>;
  offset?: InputMaybe<Scalars['Int']['input']>;
}>;

export type GetCopilotRecentSessionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type UpdateCopilotSessionMutationVariables = Exact<{
  options: UpdateChatSessionInput;
}>;

export type UpdateCopilotSessionMutation = {
  __typename?: 'Mutation';
  updateCopilotSession: string;
};

export type GetCopilotSessionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
  docId?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<QueryChatHistoriesInput>;
}>;

export type GetCopilotSessionsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      chats: {
        __typename?: 'PaginatedCopilotHistoriesType';
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'CopilotHistoriesTypeEdge';
          cursor: string;
          node: {
            __typename?: 'CopilotHistories';
            sessionId: string;
            workspaceId: string;
            docId: string | null;
            parentSessionId: string | null;
            promptName: string;
            action: string | null;
            pinned: boolean;
            title: string | null;
            createdAt: string;
            updatedAt: string;
            messages: Array<{
              __typename?: 'ChatMessage';
              id: string | null;
              role: string;
              content: string;
              attachments: Array<string> | null;
              scopeSnapshot: Record<string, string> | null;
              createdAt: string;
              streamObjects: Array<{
                __typename?: 'StreamObject';
                type: string;
                textDelta: string | null;
                toolCallId: string | null;
                toolName: string | null;
                args: Record<string, string> | null;
                result: Record<string, string> | null;
              }> | null;
            }>;
          };
        }>;
      };
    };
  } | null;
};

export type GetTranscriptTaskQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  taskId?: InputMaybe<Scalars['String']['input']>;
  blobId?: InputMaybe<Scalars['String']['input']>;
}>;

export type GetTranscriptTaskQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    copilot: {
      __typename?: 'Copilot';
      transcriptTask: {
        __typename?: 'TranscriptionResultType';
        id: string;
        status: AiJobStatus;
        title: string | null;
        summary: string | null;
        normalizedTranscript: string | null;
        sourceAudio: {
          __typename?: 'TranscriptionSourceAudioType';
          blobId: string | null;
          mimeType: string | null;
          durationMs: number | null;
          sampleRate: number | null;
          channels: number | null;
        } | null;
        quality: {
          __typename?: 'TranscriptionQualityType';
          degraded: boolean | null;
          overflowCount: number | null;
        } | null;
        sliceManifest: Array<{
          __typename?: 'AudioSliceManifestItemType';
          index: number;
          fileName: string;
          mimeType: string;
          startSec: number;
          durationSec: number;
          byteSize: number | null;
        }> | null;
        normalizedSegments: Array<{
          __typename?: 'NormalizedTranscriptSegmentType';
          speaker: string;
          startSec: number;
          endSec: number;
          start: string;
          end: string;
          text: string;
        }> | null;
        summaryJson: {
          __typename?: 'MeetingSummaryV2Type';
          title: string;
          durationMinutes: number;
          attendees: Array<string>;
          keyPoints: Array<string>;
          decisions: Array<string>;
          openQuestions: Array<string>;
          blockers: Array<string>;
          actionItems: Array<{
            __typename?: 'MeetingActionItemType';
            description: string;
            owner: string | null;
            deadline: string | null;
          }>;
        } | null;
        transcription: Array<{
          __typename?: 'TranscriptionItemType';
          speaker: string;
          start: string;
          end: string;
          transcription: string;
        }> | null;
      } | null;
    };
  } | null;
};

export type RetryTranscriptTaskMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  taskId: Scalars['String']['input'];
}>;

export type RetryTranscriptTaskMutation = {
  __typename?: 'Mutation';
  retryTranscriptTask: {
    __typename?: 'TranscriptionResultType';
    id: string;
    status: AiJobStatus;
  } | null;
};

export type SettleTranscriptTaskMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  taskId: Scalars['String']['input'];
}>;

export type SettleTranscriptTaskMutation = {
  __typename?: 'Mutation';
  settleTranscriptTask: {
    __typename?: 'TranscriptionResultType';
    id: string;
    status: AiJobStatus;
    title: string | null;
    summary: string | null;
    actions: string | null;
    normalizedTranscript: string | null;
    sourceAudio: {
      __typename?: 'TranscriptionSourceAudioType';
      blobId: string | null;
      mimeType: string | null;
      durationMs: number | null;
      sampleRate: number | null;
      channels: number | null;
    } | null;
    quality: {
      __typename?: 'TranscriptionQualityType';
      degraded: boolean | null;
      overflowCount: number | null;
    } | null;
    sliceManifest: Array<{
      __typename?: 'AudioSliceManifestItemType';
      index: number;
      fileName: string;
      mimeType: string;
      startSec: number;
      durationSec: number;
      byteSize: number | null;
    }> | null;
    normalizedSegments: Array<{
      __typename?: 'NormalizedTranscriptSegmentType';
      speaker: string;
      startSec: number;
      endSec: number;
      start: string;
      end: string;
      text: string;
    }> | null;
    summaryJson: {
      __typename?: 'MeetingSummaryV2Type';
      title: string;
      durationMinutes: number;
      attendees: Array<string>;
      keyPoints: Array<string>;
      decisions: Array<string>;
      openQuestions: Array<string>;
      blockers: Array<string>;
      actionItems: Array<{
        __typename?: 'MeetingActionItemType';
        description: string;
        owner: string | null;
        deadline: string | null;
      }>;
    } | null;
    transcription: Array<{
      __typename?: 'TranscriptionItemType';
      speaker: string;
      start: string;
      end: string;
      transcription: string;
    }> | null;
  } | null;
};

export type SubmitTranscriptTaskMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  blobId: Scalars['String']['input'];
  blob?: InputMaybe<Scalars['Upload']['input']>;
  blobs?: InputMaybe<
    Array<Scalars['Upload']['input']> | Scalars['Upload']['input']
  >;
  input?: InputMaybe<SubmitAudioTranscriptionInput>;
}>;

export type SubmitTranscriptTaskMutation = {
  __typename?: 'Mutation';
  submitTranscriptTask: {
    __typename?: 'TranscriptionResultType';
    id: string;
    status: AiJobStatus;
  } | null;
};

export type AddWorkspaceArtifactMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  blob: Scalars['Upload']['input'];
}>;

export type AddWorkspaceArtifactMutation = {
  __typename?: 'Mutation';
  addWorkspaceArtifact: {
    __typename?: 'CopilotWorkspaceArtifact';
    artifactId: string;
    contentHash: string;
    mediaType: string;
    size: number;
    createdAt: string;
  };
};

export type GetWorkspaceArtifactsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
}>;

export type GetWorkspaceArtifactsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    embedding: {
      __typename?: 'CopilotWorkspaceConfig';
      artifacts: {
        __typename?: 'PaginatedCopilotWorkspaceArtifactType';
        totalCount: number;
        pageInfo: {
          __typename?: 'PageInfo';
          endCursor: string | null;
          hasNextPage: boolean;
        };
        edges: Array<{
          __typename?: 'CopilotWorkspaceArtifactTypeEdge';
          node: {
            __typename?: 'CopilotWorkspaceArtifact';
            artifactId: string;
            contentHash: string;
            fileName: string;
            embeddingStatus: string;
            mediaType: string;
            size: number;
            createdAt: string;
          };
        }>;
      };
    };
  };
};

export type RemoveWorkspaceArtifactMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  artifactId: Scalars['String']['input'];
}>;

export type RemoveWorkspaceArtifactMutation = {
  __typename?: 'Mutation';
  removeWorkspaceArtifact: boolean;
};

export type AddWorkspaceEmbeddingIgnoredDocsMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  add: Array<Scalars['String']['input']> | Scalars['String']['input'];
}>;

export type AddWorkspaceEmbeddingIgnoredDocsMutation = {
  __typename?: 'Mutation';
  updateWorkspaceEmbeddingIgnoredDocs: number;
};

export type GetAllWorkspaceEmbeddingIgnoredDocsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type GetAllWorkspaceEmbeddingIgnoredDocsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    embedding: {
      __typename?: 'CopilotWorkspaceConfig';
      allIgnoredDocs: Array<{
        __typename?: 'CopilotWorkspaceIgnoredDoc';
        docId: string;
        createdAt: string;
      }>;
    };
  };
};

export type GetWorkspaceEmbeddingIgnoredDocsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
}>;

export type GetWorkspaceEmbeddingIgnoredDocsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    embedding: {
      __typename?: 'CopilotWorkspaceConfig';
      ignoredDocs: {
        __typename?: 'PaginatedIgnoredDocsType';
        totalCount: number;
        pageInfo: {
          __typename?: 'PageInfo';
          endCursor: string | null;
          hasNextPage: boolean;
        };
        edges: Array<{
          __typename?: 'CopilotWorkspaceIgnoredDocTypeEdge';
          node: {
            __typename?: 'CopilotWorkspaceIgnoredDoc';
            docId: string;
            createdAt: string;
            docCreatedAt: string | null;
            docUpdatedAt: string | null;
            title: string | null;
            createdBy: string | null;
            createdByAvatar: string | null;
            updatedBy: string | null;
          };
        }>;
      };
    };
  };
};

export type RemoveWorkspaceEmbeddingIgnoredDocsMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  remove: Array<Scalars['String']['input']> | Scalars['String']['input'];
}>;

export type RemoveWorkspaceEmbeddingIgnoredDocsMutation = {
  __typename?: 'Mutation';
  updateWorkspaceEmbeddingIgnoredDocs: number;
};

export type CreateCheckoutSessionMutationVariables = Exact<{
  input: CreateCheckoutSessionInput;
}>;

export type CreateCheckoutSessionMutation = {
  __typename?: 'Mutation';
  createCheckoutSession: string;
};

export type CreateCustomerPortalMutationVariables = Exact<{
  [key: string]: never;
}>;

export type CreateCustomerPortalMutation = {
  __typename?: 'Mutation';
  createCustomerPortal: string;
};

export type CreateSelfhostCustomerPortalMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type CreateSelfhostCustomerPortalMutation = {
  __typename?: 'Mutation';
  createSelfhostWorkspaceCustomerPortal: string;
};

export type CreateWorkspaceMutationVariables = Exact<{ [key: string]: never }>;

export type CreateWorkspaceMutation = {
  __typename?: 'Mutation';
  createWorkspace: {
    __typename?: 'WorkspaceType';
    id: string;
    public: boolean;
    createdAt: string;
  };
};

export type DeleteAccountMutationVariables = Exact<{ [key: string]: never }>;

export type DeleteAccountMutation = {
  __typename?: 'Mutation';
  deleteAccount: { __typename?: 'DeleteAccount'; success: boolean };
};

export type DeleteWorkspaceMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteWorkspaceMutation = {
  __typename?: 'Mutation';
  deleteWorkspace: boolean;
};

export type GetDocRolePermissionsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
}>;

export type GetDocRolePermissionsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    doc: {
      __typename?: 'DocType';
      permissions: {
        __typename?: 'DocPermissions';
        Doc_Copy: boolean;
        Doc_Delete: boolean;
        Doc_Duplicate: boolean;
        Doc_Properties_Read: boolean;
        Doc_Properties_Update: boolean;
        Doc_Publish: boolean;
        Doc_Read: boolean;
        Doc_Restore: boolean;
        Doc_TransferOwner: boolean;
        Doc_Trash: boolean;
        Doc_Update: boolean;
        Doc_Users_Manage: boolean;
        Doc_Users_Read: boolean;
        Doc_Comments_Create: boolean;
        Doc_Comments_Delete: boolean;
        Doc_Comments_Read: boolean;
        Doc_Comments_Resolve: boolean;
      };
    };
  };
};

export type CopilotChatHistoryFragment = {
  __typename?: 'CopilotHistories';
  sessionId: string;
  workspaceId: string;
  docId: string | null;
  parentSessionId: string | null;
  promptName: string;
  action: string | null;
  pinned: boolean;
  title: string | null;
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    __typename?: 'ChatMessage';
    id: string | null;
    role: string;
    content: string;
    attachments: Array<string> | null;
    scopeSnapshot: Record<string, string> | null;
    createdAt: string;
    streamObjects: Array<{
      __typename?: 'StreamObject';
      type: string;
      textDelta: string | null;
      toolCallId: string | null;
      toolName: string | null;
      args: Record<string, string> | null;
      result: Record<string, string> | null;
    }> | null;
  }>;
};

export type CredentialsRequirementsFragment = {
  __typename?: 'CredentialsRequirementType';
  password: {
    __typename?: 'PasswordLimitsType';
    minLength: number;
    maxLength: number;
  };
};

export type PaginatedCopilotChatsFragment = {
  __typename?: 'PaginatedCopilotHistoriesType';
  pageInfo: {
    __typename?: 'PageInfo';
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    startCursor: string | null;
    endCursor: string | null;
  };
  edges: Array<{
    __typename?: 'CopilotHistoriesTypeEdge';
    cursor: string;
    node: {
      __typename?: 'CopilotHistories';
      sessionId: string;
      workspaceId: string;
      docId: string | null;
      parentSessionId: string | null;
      promptName: string;
      action: string | null;
      pinned: boolean;
      title: string | null;
      createdAt: string;
      updatedAt: string;
      messages: Array<{
        __typename?: 'ChatMessage';
        id: string | null;
        role: string;
        content: string;
        attachments: Array<string> | null;
        scopeSnapshot: Record<string, string> | null;
        createdAt: string;
        streamObjects: Array<{
          __typename?: 'StreamObject';
          type: string;
          textDelta: string | null;
          toolCallId: string | null;
          toolName: string | null;
          args: Record<string, string> | null;
          result: Record<string, string> | null;
        }> | null;
      }>;
    };
  }>;
};

export type PasswordLimitsFragment = {
  __typename?: 'PasswordLimitsType';
  minLength: number;
  maxLength: number;
};

export type GenerateLicenseKeyMutationVariables = Exact<{
  sessionId: Scalars['String']['input'];
}>;

export type GenerateLicenseKeyMutation = {
  __typename?: 'Mutation';
  generateLicenseKey: string;
};

export type GetCurrentUserFeaturesQueryVariables = Exact<{
  [key: string]: never;
}>;

export type GetCurrentUserFeaturesQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    id: string;
    name: string;
    email: string;
    emailVerified: boolean;
    avatarUrl: string | null;
    features: Array<FeatureType>;
  } | null;
};

export type GetCurrentUserQueryVariables = Exact<{ [key: string]: never }>;

export type GetCurrentUserQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    id: string;
    name: string;
    email: string;
    emailVerified: boolean;
    avatarUrl: string | null;
    hasPassword: boolean | null;
    features: Array<FeatureType>;
  } | null;
};

export type GetDocCreatedByUpdatedByListQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
}>;

export type GetDocCreatedByUpdatedByListQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    docs: {
      __typename?: 'PaginatedDocType';
      totalCount: number;
      pageInfo: {
        __typename?: 'PageInfo';
        endCursor: string | null;
        hasNextPage: boolean;
      };
      edges: Array<{
        __typename?: 'DocTypeEdge';
        node: {
          __typename?: 'DocType';
          id: string;
          creatorId: string | null;
          lastUpdaterId: string | null;
        };
      }>;
    };
  };
};

export type GetDocLastAccessedMembersQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  pagination: PaginationInput;
  query?: InputMaybe<Scalars['String']['input']>;
  includeTotal?: InputMaybe<Scalars['Boolean']['input']>;
}>;

export type GetDocLastAccessedMembersQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    doc: {
      __typename?: 'DocType';
      lastAccessedMembers: {
        __typename?: 'PaginatedDocMemberLastAccess';
        totalCount: number | null;
        pageInfo: {
          __typename?: 'PageInfo';
          hasNextPage: boolean;
          hasPreviousPage: boolean;
          startCursor: string | null;
          endCursor: string | null;
        };
        edges: Array<{
          __typename?: 'DocMemberLastAccessEdge';
          cursor: string;
          node: {
            __typename?: 'DocMemberLastAccess';
            lastAccessedAt: string;
            lastDocId: string | null;
            user: {
              __typename?: 'PublicUserType';
              id: string;
              name: string;
              avatarUrl: string | null;
            };
          };
        }>;
      };
    };
  };
};

export type GetDocPageAnalyticsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  input?: InputMaybe<DocPageAnalyticsInput>;
}>;

export type GetDocPageAnalyticsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    doc: {
      __typename?: 'DocType';
      analytics: {
        __typename?: 'DocPageAnalytics';
        generatedAt: string;
        window: {
          __typename?: 'TimeWindow';
          from: string;
          to: string;
          timezone: string;
          bucket: TimeBucket;
          requestedSize: number;
          effectiveSize: number;
        };
        series: Array<{
          __typename?: 'DocPageAnalyticsPoint';
          date: string;
          totalViews: number;
          uniqueViews: number;
          guestViews: number;
        }>;
        summary: {
          __typename?: 'DocPageAnalyticsSummary';
          totalViews: number;
          uniqueViews: number;
          guestViews: number;
          lastAccessedAt: string | null;
        };
      };
    };
  };
};

export type GetDocSummaryQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
}>;

export type GetDocSummaryQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    doc: { __typename?: 'DocType'; summary: string | null };
  };
};

export type GetInviteInfoQueryVariables = Exact<{
  inviteId: Scalars['String']['input'];
}>;

export type GetInviteInfoQuery = {
  __typename?: 'Query';
  getInviteInfo: {
    __typename?: 'InvitationType';
    status: WorkspaceMemberStatus | null;
    workspace: {
      __typename?: 'InvitationWorkspaceType';
      id: string;
      name: string;
      avatar: string;
    };
    user: {
      __typename?: 'WorkspaceUserType';
      id: string;
      name: string;
      avatarUrl: string | null;
    };
    invitee: {
      __typename?: 'WorkspaceUserType';
      id: string;
      name: string;
      email: string;
      avatarUrl: string | null;
    };
  };
};

export type GetMemberCountByWorkspaceIdQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type GetMemberCountByWorkspaceIdQuery = {
  __typename?: 'Query';
  workspace: { __typename?: 'WorkspaceType'; memberCount: number };
};

export type OauthProvidersQueryVariables = Exact<{ [key: string]: never }>;

export type OauthProvidersQuery = {
  __typename?: 'Query';
  serverConfig: {
    __typename?: 'ServerConfigType';
    oauthProviders: Array<OAuthProviderType>;
  };
};

export type GetPublicUserByIdQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type GetPublicUserByIdQuery = {
  __typename?: 'Query';
  publicUserById: {
    __typename?: 'PublicUserType';
    id: string;
    avatarUrl: string | null;
    name: string;
  } | null;
};

export type GetRecentlyUpdatedDocsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pagination: PaginationInput;
}>;

export type GetRecentlyUpdatedDocsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    recentlyUpdatedDocs: {
      __typename?: 'PaginatedDocType';
      totalCount: number;
      pageInfo: {
        __typename?: 'PageInfo';
        endCursor: string | null;
        hasNextPage: boolean;
      };
      edges: Array<{
        __typename?: 'DocTypeEdge';
        node: {
          __typename?: 'DocType';
          id: string;
          title: string | null;
          createdAt: string | null;
          updatedAt: string | null;
          creatorId: string | null;
          lastUpdaterId: string | null;
        };
      }>;
    };
  };
};

export type GetUserFeaturesQueryVariables = Exact<{ [key: string]: never }>;

export type GetUserFeaturesQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    id: string;
    features: Array<FeatureType>;
  } | null;
};

export type GetUserSettingsQueryVariables = Exact<{ [key: string]: never }>;

export type GetUserSettingsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    settings: {
      __typename?: 'UserSettingsType';
      receiveInvitationEmail: boolean;
      receiveMentionEmail: boolean;
      receiveCommentEmail: boolean;
    };
  } | null;
};

export type GetUserQueryVariables = Exact<{
  email: Scalars['String']['input'];
}>;

export type GetUserQuery = {
  __typename?: 'Query';
  user:
    | {
        __typename: 'LimitedUserType';
        email: string;
        hasPassword: boolean | null;
      }
    | {
        __typename: 'UserType';
        id: string;
        name: string;
        avatarUrl: string | null;
        email: string;
        hasPassword: boolean | null;
      }
    | null;
};

export type GetWorkspacePageByIdQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pageId: Scalars['String']['input'];
}>;

export type GetWorkspacePageByIdQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    doc: {
      __typename?: 'DocType';
      id: string;
      mode: PublicDocMode;
      defaultRole: DocRole;
      public: boolean;
      title: string | null;
      summary: string | null;
    };
  };
};

export type GetWorkspacePageMetaByIdQueryVariables = Exact<{
  id: Scalars['String']['input'];
  pageId: Scalars['String']['input'];
}>;

export type GetWorkspacePageMetaByIdQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    pageMeta: {
      __typename?: 'WorkspaceDocMeta';
      createdAt: string;
      updatedAt: string;
      createdBy: {
        __typename?: 'EditorType';
        name: string;
        avatarUrl: string | null;
      } | null;
      updatedBy: {
        __typename?: 'EditorType';
        name: string;
        avatarUrl: string | null;
      } | null;
    };
  };
};

export type GetWorkspacePublicByIdQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type GetWorkspacePublicByIdQuery = {
  __typename?: 'Query';
  workspace: { __typename?: 'WorkspaceType'; public: boolean };
};

export type GetWorkspacePublicPagesQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type GetWorkspacePublicPagesQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    publicDocs: Array<{
      __typename?: 'DocType';
      id: string;
      mode: PublicDocMode;
    }>;
  };
};

export type GetWorkspaceSubscriptionQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type GetWorkspaceSubscriptionQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    subscription: {
      __typename?: 'SubscriptionType';
      id: string | null;
      status: SubscriptionStatus;
      plan: SubscriptionPlan;
      recurring: SubscriptionRecurring;
      start: string;
      end: string | null;
      nextBillAt: string | null;
      canceledAt: string | null;
      variant: SubscriptionVariant | null;
    } | null;
  };
};

export type GetWorkspaceQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type GetWorkspaceQuery = {
  __typename?: 'Query';
  workspace: { __typename?: 'WorkspaceType'; id: string };
};

export type GetWorkspacesQueryVariables = Exact<{ [key: string]: never }>;

export type GetWorkspacesQuery = {
  __typename?: 'Query';
  workspaces: Array<{
    __typename?: 'WorkspaceType';
    id: string;
    initialized: boolean;
    team: boolean;
    owner: { __typename?: 'UserType'; id: string };
  }>;
};

export type GrantDocUserRolesMutationVariables = Exact<{
  input: GrantDocUserRolesInput;
}>;

export type GrantDocUserRolesMutation = {
  __typename?: 'Mutation';
  grantDocUserRoles: boolean;
};

export type ListHistoryQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pageDocId: Scalars['String']['input'];
  take?: InputMaybe<Scalars['Int']['input']>;
  before?: InputMaybe<Scalars['DateTime']['input']>;
}>;

export type ListHistoryQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    histories: Array<{
      __typename?: 'DocHistoryType';
      id: string;
      timestamp: string;
      editor: {
        __typename?: 'EditorType';
        name: string;
        avatarUrl: string | null;
      } | null;
    }>;
  };
};

export type IndexerAggregateQueryVariables = Exact<{
  id: Scalars['String']['input'];
  input: AggregateInput;
}>;

export type IndexerAggregateQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    aggregate: {
      __typename?: 'AggregateResultObjectType';
      buckets: Array<{
        __typename?: 'AggregateBucketObjectType';
        key: string;
        count: number;
        hits: {
          __typename?: 'AggregateBucketHitsObjectType';
          nodes: Array<{
            __typename?: 'SearchNodeObjectType';
            fields: any;
            highlights: any | null;
          }>;
        };
      }>;
      pagination: {
        __typename?: 'SearchResultPagination';
        count: number;
        hasMore: boolean;
        nextCursor: string | null;
      };
    };
  };
};

export type IndexerSearchDocsQueryVariables = Exact<{
  id: Scalars['String']['input'];
  input: SearchDocsInput;
}>;

export type IndexerSearchDocsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    searchDocs: Array<{
      __typename?: 'SearchDocObjectType';
      docId: string;
      title: string;
      blockId: string;
      highlight: string;
      createdAt: string;
      updatedAt: string;
      createdByUser: {
        __typename?: 'PublicUserType';
        id: string;
        name: string;
        avatarUrl: string | null;
      } | null;
      updatedByUser: {
        __typename?: 'PublicUserType';
        id: string;
        name: string;
        avatarUrl: string | null;
      } | null;
    }>;
  };
};

export type IndexerSearchQueryVariables = Exact<{
  id: Scalars['String']['input'];
  input: SearchInput;
}>;

export type IndexerSearchQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    search: {
      __typename?: 'SearchResultObjectType';
      nodes: Array<{
        __typename?: 'SearchNodeObjectType';
        fields: any;
        highlights: any | null;
      }>;
      pagination: {
        __typename?: 'SearchResultPagination';
        count: number;
        hasMore: boolean;
        nextCursor: string | null;
      };
    };
  };
};

export type GetInvoicesCountQueryVariables = Exact<{ [key: string]: never }>;

export type GetInvoicesCountQuery = {
  __typename?: 'Query';
  currentUser: { __typename?: 'UserType'; invoiceCount: number } | null;
};

export type InvoicesQueryVariables = Exact<{
  take: Scalars['Int']['input'];
  skip: Scalars['Int']['input'];
}>;

export type InvoicesQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    invoiceCount: number;
    invoices: Array<{
      __typename?: 'InvoiceType';
      status: InvoiceStatus;
      currency: string;
      amount: number;
      reason: string;
      lastPaymentError: string | null;
      link: string | null;
      createdAt: string;
    }>;
  } | null;
};

export type LeaveWorkspaceMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  sendLeaveMail?: InputMaybe<Scalars['Boolean']['input']>;
}>;

export type LeaveWorkspaceMutation = {
  __typename?: 'Mutation';
  leaveWorkspace: boolean;
};

export type ActivateLicenseMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  license: Scalars['String']['input'];
}>;

export type ActivateLicenseMutation = {
  __typename?: 'Mutation';
  activateLicense: {
    __typename?: 'License';
    expiredAt: string | null;
    installedAt: string;
    quantity: number;
    recurring: SubscriptionRecurring;
    validatedAt: string;
    variant: SubscriptionVariant | null;
  };
};

export type DeactivateLicenseMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type DeactivateLicenseMutation = {
  __typename?: 'Mutation';
  deactivateLicense: boolean;
};

export type GetLicenseQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type GetLicenseQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    license: {
      __typename?: 'License';
      expiredAt: string | null;
      installedAt: string;
      quantity: number;
      recurring: SubscriptionRecurring;
      validatedAt: string;
      variant: SubscriptionVariant | null;
    } | null;
  };
};

export type InstallLicenseMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  license: Scalars['Upload']['input'];
}>;

export type InstallLicenseMutation = {
  __typename?: 'Mutation';
  installLicense: {
    __typename?: 'License';
    expiredAt: string | null;
    installedAt: string;
    quantity: number;
    recurring: SubscriptionRecurring;
    validatedAt: string;
    variant: SubscriptionVariant | null;
  };
};

export type LicenseBodyFragment = {
  __typename?: 'License';
  expiredAt: string | null;
  installedAt: string;
  quantity: number;
  recurring: SubscriptionRecurring;
  validatedAt: string;
  variant: SubscriptionVariant | null;
};

export type PreviewLicenseMutationVariables = Exact<{
  license: Scalars['Upload']['input'];
}>;

export type PreviewLicenseMutation = {
  __typename?: 'Mutation';
  previewLicense: {
    __typename?: 'AdminLicensePreview';
    id: string;
    workspaceId: string;
    plan: SubscriptionPlan;
    recurring: SubscriptionRecurring;
    quantity: number;
    issuedAt: string;
    expiresAt: string;
    endAt: string;
    entity: string;
    issuer: string;
    valid: boolean;
  };
};

export type ListNotificationsQueryVariables = Exact<{
  pagination: PaginationInput;
}>;

export type ListNotificationsQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    notifications: {
      __typename?: 'PaginatedNotificationObjectType';
      totalCount: number;
      edges: Array<{
        __typename?: 'NotificationObjectTypeEdge';
        cursor: string;
        node: {
          __typename?: 'NotificationObjectType';
          id: string;
          type: NotificationType;
          level: NotificationLevel;
          read: boolean;
          createdAt: string;
          updatedAt: string;
          body: any;
        };
      }>;
      pageInfo: {
        __typename?: 'PageInfo';
        startCursor: string | null;
        endCursor: string | null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
      };
    };
  } | null;
};

export type CreateMcpCredentialMutationVariables = Exact<{
  input: CreateMcpCredentialInput;
}>;

export type CreateMcpCredentialMutation = {
  __typename?: 'Mutation';
  createMcpCredential: {
    __typename?: 'RevealedMcpCredentialType';
    token: string;
    credential: {
      __typename?: 'McpCredentialType';
      id: string;
      name: string;
      workspaceId: string;
      accessMode: McpAccessMode;
      fingerprint: string;
      createdAt: string;
      expiresAt: string;
      lastUsedAt: string | null;
      revokedAt: string | null;
      graceEndsAt: string | null;
      status: McpCredentialStatus;
    };
  };
};

export type McpCredentialsQueryVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type McpCredentialsQuery = {
  __typename?: 'Query';
  mcpCredentialReadWriteAvailable: boolean;
  mcpCredentials: Array<{
    __typename?: 'McpCredentialType';
    id: string;
    name: string;
    workspaceId: string;
    accessMode: McpAccessMode;
    fingerprint: string;
    createdAt: string;
    expiresAt: string;
    lastUsedAt: string | null;
    revokedAt: string | null;
    graceEndsAt: string | null;
    status: McpCredentialStatus;
  }>;
};

export type RevokeMcpCredentialMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
}>;

export type RevokeMcpCredentialMutation = {
  __typename?: 'Mutation';
  revokeMcpCredential: boolean;
};

export type RotateMcpCredentialMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  workspaceId: Scalars['String']['input'];
  expirationDays: Scalars['Int']['input'];
}>;

export type RotateMcpCredentialMutation = {
  __typename?: 'Mutation';
  rotateMcpCredential: {
    __typename?: 'RevealedMcpCredentialType';
    token: string;
    credential: {
      __typename?: 'McpCredentialType';
      id: string;
      name: string;
      workspaceId: string;
      accessMode: McpAccessMode;
      fingerprint: string;
      createdAt: string;
      expiresAt: string;
      lastUsedAt: string | null;
      revokedAt: string | null;
      graceEndsAt: string | null;
      status: McpCredentialStatus;
    };
  };
};

export type MentionUserMutationVariables = Exact<{
  input: MentionInput;
}>;

export type MentionUserMutation = {
  __typename?: 'Mutation';
  mentionUser: string;
};

export type PricesQueryVariables = Exact<{ [key: string]: never }>;

export type PricesQuery = {
  __typename?: 'Query';
  prices: Array<{
    __typename?: 'SubscriptionPrice';
    type: string;
    plan: SubscriptionPlan;
    currency: string;
    amount: number | null;
    yearlyAmount: number | null;
    lifetimeAmount: number | null;
  }>;
};

export type PublishPageMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pageId: Scalars['String']['input'];
  mode?: InputMaybe<PublicDocMode>;
}>;

export type PublishPageMutation = {
  __typename?: 'Mutation';
  publishDoc: { __typename?: 'DocType'; id: string; mode: PublicDocMode };
};

export type QuotaQueryVariables = Exact<{ [key: string]: never }>;

export type QuotaQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    id: string;
    quota: {
      __typename?: 'UserQuotaType';
      name: string;
      blobLimit: number;
      storageQuota: number;
      historyPeriod: number;
      memberLimit: number;
      humanReadable: {
        __typename?: 'UserQuotaHumanReadableType';
        name: string;
        blobLimit: string;
        storageQuota: string;
        historyPeriod: string;
        memberLimit: string;
      };
    };
    quotaUsage: { __typename?: 'UserQuotaUsageType'; storageQuota: number };
  } | null;
};

export type ReadAllNotificationsMutationVariables = Exact<{
  [key: string]: never;
}>;

export type ReadAllNotificationsMutation = {
  __typename?: 'Mutation';
  readAllNotifications: boolean;
};

export type ReadNotificationMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type ReadNotificationMutation = {
  __typename?: 'Mutation';
  readNotification: boolean;
};

export type RecoverDocMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  docId: Scalars['String']['input'];
  timestamp: Scalars['DateTime']['input'];
}>;

export type RecoverDocMutation = {
  __typename?: 'Mutation';
  recoverDoc: string;
};

export type RemoveAvatarMutationVariables = Exact<{ [key: string]: never }>;

export type RemoveAvatarMutation = {
  __typename?: 'Mutation';
  removeAvatar: { __typename?: 'RemoveAvatar'; success: boolean };
};

export type ResumeSubscriptionMutationVariables = Exact<{
  plan?: InputMaybe<SubscriptionPlan>;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}>;

export type ResumeSubscriptionMutation = {
  __typename?: 'Mutation';
  resumeSubscription: {
    __typename?: 'SubscriptionType';
    id: string | null;
    status: SubscriptionStatus;
    nextBillAt: string | null;
    start: string;
    end: string | null;
  };
};

export type RevokeDocUserRolesMutationVariables = Exact<{
  input: RevokeDocUserRoleInput;
}>;

export type RevokeDocUserRolesMutation = {
  __typename?: 'Mutation';
  revokeDocUserRoles: boolean;
};

export type RevokeMemberPermissionMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  userId: Scalars['String']['input'];
}>;

export type RevokeMemberPermissionMutation = {
  __typename?: 'Mutation';
  revokeMember: boolean;
};

export type RevokePublicPageMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  pageId: Scalars['String']['input'];
}>;

export type RevokePublicPageMutation = {
  __typename?: 'Mutation';
  revokePublicDoc: {
    __typename?: 'DocType';
    id: string;
    mode: PublicDocMode;
    public: boolean;
  };
};

export type SendChangeEmailMutationVariables = Exact<{
  callbackUrl: Scalars['String']['input'];
}>;

export type SendChangeEmailMutation = {
  __typename?: 'Mutation';
  sendChangeEmail: boolean;
};

export type SendChangePasswordEmailMutationVariables = Exact<{
  callbackUrl: Scalars['String']['input'];
}>;

export type SendChangePasswordEmailMutation = {
  __typename?: 'Mutation';
  sendChangePasswordEmail: boolean;
};

export type SendSetPasswordEmailMutationVariables = Exact<{
  callbackUrl: Scalars['String']['input'];
}>;

export type SendSetPasswordEmailMutation = {
  __typename?: 'Mutation';
  sendSetPasswordEmail: boolean;
};

export type SendVerifyChangeEmailMutationVariables = Exact<{
  token: Scalars['String']['input'];
  email: Scalars['String']['input'];
  callbackUrl: Scalars['String']['input'];
}>;

export type SendVerifyChangeEmailMutation = {
  __typename?: 'Mutation';
  sendVerifyChangeEmail: boolean;
};

export type SendVerifyEmailMutationVariables = Exact<{
  callbackUrl: Scalars['String']['input'];
}>;

export type SendVerifyEmailMutation = {
  __typename?: 'Mutation';
  sendVerifyEmail: boolean;
};

export type ServerConfigQueryVariables = Exact<{ [key: string]: never }>;

export type ServerConfigQuery = {
  __typename?: 'Query';
  serverConfig: {
    __typename?: 'ServerConfigType';
    version: string;
    baseUrl: string;
    name: string;
    features: Array<ServerFeature>;
    type: ServerDeploymentType;
    initialized: boolean;
    calendarProviders: Array<CalendarProviderType>;
    credentialsRequirement: {
      __typename?: 'CredentialsRequirementType';
      password: {
        __typename?: 'PasswordLimitsType';
        minLength: number;
        maxLength: number;
      };
    };
  };
};

export type SetWorkspacePublicByIdMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  public: Scalars['Boolean']['input'];
}>;

export type SetWorkspacePublicByIdMutation = {
  __typename?: 'Mutation';
  updateWorkspace: { __typename?: 'WorkspaceType'; id: string };
};

export type RefreshSubscriptionMutationVariables = Exact<{
  [key: string]: never;
}>;

export type RefreshSubscriptionMutation = {
  __typename?: 'Mutation';
  refreshUserSubscriptions: Array<{
    __typename?: 'SubscriptionType';
    id: string | null;
    status: SubscriptionStatus;
    plan: SubscriptionPlan;
    recurring: SubscriptionRecurring;
    start: string;
    end: string | null;
    nextBillAt: string | null;
    canceledAt: string | null;
    variant: SubscriptionVariant | null;
  }>;
};

export type RequestApplySubscriptionMutationVariables = Exact<{
  transactionId: Scalars['String']['input'];
}>;

export type RequestApplySubscriptionMutation = {
  __typename?: 'Mutation';
  requestApplySubscription: Array<{
    __typename?: 'SubscriptionType';
    id: string | null;
    status: SubscriptionStatus;
    plan: SubscriptionPlan;
    recurring: SubscriptionRecurring;
    start: string;
    end: string | null;
    nextBillAt: string | null;
    canceledAt: string | null;
    variant: SubscriptionVariant | null;
  }>;
};

export type SubscriptionQueryVariables = Exact<{ [key: string]: never }>;

export type SubscriptionQuery = {
  __typename?: 'Query';
  currentUser: {
    __typename?: 'UserType';
    id: string;
    subscriptions: Array<{
      __typename?: 'SubscriptionType';
      id: string | null;
      status: SubscriptionStatus;
      plan: SubscriptionPlan;
      recurring: SubscriptionRecurring;
      start: string;
      end: string | null;
      nextBillAt: string | null;
      canceledAt: string | null;
      variant: SubscriptionVariant | null;
    }>;
  } | null;
};

export type UpdateDocDefaultRoleMutationVariables = Exact<{
  input: UpdateDocDefaultRoleInput;
}>;

export type UpdateDocDefaultRoleMutation = {
  __typename?: 'Mutation';
  updateDocDefaultRole: boolean;
};

export type UpdateDocUserRoleMutationVariables = Exact<{
  input: UpdateDocUserRoleInput;
}>;

export type UpdateDocUserRoleMutation = {
  __typename?: 'Mutation';
  updateDocUserRole: boolean;
};

export type UpdateSubscriptionMutationVariables = Exact<{
  plan?: InputMaybe<SubscriptionPlan>;
  recurring: SubscriptionRecurring;
  workspaceId?: InputMaybe<Scalars['String']['input']>;
}>;

export type UpdateSubscriptionMutation = {
  __typename?: 'Mutation';
  updateSubscriptionRecurring: {
    __typename?: 'SubscriptionType';
    id: string | null;
    plan: SubscriptionPlan;
    recurring: SubscriptionRecurring;
    nextBillAt: string | null;
  };
};

export type UpdateUserProfileMutationVariables = Exact<{
  input: UpdateUserInput;
}>;

export type UpdateUserProfileMutation = {
  __typename?: 'Mutation';
  updateProfile: { __typename?: 'UserType'; id: string; name: string };
};

export type UpdateUserSettingsMutationVariables = Exact<{
  input: UpdateUserSettingsInput;
}>;

export type UpdateUserSettingsMutation = {
  __typename?: 'Mutation';
  updateSettings: boolean;
};

export type UploadAvatarMutationVariables = Exact<{
  avatar: Scalars['Upload']['input'];
}>;

export type UploadAvatarMutation = {
  __typename?: 'Mutation';
  uploadAvatar: {
    __typename?: 'UserType';
    id: string;
    name: string;
    avatarUrl: string | null;
    email: string;
  };
};

export type VerifyEmailMutationVariables = Exact<{
  token: Scalars['String']['input'];
}>;

export type VerifyEmailMutation = {
  __typename?: 'Mutation';
  verifyEmail: boolean;
};

export type WorkspaceBlobQuotaQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type WorkspaceBlobQuotaQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    quota: {
      __typename?: 'WorkspaceQuotaType';
      blobLimit: number;
      humanReadable: {
        __typename?: 'WorkspaceQuotaHumanReadableType';
        blobLimit: string;
      };
    };
  };
};

export type DeleteWorkspaceByokProfileMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  profileId: Scalars['ID']['input'];
}>;

export type DeleteWorkspaceByokProfileMutation = {
  __typename?: 'Mutation';
  deleteWorkspaceByokProfile: boolean;
};

export type ProbeWorkspaceByokProfileMutationVariables = Exact<{
  input: ProbeWorkspaceByokProfileInput;
}>;

export type ProbeWorkspaceByokProfileMutation = {
  __typename?: 'Mutation';
  probeWorkspaceByokProfile: {
    __typename?: 'WorkspaceByokProbeResultType';
    definitionFingerprint: string;
    stale: boolean;
    connection: {
      __typename?: 'WorkspaceByokProbeStatusType';
      kind: ByokProbeStatusKind;
      testedAt: string | null;
      errorKind: string | null;
    };
    models: Array<{
      __typename?: 'WorkspaceByokModelProbeType';
      modelId: string;
      checks: Array<{
        __typename?: 'WorkspaceByokModelProbeCheckType';
        operation: ByokProbeOperation;
        status: {
          __typename?: 'WorkspaceByokProbeStatusType';
          kind: ByokProbeStatusKind;
          testedAt: string | null;
          errorKind: string | null;
        };
      }>;
    }>;
  };
};

export type ProbeWorkspaceByokDraftMutationVariables = Exact<{
  input: ProbeWorkspaceByokDraftInput;
}>;

export type ProbeWorkspaceByokDraftMutation = {
  __typename?: 'Mutation';
  probeWorkspaceByokDraft: {
    __typename?: 'WorkspaceByokProbeResultType';
    definitionFingerprint: string;
    stale: boolean;
    connection: {
      __typename?: 'WorkspaceByokProbeStatusType';
      kind: ByokProbeStatusKind;
      testedAt: string | null;
      errorKind: string | null;
    };
    models: Array<{
      __typename?: 'WorkspaceByokModelProbeType';
      modelId: string;
      checks: Array<{
        __typename?: 'WorkspaceByokModelProbeCheckType';
        operation: ByokProbeOperation;
        status: {
          __typename?: 'WorkspaceByokProbeStatusType';
          kind: ByokProbeStatusKind;
          testedAt: string | null;
          errorKind: string | null;
        };
      }>;
    }>;
  };
};

export type CreateWorkspaceByokProfileMutationVariables = Exact<{
  input: CreateWorkspaceByokProfileInput;
}>;

export type CreateWorkspaceByokProfileMutation = {
  __typename?: 'Mutation';
  createWorkspaceByokProfile: {
    __typename?: 'WorkspaceByokProfileType';
    profileId: string;
  };
};

export type ReplaceWorkspaceByokProfileMutationVariables = Exact<{
  input: ReplaceWorkspaceByokProfileInput;
}>;

export type ReplaceWorkspaceByokProfileMutation = {
  __typename?: 'Mutation';
  replaceWorkspaceByokProfile: {
    __typename?: 'WorkspaceByokProfileType';
    profileId: string;
  };
};

export type RotateWorkspaceByokCredentialMutationVariables = Exact<{
  input: RotateWorkspaceByokCredentialInput;
}>;

export type RotateWorkspaceByokCredentialMutation = {
  __typename?: 'Mutation';
  rotateWorkspaceByokCredential: {
    __typename?: 'WorkspaceByokProfileType';
    profileId: string;
  };
};

export type CreateWorkspaceByokLocalLeaseMutationVariables = Exact<{
  input: CreateWorkspaceByokLocalLeaseInput;
}>;

export type CreateWorkspaceByokLocalLeaseMutation = {
  __typename?: 'Mutation';
  createWorkspaceByokLocalLease: {
    __typename?: 'CreateWorkspaceByokLocalLeaseResultType';
    leaseId: string;
    expiresAt: string;
  };
};

export type ReorderWorkspaceByokProfilesMutationVariables = Exact<{
  input: ReorderWorkspaceByokProfilesInput;
}>;

export type ReorderWorkspaceByokProfilesMutation = {
  __typename?: 'Mutation';
  reorderWorkspaceByokProfiles: Array<{
    __typename?: 'WorkspaceByokProfileType';
    profileId: string;
    sortOrder: number;
    revision: number;
  }>;
};

export type WorkspaceByokSettingsQueryVariables = Exact<{
  id: Scalars['String']['input'];
  from: Scalars['DateTime']['input'];
  to: Scalars['DateTime']['input'];
}>;

export type WorkspaceByokSettingsQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    id: string;
    byokSettings: {
      __typename?: 'WorkspaceByokSettingsType';
      workspaceId: string;
      entitled: boolean;
      serverEntitled: boolean;
      localEntitled: boolean;
      policy: {
        __typename?: 'WorkspaceByokPolicyType';
        enabled: boolean;
        allowedProviders: Array<ByokProvider>;
        customEndpointMode: ByokCustomEndpointMode;
        privateEndpointSupported: boolean;
      };
      catalog: {
        __typename?: 'WorkspaceByokCatalogType';
        version: string;
        providers: Array<{
          __typename?: 'WorkspaceByokCatalogProviderType';
          provider: ByokProvider;
          models: Array<{
            __typename?: 'WorkspaceByokCatalogModelType';
            modelId: string;
            displayName: string;
            recommended: boolean;
            capabilities: Array<{
              __typename?: 'WorkspaceByokCapabilityType';
              input: Array<ByokModelInput>;
              output: Array<ByokModelOutput>;
              features: Array<ByokModelFeature>;
              attachmentKinds: Array<ByokAttachmentKind>;
              attachmentSources: Array<ByokAttachmentSource>;
            }>;
          }>;
        }>;
      };
      profiles: Array<{
        __typename?: 'WorkspaceByokProfileType';
        profileId: string;
        provider: ByokProvider;
        name: string;
        description: string | null;
        enabled: boolean;
        sortOrder: number;
        revision: number;
        definition: {
          __typename?: 'WorkspaceByokProfileDefinitionType';
          endpoint: {
            __typename?: 'WorkspaceByokEndpointType';
            kind: ByokEndpointKind;
            url: string | null;
            dialect: ByokOpenAiDialect | null;
          };
          models: Array<{
            __typename?: 'WorkspaceByokModelDeclarationType';
            modelId: string;
            enabled: boolean;
            capabilities: Array<{
              __typename?: 'WorkspaceByokCapabilityType';
              input: Array<ByokModelInput>;
              output: Array<ByokModelOutput>;
              features: Array<ByokModelFeature>;
              attachmentKinds: Array<ByokAttachmentKind>;
              attachmentSources: Array<ByokAttachmentSource>;
            }>;
          }>;
        };
        validation: {
          __typename?: 'WorkspaceByokValidationType';
          definitionFingerprint: string;
          credentialGeneration: number;
          connection: {
            __typename?: 'WorkspaceByokProbeStatusType';
            kind: ByokProbeStatusKind;
            testedAt: string | null;
            errorKind: string | null;
          };
          models: Array<{
            __typename?: 'WorkspaceByokModelProbeType';
            modelId: string;
            checks: Array<{
              __typename?: 'WorkspaceByokModelProbeCheckType';
              operation: ByokProbeOperation;
              status: {
                __typename?: 'WorkspaceByokProbeStatusType';
                kind: ByokProbeStatusKind;
                testedAt: string | null;
                errorKind: string | null;
              };
            }>;
          }>;
        } | null;
      }>;
    };
    byokUsage: Array<{
      __typename?: 'WorkspaceByokUsagePointType';
      date: string;
      featureKind: string;
      totalTokens: number;
    }>;
  };
};

export type SetEnableAiMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  enableAi: Scalars['Boolean']['input'];
}>;

export type SetEnableAiMutation = {
  __typename?: 'Mutation';
  updateWorkspace: { __typename?: 'WorkspaceType'; id: string };
};

export type SetEnableDocEmbeddingMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  enableDocEmbedding: Scalars['Boolean']['input'];
}>;

export type SetEnableDocEmbeddingMutation = {
  __typename?: 'Mutation';
  updateWorkspace: { __typename?: 'WorkspaceType'; id: string };
};

export type SetEnableSharingMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  enableSharing: Scalars['Boolean']['input'];
}>;

export type SetEnableSharingMutation = {
  __typename?: 'Mutation';
  updateWorkspace: { __typename?: 'WorkspaceType'; id: string };
};

export type SetEnableUrlPreviewMutationVariables = Exact<{
  id: Scalars['ID']['input'];
  enableUrlPreview: Scalars['Boolean']['input'];
}>;

export type SetEnableUrlPreviewMutation = {
  __typename?: 'Mutation';
  updateWorkspace: { __typename?: 'WorkspaceType'; id: string };
};

export type InviteByEmailsMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  emails: Array<Scalars['String']['input']> | Scalars['String']['input'];
}>;

export type InviteByEmailsMutation = {
  __typename?: 'Mutation';
  inviteMembers: Array<{
    __typename?: 'InviteResult';
    email: string;
    inviteId: string | null;
  }>;
};

export type AcceptInviteByInviteIdMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  inviteId: Scalars['String']['input'];
}>;

export type AcceptInviteByInviteIdMutation = {
  __typename?: 'Mutation';
  acceptInviteById: boolean;
};

export type CreateInviteLinkMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  expireTime: WorkspaceInviteLinkExpireTime;
}>;

export type CreateInviteLinkMutation = {
  __typename?: 'Mutation';
  createInviteLink: {
    __typename?: 'InviteLink';
    link: string;
    expireTime: string;
  };
};

export type RevokeInviteLinkMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
}>;

export type RevokeInviteLinkMutation = {
  __typename?: 'Mutation';
  revokeInviteLink: boolean;
};

export type WorkspaceInvoicesQueryVariables = Exact<{
  take: Scalars['Int']['input'];
  skip: Scalars['Int']['input'];
  workspaceId: Scalars['String']['input'];
}>;

export type WorkspaceInvoicesQuery = {
  __typename?: 'Query';
  workspace: {
    __typename?: 'WorkspaceType';
    invoiceCount: number;
    invoices: Array<{
      __typename?: 'InvoiceType';
      status: InvoiceStatus;
      currency: string;
      amount: number;
      reason: string;
      lastPaymentError: string | null;
      link: string | null;
      createdAt: string;
    }>;
  };
};

export type GetWorkspaceRolePermissionsQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type GetWorkspaceRolePermissionsQuery = {
  __typename?: 'Query';
  workspaceRolePermissions: {
    __typename?: 'WorkspaceRolePermissions';
    permissions: {
      __typename?: 'WorkspacePermissions';
      Workspace_Administrators_Manage: boolean;
      Workspace_Blobs_List: boolean;
      Workspace_Blobs_Read: boolean;
      Workspace_Blobs_Write: boolean;
      Workspace_Copilot: boolean;
      Workspace_CreateDoc: boolean;
      Workspace_Delete: boolean;
      Workspace_Organize_Read: boolean;
      Workspace_Payment_Manage: boolean;
      Workspace_Properties_Create: boolean;
      Workspace_Properties_Delete: boolean;
      Workspace_Properties_Read: boolean;
      Workspace_Properties_Update: boolean;
      Workspace_Read: boolean;
      Workspace_Settings_Read: boolean;
      Workspace_Settings_Update: boolean;
      Workspace_Sync: boolean;
      Workspace_TransferOwner: boolean;
      Workspace_Users_Manage: boolean;
      Workspace_Users_Read: boolean;
    };
  };
};

export type ApproveWorkspaceTeamMemberMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  userId: Scalars['String']['input'];
}>;

export type ApproveWorkspaceTeamMemberMutation = {
  __typename?: 'Mutation';
  approveMember: boolean;
};

export type GrantWorkspaceTeamMemberMutationVariables = Exact<{
  workspaceId: Scalars['String']['input'];
  userId: Scalars['String']['input'];
  permission: Permission;
}>;

export type GrantWorkspaceTeamMemberMutation = {
  __typename?: 'Mutation';
  grantMember: boolean;
};

export type Queries =
  | {
      name: 'adminAllSharedLinksQuery';
      variables: AdminAllSharedLinksQueryVariables;
      response: AdminAllSharedLinksQuery;
    }
  | {
      name: 'adminDashboardQuery';
      variables: AdminDashboardQueryVariables;
      response: AdminDashboardQuery;
    }
  | {
      name: 'adminMailDeliveriesQuery';
      variables: AdminMailDeliveriesQueryVariables;
      response: AdminMailDeliveriesQuery;
    }
  | {
      name: 'adminServerConfigQuery';
      variables: AdminServerConfigQueryVariables;
      response: AdminServerConfigQuery;
    }
  | {
      name: 'adminWorkspaceQuery';
      variables: AdminWorkspaceQueryVariables;
      response: AdminWorkspaceQuery;
    }
  | {
      name: 'adminWorkspacesQuery';
      variables: AdminWorkspacesQueryVariables;
      response: AdminWorkspacesQuery;
    }
  | {
      name: 'adminWorkspacesCountQuery';
      variables: AdminWorkspacesCountQueryVariables;
      response: AdminWorkspacesCountQuery;
    }
  | {
      name: 'authSigningKeysQuery';
      variables: AuthSigningKeysQueryVariables;
      response: AuthSigningKeysQuery;
    }
  | {
      name: 'appConfigQuery';
      variables: AppConfigQueryVariables;
      response: AppConfigQuery;
    }
  | {
      name: 'getUserByEmailQuery';
      variables: GetUserByEmailQueryVariables;
      response: GetUserByEmailQuery;
    }
  | {
      name: 'listUsersQuery';
      variables: ListUsersQueryVariables;
      response: ListUsersQuery;
    }
  | {
      name: 'validateConfigQuery';
      variables: ValidateConfigQueryVariables;
      response: ValidateConfigQuery;
    }
  | {
      name: 'listBlobsQuery';
      variables: ListBlobsQueryVariables;
      response: ListBlobsQuery;
    }
  | {
      name: 'getBlobUploadPartUrlQuery';
      variables: GetBlobUploadPartUrlQueryVariables;
      response: GetBlobUploadPartUrlQuery;
    }
  | {
      name: 'calendarAccountsQuery';
      variables: CalendarAccountsQueryVariables;
      response: CalendarAccountsQuery;
    }
  | {
      name: 'calendarEventsQuery';
      variables: CalendarEventsQueryVariables;
      response: CalendarEventsQuery;
    }
  | {
      name: 'calendarProvidersQuery';
      variables: CalendarProvidersQueryVariables;
      response: CalendarProvidersQuery;
    }
  | {
      name: 'workspaceCalendarsQuery';
      variables: WorkspaceCalendarsQueryVariables;
      response: WorkspaceCalendarsQuery;
    }
  | {
      name: 'listCommentChangesQuery';
      variables: ListCommentChangesQueryVariables;
      response: ListCommentChangesQuery;
    }
  | {
      name: 'listCommentsQuery';
      variables: ListCommentsQueryVariables;
      response: ListCommentsQuery;
    }
  | {
      name: 'getCopilotHistoryIdsQuery';
      variables: GetCopilotHistoryIdsQueryVariables;
      response: GetCopilotHistoryIdsQuery;
    }
  | {
      name: 'getCopilotDocSessionsQuery';
      variables: GetCopilotDocSessionsQueryVariables;
      response: GetCopilotDocSessionsQuery;
    }
  | {
      name: 'getCopilotPinnedSessionsQuery';
      variables: GetCopilotPinnedSessionsQueryVariables;
      response: GetCopilotPinnedSessionsQuery;
    }
  | {
      name: 'getCopilotWorkspaceSessionsQuery';
      variables: GetCopilotWorkspaceSessionsQueryVariables;
      response: GetCopilotWorkspaceSessionsQuery;
    }
  | {
      name: 'getCopilotHistoriesQuery';
      variables: GetCopilotHistoriesQueryVariables;
      response: GetCopilotHistoriesQuery;
    }
  | {
      name: 'copilotQuotaQuery';
      variables: CopilotQuotaQueryVariables;
      response: CopilotQuotaQuery;
    }
  | {
      name: 'getCopilotRouteOptionsQuery';
      variables: GetCopilotRouteOptionsQueryVariables;
      response: GetCopilotRouteOptionsQuery;
    }
  | {
      name: 'getCopilotLatestDocSessionQuery';
      variables: GetCopilotLatestDocSessionQueryVariables;
      response: GetCopilotLatestDocSessionQuery;
    }
  | {
      name: 'getCopilotSessionQuery';
      variables: GetCopilotSessionQueryVariables;
      response: GetCopilotSessionQuery;
    }
  | {
      name: 'getCopilotRecentSessionsQuery';
      variables: GetCopilotRecentSessionsQueryVariables;
      response: GetCopilotRecentSessionsQuery;
    }
  | {
      name: 'getCopilotSessionsQuery';
      variables: GetCopilotSessionsQueryVariables;
      response: GetCopilotSessionsQuery;
    }
  | {
      name: 'getTranscriptTaskQuery';
      variables: GetTranscriptTaskQueryVariables;
      response: GetTranscriptTaskQuery;
    }
  | {
      name: 'getWorkspaceArtifactsQuery';
      variables: GetWorkspaceArtifactsQueryVariables;
      response: GetWorkspaceArtifactsQuery;
    }
  | {
      name: 'getAllWorkspaceEmbeddingIgnoredDocsQuery';
      variables: GetAllWorkspaceEmbeddingIgnoredDocsQueryVariables;
      response: GetAllWorkspaceEmbeddingIgnoredDocsQuery;
    }
  | {
      name: 'getWorkspaceEmbeddingIgnoredDocsQuery';
      variables: GetWorkspaceEmbeddingIgnoredDocsQueryVariables;
      response: GetWorkspaceEmbeddingIgnoredDocsQuery;
    }
  | {
      name: 'getDocRolePermissionsQuery';
      variables: GetDocRolePermissionsQueryVariables;
      response: GetDocRolePermissionsQuery;
    }
  | {
      name: 'getCurrentUserFeaturesQuery';
      variables: GetCurrentUserFeaturesQueryVariables;
      response: GetCurrentUserFeaturesQuery;
    }
  | {
      name: 'getCurrentUserQuery';
      variables: GetCurrentUserQueryVariables;
      response: GetCurrentUserQuery;
    }
  | {
      name: 'getDocCreatedByUpdatedByListQuery';
      variables: GetDocCreatedByUpdatedByListQueryVariables;
      response: GetDocCreatedByUpdatedByListQuery;
    }
  | {
      name: 'getDocLastAccessedMembersQuery';
      variables: GetDocLastAccessedMembersQueryVariables;
      response: GetDocLastAccessedMembersQuery;
    }
  | {
      name: 'getDocPageAnalyticsQuery';
      variables: GetDocPageAnalyticsQueryVariables;
      response: GetDocPageAnalyticsQuery;
    }
  | {
      name: 'getDocSummaryQuery';
      variables: GetDocSummaryQueryVariables;
      response: GetDocSummaryQuery;
    }
  | {
      name: 'getInviteInfoQuery';
      variables: GetInviteInfoQueryVariables;
      response: GetInviteInfoQuery;
    }
  | {
      name: 'getMemberCountByWorkspaceIdQuery';
      variables: GetMemberCountByWorkspaceIdQueryVariables;
      response: GetMemberCountByWorkspaceIdQuery;
    }
  | {
      name: 'oauthProvidersQuery';
      variables: OauthProvidersQueryVariables;
      response: OauthProvidersQuery;
    }
  | {
      name: 'getPublicUserByIdQuery';
      variables: GetPublicUserByIdQueryVariables;
      response: GetPublicUserByIdQuery;
    }
  | {
      name: 'getRecentlyUpdatedDocsQuery';
      variables: GetRecentlyUpdatedDocsQueryVariables;
      response: GetRecentlyUpdatedDocsQuery;
    }
  | {
      name: 'getUserFeaturesQuery';
      variables: GetUserFeaturesQueryVariables;
      response: GetUserFeaturesQuery;
    }
  | {
      name: 'getUserSettingsQuery';
      variables: GetUserSettingsQueryVariables;
      response: GetUserSettingsQuery;
    }
  | {
      name: 'getUserQuery';
      variables: GetUserQueryVariables;
      response: GetUserQuery;
    }
  | {
      name: 'getWorkspacePageByIdQuery';
      variables: GetWorkspacePageByIdQueryVariables;
      response: GetWorkspacePageByIdQuery;
    }
  | {
      name: 'getWorkspacePageMetaByIdQuery';
      variables: GetWorkspacePageMetaByIdQueryVariables;
      response: GetWorkspacePageMetaByIdQuery;
    }
  | {
      name: 'getWorkspacePublicByIdQuery';
      variables: GetWorkspacePublicByIdQueryVariables;
      response: GetWorkspacePublicByIdQuery;
    }
  | {
      name: 'getWorkspacePublicPagesQuery';
      variables: GetWorkspacePublicPagesQueryVariables;
      response: GetWorkspacePublicPagesQuery;
    }
  | {
      name: 'getWorkspaceSubscriptionQuery';
      variables: GetWorkspaceSubscriptionQueryVariables;
      response: GetWorkspaceSubscriptionQuery;
    }
  | {
      name: 'getWorkspaceQuery';
      variables: GetWorkspaceQueryVariables;
      response: GetWorkspaceQuery;
    }
  | {
      name: 'getWorkspacesQuery';
      variables: GetWorkspacesQueryVariables;
      response: GetWorkspacesQuery;
    }
  | {
      name: 'listHistoryQuery';
      variables: ListHistoryQueryVariables;
      response: ListHistoryQuery;
    }
  | {
      name: 'indexerAggregateQuery';
      variables: IndexerAggregateQueryVariables;
      response: IndexerAggregateQuery;
    }
  | {
      name: 'indexerSearchDocsQuery';
      variables: IndexerSearchDocsQueryVariables;
      response: IndexerSearchDocsQuery;
    }
  | {
      name: 'indexerSearchQuery';
      variables: IndexerSearchQueryVariables;
      response: IndexerSearchQuery;
    }
  | {
      name: 'getInvoicesCountQuery';
      variables: GetInvoicesCountQueryVariables;
      response: GetInvoicesCountQuery;
    }
  | {
      name: 'invoicesQuery';
      variables: InvoicesQueryVariables;
      response: InvoicesQuery;
    }
  | {
      name: 'getLicenseQuery';
      variables: GetLicenseQueryVariables;
      response: GetLicenseQuery;
    }
  | {
      name: 'listNotificationsQuery';
      variables: ListNotificationsQueryVariables;
      response: ListNotificationsQuery;
    }
  | {
      name: 'mcpCredentialsQuery';
      variables: McpCredentialsQueryVariables;
      response: McpCredentialsQuery;
    }
  | {
      name: 'pricesQuery';
      variables: PricesQueryVariables;
      response: PricesQuery;
    }
  | {
      name: 'quotaQuery';
      variables: QuotaQueryVariables;
      response: QuotaQuery;
    }
  | {
      name: 'serverConfigQuery';
      variables: ServerConfigQueryVariables;
      response: ServerConfigQuery;
    }
  | {
      name: 'subscriptionQuery';
      variables: SubscriptionQueryVariables;
      response: SubscriptionQuery;
    }
  | {
      name: 'workspaceBlobQuotaQuery';
      variables: WorkspaceBlobQuotaQueryVariables;
      response: WorkspaceBlobQuotaQuery;
    }
  | {
      name: 'workspaceByokSettingsQuery';
      variables: WorkspaceByokSettingsQueryVariables;
      response: WorkspaceByokSettingsQuery;
    }
  | {
      name: 'workspaceInvoicesQuery';
      variables: WorkspaceInvoicesQueryVariables;
      response: WorkspaceInvoicesQuery;
    }
  | {
      name: 'getWorkspaceRolePermissionsQuery';
      variables: GetWorkspaceRolePermissionsQueryVariables;
      response: GetWorkspaceRolePermissionsQuery;
    };

export type Mutations =
  | {
      name: 'adminUpdateWorkspaceMutation';
      variables: AdminUpdateWorkspaceMutationVariables;
      response: AdminUpdateWorkspaceMutation;
    }
  | {
      name: 'createChangePasswordUrlMutation';
      variables: CreateChangePasswordUrlMutationVariables;
      response: CreateChangePasswordUrlMutation;
    }
  | {
      name: 'createUserMutation';
      variables: CreateUserMutationVariables;
      response: CreateUserMutation;
    }
  | {
      name: 'deleteAuthSigningKeyMutation';
      variables: DeleteAuthSigningKeyMutationVariables;
      response: DeleteAuthSigningKeyMutation;
    }
  | {
      name: 'deleteUserMutation';
      variables: DeleteUserMutationVariables;
      response: DeleteUserMutation;
    }
  | {
      name: 'disableUserMutation';
      variables: DisableUserMutationVariables;
      response: DisableUserMutation;
    }
  | {
      name: 'enableUserMutation';
      variables: EnableUserMutationVariables;
      response: EnableUserMutation;
    }
  | {
      name: 'importUsersMutation';
      variables: ImportUsersMutationVariables;
      response: ImportUsersMutation;
    }
  | {
      name: 'rotateAuthSigningKeyMutation';
      variables: RotateAuthSigningKeyMutationVariables;
      response: RotateAuthSigningKeyMutation;
    }
  | {
      name: 'sendTestEmailMutation';
      variables: SendTestEmailMutationVariables;
      response: SendTestEmailMutation;
    }
  | {
      name: 'updateAccountFeaturesMutation';
      variables: UpdateAccountFeaturesMutationVariables;
      response: UpdateAccountFeaturesMutation;
    }
  | {
      name: 'updateAccountMutation';
      variables: UpdateAccountMutationVariables;
      response: UpdateAccountMutation;
    }
  | {
      name: 'updateAppConfigMutation';
      variables: UpdateAppConfigMutationVariables;
      response: UpdateAppConfigMutation;
    }
  | {
      name: 'deleteBlobMutation';
      variables: DeleteBlobMutationVariables;
      response: DeleteBlobMutation;
    }
  | {
      name: 'releaseDeletedBlobsMutation';
      variables: ReleaseDeletedBlobsMutationVariables;
      response: ReleaseDeletedBlobsMutation;
    }
  | {
      name: 'setBlobMutation';
      variables: SetBlobMutationVariables;
      response: SetBlobMutation;
    }
  | {
      name: 'abortBlobUploadMutation';
      variables: AbortBlobUploadMutationVariables;
      response: AbortBlobUploadMutation;
    }
  | {
      name: 'completeBlobUploadMutation';
      variables: CompleteBlobUploadMutationVariables;
      response: CompleteBlobUploadMutation;
    }
  | {
      name: 'createBlobUploadMutation';
      variables: CreateBlobUploadMutationVariables;
      response: CreateBlobUploadMutation;
    }
  | {
      name: 'linkCalDavAccountMutation';
      variables: LinkCalDavAccountMutationVariables;
      response: LinkCalDavAccountMutation;
    }
  | {
      name: 'linkCalendarAccountMutation';
      variables: LinkCalendarAccountMutationVariables;
      response: LinkCalendarAccountMutation;
    }
  | {
      name: 'unlinkCalendarAccountMutation';
      variables: UnlinkCalendarAccountMutationVariables;
      response: UnlinkCalendarAccountMutation;
    }
  | {
      name: 'updateCalendarAccountMutation';
      variables: UpdateCalendarAccountMutationVariables;
      response: UpdateCalendarAccountMutation;
    }
  | {
      name: 'updateWorkspaceCalendarsMutation';
      variables: UpdateWorkspaceCalendarsMutationVariables;
      response: UpdateWorkspaceCalendarsMutation;
    }
  | {
      name: 'cancelSubscriptionMutation';
      variables: CancelSubscriptionMutationVariables;
      response: CancelSubscriptionMutation;
    }
  | {
      name: 'changeEmailMutation';
      variables: ChangeEmailMutationVariables;
      response: ChangeEmailMutation;
    }
  | {
      name: 'changePasswordMutation';
      variables: ChangePasswordMutationVariables;
      response: ChangePasswordMutation;
    }
  | {
      name: 'createCommentMutation';
      variables: CreateCommentMutationVariables;
      response: CreateCommentMutation;
    }
  | {
      name: 'deleteCommentMutation';
      variables: DeleteCommentMutationVariables;
      response: DeleteCommentMutation;
    }
  | {
      name: 'createReplyMutation';
      variables: CreateReplyMutationVariables;
      response: CreateReplyMutation;
    }
  | {
      name: 'deleteReplyMutation';
      variables: DeleteReplyMutationVariables;
      response: DeleteReplyMutation;
    }
  | {
      name: 'updateReplyMutation';
      variables: UpdateReplyMutationVariables;
      response: UpdateReplyMutation;
    }
  | {
      name: 'resolveCommentMutation';
      variables: ResolveCommentMutationVariables;
      response: ResolveCommentMutation;
    }
  | {
      name: 'updateCommentMutation';
      variables: UpdateCommentMutationVariables;
      response: UpdateCommentMutation;
    }
  | {
      name: 'uploadCommentAttachmentMutation';
      variables: UploadCommentAttachmentMutationVariables;
      response: UploadCommentAttachmentMutation;
    }
  | {
      name: 'createCopilotMessageMutation';
      variables: CreateCopilotMessageMutationVariables;
      response: CreateCopilotMessageMutation;
    }
  | {
      name: 'cleanupCopilotSessionMutation';
      variables: CleanupCopilotSessionMutationVariables;
      response: CleanupCopilotSessionMutation;
    }
  | {
      name: 'createCopilotSessionWithHistoryMutation';
      variables: CreateCopilotSessionWithHistoryMutationVariables;
      response: CreateCopilotSessionWithHistoryMutation;
    }
  | {
      name: 'createCopilotSessionMutation';
      variables: CreateCopilotSessionMutationVariables;
      response: CreateCopilotSessionMutation;
    }
  | {
      name: 'forkCopilotSessionMutation';
      variables: ForkCopilotSessionMutationVariables;
      response: ForkCopilotSessionMutation;
    }
  | {
      name: 'updateCopilotSessionMutation';
      variables: UpdateCopilotSessionMutationVariables;
      response: UpdateCopilotSessionMutation;
    }
  | {
      name: 'retryTranscriptTaskMutation';
      variables: RetryTranscriptTaskMutationVariables;
      response: RetryTranscriptTaskMutation;
    }
  | {
      name: 'settleTranscriptTaskMutation';
      variables: SettleTranscriptTaskMutationVariables;
      response: SettleTranscriptTaskMutation;
    }
  | {
      name: 'submitTranscriptTaskMutation';
      variables: SubmitTranscriptTaskMutationVariables;
      response: SubmitTranscriptTaskMutation;
    }
  | {
      name: 'addWorkspaceArtifactMutation';
      variables: AddWorkspaceArtifactMutationVariables;
      response: AddWorkspaceArtifactMutation;
    }
  | {
      name: 'removeWorkspaceArtifactMutation';
      variables: RemoveWorkspaceArtifactMutationVariables;
      response: RemoveWorkspaceArtifactMutation;
    }
  | {
      name: 'addWorkspaceEmbeddingIgnoredDocsMutation';
      variables: AddWorkspaceEmbeddingIgnoredDocsMutationVariables;
      response: AddWorkspaceEmbeddingIgnoredDocsMutation;
    }
  | {
      name: 'removeWorkspaceEmbeddingIgnoredDocsMutation';
      variables: RemoveWorkspaceEmbeddingIgnoredDocsMutationVariables;
      response: RemoveWorkspaceEmbeddingIgnoredDocsMutation;
    }
  | {
      name: 'createCheckoutSessionMutation';
      variables: CreateCheckoutSessionMutationVariables;
      response: CreateCheckoutSessionMutation;
    }
  | {
      name: 'createCustomerPortalMutation';
      variables: CreateCustomerPortalMutationVariables;
      response: CreateCustomerPortalMutation;
    }
  | {
      name: 'createSelfhostCustomerPortalMutation';
      variables: CreateSelfhostCustomerPortalMutationVariables;
      response: CreateSelfhostCustomerPortalMutation;
    }
  | {
      name: 'createWorkspaceMutation';
      variables: CreateWorkspaceMutationVariables;
      response: CreateWorkspaceMutation;
    }
  | {
      name: 'deleteAccountMutation';
      variables: DeleteAccountMutationVariables;
      response: DeleteAccountMutation;
    }
  | {
      name: 'deleteWorkspaceMutation';
      variables: DeleteWorkspaceMutationVariables;
      response: DeleteWorkspaceMutation;
    }
  | {
      name: 'generateLicenseKeyMutation';
      variables: GenerateLicenseKeyMutationVariables;
      response: GenerateLicenseKeyMutation;
    }
  | {
      name: 'grantDocUserRolesMutation';
      variables: GrantDocUserRolesMutationVariables;
      response: GrantDocUserRolesMutation;
    }
  | {
      name: 'leaveWorkspaceMutation';
      variables: LeaveWorkspaceMutationVariables;
      response: LeaveWorkspaceMutation;
    }
  | {
      name: 'activateLicenseMutation';
      variables: ActivateLicenseMutationVariables;
      response: ActivateLicenseMutation;
    }
  | {
      name: 'deactivateLicenseMutation';
      variables: DeactivateLicenseMutationVariables;
      response: DeactivateLicenseMutation;
    }
  | {
      name: 'installLicenseMutation';
      variables: InstallLicenseMutationVariables;
      response: InstallLicenseMutation;
    }
  | {
      name: 'previewLicenseMutation';
      variables: PreviewLicenseMutationVariables;
      response: PreviewLicenseMutation;
    }
  | {
      name: 'createMcpCredentialMutation';
      variables: CreateMcpCredentialMutationVariables;
      response: CreateMcpCredentialMutation;
    }
  | {
      name: 'revokeMcpCredentialMutation';
      variables: RevokeMcpCredentialMutationVariables;
      response: RevokeMcpCredentialMutation;
    }
  | {
      name: 'rotateMcpCredentialMutation';
      variables: RotateMcpCredentialMutationVariables;
      response: RotateMcpCredentialMutation;
    }
  | {
      name: 'mentionUserMutation';
      variables: MentionUserMutationVariables;
      response: MentionUserMutation;
    }
  | {
      name: 'publishPageMutation';
      variables: PublishPageMutationVariables;
      response: PublishPageMutation;
    }
  | {
      name: 'readAllNotificationsMutation';
      variables: ReadAllNotificationsMutationVariables;
      response: ReadAllNotificationsMutation;
    }
  | {
      name: 'readNotificationMutation';
      variables: ReadNotificationMutationVariables;
      response: ReadNotificationMutation;
    }
  | {
      name: 'recoverDocMutation';
      variables: RecoverDocMutationVariables;
      response: RecoverDocMutation;
    }
  | {
      name: 'removeAvatarMutation';
      variables: RemoveAvatarMutationVariables;
      response: RemoveAvatarMutation;
    }
  | {
      name: 'resumeSubscriptionMutation';
      variables: ResumeSubscriptionMutationVariables;
      response: ResumeSubscriptionMutation;
    }
  | {
      name: 'revokeDocUserRolesMutation';
      variables: RevokeDocUserRolesMutationVariables;
      response: RevokeDocUserRolesMutation;
    }
  | {
      name: 'revokeMemberPermissionMutation';
      variables: RevokeMemberPermissionMutationVariables;
      response: RevokeMemberPermissionMutation;
    }
  | {
      name: 'revokePublicPageMutation';
      variables: RevokePublicPageMutationVariables;
      response: RevokePublicPageMutation;
    }
  | {
      name: 'sendChangeEmailMutation';
      variables: SendChangeEmailMutationVariables;
      response: SendChangeEmailMutation;
    }
  | {
      name: 'sendChangePasswordEmailMutation';
      variables: SendChangePasswordEmailMutationVariables;
      response: SendChangePasswordEmailMutation;
    }
  | {
      name: 'sendSetPasswordEmailMutation';
      variables: SendSetPasswordEmailMutationVariables;
      response: SendSetPasswordEmailMutation;
    }
  | {
      name: 'sendVerifyChangeEmailMutation';
      variables: SendVerifyChangeEmailMutationVariables;
      response: SendVerifyChangeEmailMutation;
    }
  | {
      name: 'sendVerifyEmailMutation';
      variables: SendVerifyEmailMutationVariables;
      response: SendVerifyEmailMutation;
    }
  | {
      name: 'setWorkspacePublicByIdMutation';
      variables: SetWorkspacePublicByIdMutationVariables;
      response: SetWorkspacePublicByIdMutation;
    }
  | {
      name: 'refreshSubscriptionMutation';
      variables: RefreshSubscriptionMutationVariables;
      response: RefreshSubscriptionMutation;
    }
  | {
      name: 'requestApplySubscriptionMutation';
      variables: RequestApplySubscriptionMutationVariables;
      response: RequestApplySubscriptionMutation;
    }
  | {
      name: 'updateDocDefaultRoleMutation';
      variables: UpdateDocDefaultRoleMutationVariables;
      response: UpdateDocDefaultRoleMutation;
    }
  | {
      name: 'updateDocUserRoleMutation';
      variables: UpdateDocUserRoleMutationVariables;
      response: UpdateDocUserRoleMutation;
    }
  | {
      name: 'updateSubscriptionMutation';
      variables: UpdateSubscriptionMutationVariables;
      response: UpdateSubscriptionMutation;
    }
  | {
      name: 'updateUserProfileMutation';
      variables: UpdateUserProfileMutationVariables;
      response: UpdateUserProfileMutation;
    }
  | {
      name: 'updateUserSettingsMutation';
      variables: UpdateUserSettingsMutationVariables;
      response: UpdateUserSettingsMutation;
    }
  | {
      name: 'uploadAvatarMutation';
      variables: UploadAvatarMutationVariables;
      response: UploadAvatarMutation;
    }
  | {
      name: 'verifyEmailMutation';
      variables: VerifyEmailMutationVariables;
      response: VerifyEmailMutation;
    }
  | {
      name: 'deleteWorkspaceByokProfileMutation';
      variables: DeleteWorkspaceByokProfileMutationVariables;
      response: DeleteWorkspaceByokProfileMutation;
    }
  | {
      name: 'probeWorkspaceByokProfileMutation';
      variables: ProbeWorkspaceByokProfileMutationVariables;
      response: ProbeWorkspaceByokProfileMutation;
    }
  | {
      name: 'probeWorkspaceByokDraftMutation';
      variables: ProbeWorkspaceByokDraftMutationVariables;
      response: ProbeWorkspaceByokDraftMutation;
    }
  | {
      name: 'createWorkspaceByokProfileMutation';
      variables: CreateWorkspaceByokProfileMutationVariables;
      response: CreateWorkspaceByokProfileMutation;
    }
  | {
      name: 'replaceWorkspaceByokProfileMutation';
      variables: ReplaceWorkspaceByokProfileMutationVariables;
      response: ReplaceWorkspaceByokProfileMutation;
    }
  | {
      name: 'rotateWorkspaceByokCredentialMutation';
      variables: RotateWorkspaceByokCredentialMutationVariables;
      response: RotateWorkspaceByokCredentialMutation;
    }
  | {
      name: 'createWorkspaceByokLocalLeaseMutation';
      variables: CreateWorkspaceByokLocalLeaseMutationVariables;
      response: CreateWorkspaceByokLocalLeaseMutation;
    }
  | {
      name: 'reorderWorkspaceByokProfilesMutation';
      variables: ReorderWorkspaceByokProfilesMutationVariables;
      response: ReorderWorkspaceByokProfilesMutation;
    }
  | {
      name: 'setEnableAiMutation';
      variables: SetEnableAiMutationVariables;
      response: SetEnableAiMutation;
    }
  | {
      name: 'setEnableDocEmbeddingMutation';
      variables: SetEnableDocEmbeddingMutationVariables;
      response: SetEnableDocEmbeddingMutation;
    }
  | {
      name: 'setEnableSharingMutation';
      variables: SetEnableSharingMutationVariables;
      response: SetEnableSharingMutation;
    }
  | {
      name: 'setEnableUrlPreviewMutation';
      variables: SetEnableUrlPreviewMutationVariables;
      response: SetEnableUrlPreviewMutation;
    }
  | {
      name: 'inviteByEmailsMutation';
      variables: InviteByEmailsMutationVariables;
      response: InviteByEmailsMutation;
    }
  | {
      name: 'acceptInviteByInviteIdMutation';
      variables: AcceptInviteByInviteIdMutationVariables;
      response: AcceptInviteByInviteIdMutation;
    }
  | {
      name: 'createInviteLinkMutation';
      variables: CreateInviteLinkMutationVariables;
      response: CreateInviteLinkMutation;
    }
  | {
      name: 'revokeInviteLinkMutation';
      variables: RevokeInviteLinkMutationVariables;
      response: RevokeInviteLinkMutation;
    }
  | {
      name: 'approveWorkspaceTeamMemberMutation';
      variables: ApproveWorkspaceTeamMemberMutationVariables;
      response: ApproveWorkspaceTeamMemberMutation;
    }
  | {
      name: 'grantWorkspaceTeamMemberMutation';
      variables: GrantWorkspaceTeamMemberMutationVariables;
      response: GrantWorkspaceTeamMemberMutation;
    };
