import {
  Controller,
  Get,
  Logger,
  Options,
  Post,
  Req,
  Res,
} from '@nestjs/common';
import type {
  Request as ExpressRequest,
  Response as ExpressResponse,
} from 'express';
import { HTMLRewriter } from 'htmlrewriter';

import {
  applyAttachHeaders,
  BadRequest,
  Cache,
  ResponseTooLargeError,
  safeFetch,
  SsrfBlockedError,
  type SSRFBlockReason,
  Throttle,
  URLHelper,
  UseNamedGuard,
} from '../../base';
import { Public } from '../../core/auth';
import { inspectImageForProxy } from '../../native';
import { WorkerService } from './service';
import type { LinkPreviewRequest, LinkPreviewResponse } from './types';
import {
  appendUrl,
  cloneHeader,
  fixUrl,
  getCorsHeaders,
  isOriginAllowed,
  isRefererAllowed,
  parseJson,
  reduceUrls,
} from './utils';
import { decodeWithCharset } from './utils/encoding';

// cache for 30 minutes
const CACHE_TTL = 1000 * 60 * 30;
const MAX_REDIRECTS = 3;
const FETCH_TIMEOUT_MS = 10_000;
const IMAGE_PROXY_MAX_BYTES = 10 * 1024 * 1024;
const LINK_PREVIEW_MAX_BYTES = 2 * 1024 * 1024;

function safeLogUrl(value: string | URL | undefined) {
  if (!value) return undefined;
  try {
    const url = value instanceof URL ? value : new URL(value);
    return `${url.origin}${url.pathname}`;
  } catch {
    return 'invalid-url';
  }
}

function safeLogError(error: unknown) {
  return error instanceof Error ? error.name : 'UnknownError';
}

function toBadRequestReason(reason: SSRFBlockReason) {
  switch (reason) {
    case 'disallowed_protocol':
    case 'url_has_credentials':
    case 'blocked_hostname':
    case 'blocked_ip':
    case 'invalid_url':
      return 'Invalid URL';
    case 'unresolvable_hostname':
      return 'Failed to resolve hostname';
    case 'too_many_redirects':
      return 'Too many redirects';
    default:
      return 'Blocked by SSRF protection';
  }
}

@Public()
@UseNamedGuard('selfhost')
@Throttle('default', { limit: 60, ttl: 60_000 })
@Controller('/api/worker')
export class WorkerController {
  private readonly logger = new Logger(WorkerController.name);

  constructor(
    private readonly cache: Cache,
    private readonly url: URLHelper,
    private readonly service: WorkerService
  ) {}

  private get allowedOrigin() {
    return this.service.allowedOrigins;
  }

  @Options('/image-proxy')
  imageProxyOption(
    @Req() request: ExpressRequest,
    @Res() resp: ExpressResponse
  ) {
    const origin = request.headers.origin;
    return resp
      .status(204)
      .header({
        ...getCorsHeaders(origin),
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      })
      .send();
  }

  @Get('/image-proxy')
  async imageProxy(@Req() req: ExpressRequest, @Res() resp: ExpressResponse) {
    const origin = req.headers.origin;
    const referer = req.headers.referer;
    const originAllowed = origin
      ? isOriginAllowed(origin, this.allowedOrigin)
      : false;
    const refererAllowed = referer
      ? isRefererAllowed(referer, this.allowedOrigin)
      : false;
    if (!originAllowed && !refererAllowed) {
      this.logger.error('Invalid Origin', {
        origin: safeLogUrl(origin),
        referer: safeLogUrl(referer),
      });
      throw new BadRequest('Invalid header');
    }
    const url = new URL(req.url, this.url.requestBaseUrl);
    const imageURL = url.searchParams.get('url');
    if (!imageURL) {
      throw new BadRequest('Missing "url" parameter');
    }

    const targetURL = fixUrl(imageURL);
    if (!targetURL) {
      this.logger.error('Invalid URL', { url: safeLogUrl(imageURL) });
      throw new BadRequest(`Invalid URL`);
    }

    const logUrl = safeLogUrl(targetURL);

    const cachedUrl = `image-proxy:${targetURL.toString()}`;
    const cachedResponse = await this.cache.get<string>(cachedUrl);
    if (cachedResponse) {
      const buffer = Buffer.from(cachedResponse, 'base64');
      // if cached response is empty, it means the request is rejected by server previously
      if (buffer.length === 0) {
        return resp.status(404).header(getCorsHeaders(origin)).send();
      }
      resp.header({
        ...getCorsHeaders(origin),
        ...(origin ? { Vary: 'Origin' } : {}),
        'Access-Control-Allow-Methods': 'GET',
      });
      const image = this.inspectProxyImage(buffer, imageURL);
      applyAttachHeaders(resp, { buffer, contentType: image.mimeType });
      const contentType = resp.getHeader('Content-Type') as string | undefined;
      if (contentType?.startsWith('image/')) {
        return resp.status(200).send(buffer);
      } else {
        throw new BadRequest('Invalid content type');
      }
    }

    let response: Response;
    try {
      response = await safeFetch(
        targetURL.toString(),
        { method: 'GET', headers: cloneHeader(req.headers) },
        {
          timeoutMs: FETCH_TIMEOUT_MS,
          maxRedirects: MAX_REDIRECTS,
          maxBytes: IMAGE_PROXY_MAX_BYTES,
        }
      );
    } catch (error) {
      if (error instanceof SsrfBlockedError) {
        const reason = error.data?.reason as SSRFBlockReason | undefined;
        this.logger.warn('Blocked image proxy target', {
          url: logUrl,
          reason,
        });
        throw new BadRequest(toBadRequestReason(reason ?? 'invalid_url'));
      }
      if (error instanceof ResponseTooLargeError) {
        this.logger.warn('Image proxy response too large', {
          url: logUrl,
          limitBytes: error.data?.limitBytes,
          receivedBytes: error.data?.receivedBytes,
        });
        throw new BadRequest('Response too large');
      }
      this.logger.error('Failed to fetch image', {
        origin: safeLogUrl(origin),
        url: logUrl,
        error: safeLogError(error),
      });
      throw new BadRequest('Failed to fetch image');
    }
    if (response.ok) {
      const buffer = Buffer.from(await response.arrayBuffer());
      const image = this.inspectProxyImage(buffer, imageURL);
      await this.cache.set(cachedUrl, buffer.toString('base64'), {
        ttl: CACHE_TTL,
      });
      const contentDisposition = response.headers.get('Content-Disposition');
      resp.header({
        ...getCorsHeaders(origin),
        ...(origin ? { Vary: 'Origin' } : {}),
        'Access-Control-Allow-Methods': 'GET',
      });
      if (contentDisposition) {
        resp.setHeader('Content-Disposition', contentDisposition);
      }
      applyAttachHeaders(resp, { buffer, contentType: image.mimeType });
      const contentType = resp.getHeader('Content-Type') as string | undefined;
      if (contentType?.startsWith('image/')) {
        return resp.status(200).send(buffer);
      } else {
        throw new BadRequest('Invalid content type');
      }
    } else {
      if (response.status >= 400 && response.status < 500) {
        // rejected by server, cache a empty response
        await this.cache.set(cachedUrl, Buffer.from([]).toString('base64'), {
          ttl: CACHE_TTL,
        });
      }
      this.logger.error('Failed to fetch image', {
        origin: safeLogUrl(origin),
        url: logUrl,
        status: response.status,
      });
      throw new BadRequest('Failed to fetch image');
    }
  }

  private inspectProxyImage(buffer: Buffer, url: string) {
    try {
      return inspectImageForProxy(buffer);
    } catch (error) {
      this.logger.warn('Image proxy rejected invalid image', {
        url: safeLogUrl(url),
        error: safeLogError(error),
      });
      throw new BadRequest('Invalid image');
    }
  }

  @Options('/link-preview')
  linkPreviewOption(
    @Req() request: ExpressRequest,
    @Res() resp: ExpressResponse
  ) {
    const origin = request.headers.origin;
    return resp
      .status(204)
      .header({
        ...getCorsHeaders(origin),
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, x-affine-version',
      })
      .send();
  }

  @Post('/link-preview')
  async linkPreview(
    @Req() request: ExpressRequest,
    @Res() resp: ExpressResponse
  ): Promise<ExpressResponse> {
    const origin = request.headers.origin;
    const referer = request.headers.referer;
    const originAllowed = origin
      ? isOriginAllowed(origin, this.allowedOrigin)
      : false;
    const refererAllowed = referer
      ? isRefererAllowed(referer, this.allowedOrigin)
      : false;
    if (!originAllowed && !refererAllowed) {
      this.logger.error('Invalid Origin', {
        origin: safeLogUrl(origin),
        referer: safeLogUrl(referer),
      });
      throw new BadRequest('Invalid header');
    }

    const logOrigin = safeLogUrl(origin);
    this.logger.debug('Received request', {
      origin: logOrigin,
      method: request.method,
    });

    const requestBody = parseJson<LinkPreviewRequest>(request.body);
    const targetURL = fixUrl(requestBody?.url);
    // not allow same site preview
    if (!targetURL || isOriginAllowed(targetURL.origin, this.allowedOrigin)) {
      this.logger.error('Invalid URL', {
        origin: logOrigin,
        url: safeLogUrl(requestBody?.url),
      });
      throw new BadRequest('Invalid URL');
    }

    const logUrl = safeLogUrl(targetURL);
    this.logger.debug('Processing request', { origin: logOrigin, url: logUrl });

    try {
      const cachedUrl = `link-preview:${targetURL.toString()}`;
      const cachedResponse = await this.cache.get<string>(cachedUrl);
      if (cachedResponse) {
        return resp
          .status(200)
          .header({
            'content-type': 'application/json;charset=UTF-8',
            ...getCorsHeaders(origin),
          })
          .send(cachedResponse);
      }

      const method: 'GET' | 'HEAD' = requestBody?.head ? 'HEAD' : 'GET';

      const response = await safeFetch(
        targetURL.toString(),
        { method, headers: cloneHeader(request.headers) },
        {
          timeoutMs: FETCH_TIMEOUT_MS,
          maxRedirects: MAX_REDIRECTS,
          maxBytes: LINK_PREVIEW_MAX_BYTES,
        }
      );
      this.logger.debug('Fetched URL', {
        origin: logOrigin,
        url: logUrl,
        status: response.status,
      });

      if (requestBody?.head) {
        return resp
          .status(
            response.status >= 200 && response.status < 400
              ? 204
              : response.status
          )
          .header(getCorsHeaders(origin))
          .send();
      }

      const res: LinkPreviewResponse = {
        url: response.url,
        images: [],
        videos: [],
        favicons: [],
      };

      if (response.body) {
        const body = Buffer.from(await response.arrayBuffer());
        const limitedResponse = new Response(body, response);
        const resp = await decodeWithCharset(limitedResponse, res);

        const rewriter = new HTMLRewriter()
          .on('meta', {
            element(element) {
              const property =
                element.getAttribute('property') ??
                element.getAttribute('name');
              const content = element.getAttribute('content');
              if (property && content) {
                switch (property.toLowerCase()) {
                  case 'og:title':
                    res.title = content;
                    break;
                  case 'og:site_name':
                    res.siteName = content;
                    break;
                  case 'og:description':
                    res.description = content;
                    break;
                  case 'og:image':
                    appendUrl(content, res.images);
                    break;
                  case 'og:video':
                    appendUrl(content, res.videos);
                    break;
                  case 'og:type':
                    res.mediaType = content;
                    break;
                  case 'description':
                    if (!res.description) {
                      res.description = content;
                    }
                }
              }
            },
          })
          .on('link', {
            element(element) {
              if (element.getAttribute('rel')?.toLowerCase().includes('icon')) {
                appendUrl(element.getAttribute('href'), res.favicons);
              }
            },
          })
          .on('title', {
            text(text) {
              if (!res.title) {
                res.title = text.text;
              }
            },
          })
          .on('img', {
            element(element) {
              appendUrl(element.getAttribute('src'), res.images);
            },
          })
          .on('video', {
            element(element) {
              appendUrl(element.getAttribute('src'), res.videos);
            },
          });

        await rewriter.transform(resp).text();

        res.images = await reduceUrls(res.images);

        this.logger.debug('Processed response with HTMLRewriter', {
          origin: logOrigin,
          url: safeLogUrl(response.url),
        });
      }

      // fix favicon
      {
        // head default path of favicon
        const faviconUrl = new URL('/favicon.ico?v=2', response.url);
        const faviconResponse = await safeFetch(
          faviconUrl.toString(),
          { method: 'HEAD' },
          {
            timeoutMs: FETCH_TIMEOUT_MS,
            maxRedirects: MAX_REDIRECTS,
            maxBytes: 0,
          }
        );
        if (faviconResponse.ok) {
          appendUrl(faviconUrl.toString(), res.favicons);
        }

        res.favicons = await reduceUrls(res.favicons);
      }

      const json = JSON.stringify(res);
      this.logger.debug('Sending response', {
        origin: logOrigin,
        url: safeLogUrl(res.url),
        responseSize: json.length,
      });

      await this.cache.set(cachedUrl, res, { ttl: CACHE_TTL });
      return resp
        .status(200)
        .header({
          'content-type': 'application/json;charset=UTF-8',
          ...getCorsHeaders(origin),
        })
        .send(json);
    } catch (error) {
      if (error instanceof SsrfBlockedError) {
        const reason = error.data?.reason as SSRFBlockReason | undefined;
        this.logger.warn('Blocked link preview target', {
          origin: logOrigin,
          url: safeLogUrl(requestBody?.url),
          reason,
        });
        throw new BadRequest(toBadRequestReason(reason ?? 'invalid_url'));
      }
      if (error instanceof ResponseTooLargeError) {
        this.logger.warn('Link preview response too large', {
          origin: logOrigin,
          url: safeLogUrl(requestBody?.url),
          limitBytes: error.data?.limitBytes,
          receivedBytes: error.data?.receivedBytes,
        });
        throw new BadRequest('Response too large');
      }
      this.logger.error('Error fetching URL', {
        origin: logOrigin,
        url: logUrl,
        error: safeLogError(error),
      });
      throw new BadRequest('Error fetching URL');
    }
  }
}
