//! `GRAPH.RECORD` command handler.
//!
//! Runs a query in recording mode and returns operator-level execution trace
//! data for debugging and testing.
//!
//! ## What is returned
//! ```text
//! [
//!   recorded operator outputs,
//!   plan structure + variable names
//! ]
//! ```
//!
//! Recording mode executes the normal planning/runtime path but captures
//! intermediate environments per operator index to help diagnose planning or
//! runtime mismatches.
//!
//! Like `GRAPH.QUERY`, execution happens on the thread pool with the client
//! blocked; the main thread only resolves (or creates) the graph key.

use crate::dispatch::must_run_inline;
use crate::query_session::QuerySession;
use crate::{
    config::{CONFIGURATION_CACHE_SIZE, CONFIGURATION_IMPORT_FOLDER},
    graph_core::{
        BlockedClient, ThreadedGraph, c_graph_key, c_graph_name, ffi, register_graph, up_to_nul,
    },
    redis_type::GRAPH_TYPE,
    reply::reply_verbose_value,
};
use graph::{
    graph::graph::Plan,
    planner::IR,
    runtime::runtime::{GetVariables, Runtime},
    threadpool::spawn,
};
use orx_tree::{Bfs, Collection, NodeRef};
use parking_lot::RwLock;
use redis_module::{Context, NextArg, RedisError, RedisResult, RedisString, RedisValue, raw};
use std::{os::raw::c_char, sync::Arc};

#[inline]
fn record_mut(
    ctx: &Context,
    graph: &Arc<RwLock<ThreadedGraph>>,
    key_name: &Arc<str>,
    query: &str,
) -> RedisResult {
    // A recorded query may be a write, and it is a *real* write: run it under a real
    // session (per-graph lock, escalation at the first `Commit`, mutations into a
    // private MVCC version), then commit and replicate exactly like `GRAPH.QUERY`.
    // RECORD adds the operator trace to a normal write; it does not turn it into a dry
    // run, so effects land and reach replicas.
    //
    // Plain `begin`, for both callers. The background path needs escalation
    // re-authorized, since it commits long after Redis admitted the command. The inline
    // caller (MULTI / replication stream, on the main thread) reaches the same check but
    // returns early from it, because the main thread holds the GIL implicitly and there
    // is no window to re-check.
    let session = QuerySession::begin(graph);
    let Plan {
        plan, parameters, ..
    } = session
        .with_graph(|tg| tg.graph.read().borrow().get_plan(query))
        .map_err(RedisError::String)?;
    let is_write = plan.iter().any(|n| {
        matches!(
            n,
            IR::Commit | IR::CreateIndex { .. } | IR::DropIndex { .. }
        )
    });
    // Writes need the MVCC write slot so they build a private version instead of
    // mutating the published one in place; reads run on the committed snapshot.
    let g = if is_write {
        let Some(g) = session.with_graph(|tg| tg.graph.write()) else {
            return Err(RedisError::String(
                "ERR another write is in progress, retry the query".to_string(),
            ));
        };
        g
    } else {
        session.with_graph(|tg| tg.graph.read())
    };
    let g_arc = Arc::clone(&g);
    let runtime = Runtime::new(
        g,
        parameters,
        is_write,
        plan.clone(),
        true,
        (*CONFIGURATION_IMPORT_FOLDER.lock(ctx)).clone(),
        -1,
        false,
        None,
        0,
        None,
        &session,
    );
    let outcome = runtime.query();
    if is_write {
        match &outcome {
            Err(_) => {
                // Same undo a failed write does: bring the index back in line with
                // committed state, then release the MVCC write slot.
                let committed = session.with_graph(|tg| tg.graph.read());
                runtime.resync_published_indexes(&committed);
                session.with_graph(|tg| tg.graph.rollback());
            }
            Ok(result) => {
                let stats = &result.stats;
                let modified = stats.nodes_created > 0
                    || stats.nodes_deleted > 0
                    || stats.relationships_created > 0
                    || stats.relationships_deleted > 0
                    || stats.properties_set > 0
                    || stats.properties_removed > 0
                    || stats.labels_added > 0
                    || stats.labels_removed > 0
                    || stats.indexes_created > 0
                    || stats.indexes_dropped > 0
                    || runtime.effects_count.get() > 0;
                // Effects encoding mirrors `execute_query_write`: index DDL carrying
                // OPTIONS cannot round-trip, so those fall back to verbatim
                // replication of the query.
                let has_unencodable_index = runtime.plan.iter().any(
                    |node| matches!(node, IR::CreateIndex { options, .. } if options.is_some()),
                );
                let effects_buffer = if has_unencodable_index {
                    None
                } else {
                    let buf = crate::graph_core::should_use_effects(
                        false,
                        &runtime,
                        stats.execution_time,
                    );
                    crate::graph_core::build_index_effects(&runtime, buf)
                };
                let wq = crate::graph_core::WriteQueryOk {
                    graph: g_arc,
                    effects_buffer,
                    modified,
                };
                if session
                    .with_graph_mut(|tg| {
                        crate::graph_core::commit_and_replicate(tg, ctx, key_name, query, wq)
                    })
                    .is_none()
                {
                    // The plan's `Commit` never ran (`LIMIT 0` above it, say), so
                    // nothing was mutated — release the slot without publishing.
                    session.with_graph(|tg| tg.graph.rollback());
                }
            }
        }
    }
    let ids = plan.root().indices::<Bfs>().collect::<Vec<_>>();
    raw::reply_with_array(ctx.ctx, 2);
    raw::reply_with_array(ctx.ctx, runtime.record.borrow().len() as _);
    for (idx, res) in runtime.record.borrow().iter() {
        raw::reply_with_array(ctx.ctx, 3);
        raw::reply_with_long_long(ctx.ctx, ids.iter().position(|id| *id == *idx).unwrap() as _);
        match res {
            Err(err) => {
                raw::reply_with_long_long(ctx.ctx, 0);
                raw::reply_with_string_buffer(ctx.ctx, err.as_ptr().cast::<c_char>(), err.len());
            }
            Ok(row) => {
                raw::reply_with_long_long(ctx.ctx, 1);
                let vars = plan.node(*idx).get_variables();
                raw::reply_with_array(ctx.ctx, vars.len() as _);
                for name in &vars {
                    if row.is_bound_by_id(name.id) {
                        match row.get_by_id(name.id) {
                            None => {
                                raw::reply_with_null(ctx.ctx);
                            }
                            Some(value) => {
                                reply_verbose_value(ctx, &runtime, value);
                            }
                        }
                    } else {
                        raw::reply_with_null(ctx.ctx);
                    }
                }
            }
        }
    }
    drop(runtime);

    raw::reply_with_array(ctx.ctx, ids.len() as _);
    for idx in plan.root().indices::<Bfs>() {
        raw::reply_with_array(ctx.ctx, 4);
        raw::reply_with_long_long(ctx.ctx, ids.iter().position(|id| *id == idx).unwrap() as _);
        match plan.node(idx).parent() {
            Some(parent_idx) => {
                raw::reply_with_long_long(
                    ctx.ctx,
                    ids.iter().position(|id| *id == parent_idx.idx()).unwrap() as _,
                );
            }
            None => {
                raw::reply_with_null(ctx.ctx);
            }
        }
        let node = plan.node(idx).data().to_string();
        raw::reply_with_string_buffer(ctx.ctx, node.as_ptr().cast::<c_char>(), node.len());
        let vars = plan.node(idx).get_variables();
        raw::reply_with_array(ctx.ctx, vars.len() as _);
        for var in vars {
            raw::reply_with_string_buffer(
                ctx.ctx,
                var.as_str().as_ptr().cast::<c_char>(),
                var.as_str().len(),
            );
        }
    }
    Ok(RedisValue::NoReply)
}

pub fn graph_record(
    ctx: &Context,
    args: Vec<RedisString>,
) -> RedisResult {
    let mut args = args.into_iter().skip(1);
    let key_str = args.next_arg()?;
    // C ends the query at its first NUL byte; see `up_to_nul`.
    let query = up_to_nul(args.next_str()?);

    let key = ctx.open_key_writable(&key_str);

    // `key_name` is the key the graph lives at, not C's name for it — see `graph_query`.
    // An existing graph is at the key the command named; one created here lands at the
    // key C rebuilds from the name.
    let (graph, key_name): (Arc<RwLock<ThreadedGraph>>, Arc<str>) =
        if let Some(graph) = key.get_value::<Arc<RwLock<ThreadedGraph>>>(&GRAPH_TYPE)? {
            (graph.clone(), Arc::from(key_str.to_string()))
        } else {
            let name = c_graph_name(&key_str);
            let graph = Arc::new(RwLock::new(ThreadedGraph::new(
                *CONFIGURATION_CACHE_SIZE.lock(ctx) as usize,
                &name,
            )));
            // Stored under C's key, as GRAPH.QUERY does — see `c_graph_key`.
            let create_key = ctx.open_key_writable(&c_graph_key(ctx, &key_str));
            create_key.set_value(&GRAPH_TYPE, graph.clone())?;
            let key_name: Arc<str> = Arc::from(name.as_str());
            register_graph(name, graph.clone());
            (graph, key_name)
        };

    // Contexts that cannot block run inline — same rules as GRAPH.QUERY, see
    // `must_run_inline`.
    if must_run_inline(ctx) {
        return record_mut(ctx, &graph, &key_name, query);
    }

    // Run on the thread pool like GRAPH.QUERY. Executing on the main thread
    // deadlocks the server: the handler holds the GIL while waiting for the
    // ThreadedGraph read lock, while a committing write query holds the
    // write lock and waits for the GIL.
    let bc = unsafe { BlockedClient::new(ctx.ctx) };
    let query: Arc<str> = Arc::from(query);
    let key_name = key_name.clone();
    spawn(
        move || {
            let ctx = unsafe { ffi::get_thread_safe_context(bc.inner) };
            let ctx = Context::new(ctx);
            if let Err(err) = record_mut(&ctx, &graph, &key_name, &query) {
                let cerr = ffi::sanitise_error(err.to_string());
                unsafe { ffi::reply_error(ctx.ctx, cerr.as_ptr()) };
            }
            drop(bc);
            unsafe { ffi::free_thread_safe_context(ctx.ctx) };
        },
        None,
    );

    RedisResult::Ok(RedisValue::NoReply)
}
