from common import *
from datetime import datetime, date, time, timezone
from dateutil.relativedelta import relativedelta

GRAPH_ID = "temporal_test"

class testTemporalLocalTime(FlowTestsBase):
    def __init__(self):
        self.env, self.db = Env()
        self.graph = self.db.select_graph(GRAPH_ID)

    # test localtime construction from individual components
    def test_localtime_component_construction(self):
        test_cases = [
                ({'hour': 12},                                                                                        '12:00:00'),
                ({'hour': 12, 'minute': 31},                                                                          '12:31:00'),
                ({'hour': 12, 'minute': 31, 'second': 14},                                                            '12:31:14'),
                ({'hour': 12, 'minute': 31, 'second': 14, 'millisecond': 645},                                        '12:31:14'),
                ({'hour': 12, 'minute': 31, 'second': 14, 'microsecond': 645876},                                     '12:31:14'),
                ({'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 645876123},                                   '12:31:14'),
                ({'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 789, 'millisecond': 123, 'microsecond': 456}, '12:31:14')
        ]

        query = "RETURN localtime($time)"
        for map_input, expected in test_cases:
            # Construct the map string for the Cypher query
            result = self.graph.query(query, {'time': map_input})
            actual = str(result.result_set[0][0])
            self.env.assertEqual(actual, expected)

    def test_localtime_from_string(self):
        test_cases = [
                ('21',           '21:00:00'),
                ('2140',         '21:40:00'),
                ('21:40',        '21:40:00'),
                ('214032',       '21:40:32'),
                ('21:40:32',     '21:40:32'),
                ('214032.142',   '21:40:32'),
                ('21:40:32.143', '21:40:32')
        ]

        for str_input, expected in test_cases:
            query = f"RETURN localtime($str)"
            result = self.graph.query(query, {'str': str_input})
            actual = str(result.result_set[0][0])
            self.env.assertEqual(actual, expected)

    def test_localtime_components(self):
        q = """WITH localtime({hour: 12, minute: 31, second: 14, nanosecond: 645876123}) AS d
               RETURN d.hour, d.minute, d.second"""

        res = self.graph.query(q).result_set
        actual_hour   = res[0][0]
        actual_minute = res[0][1]
        actual_second = res[0][2]

        self.env.assertEqual(actual_hour, 12)
        self.env.assertEqual(actual_minute, 31)
        self.env.assertEqual(actual_second, 14)

    def test_localtime_to_from_string(self):
        q = """WITH localtime({hour: 12, minute: 31, second: 14}) AS d
               RETURN toString(d) AS ts, localtime(toString(d)) = d AS b"""

        res = self.graph.query(q).result_set
        ts = res[0][0]
        b  = res[0][1]

        self.env.assertTrue(b)
        self.env.assertEqual(str(ts), '12:31:14')

    def test_localtime_compare(self):
        q = """WITH localtime({hour: 10, minute: 35}) AS x,
                    localtime({hour: 12, minute: 31, second: 14}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertTrue(lt)
        self.env.assertFalse(ge)
        self.env.assertTrue(le)
        self.env.assertFalse(e)

class testTemporalDate(FlowTestsBase):
    def __init__(self):
        self.env, self.db = Env()
        self.graph = self.db.select_graph(GRAPH_ID)

    # test date construction from individual components
    def test_date_component_construction(self):
        test_cases = [
            ({'year': 1984},                                   '1984-01-01'),
            ({'year': 1984, 'month': 10},                      '1984-10-01'),
            ({'year': 1984, 'week': 10},                       '1984-03-05'),
            ({'year': 1984, 'month': 10, 'day': 11},           '1984-10-11'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3},       '1984-03-07'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45}, '1984-08-14'),
            ({'year': 1984, 'quarter': 3 },                    '1984-07-01'),
            #({'year': 1984, 'ordinalDay': 202},                '1984-07-20'),
        ]

        query = "RETURN date($date)"
        for map_input, expected in test_cases:
            # Construct the map string for the Cypher query
            result = self.graph.query(query, {'date': map_input})
            actual = str(result.result_set[0][0])
            self.env.assertEqual(actual, expected)

    def test_date_from_string(self):
        test_cases = [
          ('2015',       '2015-01-01'),
          ('201507',     '2015-07-01'),
          ('2015202',    '2015-07-21'),
          #('2015W30',    '2015-07-20'),
          ('2015-07',    '2015-07-01'),
          #('2015-202',   '2015-07-21'),
          #('2015W302',   '2015-07-21'),
          ('2015-W30',   '2015-07-20'),
          ('20150721',   '2015-07-21'),
          ('2015-07-21', '2015-07-21'),
          ('2015-W30-2', '2015-07-21')
        ]

        for str_input, expected in test_cases:
            query = f"RETURN date($str)"
            result = self.graph.query(query, {'str': str_input})
            actual = str(result.result_set[0][0])
            self.env.assertEqual(actual, expected)

    def test_date_components(self):
        q = """WITH date({year: 1984, month:10, day:21}) AS d
               RETURN d.year, d.quarter, d.month, d.week, d.day, d.dayOfWeek,
                      d.dayOfQuarter, d.ordinalDay"""

        res = self.graph.query(q).result_set

        year         = res[0][0]
        quarter      = res[0][1]
        month        = res[0][2]
        week         = res[0][3]
        day          = res[0][4]
        dayOfWeek    = res[0][5]
        dayOfQuarter = res[0][6]
        ordinalDay   = res[0][7]

        self.env.assertEqual(year, 1984)
        self.env.assertEqual(quarter, 4)
        self.env.assertEqual(month, 10)
        self.env.assertEqual(week, 42)
        self.env.assertEqual(day, 21)
        self.env.assertEqual(dayOfWeek, 0)
        self.env.assertEqual(dayOfQuarter, 21)
        self.env.assertEqual(ordinalDay, 295)

    def test_date_to_from_string(self):
        test_cases = [
            ({'year': 1984},                                   '1984-01-01'),
            ({'year': 1984, 'month': 10},                      '1984-10-01'),
            ({'year': 1984, 'week': 10},                       '1984-03-05'),
            ({'year': 1984, 'month': 10, 'day': 11},           '1984-10-11'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3},       '1984-03-07'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45}, '1984-08-14'),
            ({'year': 1984, 'quarter': 3 },                    '1984-07-01'),
            #({'year': 1984, 'ordinalDay': 202},                '1984-07-20'),
        ]

        for map_input, expected in test_cases:
            # Construct the map string for the Cypher query
            query = """WITH date($comp) AS d
                       RETURN toString(d) AS ts, date(toString(d)) = d AS b"""

            res = self.graph.query(query, {'comp': map_input}).result_set
            ts  = res[0][0]
            b   = res[0][1]

            self.env.assertTrue(b)
            self.env.assertEqual(ts, expected)

    def test_date_compare(self):
        q = """WITH date({year: 1980, month: 12, day: 24}) AS x,
                    date({year: 1984, month: 10, day: 11}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertTrue(lt)
        self.env.assertFalse(ge)
        self.env.assertTrue(le)
        self.env.assertFalse(e)

        q = """WITH date({year: 1984, month: 10, day: 11}) AS x,
                    date({year: 1984, month: 10, day: 11}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertFalse(lt)
        self.env.assertTrue(ge)
        self.env.assertTrue(le)
        self.env.assertTrue(e)

class testTemporalLocalDateTime(FlowTestsBase):
    def __init__(self):
        self.env, self.db = Env()
        self.graph = self.db.select_graph(GRAPH_ID)

    def test_localdatetime_component_construction(self):
        test_cases = [
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 789, 'millisecond': 123, 'microsecond': 456}, '1984-10-11 12:31:14'), # "1984-10-11 12:31:14"
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 645876123}, '1984-10-11 12:31:14'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 3}, '1984-10-11 12:31:14'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14, 'microsecond': 645876}, '1984-10-11 12:31:14'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14, 'millisecond': 645}, '1984-10-11 12:31:14'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31, 'second': 14}, '1984-10-11 12:31:14'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12, 'minute': 31}, '1984-10-11 12:31:00'),
            ({'year': 1984, 'month': 10, 'day': 11, 'hour': 12}, '1984-10-11 12:00:00'),
            ({'year': 1984, 'month': 10, 'day': 11}, '1984-10-11 00:00:00'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 645876123}, '1984-03-07 12:31:14'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12, 'minute': 31, 'second': 14, 'microsecond': 645876}, '1984-03-07 12:31:14'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12, 'minute': 31, 'second': 14, 'millisecond': 645}, '1984-03-07 12:31:14'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12, 'minute': 31, 'second': 14}, '1984-03-07 12:31:14'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12, 'minute': 31}, '1984-03-07 12:31:00'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3, 'hour': 12}, '1984-03-07 12:00:00'),
            ({'year': 1984, 'week': 10, 'dayOfWeek': 3}, '1984-03-07 00:00:00'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 645876123}, '1984-07-20 12:31:14'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12, 'minute': 31, 'second': 14, 'microsecond': 645876}, '1984-07-20 12:31:14'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12, 'minute': 31, 'second': 14, 'millisecond': 645}, '1984-07-20 12:31:14'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12, 'minute': 31, 'second': 14}, '1984-07-20 12:31:14'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12, 'minute': 31}, '1984-07-20 12:31:00'),
            #({'year': 1984, 'ordinalDay': 202, 'hour': 12}, '1984-07-20 12:00:00'),
            #({'year': 1984, 'ordinalDay': 202}, '1984-07-20 00:00:00'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12, 'minute': 31, 'second': 14, 'nanosecond': 645876123}, '1984-08-14 12:31:14'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12, 'minute': 31, 'second': 14, 'microsecond': 645876}, '1984-08-14 12:31:14'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12, 'minute': 31, 'second': 14, 'millisecond': 645}, '1984-08-14 12:31:14'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12, 'minute': 31, 'second': 14}, '1984-08-14 12:31:14'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12, 'minute': 31}, '1984-08-14 12:31:00'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45, 'hour': 12}, '1984-08-14 12:00:00'),
            ({'year': 1984, 'quarter': 3, 'dayOfQuarter': 45}, '1984-08-14 00:00:00'),
            ({'year': 1984}, '1984-01-01 00:00:00')
        ]

        query = "RETURN localdatetime($date)"
        for map_input, expected in test_cases:
            # Construct the map string for the Cypher query
            result = self.graph.query(query, {'date': map_input})
            actual = str(result.result_set[0][0]).replace("+00:00", "")
            self.env.assertEqual(actual, expected)

    def test_localdatetime_week_construction(self):
        test_cases = [
            ({'year': 1916, 'week': 1}, '1916-01-03 00:00:00'),
            ({'year': 1916, 'week': 52}, '1916-12-25 00:00:00'),
            ({'year': 1917, 'week': 1}, '1917-01-01 00:00:00'),
            ({'year': 1917, 'week': 10}, '1917-03-05 00:00:00'),
            ({'year': 1917, 'week': 30}, '1917-07-23 00:00:00'),
            ({'year': 1917, 'week': 52}, '1917-12-24 00:00:00'),
            ({'year': 1918, 'week': 1}, '1917-12-31 00:00:00'),
            ({'year': 1918, 'week': 52}, '1918-12-23 00:00:00'),
            ({'year': 1918, 'week': 53}, '1918-12-30 00:00:00'),
            #({'year': 1919, 'week': 1}, '1919-01-04 00:00:00'),
            ({'year': 1919, 'week': 52}, '1919-12-22 00:00:00'),
            ({'year': 1917, 'week': 1, 'dayOfWeek': 2}, '1917-01-02 00:00:00'),
        ]

        query = "RETURN localdatetime($date)"
        for map_input, expected in test_cases:
            # Construct the map string for the Cypher query
            result = self.graph.query(query, {'date': map_input})
            actual = str(result.result_set[0][0]).replace("+00:00", "")
            self.env.assertEqual(actual, expected)

    def test_localdatetime_components(self):
        q = """WITH localdatetime({year: 1984, month:10, day:21, hour:10, minute:31, second:46}) AS d
               RETURN d.year, d.quarter, d.month, d.week, d.day, d.dayOfWeek,
                      d.dayOfQuarter, d.ordinalDay, d.hour, d.minute, d.second"""

        res = self.graph.query(q).result_set

        year         = res[0][0]
        quarter      = res[0][1]
        month        = res[0][2]
        week         = res[0][3]
        day          = res[0][4]
        dayOfWeek    = res[0][5]
        dayOfQuarter = res[0][6]
        ordinalDay   = res[0][7]
        hour         = res[0][8]
        minute       = res[0][9]
        second       = res[0][10]

        self.env.assertEqual(year, 1984)
        self.env.assertEqual(quarter, 4)
        self.env.assertEqual(month, 10)
        self.env.assertEqual(week, 42)
        self.env.assertEqual(day, 21)
        self.env.assertEqual(dayOfWeek, 0)
        #self.env.assertEqual(dayOfQuarter, 21)
        self.env.assertEqual(ordinalDay, 295)
        self.env.assertEqual(hour, 10)
        self.env.assertEqual(minute, 31)
        self.env.assertEqual(second, 46)

    def test_localdatetime_from_string(self):
        test_cases = [
                ('2025',                datetime(year=2025, month=1, day=1, tzinfo=timezone.utc)),
                ('2025-02',             datetime(year=2025, month=2, day=1, tzinfo=timezone.utc)),
                ('2025-02-18',          datetime(year=2025, month=2, day=18, tzinfo=timezone.utc)),
                ('20250218',            datetime(year=2025, month=2, day=18, tzinfo=timezone.utc)),
                ('2025-02-18T12',       datetime(year=2025, month=2, day=18, hour=12, tzinfo=timezone.utc)),
                ('2025-02-18T12:34',    datetime(year=2025, month=2, day=18, hour=12, minute=34, tzinfo=timezone.utc)),
                ('2025-02-18T12:34:56', datetime(year=2025, month=2, day=18, hour=12, minute=34, second=56, tzinfo=timezone.utc)),
                ('20250218T123456',     datetime(year=2025, month=2, day=18, hour=12, minute=34, second=56, tzinfo=timezone.utc))
                #('2025-049', datetime()), # Year + day-of-year
                #('2025049T12', datetime()), # Year + day-of-year + hour
                #('2025049T1234', datetime()), # Year + day-of-year + hour + minute
        ]

        query = "RETURN localdatetime($str)"
        for str_input, expected in test_cases:
            result = self.graph.query(query, {'str': str_input})
            actual = result.result_set[0][0]
            self.env.assertEqual(actual, expected)

    def test_localdatetime_to_from_string(self):
        query = """WITH localdatetime({year: 1984, month: 10, day: 11, hour: 12, minute: 31, second: 14, nanosecond: 645876123}) AS d
                   RETURN d AS ts, localdatetime(toString(d)) = d AS b"""

        expected = datetime(year=1984, month=10, day=11, hour=12, minute=31, second=14, tzinfo=timezone.utc)
        res = self.graph.query(query).result_set
        ts  = res[0][0]
        b   = res[0][1]

        self.env.assertTrue(b)
        self.env.assertEqual(ts, expected)

    def test_localdatetime_compare(self):
        q = """WITH localdatetime({year: 1980, month: 12, day: 11, hour: 12, minute: 31, second: 14}) AS x,
                    localdatetime({year: 1984, month: 10, day: 11, hour: 12, minute: 31, second: 14, nanosecond: 645876123}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertTrue(lt)
        self.env.assertFalse(ge)
        self.env.assertTrue(le)
        self.env.assertFalse(e)

        q = """WITH localdatetime({year: 1984, month: 10, day: 11, hour: 12, minute: 31, second: 14, nanosecond: 645876123}) AS x,
                    localdatetime({year: 1984, month: 10, day: 11, hour: 12, minute: 31, second: 14, nanosecond: 645876123}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertFalse(lt)
        self.env.assertTrue(ge)
        self.env.assertTrue(le)
        self.env.assertTrue(e)

class testTemporalDuration(FlowTestsBase):
    def __init__(self):
        self.env, self.db = Env()
        self.graph = self.db.select_graph(GRAPH_ID)

    def test_duration_component_construction(self):
        test_cases = [
                 ( {'years':   2},                                                                          relativedelta(years=2)),
                 ( {'months':  3},                                                                          relativedelta(months=3)),
                 ( {'weeks':   1},                                                                          relativedelta(weeks=1)),
                 ( {'hours':   6},                                                                          relativedelta(hours=6)),
                 ( {'minutes': 23},                                                                         relativedelta(minutes=23)),
                 ( {'seconds': 15},                                                                         relativedelta(seconds=15)),
                 ( {'years': 2, 'months': 3},                                                               relativedelta(years=2, months=3)),
                 ( {'years': 2, 'months': 3, 'days':  4},                                                   relativedelta(years=2, months=3, days=4)),
                 ( {'years': 2, 'months': 3, 'days':  4, 'hours':   5},                                     relativedelta(years=2, months=3, days=4, hours=5)),
                 ( {'years': 2, 'months': 3, 'days':  4, 'hours':   5,  'minutes': 22},                     relativedelta(years=2, months=3, days=4, hours=5, minutes=22)),
                 ( {'years': 2, 'months': 3, 'days':  4, 'hours':   5,  'minutes': 22, 'seconds': 7},       relativedelta(years=2, months=3, days=4, hours=5, minutes=22, seconds=7)),
                 ( {'years': 2, 'weeks':  1, 'hours': 5, 'minutes': 22, 'seconds': 7},                      relativedelta(years=2, weeks=1, hours=5, minutes=22, seconds=7)),

            # Negative values:

                 ( {'years':   -2},                                                                         relativedelta(years=-2)),
                 ( {'months':  -3},                                                                         relativedelta(months=-3)),
                 ( {'weeks':   -1},                                                                         relativedelta(weeks=-1)),
                 ( {'hours':   -6},                                                                         relativedelta(hours=-6)),
                 ( {'minutes': -23},                                                                        relativedelta(minutes=-23)),
                 ( {'seconds': -15},                                                                        relativedelta(seconds=-15)),
                 ( {'years': -2, 'months': -3},                                                             relativedelta(years=-2, months=-3)),
                 ( {'years': -2, 'months': -3, 'days':  -4},                                                relativedelta(years=-2, months=-3, days=-4)),
                 ( {'years': -2, 'months': -3, 'days':  -4, 'hours':   -5},                                 relativedelta(years=-2, months=-3, days=-4, hours=-5)),
                 ( {'years': -2, 'months': -3, 'days':  -4, 'hours':   -5,  'minutes': -22},                relativedelta(years=-2, months=-3, days=-4, hours=-5, minutes=-22)),
                 ( {'years': -2, 'months': -3, 'days':  -4, 'hours':   -5,  'minutes': -22, 'seconds': -7}, relativedelta(years=-2, months=-3, days=-4, hours=-5, minutes=-22, seconds=-7)),
                 ( {'years': -2, 'weeks':  -1, 'hours': -5, 'minutes': -22, 'seconds': -7},                 relativedelta(years=-2, weeks=-1, hours=-5, minutes=-22, seconds=-7)),
        ]

        for map_input, expected in test_cases:
            # construct the map string for the Cypher query
            query = f"RETURN tostring(duration($d))"
            query = f"RETURN duration($d)"
            result = self.graph.query(query, {'d': map_input})
            actual = result.result_set[0][0]
            self.env.assertEqual(actual, expected)

    def test_duration_from_string(self):
        test_cases = [
                ('P1Y',            relativedelta(years=1,)),
                ('P1M',            relativedelta(months=1)),
                ('P1Y2M',          relativedelta(years=1, months=2)),
                ('P1Y2M3D',        relativedelta(years=1, months=2, days=3)),
                ('P1Y2M3DT4H',     relativedelta(years=1, months=2, days=3, hours=4)),
                ('P1Y2M3DT4H5M',   relativedelta(years=1, months=2, days=3, hours=4, minutes=5)),
                ('P1Y2M3DT4H5M6S', relativedelta(years=1, months=2, days=3, hours=4, minutes=5, seconds=6))
        ]

        query = "RETURN duration($str)"
        for str_input, expected in test_cases:
            result = self.graph.query(query, {'str': str_input})
            actual = result.result_set[0][0]
            self.env.assertEqual(actual, expected)

        result = self.graph.query("RETURN toString(duration('P1M')) AS s")
        self.env.assertEqual(result.result_set[0], ["P1M"])

    def test_month_end_duration_arithmetic(self):
        result = self.graph.query(
            """
            RETURN toString(date('2024-01-31') + duration('P1M')) AS d,
                   toString(localdatetime('2024-01-31T00:00:00') + duration('P1M')) AS l
            """
        )
        self.env.assertEqual(result.result_set[0], ["2024-03-02", "2024-03-02T00:00:00"])

    def test_duration_components(self):
        q = """WITH duration({years: 2, months:3, weeks:1, days:4, hours:5, minutes:22, seconds:7}) AS d
               RETURN d.years, d.months, d.weeks, d.days, d.hours, d.minutes, d.seconds"""

        res = self.graph.query(q).result_set

        years   = res[0][0]
        months  = res[0][1]
        weeks   = res[0][2]
        days    = res[0][3]
        hours   = res[0][4]
        minutes = res[0][5]
        seconds = res[0][6]

        self.env.assertEqual(years,   2)
        self.env.assertEqual(months,  3)
        self.env.assertEqual(weeks,   0)  # weeks seems to move to days
        self.env.assertEqual(days,    11)
        self.env.assertEqual(hours,   5)
        self.env.assertEqual(minutes, 22)
        self.env.assertEqual(seconds, 7)

    def test_duration_compare(self):
        q = """WITH duration({years: 1, months: 11, days: 11, hours: 12, minutes: 31, seconds: 14}) AS x,
                    duration({years: 1, months: 10, days: 11, hours: 12, minutes: 31, seconds: 14}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertTrue(gt)
        self.env.assertFalse(lt)
        self.env.assertTrue(ge)
        self.env.assertFalse(le)
        self.env.assertFalse(e)

        q = """WITH localdatetime({year: 1, month: 10, day: 11, hour: 12, minute: 31, second: 14}) AS x,
                    localdatetime({year: 1, month: 10, day: 11, hour: 12, minute: 31, second: 14}) AS d
               RETURN x > d, x < d, x >= d, x <= d, x = d"""

        res = self.graph.query(q).result_set
        gt = res[0][0]
        lt = res[0][1]
        ge = res[0][2]
        le = res[0][3]
        e  = res[0][4]

        self.env.assertFalse(gt)
        self.env.assertFalse(lt)
        self.env.assertTrue(ge)
        self.env.assertTrue(le)
        self.env.assertTrue(e)

    def test_duration_add(self):
        #-----------------------------------------------------------------------
        # duration + duration
        #-----------------------------------------------------------------------

        a = "duration({years:1, months:1, weeks:1, days:1, hours:1, minutes:32, seconds:10})"
        b = "duration({years:2, months:2, weeks:2, days:2, hours:2, minutes:34, seconds:12})"
        q = f"RETURN {a} + {b}, {b} + {a}"
        expected = relativedelta(years=3, months=3, days=24, hours=4, minutes=6, seconds=22)

        actual = self.graph.query(q).result_set[0][0]
        self.env.assertEqual(actual, expected)

        actual = self.graph.query(q).result_set[0][1]
        self.env.assertEqual(actual, expected)

        #-----------------------------------------------------------------------
        # duration - duration
        #-----------------------------------------------------------------------

        q = """RETURN duration({years:2, months:2, weeks:2, days:2, hours:2, minutes:34, seconds:12})
                      -
                      duration({years:1, months:1, weeks:1, days:1, hours:1, minutes:32, seconds:10})"""
        actual = self.graph.query(q).result_set[0][0]
        expected = relativedelta(years=1, months=1, days=8, hours=1, minutes=2, seconds=2)
        self.env.assertEqual(actual, expected)

        #-----------------------------------------------------------------------
        # date + duration
        #-----------------------------------------------------------------------

        a = "date({year:1984, month:10, day:21})"
        b = "duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})"
        q = f"RETURN {a} + {b}, {b} + {a}"
        expected = date(year=1985, month=11, day=22)

        actual = self.graph.query(q).result_set[0][0]
        self.env.assertEqual(actual, expected)

        actual = self.graph.query(q).result_set[0][1]
        self.env.assertEqual(actual, expected)

        #-----------------------------------------------------------------------
        # date - duration
        #-----------------------------------------------------------------------

        q = """RETURN date({year:1984, month:10, day:21})
                      -
                      duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})"""
        actual = self.graph.query(q).result_set[0][0]

        try:
            q = """RETURN duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})
                   -
                   date({year:1984, month:10, day:21})"""

            self.graph.query(q)
            self.env.assertFalse(True)
        except Exception:
            pass

        #-----------------------------------------------------------------------
        # time + duration
        #-----------------------------------------------------------------------

        a = "localtime({hour:2, minute: 34, second:32})"
        b = "duration({years:1, months:1, days:1, hours:1, minutes:35, seconds:35})"
        q = f"RETURN {a} + {b}, {b} + {a}"
        expected = time(hour=4, minute=10, second=7)

        actual = self.graph.query(q).result_set[0][0]
        self.env.assertEqual(actual, expected)

        actual = self.graph.query(q).result_set[0][1]
        self.env.assertEqual(actual, expected)

        #-----------------------------------------------------------------------
        # time - duration
        #-----------------------------------------------------------------------

        q = """RETURN localtime({hour:10, minute: 30, second:10})
               -
               duration({hours:2, minutes:40, seconds:30})"""
        actual = self.graph.query(q).result_set[0][0]
        expected = time(hour=7, minute=49, second=40)
        self.env.assertEqual(actual, expected)

        try:
            q = """RETURN duration({hours:2, minutes:40, seconds:30})
                   -
                   localtime({hour:10, minute: 30, second:10})"""
            self.graph.query(q)
            self.env.assertFalse(True)
        except Exception:
            pass

        #-----------------------------------------------------------------------
        # datetime + duration
        #-----------------------------------------------------------------------

        a = "localdatetime({year:1984, month:10, day:21, hour:5, minute:30, second:10})"
        b = "duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})"
        q = f"RETURN {a} + {b}, {b} + {a}"
        expected = datetime(year=1985, month=11, day=22, hour=6, minute=31, second=11, tzinfo=timezone.utc)

        actual = self.graph.query(q).result_set[0][0]
        self.env.assertEqual(actual, expected)

        actual = self.graph.query(q).result_set[0][1]
        self.env.assertEqual(actual, expected)

        #-----------------------------------------------------------------------
        # datetime - duration
        #-----------------------------------------------------------------------

        q = """RETURN localdatetime({year:1984, month:10, day:21, hour:5, minute:30, second:10})
               -
               duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})"""
        actual = self.graph.query(q).result_set[0][0]
        expected = datetime(year=1983, month=9, day=20, hour=4, minute=29, second=9, tzinfo=timezone.utc)
        self.env.assertEqual(actual, expected)

        try:
            q = """RETURN duration({years:1, months:1, days:1, hours:1, minutes:1, seconds:1})
                   -
                   localdatetime({year:1984, month:10, day:21, hour:5, minute:30, second:10})"""
            self.graph.query(q)
            self.env.assertFalse(True)
        except Exception:
            pass
