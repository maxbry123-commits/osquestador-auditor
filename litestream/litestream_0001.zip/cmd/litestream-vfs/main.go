//go:build SQLITE3VFS_LOADABLE_EXT
// +build SQLITE3VFS_LOADABLE_EXT

package main

// import C is necessary export to the c-archive .a file

/*
typedef long long int sqlite3_int64;
typedef unsigned long long int sqlite3_uint64;
*/
import "C"

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"os"
	"strings"
	"time"
	"unsafe"

	"github.com/psanford/sqlite3vfs"

	"github.com/benbjohnson/litestream"

	// Import all replica backends to register their URL factories.
	_ "github.com/benbjohnson/litestream/abs"
	_ "github.com/benbjohnson/litestream/file"
	_ "github.com/benbjohnson/litestream/gs"
	_ "github.com/benbjohnson/litestream/nats"
	_ "github.com/benbjohnson/litestream/oss"
	_ "github.com/benbjohnson/litestream/s3"
	_ "github.com/benbjohnson/litestream/sftp"
	_ "github.com/benbjohnson/litestream/webdav"
)

func main() {}

//export LitestreamVFSRegister
func LitestreamVFSRegister() *C.char {
	var client litestream.ReplicaClient

	replicaURL := os.Getenv("LITESTREAM_REPLICA_URL")
	if replicaURL != "" {
		var err error
		client, err = litestream.NewReplicaClientFromURL(replicaURL)
		if err != nil {
			return C.CString(fmt.Sprintf("failed to create replica client: %s", err))
		}

		if err := client.Init(context.Background()); err != nil {
			return C.CString(fmt.Sprintf("failed to initialize replica client: %s", err))
		}
	}

	var level slog.Level
	switch strings.ToUpper(os.Getenv("LITESTREAM_LOG_LEVEL")) {
	case "DEBUG":
		level = slog.LevelDebug
	default:
		level = slog.LevelInfo
	}

	var logOutput io.Writer = os.Stdout
	if logFile := os.Getenv("LITESTREAM_LOG_FILE"); logFile != "" {
		f, err := os.OpenFile(logFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			return C.CString(fmt.Sprintf("failed to open log file: %s", err))
		}
		logOutput = f
	}
	logger := slog.New(slog.NewTextHandler(logOutput, &slog.HandlerOptions{Level: level}))

	vfs := litestream.NewVFS(client, logger)

	// Configure write support if enabled.
	if strings.ToLower(os.Getenv("LITESTREAM_WRITE_ENABLED")) == "true" {
		vfs.WriteEnabled = true

		if s := os.Getenv("LITESTREAM_SYNC_INTERVAL"); s != "" {
			d, err := time.ParseDuration(s)
			if err != nil {
				return C.CString(fmt.Sprintf("invalid LITESTREAM_SYNC_INTERVAL: %s", err))
			}
			vfs.WriteSyncInterval = d
		}

		if s := os.Getenv("LITESTREAM_BUFFER_PATH"); s != "" {
			vfs.WriteBufferPath = s
		}
	}

	// Configure hydration support if enabled.
	if strings.ToLower(os.Getenv("LITESTREAM_HYDRATION_ENABLED")) == "true" {
		vfs.HydrationEnabled = true

		if s := os.Getenv("LITESTREAM_HYDRATION_PATH"); s != "" {
			vfs.HydrationPath = s
		}
	}

	if err := sqlite3vfs.RegisterVFS("litestream", vfs); err != nil {
		return C.CString(fmt.Sprintf("failed to register VFS: %s", err))
	}

	return nil
}

//export GoLitestreamConfigure
func GoLitestreamConfigure(dbName *C.char, key *C.char, value *C.char) *C.char {
	name := C.GoString(dbName)
	k := C.GoString(key)
	v := C.GoString(value)

	cfg := litestream.GetVFSConfig(name)
	if cfg == nil {
		cfg = &litestream.VFSConfig{}
	}

	if err := cfg.Set(k, v); err != nil {
		return C.CString(err.Error())
	}

	litestream.SetVFSConfig(name, cfg)
	return nil
}

//export GoLitestreamRegisterConnection
func GoLitestreamRegisterConnection(dbPtr unsafe.Pointer, fileID C.sqlite3_uint64) *C.char {
	if err := litestream.RegisterVFSConnection(uintptr(dbPtr), uint64(fileID)); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export GoLitestreamUnregisterConnection
func GoLitestreamUnregisterConnection(dbPtr unsafe.Pointer) *C.char {
	litestream.UnregisterVFSConnection(uintptr(dbPtr))
	return nil
}

//export GoLitestreamSetTime
func GoLitestreamSetTime(dbPtr unsafe.Pointer, timestamp *C.char) *C.char {
	if timestamp == nil {
		return C.CString("timestamp required")
	}
	if err := litestream.SetVFSConnectionTime(uintptr(dbPtr), C.GoString(timestamp)); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export GoLitestreamResetTime
func GoLitestreamResetTime(dbPtr unsafe.Pointer) *C.char {
	if err := litestream.ResetVFSConnectionTime(uintptr(dbPtr)); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export GoLitestreamTime
func GoLitestreamTime(dbPtr unsafe.Pointer, out **C.char) *C.char {
	value, err := litestream.GetVFSConnectionTime(uintptr(dbPtr))
	if err != nil {
		return C.CString(err.Error())
	}
	if out != nil {
		*out = C.CString(value)
	}
	return nil
}

//export GoLitestreamTxid
func GoLitestreamTxid(dbPtr unsafe.Pointer, out **C.char) *C.char {
	value, err := litestream.GetVFSConnectionTXID(uintptr(dbPtr))
	if err != nil {
		return C.CString(err.Error())
	}
	if out != nil {
		*out = C.CString(value)
	}
	return nil
}

//export GoLitestreamLag
func GoLitestreamLag(dbPtr unsafe.Pointer, out *C.sqlite3_int64) *C.char {
	value, err := litestream.GetVFSConnectionLag(uintptr(dbPtr))
	if err != nil {
		return C.CString(err.Error())
	}
	if out != nil {
		*out = C.sqlite3_int64(value)
	}
	return nil
}
