package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"time"

	"github.com/benbjohnson/litestream"
)

// StopCommand represents the command to stop replication for a database.
type StopCommand struct{}

// Run executes the stop command.
func (c *StopCommand) Run(ctx context.Context, args []string) error {
	fs := flag.NewFlagSet("litestream-stop", flag.ContinueOnError)
	timeout := fs.Int("timeout", 30, "timeout in seconds")
	socketPath := fs.String("socket", "/var/run/litestream.sock", "control socket path")
	jsonOutput := fs.Bool("json", false, "output raw JSON")
	fs.Usage = c.Usage
	if err := fs.Parse(args); err != nil {
		return err
	}

	if fs.NArg() == 0 {
		return &usageError{
			message: "database path required",
			hint:    "litestream stop /path/to/db",
		}
	}
	if fs.NArg() > 1 {
		return fmt.Errorf("too many arguments")
	}

	dbPath := fs.Arg(0)

	// Create HTTP client that connects via Unix socket with timeout
	clientTimeout := time.Duration(*timeout) * time.Second
	client := &http.Client{
		Timeout: clientTimeout,
		Transport: &http.Transport{
			DialContext: func(_ context.Context, _, _ string) (net.Conn, error) {
				return net.DialTimeout("unix", *socketPath, clientTimeout)
			},
		},
	}

	req := litestream.StopRequest{
		Path:    dbPath,
		Timeout: *timeout,
	}
	reqBody, err := json.Marshal(req)
	if err != nil {
		return fmt.Errorf("failed to marshal request: %w", err)
	}

	resp, err := client.Post("http://localhost/stop", "application/json", bytes.NewReader(reqBody))
	if err != nil {
		return fmt.Errorf("failed to connect to control socket: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		var errResp litestream.ErrorResponse
		if err := json.Unmarshal(body, &errResp); err == nil && errResp.Error != "" {
			return fmt.Errorf("stop failed: %s", errResp.Error)
		}
		return fmt.Errorf("stop failed: %s", string(body))
	}

	var result litestream.StopResponse
	if err := json.Unmarshal(body, &result); err != nil {
		return fmt.Errorf("failed to parse response: %w", err)
	}

	confirmation := StartStopResult{
		Status: result.Status,
		DBPath: result.Path,
		State:  "stopped",
		TXID:   result.TXID,
		Socket: *socketPath,
	}
	if err := printStartStopResult(confirmation, *jsonOutput); err != nil {
		return err
	}

	return nil
}

// Usage prints the help text for the stop command.
func (c *StopCommand) Usage() {
	fmt.Println(`
usage: litestream stop [OPTIONS] DB_PATH

Stop replication for a database.
Stop always waits for shutdown and final sync.

Options:
  -timeout SECONDS
      Maximum time to wait in seconds (default: 30).

  -socket PATH
      Path to control socket (default: /var/run/litestream.sock).

  -json
      Output raw JSON instead of human-readable text.

Examples:
  # Stop replication for a database.
  $ litestream stop /path/to/db

  # Stop replication and emit a JSON confirmation.
  $ litestream stop -json /path/to/db

  # Stop replication using a non-default control socket.
  $ litestream stop -socket /tmp/litestream.sock /path/to/db

  # Stop replication and wait up to 10 seconds for final sync and shutdown.
  $ litestream stop -timeout 10 /path/to/db
`[1:])
}
