from typing import Optional, Type
from e2b_code_interpreter import AsyncSandbox
from e2b_code_interpreter import SandboxState as E2B_SandboxState

from .base import SandboxBackend
from ....schema.sandbox import (
    SandboxCreateConfig,
    SandboxUpdateConfig,
    SandboxRuntimeInfo,
    SandboxCommandOutput,
    SandboxStatus,
)
from ....env import DEFAULT_CORE_CONFIG, LOG as logger
from ...s3 import S3_CLIENT


def _convert_e2b_state(state: E2B_SandboxState) -> SandboxStatus:
    if state == E2B_SandboxState.RUNNING:
        return SandboxStatus.RUNNING
    elif state == E2B_SandboxState.PAUSED:
        return SandboxStatus.PAUSED
    raise ValueError(f"Unknown sandbox state: {state}")


class E2BSandboxBackend(SandboxBackend):
    """E2B Sandbox Backend using e2b_code_interpreter SDK.

    This backend manages cloud sandboxes through E2B's infrastructure,
    providing secure isolated environments for code execution.
    """

    type: str = "e2b"

    def __init__(
        self, api_key: str, default_template: str, domain_base_url: str | None = None
    ):
        """Initialize the E2B sandbox backend.

        Args:
            domain_base_url: The E2B domain base URL (for BYOC or custom domains). None for default E2B cloud.
            api_key: The E2B API key for authentication.
        """
        self.__domain_base_url = domain_base_url
        self.__default_template = default_template
        self.__api_key = api_key

    async def connect_sandbox(self, sandbox_id: str) -> AsyncSandbox:
        return await AsyncSandbox.connect(
            sandbox_id=str(sandbox_id),
            api_key=self.__api_key,
            domain=self.__domain_base_url,
            timeout=DEFAULT_CORE_CONFIG.sandbox_default_keepalive_seconds,
        )

    @classmethod
    def from_default(cls: Type["E2BSandboxBackend"]) -> "E2BSandboxBackend":
        return cls(
            api_key=DEFAULT_CORE_CONFIG.e2b_api_key,
            default_template=DEFAULT_CORE_CONFIG.sandbox_default_template,
            domain_base_url=DEFAULT_CORE_CONFIG.e2b_domain_base_url,
        )

    async def start_sandbox(
        self, create_config: SandboxCreateConfig
    ) -> SandboxRuntimeInfo:
        """Create and start a new E2B sandbox.

        Args:
            create_config: Configuration for the sandbox including timeout, CPU, memory, etc.

        Returns:
            Runtime information about the created sandbox.
        """
        template = create_config.template or self.__default_template
        sandbox = await AsyncSandbox.create(
            template=template,
            api_key=self.__api_key,
            domain=self.__domain_base_url,
            timeout=DEFAULT_CORE_CONFIG.sandbox_default_keepalive_seconds,
            metadata=create_config.additional_configs,
        )
        info = await sandbox.get_info()
        return SandboxRuntimeInfo(
            sandbox_id=info.sandbox_id,
            sandbox_status=_convert_e2b_state(info.state),
            sandbox_created_at=info.started_at,
            sandbox_expires_at=info.end_at,
        )

    async def kill_sandbox(self, sandbox_id: str) -> bool:
        """Kill a running sandbox.

        Args:
            sandbox_id: The ID of the sandbox to kill.
        """
        r = await AsyncSandbox.kill(
            sandbox_id=str(sandbox_id),
            api_key=self.__api_key,
            domain=self.__domain_base_url,
        )
        return r

    async def get_sandbox(self, sandbox_id: str) -> SandboxRuntimeInfo:
        """Get runtime information about a sandbox.

        Args:
            sandbox_id: The ID of the sandbox to query.

        Returns:
            Runtime information including status, creation time, and expiration.

        Raises:
            ValueError: If the sandbox is not found or not running.
        """
        try:
            # Connect to the sandbox to verify it exists and is running
            sandbox = await self.connect_sandbox(sandbox_id)

            # Get sandbox info using the SDK method
            info = await sandbox.get_info()

            return SandboxRuntimeInfo(
                sandbox_id=info.sandbox_id,
                sandbox_status=_convert_e2b_state(info.state),
                sandbox_created_at=info.started_at,
                sandbox_expires_at=info.end_at,
            )
        except Exception as e:
            raise ValueError(f"Sandbox with ID {sandbox_id} not found: {e}")

    async def update_sandbox(
        self, sandbox_id: str, update_config: SandboxUpdateConfig
    ) -> SandboxRuntimeInfo:
        """Update sandbox configuration, such as extending the timeout.

        Args:
            sandbox_id: The ID of the sandbox to update.
            update_config: Configuration updates to apply.

        Returns:
            Runtime information about the updated sandbox.
        """
        sandbox = await self.connect_sandbox(sandbox_id)
        await sandbox.set_timeout(update_config.keepalive_longer_by_seconds)
        info = await sandbox.get_info()
        return SandboxRuntimeInfo(
            sandbox_id=info.sandbox_id,
            sandbox_status=_convert_e2b_state(info.state),
            sandbox_created_at=info.started_at,
            sandbox_expires_at=info.end_at,
        )

    async def exec_command(self, sandbox_id: str, command: str) -> SandboxCommandOutput:
        """Execute a shell command in the sandbox.

        Args:
            sandbox_id: The ID of the sandbox to execute the command in.
            command: The shell command to execute.

        Returns:
            The command output including stdout, stderr, and exit code.
        """
        sandbox = await self.connect_sandbox(sandbox_id)
        result = await sandbox.commands.run(cmd=command)

        return SandboxCommandOutput(
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
        )

    async def download_file(
        self, sandbox_id: str, from_sandbox_file: str, download_to_s3_key: str,
        user_kek: Optional[bytes] = None,
    ) -> bool:
        """Download a file from the sandbox and upload it to S3.

        Args:
            sandbox_id: The ID of the sandbox to download from.
            from_sandbox_file: The path to the file in the sandbox.
            download_to_s3_key: The full S3 key (path) to upload the file to.

        Returns:
            True if the download and upload were successful, False otherwise.
        """

        try:
            sandbox = await self.connect_sandbox(sandbox_id)

            # Read file content from sandbox
            content = await sandbox.files.read(from_sandbox_file)

            # Convert to bytes if necessary (files.read returns str or bytes)
            if isinstance(content, str):
                content_bytes = content.encode("utf-8")
            else:
                content_bytes = content

            # Upload to S3 using the provided key directly
            await S3_CLIENT.upload_object(
                key=download_to_s3_key,
                data=content_bytes,
                user_kek=user_kek,
            )

            logger.info(
                f"Downloaded file from sandbox {sandbox_id}: {from_sandbox_file} -> s3://{download_to_s3_key}"
            )
            return True

        except Exception as e:
            logger.error(
                f"Failed to download file from sandbox {sandbox_id}: {from_sandbox_file} -> {download_to_s3_key}, error: {e}"
            )
            return False

    async def upload_file(
        self, sandbox_id: str, from_s3_key: str, upload_to_sandbox_file: str,
        user_kek: Optional[bytes] = None,
    ) -> bool:
        """Download a file from S3 and upload it to the sandbox.

        Args:
            sandbox_id: The ID of the sandbox to upload to.
            from_s3_key: The S3 key to download the file from.
            upload_to_sandbox_file: The full path in the sandbox to upload the file to.

        Returns:
            True if the download and upload were successful, False otherwise.
        """
        try:
            # Download from S3
            content = await S3_CLIENT.download_object(key=from_s3_key, user_kek=user_kek)

            sandbox = await self.connect_sandbox(sandbox_id)

            # Write file to sandbox using the provided path directly
            await sandbox.files.write(upload_to_sandbox_file, content)

            logger.info(
                f"Uploaded file to sandbox {sandbox_id}: s3://{from_s3_key} -> {upload_to_sandbox_file}"
            )
            return True

        except Exception as e:
            logger.error(
                f"Failed to upload file to sandbox {sandbox_id}: {from_s3_key} -> {upload_to_sandbox_file}, error: {e}"
            )
            return False
