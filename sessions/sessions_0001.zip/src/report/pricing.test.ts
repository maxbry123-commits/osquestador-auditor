import { describe, test, expect, beforeEach } from 'bun:test';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  find,
  findFamily,
  computeCost,
  drainPricingWarnings,
  resetPricingWarnings,
  resetPricing,
  mergeRuntimePricing,
  parseLiteLLMPricing,
  type UsageCounts,
} from './pricing.ts';

const counts = (over: Partial<UsageCounts> = {}): UsageCounts => ({
  input: 0,
  output: 0,
  cacheRead: 0,
  cacheWrite: 0,
  ...over,
});

beforeEach(() => {
  resetPricingWarnings();
  // Drop any runtime layer a prior test merged so find() reads only the base map.
  resetPricing();
});

describe('find() matching', () => {
  test('exact match resolves the default model', () => {
    expect(find('claude-opus-4-8')).toBeDefined();
  });

  test('per-model entries that were the reported $0 bug all resolve', () => {
    for (const id of ['claude-opus-4-8', 'claude-fable-5', 'gpt-5.5', 'claude-opus-4-8-fast']) {
      expect(find(id), `${id} should resolve`).toBeDefined();
    }
  });

  test('normalized: dotted gpt-5.5 resolves (dots → dashes)', () => {
    const dotted = find('gpt-5.5');
    expect(dotted).toBeDefined();
  });

  test('dated suffix: 8-digit date is tolerated and matches the base key', () => {
    const dated = find('claude-opus-4-5-20251101');
    const base = find('claude-opus-4-5');
    expect(dated).toBeDefined();
    expect(base).toBeDefined();
    expect(dated).toEqual(base!);
  });

  test('version-boundary negative: claude-opus-4 does NOT match claude-opus-4-8', () => {
    const four = find('claude-opus-4');
    const fourEight = find('claude-opus-4-8');
    expect(fourEight).toBeDefined();
    // claude-opus-4 must resolve to its own (cheaper, legacy) rate, never the 4-8 rate.
    if (four) {
      expect(four.inputPerToken).not.toBe(fourEight!.inputPerToken);
    }
  });

  test('provider-prefixed ids bridge via the substring rule', () => {
    expect(find('anthropic/claude-opus-4-8')).toBeDefined();
    expect(find('openai/gpt-5.5')).toBeDefined();
  });

  test('-fast suffix resolves to the base rate (not a numeric version bump)', () => {
    expect(find('claude-opus-4-8-fast')).toEqual(find('claude-opus-4-8')!);
  });

  test('longest-key-wins when multiple candidates match', () => {
    // claude-opus-4-5-20251101 should prefer claude-opus-4-5 over claude-opus-4.
    const dated = find('claude-opus-4-5-20251101');
    expect(dated).toEqual(find('claude-opus-4-5')!);
    expect(dated).not.toEqual(find('claude-opus-4') ?? { inputPerToken: -1 });
  });

  test('completely unknown model returns undefined', () => {
    expect(find('totally-made-up-model-zzz')).toBeUndefined();
  });
});

describe('computeCost arithmetic', () => {
  test('exact match yields > 0 for a sample event', () => {
    expect(computeCost('claude-opus-4-8', counts({ input: 1000, output: 500 }))).toBeGreaterThan(0);
  });

  test('each reported-$0-bug model prices non-zero', () => {
    for (const id of ['claude-opus-4-8', 'claude-fable-5', 'gpt-5.5', 'claude-opus-4-8-fast']) {
      expect(
        computeCost(id, counts({ input: 1000, output: 1000, cacheRead: 1000, cacheWrite: 1000 })),
        `${id} should cost > 0`,
      ).toBeGreaterThan(0);
    }
  });

  test('known vector equals hand-computed value (per-token)', () => {
    // claude-opus-4-8: input 5e-6, output 25e-6, cacheWrite 6.25e-6, cacheRead 0.5e-6
    const cost = computeCost(
      'claude-opus-4-8',
      counts({ input: 1000, output: 2000, cacheRead: 4000, cacheWrite: 800 }),
    );
    const expected = 1000 * 5e-6 + 2000 * 25e-6 + 4000 * 0.5e-6 + 800 * 6.25e-6;
    expect(cost).toBeCloseTo(expected, 12);
  });

  test('1h cache-creation is priced at input×2 (5m stays at the cache_create rate)', () => {
    // opus-4-8: input 5e-6 → 1h rate 10e-6; cacheWrite (5m) rate 6.25e-6.
    const all1h = computeCost('claude-opus-4-8', counts({ cacheWrite: 1000, cacheWrite1h: 1000 }));
    const all5m = computeCost('claude-opus-4-8', counts({ cacheWrite: 1000, cacheWrite1h: 0 }));
    expect(all1h).toBeCloseTo(1000 * 10e-6, 12);
    expect(all5m).toBeCloseTo(1000 * 6.25e-6, 12);
    expect(all1h).toBeGreaterThan(all5m);
  });

  test('cache defaults applied when rates omitted (read = input*0.1, write = input*1.25)', () => {
    const map = parseLiteLLMPricing(
      JSON.stringify({
        'no-cache-model': { input_cost_per_token: 0.000002, output_cost_per_token: 0.000008 },
      }),
    );
    const p = map['no-cache-model']!;
    expect(p.cacheReadPerToken ?? p.inputPerToken * 0.1).toBeCloseTo(2e-6 * 0.1, 15);
    expect(p.cacheWritePerToken ?? p.inputPerToken * 1.25).toBeCloseTo(2e-6 * 1.25, 15);
  });
});

describe('tiered >200k pricing', () => {
  // Build a model with explicit above-200k rates via the fixture's claude-sonnet-4.
  const fixture = readFileSync(join(import.meta.dir, '__fixtures__', 'litellm-sample.json'), 'utf8');
  const map = parseLiteLLMPricing(fixture);
  const sonnet4 = map['claude-sonnet-4']!;

  test('the fixture entry carries above-200k tiers', () => {
    expect(sonnet4.inputPerTokenAbove200k).toBeDefined();
  });

  test('199k stays at base rate', () => {
    const c = sonnet4.inputPerToken;
    const at199 = 199_000 * c;
    // Recreate tiered() expectation: below threshold → all base.
    expect(at199).toBeCloseTo(199_000 * c, 9);
  });

  test('boundary 200k vs 201k: above-rate only applies to the overflow', () => {
    const base = sonnet4.inputPerToken;
    const above = sonnet4.inputPerTokenAbove200k!;
    const at200 = 200_000 * base;
    const at201 = 200_000 * base + 1_000 * above;
    expect(at201).toBeGreaterThan(at200);
    expect(at201 - at200).toBeCloseTo(1_000 * above, 9);
  });
});

describe('warning collector', () => {
  test('unknown model with tokens pushes a warning and returns 0', () => {
    const cost = computeCost('mystery-model-9', counts({ input: 100, output: 50 }));
    expect(cost).toBe(0);
    const warnings = drainPricingWarnings();
    expect(warnings).toHaveLength(1);
    expect(warnings[0]!.model).toBe('mystery-model-9');
    expect(warnings[0]!.tokens).toBe(150);
  });

  test('drain clears the collector', () => {
    computeCost('mystery-model-9', counts({ input: 100 }));
    expect(drainPricingWarnings()).toHaveLength(1);
    expect(drainPricingWarnings()).toHaveLength(0);
  });

  test('unknown model with ZERO tokens does not warn (no impact)', () => {
    const cost = computeCost('mystery-model-0', counts());
    expect(cost).toBe(0);
    expect(drainPricingWarnings()).toHaveLength(0);
  });

  test('known model never warns', () => {
    computeCost('claude-opus-4-8', counts({ input: 100, output: 100 }));
    expect(drainPricingWarnings()).toHaveLength(0);
  });
});

describe('parseLiteLLMPricing', () => {
  const fixture = readFileSync(join(import.meta.dir, '__fixtures__', 'litellm-sample.json'), 'utf8');

  test('extracts per-token fields and skips entries lacking input/output', () => {
    const map = parseLiteLLMPricing(fixture);
    expect(map['claude-opus-4-5']).toBeDefined();
    expect(map['claude-opus-4-5']!.inputPerToken).toBe(5e-6);
    expect(map['claude-opus-4-5']!.outputPerToken).toBe(25e-6);
    // sample_spec and the embedding entry (no output) must be skipped.
    expect(map['sample_spec']).toBeUndefined();
    expect(map['embedding-no-output']).toBeUndefined();
  });

  test('carries explicit cache + above-200k tiers when present', () => {
    const map = parseLiteLLMPricing(fixture);
    const s4 = map['claude-sonnet-4']!;
    expect(s4.cacheReadPerToken).toBe(0.3e-6);
    expect(s4.cacheWritePerToken).toBe(3.75e-6);
    expect(s4.inputPerTokenAbove200k).toBe(6e-6);
    expect(s4.outputPerTokenAbove200k).toBe(22.5e-6);
  });

  test('malformed JSON yields an empty map (never throws)', () => {
    expect(Object.keys(parseLiteLLMPricing('not json at all {'))).toHaveLength(0);
    expect(Object.keys(parseLiteLLMPricing('{}'))).toHaveLength(0);
  });
});

describe('mergeRuntimePricing / resetPricing', () => {
  test('runtime records win over the embedded snapshot + overrides', () => {
    const before = find('claude-opus-4-8')!;
    expect(before.inputPerToken).toBe(5e-6);
    mergeRuntimePricing({ 'claude-opus-4-8': { inputPerToken: 9e-6, outputPerToken: 99e-6 } });
    const after = find('claude-opus-4-8')!;
    expect(after.inputPerToken).toBe(9e-6);
    expect(after.outputPerToken).toBe(99e-6);
  });

  test('merge adds brand-new models that were not in the base map', () => {
    expect(find('totally-new-model-9')).toBeUndefined();
    mergeRuntimePricing({ 'totally-new-model-9': { inputPerToken: 1e-6, outputPerToken: 2e-6 } });
    expect(find('totally-new-model-9')).toBeDefined();
  });

  test('resetPricing drops the runtime layer and restores the base map', () => {
    mergeRuntimePricing({ 'claude-opus-4-8': { inputPerToken: 9e-6, outputPerToken: 99e-6 } });
    expect(find('claude-opus-4-8')!.inputPerToken).toBe(9e-6);
    resetPricing();
    expect(find('claude-opus-4-8')!.inputPerToken).toBe(5e-6);
  });
});

describe('family fallback', () => {
  // An unpriced model in a known family is billed at that family's newest rate
  // and flagged, rather than silently counted as $0.
  test('an unreleased opus is billed at the newest opus rate, and flagged', () => {
    expect(find('claude-opus-9')).toBeUndefined();
    const cost = computeCost('claude-opus-9', counts({ input: 1_000_000 }));
    expect(cost).toBeCloseTo(5, 6); // claude-opus-4-8 input rate
    const [w] = drainPricingWarnings();
    expect(w).toMatchObject({ model: 'claude-opus-9', tokens: 1_000_000, pricedAs: 'claude-opus-4-8' });
  });

  test('picks the highest version in the family, not the first or longest key', () => {
    const viaFamily = computeCost('claude-sonnet-9', counts({ input: 1_000_000 }));
    expect(viaFamily).toBeCloseTo(3, 6); // claude-sonnet-4-6, not a 4-5 or legacy rate
  });

  test('a runtime price for the winning family key is used over the frozen override', () => {
    mergeRuntimePricing({ 'claude-opus-4-8': { inputPerToken: 40e-6, outputPerToken: 0 } });
    expect(computeCost('claude-opus-9', counts({ input: 1_000_000 }))).toBeCloseTo(40, 6);
  });

  test('a model in no known family is still $0 and warned WITHOUT a pricedAs', () => {
    expect(computeCost('llama-3-70b-local', counts({ input: 1_000_000 }))).toBe(0);
    const [w] = drainPricingWarnings();
    expect(w!.pricedAs).toBeUndefined();
  });

  test('a loose stem never swallows a neighbouring family', () => {
    // Asserted on findFamily directly: gpt-4o has a real price of its own, so
    // going through computeCost would test find(), not the stem rule.
    expect(findFamily('gpt-4o-mini')).toBeUndefined();
    expect(findFamily('claude-instant-1')).toBeUndefined();
    expect(findFamily('claude-opus-9')?.key).toBe('claude-opus-4-8');
  });

  test('a priced model never goes near the fallback', () => {
    computeCost('claude-opus-4-8', counts({ input: 1_000_000 }));
    expect(drainPricingWarnings()).toEqual([]);
  });

  // Pi records bare OpenRouter model ids ('moonshotai/kimi-k3'); the snapshot
  // keys those families with a provider prefix, so the fallback must draw
  // candidates from the full map, not just BUILTIN_OVERRIDES.
  test('an unreleased kimi is billed at the newest kimi rate, and flagged', () => {
    expect(find('moonshotai/kimi-k3')).toBeUndefined();
    const cost = computeCost('moonshotai/kimi-k3', counts({ input: 1_000_000 }));
    expect(cost).toBeGreaterThan(0);
    const [w] = drainPricingWarnings();
    expect(w!.model).toBe('moonshotai/kimi-k3');
    expect(w!.pricedAs).toMatch(/kimi-k2\.5/i);
  });

  test('an unreleased glm is billed at the newest glm rate', () => {
    expect(find('z-ai/glm-5.2')).toBeUndefined();
    expect(findFamily('z-ai/glm-5.2')?.key).toBe('openrouter/z-ai/glm-5.1');
    expect(computeCost('z-ai/glm-5.2', counts({ input: 1_000_000 }))).toBeGreaterThan(0);
  });

  test('a prefixed stem only matches at a path-segment boundary', () => {
    // 'kimi-k' must not match inside an unrelated id like 'fookimi-k3'.
    expect(findFamily('fookimi-k3')).toBeUndefined();
  });
});
