// Normalization, content-addressed fingerprinting, and deterministic record
// construction. Everything in this file must be a pure function of its inputs
// (gitAuthorEmail excepted, which reads the machine's git identity once), because
// the determinism criterion asserts full-record JSON equality across two runs —
// not just id equality.

import {
  MEMORY_SCHEMA_VERSION,
  type MemoryEvidence,
  type MemoryKind,
  type MemoryRecord,
  type MemoryScope,
  type MemoryState,
} from './types';

/** 'YYYY-MM-DD'. The index stores '?' for an undated transcript, which must never reach a record. */
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Collapse every whitespace run to a single space and trim. Casing is preserved —
 * the stored `text` is what a human reads back, so "Never commit to main" must not
 * become "never commit to main". Case folding happens inside `fingerprint`, so two
 * records differing only in case still collapse to one id.
 */
export function normalizeText(raw: string): string {
  return raw.replace(/\s+/g, ' ').trim();
}

/**
 * Content-addressed identity: `sha256:<hex>` over the case-folded normalized text.
 * Bun.CryptoHasher is built in, so this adds no dependency to a binary that
 * deliberately ships with two.
 */
export function fingerprint(normalized: string): string {
  const hasher = new Bun.CryptoHasher('sha256');
  hasher.update(normalized.toLowerCase());
  return `sha256:${hasher.digest('hex')}`;
}

/**
 * The machine's git identity, or 'unknown'. A missing identity must not block
 * mining — `git config user.email` exits non-zero with empty output when no
 * global config exists, and `git` may be absent entirely. Same swallow-to-a-value
 * shape as src/repo.ts:14-22.
 */
export function gitAuthorEmail(): string {
  try {
    const result = Bun.spawnSync(['git', 'config', 'user.email']);
    if (result.exitCode !== 0) return 'unknown';
    const email = new TextDecoder().decode(result.stdout).trim();
    return email || 'unknown';
  } catch {
    return 'unknown';
  }
}

export interface BuildRecordInput {
  /** Raw source text; normalized (and fingerprinted) here, never by the caller. */
  text: string;
  kind?: MemoryKind;
  scope: MemoryScope;
  author: string;
  /** Contributing session file paths, in any order — deduped and sorted here. */
  sessions: string[];
  /** 'YYYY-MM-DD' dates of the contributing sessions, in any order. */
  dates: string[];
  /** Distinct phrasings after byte-exact collapse. Always 1 in Phase 1. */
  distinctPhrasings: number;
  state?: MemoryState;
  snoozedUntil?: string | null;
  /** Defaults to false. Set at triage, never derived — see MemoryRecord.alwaysOn. */
  alwaysOn?: boolean;
}

function buildEvidence(input: BuildRecordInput): MemoryEvidence {
  // Sorted + deduped: unsorted arrays are the single most likely source of
  // run-to-run byte differences, and two sessions can contribute the same path
  // only through a caller bug — dedupe rather than double-count it.
  const sessions = [...new Set(input.sessions)].sort();
  // String comparison is the correct ordering for 'YYYY-MM-DD'; no Date parsing,
  // no locale formatting, nothing that varies by machine timezone.
  const dates = input.dates.filter((d) => ISO_DATE.test(d)).sort();
  return {
    distinctPhrasings: input.distinctPhrasings,
    sessions,
    firstSeen: dates[0] ?? '',
    lastSeen: dates[dates.length - 1] ?? '',
  };
}

/**
 * Union two evidence blobs. Monotonic in every field: the result never reports fewer
 * phrasings, fewer sessions, or a narrower date range than either input.
 *
 * This is what makes `upsertCandidates` non-destructive, and it is load-bearing rather
 * than defensive. Evidence is derived from transcripts, but never from ALL of them at
 * once: `--since-last` mines only the files that changed (src/memory/watermark.ts), and
 * `mergeInto` assembles a `distinctPhrasings` count no mine can reproduce because
 * paraphrase clustering is an LLM judgment (src/memory/triage.ts). A replace-on-conflict
 * write loses both, and neither is rebuildable — a merge decision exists nowhere else.
 *
 * `distinctPhrasings` takes the MAX, never the sum, for the reason `toRecord` documents
 * (src/memory/portable.ts): a re-mine over the same transcripts must be idempotent, and
 * a count that inflates on every run permanently suppresses a snoozed memory, because
 * `shouldResurface` compares the fresh count against the stored one.
 *
 * Dates go through the same ISO_DATE filter as `buildEvidence` rather than a bare
 * min/max: `''` is a legal stored value for an undated record, it sorts before every
 * real date, and it would otherwise always win `firstSeen`.
 */
export function unionEvidence(prior: MemoryEvidence, fresh: MemoryEvidence): MemoryEvidence {
  const dates = [prior.firstSeen, prior.lastSeen, fresh.firstSeen, fresh.lastSeen]
    .filter((d) => ISO_DATE.test(d))
    .sort();
  return {
    distinctPhrasings: Math.max(prior.distinctPhrasings, fresh.distinctPhrasings),
    sessions: [...new Set([...prior.sessions, ...fresh.sessions])].sort(),
    firstSeen: dates[0] ?? '',
    lastSeen: dates[dates.length - 1] ?? '',
  };
}

/**
 * Assemble a memory record with a stable field order. Field order matters: the
 * determinism check is `JSON.stringify(run1) === JSON.stringify(run2)`, and
 * JSON.stringify preserves insertion order.
 *
 * `kind` defaults to 'instruction' because the mine narrows on corrective,
 * imperative language. Distinguishing an instruction from a durable piece of
 * information is a judgment call and belongs to the Phase 2 triage skill.
 *
 * `alwaysOn` defaults to false for the same reason `state` defaults to 'candidate':
 * conditional is the norm and bypassing the topic matcher is the deliberate exception.
 * A mine can never set it — nothing in a transcript says "this one is a standing
 * constraint", only a human does.
 */
export function buildRecord(input: BuildRecordInput): MemoryRecord {
  const text = normalizeText(input.text);
  return {
    v: MEMORY_SCHEMA_VERSION,
    id: fingerprint(text),
    text,
    kind: input.kind ?? 'instruction',
    scope: { type: input.scope.type, key: input.scope.key },
    author: input.author,
    evidence: buildEvidence(input),
    state: input.state ?? 'candidate',
    snoozedUntil: input.snoozedUntil ?? null,
    alwaysOn: input.alwaysOn ?? false,
    // A freshly built record is always standalone. Merging is a triage-time judgment
    // (src/memory/triage.ts `mergeInto`); nothing a mine can see decides it.
    mergedInto: null,
  };
}
